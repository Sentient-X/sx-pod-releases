"""Dependency-free task contracts shared across the platform lifecycle.

Taskpedia owns YAML parsing, ontology validation, and the YAML->core reshape
(`_template_to_core`). This module owns the immutable vocabulary that crosses
Experience, Worlds, Autonomy, and Fleet **and** contract *identity*: minting the
canonical bytes (`canonical_json`), the content-addressed ref (`contract_ref`),
and the one legal, fail-closed reader every pillar uses (`from_canonical_json`).
Constructing a record is never validation — only `from_canonical_json` is.
"""

import json
import math
from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from typing import Literal, NewType, Protocol, TypeAlias, TypeVar, cast

from sx_contracts import decode
from sx_contracts.capabilities import (
    Capability,
    CapabilitySet,
    TaskCapabilityRequirements,
    TaskRoleId,
    TaskRoleRequirement,
)
from sx_contracts.content import ContentRefError, Sha256Digest
from sx_contracts.decode import DecodeError
from sx_contracts.identity import JsonValue, content_id
from sx_contracts.identity import canonical_json as canonical_document

TaskContractPart: TypeAlias = Literal["value", "suite", "document"]


class TaskContractError(ValueError):
    """Fail-closed task-contract identity and parse failures.

    Subclasses `ValueError` so that embedding `TaskContractRef` as a pydantic field
    turns a bad digest into a 422 (pydantic only converts `ValueError`/`AssertionError`
    raised in validation) — the inbound-parse contract the mirrors used to enforce by
    hand. Callers `except TaskContractError`, never bare `ValueError`.

    ``part`` names the failed contract part: an intrinsic ``value`` law, an
    `EvaluationSuiteRef` ``suite`` fact (its digest stays a bare `str` because a
    `SuiteManifest` lives in `sx-worlds`, which this package may not import), or
    the canonical ``document`` form (`MalformedContractError`).
    """

    def __init__(self, part: TaskContractPart, message: str) -> None:
        self.part: TaskContractPart = part
        super().__init__(message)


class MalformedContractError(TaskContractError, DecodeError):
    """Canonical JSON that is not the exact structural inverse of `asdict(TaskContract)`.

    It *is* a decode failure — same two facts, same sentence — so the shared kit
    raises it directly and this module never restates a shape check.
    """

    def __init__(self, path: str, expected: str) -> None:
        self.part: TaskContractPart = "document"
        DecodeError.__init__(self, path, expected)


TaskId = NewType("TaskId", str)
TaskFamilyId = NewType("TaskFamilyId", str)
TaskSchemaVersion = NewType("TaskSchemaVersion", str)
SkillName = NewType("SkillName", str)
ObjectHead = NewType("ObjectHead", str)
RigId = NewType("RigId", str)
TaskStationRef = NewType("TaskStationRef", str)

TASK_SCHEMA_VERSION = TaskSchemaVersion("1.1")


class Relation(StrEnum):
    """What a task's goal changes in the world — the closed codomain of embodied
    work. Anything a robot can be asked to do changes matter's geometry,
    connectivity, integrity, or state; information; or a human's body or mind.
    A counterexample extends this enum by one member, never a parallel taxonomy."""

    GEOMETRY = "geometry"
    ATTACHMENT = "attachment"
    TOPOLOGY = "topology"
    MATERIAL_STATE = "material_state"
    INFORMATION = "information"
    HUMAN_BODY = "human_body"
    HUMAN_MIND = "human_mind"


class Counterparty(StrEnum):
    """Who or what the task acts with, beyond inert objects."""

    NONE = "none"
    SYSTEM = "system"
    HUMAN_BODY = "human_body"
    HUMAN_MIND = "human_mind"


class TaskHorizon(StrEnum):
    SHORT = "short"
    MEDIUM = "medium"
    LONG = "long"


class ReasoningKind(StrEnum):
    NONE = "none"
    SPATIAL = "spatial"
    SEQUENTIAL = "sequential"
    PUZZLE = "puzzle"


class ComplexityAxis(StrEnum):
    """One axis of *why* a task is hard — the object-hand-environment interaction,
    never the hardware (that is `Capability`) and never how long it takes (that is
    `TaskHorizon`). Rising complexity on an axis means the tolerance envelope
    narrows or concentrates on specific coordinates; the state space does not grow.

    A task carries its *dominant* axes in rank order, most dominant first — a
    membership set, never a numeric score: no rubric exists that would make a
    per-axis magnitude an authored fact rather than an invention.
    """

    GEOM = "geom"
    """How narrow is the set of valid pose and contact configurations?"""
    FORCE = "force"
    """How precisely must force/torque be regulated?"""
    CONTACT = "contact"
    """How many distinct contact modes, and how often do they change?"""
    OBS = "obs"
    """How much task-critical state is hidden from the sensors?"""
    DEFORM = "deform"
    """How many shape degrees of freedom, and how history-dependent are they?"""
    DYN = "dyn"
    """How fast does the state change, and how much does timing decide?"""


class FailureConditionKind(StrEnum):
    """The closed vocabulary of ways a trial fails beyond missing its goal.

    Outcome failures (`DAMAGE`, `DROP`, `OUTCOME_TOLERANCE`) are states the world
    must not end in; process failures (`PROCESS_CONSTRAINT`, `ATTEMPT_LIMIT`,
    `SIDE_EFFECT`) are ways of succeeding that do not count — a trial that reaches
    the goal by a forbidden route is a failure, which is exactly what a bare
    success rate can never express.
    """

    DAMAGE = "damage"
    """An object, fixture, or workpiece is damaged or deformed."""
    DROP = "drop"
    """An object is dropped or thrown."""
    PROCESS_CONSTRAINT = "process_constraint"
    """A forbidden method was used: tool use, external assistance, two-hand use,
    excessive force, a forbidden strategy inversion."""
    ATTEMPT_LIMIT = "attempt_limit"
    """A bounded retry was exceeded; ``limit`` carries the bound."""
    SIDE_EFFECT = "side_effect"
    """Task-external state changed: another switch toggled, another valve turned,
    the scene disturbed outside the task's own objects."""
    OUTCOME_TOLERANCE = "outcome_tolerance"
    """The end state exists but misses its quantified band: overshoot past a mark,
    residual moisture, misalignment beyond tolerance, wrong orientation."""


class TaskFamilyState(StrEnum):
    DRAFT = "draft"
    ACTIVE = "active"
    RETIRED = "retired"


class EvidenceRelation(StrEnum):
    EXACT = "exact"
    FRAGMENT = "fragment"
    ANALOG = "analog"


class EvidenceOrigin(StrEnum):
    EXISTING = "existing"
    FACTORY_ADDED = "factory_added"


class ObjectRole(StrEnum):
    FOCUS = "focus"
    FIXTURE = "fixture"
    TOOL = "tool"
    CONTAINER = "container"


class ObjectMix(StrEnum):
    IDENTICAL = "identical"
    VARIED = "varied"


class OperatorTier(StrEnum):
    ANY = "any"
    TRAINED = "trained"
    EXPERT = "expert"


class DiversificationScheme(StrEnum):
    COVERAGE_DESIGN = "coverage_design"
    FULL_FACTORIAL = "full_factorial"
    SCRIPTED = "scripted"


class AdaptationKind(StrEnum):
    NONE = "none"
    FAILURE_SEEKING = "failure_seeking"


class FillState(StrEnum):
    EMPTY = "empty"
    QUARTER = "quarter"
    HALF = "half"
    THREE_QUARTER = "three_quarter"
    FULL = "full"


class DemonstrationPace(StrEnum):
    SLOW = "slow"
    NORMAL = "normal"
    FAST = "fast"


class PerturbationKind(StrEnum):
    NONE = "none"
    STATIC_REPOSITION = "static_reposition"
    DYNAMIC_NUDGE = "dynamic_nudge"
    MOVING_TARGET = "moving_target"


class ObjectCondition(StrEnum):
    NEW = "new"
    GOOD = "good"
    WORN = "worn"
    DAMAGED = "damaged"


def _nonempty(value: str, field: str) -> None:
    if not value.strip():
        raise TaskContractError("value", f"{field} must not be empty")


def _finite(value: float, field: str) -> None:
    if isinstance(value, bool) or not math.isfinite(value):
        raise TaskContractError("value", f"{field} must be finite")


def _positive_integer(value: int, field: str) -> None:
    if isinstance(value, bool) or value <= 0:
        raise TaskContractError("value", f"{field} must be a positive integer")


def _unique(values: tuple[object, ...], field: str) -> None:
    if len(set(values)) != len(values):
        raise TaskContractError("value", f"{field} must not contain duplicates")


@dataclass(frozen=True, slots=True)
class TaskStep:
    """One step of the task's authored decomposition.

    ``reversible`` states whether re-running this step from its own failure leaves
    the world in a state the step can be attempted from again. It is the retry
    authority a long-horizon runtime needs: a reversible step may be re-issued
    under its lease, an irreversible one escalates instead (re-pouring water that
    already reached the grounds does not undo the first pour). The default is
    ``False`` because the unsafe direction is the permissive one — an author opts
    a step into retry, never out of it.
    """

    skill: SkillName
    object: str | None = None
    target: str | None = None
    when: str | None = None
    until: str | None = None
    note: str | None = None
    reversible: bool = False

    def __post_init__(self) -> None:
        _nonempty(str(self.skill), "task step skill")
        for field, value in (
            ("object", self.object),
            ("target", self.target),
            ("when", self.when),
            ("until", self.until),
            ("note", self.note),
        ):
            if value is not None:
                _nonempty(value, f"task step {field}")

    @property
    def instruction(self) -> str:
        """This step as the text something is told to do — the one such rendering.

        A long-horizon step reaches two independent consumers as text: the sequencer that
        issues it to a policy at execution time, and the training loader that conditions a
        step-trained checkpoint on it. They must agree byte-for-byte or the policy is served
        a phrasing it never trained on, so the rendering lives here rather than once in each.

        **Frozen**: ``pi0-step/v1``'s model input is this string, and every step-conditioned
        checkpoint replays it forever. Changing a word here mints a new input dialect (golden
        tests pin it on both sides). Only the executable half renders — ``skill``/``object``/
        ``target`` say what to do and ``until`` says when it is finished, the termination
        condition the policy must watch for. ``when`` is a precondition the sequencer already
        resolved before issuing the step, and ``note`` is an authoring aid for humans;
        conditioning on either would teach a policy to act on facts it cannot observe.
        """
        text = f"{self.skill} {self.object}" if self.object else str(self.skill)
        if self.target:
            text = f"{text} to {self.target}"
        if self.until:
            text = f"{text} until {self.until}"
        return text


@dataclass(frozen=True, slots=True)
class TaskpediaCodeRef:
    code: str
    relation: EvidenceRelation
    origin: EvidenceOrigin | None = None

    def __post_init__(self) -> None:
        _nonempty(self.code, "taskpedia code")


@dataclass(frozen=True, slots=True)
class CountInterval:
    minimum: int
    maximum: int

    def __post_init__(self) -> None:
        if (
            isinstance(self.minimum, bool)
            or isinstance(self.maximum, bool)
            or self.minimum < 0
            or self.maximum < self.minimum
        ):
            raise TaskContractError("value", "count interval requires 0 <= minimum <= maximum")


@dataclass(frozen=True, slots=True)
class TaskObject:
    role: ObjectRole
    head: ObjectHead
    count: CountInterval
    mix: ObjectMix
    options: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        _nonempty(str(self.head), "task object head")
        if any(not option.strip() for option in self.options):
            raise TaskContractError("value", "task object options must not be empty")
        _unique(cast(tuple[object, ...], self.options), "task object options")


@dataclass(frozen=True, slots=True)
class TaskEnvironment:
    stations: tuple[TaskStationRef, ...]
    lighting: tuple[str, ...]
    surfaces: tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.stations:
            raise TaskContractError("value", "task environment requires a station")
        for field, values in (
            ("stations", self.stations),
            ("lighting", self.lighting),
            ("surfaces", self.surfaces),
        ):
            if any(not str(value).strip() for value in values):
                raise TaskContractError(
                    "value", f"task environment {field} must not contain empties"
                )
            _unique(cast(tuple[object, ...], values), f"task environment {field}")


@dataclass(frozen=True, slots=True)
class DistractorPlan:
    easy: str
    medium: str
    hard: str

    def __post_init__(self) -> None:
        for field, value in (("easy", self.easy), ("medium", self.medium), ("hard", self.hard)):
            _nonempty(value, f"distractor plan {field}")


@dataclass(frozen=True, slots=True)
class InitialPosePlan:
    object_bins: tuple[str, ...]
    robot_bins: tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.object_bins or not self.robot_bins:
            raise TaskContractError("value", "initial pose plan requires object and robot bins")
        for field, values in (("object_bins", self.object_bins), ("robot_bins", self.robot_bins)):
            if any(not value.strip() for value in values):
                raise TaskContractError("value", f"initial pose {field} must not contain empties")
            _unique(cast(tuple[object, ...], values), f"initial pose {field}")


@dataclass(frozen=True, slots=True)
class ObjectDiversification:
    role: ObjectRole
    instances: tuple[str, ...]
    justification: str

    def __post_init__(self) -> None:
        if not self.instances or any(not value.strip() for value in self.instances):
            raise TaskContractError("value", "object diversification requires named instances")
        _unique(cast(tuple[object, ...], self.instances), "object diversification instances")
        _nonempty(self.justification, "object diversification justification")


@dataclass(frozen=True, slots=True)
class DiversificationPlan:
    scheme: DiversificationScheme
    budget: int
    adapt: AdaptationKind
    object_scheme: ObjectDiversification | None = None

    def __post_init__(self) -> None:
        _positive_integer(self.budget, "diversification budget")


@dataclass(frozen=True, slots=True)
class VariationPlan:
    fill_states: tuple[FillState, ...] = ()
    media: tuple[str, ...] = ()
    pace: tuple[DemonstrationPace, ...] = ()
    perturbations: tuple[PerturbationKind, ...] = ()
    conditions: tuple[ObjectCondition, ...] = ()
    recovery_share: float | None = None
    cameras: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not any(
            (
                self.fill_states,
                self.media,
                self.pace,
                self.perturbations,
                self.conditions,
                self.recovery_share is not None,
                self.cameras,
            )
        ):
            raise TaskContractError("value", "variation plan must contain at least one variation")
        if self.recovery_share is not None:
            _finite(self.recovery_share, "variation recovery_share")
            if not 0.0 <= self.recovery_share <= 1.0:
                raise TaskContractError("value", "variation recovery_share must be within [0, 1]")
        for field, values in (("media", self.media), ("cameras", self.cameras)):
            if any(not value.strip() for value in values):
                raise TaskContractError("value", f"variation {field} must not contain empties")
        for field, values in (
            ("fill_states", self.fill_states),
            ("media", self.media),
            ("pace", self.pace),
            ("perturbations", self.perturbations),
            ("conditions", self.conditions),
            ("cameras", self.cameras),
        ):
            _unique(cast(tuple[object, ...], values), f"variation {field}")


@dataclass(frozen=True, slots=True)
class CapturePlan:
    episodes_per_scenario_max: int | None = None
    episode_minutes_est: float | None = None

    def __post_init__(self) -> None:
        if self.episodes_per_scenario_max is None and self.episode_minutes_est is None:
            raise TaskContractError("value", "capture plan must contain at least one limit")
        if self.episodes_per_scenario_max is not None:
            _positive_integer(self.episodes_per_scenario_max, "capture episodes_per_scenario_max")
        if self.episode_minutes_est is not None:
            _finite(self.episode_minutes_est, "capture episode_minutes_est")
            if self.episode_minutes_est <= 0:
                raise TaskContractError("value", "capture episode_minutes_est must be positive")


class MeasureKind(StrEnum):
    """The closed vocabulary of measurable things a goal predicate can assert about.

    These strings are the wire: they are what a stored contract's canonical bytes say,
    so changing one is a data-contract break that must fail closed at parse. They lived
    spelled out three times — the document renderer, the parser's dispatch, and the
    parser's own error message — which is exactly the second-enumeration drift the
    layering rules exist to stop. One name each, here.
    """

    PLANAR_DISTANCE_TO = "planar_distance_to"
    VERTICAL_DISTANCE_TO = "vertical_distance_to"
    ORIENTATION_ERROR_TO = "orientation_error_to"
    UPRIGHT_ORIENTATION_ERROR = "upright_orientation_error"
    FRACTION_TRANSFERRED_TO = "fraction_transferred_to"
    COUNT_WITHIN = "count_within"
    JOINT_FRACTION_AT_LEAST = "joint_fraction_at_least"
    BINARY_STATE_IS = "binary_state_is"
    JOINT_ANGLE_OUTSIDE = "joint_angle_outside"
    CONTACT_WITH = "contact_with"


class ComparisonKind(StrEnum):
    """How a measured quantity is compared against a goal's threshold. Wire values."""

    AT_MOST = "at_most"
    AT_LEAST = "at_least"
    EXACTLY = "exactly"
    WITHIN = "within"


@dataclass(frozen=True, slots=True)
class PlanarDistanceTo:
    reference: str

    def __post_init__(self) -> None:
        _nonempty(self.reference, "planar-distance reference")


@dataclass(frozen=True, slots=True)
class VerticalDistanceTo:
    reference: str

    def __post_init__(self) -> None:
        _nonempty(self.reference, "vertical-distance reference")


@dataclass(frozen=True, slots=True)
class OrientationErrorTo:
    reference: str

    def __post_init__(self) -> None:
        _nonempty(self.reference, "orientation-error reference")


@dataclass(frozen=True, slots=True)
class UprightOrientationError:
    pass


@dataclass(frozen=True, slots=True)
class FractionTransferredTo:
    reference: str

    def __post_init__(self) -> None:
        _nonempty(self.reference, "fraction-transferred reference")


@dataclass(frozen=True, slots=True)
class CountWithin:
    reference: str

    def __post_init__(self) -> None:
        _nonempty(self.reference, "count-within reference")


BINARY_STATE_THRESHOLD = 0.5
"""Where a two-state articulation flips: at or past half its travel it reads *on*."""


@dataclass(frozen=True, slots=True)
class JointFractionAtLeast:
    """The named articulation has travelled at least ``fraction`` of its range.

    A truth-valued measure: it reads 1.0 when the articulation's normalized joint
    fraction (0.0 at the range's lower bound, 1.0 at its upper) has reached
    ``fraction``, else 0.0 — so its comparison grades a truth value, not a distance.
    """

    articulation: str
    fraction: float

    def __post_init__(self) -> None:
        _nonempty(self.articulation, "joint-fraction articulation")
        _finite(self.fraction, "joint-fraction threshold")
        if not 0.0 <= self.fraction <= 1.0:
            raise TaskContractError("value", "joint-fraction threshold must be within [0, 1]")
        object.__setattr__(self, "fraction", float(self.fraction))


@dataclass(frozen=True, slots=True)
class BinaryStateIs:
    """The named articulation, read as a two-state switch, is ``on`` (or off).

    A truth-valued measure: the switch reads *on* once its joint fraction crosses
    :data:`BINARY_STATE_THRESHOLD`, and the measure is 1.0 when that state equals
    ``on``, else 0.0.
    """

    articulation: str
    on: bool

    def __post_init__(self) -> None:
        _nonempty(self.articulation, "binary-state articulation")


@dataclass(frozen=True, slots=True)
class JointAngleOutside:
    """The named articulation's raw angle lies outside the closed band
    ``[lower_rad, upper_rad]``.

    A truth-valued measure over the *raw* joint angle, not the normalized
    fraction: the angle is first wrapped to ``[0, 2*pi)`` by ``angle % (2*pi)``
    (the RoboCasa stove normalization, ``get_knobs_state``), and the measure
    reads 1.0 when the wrapped angle lies strictly outside the closed band,
    else 0.0. The band is closed because its interior is the *asserted-against*
    region (a stove burner is *on* over ``[0.35, 2*pi - 0.35]`` rad, and "off"
    means strictly outside), so an angle exactly on a bound reads 0.0.
    """

    articulation: str
    lower_rad: float
    upper_rad: float

    def __post_init__(self) -> None:
        _nonempty(self.articulation, "joint-angle articulation")
        _finite(self.lower_rad, "joint-angle band lower")
        _finite(self.upper_rad, "joint-angle band upper")
        if not 0.0 <= self.lower_rad <= self.upper_rad <= 2.0 * math.pi:
            raise TaskContractError(
                "value", "joint-angle band requires 0 <= lower_rad <= upper_rad <= 2*pi"
            )
        object.__setattr__(self, "lower_rad", float(self.lower_rad))
        object.__setattr__(self, "upper_rad", float(self.upper_rad))


@dataclass(frozen=True, slots=True)
class ContactWith:
    """The predicate's entity is in physical contact with the named surface.

    A truth-valued measure: 1.0 when the entity touches ``surface`` — a named
    scene surface or body tag, resolved by whatever grounded the goal — else
    0.0. The entity slot carries the touching object; the measure carries only
    what it must touch.
    """

    surface: str

    def __post_init__(self) -> None:
        _nonempty(self.surface, "contact surface")


Measure: TypeAlias = (
    PlanarDistanceTo
    | VerticalDistanceTo
    | OrientationErrorTo
    | UprightOrientationError
    | FractionTransferredTo
    | CountWithin
    | JointFractionAtLeast
    | BinaryStateIs
    | JointAngleOutside
    | ContactWith
)


@dataclass(frozen=True, slots=True)
class AtMost:
    value: float

    def __post_init__(self) -> None:
        _finite(self.value, "at-most comparison")
        object.__setattr__(self, "value", float(self.value))


@dataclass(frozen=True, slots=True)
class AtLeast:
    value: float

    def __post_init__(self) -> None:
        _finite(self.value, "at-least comparison")
        object.__setattr__(self, "value", float(self.value))


@dataclass(frozen=True, slots=True)
class Exactly:
    value: float

    def __post_init__(self) -> None:
        _finite(self.value, "exact comparison")
        object.__setattr__(self, "value", float(self.value))


@dataclass(frozen=True, slots=True)
class Within:
    value: float
    tolerance: float

    def __post_init__(self) -> None:
        _finite(self.value, "within comparison value")
        _finite(self.tolerance, "within comparison tolerance")
        if self.tolerance < 0:
            raise TaskContractError("value", "within comparison tolerance must be non-negative")
        object.__setattr__(self, "value", float(self.value))
        object.__setattr__(self, "tolerance", float(self.tolerance))


Comparison: TypeAlias = AtMost | AtLeast | Exactly | Within


@dataclass(frozen=True, slots=True)
class GoalPredicate:
    """One entity, one typed measure, and one typed comparison."""

    entity: str
    measure: Measure
    comparison: Comparison

    def __post_init__(self) -> None:
        _nonempty(self.entity, "goal predicate entity")
        value = self.comparison.value
        if isinstance(self.measure, FractionTransferredTo) and not 0.0 <= value <= 1.0:
            raise TaskContractError("value", "fraction comparison value must be within [0, 1]")
        if isinstance(self.measure, CountWithin):
            if value < 0 or not float(value).is_integer():
                raise TaskContractError(
                    "value", "count comparison value must be a non-negative integer"
                )
            if (
                isinstance(self.comparison, Within)
                and not float(self.comparison.tolerance).is_integer()
            ):
                raise TaskContractError("value", "count comparison tolerance must be integral")
        if isinstance(
            self.measure, (JointFractionAtLeast, BinaryStateIs, JointAngleOutside, ContactWith)
        ) and value not in (0.0, 1.0):
            raise TaskContractError("value", "truth-valued comparison value must be 0 or 1")


@dataclass(frozen=True, slots=True)
class TaskGoal:
    """The typed goal: which relation the task's success criterion asserts,
    with whom, and the machine-checkable clauses that assert it (conjunction —
    all must hold). ``predicates`` captures the measurable core of the
    free-text ``success``, which remains the human-readable superset."""

    relation: Relation
    counterparty: Counterparty
    predicates: tuple[GoalPredicate, ...] = ()

    def __post_init__(self) -> None:
        if not self.predicates:
            raise TaskContractError("value", "task goal requires at least one predicate")


class GoalStatus(StrEnum):
    """What one grounding concluded about a goal. Deliberately three-valued.

    ``UNGROUNDED`` is not a soft ``NOT_SATISFIED``: "the robot did not do it" and "nothing
    looked" are different facts, and a verifier that conflates them teaches a policy its plan
    failed when nobody ever checked. Only a verifier that measured every clause may say
    ``SATISFIED``.
    """

    SATISFIED = "satisfied"
    NOT_SATISFIED = "not_satisfied"
    UNGROUNDED = "ungrounded"


class UngroundedMeasureError(LookupError):
    """This perception cannot measure what a predicate asks about — an environment fact.

    Raised by a :class:`GoalGrounding`, never by a caller. It says nothing about whether the
    task was achieved, which is exactly why it is not a :class:`TaskContractError`: the
    contract is well formed and the clause is legal; what is absent is a measurement.
    """


class GoalGrounding(Protocol):
    """One perception, asked for one number at a time.

    The whole surface between a task's criterion and whatever measured it. Keeping it to a
    single method is what lets this package stay dependency-free while the geometry lives in
    the runtime that owns cameras: a grounding answers *what is this measure's value for this
    entity*, in the measure's own unit (metres for the distances, radians for the orientation
    errors, a fraction in [0, 1] for a transfer, a cardinality for a tally, a truth value in
    {0, 1} for the articulation and contact reads), and raises
    :class:`UngroundedMeasureError` when it cannot — an entity it never saw, or a measure its
    sensors do not produce.
    """

    def measure(self, entity: str, measure: Measure) -> float:
        """Measure ``measure`` for ``entity`` now, or raise :class:`UngroundedMeasureError`."""
        ...


@dataclass(frozen=True, slots=True)
class Measured:
    """One clause decided on a real number."""

    predicate: GoalPredicate
    value: float
    satisfied: bool


@dataclass(frozen=True, slots=True)
class Ungrounded:
    """One clause nothing could measure, and the grounding's own reason."""

    predicate: GoalPredicate
    reason: str


ClauseOutcome: TypeAlias = Measured | Ungrounded


@dataclass(frozen=True, slots=True)
class GoalEvaluation:
    """What one grounding says about a goal: the conjunction, and every clause behind it."""

    status: GoalStatus
    clauses: tuple[ClauseOutcome, ...]

    def evidence(self) -> dict[str, JsonValue]:
        """The clause-by-clause record, shaped for a verification receipt.

        A verdict a policy cannot audit is a verdict it has to take on trust, so the number
        each clause turned on travels with the conclusion.
        """

        return {
            "status": self.status.value,
            "clauses": [
                {
                    "entity": outcome.predicate.entity,
                    "measure": _measure_document(outcome.predicate.measure),
                    "comparison": _comparison_document(outcome.predicate.comparison),
                    **(
                        {"value": outcome.value, "satisfied": outcome.satisfied}
                        if isinstance(outcome, Measured)
                        else {"ungrounded": outcome.reason}
                    ),
                }
                for outcome in self.clauses
            ],
        }


def evaluate_goal(goal: TaskGoal, grounding: GoalGrounding) -> GoalEvaluation:
    """Decide a task's goal against one perception.

    The clauses are a conjunction, so this is Kleene's: a clause that measured *false* makes
    the conjunction false whatever else could not be measured — a robot that put the mug down
    outside the tray failed the task, and the tally it also could not count cannot rescue that.
    Absent such a clause, anything ungrounded leaves the whole goal ungrounded. ``SATISFIED``
    therefore means every clause was measured and every clause held, and `TaskGoal` refuses an
    empty predicate tuple, so it can never be the vacuous truth of an empty conjunction.
    """

    clauses = tuple(_evaluate_clause(predicate, grounding) for predicate in goal.predicates)
    if any(isinstance(outcome, Measured) and not outcome.satisfied for outcome in clauses):
        return GoalEvaluation(GoalStatus.NOT_SATISFIED, clauses)
    if any(isinstance(outcome, Ungrounded) for outcome in clauses):
        return GoalEvaluation(GoalStatus.UNGROUNDED, clauses)
    return GoalEvaluation(GoalStatus.SATISFIED, clauses)


def _evaluate_clause(predicate: GoalPredicate, grounding: GoalGrounding) -> ClauseOutcome:
    try:
        value = grounding.measure(predicate.entity, predicate.measure)
    except UngroundedMeasureError as error:
        return Ungrounded(predicate, str(error))
    if not math.isfinite(value):
        # A comparison against NaN is False for every operator, so an unchecked non-finite
        # measurement would read as a clause that failed rather than one that was never made.
        return Ungrounded(predicate, f"the grounding measured {value!r}, which is not a value")
    return Measured(predicate, value, _comparison_holds(predicate.comparison, value))


def _comparison_holds(comparison: Comparison, value: float) -> bool:
    """Total over `Comparison`; a new member is a type error here, not a silent False."""

    match comparison:
        case AtMost():
            return value <= comparison.value
        case AtLeast():
            return value >= comparison.value
        case Exactly():
            # Exact equality, because that is what the word means and the contract offers
            # `Within` for the tolerated kind. It is the honest operator for `CountWithin`,
            # whose values the contract already forces to be integral.
            return value == comparison.value
        case Within():
            return abs(value - comparison.value) <= comparison.tolerance


@dataclass(frozen=True, slots=True)
class EvaluationSuiteRef:
    """The registered, content-addressed Worlds suite an evaluation is measured over.

    ``suite_id`` names the suite; ``sha256`` pins the exact bytes of its
    registered ``SuiteManifest`` (its ``suite_digest``), so the entries a run is
    scored over cannot drift under a contract that already passed. Naming a
    suite the registry does not hold at that digest is a fail-closed refusal at
    the Worlds door, never a silent re-derivation."""

    suite_id: str
    sha256: Sha256Digest

    def __post_init__(self) -> None:
        if not self.suite_id.strip():
            raise TaskContractError(
                "suite", f"suite_id: expected a non-empty suite id, got {self.suite_id!r}"
            )
        try:
            object.__setattr__(self, "sha256", Sha256Digest(self.sha256))
        except ContentRefError as error:
            raise TaskContractError(
                "suite", f"sha256: expected 64-char lowercase hex sha256, got {self.sha256!r}"
            ) from error


@dataclass(frozen=True, slots=True)
class NativeEvaluationCriteria:
    threshold: float
    trials: int

    def __post_init__(self) -> None:
        _evaluation_laws(self.threshold, self.trials)
        object.__setattr__(self, "threshold", float(self.threshold))


@dataclass(frozen=True, slots=True)
class SuiteEvaluationCriteria:
    threshold: float
    trials: int
    suite: EvaluationSuiteRef

    def __post_init__(self) -> None:
        _evaluation_laws(self.threshold, self.trials)
        object.__setattr__(self, "threshold", float(self.threshold))


EvaluationCriteria: TypeAlias = NativeEvaluationCriteria | SuiteEvaluationCriteria


def _evaluation_laws(threshold: float, trials: int) -> None:
    _finite(threshold, "evaluation threshold")
    if not 0.0 <= threshold <= 1.0:
        raise TaskContractError("value", "evaluation threshold must be within [0, 1]")
    _positive_integer(trials, "evaluation trials")


@dataclass(frozen=True, slots=True)
class FailureCondition:
    """One enumerated way a trial of this task fails.

    ``detail`` is the authored, task-specific statement ("cross-threaded start",
    "unintended rotation of other valves"); ``kind`` is the closed classification an
    evaluator or aggregation can act on without reading prose. ``limit`` exists only
    for `ATTEMPT_LIMIT` — the bound whose breach is the failure ("more than 2
    re-insertion attempts" is ``limit=2``) — and is refused on every other kind.
    """

    kind: FailureConditionKind
    detail: str
    limit: int | None = None

    def __post_init__(self) -> None:
        _nonempty(self.detail, "failure condition detail")
        if self.kind is FailureConditionKind.ATTEMPT_LIMIT:
            if self.limit is None:
                raise TaskContractError("value", "attempt_limit failure requires a limit")
            _positive_integer(self.limit, "failure condition limit")
        elif self.limit is not None:
            raise TaskContractError(
                "value", f"failure condition limit is meaningless for {self.kind.value!r}"
            )


@dataclass(frozen=True, slots=True)
class TaskTemplate:
    id: TaskId
    name: str
    horizon: TaskHorizon
    reasoning: ReasoningKind
    rigs: tuple[RigId, ...]
    operator: OperatorTier
    embodiment: TaskCapabilityRequirements
    steps: tuple[TaskStep, ...]
    taskpedia_codes: tuple[TaskpediaCodeRef, ...]
    objects: tuple[TaskObject, ...]
    environment: TaskEnvironment
    distractors: DistractorPlan
    initial_poses: InitialPosePlan
    diversification: DiversificationPlan
    success: str
    goal: TaskGoal
    complexity: tuple[ComplexityAxis, ...] = ()
    variation: VariationPlan | None = None
    capture: CapturePlan | None = None
    evaluation: EvaluationCriteria | None = None
    failure_conditions: tuple[FailureCondition, ...] = ()
    safety: str | None = None

    def __post_init__(self) -> None:
        for field, value in (
            ("id", str(self.id)),
            ("name", self.name),
            ("success", self.success),
        ):
            _nonempty(value, f"task {field}")
        if not self.rigs or not self.steps or not self.objects or not self.taskpedia_codes:
            raise TaskContractError(
                "value", "task requires rigs, steps, objects, and taskpedia evidence"
            )
        if any(not str(value).strip() for value in self.rigs):
            raise TaskContractError("value", "task rigs must not contain empties")
        _unique(cast(tuple[object, ...], self.rigs), "task rigs")
        _unique(cast(tuple[object, ...], self.complexity), "task complexity axes")
        _unique(
            cast(tuple[object, ...], tuple(item.detail for item in self.failure_conditions)),
            "task failure condition details",
        )
        object_heads = tuple(item.head for item in self.objects)
        _unique(cast(tuple[object, ...], object_heads), "task object heads")
        if self.safety is not None:
            _nonempty(self.safety, "task safety")


@dataclass(frozen=True, slots=True)
class TaskFamily:
    schema_version: TaskSchemaVersion
    family: TaskFamilyId
    description: str
    status: TaskFamilyState
    rigs: tuple[RigId, ...]
    tasks: tuple[TaskTemplate, ...]

    def __post_init__(self) -> None:
        if self.schema_version != TASK_SCHEMA_VERSION:
            raise TaskContractError(
                "value", f"unsupported task schema_version {self.schema_version!r}"
            )
        _nonempty(str(self.family), "task family id")
        _nonempty(self.description, "task family description")
        if not self.rigs or not self.tasks:
            raise TaskContractError("value", "task family requires rigs and tasks")
        _unique(cast(tuple[object, ...], self.rigs), "task family rigs")
        _unique(
            cast(tuple[object, ...], tuple(task.id for task in self.tasks)),
            "task family task ids",
        )


@dataclass(frozen=True, slots=True)
class TaskContract:
    """One validated task template in transit across the lifecycle."""

    schema_version: TaskSchemaVersion
    family: TaskFamilyId
    task: TaskTemplate

    def __post_init__(self) -> None:
        if self.schema_version != TASK_SCHEMA_VERSION:
            raise TaskContractError(
                "value", f"unsupported task schema_version {self.schema_version!r}"
            )
        _nonempty(str(self.family), "task contract family")

    @property
    def ref(self) -> "TaskContractRef":
        """The exact content identity to persist after discovering this value."""

        return contract_ref(self)


@dataclass(frozen=True, slots=True)
class TaskContractRef:
    """Content-addressed identity stamped onto every downstream artifact."""

    task_id: TaskId
    schema_version: TaskSchemaVersion
    sha256: Sha256Digest

    def __post_init__(self) -> None:
        if self.schema_version != TASK_SCHEMA_VERSION:
            raise TaskContractError(
                "value", f"unsupported task schema_version {self.schema_version!r}"
            )


def canonical_json(contract: TaskContract) -> str:
    """The exact schema-1.1 document used for identity and reconstruction."""

    return canonical_document(_contract_document(contract))


def contract_ref(contract: TaskContract) -> TaskContractRef:
    """The content-addressed identity stamped onto every downstream artifact."""

    return TaskContractRef(
        task_id=contract.task.id,
        schema_version=contract.schema_version,
        sha256=content_id(Sha256Digest, _contract_document(contract)),
    )


def task_goal_to_dict(goal: TaskGoal) -> dict[str, JsonValue]:
    """Return the one tagged, lossless wire document for a task goal."""

    return {
        "relation": goal.relation.value,
        "counterparty": goal.counterparty.value,
        "predicates": [
            {
                "entity": predicate.entity,
                "measure": _measure_document(predicate.measure),
                "comparison": _comparison_document(predicate.comparison),
            }
            for predicate in goal.predicates
        ],
    }


def task_goal_from_dict(value: object) -> TaskGoal:
    """Parse exactly the tagged goal document; unknown or extra facts are errors."""

    return _parse_goal(value, path="goal")


def from_canonical_json(data: str) -> TaskContract:
    """Parse the one explicit tagged schema-1.1 form and reject every alternative."""

    try:
        payload: object = json.loads(data)
    except (json.JSONDecodeError, TypeError) as err:
        raise MalformedContractError("<root>", "valid JSON") from err
    contract = _parse_contract(payload)
    if canonical_json(contract) != data:
        raise MalformedContractError("<root>", "the canonical schema-1.1 encoding")
    return contract


def _contract_document(contract: TaskContract) -> dict[str, JsonValue]:
    return {
        "schema_version": str(contract.schema_version),
        "family": str(contract.family),
        "task": _task_document(contract.task),
    }


def _task_document(task: TaskTemplate) -> dict[str, JsonValue]:
    object_scheme: JsonValue = None
    if task.diversification.object_scheme is not None:
        value = task.diversification.object_scheme
        object_scheme = {
            "role": value.role.value,
            "instances": list(value.instances),
            "justification": value.justification,
        }
    variation: JsonValue = None
    if task.variation is not None:
        variation = {
            "fill_states": [value.value for value in task.variation.fill_states],
            "media": list(task.variation.media),
            "pace": [value.value for value in task.variation.pace],
            "perturbations": [value.value for value in task.variation.perturbations],
            "conditions": [value.value for value in task.variation.conditions],
            "recovery_share": task.variation.recovery_share,
            "cameras": list(task.variation.cameras),
        }
    capture: JsonValue = None
    if task.capture is not None:
        capture = {
            "episodes_per_scenario_max": task.capture.episodes_per_scenario_max,
            "episode_minutes_est": task.capture.episode_minutes_est,
        }
    evaluation: JsonValue = (
        None if task.evaluation is None else _evaluation_document(task.evaluation)
    )
    return {
        "id": str(task.id),
        "name": task.name,
        "horizon": task.horizon.value,
        "reasoning": task.reasoning.value,
        "rigs": [str(value) for value in task.rigs],
        "operator": task.operator.value,
        "embodiment": {
            "roles": [
                {
                    "role_id": str(role.role_id),
                    "capabilities": [value.value for value in role.capabilities.ordered],
                }
                for role in task.embodiment.roles
            ]
        },
        "steps": [
            {
                "skill": str(step.skill),
                "object": step.object,
                "target": step.target,
                "when": step.when,
                "until": step.until,
                "note": step.note,
                "reversible": step.reversible,
            }
            for step in task.steps
        ],
        "taskpedia_codes": [
            {
                "code": value.code,
                "relation": value.relation.value,
                "origin": None if value.origin is None else value.origin.value,
            }
            for value in task.taskpedia_codes
        ],
        "objects": [
            {
                "role": value.role.value,
                "head": str(value.head),
                "count": {
                    "minimum": value.count.minimum,
                    "maximum": value.count.maximum,
                },
                "mix": value.mix.value,
                "options": list(value.options),
            }
            for value in task.objects
        ],
        "environment": {
            "stations": [str(value) for value in task.environment.stations],
            "lighting": list(task.environment.lighting),
            "surfaces": list(task.environment.surfaces),
        },
        "distractors": {
            "easy": task.distractors.easy,
            "medium": task.distractors.medium,
            "hard": task.distractors.hard,
        },
        "initial_poses": {
            "object_bins": list(task.initial_poses.object_bins),
            "robot_bins": list(task.initial_poses.robot_bins),
        },
        "diversification": {
            "scheme": task.diversification.scheme.value,
            "budget": task.diversification.budget,
            "adapt": task.diversification.adapt.value,
            "object_scheme": object_scheme,
        },
        "success": task.success,
        "goal": task_goal_to_dict(task.goal),
        "complexity": [value.value for value in task.complexity],
        "variation": variation,
        "capture": capture,
        "evaluation": evaluation,
        "failure_conditions": [
            {"kind": value.kind.value, "detail": value.detail, "limit": value.limit}
            for value in task.failure_conditions
        ],
        "safety": task.safety,
    }


def _measure_document(measure: Measure) -> dict[str, JsonValue]:
    if isinstance(measure, PlanarDistanceTo):
        return {"kind": MeasureKind.PLANAR_DISTANCE_TO.value, "reference": measure.reference}
    if isinstance(measure, VerticalDistanceTo):
        return {"kind": MeasureKind.VERTICAL_DISTANCE_TO.value, "reference": measure.reference}
    if isinstance(measure, OrientationErrorTo):
        return {"kind": MeasureKind.ORIENTATION_ERROR_TO.value, "reference": measure.reference}
    if isinstance(measure, UprightOrientationError):
        return {"kind": MeasureKind.UPRIGHT_ORIENTATION_ERROR.value}
    if isinstance(measure, FractionTransferredTo):
        return {"kind": MeasureKind.FRACTION_TRANSFERRED_TO.value, "reference": measure.reference}
    if isinstance(measure, JointFractionAtLeast):
        return {
            "kind": MeasureKind.JOINT_FRACTION_AT_LEAST.value,
            "articulation": measure.articulation,
            "fraction": measure.fraction,
        }
    if isinstance(measure, BinaryStateIs):
        return {
            "kind": MeasureKind.BINARY_STATE_IS.value,
            "articulation": measure.articulation,
            "on": measure.on,
        }
    if isinstance(measure, JointAngleOutside):
        return {
            "kind": MeasureKind.JOINT_ANGLE_OUTSIDE.value,
            "articulation": measure.articulation,
            "lower_rad": measure.lower_rad,
            "upper_rad": measure.upper_rad,
        }
    if isinstance(measure, ContactWith):
        return {"kind": MeasureKind.CONTACT_WITH.value, "surface": measure.surface}
    return {"kind": MeasureKind.COUNT_WITHIN.value, "reference": measure.reference}


def _comparison_document(comparison: Comparison) -> dict[str, JsonValue]:
    if isinstance(comparison, AtMost):
        return {"kind": ComparisonKind.AT_MOST.value, "value": comparison.value}
    if isinstance(comparison, AtLeast):
        return {"kind": ComparisonKind.AT_LEAST.value, "value": comparison.value}
    if isinstance(comparison, Exactly):
        return {"kind": ComparisonKind.EXACTLY.value, "value": comparison.value}
    return {
        "kind": ComparisonKind.WITHIN.value,
        "value": comparison.value,
        "tolerance": comparison.tolerance,
    }


def _evaluation_document(criteria: EvaluationCriteria) -> dict[str, JsonValue]:
    if isinstance(criteria, NativeEvaluationCriteria):
        return {"kind": "native", "threshold": criteria.threshold, "trials": criteria.trials}
    return {
        "kind": "registered_suite",
        "threshold": criteria.threshold,
        "trials": criteria.trials,
        "suite": {"suite_id": criteria.suite.suite_id, "sha256": criteria.suite.sha256},
    }


def _parse_contract(value: object) -> TaskContract:
    document = _object(value, "<root>", {"schema_version", "family", "task"})
    version = TaskSchemaVersion(decode.text(document, "schema_version"))
    if version != TASK_SCHEMA_VERSION:
        raise MalformedContractError("schema_version", str(TASK_SCHEMA_VERSION))
    return TaskContract(
        schema_version=version,
        family=TaskFamilyId(decode.text(document, "family")),
        task=_parse_task(document["task"]),
    )


def _parse_task(value: object) -> TaskTemplate:
    keys = {
        "id",
        "name",
        "horizon",
        "reasoning",
        "rigs",
        "operator",
        "embodiment",
        "steps",
        "taskpedia_codes",
        "objects",
        "environment",
        "distractors",
        "initial_poses",
        "diversification",
        "success",
        "goal",
        "complexity",
        "variation",
        "capture",
        "evaluation",
        "failure_conditions",
        "safety",
    }
    task = _object(value, "task", keys)
    requirements = _object(task["embodiment"], "task.embodiment", {"roles"})
    roles = tuple(
        _parse_role(value, f"task.embodiment.roles[{index}]")
        for index, value in enumerate(decode.sequence(requirements, "roles"))
    )
    return TaskTemplate(
        id=TaskId(decode.text(task, "id")),
        name=decode.text(task, "name"),
        horizon=_enum(TaskHorizon, task, "horizon"),
        reasoning=_enum(ReasoningKind, task, "reasoning"),
        rigs=tuple(RigId(value) for value in decode.texts(task, "rigs")),
        operator=_enum(OperatorTier, task, "operator"),
        embodiment=TaskCapabilityRequirements(roles),
        steps=tuple(
            _parse_step(value, f"task.steps[{index}]")
            for index, value in enumerate(decode.sequence(task, "steps"))
        ),
        taskpedia_codes=tuple(
            _parse_code(value, f"task.taskpedia_codes[{index}]")
            for index, value in enumerate(decode.sequence(task, "taskpedia_codes"))
        ),
        objects=tuple(
            _parse_object(value, f"task.objects[{index}]")
            for index, value in enumerate(decode.sequence(task, "objects"))
        ),
        environment=_parse_environment(task["environment"]),
        distractors=_parse_distractors(task["distractors"]),
        initial_poses=_parse_initial_poses(task["initial_poses"]),
        diversification=_parse_diversification(task["diversification"]),
        success=decode.text(task, "success"),
        goal=_parse_goal(task["goal"]),
        complexity=_enums(ComplexityAxis, task, "complexity"),
        variation=None if task["variation"] is None else _parse_variation(task["variation"]),
        capture=None if task["capture"] is None else _parse_capture(task["capture"]),
        evaluation=(None if task["evaluation"] is None else _parse_evaluation(task["evaluation"])),
        failure_conditions=tuple(
            _parse_failure_condition(value, f"task.failure_conditions[{index}]")
            for index, value in enumerate(decode.sequence(task, "failure_conditions"))
        ),
        safety=decode.optional_text(task, "safety"),
    )


def _parse_role(value: object, path: str) -> TaskRoleRequirement:
    document = _object(value, path, {"role_id", "capabilities"})
    capabilities = CapabilitySet(_enums(Capability, document, "capabilities"))
    return TaskRoleRequirement(TaskRoleId(decode.text(document, "role_id")), capabilities)


def _parse_step(value: object, path: str) -> TaskStep:
    document = _object(
        value, path, {"skill", "object", "target", "when", "until", "note", "reversible"}
    )
    return TaskStep(
        skill=SkillName(decode.text(document, "skill")),
        object=decode.optional_text(document, "object"),
        target=decode.optional_text(document, "target"),
        when=decode.optional_text(document, "when"),
        until=decode.optional_text(document, "until"),
        note=decode.optional_text(document, "note"),
        reversible=decode.boolean(document, "reversible"),
    )


def _parse_failure_condition(value: object, path: str) -> FailureCondition:
    document = _object(value, path, {"kind", "detail", "limit"})
    limit = document["limit"]
    return FailureCondition(
        kind=_enum(FailureConditionKind, document, "kind"),
        detail=decode.text(document, "detail"),
        limit=None if limit is None else decode.integer(document, "limit"),
    )


def _parse_code(value: object, path: str) -> TaskpediaCodeRef:
    document = _object(value, path, {"code", "relation", "origin"})
    origin = document["origin"]
    return TaskpediaCodeRef(
        code=decode.text(document, "code"),
        relation=_enum(EvidenceRelation, document, "relation"),
        origin=None if origin is None else _enum(EvidenceOrigin, document, "origin"),
    )


def _parse_object(value: object, path: str) -> TaskObject:
    document = _object(value, path, {"role", "head", "count", "mix", "options"})
    count = _object(document["count"], f"{path}.count", {"minimum", "maximum"})
    return TaskObject(
        role=_enum(ObjectRole, document, "role"),
        head=ObjectHead(decode.text(document, "head")),
        count=CountInterval(
            decode.integer(count, "minimum"),
            decode.integer(count, "maximum"),
        ),
        mix=_enum(ObjectMix, document, "mix"),
        options=decode.texts(document, "options"),
    )


def _parse_environment(value: object) -> TaskEnvironment:
    path = "task.environment"
    document = _object(value, path, {"stations", "lighting", "surfaces"})
    return TaskEnvironment(
        stations=tuple(TaskStationRef(value) for value in decode.texts(document, "stations")),
        lighting=decode.texts(document, "lighting"),
        surfaces=decode.texts(document, "surfaces"),
    )


def _parse_distractors(value: object) -> DistractorPlan:
    path = "task.distractors"
    document = _object(value, path, {"easy", "medium", "hard"})
    return DistractorPlan(*(decode.text(document, key) for key in ("easy", "medium", "hard")))


def _parse_initial_poses(value: object) -> InitialPosePlan:
    path = "task.initial_poses"
    document = _object(value, path, {"object_bins", "robot_bins"})
    return InitialPosePlan(
        decode.texts(document, "object_bins"),
        decode.texts(document, "robot_bins"),
    )


def _parse_diversification(value: object) -> DiversificationPlan:
    path = "task.diversification"
    document = _object(value, path, {"scheme", "budget", "adapt", "object_scheme"})
    raw_scheme = document["object_scheme"]
    object_scheme: ObjectDiversification | None = None
    if raw_scheme is not None:
        scheme = _object(
            raw_scheme, f"{path}.object_scheme", {"role", "instances", "justification"}
        )
        object_scheme = ObjectDiversification(
            role=_enum(ObjectRole, scheme, "role"),
            instances=decode.texts(scheme, "instances"),
            justification=decode.text(scheme, "justification"),
        )
    return DiversificationPlan(
        scheme=_enum(DiversificationScheme, document, "scheme"),
        budget=decode.integer(document, "budget"),
        adapt=_enum(AdaptationKind, document, "adapt"),
        object_scheme=object_scheme,
    )


def _parse_goal(value: object, path: str = "task.goal") -> TaskGoal:
    document = _object(value, path, {"relation", "counterparty", "predicates"})
    return TaskGoal(
        relation=_enum(Relation, document, "relation"),
        counterparty=_enum(Counterparty, document, "counterparty"),
        predicates=tuple(
            _parse_predicate(value, f"{path}.predicates[{index}]")
            for index, value in enumerate(decode.sequence(document, "predicates"))
        ),
    )


def _parse_predicate(value: object, path: str) -> GoalPredicate:
    document = _object(value, path, {"entity", "measure", "comparison"})
    return GoalPredicate(
        entity=decode.text(document, "entity"),
        measure=_parse_measure(document["measure"], f"{path}.measure"),
        comparison=_parse_comparison(document["comparison"], f"{path}.comparison"),
    )


#: Measures whose whole content is one named reference; the parse is identical for each.
_REFERENCE_MEASURES: dict[
    MeasureKind,
    type[
        PlanarDistanceTo
        | VerticalDistanceTo
        | OrientationErrorTo
        | FractionTransferredTo
        | CountWithin
    ],
] = {
    MeasureKind.PLANAR_DISTANCE_TO: PlanarDistanceTo,
    MeasureKind.VERTICAL_DISTANCE_TO: VerticalDistanceTo,
    MeasureKind.ORIENTATION_ERROR_TO: OrientationErrorTo,
    MeasureKind.FRACTION_TRANSFERRED_TO: FractionTransferredTo,
    MeasureKind.COUNT_WITHIN: CountWithin,
}


def _parse_measure(value: object, path: str) -> Measure:
    raw = _document(value, path)
    try:
        kind = MeasureKind(decode.text(raw, "kind"))
    except ValueError as error:
        raise MalformedContractError(
            f"{path}.kind", f"one of {sorted(member.value for member in MeasureKind)}"
        ) from error
    if kind is MeasureKind.UPRIGHT_ORIENTATION_ERROR:
        _exact_keys(raw, path, {"kind"})
        return UprightOrientationError()
    if kind is MeasureKind.JOINT_FRACTION_AT_LEAST:
        _exact_keys(raw, path, {"kind", "articulation", "fraction"})
        return JointFractionAtLeast(
            decode.text(raw, "articulation"), decode.number(raw, "fraction")
        )
    if kind is MeasureKind.BINARY_STATE_IS:
        _exact_keys(raw, path, {"kind", "articulation", "on"})
        return BinaryStateIs(decode.text(raw, "articulation"), decode.boolean(raw, "on"))
    if kind is MeasureKind.JOINT_ANGLE_OUTSIDE:
        _exact_keys(raw, path, {"kind", "articulation", "lower_rad", "upper_rad"})
        return JointAngleOutside(
            decode.text(raw, "articulation"),
            decode.number(raw, "lower_rad"),
            decode.number(raw, "upper_rad"),
        )
    if kind is MeasureKind.CONTACT_WITH:
        _exact_keys(raw, path, {"kind", "surface"})
        return ContactWith(decode.text(raw, "surface"))
    _exact_keys(raw, path, {"kind", "reference"})
    return _REFERENCE_MEASURES[kind](decode.text(raw, "reference"))


#: Comparisons whose whole content is one threshold; `within` also carries a tolerance.
_THRESHOLD_COMPARISONS: dict[ComparisonKind, type[AtMost | AtLeast | Exactly]] = {
    ComparisonKind.AT_MOST: AtMost,
    ComparisonKind.AT_LEAST: AtLeast,
    ComparisonKind.EXACTLY: Exactly,
}


def _parse_comparison(value: object, path: str) -> Comparison:
    raw = _document(value, path)
    try:
        kind = ComparisonKind(decode.text(raw, "kind"))
    except ValueError as error:
        raise MalformedContractError(
            f"{path}.kind", f"one of {sorted(member.value for member in ComparisonKind)}"
        ) from error
    if kind is ComparisonKind.WITHIN:
        _exact_keys(raw, path, {"kind", "value", "tolerance"})
        return Within(decode.number(raw, "value"), decode.number(raw, "tolerance"))
    constructor = _THRESHOLD_COMPARISONS[kind]
    _exact_keys(raw, path, {"kind", "value"})
    return constructor(decode.number(raw, "value"))


def _parse_variation(value: object) -> VariationPlan:
    path = "task.variation"
    document = _object(
        value,
        path,
        {
            "fill_states",
            "media",
            "pace",
            "perturbations",
            "conditions",
            "recovery_share",
            "cameras",
        },
    )
    recovery = document["recovery_share"]
    return VariationPlan(
        fill_states=_enums(FillState, document, "fill_states"),
        media=decode.texts(document, "media"),
        pace=_enums(DemonstrationPace, document, "pace"),
        perturbations=_enums(PerturbationKind, document, "perturbations"),
        conditions=_enums(ObjectCondition, document, "conditions"),
        recovery_share=None if recovery is None else decode.number(document, "recovery_share"),
        cameras=decode.texts(document, "cameras"),
    )


def _parse_capture(value: object) -> CapturePlan:
    path = "task.capture"
    document = _object(value, path, {"episodes_per_scenario_max", "episode_minutes_est"})
    episodes = document["episodes_per_scenario_max"]
    minutes = document["episode_minutes_est"]
    return CapturePlan(
        episodes_per_scenario_max=None
        if episodes is None
        else decode.integer(document, "episodes_per_scenario_max"),
        episode_minutes_est=None
        if minutes is None
        else decode.number(document, "episode_minutes_est"),
    )


def _parse_evaluation(value: object) -> EvaluationCriteria:
    path = "task.evaluation"
    raw = _document(value, path)
    kind = decode.text(raw, "kind")
    if kind == "native":
        _exact_keys(raw, path, {"kind", "threshold", "trials"})
        return NativeEvaluationCriteria(
            decode.number(raw, "threshold"),
            decode.integer(raw, "trials"),
        )
    if kind != "registered_suite":
        raise MalformedContractError(f"{path}.kind", "native or registered_suite")
    _exact_keys(raw, path, {"kind", "threshold", "trials", "suite"})
    suite = _object(raw["suite"], f"{path}.suite", {"suite_id", "sha256"})
    return SuiteEvaluationCriteria(
        decode.number(raw, "threshold"),
        decode.integer(raw, "trials"),
        EvaluationSuiteRef(
            decode.text(suite, "suite_id"),
            _digest(suite, "sha256", f"{path}.suite"),
        ),
    )


def _digest(document: decode.Document, key: str, path: str) -> Sha256Digest:
    """One digest invariant, refused with the error a contract reader is catching."""
    try:
        return Sha256Digest(decode.text(document, key))
    except ContentRefError as error:
        raise MalformedContractError(
            f"{path}.{key}", "a 64-character lowercase hex digest"
        ) from error


def _document(value: object, path: str) -> decode.Document:
    return decode.document(value, where=path, error=MalformedContractError)


def _object(value: object, path: str, keys: set[str]) -> decode.Document:
    """A document whose key set is exactly the contract's — the exact-keys rule."""
    document = _document(value, path)
    _exact_keys(document, path, keys)
    return document


def _exact_keys(document: Mapping[str, object], path: str, keys: set[str]) -> None:
    if set(document) != keys:
        raise MalformedContractError(path, f"exact keys {sorted(keys)}")


EnumT = TypeVar("EnumT", bound=StrEnum)


def _enum(kind: type[EnumT], document: decode.Document, key: str) -> EnumT:
    return _member(kind, decode.text(document, key), f"{document.where}.{key}")


def _enums(kind: type[EnumT], document: decode.Document, key: str) -> tuple[EnumT, ...]:
    return tuple(
        _member(kind, item, f"{document.where}.{key}[{index}]")
        for index, item in enumerate(decode.texts(document, key))
    )


def _member(kind: type[EnumT], raw: str, path: str) -> EnumT:
    try:
        return kind(raw)
    except ValueError as error:
        raise MalformedContractError(path, f"one of {[item.value for item in kind]}") from error
