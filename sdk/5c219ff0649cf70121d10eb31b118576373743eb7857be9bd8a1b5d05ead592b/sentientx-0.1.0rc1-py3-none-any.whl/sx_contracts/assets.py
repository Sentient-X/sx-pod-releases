"""The platform's content-addressed asset vocabulary.

Absorbed from sx-embodiments 2026-08-03 (the capabilities/delivery absorption
precedent): every governed artifact ladder — embodiment bundles, environment bundles,
composed scenes, the catalog's Worlds rungs — speaks these records, so the vocabulary
lives in the cross-repo contracts package rather than the hardware registry it happened
to be born in. What stayed behind in sx-embodiments is payload machinery, not
vocabulary: ``asset_root``/``resolve_asset`` (the ``package://sx-embodiments/...``
resolver over that package's shipped description assets), ``PackagedAsset``, and the
provenance-mandatory ``EmbodiedAsset`` refinement the ``Embodiment`` record carries.

Resolving a packaged reference to local bytes is therefore an sx-embodiments capability
(``sx_embodiments.resolve_asset``); the records here are pure facts.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path, PurePosixPath
from typing import Self
from urllib.parse import urlparse

from sx_contracts.content import ContentBlob, Sha256Digest


class AssetIntegrityError(ValueError):
    """An asset reference is malformed: bad URI, digest, size, or logical path.

    A ``ValueError`` deliberately, so consumer boundaries that funnel construction
    failures through ``except ValueError`` keep failing closed.
    """


def validate_logical_path(path: PurePosixPath) -> None:
    """Reject bundle-member paths that could escape or alias a materialization root."""
    text = str(path)
    if path.is_absolute():
        raise AssetIntegrityError(f"logical_path must be relative: {text!r}")
    if not path.parts:
        raise AssetIntegrityError("logical_path must not be empty")
    if any(part in (".", "..") for part in path.parts):
        raise AssetIntegrityError(f"logical_path must not contain '.' or '..' segments: {text!r}")
    if "\\" in text:
        raise AssetIntegrityError(f"logical_path must use forward slashes: {text!r}")


class AssetFormat(StrEnum):
    """Portable formats understood by the robotics data platform."""

    URDF = "urdf"
    SRDF = "srdf"
    SDF = "sdf"
    STEP = "step"
    MJCF = "mjcf"
    USD = "usd"
    USDA = "usda"
    USDC = "usdc"
    USDZ = "usdz"
    MESH = "mesh"
    SPLAT = "splat"
    """A gaussian-splat radiance field (.ply/.spz/.rad/.lcc) — the visual record of a
    captured or generated environment (the Worlds artifact ladder's reconstruction
    rung)."""
    CALIBRATION = "calibration"
    OTHER = "other"


class AssetRole(StrEnum):
    """How an asset participates in an embodiment bundle."""

    DESCRIPTION = "description"
    GEOMETRY = "geometry"
    COLLISION = "collision"
    CALIBRATION = "calibration"
    TEXTURE = "texture"
    LICENSE = "license"
    OTHER = "other"


@dataclass(frozen=True, slots=True)
class AssetProvenance:
    """Immutable origin of packaged asset bytes."""

    repository: str
    revision: str
    path: str
    license_id: str
    generator: str | None = None

    def __post_init__(self) -> None:
        parsed = urlparse(self.repository)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise AssetIntegrityError("asset provenance repository must be an HTTP(S) URL")
        if not self.revision.strip():
            raise AssetIntegrityError("asset provenance revision must not be empty")
        if not self.path or self.path.startswith(("/", ".")):
            raise AssetIntegrityError("asset provenance path must be repository-relative")
        if not self.license_id.strip():
            raise AssetIntegrityError("asset provenance license_id must not be empty")


@dataclass(frozen=True, slots=True)
class AssetRef:
    """Content-addressed robotics asset at a catalog-resolvable URI.

    ``logical_path`` is the member's path inside a multi-file bundle (URDF + SRDF + mesh
    closure), validated fail-closed: relative, forward-slash, no ``..``. Single-file
    producers keep ``None``; bundle ingest requires it. The same content blob may appear at
    multiple logical paths within one bundle.
    """

    location: str
    content: ContentBlob
    format: AssetFormat
    role: AssetRole
    media_type: str | None = None
    logical_path: PurePosixPath | None = None

    def __post_init__(self) -> None:
        parsed = urlparse(self.location)
        if not parsed.scheme:
            raise AssetIntegrityError("asset uri must be absolute and include a scheme")
        if self.logical_path is not None:
            validate_logical_path(self.logical_path)

    @property
    def uri(self) -> str:
        """The external location projection used by asset transport boundaries."""
        return self.location

    @property
    def sha256(self) -> str:
        return str(self.content.sha256)

    @property
    def byte_size(self) -> int:
        return self.content.size_bytes

    @classmethod
    def from_bytes(
        cls,
        content: bytes,
        *,
        uri: str,
        format: AssetFormat,
        role: AssetRole,
        media_type: str | None = None,
    ) -> Self:
        """Create a canonical reference after hashing bytes at an ingest boundary."""
        return cls(
            location=uri,
            content=ContentBlob(
                Sha256Digest(hashlib.sha256(content).hexdigest()),
                len(content),
            ),
            format=format,
            role=role,
            media_type=media_type,
        )

    @classmethod
    def from_path(
        cls,
        path: Path,
        *,
        format: AssetFormat,
        role: AssetRole,
        media_type: str | None = None,
    ) -> Self:
        """Hash a local asset and bind it to its absolute file URI."""
        resolved = path.resolve(strict=True)
        return cls.from_bytes(
            resolved.read_bytes(),
            uri=resolved.as_uri(),
            format=format,
            role=role,
            media_type=media_type,
        )


@dataclass(frozen=True, slots=True)
class ProvenancedAsset:
    """An asset plus its mandatory, independently typed origin."""

    asset: AssetRef
    provenance: AssetProvenance

    @property
    def uri(self) -> str:
        return self.asset.location

    @property
    def sha256(self) -> str:
        return str(self.asset.content.sha256)

    @property
    def byte_size(self) -> int:
        return self.asset.content.size_bytes

    @property
    def format(self) -> AssetFormat:
        return self.asset.format

    @property
    def role(self) -> AssetRole:
        return self.asset.role

    @property
    def media_type(self) -> str | None:
        return self.asset.media_type

    @property
    def logical_path(self) -> PurePosixPath | None:
        return self.asset.logical_path
