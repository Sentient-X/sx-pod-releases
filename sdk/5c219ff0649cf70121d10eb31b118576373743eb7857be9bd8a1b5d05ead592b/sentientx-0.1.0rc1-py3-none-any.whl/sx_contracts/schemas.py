"""Which exact contract a governed artifact claims to be, and who proves the claim.

The catalog governs bytes it did not produce and cannot re-derive: an episode RRD
written by a station, an MCAP fused on a pod, a LeRobot tar from a partner. What
makes such a thing admissible is never its file extension. It is a *claim* — these
bytes satisfy an exact contract — plus a procedure that can check the claim. This
module is that pair, and nothing else.

`SchemaId` is the claim (`sx.episode/v8`): already the spelling a recording carries
in its own metadata and a segment row stores in its schema column. `SchemaRevision`
is the contract the claim names; it is immutable, because a contract that could be
edited after artifacts were admitted under it would not be a contract. `ValidatorId`
is the procedure, named *inside* the revision, so changing how conformance is proven
changes the revision's identity too.

Compatibility is deliberately two questions, answered by two different kinds of
evidence and then combined:

    SchemaId    vs SchemaId      what the producer *says* — a name comparison
    PhysicalSchema vs PhysicalSchema   what a reader actually *found* in the bytes

Neither alone is enough. Two recordings can both say `sx.episode/v8` and disagree
about whether a joint angle is an f32 or an f64, and two byte-identical layouts can
mean different things under different revisions. `SchemaCompatibility.worst` is how
the two answers compose: the strictest verdict wins, always.

What is deliberately *not* here is the schema document of any particular family. The
package that defines a standard emits its own revision — `sx_episodes` says what
`sx.episode/v8` is — and the catalog registers and enforces what it is handed. A copy
of that document here, or in the catalog's SQL, would be a second source for one truth
and would drift the first time either moved.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from enum import StrEnum
from typing import ClassVar, cast

from sx_contracts import decode
from sx_contracts.catalog import RepresentationFormat
from sx_contracts.content import Sha256Digest
from sx_contracts.identity import (
    JsonObject,
    JsonValue,
    canonical_json,
    content_digest,
    freeze_json,
)
from sx_contracts.wire import RevisionedName


class SchemaContractError(ValueError):
    """A schema revision, validator name, or observed schema is malformed."""


class SchemaId(RevisionedName):
    """The exact contract an artifact claims — ``sx.episode/v8``, ``skl.mcap/v10``."""

    __slots__ = ()
    error: ClassVar[type[Exception]] = SchemaContractError
    noun: ClassVar[str] = "schema id"


class ValidatorId(RevisionedName):
    """The exact procedure that proves conformance — ``sx.episode.conformance/v1``.

    A name and a revision, not a record: everything else a validator will need — its
    configuration, its resource request, the report it promises — belongs to the
    executable that implements it, and that executable does not exist yet. Naming it
    here is enough to make the revision's identity depend on it, which is the whole
    reason the plan wants the validator content-identified.
    """

    __slots__ = ()
    error: ClassVar[type[Exception]] = SchemaContractError
    noun: ClassVar[str] = "validator id"


class SchemaCompatibility(StrEnum):
    """How one governed artifact relates to the contract it is offered against.

    Ordered from most to least admissible; `worst` composes independent verdicts and
    `admits` is the one place the admission line is drawn, so no caller re-spells it.
    """

    IDENTICAL = "identical"
    """The same contract and the same physical layout. Nothing to decide."""

    READ_COMPATIBLE = "read_compatible"
    """Additions only. Every column both sides carry has the same physical type."""

    MIGRATION_REQUIRED = "migration_required"
    """A conversion exists but must materialize a new snapshot. Never implicit."""

    INCOMPATIBLE = "incompatible"
    """Reject. A shared name means two different things, or the families differ."""

    @property
    def admits(self) -> bool:
        return self in {SchemaCompatibility.IDENTICAL, SchemaCompatibility.READ_COMPATIBLE}

    @classmethod
    def worst(cls, verdicts: Iterable[SchemaCompatibility]) -> SchemaCompatibility:
        """The strictest of several independent verdicts — the only lawful way to combine.

        An empty argument is `IDENTICAL`: nothing was found to object to. Callers that
        mean "nothing was checked" must say so with their own error, not with this.
        """
        order = tuple(cls)
        return max(verdicts, key=order.index, default=cls.IDENTICAL)


def compare_ids(pinned: SchemaId, observed: SchemaId) -> SchemaCompatibility:
    """Compare two claims by name alone — the cheap half, available before any read.

    A different family is never a migration: `skl.mcap/v10` is not an older
    `sx.episode`, and offering to convert between unrelated contracts by revision
    arithmetic is how a format guess gets in. Same family, different revision is
    exactly what a migration step exists for, whichever direction it runs.
    """
    if pinned.family != observed.family:
        return SchemaCompatibility.INCOMPATIBLE
    if pinned.revision != observed.revision:
        return SchemaCompatibility.MIGRATION_REQUIRED
    return SchemaCompatibility.IDENTICAL


@dataclass(frozen=True, slots=True, order=True)
class PhysicalColumn:
    """One typed column a reader found: where it lives, what it is called, what it is.

    The three parts are the representation's own vocabulary, not a normalization of
    it — a Rerun entity path and component column, an MCAP topic and message field.
    Flattening them into one string would make the two halves un-comparable, and
    translating them into a house vocabulary would put a mapping table between the
    bytes and the check that reads them.
    """

    path: str
    name: str
    datatype: str

    def __post_init__(self) -> None:
        if not (self.path.strip() and self.name.strip() and self.datatype.strip()):
            raise SchemaContractError("a physical column needs a path, a name, and a datatype")


@dataclass(frozen=True, slots=True)
class PhysicalSchema:
    """What a reader actually found in one artifact's bytes.

    Derived, never declared. This is the fact the plan insists is not hand-maintained:
    a dataset's physical schema is whatever its first admitted member turned out to
    be, and every later member is compared against that rather than against prose.
    """

    columns: tuple[PhysicalColumn, ...]

    def __post_init__(self) -> None:
        keys = [(column.path, column.name) for column in self.columns]
        if len(set(keys)) != len(keys):
            raise SchemaContractError("a physical schema names each column once")
        object.__setattr__(self, "columns", tuple(sorted(self.columns)))

    def compare(self, observed: PhysicalSchema) -> SchemaCompatibility:
        """How an observed layout relates to this one.

        A column both sides carry under one name must have one type — that
        disagreement is the physical incompatibility the plan names as the minimum
        bar, and it is silent under Rerun's schema-on-read union, which is exactly why
        a governed dataset has to check it. Columns present on only one side are
        additions or omissions: readable either way, so read-compatible.
        """
        mine = {(column.path, column.name): column.datatype for column in self.columns}
        theirs = {(column.path, column.name): column.datatype for column in observed.columns}
        if any(mine[key] != theirs[key] for key in mine.keys() & theirs.keys()):
            return SchemaCompatibility.INCOMPATIBLE
        if mine == theirs:
            return SchemaCompatibility.IDENTICAL
        return SchemaCompatibility.READ_COMPATIBLE


@dataclass(frozen=True, slots=True)
class SchemaRevision:
    """One immutable admission contract, as the package that owns the standard states it.

    `document` is that package's own canonical statement of the contract — required
    entity paths and timelines for an RRD family, topics and message schemas for MCAP.
    It is opaque here on purpose: this module can say that a revision *has* a document
    and that the document is part of its identity without ever needing to know what a
    Rerun entity path is.
    """

    id: SchemaId
    representation: RepresentationFormat
    validator: ValidatorId
    document: JsonObject
    """Deeply frozen on construction, so the digest below cannot move under a holder."""

    def __post_init__(self) -> None:
        object.__setattr__(self, "id", SchemaId(self.id))
        object.__setattr__(self, "validator", ValidatorId(self.validator))
        frozen = freeze_json(self.document)
        if not isinstance(frozen, Mapping) or not frozen:
            raise SchemaContractError(f"schema revision {self.id} must carry a schema document")
        object.__setattr__(self, "document", frozen)

    @property
    def digest(self) -> Sha256Digest:
        """The revision's content identity, over everything above including the validator."""
        return content_digest(schema_revision_to_dict(self))


def schema_revision_to_dict(revision: SchemaRevision) -> dict[str, JsonValue]:
    """The one wire shape; also the bytes the revision's digest is taken over."""
    thawed = cast("object", json.loads(canonical_json(revision.document)))
    if not isinstance(thawed, dict):  # SchemaRevision already proves this is an object.
        raise SchemaContractError(f"schema revision {revision.id} has a non-object document")
    return {
        "id": str(revision.id),
        "representation": revision.representation.value,
        "validator": str(revision.validator),
        "document": cast("JsonObject", thawed),
    }


def schema_revision_from_dict(data: object) -> SchemaRevision:
    """Parse a revision once, failing closed on an unknown representation or bad name."""
    value = decode.document(data, where="schema revision", error=SchemaContractError)
    document = freeze_json(decode.mapping(value, "document"))
    if not isinstance(document, Mapping):  # decode.mapping already proved this
        raise SchemaContractError("a schema document must be an object")
    try:
        return SchemaRevision(
            id=SchemaId(decode.text(value, "id")),
            representation=RepresentationFormat(decode.text(value, "representation")),
            validator=ValidatorId(decode.text(value, "validator")),
            document=document,
        )
    except (TypeError, ValueError) as error:
        raise SchemaContractError(f"invalid schema revision: {error}") from error


def physical_schema_to_dict(schema: PhysicalSchema) -> dict[str, JsonValue]:
    return {
        "columns": [
            {"path": column.path, "name": column.name, "datatype": column.datatype}
            for column in schema.columns
        ]
    }


def physical_schema_from_dict(data: object) -> PhysicalSchema:
    value = decode.document(data, where="physical schema", error=SchemaContractError)
    try:
        return PhysicalSchema(
            columns=tuple(
                PhysicalColumn(
                    path=decode.text(row, "path"),
                    name=decode.text(row, "name"),
                    datatype=decode.text(row, "datatype"),
                )
                for row in decode.documents(value, "columns")
            )
        )
    except (TypeError, ValueError) as error:
        raise SchemaContractError(f"invalid physical schema: {error}") from error
