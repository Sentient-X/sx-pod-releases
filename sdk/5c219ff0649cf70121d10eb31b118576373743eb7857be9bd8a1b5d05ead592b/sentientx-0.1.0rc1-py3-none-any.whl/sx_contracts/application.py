"""One exact robot application: a target-qualified graph of OCI workloads.

Images are the executable packaging boundary.  A :class:`RobotApplication` is the
deployment boundary: it binds exact images to immutable artifacts, mutable storage,
typed connections, resources, secrets by governed name, and exact logical devices.
The graph binds image ABI ports and inputs; runtime addresses and credentials remain
execution facts. Commands and arbitrary program internals remain owned by the exact image.

The station and service releases below are projections.  They are deliberately not
separate authoring formats: both are total functions of the same application value.
"""

from collections.abc import Iterable, Mapping
from dataclasses import dataclass, replace
from enum import StrEnum
from re import fullmatch
from typing import NewType, cast
from urllib.parse import urlsplit

from sx_contracts import decode
from sx_contracts.content import ArtifactId, ContentRef, ContentRefError, Sha256Digest
from sx_contracts.identity import CanonicalDocument, JsonValue, ascii_canonical_json, content_id
from sx_contracts.images import BoundImage
from sx_contracts.runtime import RuntimeContractError, parse_runtime, runtime_wire
from sx_contracts.stations import (
    StationTarget,
    StationTargetContractError,
    station_target_from_dict,
    station_target_to_dict,
)

APPLICATION_SCHEMA_VERSION = "sx.application/v2"
_HISTORICAL_SCHEMA_VERSION = "sx.application/v1"
ROBOT_APPLICATION_REF_PATTERN = r"^application:[0-9a-f]{64}$"

RobotApplicationRef = NewType("RobotApplicationRef", str)
ApplicationName = NewType("ApplicationName", str)
WorkloadName = NewType("WorkloadName", str)
InterfaceName = NewType("InterfaceName", str)
ConnectionName = NewType("ConnectionName", str)
ArtifactSlot = NewType("ArtifactSlot", str)
FilesystemSlot = NewType("FilesystemSlot", str)
VolumeName = NewType("VolumeName", str)
SecretName = NewType("SecretName", str)
ComputeProfileRef = NewType("ComputeProfileRef", str)
LogicalDevice = NewType("LogicalDevice", str)
TaskFamilyRef = NewType("TaskFamilyRef", str)
EnvironmentVariableName = NewType("EnvironmentVariableName", str)
APPLICATION_BINDING_VARIABLE = EnvironmentVariableName("SX_APPLICATION_BINDING")


class ApplicationContractError(ValueError):
    """An application is ambiguous, unsafe, cyclic, or malformed."""


def parse_robot_application_ref(value: str) -> RobotApplicationRef:
    """Parse the one canonical immutable robot-application reference shape."""

    if fullmatch(ROBOT_APPLICATION_REF_PATTERN, value) is None:
        raise ApplicationContractError(
            "robot application ref must be application:<64 lowercase hex>"
        )
    return RobotApplicationRef(value)


class WorkloadPlacement(StrEnum):
    STATION = "station"
    SERVICE = "service"


class SecurityProfile(StrEnum):
    """Host authority, not a software taxonomy."""

    ISOLATED_COMPUTE = "isolated_compute"
    ACCELERATOR_COMPUTE = "accelerator_compute"
    ROBOT_IO_CONFORMER = "robot_io_conformer"
    TRUSTED_PLATFORM_RUNTIME = "trusted_platform_runtime"


class EndpointProtocol(StrEnum):
    HTTP = "http"
    WEBSOCKET = "websocket"


@dataclass(frozen=True, slots=True)
class EnvironmentEntry:
    """One immutable nonsecret process input; secret values are resolved by the owner."""

    name: EnvironmentVariableName
    value: str

    def __post_init__(self) -> None:
        _environment_name(self.name)
        if (
            not isinstance(cast("object", self.value), str)
            or "\n" in self.value
            or "\0" in self.value
        ):
            raise ApplicationContractError("environment values must be text without newline or NUL")


class InterfaceKind(StrEnum):
    ROBOT_CONTROL = "robot_control"
    APPLICATION_MEMORY = "application_memory"
    APPLICATION_SERVICE = "application_service"


class VolumeClass(StrEnum):
    SCRATCH = "scratch"
    PERSISTENT = "persistent"


class DeviceAccess(StrEnum):
    READ = "read"
    CONTROL = "control"


class DisconnectBehavior(StrEnum):
    SAFE_STOP = "safe_stop"
    LOCAL_FALLBACK = "local_fallback"


@dataclass(frozen=True, slots=True)
class DecisionLeasePolicy:
    """Station enforcement for decisions influenced by a remote service.

    The runtime assigns the actual endpoint and lease identity.  The application
    declares only the safety behavior that changes execution: how old a decision
    may be and whether loss of the remote service stops locally or transfers to an
    exact station workload in the same application.
    """

    maximum_age_ms: int
    disconnect: DisconnectBehavior
    local_fallback: WorkloadName | None = None

    def __post_init__(self) -> None:
        if isinstance(self.maximum_age_ms, bool) or self.maximum_age_ms < 1:
            raise ApplicationContractError("decision lease maximum age must be positive")
        if (self.disconnect is DisconnectBehavior.LOCAL_FALLBACK) != (
            self.local_fallback is not None
        ):
            raise ApplicationContractError(
                "local-fallback disconnect behavior needs exactly one fallback workload"
            )
        if self.local_fallback is not None:
            _name(self.local_fallback, "decision lease fallback workload")


@dataclass(frozen=True, slots=True)
class ResourceBudget:
    cpu_millis: int
    memory_mib: int
    pids: int
    accelerator_units: int = 0

    def __post_init__(self) -> None:
        values = (self.cpu_millis, self.memory_mib, self.pids)
        if any(isinstance(value, bool) or value < 1 for value in values):
            raise ApplicationContractError("workload CPU, memory, and PID budgets must be positive")
        if isinstance(self.accelerator_units, bool) or self.accelerator_units < 0:
            raise ApplicationContractError("workload accelerator units must be non-negative")


@dataclass(frozen=True, slots=True)
class ProvidedInterface:
    name: InterfaceName
    kind: InterfaceKind
    version: str
    protocol: EndpointProtocol | None = None
    container_port: int | None = None

    def __post_init__(self) -> None:
        _name(self.name, "provided interface")
        _text(self.version, "provided interface version")
        if (self.protocol is None) != (self.container_port is None):
            raise ApplicationContractError(
                "an interface ABI needs both protocol and container port"
            )
        if self.protocol is not None and not isinstance(
            cast("object", self.protocol), EndpointProtocol
        ):
            raise ApplicationContractError(
                "interface protocol must be a supported endpoint protocol"
            )
        if self.container_port is not None and (
            not isinstance(cast("object", self.container_port), int)
            or isinstance(self.container_port, bool)
            or not 1 <= self.container_port <= 65535
        ):
            raise ApplicationContractError("interface container port must be within 1..65535")


@dataclass(frozen=True, slots=True)
class WorkloadConnection:
    name: ConnectionName
    target: WorkloadName
    interface: InterfaceName
    decision_lease: DecisionLeasePolicy | None = None
    environment_variable: EnvironmentVariableName | None = None
    requires_ready: bool = True

    def __post_init__(self) -> None:
        _name(self.name, "connection")
        _name(self.target, "connection target")
        _name(self.interface, "connection interface")
        if self.environment_variable is not None:
            _environment_name(self.environment_variable)
        if not isinstance(cast("object", self.requires_ready), bool):
            raise ApplicationContractError("connection requires_ready must be a boolean")


@dataclass(frozen=True, slots=True)
class ArtifactMount:
    slot: ArtifactSlot
    artifact: ContentRef

    def __post_init__(self) -> None:
        _name(self.slot, "artifact slot")


@dataclass(frozen=True, slots=True)
class FilesystemMount:
    slot: FilesystemSlot
    volume: VolumeName
    kind: VolumeClass

    def __post_init__(self) -> None:
        _name(self.slot, "filesystem slot")
        _name(self.volume, "volume")


@dataclass(frozen=True, slots=True)
class SecretMount:
    slot: SecretName
    secret: SecretName

    def __post_init__(self) -> None:
        _name(self.slot, "secret slot")
        _name(self.secret, "governed secret")
        if any(character in str(self.secret) for character in ("=", "\n", "\0")):
            raise ApplicationContractError(
                "a secret reference must be a governed name, not a value"
            )


@dataclass(frozen=True, slots=True)
class DeviceGrant:
    device: LogicalDevice
    access: DeviceAccess

    def __post_init__(self) -> None:
        _reference(self.device, "logical device")


@dataclass(frozen=True, slots=True)
class ApplicationWorkload:
    """One exact application process and only the authority it needs.

    ``compute`` is present exactly for service placement: a station is selected by the
    application's exact target, while a service is selected by its governed project
    compute profile.  Image entrypoint and OCI healthcheck remain image metadata and
    therefore cannot be overridden here.
    """

    name: WorkloadName
    image: BoundImage
    placement: WorkloadPlacement
    security: SecurityProfile
    resources: ResourceBudget
    compute: ComputeProfileRef | None = None
    artifacts: tuple[ArtifactMount, ...] = ()
    connects: tuple[WorkloadConnection, ...] = ()
    filesystems: tuple[FilesystemMount, ...] = ()
    secrets: tuple[SecretMount, ...] = ()
    provides: tuple[ProvidedInterface, ...] = ()
    devices: tuple[DeviceGrant, ...] = ()
    environment: tuple[EnvironmentEntry, ...] = ()

    def __post_init__(self) -> None:
        _name(self.name, "workload")
        _unique((item.slot for item in self.artifacts), f"workload {self.name} artifact slots")
        _unique((item.name for item in self.connects), f"workload {self.name} connection names")
        _unique((item.slot for item in self.filesystems), f"workload {self.name} filesystem slots")
        _unique((item.slot for item in self.secrets), f"workload {self.name} secret slots")
        _unique((item.name for item in self.provides), f"workload {self.name} interfaces")
        _unique((item.device for item in self.devices), f"workload {self.name} devices")
        _unique(
            (
                *[entry.name for entry in self.environment],
                *[
                    connection.environment_variable
                    for connection in self.connects
                    if connection.environment_variable is not None
                ],
                *[mount.slot for mount in self.secrets],
            ),
            f"workload {self.name} process input names",
        )
        if any(item.target == self.name and item.requires_ready for item in self.connects):
            raise ApplicationContractError(f"workload {self.name} connects to itself")
        if self.placement is WorkloadPlacement.STATION:
            if self.compute is not None:
                raise ApplicationContractError("station workloads cannot select service compute")
        else:
            if self.compute is None or not str(self.compute).strip():
                raise ApplicationContractError("service workloads need a governed compute profile")
            if self.devices:
                raise ApplicationContractError("service workloads cannot receive robot devices")
            if self.security in {
                SecurityProfile.ROBOT_IO_CONFORMER,
                SecurityProfile.TRUSTED_PLATFORM_RUNTIME,
            }:
                raise ApplicationContractError(
                    "service workloads cannot use robot-I/O or trusted-platform authority"
                )
        if self.security is SecurityProfile.TRUSTED_PLATFORM_RUNTIME:
            raise ApplicationContractError(
                "project applications cannot request the trusted platform runtime"
            )
        if self.security is SecurityProfile.ACCELERATOR_COMPUTE:
            if self.resources.accelerator_units < 1:
                raise ApplicationContractError(
                    "accelerator-compute workloads need an accelerator resource"
                )
        elif self.security is SecurityProfile.ISOLATED_COMPUTE and self.resources.accelerator_units:
            raise ApplicationContractError(
                "isolated-compute workloads cannot reserve accelerator resources"
            )


@dataclass(frozen=True, slots=True)
class RobotApplication:
    """The complete deployable unit for one exact station target."""

    name: ApplicationName
    target: StationTarget
    workloads: tuple[ApplicationWorkload, ...]
    capabilities: tuple[TaskFamilyRef, ...]

    def __post_init__(self) -> None:
        _name(self.name, "application")
        if not self.workloads:
            raise ApplicationContractError("an application needs at least one workload")
        if not self.capabilities:
            raise ApplicationContractError("an application needs at least one task family")
        _unique((workload.name for workload in self.workloads), "workload names")
        _unique(self.capabilities, "task families")
        for capability in self.capabilities:
            _reference(capability, "task family")
        by_name = {workload.name: workload for workload in self.workloads}
        provided: dict[tuple[WorkloadName, InterfaceName], ProvidedInterface] = {}
        for workload in self.workloads:
            for interface in workload.provides:
                provided[(workload.name, interface.name)] = interface
        for workload in self.workloads:
            for connection in workload.connects:
                provider = by_name.get(connection.target)
                if provider is None:
                    raise ApplicationContractError(
                        f"workload {workload.name} connects to missing workload {connection.target}"
                    )
                if (connection.target, connection.interface) not in provided:
                    raise ApplicationContractError(
                        f"workload {workload.name} connection {connection.name} names an "
                        f"undeclared interface on {connection.target}"
                    )
                crosses_to_service = (
                    workload.placement is WorkloadPlacement.STATION
                    and provider.placement is WorkloadPlacement.SERVICE
                )
                if crosses_to_service != (connection.decision_lease is not None):
                    raise ApplicationContractError(
                        "every station-to-service connection needs exactly one decision lease"
                    )
                if (
                    workload.placement is WorkloadPlacement.SERVICE
                    and provider.placement is WorkloadPlacement.STATION
                ):
                    raise ApplicationContractError(
                        "service workloads cannot open application connections into a station"
                    )
                lease = connection.decision_lease
                if lease is not None and lease.local_fallback is not None:
                    fallback = by_name.get(lease.local_fallback)
                    if fallback is None or fallback.placement is not WorkloadPlacement.STATION:
                        raise ApplicationContractError(
                            "a decision lease fallback must name a station workload"
                        )
        _topological_names(self.workloads)
        volumes = tuple(
            mount.volume for workload in self.workloads for mount in workload.filesystems
        )
        _unique(volumes, "application volume names")
        devices = tuple(grant.device for workload in self.workloads for grant in workload.devices)
        _unique(devices, "application logical devices")
        boundaries = tuple(
            (workload, interface)
            for workload in self.workloads
            for interface in workload.provides
            if interface.kind is InterfaceKind.ROBOT_CONTROL
        )
        if len(boundaries) != 1:
            raise ApplicationContractError(
                "an application must provide exactly one robot-control boundary"
            )
        controller, _ = boundaries[0]
        if (
            controller.placement is not WorkloadPlacement.STATION
            or controller.security is not SecurityProfile.ROBOT_IO_CONFORMER
        ):
            raise ApplicationContractError(
                "the robot-control boundary must be a station robot-I/O conformer"
            )
        control_holders = tuple(
            workload
            for workload in self.workloads
            if any(grant.access is DeviceAccess.CONTROL for grant in workload.devices)
        )
        if control_holders != (controller,):
            raise ApplicationContractError(
                "only the robot-control conformer must hold logical actuator authority"
            )

    @property
    def ref(self) -> RobotApplicationRef:
        return RobotApplicationRef(
            f"application:{content_id(Sha256Digest, cast('CanonicalDocument', _document(self)))}"
        )

    @property
    def activation_order(self) -> tuple[WorkloadName, ...]:
        """The startup order, derived only from connections that require readiness."""

        return _topological_names(self.workloads)

    @property
    def robot_control(self) -> tuple[ApplicationWorkload, ProvidedInterface]:
        return next(
            (workload, interface)
            for workload in self.workloads
            for interface in workload.provides
            if interface.kind is InterfaceKind.ROBOT_CONTROL
        )

    def specialize(
        self,
        *,
        target: StationTarget,
        workloads: Mapping[WorkloadName, ApplicationWorkload],
    ) -> "RobotApplication":
        """Substitute named implementations for one exact target.

        Every replacement is a complete workload: native image, artifacts, devices,
        resources and connections travel together. Unknown names and renaming refuse;
        adding or removing nodes is ordinary construction of a different graph.
        Substitution preserves untouched nodes and their order, including historical
        identities. No evaluation, hardware qualification or approval is transferred.
        """
        known = {workload.name for workload in self.workloads}
        if unknown := set(workloads) - known:
            raise ApplicationContractError(
                f"specialization names unknown workloads: {sorted(unknown)}"
            )
        if any(name != workload.name for name, workload in workloads.items()):
            raise ApplicationContractError("specialization cannot rename a workload")
        return replace(
            self,
            target=target,
            workloads=tuple(workloads.get(workload.name, workload) for workload in self.workloads),
        )


@dataclass(frozen=True, slots=True)
class StationApplicationRelease:
    application: RobotApplicationRef
    target: StationTarget
    workloads: tuple[ApplicationWorkload, ...]


@dataclass(frozen=True, slots=True)
class ServiceApplicationRelease:
    application: RobotApplicationRef
    workloads: tuple[ApplicationWorkload, ...]


def application_endpoint_name(workload: WorkloadName, interface: InterfaceName) -> str:
    """A bounded network alias for one unambiguous logical endpoint pair.

    Address allocation stays outside graph identity. Compilers still check uniqueness
    among the aliases in a release rather than treating a truncated digest as proof.
    """

    _name(workload, "endpoint workload")
    _name(interface, "endpoint interface")
    digest = content_id(Sha256Digest, {"workload": str(workload), "interface": str(interface)})
    return f"sx-{digest[:60]}"


def application_environment(
    application: RobotApplication,
    workload: WorkloadName,
    endpoints: Mapping[tuple[WorkloadName, InterfaceName], str],
) -> tuple[EnvironmentEntry, ...]:
    """Bind logical connections to owner-observed addresses without changing identity.

    Only inputs consumed by this workload are required. Extra addresses grant no
    connection; every injected input must come from an edge in the exact graph.
    """
    by_name = {item.name: item for item in application.workloads}
    if workload not in by_name:
        raise ApplicationContractError("process binding names an unknown workload")
    consumer = by_name[workload]
    result = list(consumer.environment)
    for connection in consumer.connects:
        variable = connection.environment_variable
        if variable is None:
            raise ApplicationContractError("application connection has no process binding")
        provider = by_name[connection.target]
        interface = next(item for item in provider.provides if item.name == connection.interface)
        if interface.protocol is None or interface.container_port is None:
            raise ApplicationContractError("connected interface has no executable endpoint")
        address = endpoints.get((provider.name, interface.name))
        if address is None:
            raise ApplicationContractError("application connection has no observed endpoint")
        try:
            parsed = urlsplit(address)
            port = parsed.port
        except ValueError as error:
            raise ApplicationContractError("application endpoint is malformed") from error
        protocols = {
            EndpointProtocol.HTTP: {"http", "https"},
            EndpointProtocol.WEBSOCKET: {"ws", "wss"},
        }
        if (
            port == 0
            or parsed.scheme not in protocols[interface.protocol]
            or not parsed.hostname
            or parsed.username is not None
            or parsed.password is not None
            or parsed.fragment
        ):
            raise ApplicationContractError("application endpoint disagrees with its interface")
        result.append(EnvironmentEntry(variable, address))
    if any(entry.name == APPLICATION_BINDING_VARIABLE for entry in result):
        raise ApplicationContractError("application launch binding is reserved for the owner")
    controller, control = application.robot_control
    if consumer.name == controller.name:
        result.append(
            EnvironmentEntry(
                APPLICATION_BINDING_VARIABLE,
                ascii_canonical_json(
                    {
                        "application_ref": str(application.ref),
                        "workload_name": str(controller.name),
                        "image_name": str(controller.image.name),
                        "image_digest": str(controller.image.digest),
                        "interface_name": str(control.name),
                        "interface_version": str(control.version),
                    }
                ),
            )
        )
    return tuple(result)


def station_application_release(application: RobotApplication) -> StationApplicationRelease:
    """Derive the station-only release in connection order."""

    by_name = {workload.name: workload for workload in application.workloads}
    workloads = tuple(
        by_name[name]
        for name in application.activation_order
        if by_name[name].placement is WorkloadPlacement.STATION
    )
    return StationApplicationRelease(application.ref, application.target, workloads)


def service_application_release(application: RobotApplication) -> ServiceApplicationRelease:
    """Derive the hosted/private release in connection order."""

    by_name = {workload.name: workload for workload in application.workloads}
    workloads = tuple(
        by_name[name]
        for name in application.activation_order
        if by_name[name].placement is WorkloadPlacement.SERVICE
    )
    return ServiceApplicationRelease(application.ref, workloads)


def robot_application_to_dict(application: RobotApplication) -> dict[str, object]:
    return {
        "schema": APPLICATION_SCHEMA_VERSION
        if _has_execution_facts(application)
        else _HISTORICAL_SCHEMA_VERSION,
        **_document(application),
    }


def robot_application_from_dict(value: object) -> RobotApplication:
    document = decode.document(value, where="robot application", error=ApplicationContractError)
    _exact(document, {"schema", "name", "target", "workloads", "capabilities"}, "application")
    schema = decode.text(document, "schema")
    if schema not in {APPLICATION_SCHEMA_VERSION, _HISTORICAL_SCHEMA_VERSION}:
        raise ApplicationContractError(
            f"unsupported robot-application schema: {document['schema']!r}"
        )
    try:
        return RobotApplication(
            ApplicationName(decode.text(document, "name")),
            station_target_from_dict(document["target"]),
            tuple(
                _workload_from_dict(
                    item, executable=document["schema"] == APPLICATION_SCHEMA_VERSION
                )
                for item in decode.sequence(document, "workloads")
            ),
            tuple(TaskFamilyRef(item) for item in decode.texts(document, "capabilities")),
        )
    except ApplicationContractError:
        raise
    except (ContentRefError, RuntimeContractError, StationTargetContractError, ValueError) as error:
        raise ApplicationContractError(f"malformed robot application: {error}") from error


def _document(application: RobotApplication) -> dict[str, JsonValue]:
    return {
        "name": str(application.name),
        "target": cast("dict[str, JsonValue]", station_target_to_dict(application.target)),
        "workloads": [_workload_document(workload) for workload in application.workloads],
        "capabilities": [str(capability) for capability in application.capabilities],
    }


def _workload_document(workload: ApplicationWorkload) -> dict[str, JsonValue]:
    return {
        **(
            {
                "environment": [
                    {"name": str(item.name), "value": item.value} for item in workload.environment
                ]
            }
            if workload.environment
            else {}
        ),
        "name": str(workload.name),
        "image": runtime_wire(workload.image),
        "placement": workload.placement.value,
        "security": workload.security.value,
        "resources": {
            "cpu_millis": workload.resources.cpu_millis,
            "memory_mib": workload.resources.memory_mib,
            "pids": workload.resources.pids,
            "accelerator_units": workload.resources.accelerator_units,
        },
        "compute": None if workload.compute is None else str(workload.compute),
        "artifacts": [
            {"slot": str(mount.slot), "artifact": _content_document(mount.artifact)}
            for mount in workload.artifacts
        ],
        "connects": [
            {
                "name": str(connection.name),
                "target": str(connection.target),
                "interface": str(connection.interface),
                **(
                    {"environment_variable": str(connection.environment_variable)}
                    if connection.environment_variable is not None
                    else {}
                ),
                **({"requires_ready": False} if not connection.requires_ready else {}),
                "decision_lease": (
                    None
                    if connection.decision_lease is None
                    else {
                        "maximum_age_ms": connection.decision_lease.maximum_age_ms,
                        "disconnect": connection.decision_lease.disconnect.value,
                        "local_fallback": (
                            None
                            if connection.decision_lease.local_fallback is None
                            else str(connection.decision_lease.local_fallback)
                        ),
                    }
                ),
            }
            for connection in workload.connects
        ],
        "filesystems": [
            {"slot": str(mount.slot), "volume": str(mount.volume), "kind": mount.kind.value}
            for mount in workload.filesystems
        ],
        "secrets": [
            {"slot": str(mount.slot), "secret": str(mount.secret)} for mount in workload.secrets
        ],
        "provides": [
            {
                "name": str(item.name),
                "kind": item.kind.value,
                "version": item.version,
                **(
                    {"protocol": item.protocol.value, "container_port": item.container_port}
                    if item.protocol is not None
                    else {}
                ),
            }
            for item in workload.provides
        ],
        "devices": [
            {"device": str(grant.device), "access": grant.access.value}
            for grant in workload.devices
        ],
    }


def _workload_from_dict(value: object, *, executable: bool) -> ApplicationWorkload:
    document = decode.document(value, where="application workload", error=ApplicationContractError)
    fields = {
        "name",
        "image",
        "placement",
        "security",
        "resources",
        "compute",
        "artifacts",
        "connects",
        "filesystems",
        "secrets",
        "provides",
        "devices",
    }
    _optional(document, fields, {"environment"} if executable else set(), "application workload")
    resources = decode.mapping(document, "resources")
    _exact(
        resources,
        {"cpu_millis", "memory_mib", "pids", "accelerator_units"},
        "workload resources",
    )
    runtime = parse_runtime(document["image"])
    if not isinstance(runtime, BoundImage):
        raise ApplicationContractError("application workload runtime must be an OCI image")
    compute = document["compute"]
    if compute is not None and not isinstance(compute, str):
        raise ApplicationContractError("workload compute must be null or a governed reference")
    return ApplicationWorkload(
        WorkloadName(decode.text(document, "name")),
        runtime,
        WorkloadPlacement(decode.text(document, "placement")),
        SecurityProfile(decode.text(document, "security")),
        ResourceBudget(
            decode.integer(resources, "cpu_millis"),
            decode.integer(resources, "memory_mib"),
            decode.integer(resources, "pids"),
            decode.integer(resources, "accelerator_units"),
        ),
        None if compute is None else ComputeProfileRef(compute),
        tuple(_artifact_from_dict(item) for item in decode.sequence(document, "artifacts")),
        tuple(
            _connection_from_dict(item, executable=executable)
            for item in decode.sequence(document, "connects")
        ),
        tuple(_filesystem_from_dict(item) for item in decode.sequence(document, "filesystems")),
        tuple(_secret_from_dict(item) for item in decode.sequence(document, "secrets")),
        tuple(
            _interface_from_dict(item, executable=executable)
            for item in decode.sequence(document, "provides")
        ),
        tuple(_device_from_dict(item) for item in decode.sequence(document, "devices")),
        tuple(_environment_from_dict(item) for item in decode.sequence(document, "environment"))
        if "environment" in document
        else (),
    )


def _artifact_from_dict(value: object) -> ArtifactMount:
    document = decode.document(value, where="artifact mount", error=ApplicationContractError)
    _exact(document, {"slot", "artifact"}, "artifact mount")
    return ArtifactMount(
        ArtifactSlot(decode.text(document, "slot")),
        _content_from_dict(document["artifact"]),
    )


def _connection_from_dict(value: object, *, executable: bool) -> WorkloadConnection:
    document = decode.document(value, where="workload connection", error=ApplicationContractError)
    _optional(
        document,
        {"name", "target", "interface", "decision_lease"},
        {"environment_variable", "requires_ready"} if executable else set(),
        "workload connection",
    )
    lease_value = document["decision_lease"]
    return WorkloadConnection(
        ConnectionName(decode.text(document, "name")),
        WorkloadName(decode.text(document, "target")),
        InterfaceName(decode.text(document, "interface")),
        None if lease_value is None else _decision_lease_from_dict(lease_value),
        EnvironmentVariableName(decode.text(document, "environment_variable"))
        if "environment_variable" in document
        else None,
        _requires_ready(document),
    )


def _decision_lease_from_dict(value: object) -> DecisionLeasePolicy:
    document = decode.document(value, where="decision lease", error=ApplicationContractError)
    _exact(
        document,
        {"maximum_age_ms", "disconnect", "local_fallback"},
        "decision lease",
    )
    fallback = document["local_fallback"]
    if fallback is not None and not isinstance(fallback, str):
        raise ApplicationContractError("decision lease fallback must be text or null")
    return DecisionLeasePolicy(
        decode.integer(document, "maximum_age_ms"),
        DisconnectBehavior(decode.text(document, "disconnect")),
        None if fallback is None else WorkloadName(fallback),
    )


def _filesystem_from_dict(value: object) -> FilesystemMount:
    document = decode.document(value, where="filesystem mount", error=ApplicationContractError)
    _exact(document, {"slot", "volume", "kind"}, "filesystem mount")
    return FilesystemMount(
        FilesystemSlot(decode.text(document, "slot")),
        VolumeName(decode.text(document, "volume")),
        VolumeClass(decode.text(document, "kind")),
    )


def _secret_from_dict(value: object) -> SecretMount:
    document = decode.document(value, where="secret mount", error=ApplicationContractError)
    _exact(document, {"slot", "secret"}, "secret mount")
    return SecretMount(
        SecretName(decode.text(document, "slot")), SecretName(decode.text(document, "secret"))
    )


def _interface_from_dict(value: object, *, executable: bool) -> ProvidedInterface:
    document = decode.document(value, where="provided interface", error=ApplicationContractError)
    _optional(
        document,
        {"name", "kind", "version"},
        {"protocol", "container_port"} if executable else set(),
        "provided interface",
    )
    return ProvidedInterface(
        InterfaceName(decode.text(document, "name")),
        InterfaceKind(decode.text(document, "kind")),
        decode.text(document, "version"),
        EndpointProtocol(decode.text(document, "protocol")) if "protocol" in document else None,
        decode.integer(document, "container_port") if "container_port" in document else None,
    )


def _device_from_dict(value: object) -> DeviceGrant:
    document = decode.document(value, where="device grant", error=ApplicationContractError)
    _exact(document, {"device", "access"}, "device grant")
    return DeviceGrant(
        LogicalDevice(decode.text(document, "device")),
        DeviceAccess(decode.text(document, "access")),
    )


def _content_document(value: ContentRef) -> dict[str, str]:
    return {"artifact_id": str(value.artifact_id), "sha256": str(value.sha256)}


def _content_from_dict(value: object) -> ContentRef:
    document = decode.document(value, where="content reference", error=ApplicationContractError)
    _exact(document, {"artifact_id", "sha256"}, "content reference")
    return ContentRef(
        ArtifactId(decode.text(document, "artifact_id")),
        Sha256Digest(decode.text(document, "sha256")),
    )


def _topological_names(workloads: tuple[ApplicationWorkload, ...]) -> tuple[WorkloadName, ...]:
    dependencies = {
        workload.name: {
            connection.target for connection in workload.connects if connection.requires_ready
        }
        for workload in workloads
    }
    ordered: list[WorkloadName] = []
    remaining = set(dependencies)
    while remaining:
        ready = sorted(
            (name for name in remaining if dependencies[name].isdisjoint(remaining)), key=str
        )
        if not ready:
            cycle = ", ".join(sorted(map(str, remaining)))
            raise ApplicationContractError(f"application workload graph contains a cycle: {cycle}")
        ordered.extend(ready)
        remaining.difference_update(ready)
    return tuple(ordered)


def _has_execution_facts(application: RobotApplication) -> bool:
    return any(
        workload.environment
        or any(interface.protocol is not None for interface in workload.provides)
        or any(
            connection.environment_variable is not None or not connection.requires_ready
            for connection in workload.connects
        )
        for workload in application.workloads
    )


def _environment_name(value: EnvironmentVariableName) -> None:
    if fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", str(value)) is None:
        raise ApplicationContractError("environment variable name must be an ASCII identifier")


def _environment_from_dict(value: object) -> EnvironmentEntry:
    document = decode.document(value, where="environment entry", error=ApplicationContractError)
    _exact(document, {"name", "value"}, "environment entry")
    # Empty values are legitimate process inputs.
    text = document["value"]
    if not isinstance(text, str):
        raise ApplicationContractError("environment value must be text")
    return EnvironmentEntry(EnvironmentVariableName(decode.text(document, "name")), text)


def _requires_ready(document: decode.Document) -> bool:
    value = document.get("requires_ready", True)
    if not isinstance(value, bool):
        raise ApplicationContractError("connection requires_ready must be a boolean")
    return value


def _optional(
    document: decode.Document, required: set[str], optional: set[str], label: str
) -> None:
    if not required <= set(document) or not set(document) <= required | optional:
        raise ApplicationContractError(f"{label} has fields {sorted(document)}")


def _exact(document: decode.Document, fields: set[str], label: str) -> None:
    if set(document) != fields:
        actual = sorted(document)
        raise ApplicationContractError(f"{label} has fields {actual}")


def _name(value: object, label: str) -> None:
    text = str(value)
    if (
        not text
        or not text.isascii()
        or text != text.strip()
        or any(character.isspace() or character in "@:/\\" for character in text)
    ):
        raise ApplicationContractError(f"{label} must be a non-empty governed name")


def _text(value: str, label: str) -> None:
    if not value.strip():
        raise ApplicationContractError(f"{label} must not be empty")


def _reference(value: object, label: str) -> None:
    text = str(value)
    if (
        not text
        or not text.isascii()
        or text != text.strip()
        or any(character.isspace() or character in "=\\\n\0" for character in text)
    ):
        raise ApplicationContractError(f"{label} must be a non-empty governed reference")


def _unique(values: Iterable[object], label: str) -> None:
    items = tuple(values)
    if len(set(items)) != len(items):
        raise ApplicationContractError(f"{label} must be unique")
