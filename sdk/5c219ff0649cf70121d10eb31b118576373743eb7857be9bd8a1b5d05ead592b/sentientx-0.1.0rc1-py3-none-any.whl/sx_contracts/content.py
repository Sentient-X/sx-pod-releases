"""Content identity for artifacts whose *kind* is the consumer's business.

`ContentRef` pins an artifact by name and exact bytes without claiming to know what
those bytes are — a trained checkpoint, an inner-agent bundle, a prompt bundle, a config
document. It is the one shared digest-bearing reference; a repo that needs "some pinned
artifact" uses this rather than minting another `(id, sha256)` pair.

What kind of artifact a particular reference names is the *signature's* business, not a
second type's: a field spelled `checkpoint: ContentRef` says as much as a checkpoint-only
sibling type did, and says it where a reader is already looking. `AssetRef`
(sx-embodiments) is not a sibling at all: it carries real per-asset facts beyond identity.

The wire is not renamed with the Python names. The checkpoint documents that already say
`"checkpoint_id"` keep saying it; their codecs own that spelling.
"""

from dataclasses import dataclass
from typing import NewType

from sx_contracts.wire import HexDigest

ArtifactId = NewType("ArtifactId", str)


class ContentRefError(ValueError):
    """A content reference is incomplete or malformed."""


class Sha256Digest(HexDigest):
    """Validated lowercase SHA-256 of an artifact's canonical bytes."""

    error = ContentRefError
    noun = "sha256 digest"


@dataclass(frozen=True, slots=True)
class ContentRef:
    """One opaque artifact, pinned by name and exact content."""

    artifact_id: ArtifactId
    sha256: Sha256Digest

    def __post_init__(self) -> None:
        if not str(self.artifact_id).strip():
            raise ContentRefError("artifact id must not be empty")


@dataclass(frozen=True, slots=True)
class ContentBlob:
    """The identity and measured size of immutable bytes.

    Locations, formats, roles, and provenance belong to the values that use the bytes;
    this product owns only the two facts shared by assets, delivery objects, and capture
    artifacts.
    """

    sha256: Sha256Digest
    size_bytes: int

    def __post_init__(self) -> None:
        if isinstance(self.size_bytes, bool) or self.size_bytes < 0:
            raise ContentRefError("content size_bytes must be a non-negative integer")
