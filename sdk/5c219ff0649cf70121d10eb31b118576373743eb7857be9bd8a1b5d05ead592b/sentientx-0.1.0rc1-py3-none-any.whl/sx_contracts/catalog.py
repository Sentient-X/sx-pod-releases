"""Typed identities for Catalog-governed bytes, whatever form they take.

The catalog governs one kind of thing — an *entry* — and entries are wildly
different inside: an episode dataset, a training corpus, an embodiment's mesh and
URDF bundle, a 3D scene, model weights, a sealed raw capture. What they share is
that each exists as bytes, sometimes as bytes in several forms at once: the same
recording as the canonical RRD and as the fused MCAP it was built from, a capture
sealed as a LeRobot v3 tar, an embodiment as a set of meshes.

So the vocabulary here is deliberately two words, not one per kind:

    Representation   *what forms exist* — a fact about the entry, cheap and stable
    Access           *how to read one now* — a grant, expiring, never cached

Splitting them is what lets one interface span the whole catalog. Listing forms
needs no authority to hand out bytes, and handing out bytes needs no opinion about
what the bytes mean. It is also what keeps the query plane from being a special
case: reading a table and reading a file are two arms of one `Access`, not two APIs.
"""

import re
from dataclasses import dataclass
from enum import StrEnum
from typing import ClassVar, Self, TypeAlias, cast

from sx_contracts.content import Sha256Digest
from sx_contracts.wire import WireString


class CatalogRepresentationError(ValueError):
    """A representation or read grant is incomplete or internally inconsistent."""


class CatalogSegmentError(ValueError):
    """A segment reference is incomplete or carries an invalid base digest."""


class DatasetSnapshotIdError(ValueError):
    """A snapshot identity is not the catalog's content-addressed entry name."""


_SNAPSHOT_PREFIX = "snapshots."


class DatasetSnapshotId(WireString):
    """One immutable membership, named by its own content: ``snapshots.<digest>``.

    The name and the pin are deliberately the same value. It is the entry name a
    read grant is asked for, so nothing has to derive an address from an id; and it
    carries the digest, so a corpus that names one cannot be re-pointed at other
    members by renaming anything. A caller resolves it and checks the digest it is
    handed against `digest` — the two disagreeing is a catalog answering about
    something else, which is a refusal rather than a surprise.
    """

    __slots__ = ()
    json_pattern: ClassVar[str | None] = r"^snapshots\.[a-f0-9]{64}$"

    def __new__(cls, value: str) -> Self:
        prefix, _, digest = value.partition(".")
        if prefix != "snapshots" or not digest:
            raise DatasetSnapshotIdError(
                f"a dataset snapshot id is {_SNAPSHOT_PREFIX}<digest>, not {value!r}"
            )
        try:
            Sha256Digest(digest)  # the 64-hex invariant lives in HexDigest, not here
        except ValueError as error:
            raise DatasetSnapshotIdError(
                f"invalid dataset snapshot id {value!r}: {error}"
            ) from error
        return super().__new__(cls, value)

    @classmethod
    def of(cls, digest: Sha256Digest) -> Self:
        """Name the membership whose canonical bytes hash to this digest."""
        return cls(f"{_SNAPSHOT_PREFIX}{digest}")

    @property
    def digest(self) -> Sha256Digest:
        """The membership digest this name is."""
        return Sha256Digest(self[len(_SNAPSHOT_PREFIX) :])


class RepresentationFormat(StrEnum):
    """The shape an entry's bytes are in — which reader opens them, nothing more.

    Every member names a tool. That is the whole definition, and it is what keeps
    the vocabulary from drifting into governance: a sealed raw capture is evidence,
    but it is evidence *in MCAP*, and the reader does not care which. Rawness is a
    property of the entry's kind, so there is no `RAW` member here — asking for one
    would be asking "what may I do with this?", which is the grant's question.

    Not `DeliveryFormat`, deliberately. The two vocabularies overlap but answer
    different questions: a delivery format is what a customer destination may be
    *configured to emit*, and carries packaging in its wire values (`rrd_bundle`)
    plus a legacy duplicate it cannot yet drop (`rerun_bundle`). A representation is
    what bytes already in the catalog *are*. See `docs/ABSTRACTIONS.md`.

    It *does* share `CaptureArtifactFormat`'s three values exactly, because there
    the two really are one question — a capture artifact's admitted format is the
    shape of its bytes. They are spelled out rather than derived so this module
    stays readable, and `sx-contracts` proves the equality instead of assuming it.
    """

    RRD = "rrd"
    """The canonical `sx.episode` artifact — the one form that is also a table."""

    MCAP = "mcap"
    LEROBOT_V3_TAR = "lerobot_v3_tar"
    SIMULATION_JSON = "simulation_json"

    PARQUET = "parquet"
    """A columnar index the query engine reads directly — a snapshot's membership."""

    WEIGHTS = "weights"
    """Model weights, whether trained here or brought in as a base."""

    ASSET_BUNDLE = "asset_bundle"
    """The native artifacts of one embodiment, scene, or world, as a set."""


@dataclass(frozen=True, slots=True)
class Representation:
    """One form an entry's bytes exist in — a fact about it, not a way to read it.

    Deliberately carries no digest: the entry already has a content identity, and a
    second one computed over the same bytes would be a second truth to keep in step.
    """

    format: RepresentationFormat
    objects: int
    size_bytes: int

    def __post_init__(self) -> None:
        if self.objects <= 0:
            raise CatalogRepresentationError("a representation with no objects is not a form")
        if self.size_bytes < 0:
            raise CatalogRepresentationError("representation size_bytes must be >= 0")


@dataclass(frozen=True, slots=True)
class ObjectRead:
    """One expiring grant to read one immutable object.

    Two fields, because a grant is an address and a proof and nothing else. Size
    is deliberately absent: `Representation.size_bytes` already answers "how much
    is this?" in the call that is free to make, and repeating it per object would
    put the same total on the wire twice — once where deciding is cheap and once
    where the decision has already been made.
    """

    sha256: Sha256Digest
    url: str

    def __post_init__(self) -> None:
        if not self.url:
            raise CatalogRepresentationError("an object read grant must carry a URL")
        object.__setattr__(self, "sha256", Sha256Digest(self.sha256))


@dataclass(frozen=True, slots=True)
class ObjectReads:
    """Read these bytes yourself, before the grants expire."""

    objects: tuple[ObjectRead, ...]
    expires_in_s: int

    def __post_init__(self) -> None:
        if not self.objects:
            raise CatalogRepresentationError("an object grant must cover at least one object")
        if self.expires_in_s <= 0:
            raise CatalogRepresentationError("an object grant must expire")


@dataclass(frozen=True, slots=True)
class QueryPlane:
    """Read these bytes as a table, from the server that already serves them.

    The other arm of `Access`. A caller holding this never downloads anything: it
    opens the named dataset on that server and gets a lazy plan back.
    """

    server_url: str
    dataset_id: str
    dataset_name: str

    def __post_init__(self) -> None:
        if not (self.server_url and self.dataset_id and self.dataset_name):
            raise CatalogRepresentationError("a query plane grant must be fully addressed")


Access: TypeAlias = ObjectReads | QueryPlane
"""How to read one representation *now*.

Which arm you get is the catalog's answer, not the caller's choice, and the two
are not equivalent offers: `QueryPlane` arrives only for `RRD`, only where a
server already serves those episodes as tables, and it is strictly the better
read — a lazy plan with predicate pushdown instead of N downloads. `ObjectReads`
is the floor, always available, and what `RRD` falls back to where no such server
is deployed. So a caller matches on the arm; it never asks for one."""


@dataclass(frozen=True, slots=True)
class CatalogSegmentRef:
    dataset_id: str
    segment_id: str
    base_sha256: Sha256Digest

    def __post_init__(self) -> None:
        if not self.dataset_id.strip() or not self.segment_id.strip():
            raise CatalogSegmentError("Catalog segment dataset and segment ids must not be empty")
        if any(character.isspace() for character in self.dataset_id):
            raise CatalogSegmentError("Catalog dataset id must not contain whitespace")
        if self.segment_id.startswith("/") or self.segment_id.endswith("/"):
            raise CatalogSegmentError("Catalog segment id must be relative and non-empty")
        if re.fullmatch(r"[a-f0-9]{64}", str(self.base_sha256)) is None:
            raise CatalogSegmentError("Catalog segment base_sha256 must be lowercase SHA-256")


def catalog_segment_to_dict(value: CatalogSegmentRef) -> dict[str, str]:
    return {
        "dataset_id": value.dataset_id,
        "segment_id": value.segment_id,
        "base_sha256": str(value.base_sha256),
    }


def catalog_segment_from_dict(value: object) -> CatalogSegmentRef:
    if not isinstance(value, dict):
        raise CatalogSegmentError("Catalog segment must be an object")
    fields = cast("dict[str, object]", value)
    if set(fields) != {"dataset_id", "segment_id", "base_sha256"}:
        raise CatalogSegmentError(
            "Catalog segment must contain exactly dataset_id, segment_id, and base_sha256"
        )
    dataset_id = fields["dataset_id"]
    segment_id = fields["segment_id"]
    base_sha256 = fields["base_sha256"]
    if (
        not isinstance(dataset_id, str)
        or not isinstance(segment_id, str)
        or not isinstance(base_sha256, str)
    ):
        raise CatalogSegmentError("Catalog segment fields must be strings")
    return CatalogSegmentRef(dataset_id, segment_id, Sha256Digest(base_sha256))
