"""Leased scarcity, and the one receipt allowed to say what a call cost.

An external call is a partition in miniature. A worker may not simply make one: it
acquires a **lease** from the party that owns the scarcity (admission), makes exactly
one call, and settles the lease with a **receipt** (measurement). Between those two
acts the call is outstanding, and that fact is a row somebody else can see — which is
the whole difference between a limiter and a process-local counter.

`sxd.gemini_admission` was the counter, and it was weaker than it looked. The module
*describes* an RPM window, a token bucket, a concurrency cap and a circuit breaker
behind a flock-guarded state file — but `AdmissionService`, the class holding all of
it, is constructed nowhere outside `tests/test_gemini_admission.py`, and neither is
`install_global_service`. What production actually admitted against was
`_MODEL_SEMAPHORES` in `sxd.umico.adapters.stt_vlm`: a bare per-process
`BoundedSemaphore` with no window, no bucket, no breaker, and one process's idea of a
fleet-wide ceiling. So this replaces less than that file claims, which is worth saying
plainly — the honest comparison is against nothing, not against a limiter that worked
on one node. The ceilings belong to a project rather than to a filesystem, so they live
where the project's other governed facts live, and this is the vocabulary both ends
speak.

Three parties speak it and none may import the others: a worker asks for a lease and
settles it, the catalog issues and records it, and a project author writes the policy
that says how much scarcity there is. So the values are here.

**What a receipt may say, and may not.** It records provider *facts* — units the
provider counted, the identity the provider gave its answer — and never a price. Price
is billing's, one meter version behind it, and a cost stamped here would be a second
one nobody could reconcile. It records `credential_slot`, which is the **name** of a
credential in the secret store and never its value; no type in this module carries
secret material, and none ever may.

**Ambiguity is the interesting case.** A mutation whose outcome is unknown — a timeout
after the bytes went out — must never be silently retried and must never be silently
dropped. It settles into a state that fails closed and says how it can be recovered:
the provider deduplicates on the idempotency key (replay it), the provider can be asked
whether it landed (query it), or nothing can answer (it is unreconcilable, and that key
is refused forever). :func:`ledger_state` is the one total function from what a worker
observed to what the ledger makes of it.

**Deliberately absent.** There is no token-per-minute ceiling: scarcity here is counted
in leases — outstanding ones for concurrency, granted ones for the window — and a
budget over :class:`UsageFact` quantities is derivable from the settled ledger the day a
policy field has a reader, without a column. And there is no reconciliation *verb*: an
ambiguous effect is reconciled by settling it again with a definite outcome, which is
the same act under the same identity rather than a second one to keep in step.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum
from typing import ClassVar, Literal, TypeAlias
from uuid import UUID

from sx_contracts.content import Sha256Digest
from sx_contracts.operations import IdempotencyKey, OperationFailure
from sx_contracts.pipelines import Effects
from sx_contracts.wire import DottedIdentifier


class EffectContractError(ValueError):
    """A provider-effect value violates the law it declares."""


class ProviderName(DottedIdentifier):
    """The external service scarcity is leased from — ``gemini``, not a URL."""

    __slots__ = ()
    error: ClassVar[type[Exception]] = EffectContractError
    noun: ClassVar[str] = "provider name"


class CredentialSlot(DottedIdentifier):
    """The **name** of the credential a call is made under. Never its value.

    Scarcity is a property of the key, not of the service: two projects holding two
    keys at one provider have two independent ceilings, and one key used by twenty
    workers has one. So the slot is half of every ceiling's identity — and it is a
    name in the secret store, which is why it is safe to write into a row, a receipt
    and a log line.
    """

    __slots__ = ()
    error: ClassVar[type[Exception]] = EffectContractError
    noun: ClassVar[str] = "credential slot"


class EffectOperation(DottedIdentifier):
    """Which call this is — ``generate-content``, ``embed``.

    A label on the effect rather than a term in the ceiling: a project's key is limited
    as one key, and splitting the ceiling per operation would let a caller evade it by
    naming a new one.
    """

    __slots__ = ()
    error: ClassVar[type[Exception]] = EffectContractError
    noun: ClassVar[str] = "provider operation"


class UsageUnit(StrEnum):
    """The counted quantities a provider reports about one call.

    Closed, because a metered quantity nobody named is a quantity nobody can bill or
    compare. A provider that counts something not here adds a member in the change
    that reads it.
    """

    REQUESTS = "requests"
    INPUT_TOKENS = "input_tokens"
    OUTPUT_TOKENS = "output_tokens"
    CACHED_INPUT_TOKENS = "cached_input_tokens"


@dataclass(frozen=True, slots=True, order=True)
class UsageFact:
    """One quantity the provider counted, exactly as the provider reported it.

    A fact, never a price. Zero is legitimate and is not absence — a cached call
    reporting zero input tokens is measurement, and dropping it would make a truthful
    zero indistinguishable from a provider that counts nothing.
    """

    unit: UsageUnit
    quantity: int

    def __post_init__(self) -> None:
        if isinstance(self.quantity, bool) or self.quantity < 0:
            raise EffectContractError(
                f"a counted provider quantity is non-negative: {self.quantity!r}"
            )


class EffectOutcome(StrEnum):
    """What the worker observed about its own call."""

    SUCCEEDED = "succeeded"
    FAILED = "failed"
    AMBIGUOUS = "ambiguous"


class AmbiguityRecovery(StrEnum):
    """How an unknown outcome can be turned into a known one."""

    REPLAY_UNDER_KEY = "replay_under_key"
    """The provider deduplicates on the idempotency key: calling again settles it."""

    PROVIDER_QUERY = "provider_query"
    """The provider can be asked whether the effect landed.

    Against a handle it gave, when there is one — and often there is not, which is why
    :attr:`EffectAmbiguous.provider_handle` may be empty here and only here. The two
    cases that actually occur both arrive handleless: a call that timed out before the
    provider named anything, and a lease that expired with its holder gone, where the
    ledger declares the query because no worker survived to describe the call. An
    operator then queries by key and time rather than by id. Read this as "somebody can
    still find out", not as "an id exists to look up".
    """

    UNRECONCILABLE = "unreconcilable"
    """Nothing can answer. The effect fails closed permanently, and its key is spent."""


class EffectState(StrEnum):
    """What the ledger holds about one effect.

    Not :class:`EffectOutcome`. An outcome is what a worker saw; a state is what this
    ledger made of it, and the two differ in exactly one place — an ambiguous outcome
    that nothing can reconcile is ``unreconcilable`` here, which is the state that
    refuses that idempotency key forever.
    """

    LEASED = "leased"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    AMBIGUOUS = "ambiguous"
    UNRECONCILABLE = "unreconcilable"


def _usage(facts: tuple[UsageFact, ...]) -> tuple[UsageFact, ...]:
    """The counted quantities in one canonical order, each unit at most once.

    Sorted so two receipts of the same call are equal values rather than merely
    equivalent ones, and unique because a unit counted twice is two answers to one
    question with no rule for choosing.
    """
    units = [fact.unit for fact in facts]
    if len(set(units)) != len(units):
        raise EffectContractError("a settlement counts each usage unit at most once")
    return tuple(sorted(facts))


@dataclass(frozen=True, slots=True)
class EffectSucceeded:
    """The provider answered, and this is what the answer cost and what it was."""

    usage: tuple[UsageFact, ...]

    provider_response_id: str
    """The provider's own identity for this answer — its response id, or failing that
    the request id it returned in a header.

    Required, and not derivable: it is the handle an operator carries back to the
    provider's own console when a bill or an outcome is disputed. A success that
    cannot name what the provider answered is not evidence of anything.
    """

    response_sha256: Sha256Digest
    """This catalog's own identity for the answer's bytes, so the provider's word and
    the worker's copy can be compared later."""

    outcome: Literal[EffectOutcome.SUCCEEDED] = EffectOutcome.SUCCEEDED

    def __post_init__(self) -> None:
        object.__setattr__(self, "usage", _usage(self.usage))
        if not self.provider_response_id:
            raise EffectContractError("a successful effect names the provider's own response id")


@dataclass(frozen=True, slots=True)
class EffectFailed:
    """The provider definitely did not perform the effect, and said why.

    Usage is still carried: a call that failed after the provider counted tokens cost
    those tokens, and a receipt that omitted them would under-report what was spent.

    **``failure.retryable`` decides whether the key survives, so it is load-bearing
    rather than annotation.** Nothing was mutated, so trying again is not a second
    mutation — it is the first one finally happening, and the ledger says so: a
    retryable failure leaves the key acquirable and the next request is granted a fresh
    attempt, while a final one settles the key and every later request replays this
    receipt. Spelling a transport timeout as final burns that idempotency key for good;
    spelling a rejected credential as retryable spends the window forever on a call
    that can never work.
    """

    usage: tuple[UsageFact, ...]
    failure: OperationFailure
    outcome: Literal[EffectOutcome.FAILED] = EffectOutcome.FAILED

    def __post_init__(self) -> None:
        object.__setattr__(self, "usage", _usage(self.usage))


@dataclass(frozen=True, slots=True)
class EffectAmbiguous:
    """The effect may or may not have happened, and this says how to find out.

    The one settlement that is not an ending. It fails closed — the idempotency key is
    not free again — and ``recovery`` is the only thing that says what would release
    it, which is why it is a declared value rather than a guess made later from a
    failure code.
    """

    usage: tuple[UsageFact, ...]
    failure: OperationFailure
    recovery: AmbiguityRecovery

    provider_handle: str
    """The provider-side id a :attr:`AmbiguityRecovery.PROVIDER_QUERY` asks about.

    Empty for every other recovery — a handle nothing will query is noise in a row —
    and legitimately empty for a provider query too. A lease that expires with its
    holder gone leaves an unknown outcome that nobody is left to describe: the ledger
    declares the query, and there is no handle because no worker survived to record
    one. So the law runs one way only, and an operator queries by key and time.
    """

    outcome: Literal[EffectOutcome.AMBIGUOUS] = EffectOutcome.AMBIGUOUS

    def __post_init__(self) -> None:
        object.__setattr__(self, "usage", _usage(self.usage))
        if self.provider_handle and self.recovery is not AmbiguityRecovery.PROVIDER_QUERY:
            raise EffectContractError(
                "only a provider_query recovery names a handle to query: "
                f"{self.recovery.value} with {self.provider_handle!r}"
            )


EffectSettlement: TypeAlias = EffectSucceeded | EffectFailed | EffectAmbiguous
"""Everything a worker may say about a call it made, and nothing else.

Total and tagged by the outcome each one reports, so a settlement and the state it
moves an effect to speak one vocabulary. There is no variant for "still going" — a
lease already says that, and a worker restating it would be reporting its own grant.
"""


def ledger_state(settlement: EffectSettlement) -> EffectState:
    """What the ledger makes of what a worker observed. One total function, one home.

    The only place ambiguity is adjudicated: an unknown outcome that something can
    still answer stays ``ambiguous`` and is reconcilable, and one nothing can answer
    is ``unreconcilable`` — permanent, and the reason that key is never granted again.
    """
    if isinstance(settlement, EffectSucceeded):
        return EffectState.SUCCEEDED
    if isinstance(settlement, EffectFailed):
        return EffectState.FAILED
    if settlement.recovery is AmbiguityRecovery.UNRECONCILABLE:
        return EffectState.UNRECONCILABLE
    return EffectState.AMBIGUOUS


@dataclass(frozen=True, slots=True)
class ProviderLeaseRequest:
    """A worker asking to make exactly one external call.

    ``effects`` is the worker binding itself, not an authority it is granted: it is
    what the ledger applies when the worker never comes back, because a lease that
    expired unsettled is an unknown outcome nobody is left to describe. A read-only
    effect is simply granted again; a provider-idempotent mutation is granted again
    under the same key, which still performs one external mutation; a reconciled
    mutation fails closed and waits to be settled. Declaring the weakest class is
    therefore a worker weakening its own recovery, never widening its reach.
    """

    credential_slot: CredentialSlot
    operation: EffectOperation

    call_budget_s: int
    """How long the external call may take, declared before it is admitted.

    A concurrency slot that frees while the call it admitted is still running is not a
    ceiling — it is a ceiling multiplied by however many times the call outlasts the
    lease. So the ceiling and the call are tied together here: the door refuses a grant
    whose policy TTL does not cover this budget, and the holder must abandon the call
    when it elapses. The second half cannot be enforced from the outside, which is why
    it is stated as an obligation rather than implied by a timeout somewhere.

    **Size the policy at roughly twice this, and here is the honest reason why.** A
    holder enforces its budget by checking elapsed time at whatever boundary it has —
    after a streamed chunk, between retries of a sub-request — so the check lands
    *after* work it had already started. The overshoot is bounded by one such unit,
    which in the worst realistic case is close to the budget itself, and the abandonment
    can take until roughly ``2 * call_budget_s``. So ``lease_ttl_s >= call_budget_s`` is
    what the door can *check*, and it is not by itself a guarantee that the slot
    outlasts the call: a policy sized at ``lease_ttl_s ~= 2 * call_budget_s`` is what
    actually makes the ceiling hold. The check stays at the weaker inequality on
    purpose — tightening it would refuse policies that are fine for callers whose
    boundaries are small, and how much headroom a project wants is the policy owner's
    call, not this contract's.
    """

    idempotency_key: IdempotencyKey
    """The caller's identity for the *mutation* — never for the request, and never
    supplied by whoever asked for the work.

    There is no derivation function here, because what counts as "the same call" is
    known only to the party making it: one worker's is a member digest and a step
    configuration, another's would be a session and a turn. What this contract requires
    instead is the law that makes replay mean anything, and it is a law about the
    *deriving*, not about the bytes:

    * a **total function of the call's own inputs** — so two attempts at one intention
      agree without either knowing the other happened;
    * **stable across processes and restarts** — a key seeded by a clock, a hostname, a
      random value, or a retry counter makes every attempt a new mutation;
    * **derived, never accepted** — a key a caller supplies is a caller choosing which
      of somebody else's effects to replay.

    A worker that satisfies those three gets the promise: one key, one external
    mutation, however many times it asks. One that does not gets a ledger that cannot
    tell a retry from a second call, and no refusal here can rescue it — which is why
    this is written down where both ends read it.
    """

    effects: Effects

    def __post_init__(self) -> None:
        if not str(self.idempotency_key):
            raise EffectContractError("a leased effect is identified by a non-empty key")
        if isinstance(self.call_budget_s, bool) or self.call_budget_s < 1:
            raise EffectContractError(
                f"a call budget is a positive number of seconds: {self.call_budget_s!r}"
            )
        if self.effects is Effects.NONE:
            raise EffectContractError(
                "an effect class of 'none' describes work that makes no external call, "
                "so there is no scarcity to lease"
            )


@dataclass(frozen=True, slots=True)
class RateWindow:
    """The window a grant was counted in, as the ledger measured it at that moment.

    Carried on the grant so a worker can pace itself without a second request, and
    measured rather than configured: ``granted`` includes this lease, so a worker
    holding the last one of a window knows it before it is refused.
    """

    window_s: int
    granted: int
    limit: int

    def __post_init__(self) -> None:
        if self.window_s < 1 or self.limit < 1:
            raise EffectContractError("a rate window has a positive length and ceiling")
        if self.granted < 1 or self.granted > self.limit:
            raise EffectContractError(
                f"a grant is counted within its own window: {self.granted} of {self.limit}"
            )


@dataclass(frozen=True, slots=True)
class ProviderLease:
    """Permission to make one external call, and the scarcity it was taken from.

    One lease per ``(effect_id, attempt)``. It expires, and an expired lease is not a
    freed one: the call it authorized may have happened, so what becomes of it is
    decided by the effect class the request declared, never by the clock alone.
    """

    effect_id: UUID
    provider: ProviderName
    credential_slot: CredentialSlot
    operation: EffectOperation
    idempotency_key: IdempotencyKey
    attempt: int
    window: RateWindow
    outstanding: int
    max_outstanding: int
    expires_at: datetime
    state: Literal[EffectState.LEASED] = EffectState.LEASED

    def __post_init__(self) -> None:
        if isinstance(self.attempt, bool) or self.attempt < 1:
            raise EffectContractError(f"a lease attempt is counted from 1: {self.attempt!r}")
        if self.outstanding < 1 or self.outstanding > self.max_outstanding:
            raise EffectContractError(
                f"a lease is counted among the outstanding: {self.outstanding} "
                f"of {self.max_outstanding}"
            )
        if self.expires_at.tzinfo is None:
            raise EffectContractError("a lease expiry must be timezone-aware")


@dataclass(frozen=True, slots=True)
class ProviderReceipt:
    """One settled external effect: what was leased, and what it turned out to cost.

    The only thing allowed to say what a call cost. ``state`` is not a second spelling
    of ``settlement.outcome`` — it is :func:`ledger_state` of it, and the two differ
    exactly where ambiguity cannot be recovered.
    """

    effect_id: UUID
    provider: ProviderName
    credential_slot: CredentialSlot
    operation: EffectOperation
    idempotency_key: IdempotencyKey
    attempt: int
    settlement: EffectSettlement
    granted_at: datetime
    settled_at: datetime
    state: EffectState

    def __post_init__(self) -> None:
        if self.state is not ledger_state(self.settlement):
            raise EffectContractError(
                f"a {self.settlement.outcome.value} settlement is recorded as "
                f"{ledger_state(self.settlement).value}, not {self.state.value}"
            )
        if self.granted_at.tzinfo is None or self.settled_at.tzinfo is None:
            raise EffectContractError("effect timestamps must be timezone-aware")
        if self.settled_at < self.granted_at:
            raise EffectContractError("an effect cannot settle before it was granted")


ProviderAdmission: TypeAlias = ProviderLease | ProviderReceipt
"""What asking for a lease answers with: permission, or the answer already recorded.

A replayed key gets its original receipt and **no second grant** — that is what makes
provider-idempotent replay perform one external mutation rather than one per attempt.
The two are told apart by ``state``: ``leased`` is the grant, anything else is the
settled fact.

**Which settled keys replay, and which are granted again.** A receipt comes back only
when asking again could not help: a success, and a failure whose
:attr:`OperationFailure.retryable` is false. A *retryable* failure is not an ending —
nothing was mutated, so the next request is granted a fresh attempt, and it passes
every ceiling and the circuit exactly as a first acquisition does. Treating a retryable
failure as terminal was this contract's own bug: it made a worker's first provider
``429`` spend that idempotency key permanently, and turned every retry schedule built
against it into unreachable code.

**Parse it as a plain union.** ``state`` is the discriminator a reader uses, but it is
not a *pydantic* discriminator and cannot become one: a discriminated union needs a
``Literal`` on every member, and the settled side is legitimately four values rather
than one. Tagging it would mean carrying a second field that says only what ``state``
already says, and this package does not keep two spellings of one fact. Nothing is
lost — the two members' required fields are disjoint (a grant has ``window`` and
``expires_at``, a receipt has ``settlement`` and ``settled_at``), so ordinary
validation resolves either one exactly. `tests/test_provider_effect_contract.py` pins
that disjointness, because it is the property doing the work: a field added to one
member that also appears on the other would make the union ambiguous, silently.
"""


@dataclass(frozen=True, slots=True)
class ProviderPolicy:
    """A project's declaration of how much of a provider its key may consume.

    Required. A provider with no policy admits nothing at all, because a ceiling that
    defaults to something is a ceiling nobody chose — which is exactly how the limiter
    this replaces came to enforce one node's worth of a fleet-wide limit.
    """

    provider: ProviderName
    credential_slot: CredentialSlot

    requests_per_window: int
    """How many leases may be granted in one sliding window."""

    window_s: int
    max_outstanding: int
    """How many leases may be outstanding at once — the concurrency ceiling."""

    lease_ttl_s: int
    """How long a grant is good for. Past it the effect's own class decides what its
    unknown outcome becomes."""

    failure_threshold: int
    """Consecutive settlements that did not succeed before the circuit opens."""

    recovery_s: int
    """How long an open circuit refuses before it admits one call again."""

    def __post_init__(self) -> None:
        positive = {
            "requests_per_window": self.requests_per_window,
            "window_s": self.window_s,
            "max_outstanding": self.max_outstanding,
            "lease_ttl_s": self.lease_ttl_s,
            "failure_threshold": self.failure_threshold,
            "recovery_s": self.recovery_s,
        }
        for name, value in positive.items():
            if isinstance(value, bool) or value < 1:
                raise EffectContractError(f"provider policy {name} must be positive: {value!r}")


@dataclass(frozen=True, slots=True)
class CircuitClosed:
    """The provider is answering, and calls are admitted."""

    consecutive_failures: int
    open: Literal[False] = False


@dataclass(frozen=True, slots=True)
class CircuitOpen:
    """The provider stopped answering, and this is the evidence and the deadline."""

    consecutive_failures: int
    opened_at: datetime
    opens_until: datetime
    failure: OperationFailure
    open: Literal[True] = True

    def __post_init__(self) -> None:
        if self.opened_at.tzinfo is None or self.opens_until.tzinfo is None:
            raise EffectContractError("circuit timestamps must be timezone-aware")


ProviderCircuit: TypeAlias = CircuitClosed | CircuitOpen
"""The mutex's own health: open carries why and until when, closed carries neither."""


@dataclass(frozen=True, slots=True)
class ProviderPolicyState:
    """What a project declared about a provider, and what is happening under it."""

    policy: ProviderPolicy
    circuit: ProviderCircuit
    outstanding: int
    granted_in_window: int
