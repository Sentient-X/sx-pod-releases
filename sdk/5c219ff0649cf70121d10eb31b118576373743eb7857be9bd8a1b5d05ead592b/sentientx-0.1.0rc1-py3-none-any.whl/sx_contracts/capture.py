"""Portable capture policy and collector receipts.

The factory writes these records beside captured data; SXD and the catalog read
the same wire shape.  They intentionally contain capture-time facts only. Rich
frame annotations and quality scores remain labeler-owned layers.
"""

from __future__ import annotations

import hashlib
import re
from collections.abc import Callable, Iterator, Mapping
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Literal, NewType, TypeAlias, cast

from sx_contracts import decode
from sx_contracts.content import Sha256Digest
from sx_contracts.identity import JsonValue, ascii_canonical_json, canonical_json
from sx_contracts.ids import EpisodeId
from sx_contracts.outcomes import (
    EpisodeEnd,
    episode_end_from_dict,
    episode_end_to_dict,
)
from sx_contracts.tasks import TaskContractRef, TaskId, TaskSchemaVersion

CaptureSessionId = NewType("CaptureSessionId", str)
CaptureAssignmentId = NewType("CaptureAssignmentId", str)
CollectorId = NewType("CollectorId", str)
CollectorPromptId = NewType("CollectorPromptId", str)
CaptureArtifactUri = NewType("CaptureArtifactUri", str)


class CaptureArtifactFormat(StrEnum):
    """Raw capture byte formats accepted by the Catalog capture boundary."""

    MCAP = "mcap"
    LEROBOT_V3_TAR = "lerobot_v3_tar"
    SIMULATION_JSON = "simulation_json"


class CaptureContractError(ValueError):
    """A capture policy or receipt violates the shared contract.

    A ``ValueError`` so a pydantic door parsing straight into these dataclasses
    rejects a violating body as a 422 instead of crashing the request.
    """


@dataclass(frozen=True, slots=True)
class CaptureArtifactFile:
    """One regular file covered by a sealed raw-artifact manifest."""

    path: str
    sha256: Sha256Digest
    size_bytes: int

    def __post_init__(self) -> None:
        parts = self.path.split("/")
        if (
            not self.path
            or self.path.startswith("/")
            or any(part in {"", ".", ".."} for part in parts)
        ):
            raise CaptureContractError("capture artifact file path must be canonical and relative")
        object.__setattr__(self, "sha256", Sha256Digest(self.sha256))
        if self.size_bytes < 0:
            raise CaptureContractError("capture artifact file size must be non-negative")


@dataclass(frozen=True, slots=True)
class CaptureArtifactManifest:
    """The complete immutable identity of one raw capture artifact.

    The URI of a pod, NAS, drive, or staging copy is deliberately absent: those
    are replicas of these bytes and may change without changing this value.
    """

    format: CaptureArtifactFormat
    sha256: Sha256Digest
    size_bytes: int
    episode_ids: tuple[EpisodeId, ...]
    files: tuple[CaptureArtifactFile, ...]
    schema_version: str = "1"

    def __post_init__(self) -> None:
        if self.schema_version != "1":
            raise CaptureContractError(
                f"unsupported capture artifact manifest version: {self.schema_version}"
            )
        object.__setattr__(self, "sha256", Sha256Digest(self.sha256))
        if self.size_bytes <= 0:
            raise CaptureContractError("capture artifact byte size must be positive")
        if not self.episode_ids or len(set(self.episode_ids)) != len(self.episode_ids):
            raise CaptureContractError(
                "capture artifact episode membership must be non-empty and unique"
            )
        if any(not str(episode_id).strip() for episode_id in self.episode_ids):
            raise CaptureContractError("capture artifact episode ids must be non-blank")
        paths = [item.path for item in self.files]
        if not paths or paths != sorted(paths) or len(paths) != len(set(paths)):
            raise CaptureContractError(
                "capture artifact files must be non-empty, unique, and path-sorted"
            )
        if self.format in {
            CaptureArtifactFormat.MCAP,
            CaptureArtifactFormat.SIMULATION_JSON,
        }:
            if len(self.episode_ids) != 1 or len(self.files) != 1:
                raise CaptureContractError(
                    f"{self.format.value} artifacts must contain exactly one episode file"
                )
            file = self.files[0]
            if file.sha256 != self.sha256 or file.size_bytes != self.size_bytes:
                raise CaptureContractError(
                    "single-file capture manifest must equal the artifact byte identity"
                )
            if self.format is CaptureArtifactFormat.MCAP and file.path != "episode.mcap":
                raise CaptureContractError("MCAP capture artifact file must be named episode.mcap")

    @property
    def canonical_json(self) -> str:
        return canonical_json(capture_artifact_manifest_to_dict(self))

    @property
    def manifest_sha256(self) -> str:
        return hashlib.sha256(self.canonical_json.encode()).hexdigest()


def capture_artifact_manifest_to_dict(
    manifest: CaptureArtifactManifest,
) -> dict[str, JsonValue]:
    """Encode the one canonical raw-artifact manifest wire shape."""

    return {
        "schema_version": manifest.schema_version,
        "format": manifest.format.value,
        "sha256": manifest.sha256,
        "size_bytes": manifest.size_bytes,
        "episode_ids": [str(episode_id) for episode_id in manifest.episode_ids],
        "files": [
            {"path": item.path, "sha256": item.sha256, "size_bytes": item.size_bytes}
            for item in manifest.files
        ],
    }


def capture_artifact_manifest_from_dict(data: object) -> CaptureArtifactManifest:
    """Parse a raw-artifact manifest once and fail closed on every missing fact."""

    value = decode.document(data, where="artifact", error=CaptureContractError)
    try:
        return CaptureArtifactManifest(
            schema_version=decode.text(value, "schema_version"),
            format=CaptureArtifactFormat(decode.text(value, "format")),
            sha256=Sha256Digest(decode.text(value, "sha256")),
            size_bytes=decode.integer(value, "size_bytes"),
            episode_ids=tuple(EpisodeId(item) for item in decode.texts(value, "episode_ids")),
            files=tuple(
                CaptureArtifactFile(
                    path=decode.text(row, "path"),
                    sha256=Sha256Digest(decode.text(row, "sha256")),
                    size_bytes=decode.integer(row, "size_bytes"),
                )
                for row in decode.documents(value, "files")
            ),
        )
    except CaptureContractError:
        raise
    except (TypeError, ValueError) as error:
        raise CaptureContractError(f"invalid capture artifact manifest: {error}") from error


class CaptureAnnotationMode(StrEnum):
    NONE = "none"
    BOUNDARY_HINTS = "boundary_hints"


class CaptureOrderState(StrEnum):
    """Customer-visible lifecycle of one Factory capture order."""

    PENDING = "pending"
    COLLECTING = "collecting"
    QA = "qa"
    DELIVERING = "delivering"
    COMPLETE = "complete"
    CANCELLED = "cancelled"
    FAILED = "failed"


@dataclass(frozen=True, slots=True)
class CaptureProgress(Mapping[str, object]):
    """Typed progress carried by Factory capture operation snapshots.

    The fixed, immutable mapping view lets the shared durable-operation receipt
    carry this value without weakening it back to an open dictionary.
    """

    state: CaptureOrderState
    episodes_target: int
    episodes_completed: int

    def __post_init__(self) -> None:
        if self.episodes_target < 1:
            raise CaptureContractError("capture progress needs a positive episode target")
        if not 0 <= self.episodes_completed <= self.episodes_target:
            raise CaptureContractError(
                "capture progress completed episodes must be within its target"
            )

    def __getitem__(self, key: str) -> object:
        if key == "state":
            return self.state.value
        if key == "episodes_target":
            return self.episodes_target
        if key == "episodes_completed":
            return self.episodes_completed
        raise KeyError(key)

    def __iter__(self) -> Iterator[str]:
        return iter(("state", "episodes_target", "episodes_completed"))

    def __len__(self) -> int:
        return 3


class CollectorPromptScope(StrEnum):
    EPISODE = "episode"
    BATCH = "batch"


# One source per bound: __post_init__ enforces these, and the schema hooks below
# publish exactly them, so a door's OpenAPI cannot drift from what construction rejects.
_PROMPT_ID_PATTERN = r"[a-z][a-z0-9_]*"
_PROMPT_ID = re.compile(_PROMPT_ID_PATTERN)
_PROMPT_ID_MAX_CHARS = 80
_LABEL_MAX_CHARS = 240
_CHOICES_MAX = 20
_ANSWER_MAX_CHARS = 500
_PROMPTS_MAX = 20


def _check_prompt(prompt: CollectorPrompt, kind: str) -> None:
    if prompt.kind != kind:
        raise CaptureContractError(f"{type(prompt).__name__} kind must be {kind!r}")
    if not _PROMPT_ID.fullmatch(prompt.id) or len(prompt.id) > _PROMPT_ID_MAX_CHARS:
        raise CaptureContractError(
            "collector prompt ids are 1-80 characters matching [a-z][a-z0-9_]*"
        )
    if not prompt.label.strip() or len(prompt.label) > _LABEL_MAX_CHARS:
        raise CaptureContractError("collector prompt labels are 1-240 non-blank characters")


def _check_answer(answer: CollectorAnswer, kind: str) -> None:
    if answer.kind != kind:
        raise CaptureContractError(f"{type(answer).__name__} kind must be {kind!r}")
    if not answer.prompt_id:
        raise CaptureContractError("collector answer prompt_id must be non-empty")


def _bound(schema: dict[str, object], field_name: str, **bounds: int | str) -> None:
    properties = cast("dict[str, dict[str, object]]", schema["properties"])
    properties[field_name].update(bounds)


def _prompt_json_schema(schema: dict[str, object]) -> None:
    _bound(
        schema, "id", pattern=f"^{_PROMPT_ID_PATTERN}$", minLength=1, maxLength=_PROMPT_ID_MAX_CHARS
    )
    _bound(schema, "label", minLength=1, maxLength=_LABEL_MAX_CHARS)


def _choice_prompt_json_schema(schema: dict[str, object]) -> None:
    _prompt_json_schema(schema)
    _bound(schema, "choices", minItems=1, maxItems=_CHOICES_MAX)


def _answer_json_schema(schema: dict[str, object]) -> None:
    _bound(schema, "value", minLength=1, maxLength=_ANSWER_MAX_CHARS)


def _policy_json_schema(schema: dict[str, object]) -> None:
    _bound(schema, "prompts", maxItems=_PROMPTS_MAX)


def _wire_config(
    json_schema_extra: Callable[[dict[str, object]], None] | None = None,
) -> dict[str, object]:
    """How a pydantic door parses these dataclasses (`wire.py`'s law, no import needed).

    ``__pydantic_config__`` is a plain attribute pydantic reads when a caller that
    already holds pydantic validates the dataclass: unknown fields fail closed instead
    of being silently dropped, and the ``__post_init__`` bounds appear in the published
    JSON Schema, where a generated client can see them.
    """
    config: dict[str, object] = {"extra": "forbid"}
    if json_schema_extra is not None:
        config["json_schema_extra"] = json_schema_extra
    return config


@dataclass(frozen=True, slots=True)
class BooleanPrompt:
    """A yes/no prompt answered once at its declared scope."""

    id: CollectorPromptId
    label: str
    scope: CollectorPromptScope
    required: bool = True
    # The wire tag is required, never defaulted: a defaulted tag lets a schema-shaped
    # union accept a kind-less document as whichever member matches first.
    kind: Literal["boolean"] = field(kw_only=True)

    __pydantic_config__ = _wire_config(_prompt_json_schema)

    def __post_init__(self) -> None:
        _check_prompt(self, "boolean")


@dataclass(frozen=True, slots=True)
class SingleChoicePrompt:
    """A prompt whose answer must be one member of a closed choice set."""

    id: CollectorPromptId
    label: str
    scope: CollectorPromptScope
    choices: tuple[str, ...]
    required: bool = True
    kind: Literal["single_choice"] = field(kw_only=True)

    __pydantic_config__ = _wire_config(_choice_prompt_json_schema)

    def __post_init__(self) -> None:
        _check_prompt(self, "single_choice")
        if not 1 <= len(self.choices) <= _CHOICES_MAX or any(
            not choice.strip() for choice in self.choices
        ):
            raise CaptureContractError("single-choice prompts need 1-20 non-empty choices")
        if len(set(self.choices)) != len(self.choices):
            raise CaptureContractError("single-choice prompt choices must be unique")


@dataclass(frozen=True, slots=True)
class ShortTextPrompt:
    """A prompt answered with non-blank short text."""

    id: CollectorPromptId
    label: str
    scope: CollectorPromptScope
    required: bool = True
    kind: Literal["short_text"] = field(kw_only=True)

    __pydantic_config__ = _wire_config(_prompt_json_schema)

    def __post_init__(self) -> None:
        _check_prompt(self, "short_text")


CollectorPrompt: TypeAlias = BooleanPrompt | SingleChoicePrompt | ShortTextPrompt


@dataclass(frozen=True, slots=True)
class CapturePolicy:
    annotation_mode: CaptureAnnotationMode = CaptureAnnotationMode.NONE
    prompts: tuple[CollectorPrompt, ...] = ()

    __pydantic_config__ = _wire_config(_policy_json_schema)

    def __post_init__(self) -> None:
        if len(self.prompts) > _PROMPTS_MAX:
            raise CaptureContractError("a capture policy carries at most 20 prompts")
        ids = [prompt.id for prompt in self.prompts]
        if len(set(ids)) != len(ids):
            raise CaptureContractError("collector prompt ids must be unique")


@dataclass(frozen=True, slots=True)
class BooleanAnswer:
    prompt_id: CollectorPromptId
    value: bool
    kind: Literal["boolean"] = field(kw_only=True)

    __pydantic_config__ = _wire_config()

    def __post_init__(self) -> None:
        _check_answer(self, "boolean")


@dataclass(frozen=True, slots=True)
class ChoiceAnswer:
    prompt_id: CollectorPromptId
    value: str
    kind: Literal["choice"] = field(kw_only=True)

    __pydantic_config__ = _wire_config(_answer_json_schema)

    def __post_init__(self) -> None:
        _check_answer(self, "choice")
        if not self.value.strip() or len(self.value) > _ANSWER_MAX_CHARS:
            raise CaptureContractError("choice answers are 1-500 non-blank characters")


@dataclass(frozen=True, slots=True)
class TextAnswer:
    prompt_id: CollectorPromptId
    value: str
    kind: Literal["text"] = field(kw_only=True)

    __pydantic_config__ = _wire_config(_answer_json_schema)

    def __post_init__(self) -> None:
        _check_answer(self, "text")
        if not self.value.strip() or len(self.value) > _ANSWER_MAX_CHARS:
            raise CaptureContractError("text answers are 1-500 non-blank characters")


CollectorAnswer: TypeAlias = BooleanAnswer | ChoiceAnswer | TextAnswer


@dataclass(frozen=True, slots=True)
class SubtaskBoundaryHint:
    step_index: int
    occurrence: int
    recorded_at: datetime

    def __post_init__(self) -> None:
        if self.step_index < 0 or self.occurrence < 0:
            raise CaptureContractError("boundary hint indices must be non-negative")
        if self.recorded_at.tzinfo is None:
            raise CaptureContractError("boundary hint timestamp must be timezone-aware")


@dataclass(frozen=True, slots=True)
class CaptureEpisodeReceipt:
    episode_id: EpisodeId
    source_episode_index: int
    artifact_uri: CaptureArtifactUri
    frame_count: int
    end: EpisodeEnd
    attention: bool = False
    note: str | None = None
    boundary_hints: tuple[SubtaskBoundaryHint, ...] = ()
    answers: tuple[CollectorAnswer, ...] = ()

    def __post_init__(self) -> None:
        if not self.episode_id or not self.artifact_uri:
            raise CaptureContractError("episode and artifact identity must be non-empty")
        if self.source_episode_index < 0 or self.frame_count < 1:
            raise CaptureContractError("source episode index must be non-negative and non-empty")
        if self.note is not None and not self.note.strip():
            raise CaptureContractError("episode notes cannot be blank")


@dataclass(frozen=True, slots=True)
class CaptureSessionReceipt:
    schema_version: str
    session_id: CaptureSessionId
    assignment_id: CaptureAssignmentId
    task: TaskContractRef
    collector_id: CollectorId
    dataset_uri: CaptureArtifactUri
    started_at: datetime
    finalized_at: datetime
    policy: CapturePolicy
    episodes: tuple[CaptureEpisodeReceipt, ...]
    answers: tuple[CollectorAnswer, ...] = ()

    def __post_init__(self) -> None:
        if self.schema_version != "2":
            raise CaptureContractError(
                f"unsupported capture receipt version: {self.schema_version}"
            )
        if not all((self.session_id, self.assignment_id, self.collector_id, self.dataset_uri)):
            raise CaptureContractError("capture receipt identity fields must be non-empty")
        if self.started_at.tzinfo is None or self.finalized_at.tzinfo is None:
            raise CaptureContractError("capture receipt timestamps must be timezone-aware")
        if self.finalized_at < self.started_at:
            raise CaptureContractError("capture receipt cannot finalize before it starts")
        if not self.episodes:
            raise CaptureContractError("a finalized capture receipt needs at least one episode")
        episode_ids = [episode.episode_id for episode in self.episodes]
        source_indices = [episode.source_episode_index for episode in self.episodes]
        if len(set(episode_ids)) != len(episode_ids) or len(set(source_indices)) != len(
            source_indices
        ):
            raise CaptureContractError("episode ids and source indices must be unique in a session")
        prompts = {prompt.id: prompt for prompt in self.policy.prompts}
        self._validate_answers(self.answers, CollectorPromptScope.BATCH, prompts, "batch")
        for episode in self.episodes:
            self._validate_answers(
                episode.answers,
                CollectorPromptScope.EPISODE,
                prompts,
                f"episode {episode.episode_id}",
            )

    @staticmethod
    def _validate_answers(
        answers: tuple[CollectorAnswer, ...],
        scope: CollectorPromptScope,
        prompts: dict[CollectorPromptId, CollectorPrompt],
        label: str,
    ) -> None:
        answer_ids = [answer.prompt_id for answer in answers]
        if len(set(answer_ids)) != len(answer_ids):
            raise CaptureContractError(f"{label} repeats a collector answer")
        for answer in answers:
            prompt = prompts.get(answer.prompt_id)
            if prompt is None:
                raise CaptureContractError(f"{label} answers unknown prompt {answer.prompt_id!r}")
            if prompt.scope is not scope:
                raise CaptureContractError(f"{label} answers a {prompt.scope.value}-scoped prompt")
            if isinstance(prompt, BooleanPrompt) and not isinstance(answer, BooleanAnswer):
                raise CaptureContractError(f"prompt {prompt.id!r} requires a boolean answer")
            if isinstance(prompt, SingleChoicePrompt):
                if not isinstance(answer, ChoiceAnswer):
                    raise CaptureContractError(f"prompt {prompt.id!r} requires a choice answer")
                if answer.value not in prompt.choices:
                    raise CaptureContractError(
                        f"answer {answer.value!r} is not a choice for prompt {prompt.id!r}"
                    )
            if isinstance(prompt, ShortTextPrompt) and not isinstance(answer, TextAnswer):
                raise CaptureContractError(f"prompt {prompt.id!r} requires a text answer")
        required = {
            prompt.id for prompt in prompts.values() if prompt.scope is scope and prompt.required
        }
        missing = required - set(answer_ids)
        if missing:
            raise CaptureContractError(f"{label} lacks required answers: {sorted(missing)}")


@dataclass(frozen=True, slots=True)
class CaptureOrderResult:
    """All sealed session receipts that truthfully complete one capture order.

    Factory scheduling may split one order across several pods. The result therefore
    owns an ordered set of session receipts; treating a single session as the operation
    result would make successful multi-pod work unreadable.
    """

    order_id: str
    session_receipts: tuple[CaptureSessionReceipt, ...]

    def __post_init__(self) -> None:
        if not self.order_id.strip():
            raise CaptureContractError("capture order result needs an order id")
        if not self.session_receipts:
            raise CaptureContractError("capture order result needs at least one session receipt")
        session_ids = tuple(str(receipt.session_id) for receipt in self.session_receipts)
        if len(set(session_ids)) != len(session_ids):
            raise CaptureContractError("capture order result repeats a session receipt")
        if session_ids != tuple(sorted(session_ids)):
            raise CaptureContractError(
                "capture order result receipts must be ordered by session id"
            )


def capture_receipt_to_dict(receipt: CaptureSessionReceipt) -> dict[str, JsonValue]:
    """Encode the one shared JSON wire shape."""

    return {
        "schema_version": receipt.schema_version,
        "session_id": receipt.session_id,
        "assignment_id": receipt.assignment_id,
        "task": {
            "task_id": receipt.task.task_id,
            "schema_version": receipt.task.schema_version,
            "sha256": receipt.task.sha256,
        },
        "collector_id": receipt.collector_id,
        "dataset_uri": receipt.dataset_uri,
        "started_at": receipt.started_at.isoformat(),
        "finalized_at": receipt.finalized_at.isoformat(),
        "policy": capture_policy_to_dict(receipt.policy),
        "episodes": [
            {
                "episode_id": episode.episode_id,
                "source_episode_index": episode.source_episode_index,
                "artifact_uri": episode.artifact_uri,
                "frame_count": episode.frame_count,
                "end": episode_end_to_dict(episode.end),
                "attention": episode.attention,
                "note": episode.note,
                "boundary_hints": [
                    {
                        "step_index": hint.step_index,
                        "occurrence": hint.occurrence,
                        "recorded_at": hint.recorded_at.isoformat(),
                    }
                    for hint in episode.boundary_hints
                ],
                "answers": [collector_answer_to_dict(item) for item in episode.answers],
            }
            for episode in receipt.episodes
        ],
        "answers": [collector_answer_to_dict(item) for item in receipt.answers],
    }


def collector_answer_to_dict(value: CollectorAnswer) -> dict[str, JsonValue]:
    """Encode one collector answer with the vocabulary used inside sealed receipts."""

    return {"kind": value.kind, "prompt_id": value.prompt_id, "value": value.value}


def collector_answer_from_dict(data: object) -> CollectorAnswer:
    """Parse one collector answer, failing closed on unknown kinds and fields."""

    return _answer_from_document(
        decode.document(data, where="collector answer", error=CaptureContractError)
    )


def capture_policy_to_dict(policy: CapturePolicy) -> dict[str, JsonValue]:
    """Encode policy with the same vocabulary used inside sealed receipts."""

    return {
        "annotation_mode": policy.annotation_mode.value,
        "prompts": [_prompt_to_dict(prompt) for prompt in policy.prompts],
    }


def capture_policy_from_dict(data: object) -> CapturePolicy:
    """Parse the sole capture-policy wire shape and reject extra fields."""

    row = decode.document(data, where="capture policy", error=CaptureContractError)
    if set(row) != {"annotation_mode", "prompts"}:
        raise CaptureContractError("capture policy fields are incomplete or unknown")
    try:
        return _policy_from_document(row)
    except CaptureContractError:
        raise
    except (TypeError, ValueError) as error:
        raise CaptureContractError("malformed capture policy") from error


def capture_receipt_sha256(receipt: CaptureSessionReceipt) -> str:
    """Hash the canonical compact JSON representation used by every consumer."""

    # This is the stack's ASCII-escaping canonical form, not the primary one: the digests
    # below are already persisted, so the divergence is named (`ascii_canonical_json`)
    # rather than repaired. See docs/ABSTRACTIONS.md.
    return hashlib.sha256(
        ascii_canonical_json(capture_receipt_to_dict(receipt)).encode()
    ).hexdigest()


def capture_receipt_from_dict(data: object) -> CaptureSessionReceipt:
    """Decode a receipt, failing closed on missing fields and enum values."""

    receipt = decode.document(data, where="capture receipt", error=CaptureContractError)
    try:
        task = decode.mapping(receipt, "task")
        return CaptureSessionReceipt(
            schema_version=decode.text(receipt, "schema_version"),
            session_id=CaptureSessionId(decode.text(receipt, "session_id")),
            assignment_id=CaptureAssignmentId(decode.text(receipt, "assignment_id")),
            task=TaskContractRef(
                task_id=TaskId(decode.text(task, "task_id")),
                schema_version=TaskSchemaVersion(decode.text(task, "schema_version")),
                sha256=Sha256Digest(decode.text(task, "sha256")),
            ),
            collector_id=CollectorId(decode.text(receipt, "collector_id")),
            dataset_uri=CaptureArtifactUri(decode.text(receipt, "dataset_uri")),
            started_at=_timestamp(receipt, "started_at"),
            finalized_at=_timestamp(receipt, "finalized_at"),
            policy=_policy_from_document(decode.mapping(receipt, "policy")),
            episodes=tuple(
                _episode_from_document(row) for row in decode.documents(receipt, "episodes")
            ),
            answers=_answers(receipt, "answers"),
        )
    except CaptureContractError:
        raise
    except (TypeError, ValueError) as error:
        raise CaptureContractError("malformed capture receipt") from error


def _policy_from_document(row: decode.Document) -> CapturePolicy:
    return CapturePolicy(
        annotation_mode=CaptureAnnotationMode(decode.text(row, "annotation_mode")),
        prompts=tuple(_prompt_from_document(value) for value in decode.documents(row, "prompts")),
    )


def _episode_from_document(row: decode.Document) -> CaptureEpisodeReceipt:
    return CaptureEpisodeReceipt(
        episode_id=EpisodeId(decode.text(row, "episode_id")),
        source_episode_index=decode.integer(row, "source_episode_index"),
        artifact_uri=CaptureArtifactUri(decode.text(row, "artifact_uri")),
        frame_count=decode.integer(row, "frame_count"),
        end=episode_end_from_dict(row["end"]),
        attention=decode.boolean(row, "attention"),
        note=decode.optional_text(row, "note"),
        boundary_hints=tuple(
            SubtaskBoundaryHint(
                step_index=decode.integer(hint, "step_index"),
                occurrence=decode.integer(hint, "occurrence"),
                recorded_at=_timestamp(hint, "recorded_at"),
            )
            for hint in decode.documents(row, "boundary_hints")
        ),
        answers=_answers(row, "answers"),
    )


def _answers(doc: decode.Document, key: str) -> tuple[CollectorAnswer, ...]:
    return tuple(_answer_from_document(row) for row in decode.documents(doc, key))


def _answer_from_document(row: decode.Document) -> CollectorAnswer:
    if set(row) != {"kind", "prompt_id", "value"}:
        raise CaptureContractError("collector answer fields are incomplete or unknown")
    prompt_id = CollectorPromptId(decode.text(row, "prompt_id"))
    kind = decode.text(row, "kind")
    if kind == "boolean":
        return BooleanAnswer(prompt_id, decode.boolean(row, "value"), kind="boolean")
    if kind == "choice":
        return ChoiceAnswer(prompt_id, decode.text(row, "value"), kind="choice")
    if kind == "text":
        return TextAnswer(prompt_id, decode.text(row, "value"), kind="text")
    raise CaptureContractError(f"unknown collector answer kind: {kind!r}")


def _prompt_to_dict(prompt: CollectorPrompt) -> dict[str, JsonValue]:
    document: dict[str, JsonValue] = {
        "kind": prompt.kind,
        "id": prompt.id,
        "label": prompt.label,
        "scope": prompt.scope.value,
        "required": prompt.required,
    }
    if isinstance(prompt, SingleChoicePrompt):
        document["choices"] = list(prompt.choices)
    return document


def _prompt_from_document(row: decode.Document) -> CollectorPrompt:
    kind = decode.text(row, "kind")
    common_keys = {"kind", "id", "label", "scope", "required"}
    expected = common_keys | ({"choices"} if kind == "single_choice" else set[str]())
    if set(row) != expected:
        raise CaptureContractError("collector prompt fields are incomplete or unknown")
    prompt_id = CollectorPromptId(decode.text(row, "id"))
    label = decode.text(row, "label")
    scope = CollectorPromptScope(decode.text(row, "scope"))
    required = decode.boolean(row, "required")
    if kind == "boolean":
        return BooleanPrompt(prompt_id, label, scope, required, kind="boolean")
    if kind == "single_choice":
        return SingleChoicePrompt(
            prompt_id, label, scope, decode.texts(row, "choices"), required, kind="single_choice"
        )
    if kind == "short_text":
        return ShortTextPrompt(prompt_id, label, scope, required, kind="short_text")
    raise CaptureContractError(f"unknown collector prompt kind: {kind!r}")


def _timestamp(doc: decode.Document, key: str) -> datetime:
    """An ISO-8601 instant — the one read this package owns beyond the shared kit."""
    raw = decode.text(doc, key)
    try:
        parsed = datetime.fromisoformat(raw)
    except ValueError as error:
        raise CaptureContractError(f"{doc.where}.{key} must be an ISO-8601 timestamp") from error
    if parsed.tzinfo is None:
        raise CaptureContractError(f"{doc.where}.{key} must be timezone-aware")
    return parsed
