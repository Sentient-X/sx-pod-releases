"""Domain scalars stamped onto data by more than one repo.

A ``str`` is text, never a tag; these ``NewType`` wrappers keep identifiers from
bleeding into each other across repo boundaries. Only ids that genuinely cross
repos live here — a rollout's addressable unit and the keys episode data is
attributed by. Repo-local identifiers (policy, ticket, benchmark, …) stay in
their repo's own ``core.types``.

Not shared on purpose: ``StationId`` — auto-perfect indexes stations by fleet position
(``int``), supervisors by deployment name (``str``). Unify deliberately or not
at all; a silent re-typing would corrupt whichever side loses.
"""

from typing import NewType

RolloutId = NewType("RolloutId", str)
"""Identifies one rollout. Rollouts are never mixed: each gets its own buffer directory."""

EpisodeId = NewType("EpisodeId", str)
"""Identifies one episode; the unit outcomes are attributed to."""

CameraName = NewType("CameraName", str)
"""A free-form camera key, for fleets whose camera set is deployment-defined."""

DeploymentGroupRef = NewType("DeploymentGroupRef", str)
"""A governed Fleet group reference carried across qualification and improvement."""
