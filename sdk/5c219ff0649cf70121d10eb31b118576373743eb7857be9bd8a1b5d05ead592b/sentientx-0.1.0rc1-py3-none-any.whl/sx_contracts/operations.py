"""Canonical receipt for durable operations across the four platform pillars."""

from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from enum import StrEnum
from typing import Generic, Literal, NewType, TypeAlias, TypeVar

OperationId = NewType("OperationId", str)
ResourceRef = NewType("ResourceRef", str)
TraceId = NewType("TraceId", str)

UpdateCursor = NewType("UpdateCursor", int)
"""The monotonic durable update cursor: every durable change to an operation
(state transition, cancellation request) advances it, and it never regresses.
A caller pages updates with "everything after cursor N"."""

IdempotencyKey = NewType("IdempotencyKey", str)
"""The caller-supplied admission key. A door pins it to the operation's
immutable input: replaying it answers the same operation, and reusing the same
operation identity under a different key fails closed."""

_ADMISSION_CURSOR = UpdateCursor(0)
"""Where every operation's durable update count starts."""

_EPOCH = datetime(1970, 1, 1, tzinfo=UTC)
OperationProgress: TypeAlias = Mapping[str, object]


class PlatformPillar(StrEnum):
    """The public platform owner of an operation."""

    EXPERIENCE = "experience"
    WORLDS = "worlds"
    AUTONOMY = "autonomy"
    FLEET = "fleet"


class OperationState(StrEnum):
    """The complete, monotonic lifecycle of a durable operation."""

    ACCEPTED = "accepted"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"


class OperationKind(StrEnum):
    """Every durable operation family admitted by the platform.

    The kind is both the persisted discriminator and the second path component of an
    :class:`OperationRef`. Keeping it closed makes an unknown route unreadable instead of
    letting a client discover the mismatch only after sending a request.
    """

    EPISODE_INGEST = "episode-ingest"
    REGISTRATION = "registration"
    BATCH_REGISTRATION = "batch-registration"
    ASSET_REGISTRATION = "asset-registration"
    CAPTURE_REGISTRATION = "capture-registration"
    POLICY_REGISTRATION = "policy-registration"
    TRAINING_CHECKPOINT_REGISTRATION = "training-checkpoint-registration"
    EXPORT_CREDENTIAL_VALIDATION = "export-credential-validation"
    INGEST_CONVERSION = "ingest-conversion"
    PIPELINE_RUN = "pipeline-run"
    EXPORT = "export"
    RETENTION = "retention"
    COMPACTION = "compaction"
    REINDEX = "reindex"
    CAPTURE = "capture"
    EVALUATION = "evaluation"
    GENERATION = "generation"
    SESSION = "session"
    AUTHORING = "authoring"
    TRAINING = "training"
    PROGRAM = "program"
    IMPROVEMENT = "improvement"
    DEPLOYMENT = "deployment"
    ROLLBACK = "rollback"
    RESEARCH = "research"
    WORKLOAD = "workload"


class OperationContractError(ValueError):
    """A durable operation value is incomplete or malformed."""


class OperationKindMismatchError(OperationContractError):
    """A stored operation reference has another runtime result family."""

    def __init__(self, *, expected: OperationKind, actual: OperationKind) -> None:
        self.expected = expected
        self.actual = actual
        super().__init__(
            f"operation kind mismatch: expected {expected.value!r}, got {actual.value!r}"
        )


def operation_timeout_seconds(timeout: timedelta) -> int:
    """Project a positive whole-second Python timeout onto the platform wire."""

    seconds = timeout.total_seconds()
    if seconds <= 0:
        raise OperationContractError("operation timeout must be positive")
    if not seconds.is_integer():
        raise OperationContractError("operation timeout must use whole seconds")
    return int(seconds)


def _require_text(value: str, name: str) -> None:
    if not value.strip():
        raise OperationContractError(f"{name} must not be empty")


# Phantom parameters: neither appears in a field — they type what the *door* hands back
# when this ref is awaited, not anything the ref carries. Covariance is what that means,
# and it is what `parse` needs to widen a reattached ref to `OperationRef[object, object]`.
# Spelled out because the pre-3.11 TypeVar defaults to invariant where PEP 695 inferred it.
ResultT = TypeVar("ResultT", covariant=True)
ProgressT = TypeVar("ProgressT", covariant=True)


@dataclass(frozen=True, slots=True)
class OperationRef(Generic[ResultT, ProgressT]):
    """The compact, serializable route back to one durable operation.

    Pillar x kind x opaque id: the pillar names the public owner, the kind names
    the door family inside it, and the id is that door's own opaque operation
    identity. ``str(ref)`` is the one wire spelling (``pillar/kind/id``) and
    :meth:`parse` reattaches it days later — the id may itself contain ``/``.
    """

    pillar: PlatformPillar
    kind: OperationKind
    operation_id: OperationId

    def __post_init__(self) -> None:
        _require_text(str(self.kind), "operation kind")
        if "/" in str(self.kind):
            raise OperationContractError("operation kind must not contain '/'")
        _require_text(str(self.operation_id), "operation id")

    def __str__(self) -> str:
        return f"{self.pillar.value}/{self.kind.value}/{self.operation_id}"

    @classmethod
    def parse(
        cls,
        text: str,
        *,
        expected: OperationKind | None = None,
    ) -> "OperationRef[object, object]":
        """Reattach a stored ``pillar/kind/id`` spelling, or fail closed."""

        parts = text.split("/", 2)
        if len(parts) != 3:
            raise OperationContractError(f"operation ref must be pillar/kind/id, got {text!r}")
        raw_pillar, kind, operation_id = parts
        try:
            pillar = PlatformPillar(raw_pillar)
        except ValueError as error:
            raise OperationContractError(f"unknown operation pillar: {raw_pillar!r}") from error
        try:
            parsed_kind = OperationKind(kind)
        except ValueError as error:
            raise OperationContractError(f"unknown operation kind: {kind!r}") from error
        if expected is not None and parsed_kind is not expected:
            raise OperationKindMismatchError(expected=expected, actual=parsed_kind)
        return cls(pillar, parsed_kind, OperationId(operation_id))


@dataclass(frozen=True, slots=True)
class CancellationRequest:
    """Cancellation asked for but not yet safely reached.

    A lawful fact on ACCEPTED/RUNNING only — never a sixth lifecycle state. The
    owner honours it at its next safe boundary; the terminal CANCELLED receipt
    then carries this reason.
    """

    reason: str
    requested_at: datetime = _EPOCH

    def __post_init__(self) -> None:
        _require_text(self.reason, "cancellation request reason")
        if self.requested_at.tzinfo is None:
            raise OperationContractError("cancellation request timestamp must be timezone-aware")


def _validate_identity(
    operation_id: OperationId,
    kind: OperationKind,
    resource_ref: ResourceRef,
    trace_id: TraceId,
    cursor: UpdateCursor,
    idempotency_key: IdempotencyKey | None,
    created_at: datetime,
    updated_at: datetime,
) -> None:
    _require_text(str(operation_id), "operation id")
    _require_text(str(kind), "operation kind")
    if "/" in str(kind):
        raise OperationContractError("operation kind must not contain '/'")
    _require_text(str(resource_ref), "resource ref")
    _require_text(str(trace_id), "trace id")
    if int(cursor) < 0:
        raise OperationContractError("update cursor must not be negative")
    if idempotency_key is not None:
        _require_text(str(idempotency_key), "idempotency key")
    if created_at.tzinfo is None or updated_at.tzinfo is None:
        raise OperationContractError("operation timestamps must be timezone-aware")
    if updated_at < created_at:
        raise OperationContractError("operation updated_at cannot precede created_at")


FAILURE_MESSAGE_MAX_CHARS = 4000
"""How long a failure message may be, across every pillar that speaks one.

The number is the wire's: `sentientx.sx.operations.v1.OperationFailure.message`
declares `max_len: 4000`, and a value this vocabulary admitted but no door would
carry is a value that fails at the boundary instead of at its author. So the
ceiling lives here, where the message is constructed, and
`bounded_failure_message` is how an author with an unbounded string — a container's
whole stderr, a stack trace — reaches it on purpose rather than by luck.
"""

_TRUNCATION_MARKER = "… truncated"


def bounded_failure_message(text: str) -> str:
    """Fit an arbitrary diagnostic into one failure message, saying that it was cut.

    Explicit rather than silent, because the cut is the interesting part: a reader
    who cannot tell a complete message from a clipped one will go looking for the
    rest of a sentence that was never sent. The marker is inside the ceiling, so
    the result always fits.
    """

    if len(text) <= FAILURE_MESSAGE_MAX_CHARS:
        return text
    keep = FAILURE_MESSAGE_MAX_CHARS - len(_TRUNCATION_MARKER)
    return text[:keep] + _TRUNCATION_MARKER


@dataclass(frozen=True, slots=True)
class OperationFailure:
    """A terminal failure with an actionable machine code and retry policy."""

    code: str
    message: str
    retryable: bool

    def __post_init__(self) -> None:
        _require_text(self.code, "failure code")
        _require_text(self.message, "failure message")
        if len(self.message) > FAILURE_MESSAGE_MAX_CHARS:
            raise OperationContractError(
                f"a failure message is at most {FAILURE_MESSAGE_MAX_CHARS} characters, "
                f"and this one is {len(self.message)}; an author holding an unbounded "
                "diagnostic passes it through `bounded_failure_message` first"
            )


class _OperationValue:
    """Shared behavior of every receipt without adding a second wire model."""

    operation_id: OperationId
    pillar: PlatformPillar
    kind: OperationKind
    resource_ref: ResourceRef

    @property
    def ref(self) -> OperationRef[object, object]:
        """The one portable handle for status, updates, and cancellation."""

        return OperationRef(self.pillar, self.kind, self.operation_id)


@dataclass(frozen=True, slots=True)
class AcceptedOperation(_OperationValue):
    operation_id: OperationId
    pillar: PlatformPillar
    kind: OperationKind
    resource_ref: ResourceRef
    trace_id: TraceId
    cursor: UpdateCursor = _ADMISSION_CURSOR
    idempotency_key: IdempotencyKey | None = None
    progress: OperationProgress | None = None
    cancellation: CancellationRequest | None = None
    created_at: datetime = _EPOCH
    updated_at: datetime = _EPOCH
    state: Literal[OperationState.ACCEPTED] = field(default=OperationState.ACCEPTED, init=False)

    def __post_init__(self) -> None:
        _validate_identity(
            self.operation_id,
            self.kind,
            self.resource_ref,
            self.trace_id,
            self.cursor,
            self.idempotency_key,
            self.created_at,
            self.updated_at,
        )


@dataclass(frozen=True, slots=True)
class RunningOperation(_OperationValue):
    operation_id: OperationId
    pillar: PlatformPillar
    kind: OperationKind
    resource_ref: ResourceRef
    trace_id: TraceId
    cursor: UpdateCursor = _ADMISSION_CURSOR
    idempotency_key: IdempotencyKey | None = None
    progress: OperationProgress | None = None
    cancellation: CancellationRequest | None = None
    created_at: datetime = _EPOCH
    updated_at: datetime = _EPOCH
    state: Literal[OperationState.RUNNING] = field(default=OperationState.RUNNING, init=False)

    def __post_init__(self) -> None:
        _validate_identity(
            self.operation_id,
            self.kind,
            self.resource_ref,
            self.trace_id,
            self.cursor,
            self.idempotency_key,
            self.created_at,
            self.updated_at,
        )


@dataclass(frozen=True, slots=True)
class SucceededOperation(_OperationValue):
    operation_id: OperationId
    pillar: PlatformPillar
    kind: OperationKind
    resource_ref: ResourceRef
    trace_id: TraceId
    cursor: UpdateCursor = _ADMISSION_CURSOR
    idempotency_key: IdempotencyKey | None = None
    progress: OperationProgress | None = None
    created_at: datetime = _EPOCH
    updated_at: datetime = _EPOCH
    completed_at: datetime = _EPOCH
    state: Literal[OperationState.SUCCEEDED] = field(default=OperationState.SUCCEEDED, init=False)

    def __post_init__(self) -> None:
        _validate_identity(
            self.operation_id,
            self.kind,
            self.resource_ref,
            self.trace_id,
            self.cursor,
            self.idempotency_key,
            self.created_at,
            self.updated_at,
        )
        if not self.created_at <= self.completed_at <= self.updated_at:
            raise OperationContractError("operation completion timestamp is outside its lifetime")


@dataclass(frozen=True, slots=True)
class FailedOperation(_OperationValue):
    operation_id: OperationId
    pillar: PlatformPillar
    kind: OperationKind
    resource_ref: ResourceRef
    trace_id: TraceId
    failure: OperationFailure
    cursor: UpdateCursor = _ADMISSION_CURSOR
    idempotency_key: IdempotencyKey | None = None
    progress: OperationProgress | None = None
    created_at: datetime = _EPOCH
    updated_at: datetime = _EPOCH
    failed_at: datetime = _EPOCH
    state: Literal[OperationState.FAILED] = field(default=OperationState.FAILED, init=False)

    def __post_init__(self) -> None:
        _validate_identity(
            self.operation_id,
            self.kind,
            self.resource_ref,
            self.trace_id,
            self.cursor,
            self.idempotency_key,
            self.created_at,
            self.updated_at,
        )
        if not self.created_at <= self.failed_at <= self.updated_at:
            raise OperationContractError("operation failure timestamp is outside its lifetime")


@dataclass(frozen=True, slots=True)
class CancelledOperation(_OperationValue):
    operation_id: OperationId
    pillar: PlatformPillar
    kind: OperationKind
    resource_ref: ResourceRef
    trace_id: TraceId
    reason: str
    cursor: UpdateCursor = _ADMISSION_CURSOR
    idempotency_key: IdempotencyKey | None = None
    progress: OperationProgress | None = None
    created_at: datetime = _EPOCH
    updated_at: datetime = _EPOCH
    cancelled_at: datetime = _EPOCH
    state: Literal[OperationState.CANCELLED] = field(default=OperationState.CANCELLED, init=False)

    def __post_init__(self) -> None:
        _validate_identity(
            self.operation_id,
            self.kind,
            self.resource_ref,
            self.trace_id,
            self.cursor,
            self.idempotency_key,
            self.created_at,
            self.updated_at,
        )
        _require_text(self.reason, "cancellation reason")
        if not self.created_at <= self.cancelled_at <= self.updated_at:
            raise OperationContractError("operation cancellation timestamp is outside its lifetime")


OperationReceipt: TypeAlias = (
    AcceptedOperation | RunningOperation | SucceededOperation | FailedOperation | CancelledOperation
)
