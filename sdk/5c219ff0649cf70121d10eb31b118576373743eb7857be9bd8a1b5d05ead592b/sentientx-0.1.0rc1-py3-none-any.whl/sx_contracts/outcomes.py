"""The one closed algebra for task verdicts and episode endings."""

from dataclasses import dataclass
from enum import StrEnum
from typing import TypeAlias, cast


class EpisodeUse(StrEnum):
    """The immutable governance purpose assigned when an episode is produced."""

    TRAINING = "training"
    EVALUATION = "evaluation"


class TerminationReason(StrEnum):
    """Why an episode ended. Distinguishes a true terminal state from a truncation.

    A safety violation triggers immediate task failure *and* an automated reset, and serves
    as a source of either termination or truncation (ENPIRE Sec. 2.1, "Hard safety
    constraints").

    ``STOPPED`` and ``POLICY_FAILURE`` are truncations an execution owner declares about
    itself, not verdicts about the task: an operator stop, an expired lease, or an
    exhausted budget ends the episode with motion evidence intact, and a policy that
    fails or falls silent ends it with the arm stopped first. Neither says the task
    failed — a verifier does that, and cannot, so both score as unknown.
    """

    SUCCESS = "success"
    FAILURE = "failure"
    SAFETY_VIOLATION = "safety_violation"
    MAX_STEPS = "max_steps"
    STOPPED = "stopped"
    POLICY_FAILURE = "policy_failure"


class TaskVerdict(StrEnum):
    """What the task's governed verifier concluded."""

    SATISFIED = "satisfied"
    NOT_SATISFIED = "not_satisfied"
    UNKNOWN = "unknown"


class EpisodeEndError(ValueError):
    """An episode ending contradicts the platform's reason/verdict matrix."""


@dataclass(frozen=True, slots=True)
class Terminated:
    """The environment reached a task-terminal state."""

    reason: TerminationReason
    verdict: TaskVerdict

    def __post_init__(self) -> None:
        expected = {
            TerminationReason.SUCCESS: TaskVerdict.SATISFIED,
            TerminationReason.FAILURE: TaskVerdict.NOT_SATISFIED,
            TerminationReason.SAFETY_VIOLATION: TaskVerdict.NOT_SATISFIED,
        }
        if expected.get(self.reason) is not self.verdict:
            raise EpisodeEndError(
                f"terminated {self.reason.value} must have its fixed task verdict"
            )

    @property
    def terminated(self) -> bool:
        return True

    @property
    def truncated(self) -> bool:
        return False


@dataclass(frozen=True, slots=True)
class Truncated:
    """Execution stopped without reaching an ordinary task terminal state."""

    reason: TerminationReason
    verdict: TaskVerdict

    def __post_init__(self) -> None:
        expected = {
            TerminationReason.SAFETY_VIOLATION: TaskVerdict.NOT_SATISFIED,
            TerminationReason.MAX_STEPS: TaskVerdict.NOT_SATISFIED,
            TerminationReason.STOPPED: TaskVerdict.UNKNOWN,
            TerminationReason.POLICY_FAILURE: TaskVerdict.UNKNOWN,
        }
        if expected.get(self.reason) is not self.verdict:
            raise EpisodeEndError(f"truncated {self.reason.value} must have its fixed task verdict")

    @property
    def terminated(self) -> bool:
        return False

    @property
    def truncated(self) -> bool:
        return True


EpisodeEnd: TypeAlias = Terminated | Truncated


@dataclass(frozen=True, slots=True)
class Continuing:
    """A step completed and the episode remains open."""


@dataclass(frozen=True, slots=True)
class Ended:
    """A step completed and closed the episode with these exact terminal facts."""

    end: EpisodeEnd


StepProgress: TypeAlias = Continuing | Ended


def episode_end_to_dict(end: EpisodeEnd) -> dict[str, str]:
    """Encode an episode ending without redundant boolean or outcome fields."""

    return {
        "kind": "terminated" if isinstance(end, Terminated) else "truncated",
        "reason": end.reason.value,
        "verdict": end.verdict.value,
    }


def episode_end_from_dict(value: object) -> EpisodeEnd:
    """Fail-closed inverse of :func:`episode_end_to_dict`."""

    if not isinstance(value, dict):
        raise EpisodeEndError("episode end must be an object")
    fields = cast(dict[str, object], value)
    if set(fields) != {"kind", "reason", "verdict"}:
        raise EpisodeEndError("episode end must contain exactly kind, reason, and verdict")
    kind = fields["kind"]
    reason = fields["reason"]
    verdict = fields["verdict"]
    if not isinstance(kind, str) or not isinstance(reason, str) or not isinstance(verdict, str):
        raise EpisodeEndError("episode end fields must be strings")
    try:
        parsed_reason = TerminationReason(reason)
        parsed_verdict = TaskVerdict(verdict)
    except ValueError as error:
        raise EpisodeEndError("episode end contains an unknown reason or verdict") from error
    if kind == "terminated":
        return Terminated(parsed_reason, parsed_verdict)
    if kind == "truncated":
        return Truncated(parsed_reason, parsed_verdict)
    raise EpisodeEndError(f"unknown episode end kind: {kind!r}")


def step_progress_to_dict(progress: StepProgress) -> dict[str, object]:
    """Encode step progress as one closed alternative."""

    if isinstance(progress, Continuing):
        return {"kind": "continuing"}
    return {"kind": "ended", "end": episode_end_to_dict(progress.end)}


def step_progress_from_dict(value: object) -> StepProgress:
    """Fail-closed inverse of :func:`step_progress_to_dict`."""

    if not isinstance(value, dict):
        raise EpisodeEndError("step progress must be an object")
    fields = cast(dict[str, object], value)
    if fields == {"kind": "continuing"}:
        return Continuing()
    if set(fields) == {"kind", "end"} and fields.get("kind") == "ended":
        return Ended(episode_end_from_dict(fields["end"]))
    raise EpisodeEndError("step progress fields are incomplete or unknown")
