"""Typed capability requirements and exact task-role bindings.

The vocabulary is deliberately about what a component can do, never which robot family it
belongs to. Matching is deterministic and injective: two task roles cannot silently claim the
same physical component.
"""

import json
from collections.abc import Iterable, Iterator
from dataclasses import dataclass
from enum import StrEnum
from typing import Literal, TypeAlias, TypedDict, cast

from sx_contracts.identity import JsonValue, canonical_json
from sx_contracts.wire import WireString

CapabilityPart: TypeAlias = Literal["identifier", "profile", "requirement", "binding"]


class CapabilityError(ValueError):
    """Fail-closed capability and binding rejection.

    ``part`` names which contract part failed: a component or task-role
    ``identifier``, an embodiment capability ``profile``, a task role
    ``requirement``, or a task-to-component ``binding`` (including its canonical
    wire form).
    """

    def __init__(self, part: CapabilityPart, message: str) -> None:
        self.part: CapabilityPart = part
        super().__init__(message)


class UnsatisfiedCapabilityRequirementsError(CapabilityError):
    """No injective component assignment can satisfy every requested task role."""

    def __init__(self, roles: tuple["TaskRoleId", ...]) -> None:
        self.roles = roles
        joined = ", ".join(str(role) for role in roles)
        super().__init__(
            "binding", f"no embodiment component binding satisfies task roles: {joined}"
        )


class ComponentId(WireString):
    """Stable component identity within one embodiment descriptor."""

    def __new__(cls, value: str) -> "ComponentId":
        _validate_identifier("component_id", value)
        return super().__new__(cls, value)


class TaskRoleId(WireString):
    """Task-local semantic role, such as ``manipulation.primary``."""

    def __new__(cls, value: str) -> "TaskRoleId":
        _validate_identifier("task_role_id", value)
        return super().__new__(cls, value)


def _validate_identifier(field: str, value: str) -> None:
    segments = value.split(".")
    if (
        not value
        or any(not segment for segment in segments)
        or any(not segment.replace("_", "").replace("-", "").isalnum() for segment in segments)
    ):
        raise CapabilityError(
            "identifier", f"{field} must be a non-empty dotted identifier, got {value!r}"
        )


class Capability(StrEnum):
    """Closed physical and sensing vocabulary shared by all lifecycle pillars."""

    SPATIAL_MOTION_SE3 = "spatial_motion.se3"
    PLANAR_MOTION_SE2 = "spatial_motion.se2"
    GRASP = "grasp"
    GRASP_PARALLEL = "grasp.parallel"
    GRASP_DEXTEROUS = "grasp.dexterous"
    LOCOMOTION_PLANAR = "locomotion.planar"
    LOCOMOTION_LEGGED = "locomotion.legged"
    SENSING_RGB = "sensing.rgb"
    SENSING_DEPTH = "sensing.depth"
    SENSING_LIDAR = "sensing.lidar"
    SENSING_TACTILE = "sensing.tactile"
    SENSING_FORCE_TORQUE = "sensing.force_torque"


class StandardTaskRole(StrEnum):
    """Canonical role names authored in portable task contracts."""

    MANIPULATION_PRIMARY = "manipulation.primary"
    MANIPULATION_SECONDARY = "manipulation.secondary"
    MOBILITY_BASE = "mobility.base"
    PERCEPTION_PRIMARY = "perception.primary"
    PERCEPTION_SECONDARY = "perception.secondary"


@dataclass(frozen=True, slots=True, init=False)
class CapabilitySet:
    """An order-independent set with a deterministic wire projection."""

    values: frozenset[Capability]

    def __init__(self, values: Iterable[Capability]) -> None:
        object.__setattr__(self, "values", frozenset(values))

    def __iter__(self) -> Iterator[Capability]:
        return iter(self.values)

    def __contains__(self, value: object) -> bool:
        return value in self.values

    def __len__(self) -> int:
        return len(self.values)

    @property
    def ordered(self) -> tuple[Capability, ...]:
        return tuple(sorted(self.values, key=lambda capability: capability.value))

    def issubset(self, other: "CapabilitySet") -> bool:
        return self.values <= other.values


@dataclass(frozen=True, slots=True)
class ComponentCapabilities:
    """Capabilities advertised by one exact component."""

    component_id: ComponentId
    capabilities: CapabilitySet

    def __post_init__(self) -> None:
        if not self.capabilities:
            raise CapabilityError(
                "profile", f"component {self.component_id!r} must advertise at least one capability"
            )

    def satisfies(self, requirement: "TaskRoleRequirement") -> bool:
        return requirement.capabilities.issubset(self.capabilities)


@dataclass(frozen=True, slots=True)
class CapabilityProfile:
    """The complete, ordered capability projection of an embodiment descriptor."""

    components: tuple[ComponentCapabilities, ...]

    def __post_init__(self) -> None:
        ids = tuple(component.component_id for component in self.components)
        if len(set(ids)) != len(ids):
            raise CapabilityError("profile", "capability profile repeats a component id")


@dataclass(frozen=True, slots=True)
class TaskRoleRequirement:
    """Capabilities one semantic role in a task must provide."""

    role_id: TaskRoleId
    capabilities: CapabilitySet

    def __post_init__(self) -> None:
        if not self.capabilities:
            raise CapabilityError(
                "requirement", f"task role {self.role_id!r} must require at least one capability"
            )


@dataclass(frozen=True, slots=True)
class TaskCapabilityRequirements:
    """All embodiment roles required by one task; declaration order is significant."""

    roles: tuple[TaskRoleRequirement, ...]

    def __post_init__(self) -> None:
        if not self.roles:
            raise CapabilityError("requirement", "a task must require at least one embodiment role")
        ids = tuple(role.role_id for role in self.roles)
        if len(set(ids)) != len(ids):
            raise CapabilityError("requirement", "task requirements repeat a role id")


@dataclass(frozen=True, slots=True)
class TaskRoleBinding:
    """One task role bound to one exact embodiment component."""

    role_id: TaskRoleId
    component_id: ComponentId


class TaskRoleBindingWire(TypedDict):
    """The one JSON projection of a task-role assignment at API boundaries."""

    role_id: str
    component_id: str


@dataclass(frozen=True, slots=True)
class TaskRoleAssignments:
    """A unique, injective assignment; complete owners prove semantic compatibility."""

    assignments: tuple[TaskRoleBinding, ...]

    def __post_init__(self) -> None:
        if not self.assignments:
            raise CapabilityError("binding", "binding must assign at least one task role")
        roles = tuple(item.role_id for item in self.assignments)
        components = tuple(item.component_id for item in self.assignments)
        if len(set(roles)) != len(roles):
            raise CapabilityError("binding", "binding repeats a task role")
        if len(set(components)) != len(components):
            raise CapabilityError(
                "binding", "binding assigns one component to more than one task role"
            )


def match_capabilities(
    requirements: TaskCapabilityRequirements,
    profile: CapabilityProfile,
) -> TaskRoleAssignments:
    """Return the first declaration-ordered injective binding, or fail closed."""

    result = _match_role(requirements.roles, profile.components, role_index=0, used=frozenset())
    if result is None:
        unmatched = tuple(
            requirement.role_id
            for requirement in requirements.roles
            if not any(component.satisfies(requirement) for component in profile.components)
        )
        raise UnsatisfiedCapabilityRequirementsError(
            unmatched or tuple(requirement.role_id for requirement in requirements.roles)
        )
    binding = TaskRoleAssignments(result)
    return validate_assignments(requirements, profile, binding)


def _match_role(
    requirements: tuple[TaskRoleRequirement, ...],
    components: tuple[ComponentCapabilities, ...],
    *,
    role_index: int,
    used: frozenset[ComponentId],
) -> tuple[TaskRoleBinding, ...] | None:
    if role_index == len(requirements):
        return ()
    requirement = requirements[role_index]
    for component in components:
        if component.component_id in used or not component.satisfies(requirement):
            continue
        suffix = _match_role(
            requirements,
            components,
            role_index=role_index + 1,
            used=used | {component.component_id},
        )
        if suffix is not None:
            return (TaskRoleBinding(requirement.role_id, component.component_id), *suffix)
    return None


def validate_assignments(
    requirements: TaskCapabilityRequirements,
    profile: CapabilityProfile,
    binding: TaskRoleAssignments,
) -> TaskRoleAssignments:
    """Prove that a supplied binding is total and capability-compatible."""

    requirements_by_role = {requirement.role_id: requirement for requirement in requirements.roles}
    components_by_id = {component.component_id: component for component in profile.components}
    assignment_roles = {assignment.role_id for assignment in binding.assignments}
    if assignment_roles != set(requirements_by_role):
        missing = sorted(set(requirements_by_role) - assignment_roles)
        extra = sorted(assignment_roles - set(requirements_by_role))
        raise CapabilityError(
            "binding", f"binding role set differs: missing={missing}, extra={extra}"
        )
    expected_roles = tuple(requirement.role_id for requirement in requirements.roles)
    actual_roles = tuple(assignment.role_id for assignment in binding.assignments)
    if actual_roles != expected_roles:
        raise CapabilityError(
            "binding",
            f"binding role order differs: expected={expected_roles}, actual={actual_roles}",
        )
    for assignment in binding.assignments:
        component = components_by_id.get(assignment.component_id)
        if component is None:
            raise CapabilityError(
                "binding", f"binding names unknown component {assignment.component_id!r}"
            )
        requirement = requirements_by_role[assignment.role_id]
        if not component.satisfies(requirement):
            raise CapabilityError(
                "binding",
                f"component {component.component_id!r} does not satisfy role "
                f"{requirement.role_id!r}",
            )
    return binding


def task_role_assignments_canonical_json(binding: TaskRoleAssignments) -> str:
    """Deterministic bytes for owners that persist a task-to-embodiment binding."""

    assignments: list[JsonValue] = [
        {"role_id": str(item.role_id), "component_id": str(item.component_id)}
        for item in binding.assignments
    ]
    document: dict[str, JsonValue] = {"assignments": assignments}
    return canonical_json(document)


def task_role_assignments_wire(
    binding: TaskRoleAssignments,
) -> tuple[TaskRoleBindingWire, ...]:
    """Project a domain binding to its shared, typed JSON assignment shape."""

    return tuple(
        TaskRoleBindingWire(
            role_id=str(item.role_id),
            component_id=str(item.component_id),
        )
        for item in binding.assignments
    )


def task_role_assignments_from_canonical_json(data: str) -> TaskRoleAssignments:
    """Parse exact canonical binding bytes and reject alternate or partial documents."""

    try:
        document: object = json.loads(data)
    except json.JSONDecodeError as exc:
        raise CapabilityError("binding", "binding is not valid JSON") from exc
    if not isinstance(document, dict):
        raise CapabilityError("binding", "binding must be an object containing only assignments")
    document_map = cast(dict[object, object], document)
    if set(document_map) != {"assignments"}:
        raise CapabilityError("binding", "binding must be an object containing only assignments")
    raw_assignments = document_map["assignments"]
    if not isinstance(raw_assignments, list):
        raise CapabilityError("binding", "binding assignments must be a list")
    assignments: list[TaskRoleBinding] = []
    for offset, raw in enumerate(cast(list[object], raw_assignments)):
        if not isinstance(raw, dict):
            raise CapabilityError("binding", f"binding assignment {offset} has invalid keys")
        raw_map = cast(dict[object, object], raw)
        if set(raw_map) != {"component_id", "role_id"}:
            raise CapabilityError("binding", f"binding assignment {offset} has invalid keys")
        component_id = raw_map["component_id"]
        role_id = raw_map["role_id"]
        if not isinstance(component_id, str) or not isinstance(role_id, str):
            raise CapabilityError("binding", f"binding assignment {offset} ids must be strings")
        try:
            assignments.append(TaskRoleBinding(TaskRoleId(role_id), ComponentId(component_id)))
        except CapabilityError as exc:
            raise CapabilityError(
                "binding", f"binding assignment {offset} has an invalid identifier"
            ) from exc
    try:
        binding = TaskRoleAssignments(tuple(assignments))
    except CapabilityError as exc:
        raise CapabilityError("binding", f"invalid binding: {exc}") from exc
    if task_role_assignments_canonical_json(binding) != data:
        raise CapabilityError("binding", "binding JSON is not canonical")
    return binding
