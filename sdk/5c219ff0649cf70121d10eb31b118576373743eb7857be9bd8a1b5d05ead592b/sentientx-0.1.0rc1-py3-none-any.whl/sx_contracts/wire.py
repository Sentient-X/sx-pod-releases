"""The validated string-atom kit: one invariant, many domain names.

Letting a door parse straight into the contract types.

Every HTTP boundary in the stack used to re-declare the vocabulary it already
depends on: `DeployablePolicy` exists here, and five repos carried a pydantic
`DeployablePolicyIn`/`Wire` beside it with the same four fields. Not because the
facts differed — because a frozen dataclass cannot validate a request body, and
this package is dependency-free by law, so mirroring was the only way in.

Pydantic can already validate a stdlib dataclass recursively. The only thing it
cannot do is the validated value objects — `Sha256Digest` and its siblings — which
carry their invariant in `__new__` and mean nothing to a schema generator. This
module supplies the one hook that teaches it, so a door can name the contract type
itself and delete its mirror.

The pydantic import lives inside the hook, never at module scope. The law this
package keeps is that it is importable into *any* environment; a hook that only a
caller already holding pydantic can invoke does not change that, and
`tests/test_purity.py` enforces exactly that distinction.

The second thing this module supplies is the *predicates*. A validated string atom
has two parts — what makes it valid, and what it is called — and the stack kept
re-writing the first to get the second. Six types across five packages carried a
byte-identical "64 lowercase hex characters" check, and two more carried the same
lowercase-dotted-identifier regex. `HexDigest` and `DottedIdentifier` state each
invariant once; a domain type subclasses one and supplies only what actually differs,
which is the exception its callers catch and the noun that exception names. A type
whose invariant is genuinely its own subclasses `WireString` directly and keeps its
`__new__` — that is the honest case, not a failure to reuse.
"""

from __future__ import annotations

import inspect
import re
from typing import Any, ClassVar, Self

from sx_contracts.secret import Secret, SecretExposedError

_HEX = frozenset("0123456789abcdef")
_DOTTED = re.compile(r"[a-z][a-z0-9_.-]*")


class WireStringError(ValueError):
    """A string value object does not satisfy its declared invariant."""


class WireString(str):
    """A validated string value object a wire boundary can parse into directly.

    Subclasses keep validating in ``__new__`` — that stays the single definition of
    the invariant. This only makes that constructor reachable from a schema, so an
    invalid digest is rejected at the door with the same error it would raise in
    process.
    """

    __slots__ = ()

    json_pattern: ClassVar[str | None] = None
    """The invariant as a regex, for the schema a door publishes — nothing else reads it.

    A generated client cannot run `__new__`, so without this the OpenAPI says only
    `type: string` and forty pydantic fields restate `Field(pattern=r"^[a-f0-9]{64}$")`
    beside an annotation that already means it. Declared once per predicate, next to the
    predicate, it stays a single source: a subclass that narrows the invariant narrows
    this too, or leaves it `None` and publishes no claim it does not enforce.
    """

    @classmethod
    def __get_pydantic_core_schema__(cls, _source: Any, _handler: Any) -> Any:
        from pydantic_core import core_schema

        # The read and the write schema must be *identical*, not merely equivalent:
        # pydantic splits a component into `Foo-Input`/`Foo-Output` the moment they
        # differ, and a bare `to_string_ser_schema()` drops the pattern the validator
        # carries. That split renames the component in every door's published OpenAPI —
        # a generated-client break for a type whose JSON never changed.
        string = core_schema.str_schema(pattern=cls.json_pattern)
        return core_schema.no_info_after_validator_function(
            cls,
            string,
            serialization=core_schema.plain_serializer_function_ser_schema(
                str, return_schema=string, when_used="json"
            ),
        )


class HexDigest(WireString):
    """A lowercase 64-character SHA-256 digest, whatever it is a digest *of*.

    Subclasses declare the two things that differ between domains::

        class EmbodimentId(HexDigest):
            error = EmbodimentSchemaError
            noun = "embodiment id"

    They do not redeclare the check. An id that is not a digest at all does not
    belong here — it belongs on `WireString` with its own `__new__`.
    """

    __slots__ = ()
    error: ClassVar[type[Exception]] = WireStringError
    noun: ClassVar[str] = "digest"
    json_pattern: ClassVar[str | None] = r"^[a-f0-9]{64}$"

    def __new__(cls, value: str) -> Self:
        if len(value) != 64 or any(char not in _HEX for char in value):
            raise cls.error(f"{cls.noun} must be 64 lowercase hexadecimal characters")
        return super().__new__(cls, value)


class DottedIdentifier(WireString):
    """A lowercase dotted identifier — ``[a-z][a-z0-9_.-]*`` — used as a stable name.

    Subclasses declare `error` and `noun` exactly as for `HexDigest`.
    """

    __slots__ = ()
    error: ClassVar[type[Exception]] = WireStringError
    noun: ClassVar[str] = "identifier"
    json_pattern: ClassVar[str | None] = r"^[a-z][a-z0-9_.-]*$"

    def __new__(cls, value: str) -> Self:
        if _DOTTED.fullmatch(value) is None:
            raise cls.error(f"{cls.noun} must be a lowercase dotted identifier: {value!r}")
        return super().__new__(cls, value)


_REVISIONED = re.compile(r"[a-z][a-z0-9_.-]*/[a-z0-9](?:[a-z0-9_.-]*[a-z0-9])?")


class RevisionedName(WireString):
    """A dotted name carrying its own revision — ``family/revision``.

    The stack already spells contracts this way everywhere it stores one: an episode
    RRD's own metadata says `sx.episode/v8`, a segment row stores it, a pipeline step
    declares what it accepts and produces with it. The two halves are what get read —
    a family decides *whether* two contracts are comparable at all, the revision
    decides *which* — so they are parsed once here instead of re-split at each site.

    The revision is a token, not a number. `v8` is the common spelling but not the
    only lawful one: a customer delivery profile is pinned by month
    (`pi.lerobot-v3/2026-08`), and a scheme that admitted only `vN` would push those
    into a second vocabulary — which is the duplication this type exists to end.
    Ordering revisions is therefore not offered, and nothing needs it: two revisions
    of one family are either the same contract or a migration, whichever way round
    they are compared.

    Subclasses declare `error` and `noun` exactly as for `HexDigest`.
    """

    __slots__ = ()
    error: ClassVar[type[Exception]] = WireStringError
    noun: ClassVar[str] = "revisioned name"
    json_pattern: ClassVar[str | None] = r"^[a-z][a-z0-9_.-]*/[a-z0-9](?:[a-z0-9_.-]*[a-z0-9])?$"

    def __new__(cls, value: str) -> Self:
        if _REVISIONED.fullmatch(value) is None:
            raise cls.error(f"{cls.noun} must be spelled family/revision: {value!r}")
        return super().__new__(cls, value)

    @property
    def family(self) -> str:
        """The part that must match before two revisions are comparable at all."""
        return self.partition("/")[0]

    @property
    def revision(self) -> str:
        return self.partition("/")[2]


def temporal_data_converter() -> Any:
    """The `DataConverter` every Temporal client and worker in the stack must use.

    The second hook, for the same reason as the pydantic one above: a validated string
    atom means nothing to a framework that has not been taught it, and Temporal's default
    is worse than ignorance. `DefaultPayloadConverter` reconstructs a **`str` subclass**
    by iterating it, so a `HexDigest` field round-trips as a *list of one-character
    strings* — and because nothing constructs the type, `__new__` never runs and the
    invariant is never checked. It is silent, it is fail-**open**, and it strikes exactly
    the code that followed the house style.

    This converter is consulted before Temporal's own logic (`value_to_type` tries custom
    converters first), so a field annotated `EmbodimentId` arrives as an `EmbodimentId`
    that has passed its own constructor, and a payload carrying a malformed one is refused
    at the boundary instead of flowing into workflow logic. Enums, plain `str`, and every
    other hint fall through untouched.

    Wire it at **both** ends — `Client.connect(..., data_converter=...)` and the `Worker`'s
    client — because the two directions are converted independently.

    The temporalio import lives inside this function, never at module scope: the law this
    package keeps is that it is importable into any environment, and a hook only callable
    by someone already holding temporalio does not change that. `tests/test_purity.py`
    enforces that distinction for this function by name.
    """
    from temporalio.converter import (
        AdvancedJSONEncoder,
        CompositePayloadConverter,
        DataConverter,
        DefaultPayloadConverter,
        JSONPlainPayloadConverter,
        JSONTypeConverter,
    )

    class _WireStringConverter(JSONTypeConverter):
        def to_typed_value(self, hint: type, value: Any) -> Any:
            if not (inspect.isclass(hint) and issubclass(hint, WireString)):
                return JSONTypeConverter.Unhandled
            if not isinstance(value, str):
                raise TypeError(
                    f"{hint.__name__} expects a JSON string, got {type(value).__name__}"
                )
            # The domain constructor — this is the line that restores the invariant.
            return hint(value)

    class _RefusingEncoder(AdvancedJSONEncoder):
        """Refuse to write a held credential into a workflow payload.

        A workflow history outlives the incident that made anyone read it, so a
        `Secret` reaching this encoder is a boundary mistake, not a formatting one:
        it fails closed here rather than being persisted. Code that means to send a
        credential sends `reveal()`, and says so.
        """

        def default(self, o: Any) -> Any:
            if isinstance(o, Secret):
                raise SecretExposedError(
                    "a Secret may not be serialized into a Temporal payload; "
                    "pass reveal() at the boundary that genuinely needs the value"
                )
            return super().default(o)

    class _Composite(CompositePayloadConverter):
        def __init__(self) -> None:
            super().__init__(
                *(
                    JSONPlainPayloadConverter(
                        encoder=_RefusingEncoder,
                        custom_type_converters=[_WireStringConverter()],
                    )
                    if isinstance(converter, JSONPlainPayloadConverter)
                    else converter
                    for converter in DefaultPayloadConverter().converters.values()
                )
            )

    return DataConverter(payload_converter_class=_Composite)
