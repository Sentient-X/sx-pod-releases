"""One canonical demo ``TaskContract``, parameterised rather than rebuilt.

Every member that handles tasks needs *a* complete valid contract. A ``TaskContract`` is
a large value with real invariants (roles must be unique and non-empty, every plan tuple
non-empty, the goal anchored on real participants), so independently authored "minimal"
ones would be that many chances to encode a contract that could not actually validate —
and they would drift apart the first time an invariant tightened.

So the demo contract lives here, beside the type whose laws it must satisfy, and every
consumer parameterises it (or ``dataclasses.replace``s its specifics) rather than
rebuilding it. This is package data, not test scaffolding: ``sx_worlds.samples`` builds
its demo world over these exact values, and the catalog dev seed publishes its demo
contracts through it; the catalog, factory, catalog-client, and auto-perfect suites
parameterise the same builder. The frozen golden in ``tests/test_tasks.py`` stays
hand-written on purpose — it pins the wire, this module does not.
"""

from __future__ import annotations

from sx_contracts.capabilities import (
    Capability,
    CapabilitySet,
    StandardTaskRole,
    TaskCapabilityRequirements,
    TaskRoleId,
    TaskRoleRequirement,
)
from sx_contracts.tasks import (
    TASK_SCHEMA_VERSION,
    AdaptationKind,
    AtMost,
    Counterparty,
    CountInterval,
    DistractorPlan,
    DiversificationPlan,
    DiversificationScheme,
    EvaluationCriteria,
    EvidenceRelation,
    GoalPredicate,
    InitialPosePlan,
    ObjectHead,
    ObjectMix,
    ObjectRole,
    OperatorTier,
    PlanarDistanceTo,
    ReasoningKind,
    Relation,
    RigId,
    SkillName,
    TaskContract,
    TaskEnvironment,
    TaskFamilyId,
    TaskGoal,
    TaskHorizon,
    TaskId,
    TaskObject,
    TaskpediaCodeRef,
    TaskStationRef,
    TaskStep,
    TaskTemplate,
)

_MANIPULATION_ROLE_IDS = (
    TaskRoleId(StandardTaskRole.MANIPULATION_PRIMARY.value),
    TaskRoleId(StandardTaskRole.MANIPULATION_SECONDARY.value),
)

DEFAULT_TASK_ID = TaskId("pick-place")
DEFAULT_FAMILY = TaskFamilyId("world-samples")
DEFAULT_RIGS = (RigId("piper"),)

DEFAULT_ROLES = (
    TaskRoleRequirement(_MANIPULATION_ROLE_IDS[0], CapabilitySet((Capability.SPATIAL_MOTION_SE3,))),
    TaskRoleRequirement(_MANIPULATION_ROLE_IDS[1], CapabilitySet((Capability.GRASP,))),
)


def manipulation_roles(count: int) -> tuple[TaskRoleRequirement, ...]:
    """``count`` manipulation roles (primary, then secondary) sharing one capability set."""
    if not 1 <= count <= len(_MANIPULATION_ROLE_IDS):
        raise ValueError(
            f"the sample offers {len(_MANIPULATION_ROLE_IDS)} manipulation roles, "
            f"not {count}; build a custom roles tuple instead"
        )
    capabilities = CapabilitySet((Capability.SPATIAL_MOTION_SE3, Capability.GRASP))
    return tuple(
        TaskRoleRequirement(role_id, capabilities) for role_id in _MANIPULATION_ROLE_IDS[:count]
    )


def sample_task(
    *,
    task_id: TaskId = DEFAULT_TASK_ID,
    family: TaskFamilyId = DEFAULT_FAMILY,
    rigs: tuple[RigId, ...] = DEFAULT_RIGS,
    roles: tuple[TaskRoleRequirement, ...] = DEFAULT_ROLES,
    evaluation: EvaluationCriteria | None = None,
) -> TaskContract:
    """The demo pick-and-place contract, gated (promotable) when ``evaluation`` is set."""
    template = TaskTemplate(
        id=task_id,
        name="Pick and place",
        horizon=TaskHorizon.SHORT,
        reasoning=ReasoningKind.SPATIAL,
        rigs=rigs,
        operator=OperatorTier.ANY,
        embodiment=TaskCapabilityRequirements(roles),
        steps=(TaskStep(SkillName("pick")), TaskStep(SkillName("place"))),
        taskpedia_codes=(TaskpediaCodeRef("00-0000.00/1/world", EvidenceRelation.EXACT),),
        objects=(
            TaskObject(
                ObjectRole.FOCUS,
                ObjectHead("box"),
                CountInterval(1, 1),
                ObjectMix.IDENTICAL,
            ),
        ),
        environment=TaskEnvironment((TaskStationRef("bench"),), ("normal",), ("table",)),
        distractors=DistractorPlan("none", "none", "none"),
        initial_poses=InitialPosePlan(("center",), ("ready",)),
        diversification=DiversificationPlan(
            DiversificationScheme.COVERAGE_DESIGN, 4, AdaptationKind.NONE
        ),
        success="box center is within five centimeters of target center",
        goal=TaskGoal(
            Relation.GEOMETRY,
            Counterparty.NONE,
            (GoalPredicate("box", PlanarDistanceTo("target"), AtMost(0.05)),),
        ),
        evaluation=evaluation,
    )
    return TaskContract(TASK_SCHEMA_VERSION, family, template)
