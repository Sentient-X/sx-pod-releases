"""Immutable execution-target facts shared by Train and Fleet.

A target describes the hardware/runtime class qualified together. Per-station health,
free capacity, credentials, and measured calibration remain runtime facts owned by
Fleet; they do not participate in this content identity.
"""

import hashlib
from dataclasses import dataclass
from enum import StrEnum
from typing import NewType, cast

from sx_contracts import decode
from sx_contracts.identity import ascii_canonical_json

StationTargetRef = NewType("StationTargetRef", str)
RuntimeAbi = NewType("RuntimeAbi", str)
PowerMode = NewType("PowerMode", str)


class StationTargetContractError(ValueError):
    """A station target is incomplete or internally inconsistent."""


class CpuArchitecture(StrEnum):
    X86_64 = "x86_64"
    AARCH64 = "aarch64"


class Accelerator(StrEnum):
    RTX_5090 = "rtx_5090"
    DGX_SPARK_GB10 = "dgx_spark_gb10"
    JETSON_THOR_T5000 = "jetson_thor_t5000"
    ROCKCHIP_RK3588_NPU = "rockchip_rk3588_npu"


@dataclass(frozen=True, slots=True)
class StationTarget:
    """One hardware and inference-runtime combination qualified as a unit."""

    cpu: CpuArchitecture
    accelerator: Accelerator
    minimum_memory_mib: int
    runtime_abi: RuntimeAbi
    power_mode: PowerMode

    def __post_init__(self) -> None:
        if self.minimum_memory_mib <= 0:
            raise StationTargetContractError("minimum target memory must be positive")
        if not str(self.runtime_abi).strip():
            raise StationTargetContractError("runtime ABI must not be empty")
        if not str(self.power_mode).strip():
            raise StationTargetContractError("power mode must not be empty")

    @property
    def ref(self) -> StationTargetRef:
        """Content identity derived from every target fact."""
        # This is the stack's ASCII-escaping canonical form, not the primary one: the digests
        # below are already persisted, so the divergence is named (`ascii_canonical_json`)
        # rather than repaired. See docs/ABSTRACTIONS.md.
        canonical = ascii_canonical_json(
            {
                "accelerator": self.accelerator.value,
                "cpu": self.cpu.value,
                "minimum_memory_mib": self.minimum_memory_mib,
                "power_mode": str(self.power_mode),
                "runtime_abi": str(self.runtime_abi),
            }
        )
        return StationTargetRef(f"station-target:{hashlib.sha256(canonical.encode()).hexdigest()}")


def station_target_to_dict(target: StationTarget) -> dict[str, object]:
    """The one wire projection used by Fleet, Train, and station heartbeats."""

    return {
        "cpu": target.cpu.value,
        "accelerator": target.accelerator.value,
        "minimum_memory_mib": target.minimum_memory_mib,
        "runtime_abi": str(target.runtime_abi),
        "power_mode": str(target.power_mode),
    }


def station_target_from_dict(value: object) -> StationTarget:
    """Parse an exact target document and reject stale profile-shaped values."""

    document = decode.document(value, where="station target", error=StationTargetContractError)
    fields = {
        "cpu",
        "accelerator",
        "minimum_memory_mib",
        "runtime_abi",
        "power_mode",
    }
    if set(document) != fields:
        raise StationTargetContractError(
            f"station target has fields {sorted(cast('dict[str, object]', document))}"
        )
    try:
        return StationTarget(
            CpuArchitecture(decode.text(document, "cpu")),
            Accelerator(decode.text(document, "accelerator")),
            decode.integer(document, "minimum_memory_mib"),
            RuntimeAbi(decode.text(document, "runtime_abi")),
            PowerMode(decode.text(document, "power_mode")),
        )
    except ValueError as error:
        raise StationTargetContractError(f"malformed station target: {error}") from error
