"""Immutable, image-bound pipeline graphs.

A :class:`Step` says what one operation accepts and produces, which exact OCI image
supplies its implementation, and what resources it needs. A :class:`Pipeline` composes
those values into a validated DAG. Neither value knows about Temporal, Ray, projects,
buckets, or mutable dataset names.

These are here rather than beside the runner because three parties now speak them and
none of them may import the others: `sx_pipeline` executes a graph, the catalog admits a
plan built from one — proving its schema transitions against a governed snapshot before
anything runs — and the layering law says the catalog never imports a member. A value
spoken across that boundary is cross-repo vocabulary, which is what this package is for.

The split with `sx_pipeline` is the honest one: the *vocabulary* is here, and the
*mechanics* — compiling to a Ray DAG, invoking a container, leasing a runtime — stay
with the runner, because nothing outside it needs to know how a step is made to run.
"""

from __future__ import annotations

import json
import math
import re
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum
from typing import TYPE_CHECKING, Literal, TypeAlias, cast
from uuid import UUID

from sx_contracts.content import Sha256Digest
from sx_contracts.identity import canonical_json, content_digest
from sx_contracts.images import BoundImage, ImageDigest, ImageName
from sx_contracts.operations import OperationFailure, OperationState
from sx_contracts.schemas import SchemaCompatibility, SchemaId

if TYPE_CHECKING:
    from sx_contracts.identity import CanonicalDocument, JsonValue

_NAME = re.compile(r"^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$")
_ENTRYPOINT = re.compile(r"^[A-Za-z_][A-Za-z0-9_.]*:[A-Za-z_][A-Za-z0-9_.]*$")
_ABI = re.compile(r"^[a-z0-9][a-z0-9._+-]*$")


class GraphError(ValueError):
    """A pipeline graph is incomplete or unlawful."""


class DuplicateNameError(GraphError):
    """Two inputs or nodes use the same graph-local name."""


class UnknownDependencyError(GraphError):
    """A node names an input or predecessor that does not exist."""


class CycleError(GraphError):
    """The proposed dependency graph contains a cycle."""


class SchemaEdgeError(GraphError):
    """A producer schema does not satisfy the consuming step."""


@dataclass(frozen=True, slots=True, order=True)
class Resource:
    """One Ray custom-resource claim."""

    name: str
    amount: float

    def __post_init__(self) -> None:
        if not _NAME.fullmatch(self.name):
            raise GraphError(f"resource name is not lowercase and identifier-safe: {self.name!r}")
        if isinstance(self.amount, bool) or not math.isfinite(self.amount) or self.amount <= 0:
            raise GraphError(f"resource amount must be finite and positive: {self.amount!r}")
        object.__setattr__(self, "amount", float(self.amount))


@dataclass(frozen=True, slots=True)
class AcceleratorRequest:
    """One exact accelerator/runtime request for a step.

    A request, not a fact: `sx_contracts.stations.Accelerator` names hardware this
    platform qualifies, and this names what a step needs. The scheduler matches one
    against the other, so they must not share a name.
    """

    kind: str
    ray_resource: str
    count: float
    memory_mib: int
    runtime_abi: str
    exclusive: bool

    def __post_init__(self) -> None:
        if not _NAME.fullmatch(self.kind):
            raise GraphError(f"accelerator kind is not identifier-safe: {self.kind!r}")
        if not _NAME.fullmatch(self.ray_resource):
            raise GraphError(
                f"accelerator ray_resource is not identifier-safe: {self.ray_resource!r}"
            )
        if isinstance(self.count, bool) or not math.isfinite(self.count) or self.count <= 0:
            raise GraphError(f"accelerator count must be finite and positive: {self.count!r}")
        if self.exclusive and not float(self.count).is_integer():
            raise GraphError("an exclusive accelerator request must use a whole count")
        object.__setattr__(self, "count", float(self.count))
        if isinstance(self.memory_mib, bool) or self.memory_mib <= 0:
            raise GraphError("accelerator memory_mib must be positive")
        if not _ABI.fullmatch(self.runtime_abi):
            raise GraphError(
                f"accelerator runtime_abi is not identifier-safe: {self.runtime_abi!r}"
            )


@dataclass(frozen=True, slots=True)
class Resources:
    """The complete schedulable resource request for one step."""

    cpus: float = 1.0
    memory_mib: int = 512
    scratch_mib: int = 0
    accelerator: AcceleratorRequest | None = None
    custom: tuple[Resource, ...] = ()

    def __post_init__(self) -> None:
        if isinstance(self.cpus, bool) or not math.isfinite(self.cpus) or self.cpus <= 0:
            raise GraphError(f"cpus must be finite and positive: {self.cpus!r}")
        object.__setattr__(self, "cpus", float(self.cpus))
        if isinstance(self.memory_mib, bool) or self.memory_mib <= 0:
            raise GraphError(f"memory_mib must be positive: {self.memory_mib!r}")
        if isinstance(self.scratch_mib, bool) or self.scratch_mib < 0:
            raise GraphError(f"scratch_mib must be non-negative: {self.scratch_mib!r}")
        names = [resource.name for resource in self.custom]
        if len(names) != len(set(names)):
            raise GraphError("custom resource names must be unique")
        reserved = {"sx_scratch_mib"}
        if self.accelerator is not None:
            reserved.add(self.accelerator.ray_resource)
        overlap = sorted(reserved & set(names))
        if overlap:
            raise GraphError(f"custom resources duplicate platform resource claims: {overlap}")
        object.__setattr__(self, "custom", tuple(sorted(self.custom)))


def config_json(config: dict[str, JsonValue]) -> str:
    """Freeze typed step configuration in the platform canonical JSON form."""
    return canonical_json(config)


class Partitioning(StrEnum):
    """How one step changes partition boundaries."""

    PARTITION_LOCAL = "partition_local"
    REPARTITIONING = "repartitioning"
    GLOBAL_REDUCTION = "global_reduction"


class Determinism(StrEnum):
    """What repeated execution over identical inputs promises."""

    DETERMINISTIC = "deterministic"
    SEEDED = "seeded"
    NONDETERMINISTIC = "nondeterministic"


class Effects(StrEnum):
    """The complete external-effect class of an implementation."""

    NONE = "none"
    READ_ONLY = "read_only"
    PROVIDER_IDEMPOTENT_MUTATION = "provider_idempotent_mutation"
    RECONCILED_MUTATION = "reconciled_mutation"


class ValidationScope(StrEnum):
    """The governed value a validator evaluates."""

    ITEM = "item"
    DATASET = "dataset"


@dataclass(frozen=True, slots=True)
class Validator:
    """One image-bound acceptance policy over an exact produced schema."""

    name: str
    runtime: BoundImage
    entrypoint: str
    accepts: SchemaId
    report: SchemaId
    scope: ValidationScope
    config_json: str
    resources: Resources

    def __post_init__(self) -> None:
        if not _NAME.fullmatch(self.name):
            raise GraphError(f"validator name is not lowercase and identifier-safe: {self.name!r}")
        _validate_entrypoint(self.entrypoint)
        _validate_config_json(self.config_json)

    @property
    def digest(self) -> Sha256Digest:
        """Content identity of this exact acceptance policy."""
        return content_digest(_validator_document(self))


@dataclass(frozen=True, slots=True)
class Step:
    """One fully bound, reusable operation.

    ``runtime`` is mandatory even for DataFusion and Arrow kernels. Several
    steps may share it; changing its digest deliberately changes each bound
    step's identity.
    """

    name: str
    runtime: BoundImage
    entrypoint: str
    accepts: tuple[SchemaId, ...]
    produces: SchemaId
    config_json: str
    partitioning: Partitioning
    resources: Resources
    determinism: Determinism
    effects: Effects
    validator: Validator

    def __post_init__(self) -> None:
        if not _NAME.fullmatch(self.name):
            raise GraphError(f"step name is not lowercase and identifier-safe: {self.name!r}")
        _validate_entrypoint(self.entrypoint)
        if not self.accepts:
            raise GraphError("a step must accept at least one declared input schema")
        _validate_config_json(self.config_json)
        if self.validator.accepts != self.produces:
            raise GraphError(
                f"step {self.name!r} produces {self.produces} but validator "
                f"{self.validator.name!r} accepts {self.validator.accepts}"
            )

    @property
    def digest(self) -> Sha256Digest:
        """Content identity of this exact operation and executable image."""
        return content_digest(_step_document(self))


def _validate_entrypoint(entrypoint: str) -> None:
    if not _ENTRYPOINT.fullmatch(entrypoint):
        raise GraphError(f"entrypoint must be an importable 'module:function': {entrypoint!r}")


def _validate_config_json(encoded: str) -> None:
    try:
        decoded = cast("object", json.loads(encoded))
    except json.JSONDecodeError as error:
        raise GraphError(f"configuration is not JSON: {error.msg}") from error
    if not isinstance(decoded, dict):
        raise GraphError("configuration must be a JSON object")
    document = cast("CanonicalDocument", decoded)
    if canonical_json(document) != encoded:
        raise GraphError("configuration must use canonical_json(...)")


@dataclass(frozen=True, slots=True)
class PipelineInput:
    """One immutable data input to a graph."""

    name: str
    schema: SchemaId
    digest: Sha256Digest

    def __post_init__(self) -> None:
        if not _NAME.fullmatch(self.name):
            raise GraphError(f"input name is not lowercase and identifier-safe: {self.name!r}")


@dataclass(frozen=True, slots=True)
class Node:
    """One graph-local application of a reusable :class:`Step`."""

    name: str
    step: Step
    after: tuple[str, ...]

    def __post_init__(self) -> None:
        if not _NAME.fullmatch(self.name):
            raise GraphError(f"node name is not lowercase and identifier-safe: {self.name!r}")
        if len(self.after) != len(self.step.accepts):
            raise GraphError(
                f"node {self.name!r} has {len(self.after)} dependencies but "
                f"step {self.step.name!r} accepts {len(self.step.accepts)} inputs"
            )


@dataclass(frozen=True, slots=True)
class Pipeline:
    """A canonical acyclic composition of image-bound steps."""

    inputs: tuple[PipelineInput, ...]
    nodes: tuple[Node, ...] = ()

    def __post_init__(self) -> None:
        if not self.inputs:
            raise GraphError("a pipeline must have at least one immutable input")
        _validate_names(self.inputs, self.nodes)
        ordered = _topological_nodes(self.inputs, self.nodes)
        _validate_schemas(self.inputs, ordered)

    def apply(self, name: str, step: Step, *, after: tuple[str, ...]) -> Pipeline:
        """Return a new graph with ``step`` applied to the named predecessors."""
        return Pipeline(self.inputs, (*self.nodes, Node(name, step, after)))

    def then(self, name: str, step: Step) -> Pipeline:
        """Append to the graph's single current leaf—the ordinary linear call site."""
        leaves = self.leaves
        if len(leaves) != 1:
            raise GraphError(
                f"then() requires exactly one current leaf, found {len(leaves)}; "
                "use apply(..., after=...)"
            )
        return self.apply(name, step, after=leaves)

    def partition(self, members: Mapping[str, Sha256Digest]) -> Pipeline:
        """The same graph over one partition's exact member of each declared input.

        A membership's identity is not any member's identity. The whole graph names the
        snapshot each input resolves to; this names one member of each. Same nodes, same
        step digests, same schema at every edge — only the bytes at the sources move, so
        a partition graph is how the compiler and the runner see exactly one member, and
        no node ever had to learn that partitions exist.

        Its digest is its own, which is the point: work over one member is not work over
        the membership, and two callers naming the same members get the same identity.

        Every declared input must be named. A partition that inherited the membership
        digest for an input it forgot would read the whole snapshot while reporting
        itself as one part of it.
        """
        declared = {item.name for item in self.inputs}
        named = set(members)
        if named != declared:
            raise GraphError(
                "a partition names every declared input exactly once; missing "
                f"{sorted(declared - named)}, unknown {sorted(named - declared)}"
            )
        return Pipeline(
            tuple(
                PipelineInput(item.name, item.schema, members[item.name]) for item in self.inputs
            ),
            self.nodes,
        )

    @property
    def ordered_nodes(self) -> tuple[Node, ...]:
        """Stable topological order, with node names breaking independent ties."""
        return _topological_nodes(self.inputs, self.nodes)

    @property
    def leaves(self) -> tuple[str, ...]:
        """Graph outputs in deterministic name order."""
        consumed = {dependency for node in self.nodes for dependency in node.after}
        candidates = [item.name for item in self.inputs] + [node.name for node in self.nodes]
        return tuple(sorted(name for name in candidates if name not in consumed))

    @property
    def digest(self) -> Sha256Digest:
        """Content identity independent of branch construction order."""
        return content_digest(_pipeline_document(self))


def _validate_names(inputs: tuple[PipelineInput, ...], nodes: tuple[Node, ...]) -> None:
    names = [item.name for item in inputs] + [node.name for node in nodes]
    if len(names) != len(set(names)):
        duplicates = sorted({name for name in names if names.count(name) > 1})
        raise DuplicateNameError(f"graph names must be unique: {duplicates}")


def _topological_nodes(
    inputs: tuple[PipelineInput, ...], nodes: tuple[Node, ...]
) -> tuple[Node, ...]:
    input_names = {item.name for item in inputs}
    by_name = {node.name: node for node in nodes}
    known = input_names | set(by_name)
    for node in nodes:
        for dependency in node.after:
            if dependency not in known:
                raise UnknownDependencyError(
                    f"node {node.name!r} depends on unknown value {dependency!r}"
                )

    remaining = set(by_name)
    available = set(input_names)
    ordered: list[Node] = []
    while remaining:
        ready = sorted(name for name in remaining if set(by_name[name].after).issubset(available))
        if not ready:
            raise CycleError(f"pipeline contains a dependency cycle among {sorted(remaining)}")
        for name in ready:
            ordered.append(by_name[name])
            available.add(name)
            remaining.remove(name)
    return tuple(ordered)


def _validate_schemas(inputs: tuple[PipelineInput, ...], ordered: tuple[Node, ...]) -> None:
    schemas = {item.name: item.schema for item in inputs}
    for node in ordered:
        actual = tuple(schemas[dependency] for dependency in node.after)
        if actual != node.step.accepts:
            raise SchemaEdgeError(
                f"node {node.name!r} expects {[str(schema) for schema in node.step.accepts]} "
                f"but receives {[str(schema) for schema in actual]}"
            )
        schemas[node.name] = node.step.produces


def _resources_document(resources: Resources) -> dict[str, JsonValue]:
    accelerator: JsonValue = None
    if resources.accelerator is not None:
        accelerator = {
            "kind": resources.accelerator.kind,
            "ray_resource": resources.accelerator.ray_resource,
            "count": resources.accelerator.count,
            "memory_mib": resources.accelerator.memory_mib,
            "runtime_abi": resources.accelerator.runtime_abi,
            "exclusive": resources.accelerator.exclusive,
        }
    return {
        "cpus": resources.cpus,
        "memory_mib": resources.memory_mib,
        "scratch_mib": resources.scratch_mib,
        "accelerator": accelerator,
        "custom": [
            {"name": resource.name, "amount": resource.amount} for resource in resources.custom
        ],
    }


def _validator_document(validator: Validator) -> dict[str, JsonValue]:
    config = cast("JsonValue", json.loads(validator.config_json))
    return {
        "name": validator.name,
        "runtime": {"name": str(validator.runtime.name), "digest": str(validator.runtime.digest)},
        "entrypoint": validator.entrypoint,
        "accepts": str(validator.accepts),
        "report": str(validator.report),
        "scope": validator.scope.value,
        "config": config,
        "resources": _resources_document(validator.resources),
    }


def _step_document(step: Step) -> dict[str, JsonValue]:
    config = cast("JsonValue", json.loads(step.config_json))
    return {
        "name": step.name,
        "runtime": {"name": str(step.runtime.name), "digest": str(step.runtime.digest)},
        "entrypoint": step.entrypoint,
        "accepts": [str(schema) for schema in step.accepts],
        "produces": str(step.produces),
        "config": config,
        "partitioning": step.partitioning.value,
        "resources": _resources_document(step.resources),
        "determinism": step.determinism.value,
        "effects": step.effects.value,
        "validator": str(step.validator.digest),
    }


def _pipeline_document(pipeline: Pipeline) -> dict[str, JsonValue]:
    return {
        "inputs": [
            {"name": item.name, "schema": str(item.schema), "digest": str(item.digest)}
            for item in sorted(pipeline.inputs, key=lambda value: value.name)
        ],
        "nodes": [
            {
                "name": node.name,
                "step": str(node.step.digest),
                "after": list(node.after),
            }
            for node in pipeline.ordered_nodes
        ],
    }


def pipeline_json(pipeline: Pipeline) -> str:
    """Encode a complete graph for the isolated Ray driver.

    The graph itself still refers to steps by content identity. The wire carries
    each referenced definition once and verifies that identity again while
    parsing, so no import-name or mutable registry lookup can change execution.
    """
    steps = {str(node.step.digest): node.step for node in pipeline.nodes}
    return canonical_json(
        {
            "schema": "sx.pipeline/v1",
            "inputs": [
                {"name": item.name, "schema": str(item.schema), "digest": str(item.digest)}
                for item in sorted(pipeline.inputs, key=lambda item: item.name)
            ],
            "steps": [
                {
                    "digest": digest,
                    "definition": _step_document(step),
                    "validator": _validator_document(step.validator),
                }
                for digest, step in sorted(steps.items())
            ],
            "nodes": [
                {
                    "name": node.name,
                    "step": str(node.step.digest),
                    "after": list(node.after),
                }
                for node in pipeline.ordered_nodes
            ],
        }
    )


def pipeline_from_json(encoded: str) -> Pipeline:
    """Parse a complete canonical graph and re-prove every content identity."""
    document = _wire_mapping(_wire_document(encoded, "pipeline"), "pipeline")
    _wire_keys(document, {"schema", "inputs", "steps", "nodes"}, "pipeline")
    if _wire_string(document["schema"], "pipeline schema") != "sx.pipeline/v1":
        raise GraphError("unsupported pipeline wire schema")

    inputs = tuple(_wire_input(value) for value in _wire_list(document["inputs"], "inputs"))
    steps: dict[str, Step] = {}
    for value in _wire_list(document["steps"], "steps"):
        entry = _wire_mapping(value, "step entry")
        _wire_keys(entry, {"digest", "definition", "validator"}, "step entry")
        digest = _wire_string(entry["digest"], "step digest")
        if digest in steps:
            raise GraphError(f"duplicate step definition: {digest}")
        step = _wire_step(entry["definition"], entry["validator"])
        if str(step.digest) != digest:
            raise GraphError(f"step definition does not match its content digest: {digest}")
        steps[digest] = step

    nodes: list[Node] = []
    for value in _wire_list(document["nodes"], "nodes"):
        node = _wire_mapping(value, "node")
        _wire_keys(node, {"name", "step", "after"}, "node")
        step_digest = _wire_string(node["step"], "node step digest")
        try:
            step = steps[step_digest]
        except KeyError as error:
            raise GraphError(f"node references an absent step definition: {step_digest}") from error
        nodes.append(
            Node(
                _wire_string(node["name"], "node name"),
                step,
                tuple(
                    _wire_string(item, "node dependency")
                    for item in _wire_list(node["after"], "node dependencies")
                ),
            )
        )
    pipeline = Pipeline(inputs, tuple(nodes))
    if pipeline_json(pipeline) != encoded:
        raise GraphError("pipeline wire is not the one canonical graph representation")
    return pipeline


def validator_json(validator: Validator) -> str:
    """Encode one acceptance policy on its own, for a party that registers it without a graph.

    The same bytes `pipeline_json` embeds per step, and the same bytes `Validator.digest`
    is taken over — a validator carried alone must be the identical document, or the
    digest a registry stores would not be the digest a graph proves.
    """
    return canonical_json(_validator_document(validator))


def validator_from_json(encoded: str) -> Validator:
    """Parse one acceptance policy and re-prove that the wire is its canonical form."""
    validator = _wire_validator(_wire_document(encoded, "validator"))
    if validator_json(validator) != encoded:
        raise GraphError("validator wire is not the one canonical representation")
    return validator


def _wire_input(value: object) -> PipelineInput:
    document = _wire_mapping(value, "pipeline input")
    _wire_keys(document, {"name", "schema", "digest"}, "pipeline input")
    return PipelineInput(
        _wire_string(document["name"], "input name"),
        SchemaId(_wire_string(document["schema"], "input schema")),
        Sha256Digest(_wire_string(document["digest"], "input digest")),
    )


def _wire_step(definition_value: object, validator_value: object) -> Step:
    definition = _wire_mapping(definition_value, "step definition")
    _wire_keys(
        definition,
        {
            "name",
            "runtime",
            "entrypoint",
            "accepts",
            "produces",
            "config",
            "partitioning",
            "resources",
            "determinism",
            "effects",
            "validator",
        },
        "step definition",
    )
    validator = _wire_validator(validator_value)
    if _wire_string(definition["validator"], "validator digest") != str(validator.digest):
        raise GraphError("step definition names a different validator digest")
    return Step(
        name=_wire_string(definition["name"], "step name"),
        runtime=_wire_image(definition["runtime"]),
        entrypoint=_wire_string(definition["entrypoint"], "step entrypoint"),
        accepts=tuple(
            SchemaId(_wire_string(item, "accepted schema"))
            for item in _wire_list(definition["accepts"], "accepted schemas")
        ),
        produces=SchemaId(_wire_string(definition["produces"], "produced schema")),
        config_json=canonical_json(
            cast("CanonicalDocument", _wire_mapping(definition["config"], "step config"))
        ),
        partitioning=Partitioning(_wire_string(definition["partitioning"], "step partitioning")),
        resources=_wire_resources(definition["resources"]),
        determinism=Determinism(_wire_string(definition["determinism"], "step determinism")),
        effects=Effects(_wire_string(definition["effects"], "step effects")),
        validator=validator,
    )


def _wire_validator(value: object) -> Validator:
    document = _wire_mapping(value, "validator definition")
    _wire_keys(
        document,
        {"name", "runtime", "entrypoint", "accepts", "report", "scope", "config", "resources"},
        "validator definition",
    )
    return Validator(
        name=_wire_string(document["name"], "validator name"),
        runtime=_wire_image(document["runtime"]),
        entrypoint=_wire_string(document["entrypoint"], "validator entrypoint"),
        accepts=SchemaId(_wire_string(document["accepts"], "validator schema")),
        report=SchemaId(_wire_string(document["report"], "validator report schema")),
        scope=ValidationScope(_wire_string(document["scope"], "validator scope")),
        config_json=canonical_json(
            cast("CanonicalDocument", _wire_mapping(document["config"], "validator config"))
        ),
        resources=_wire_resources(document["resources"]),
    )


def _wire_image(value: object) -> BoundImage:
    document = _wire_mapping(value, "runtime image")
    _wire_keys(document, {"name", "digest"}, "runtime image")
    return BoundImage(
        ImageName(_wire_string(document["name"], "runtime image name")),
        ImageDigest(_wire_string(document["digest"], "runtime image digest")),
    )


def _wire_resources(value: object) -> Resources:
    document = _wire_mapping(value, "resources")
    _wire_keys(
        document, {"cpus", "memory_mib", "scratch_mib", "accelerator", "custom"}, "resources"
    )
    accelerator_value = document["accelerator"]
    accelerator: AcceleratorRequest | None = None
    if accelerator_value is not None:
        raw = _wire_mapping(accelerator_value, "accelerator")
        _wire_keys(
            raw,
            {"kind", "ray_resource", "count", "memory_mib", "runtime_abi", "exclusive"},
            "accelerator",
        )
        accelerator = AcceleratorRequest(
            kind=_wire_string(raw["kind"], "accelerator kind"),
            ray_resource=_wire_string(raw["ray_resource"], "accelerator resource"),
            count=_wire_number(raw["count"], "accelerator count"),
            memory_mib=_wire_integer(raw["memory_mib"], "accelerator memory"),
            runtime_abi=_wire_string(raw["runtime_abi"], "accelerator runtime ABI"),
            exclusive=_wire_boolean(raw["exclusive"], "accelerator exclusivity"),
        )
    custom: list[Resource] = []
    for value in _wire_list(document["custom"], "custom resources"):
        raw = _wire_mapping(value, "custom resource")
        _wire_keys(raw, {"name", "amount"}, "custom resource")
        custom.append(
            Resource(
                _wire_string(raw["name"], "custom resource name"),
                _wire_number(raw["amount"], "custom resource amount"),
            )
        )
    return Resources(
        cpus=_wire_number(document["cpus"], "cpus"),
        memory_mib=_wire_integer(document["memory_mib"], "memory_mib"),
        scratch_mib=_wire_integer(document["scratch_mib"], "scratch_mib"),
        accelerator=accelerator,
        custom=tuple(custom),
    )


def _wire_document(encoded: str, noun: str) -> CanonicalDocument:
    try:
        value = cast("object", json.loads(encoded))
    except json.JSONDecodeError as error:
        raise GraphError(f"{noun} wire is not JSON: {error.msg}") from error
    if not isinstance(value, (dict, list)):
        raise GraphError(f"{noun} wire must be a JSON object")
    document = cast("CanonicalDocument", value)
    if canonical_json(document) != encoded:
        raise GraphError(f"{noun} wire must use canonical_json(...)")
    return document


def _wire_mapping(value: object, noun: str) -> dict[str, object]:
    if not isinstance(value, dict):
        raise GraphError(f"{noun} must be a JSON object")
    source = cast("dict[object, object]", value)
    if not all(isinstance(key, str) for key in source):
        raise GraphError(f"{noun} keys must be strings")
    return cast("dict[str, object]", source)


def _wire_list(value: object, noun: str) -> list[object]:
    if not isinstance(value, list):
        raise GraphError(f"{noun} must be a JSON array")
    return cast("list[object]", value)


def _wire_keys(document: dict[str, object], expected: set[str], noun: str) -> None:
    if set(document) != expected:
        raise GraphError(
            f"{noun} fields must be exactly {sorted(expected)}, received {sorted(document)}"
        )


def _wire_string(value: object, noun: str) -> str:
    if not isinstance(value, str) or not value:
        raise GraphError(f"{noun} must be a non-empty string")
    return value


def _wire_number(value: object, noun: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise GraphError(f"{noun} must be a number")
    return float(value)


def _wire_integer(value: object, noun: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise GraphError(f"{noun} must be an integer")
    return value


def _wire_boolean(value: object, noun: str) -> bool:
    if not isinstance(value, bool):
        raise GraphError(f"{noun} must be a boolean")
    return value


@dataclass(frozen=True, slots=True)
class PipelinePlan:
    """One project's intention to run an exact graph over exact values.

    Deliberately not a row yet. A plan becomes durable when a run references it, and a
    run is not something this catalog can start — so persisting one now would be a table
    whose only reader is the writer.
    """

    pipeline: Pipeline
    inputs: dict[str, str]
    """Graph input name -> the snapshot entry name it resolves to, here."""

    destination: str

    @property
    def digest(self) -> Sha256Digest:
        """Stable across processes: the graph's own canonical form plus this binding."""
        return content_digest(
            {
                # The graph's own canonical wire, verbatim: its identity is already
                # frozen and re-derived on parse, so a second encoding here would be a
                # second definition of what a graph is.
                "pipeline": pipeline_json(self.pipeline),
                "inputs": dict(sorted(self.inputs.items())),
                "destination": self.destination,
            }
        )


@dataclass(frozen=True, slots=True)
class ResolvedInput:
    """One graph input, and the governed value it was proven to name."""

    input_name: str
    snapshot: str
    schema: SchemaId
    members: int


@dataclass(frozen=True, slots=True)
class PlanStage:
    """One node of an admitted plan, and the contract it promises to produce."""

    node: str
    produces: SchemaId


@dataclass(frozen=True, slots=True)
class AdmittedPlan:
    """What validation learned, in the order a caller wants to read it.

    `explain` is this and nothing more, which is what keeps it bounded: the node order
    and the schema at each edge come from the graph itself, and the inputs cost one row
    apiece. Nothing here grows with a membership.
    """

    digest: Sha256Digest
    inputs: tuple[ResolvedInput, ...]
    stages: tuple[PlanStage, ...]
    produces: SchemaId
    destination: str
    outlet: SchemaCompatibility


# ── running one ──────────────────────────────────────────────────────────────
#
# Three parties speak what follows and none may import the others: the catalog
# admits a run and starts it, the executor executes it and says how it went, and
# Temporal carries one value between them. So the wire lives here — the queue's
# name, the workflow's name, what the start carries, and the closed vocabulary a
# report may use — while both ends keep their own mechanics.

PIPELINE_RUN_WORKFLOW = "SxPipelineRun"
"""The Temporal workflow type that owns one run's durable envelope.

A name rather than a class, because the party that *starts* it is not the party
that implements it: the catalog holds the truth and may not import the executor.
Temporal resolves a workflow by this exact string, so changing it strands every
history already written under the old one.
"""

PIPELINE_RUN_TASK_QUEUE = "sx-pipeline-runs"
"""The one queue the `sx_pipeline` run worker polls.

That worker, not the legacy `sxd` one: `sxd-main` belongs to the fixed-stage episode
workflow this substrate replaces, and pointing new runs at it would give a retiring
import root a fresh obligation. The name follows the queue convention every other
member already uses (`sx-catalog`, `sx-catalog-exports`) — the distribution, then
what it serves.

One queue rather than a family of them, because heterogeneity is Ray's business
beneath the run and not Temporal's. The catalog stamps this onto the run at
admission instead of reading it at start time: a queue renamed in configuration
must not orphan work already accepted.
"""


class RunPhase(StrEnum):
    """Where a *running* run has got to.

    Deliberately not more operation states. `OperationState` is the lifecycle every
    pillar shares and it stays five values; this is the live detail underneath one of
    them, and it exists only while the state is ``running`` — an accepted or settled
    run carrying a phase would be reporting liveness it does not have.

    Blocked work is not a phase either. Partitions waiting on capacity, a provider
    limit, or a retry backoff are facts about that work; a run with anything still
    runnable is ``executing``.
    """

    PLANNING = "planning"
    WAITING_FOR_CAPACITY = "waiting_for_capacity"
    EXECUTING = "executing"
    VALIDATING = "validating"
    PUBLISHING = "publishing"
    CANCELLING = "cancelling"


@dataclass(frozen=True, slots=True)
class PipelineRunSubmission:
    """Everything Temporal carries from the catalog to the executor: an identity.

    Not the plan. The graph, its resolved inputs and its destination are already
    durable in the catalog under ``plan_digest``, and a workflow history is a bad
    place to keep a value that must not drift from the one that was admitted — so
    the executor fetches it back through the door, under its own credential, and
    gets exactly what was admitted or nothing.

    ``project_id`` is the authority the catalog stamped, never anything a caller
    supplied: the executor needs it to select the project its credential is acting
    in. It widens nothing — a credential without a binding there is still refused.
    """

    run_id: UUID
    project_id: UUID
    plan_digest: Sha256Digest


@dataclass(frozen=True, slots=True)
class RunProgress:
    """The executor reached a new phase and is still running."""

    phase: RunPhase
    state: Literal[OperationState.RUNNING] = OperationState.RUNNING


@dataclass(frozen=True, slots=True)
class RunPublished:
    """The run finished and this snapshot is what it published.

    A success names its output, because a run that succeeded without publishing one
    is a run whose result nobody can read. The catalog checks the snapshot is one of
    the destination's own before it believes this.
    """

    snapshot_id: UUID
    state: Literal[OperationState.SUCCEEDED] = OperationState.SUCCEEDED


@dataclass(frozen=True, slots=True)
class RunFailed:
    """The run failed, with the code and retry policy a caller acts on."""

    failure: OperationFailure
    state: Literal[OperationState.FAILED] = OperationState.FAILED


@dataclass(frozen=True, slots=True)
class RunCancelled:
    """Execution converged on a cancellation, and stopped here."""

    reason: str
    state: Literal[OperationState.CANCELLED] = OperationState.CANCELLED


RunReport: TypeAlias = RunProgress | RunPublished | RunFailed | RunCancelled
"""The complete set of things an executor may say about a run it holds.

Tagged by the state each one moves the run to, so the report and the receipt speak
one vocabulary, and total: every variant carries exactly what its state requires and
nothing it does not. There is no variant for ``accepted`` — admission is the
catalog's act, and an executor claiming it would be reporting its own creation.
"""


# ── leasing one partition ────────────────────────────────────────────────────
#
# A run is one value; a partition is where the work actually is. What follows is
# the three things said about one partition across the same boundary: what the
# worker offers before it is given any, what the catalog hands it to make it
# runnable, and what it offers back. The graph a leased worker executes is
# `Pipeline.partition(...)` above — these values carry the authority and the
# outcome around it, never a second copy of it.


class Scarcity(StrEnum):
    """What a worker can fall short of. One member per axis :class:`Resources` declares.

    Closed, and it is the *scheduling* reading of a declaration billing also reads:
    `sx_contracts.usage.reserved_quantities` turns the same `Resources` into meters.
    Scheduling and billing both retain accelerator class: scheduling matches this axis,
    while `usage.accelerator_meter` embeds its kind in the billed meter.
    """

    CPUS = "cpus"
    MEMORY_MIB = "memory_mib"
    SCRATCH_MIB = "scratch_mib"
    ACCELERATOR = "accelerator"
    ACCELERATOR_MEMORY_MIB = "accelerator.memory_mib"
    CUSTOM = "custom"


_PLATFORM_SCARCITY = frozenset({Scarcity.CPUS, Scarcity.MEMORY_MIB, Scarcity.SCRATCH_MIB})


@dataclass(frozen=True, slots=True, order=True)
class Shortfall:
    """One scarce thing a step needs more of than a worker offers.

    A deficit by construction — ``needed`` above ``offered`` — so a shortfall cannot
    be constructed for a resource that fits. What it names is in ``name``: the axis's
    own spelling for the three platform axes, the accelerator's *kind* for the two
    accelerator ones, and the declared resource's own name for a custom one, which is
    also the name `usage.custom_meter` bills it under.
    """

    scarcity: Scarcity
    name: str
    needed: float
    offered: float

    def __post_init__(self) -> None:
        if not _NAME.fullmatch(self.name):
            raise GraphError(f"shortfall name is not identifier-safe: {self.name!r}")
        if self.scarcity in _PLATFORM_SCARCITY and self.name != self.scarcity.value:
            raise GraphError(
                f"a {self.scarcity.value} shortfall names that axis, not {self.name!r}"
            )
        if isinstance(self.needed, bool) or not math.isfinite(self.needed) or self.needed <= 0:
            raise GraphError(f"a shortfall needs a finite positive amount: {self.needed!r}")
        if isinstance(self.offered, bool) or not math.isfinite(self.offered) or self.offered < 0:
            raise GraphError(f"a shortfall offers a finite non-negative amount: {self.offered!r}")
        if self.needed <= self.offered:
            raise GraphError(
                f"{self.name!r} is not short: {self.needed} needed, {self.offered} offered"
            )
        object.__setattr__(self, "needed", float(self.needed))
        object.__setattr__(self, "offered", float(self.offered))

    def __str__(self) -> str:
        return f"{self.name} ({self.scarcity.value}): needs {self.needed}, offers {self.offered}"


@dataclass(frozen=True, slots=True, order=True)
class AcceleratorCapacity:
    """One accelerator class a worker supplies, answering one :class:`AcceleratorRequest`.

    Every field a request states except ``exclusive``, which is not a property of the
    hardware: it says whether a *step* will share the device, and nothing a worker can
    advertise answers it.
    """

    kind: str
    ray_resource: str
    count: float
    memory_mib: int
    runtime_abi: str

    def __post_init__(self) -> None:
        if not _NAME.fullmatch(self.kind):
            raise GraphError(f"accelerator kind is not identifier-safe: {self.kind!r}")
        if not _NAME.fullmatch(self.ray_resource):
            raise GraphError(
                f"accelerator ray_resource is not identifier-safe: {self.ray_resource!r}"
            )
        if isinstance(self.count, bool) or not math.isfinite(self.count) or self.count <= 0:
            raise GraphError(f"an offered accelerator count is positive: {self.count!r}")
        object.__setattr__(self, "count", float(self.count))
        if isinstance(self.memory_mib, bool) or self.memory_mib <= 0:
            raise GraphError(f"an offered accelerator has memory: {self.memory_mib!r}")
        if not _ABI.fullmatch(self.runtime_abi):
            raise GraphError(
                f"accelerator runtime_abi is not identifier-safe: {self.runtime_abi!r}"
            )


@dataclass(frozen=True, slots=True)
class Capacity:
    """What one worker can supply, in the vocabulary a step asks in.

    The other side of :class:`Resources`, field for field: a reservation is what a
    step *needs* and a capacity is what a machine *has*, so the match between them
    is arithmetic rather than interpretation. There is exactly one declaration of
    scarcity in this platform — the step's — and this is the only thing entitled to
    answer it. The claim carries one because the alternative is a door handing a
    partition to a machine that cannot run it: the worker then burns metered
    reservation time (`usage.reserved_quantities` bills the *declaration*, not what
    the worker managed to do) and fails, and the project is charged for a placement
    the platform got wrong.

    Several accelerator classes, because a real node can hold more than one and a
    partition executes a whole graph on one worker — a two-accelerator graph is
    schedulable exactly where both classes are.
    """

    cpus: float
    memory_mib: int
    scratch_mib: int = 0
    accelerators: tuple[AcceleratorCapacity, ...] = ()
    custom: tuple[Resource, ...] = ()

    def __post_init__(self) -> None:
        if isinstance(self.cpus, bool) or not math.isfinite(self.cpus) or self.cpus <= 0:
            raise GraphError(f"offered cpus must be finite and positive: {self.cpus!r}")
        object.__setattr__(self, "cpus", float(self.cpus))
        if isinstance(self.memory_mib, bool) or self.memory_mib <= 0:
            raise GraphError(f"offered memory_mib must be positive: {self.memory_mib!r}")
        if isinstance(self.scratch_mib, bool) or self.scratch_mib < 0:
            raise GraphError(f"offered scratch_mib must be non-negative: {self.scratch_mib!r}")
        classes = [(item.ray_resource, item.runtime_abi) for item in self.accelerators]
        if len(classes) != len(set(classes)):
            raise GraphError("an offered accelerator class is advertised once")
        names = [resource.name for resource in self.custom]
        if len(names) != len(set(names)):
            raise GraphError("offered custom resource names must be unique")
        object.__setattr__(
            self,
            "accelerators",
            tuple(
                sorted(self.accelerators, key=lambda item: (item.ray_resource, item.runtime_abi))
            ),
        )
        object.__setattr__(self, "custom", tuple(sorted(self.custom)))

    def unmet(self, needed: Resources) -> tuple[Shortfall, ...]:
        """Everything this worker is short of for one step. Empty means it can run it.

        Total over :class:`Resources`: every field a step may declare is answered
        here, so a field added there is a match this refuses to compile rather than
        one it silently stops enforcing.

        ``exclusive`` is deliberately not read, and it is the one thing this predicate
        does not prove. A worker is leased one partition at a time by this door, but
        nothing here knows what *else* is running on the machine underneath it — that
        is the Ray placement conjunction's question, and answering it from a
        self-reported capacity would be a guarantee made out of a claim.
        """
        missing: list[Shortfall] = []
        if needed.cpus > self.cpus:
            missing.append(Shortfall(Scarcity.CPUS, "cpus", needed.cpus, self.cpus))
        if needed.memory_mib > self.memory_mib:
            missing.append(
                Shortfall(Scarcity.MEMORY_MIB, "memory_mib", needed.memory_mib, self.memory_mib)
            )
        if needed.scratch_mib > self.scratch_mib:
            missing.append(
                Shortfall(Scarcity.SCRATCH_MIB, "scratch_mib", needed.scratch_mib, self.scratch_mib)
            )
        missing.extend(self._unmet_accelerator(needed.accelerator))
        supplied = {resource.name: resource.amount for resource in self.custom}
        missing.extend(
            Shortfall(
                Scarcity.CUSTOM, resource.name, resource.amount, supplied.get(resource.name, 0.0)
            )
            for resource in needed.custom
            if resource.amount > supplied.get(resource.name, 0.0)
        )
        return tuple(sorted(missing))

    def _unmet_accelerator(self, request: AcceleratorRequest | None) -> tuple[Shortfall, ...]:
        """The class this request names, or the whole request as the deficit.

        Kind, Ray resource and runtime ABI are matched exactly and together: a device
        of the right kind reached under another resource name is not the one Ray will
        place against, and one that cannot run the requested ABI cannot run the image.
        None of the three is a quantity, so failing any of them is short of the whole
        request rather than of some of it.
        """
        if request is None:
            return ()
        offered = next(
            (
                item
                for item in self.accelerators
                if item.kind == request.kind
                and item.ray_resource == request.ray_resource
                and item.runtime_abi == request.runtime_abi
            ),
            None,
        )
        if offered is None:
            return (Shortfall(Scarcity.ACCELERATOR, request.kind, request.count, 0.0),)
        short: list[Shortfall] = []
        if request.count > offered.count:
            short.append(
                Shortfall(Scarcity.ACCELERATOR, request.kind, request.count, offered.count)
            )
        if request.memory_mib > offered.memory_mib:
            short.append(
                Shortfall(
                    Scarcity.ACCELERATOR_MEMORY_MIB,
                    request.kind,
                    request.memory_mib,
                    offered.memory_mib,
                )
            )
        return tuple(short)

    @property
    def digest(self) -> Sha256Digest:
        """Content identity of exactly this offer — how two identical workers are one row."""
        return content_digest(capacity_document(self))


def unschedulable(capacity: Capacity, pipeline: Pipeline) -> tuple[Shortfall, ...]:
    """What this worker lacks for the *graph*; empty means it can run one partition of it.

    A partition executes the whole graph over one member on one worker, so what has to
    be available is every step's declaration — the same reading
    `sx_catalog.server.usage.partition_quantities` bills, taken per axis instead of
    per meter, and reported as the largest deficit on each axis rather than the sum,
    which would be short of capacity nobody holds at once.

    A graph with no steps still needs the platform's own default reservation: a worker
    claims, fetches, judges and offers a member, and `Resources()` is what billing
    already charges for that, so it is what scheduling asks for too.
    """
    declared = [node.step.resources for node in pipeline.nodes] or [Resources()]
    worst: dict[tuple[Scarcity, str], Shortfall] = {}
    for resources in declared:
        for short in capacity.unmet(resources):
            key = (short.scarcity, short.name)
            standing = worst.get(key)
            if standing is None or short.needed > standing.needed:
                worst[key] = short
    return tuple(sorted(worst.values()))


def capacity_document(capacity: Capacity) -> dict[str, JsonValue]:
    """What a worker offered, as the one rendering that is stored and digested.

    Public, unlike the documents above it, because an offer is *kept*: the catalog
    records the ones it refused so an operator can see what has asked, and a stored
    value read back by a second rendering would be a second wire.
    """
    return {
        "cpus": capacity.cpus,
        "memory_mib": capacity.memory_mib,
        "scratch_mib": capacity.scratch_mib,
        "accelerators": [
            {
                "kind": item.kind,
                "ray_resource": item.ray_resource,
                "count": item.count,
                "memory_mib": item.memory_mib,
                "runtime_abi": item.runtime_abi,
            }
            for item in capacity.accelerators
        ],
        "custom": [
            {"name": resource.name, "amount": resource.amount} for resource in capacity.custom
        ],
    }


def capacity_from_document(value: object) -> Capacity:
    """Read back an offer stored as :func:`capacity_document`, or refuse it by name."""
    document = _wire_mapping(value, "capacity")
    _wire_keys(
        document, {"cpus", "memory_mib", "scratch_mib", "accelerators", "custom"}, "capacity"
    )
    accelerators: list[AcceleratorCapacity] = []
    for item in _wire_list(document["accelerators"], "offered accelerators"):
        raw = _wire_mapping(item, "offered accelerator")
        _wire_keys(
            raw,
            {"kind", "ray_resource", "count", "memory_mib", "runtime_abi"},
            "offered accelerator",
        )
        accelerators.append(
            AcceleratorCapacity(
                kind=_wire_string(raw["kind"], "accelerator kind"),
                ray_resource=_wire_string(raw["ray_resource"], "accelerator resource"),
                count=_wire_number(raw["count"], "accelerator count"),
                memory_mib=_wire_integer(raw["memory_mib"], "accelerator memory"),
                runtime_abi=_wire_string(raw["runtime_abi"], "accelerator runtime ABI"),
            )
        )
    custom: list[Resource] = []
    for item in _wire_list(document["custom"], "offered custom resources"):
        raw = _wire_mapping(item, "offered custom resource")
        _wire_keys(raw, {"name", "amount"}, "offered custom resource")
        custom.append(
            Resource(
                _wire_string(raw["name"], "custom resource name"),
                _wire_number(raw["amount"], "custom resource amount"),
            )
        )
    return Capacity(
        cpus=_wire_number(document["cpus"], "cpus"),
        memory_mib=_wire_integer(document["memory_mib"], "memory_mib"),
        scratch_mib=_wire_integer(document["scratch_mib"], "scratch_mib"),
        accelerators=tuple(accelerators),
        custom=tuple(custom),
    )


@dataclass(frozen=True, slots=True)
class LeasedObject:
    """One exact immutable object this lease authorizes, and nothing else.

    Bytes named by digest rather than by prefix: a worker cannot enumerate what it was
    not given, and an authority phrased as a location would widen the moment that
    location gained a sibling. ``input_name`` says which declared graph input these
    bytes are the member of, so a step reads its arguments under the names its own
    graph already uses.
    """

    input_name: str
    schema: SchemaId
    sha256: Sha256Digest
    size_bytes: int
    url: str

    def __post_init__(self) -> None:
        if not _NAME.fullmatch(self.input_name):
            raise GraphError(
                f"leased input name is not lowercase and identifier-safe: {self.input_name!r}"
            )
        if isinstance(self.size_bytes, bool) or self.size_bytes <= 0:
            raise GraphError(f"a leased object must have a positive size: {self.size_bytes!r}")
        if not self.url:
            raise GraphError("a leased object must carry the URL it is read from")


@dataclass(frozen=True, slots=True)
class WorkLease:
    """Scheduling ownership and execution capability as one value.

    Not two. A worker holding an assignment and fetching its authority separately would
    have a window in which it owns work it may not read, and a second value to keep in
    step with the first. One lease says which partition is yours, which exact objects
    you may read, where the result is staged, and until when.

    **Unsigned by design.** Nothing verifies a lease without calling the catalog: the
    object store verifies the presign it was handed, and the door verifies the
    generation when a receipt arrives. A signature here would be a proof no reader
    checks — it lands when a verifier that is not the catalog exists, and cross-project
    cache dedupe is that verifier, unbuilt.

    One lease per ``(run, ordinal, generation)``. Custody is who may hold one, never how
    many exist: a stolen partition is a *new* generation, so the displaced holder finds
    its receipt refused rather than racing the new holder to write.
    """

    run_id: UUID
    project_id: UUID
    plan_digest: Sha256Digest
    ordinal: int
    generation: int
    attempt: int
    inputs: tuple[LeasedObject, ...]
    output_url: str
    output_max_bytes: int
    report_url: str
    """Where the validator's own report is staged, beside the member it judged.

    A second location rather than a second call: the acceptance policy runs in the
    same leased attempt as the step, and a worker that had to ask for somewhere to put
    its verdict would be able to produce a member it never offered a verdict for. One
    lease, both places, so the pair is inseparable by construction.
    """

    expires_at: datetime

    def __post_init__(self) -> None:
        _validate_partition_identity(self.ordinal, self.generation)
        if isinstance(self.attempt, bool) or self.attempt < 1:
            raise GraphError(f"a lease attempt is counted from 1: {self.attempt!r}")
        if not self.inputs:
            raise GraphError("a lease authorizing no object authorizes no work")
        leased = [(item.input_name, str(item.sha256)) for item in self.inputs]
        if len(set(leased)) != len(leased):
            raise GraphError("a lease names each authorized object once")
        if not self.output_url:
            raise GraphError("a lease must name where the partition's output is staged")
        if not self.report_url:
            raise GraphError("a lease must name where the partition's report is staged")
        if self.report_url == self.output_url:
            raise GraphError("a member and the report that judges it are not the same object")
        if isinstance(self.output_max_bytes, bool) or self.output_max_bytes <= 0:
            raise GraphError(f"a lease output ceiling must be positive: {self.output_max_bytes!r}")
        if self.expires_at.tzinfo is None:
            raise GraphError("a lease expiry must be timezone-aware")


@dataclass(frozen=True, slots=True)
class ProducedMember:
    """What one partition produced, offered for admission.

    Identity only. Every judgement — that the staged bytes hash to this, that they are
    this large, what physical schema they turn out to have — is re-derived catalog-side
    with the catalog's own per-family reader. A producer that could *state* its schema
    could state one it does not have, and the point of a governed dataset is that its
    layout is found rather than declared. The contract this member is admitted against
    is not claimed here either: it is ``produces`` of the admitted plan's terminal step,
    which the catalog already holds.

    What a worker knows and the catalog cannot re-derive is which pinned procedure ran
    and what that procedure emitted — so those two, and nothing else here, are facts
    rather than claims.
    """

    ordinal: int
    generation: int
    sha256: Sha256Digest
    size_bytes: int

    validator_digest: Sha256Digest
    """Which acceptance policy ran: a :attr:`Validator.digest`, checked against the
    binding the admitted plan registered for this step."""

    report_sha256: Sha256Digest
    """The ``sx.validation-report/v1`` artifact that policy emitted."""

    def __post_init__(self) -> None:
        _validate_partition_identity(self.ordinal, self.generation)
        if isinstance(self.size_bytes, bool) or self.size_bytes <= 0:
            raise GraphError(f"a produced member must have a positive size: {self.size_bytes!r}")


@dataclass(frozen=True, slots=True)
class PartitionFailed:
    """One partition ended without a member, and why.

    :class:`OperationFailure`, not a failure type of its own: a partition failing is the
    same event as an operation failing — an actionable code and whether trying again
    could help — and a second vocabulary for it would leave a door translating between
    two spellings of ``retryable``.
    """

    ordinal: int
    generation: int
    failure: OperationFailure

    def __post_init__(self) -> None:
        _validate_partition_identity(self.ordinal, self.generation)


def _validate_partition_identity(ordinal: int, generation: int) -> None:
    """The two numbers that say which partition attempt is speaking.

    The ordinal indexes the run's partitions from zero. The fencing generation counts
    from one, so that "never leased" and "leased once" are not the same number.
    """
    if isinstance(ordinal, bool) or ordinal < 0:
        raise GraphError(f"a partition ordinal is a non-negative index: {ordinal!r}")
    if isinstance(generation, bool) or generation < 1:
        raise GraphError(f"a fencing generation is counted from 1: {generation!r}")
