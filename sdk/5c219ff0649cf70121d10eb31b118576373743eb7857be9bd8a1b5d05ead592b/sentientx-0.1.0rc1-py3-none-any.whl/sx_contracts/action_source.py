"""Action provenance and data-buffer routing.

Every executed transition carries an :class:`ActionSource` label; downstream
training mixes data by routing that label to a buffer (RLPD-style data mixing,
ENPIRE Appendix B.5). This module is the single definition of both the label
set and the routing.

Reconciliation note: `enpire` originally used {RL, HUMAN, MANUAL} over two
buffers; `supervisors` used {POLICY, HEURISTIC_OVERRIDE, AGENT, HUMAN_TELEOP}
over three. The union keeps supervisors' finer intervention taxonomy and
enpire's scripted-demonstration source (SCRIPTED, né MANUAL) — a scripted demo
is collection-time data, not a supervision intervention, so it is not a
HEURISTIC_OVERRIDE.
"""

from enum import StrEnum


class ActionSource(StrEnum):
    """Who ultimately produced the executed action — the label data routing keys on."""

    POLICY = "policy"
    """The autonomous policy under training/deployment (was `enpire.ActionSource.RL`)."""
    HEURISTIC_OVERRIDE = "heuristic_override"
    """An L0/L1 supervision layer clipped or replaced the action."""
    AGENT = "agent"
    """An L2 agentic supervisor intervened."""
    HUMAN_TELEOP = "human_teleop"
    """A human teleoperator took over (was `enpire.ActionSource.HUMAN`)."""
    SCRIPTED = "scripted"
    """A scripted routine produced demonstration data (was `enpire.ActionSource.MANUAL`)."""
    SIM_AUGMENTED = "sim_augmented"
    """Simulation-generated data derived from real seed trajectories by Worlds ``datagen``.
    This labels **data lineage**, not a supervision intervention: an augmented
    episode trains like a demonstration but stays distinguishable from real captures on the
    wire, so generated and real data are never mixed indistinguishably. Routed to
    :attr:`DatasetKind.DEMO` for now; a dedicated ``DatasetKind.SIM`` is a later additive
    change if a trainer wants a separate mixing ratio."""


class DatasetKind(StrEnum):
    """The three data buffers downstream training mixes from."""

    ONLINE = "online"
    """Autonomous policy transitions (on-policy / replay)."""
    CORRECTION = "correction"
    """Automatic overrides (heuristic clips, agent interventions)."""
    DEMO = "demo"
    """Demonstrations — human teleop segments or scripted routines."""


class BufferKind(StrEnum):
    """The two-buffer RLPD view: demo transitions are mixed into each online batch.

    A projection of :class:`DatasetKind` for consumers (auto-perfect's PLD-RL tier)
    that mix corrections and demonstrations into one demo buffer.
    """

    ONLINE = "online"
    DEMO = "demo"


def dataset_for_source(source: ActionSource) -> DatasetKind:
    """Route an executed action's transitions to the buffer downstream training reads.

    Autonomous transitions go online, automatic overrides become corrections,
    and human teleop, scripted routines, or sim-augmented data become demonstrations.
    """
    match source:
        case ActionSource.POLICY:
            return DatasetKind.ONLINE
        case ActionSource.HEURISTIC_OVERRIDE | ActionSource.AGENT:
            return DatasetKind.CORRECTION
        case ActionSource.HUMAN_TELEOP | ActionSource.SCRIPTED | ActionSource.SIM_AUGMENTED:
            return DatasetKind.DEMO


def buffer_for_dataset(dataset: DatasetKind) -> BufferKind:
    """Collapse the three-buffer taxonomy onto RLPD's two: corrections count as demos."""
    match dataset:
        case DatasetKind.ONLINE:
            return BufferKind.ONLINE
        case DatasetKind.CORRECTION | DatasetKind.DEMO:
            return BufferKind.DEMO
