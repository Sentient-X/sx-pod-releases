"""What an agent may decide, what it is told back, and what the runtime published to decide on.

Three languages used to say this: the native crate emitted free text, the policy runtime routed
a union it defined itself, and the rigid executor typed the subset it could run. One vocabulary
now owns all of it, here, in the package every side already depends on. The runtime routes it,
the executor executes the rigid half, and the crate mirrors it on the wire.

A decision reaches an executor as a **tagged command**, never as a sentence. Upstream found that
free text handed to a detector primes it to hallucinate the target, and the runtime contract
independently forbids scraping model prose into control state. So free text lives in exactly one
variant — :class:`Vla`, where it *is* the prompt — and nowhere else. Not one of the rigid
commands has a field an invented object could be written into: a :class:`TargetRef` can only
echo an id the runtime published in a :class:`PublishedScene`.

:class:`Pick` and :class:`Place` are the verified split. :class:`Transfer` is the same work as
one open-loop primitive — upstream's control, kept as a first-class command so the two arms of
an ablation are two commands rather than one code path with a boolean in it. ``Transfer`` is a
lawful decision and is deliberately **not** a wire variant: the scripted ablation issues it, and
an agent cannot, which is why it has no ``to_wire``.

The answer to a decision is a :class:`DecisionReceipt`, and it is deliberately **not** a
:class:`GoalVerificationReceipt`. The inner agent's engine treats a satisfied goal verification
as *completing the active goal*; routing a grasp verdict through that channel would either be
rejected for naming a different objective or, worse, silently declare the task done because the
jaws closed on something. A ``DecisionReceipt`` says whether the jaws closed; a
``GoalVerificationReceipt`` says whether the task is done. The vocabulary hosts both and must
never merge them: an executor verdict verifies an executor's own precondition, so it comes back
on its own decision-scoped channel, structurally incapable of completing anything.

One decision holds control at a time — except when the spine takes it. :class:`Preemption` is
a suspension the decision comes back from, distinct from both ordinary replanning and a timed-out
decision boundary. It exists as a value because a reflex is a third writer to the actuators, and
a third writer nobody can name is the subtlest bug a control runtime can have.

:class:`NotSatisfiedReason` is a closed set on purpose. "The agent re-decides" is only useful if
what it re-decides on is a value it can branch over — a prose ``detail`` string carries the same
information in a form nothing can dispatch on, so the detail rides *alongside* the reason and
never instead of it.

Wire values here are a data contract shared with the Rust crate; changing one is a breaking
change that must fail closed, never reroute silently.
"""

from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from typing import Final, Literal, NewType, TypeVar, cast

from sx_contracts import decode
from sx_contracts.content import Sha256Digest
from sx_contracts.identity import canonical_json
from sx_contracts.outcomes import TaskVerdict
from sx_contracts.wire import WireString

IO_SCHEMA: Final = "sx.inner-agent.io/v6"
"""The agent-runtime input/event wire this vocabulary is the Python half of.

Defined here because the schema id belongs with the vocabulary it names, not with one client.
``sx_runtime.inner_agent`` imports this constant rather than carrying its own, and the crate
mirrors it as ``IoSchema::V6``; the two are held together by the conformance fixtures rather
than by anyone remembering to change both.
"""

GOAL_VERIFICATION_SCHEMA: Final = "sx.inner-agent.goal-verification/v3"
"""The goal-verification receipt schema, unchanged: the crate and the Worlds session door
already emit exactly these fields under exactly this label."""

GoalVerificationSchema = Literal["sx.inner-agent.goal-verification/v3"]
"""The type of :data:`GOAL_VERIFICATION_SCHEMA`, so a pydantic door can pin it without
re-typing the string."""

SPAN_SCHEMA: Final = "sx.decision-spans/v1"
"""The decision-span sidecar schema. Every decision produces spans by the identical path —
a VLA subgoal as much as a rigid command — so the label names no single executor."""

SCENE_FACT_KEY: Final = "sx.scene"
"""The reserved observation fact key carrying the :class:`PublishedScene`."""

RECEIPT_FACT_KEY: Final = "sx.receipt"
"""The reserved observation fact key carrying the last :class:`DecisionReceipt`."""

REFLEX_FACT_KEY: Final = "sx.reflex"
"""The reserved observation fact key carrying the :class:`Preemption`s the spine took.

A list, because several hazards can come and go between two decision boundaries, and the
agent replans against all of them or against a world it misreads. It rides the same
observation-facts channel as the two keys above at the same ``io/v6`` schema: a fact is a
JSON value under a reserved key, and a new reserved key is not a new wire."""


ALARM_FACT_KEY: Final = "sx.alarm"
"""The reserved observation fact key carrying the calibrated alarm that opened this boundary.

Same channel and same ``io/v6`` schema as the three keys above. It carries the monitor's
name, its score, and the threshold that score crossed, because "you are being asked again
early" is a different question from "you are being asked again early, and this is how far
outside the nominal envelope the run has drifted"."""


class DecisionError(ValueError):
    """A decision, replan interval, receipt, or published scene is not well formed."""


class SpanError(ValueError):
    """A span cannot be recorded for this decision."""


class DecisionId(WireString):
    """The agent's handle for one subgoal; a retry is a new decision, not a new attempt."""

    __slots__ = ()

    def __new__(cls, value: str) -> "DecisionId":
        if not value.strip() or any(character.isspace() for character in value):
            raise DecisionError(f"decision id must be non-empty and unbroken: {value!r}")
        return str.__new__(cls, value)


InstanceId = NewType("InstanceId", str)
"""A runtime-issued name for one grounded object, unique within its snapshot."""

ObservationSequence = NewType("ObservationSequence", int)
"""Which perception a snapshot came from; monotone within one episode."""


@dataclass(frozen=True, slots=True)
class TargetRef:
    """A decision's only way to point at an object: echo an id the runtime issued."""

    observation_sequence: ObservationSequence
    instance: InstanceId

    def to_wire(self) -> dict[str, object]:
        return {
            "observation_sequence": int(self.observation_sequence),
            "instance": str(self.instance),
        }


class PlacementMode(StrEnum):
    """How a place ends — the two cases that differ in *where* the jaws open."""

    ON_SURFACE = "on_surface"
    """Descend until the object is a clearance above the destination, then release."""
    IN_CONTAINER = "in_container"
    """Release from above the rim; the object falls the rest of the way."""


@dataclass(frozen=True, slots=True)
class ReplanInterval:
    """The fixed policy-level cadence for replacing a running decision."""

    chunks: int
    wall_ms: int

    def __post_init__(self) -> None:
        if self.chunks < 1:
            raise DecisionError("a replan interval must include at least one chunk")
        if self.wall_ms < 1:
            raise DecisionError("a replan interval must include at least one millisecond")

    def to_wire(self) -> dict[str, int]:
        return {"chunks": self.chunks, "wall_ms": self.wall_ms}


class DecisionKind(StrEnum):
    """The ``kind`` tag one decision travels under — the closed vocabulary, and the wire type.

    Every wire that names decision variants names them with these values: the ``kind`` field
    each :meth:`to_wire` renders, the tag :func:`parse_subgoal_command` dispatches on, and the
    set a native inner-agent bundle declares it admits — which its runtime publishes on the
    io/v6 status so the seat reads what that endpoint will offer instead of maintaining a
    second list. One vocabulary, so a deployment cannot spell its capability two ways.

    :class:`Transfer` has no member, because it has no wire form at all: it is the script-only
    open-loop control, and an agent cannot ask for the ungated primitive.
    """

    VLA = "vla"
    PICK = "pick"
    PLACE = "place"

    @property
    def decision(self) -> "type[Decision]":
        """The variant this tag names — the one map between the wire and the union."""
        return _DECISION_BY_KIND[self]


@dataclass(frozen=True, slots=True)
class Vla:
    """Hand control to the VLA under one short-horizon instruction.

    A VLA subgoal has no receipt: nothing inside the runtime can verify it, so its span closes
    as still-running when a replacement takes over or the episode ends. The policy-level
    :class:`ReplanInterval`, not this decision, determines when to request that replacement.
    """

    decision_id: DecisionId
    instruction: str

    def __post_init__(self) -> None:
        if not self.instruction.strip():
            raise DecisionError("a VLA subgoal needs a non-empty instruction")

    def to_wire(self) -> dict[str, object]:
        return {
            "kind": DecisionKind.VLA.value,
            "decision_id": str(self.decision_id),
            "instruction": self.instruction,
        }


@dataclass(frozen=True, slots=True)
class Pick:
    """Take the named object. Ends held, lifted, and verified — or not satisfied."""

    decision_id: DecisionId
    target: TargetRef

    def to_wire(self) -> dict[str, object]:
        return {
            "kind": DecisionKind.PICK.value,
            "decision_id": str(self.decision_id),
            "target": self.target.to_wire(),
        }


@dataclass(frozen=True, slots=True)
class Place:
    """Put what is held at the named destination. Refused unless a grasp is confirmed."""

    decision_id: DecisionId
    target: TargetRef
    mode: PlacementMode

    def to_wire(self) -> dict[str, object]:
        return {
            "kind": DecisionKind.PLACE.value,
            "decision_id": str(self.decision_id),
            "target": self.target.to_wire(),
            "mode": self.mode.value,
        }


@dataclass(frozen=True, slots=True)
class Transfer:
    """Take the named object to the named destination as **one open-loop primitive**.

    Upstream's TiPToP arm, and the control the verified split is measured against: a grasp and
    a release with nothing able to say no in between, so "a slip or mislocalized grasp can lead
    to failure" (arXiv:2607.21725 Section 5.3). It is a distinct command rather than a flag on
    :class:`Pick` because that is what it is — a different primitive with different guarantees,
    and a flag would make the two arms of an ablation one code path with a boolean.

    Nothing here is gated: a transfer takes no aperture reading, so no verdict exists to gate on
    and none is faked. It is the honest control — and it is the one command with no wire form,
    because only a script issues it. An agent cannot ask for the ungated primitive.
    """

    decision_id: DecisionId
    target: TargetRef
    destination: TargetRef
    mode: PlacementMode


RigidCommand = Pick | Place | Transfer
"""What the rigid executor executes. The VLA variant is not here: an executor never sees an
instruction string, so it cannot be talked into acting on one."""

Decision = Vla | Pick | Place | Transfer
"""The complete union a deployable policy routes on. Free text exists only in :class:`Vla`."""

_DECISION_BY_KIND: Final[Mapping[DecisionKind, type[Decision]]] = {
    DecisionKind.VLA: Vla,
    DecisionKind.PICK: Pick,
    DecisionKind.PLACE: Place,
}
"""The one map behind :attr:`DecisionKind.decision`, kept beside the union it maps into."""


class DecisionState(StrEnum):
    RUNNING = "running"
    SATISFIED = "satisfied"
    NOT_SATISFIED = "not_satisfied"


class NotSatisfiedReason(StrEnum):
    """Why a subgoal stopped — the vocabulary the agent re-decides on."""

    NO_GRASP = "no_grasp"
    """Nothing on the object admitted a force-closure grasp this body can execute."""
    UNREACHABLE = "unreachable"
    """A planned waypoint admits no configuration this body can reach within its limits."""
    TARGET_LOST = "target_lost"
    """A published instance no longer grounds where it was — moved, occluded, or taken."""
    GRASP_EMPTY = "grasp_empty"
    """The jaws closed on air, or dropped the object during the lift."""
    GRASP_UNCERTAIN = "grasp_uncertain"
    """Something is held, but not demonstrably the object that was planned for."""
    PLAN_DIVERGED = "plan_diverged"
    """The measured body left the planned path: the world moved, so the plan is stale."""
    HOLD_BUDGET_EXHAUSTED = "hold_budget_exhausted"
    """The decision spent its allowance of standing-still chunks without progressing."""


@dataclass(frozen=True, slots=True)
class DecisionReceipt:
    """The outcome of one subgoal, keyed by the decision it answers.

    Not a goal verdict: see this module's docstring. A satisfied receipt says the executor's
    own precondition held, and can complete nothing.
    """

    decision_id: DecisionId
    status: DecisionState
    reason: NotSatisfiedReason | None = None
    detail: str = ""

    def __post_init__(self) -> None:
        unsatisfied = self.status is DecisionState.NOT_SATISFIED
        if unsatisfied is not (self.reason is not None):
            raise DecisionError(
                "a not-satisfied receipt carries exactly one reason, and every other status "
                "carries none"
            )

    def to_wire(self) -> dict[str, object]:
        return {
            "decision_id": str(self.decision_id),
            "status": self.status.value,
            "reason": None if self.reason is None else self.reason.value,
            "detail": self.detail,
        }


# -- what the runtime published --------------------------------------------------------


@dataclass(frozen=True, slots=True)
class PublishedInstance:
    """One grounded object as the agent may see it: the echoable id, its label, the confidence.

    The runtime's own :class:`SceneInstance` also carries a base-frame position; that is the
    executor's fact, not the agent's, and does not cross.
    """

    instance: InstanceId
    label: str
    score: float

    def __post_init__(self) -> None:
        if not str(self.instance).strip():
            raise DecisionError("a published instance needs a non-empty id")
        if not 0.0 <= self.score <= 1.0:
            raise DecisionError(f"detection score {self.score} is not a confidence")

    def to_wire(self) -> dict[str, object]:
        return {"instance": str(self.instance), "label": self.label, "score": float(self.score)}


@dataclass(frozen=True, slots=True)
class PublishedScene:
    """Everything one perception grounded, as the agent receives it.

    This is what makes a :class:`TargetRef` safe: the ids exist because the runtime minted
    them, and a decision can only echo one back. An empty scene is a legitimate, truthful
    answer — a composite with no perception grounds nothing, and says so.
    """

    sequence: ObservationSequence
    instances: tuple[PublishedInstance, ...]

    def __post_init__(self) -> None:
        if int(self.sequence) < 0:
            raise DecisionError("an observation sequence is non-negative")
        names = [instance.instance for instance in self.instances]
        if len(names) != len(set(names)):
            raise DecisionError("instance ids must be unique within a published scene")

    def to_wire(self) -> dict[str, object]:
        return {
            "observation_sequence": int(self.sequence),
            "instances": [instance.to_wire() for instance in self.instances],
        }


# -- the agent's own causal identity ---------------------------------------------------


@dataclass(frozen=True, slots=True)
class EffectIdentity:
    """The one outstanding environment effect a decision is: the crate's own handle for it."""

    effect_id: str
    request_digest: Sha256Digest

    def __post_init__(self) -> None:
        if not self.effect_id.strip():
            raise DecisionError("an effect identity needs a non-empty effect id")
        if not self.request_digest.strip():
            raise DecisionError("an effect identity needs a non-empty request digest")

    def to_wire(self) -> dict[str, object]:
        return {"effect_id": self.effect_id, "request_digest": self.request_digest}


@dataclass(frozen=True, slots=True)
class DecisionIdentity:
    """Where one decision sits in the agent's own causal history.

    The crate resolves an outstanding decision only against an **exact** echo of this document,
    so the law that matters is ``parse_decision_identity(identity.to_wire()) == identity``:
    every field survives the round trip, and a document carrying anything else is refused
    rather than normalized.

    ``decision_id`` is the model-local label, a plain string: it is echoed, never constructed,
    so it is not narrowed to :class:`DecisionId` — the crate's alphabet is the crate's.
    """

    environment_generation: int
    effect: EffectIdentity
    goal_id: str
    goal_revision: int
    decision_id: str

    def __post_init__(self) -> None:
        if self.environment_generation < 1:
            raise DecisionError("an environment generation is a positive integer")
        if self.goal_revision < 1:
            raise DecisionError("a goal revision is a positive integer")
        if not self.goal_id.strip():
            raise DecisionError("a decision identity needs a non-empty goal id")
        if not self.decision_id.strip():
            raise DecisionError("a decision identity needs a non-empty decision id")

    def to_wire(self) -> dict[str, object]:
        return {
            "environment_generation": self.environment_generation,
            "effect": self.effect.to_wire(),
            "goal_id": self.goal_id,
            "goal_revision": self.goal_revision,
            "decision_id": self.decision_id,
        }


# -- the goal verdict ------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class VerifierIdentity:
    """Which verifier spoke, and at which revision of its own contract."""

    name: str
    version: str

    def __post_init__(self) -> None:
        if not self.name.strip() or not self.version.strip():
            raise DecisionError("a verifier identity needs both a name and a version")

    def to_wire(self) -> dict[str, object]:
        return {"name": self.name, "version": self.version}


@dataclass(frozen=True, slots=True)
class GoalVerificationReceipt:
    """Whether the **task** is done, from the only party that can know: the environment owner.

    The counterpart to :class:`DecisionReceipt` and never a substitute for it. A satisfied
    verdict here completes the agent's active goal; a satisfied ``DecisionReceipt`` completes
    nothing at all.

    ``schema`` is not a field: it is :data:`GOAL_VERIFICATION_SCHEMA`, emitted by
    :meth:`to_wire` and required by the parse. ``evidence`` is the verifier's own world facts,
    left open because this contract cannot know them — it mirrors the crate's
    ``BTreeMap<String, Value>`` and is the one place free-form JSON is lawful here.
    """

    decision: DecisionIdentity
    status: TaskVerdict
    summary: str
    observation_sequence: ObservationSequence
    verifier: VerifierIdentity
    evidence: Mapping[str, object]

    def __post_init__(self) -> None:
        if not self.summary.strip():
            raise DecisionError("a goal verification receipt needs a non-empty summary")
        if int(self.observation_sequence) < 0:
            raise DecisionError("an observation sequence is non-negative")

    def to_wire(self) -> dict[str, object]:
        return {
            "schema": GOAL_VERIFICATION_SCHEMA,
            "decision": self.decision.to_wire(),
            "status": self.status.value,
            "summary": self.summary,
            "observation_sequence": int(self.observation_sequence),
            "verifier": self.verifier.to_wire(),
            "evidence": dict(self.evidence),
        }


STEP_VERIFICATION_SCHEMA = "sx.step-verification/v1"
"""The wire tag one step verdict travels under."""


class StepState(StrEnum):
    """What a verifier concluded about ONE authored contract step.

    Three verdicts that must never collapse into two. :class:`TaskVerdict` cannot
    be reused here, and the reason is the whole point of the type: its ``NOT_SATISFIED``
    means "the goal does not hold", which for a step conflates *still working on it* with
    *it went wrong* — and that is precisely the distinction a long-horizon runtime spends its
    retry budget on. A step that is merely unfinished must not look like one that failed, or
    every slow pour reads as a fault.
    """

    RUNNING = "running"
    """Not finished, and nothing has gone wrong. The step keeps its control."""
    SATISFIED = "satisfied"
    """The step's authored ``until`` condition holds. The chain may advance."""
    FAILED = "failed"
    """The step cannot finish from here. Whether that ends the episode is
    :attr:`sx_contracts.TaskStep.reversible`'s answer, not this verdict's."""


@dataclass(frozen=True, slots=True)
class StepVerificationReceipt:
    """One verifier's verdict on one authored step of a task contract's decomposition.

    Addressed by ``step_index`` into the contract's own ``steps`` — the same index a
    ``sx_episodes.StepBoundary`` carries — because a step has no identity of its own and
    inventing one would fork the contract's ordering.

    A sibling of :class:`GoalVerificationReceipt`, never a replacement: that one says whether
    the *task* is done and completes an agent's goal; this one says how one step of the way
    there is going and completes nothing. Merging them would let a satisfied step read as a
    satisfied task, which on a twelve-step brew is the difference between coffee and a wet
    filter.

    ``evidence`` is the verifier's own world facts (the scale read 61.2 g at t=94.1) — open
    for the same reason its sibling's is: this contract cannot know them.
    """

    step_index: int
    status: StepState
    summary: str
    observation_sequence: ObservationSequence
    verifier: VerifierIdentity
    evidence: Mapping[str, object]

    def __post_init__(self) -> None:
        if self.step_index < 0:
            raise DecisionError("a step index is a non-negative position in the contract")
        if not self.summary.strip():
            raise DecisionError("a step verification receipt needs a non-empty summary")
        if int(self.observation_sequence) < 0:
            raise DecisionError("an observation sequence is non-negative")

    def to_wire(self) -> dict[str, object]:
        return {
            "schema": STEP_VERIFICATION_SCHEMA,
            "step_index": self.step_index,
            "status": self.status.value,
            "summary": self.summary,
            "observation_sequence": int(self.observation_sequence),
            "verifier": self.verifier.to_wire(),
            "evidence": dict(self.evidence),
        }


# -- what actually moved ---------------------------------------------------------------


class ChunkKind(StrEnum):
    """Who commanded one emitted chunk, and whether it moved."""

    HOLD = "hold"
    """The decision in force commanded stillness."""
    MOTION = "motion"
    """The decision in force commanded motion."""
    PREEMPTED = "preempted"
    """The **spine** commanded this chunk; the decision in force was suspended for it.

    Neither hold nor motion, because both of those attribute what the robot did to the
    decision that was in force — and this motion is exactly what that decision did *not*
    ask for. Counting a withdrawal as the subgoal's motion would make an episode where the
    spine intervened read as ordinary progress, which is the one reading the evidence must
    never support.
    """


@dataclass(frozen=True, slots=True)
class Preemption:
    """One stretch of control the reflex took back from the decision in force.

    Replanning requests a replacement and silence past the policy's decision timeout fails the
    boundary; preemption does neither. It *suspends* the decision — the reflex withdraws while
    the hazard persists, and when the hazard clears control returns to the same decision with
    its replan interval resuming where it was rather than running down under motion it never
    commanded.

    It reaches the agent as the :data:`REFLEX_FACT_KEY` observation fact at the next decision
    boundary — after the fact, the way a spinal reflex reaches cortex. An agent that is not
    told replans against a world it misreads: it believes its subgoal held control for the
    whole interval and that whatever the arm did, it asked for.
    """

    reflex: str
    """The organ's stable name — which reflex fired, not merely that one did."""
    hazard: str
    """What it withdrew from, in the reflex's own words. Free text is lawful here because
    no model wrote it: a reflex is local machinery, and this text is never parsed."""
    decision_id: DecisionId
    """The decision that was suspended and then resumed. Total: a reflex preempts a
    decision in force, so there is always one to name."""
    chunks: int
    """How many chunks the spine commanded before the hazard cleared."""

    def __post_init__(self) -> None:
        if not self.reflex.strip():
            raise DecisionError("a preemption names the reflex that took control")
        if not self.hazard.strip():
            raise DecisionError("a preemption names the hazard it withdrew from")
        if self.chunks < 1:
            raise DecisionError("a preemption that commanded nothing is not a preemption")

    def to_wire(self) -> dict[str, object]:
        return {
            "reflex": self.reflex,
            "hazard": self.hazard,
            "decision_id": str(self.decision_id),
            "chunks": self.chunks,
        }


@dataclass(frozen=True, slots=True)
class DecisionAnchor:
    """Where a decision sits in the agent's own trace.

    ``atif_step_id`` rides on the decision event because the recorder assigns it *before* the
    tool executes; recovering it afterwards would mean scanning for a match. ``invocation_id``
    separates retries: the same tool call attempted twice is two spans, not one long one.
    """

    decision_id: DecisionId
    atif_step_id: str
    tool_call_id: str
    invocation_id: int

    def __post_init__(self) -> None:
        if not self.atif_step_id.strip() or not self.tool_call_id.strip():
            raise SpanError("a decision anchor needs both an ATIF step and a tool call")
        if self.invocation_id < 0:
            raise SpanError("invocation id must be a non-negative integer")


@dataclass(frozen=True, slots=True)
class DecisionSpan:
    """One decision's runtime half: when it moved, how long it stood still, how it ended.

    A decision can spend tens of seconds perceiving and planning while the robot stands still
    under hold chunks. Charging that to the span would make the capability look enormously
    slower than it is and — worse — would hide the opposite failure, where a decision
    "succeeds" having spent most of its budget holding. So the span runs from the first motion
    to the last, and the hold count rides alongside as evidence rather than being averaged away.

    ``reason`` is the receipt's typed not-satisfied reason (empty for every other status):
    the sidecar is evidence, and a failed decision whose failure mode is not in the evidence
    would have to be re-derived from logs.

    ``preempted_chunks`` is the same argument for the spine. A decision suspended under a
    reflex did not run under the conditions its span would otherwise claim, so those chunks
    are counted apart from both motion and hold — a preempted span must never read as ordinary
    motion.
    """

    anchor: DecisionAnchor
    status: DecisionState
    first_motion_wall_time_ns: int | None
    last_motion_wall_time_ns: int | None
    motion_chunks: int
    hold_chunks: int
    preempted_chunks: int
    reason: str = ""

    def __post_init__(self) -> None:
        bounded = (self.first_motion_wall_time_ns is None) is (
            self.last_motion_wall_time_ns is None
        )
        if not bounded:
            raise SpanError("a span is bounded at both ends or at neither")
        if (
            self.first_motion_wall_time_ns is not None
            and self.last_motion_wall_time_ns is not None
            and self.last_motion_wall_time_ns < self.first_motion_wall_time_ns
        ):
            raise SpanError("a span cannot end before it begins")
        if (self.motion_chunks > 0) is not (self.first_motion_wall_time_ns is not None):
            raise SpanError("a span has motion chunks exactly when it has a motion interval")
        if self.preempted_chunks < 0:
            raise SpanError("a span cannot have been preempted for a negative number of chunks")

    @property
    def moved(self) -> bool:
        """Whether this decision ever commanded the robot to move at all."""
        return self.motion_chunks > 0


def dump_decision_spans(spans: tuple[DecisionSpan, ...]) -> str:
    """The sidecar document the environment owner joins to control steps at episode close.

    The runtime writes this half — the ATIF anchors and wall times it stamped. Only the
    environment owner knows the episode's clock, so it joins the control-step range and writes
    the ``sx.episode.agent/v1`` layer; the runtime never writes a second base episode.
    """
    return canonical_json(
        {
            "schema": SPAN_SCHEMA,
            "spans": [
                {
                    "decision_id": str(span.anchor.decision_id),
                    "atif_step_id": span.anchor.atif_step_id,
                    "tool_call_id": span.anchor.tool_call_id,
                    "invocation_id": span.anchor.invocation_id,
                    "status": span.status.value,
                    "reason": span.reason,
                    "first_motion_wall_time_ns": span.first_motion_wall_time_ns,
                    "last_motion_wall_time_ns": span.last_motion_wall_time_ns,
                    "motion_chunks": span.motion_chunks,
                    "hold_chunks": span.hold_chunks,
                    "preempted_chunks": span.preempted_chunks,
                }
                for span in spans
            ],
        }
    )


# -- the codecs ------------------------------------------------------------------------
#
# Every parse below is total on its declared domain and fail-closed everywhere else: an
# unknown tag, an extra field, a missing field, and an out-of-range value are all a typed
# `DecisionError`. Nothing is coerced, defaulted, or ignored.


def _exactly(document: Mapping[str, object], names: set[str], *, where: str) -> None:
    if set(document) != names:
        raise DecisionError(
            f"{where} carries fields {sorted(document)}, and the contract is {sorted(names)}"
        )


E = TypeVar("E", bound=StrEnum)


def _member(enum: type[E], raw: str, *, where: str) -> E:
    try:
        return enum(raw)
    except ValueError as error:
        raise DecisionError(f"{where} is not a {enum.__name__}: {raw!r}") from error


def parse_replan_interval(obj: object) -> ReplanInterval:
    """A policy-level replan interval from its wire form."""
    document = decode.document(obj, where="a replan interval", error=DecisionError)
    _exactly(document, {"chunks", "wall_ms"}, where="a replan interval")
    return ReplanInterval(
        chunks=decode.integer(document, "chunks"),
        wall_ms=decode.integer(document, "wall_ms"),
    )


def _parse_target_ref(obj: object, *, where: str) -> TargetRef:
    document = decode.document(obj, where=where, error=DecisionError)
    _exactly(document, {"observation_sequence", "instance"}, where=where)
    sequence = decode.integer(document, "observation_sequence")
    if sequence < 0:
        raise DecisionError(f"{where} names a negative observation sequence: {sequence}")
    instance = decode.text(document, "instance")
    if not instance.strip():
        raise DecisionError(f"{where} names an empty instance id")
    return TargetRef(
        observation_sequence=ObservationSequence(sequence), instance=InstanceId(instance)
    )


def parse_subgoal_command(obj: object) -> Vla | Pick | Place:
    """One decision an agent may issue, tagged by ``kind``.

    :class:`Transfer` is deliberately absent: it is a lawful decision a script issues, never a
    wire variant, so ``kind: "transfer"`` is refused like any other unknown tag.
    """
    where = "a subgoal command"
    document = decode.document(obj, where=where, error=DecisionError)
    if "kind" not in document:
        raise DecisionError(f"{where} is missing its {'kind'!r} tag")
    kind = decode.text(document, "kind")
    match kind:
        case DecisionKind.VLA:
            _exactly(document, {"kind", "decision_id", "instruction"}, where="a vla command")
            return Vla(
                decision_id=DecisionId(decode.text(document, "decision_id")),
                instruction=decode.text(document, "instruction"),
            )
        case DecisionKind.PICK:
            _exactly(document, {"kind", "decision_id", "target"}, where="a pick command")
            return Pick(
                decision_id=DecisionId(decode.text(document, "decision_id")),
                target=_parse_target_ref(document["target"], where="a pick target"),
            )
        case DecisionKind.PLACE:
            _exactly(document, {"kind", "decision_id", "target", "mode"}, where="a place command")
            return Place(
                decision_id=DecisionId(decode.text(document, "decision_id")),
                target=_parse_target_ref(document["target"], where="a place target"),
                mode=_member(
                    PlacementMode,
                    decode.text(document, "mode"),
                    where="a place mode",
                ),
            )
        case _:
            raise DecisionError(f"unknown subgoal command kind: {kind!r}")


def parse_decision_receipt(obj: object) -> DecisionReceipt:
    """An executor verdict from its wire form."""
    where = "a decision receipt"
    document = decode.document(obj, where=where, error=DecisionError)
    _exactly(document, {"decision_id", "status", "reason", "detail"}, where=where)
    raw_reason = document["reason"]
    if raw_reason is not None and not isinstance(raw_reason, str):
        raise DecisionError(f"{where} field 'reason' must be a string or null, got {raw_reason!r}")
    return DecisionReceipt(
        decision_id=DecisionId(decode.text(document, "decision_id")),
        status=_member(
            DecisionState,
            decode.text(document, "status"),
            where=where,
        ),
        reason=(
            None
            if raw_reason is None
            else _member(NotSatisfiedReason, raw_reason, where=f"{where} reason")
        ),
        detail=decode.text(document, "detail"),
    )


def parse_published_scene(obj: object) -> PublishedScene:
    """A published scene from its wire form."""
    where = "a published scene"
    document = decode.document(obj, where=where, error=DecisionError)
    _exactly(document, {"observation_sequence", "instances"}, where=where)
    raw_instances = document["instances"]
    if not isinstance(raw_instances, list):
        raise DecisionError(f"{where} field 'instances' must be a list, got {raw_instances!r}")
    instances: list[PublishedInstance] = []
    for raw in cast("list[object]", raw_instances):
        instance = decode.document(raw, where="a published instance", error=DecisionError)
        _exactly(instance, {"instance", "label", "score"}, where="a published instance")
        instances.append(
            PublishedInstance(
                instance=InstanceId(decode.text(instance, "instance")),
                label=decode.text(instance, "label"),
                score=decode.number(instance, "score"),
            )
        )
    return PublishedScene(
        sequence=ObservationSequence(decode.integer(document, "observation_sequence")),
        instances=tuple(instances),
    )


def parse_decision_identity(obj: object) -> DecisionIdentity:
    """A causal decision identity from its wire form; the inverse of
    :meth:`DecisionIdentity.to_wire`."""
    where = "a decision identity"
    document = decode.document(obj, where=where, error=DecisionError)
    _exactly(
        document,
        {"environment_generation", "effect", "goal_id", "goal_revision", "decision_id"},
        where=where,
    )
    effect = decode.document(document["effect"], where="an effect identity", error=DecisionError)
    _exactly(effect, {"effect_id", "request_digest"}, where="an effect identity")
    return DecisionIdentity(
        environment_generation=decode.integer(document, "environment_generation"),
        effect=EffectIdentity(
            effect_id=decode.text(effect, "effect_id"),
            request_digest=Sha256Digest(decode.text(effect, "request_digest")),
        ),
        goal_id=decode.text(document, "goal_id"),
        goal_revision=decode.integer(document, "goal_revision"),
        decision_id=decode.text(document, "decision_id"),
    )


def parse_goal_verification_receipt(obj: object) -> GoalVerificationReceipt:
    """A goal verdict from its wire form; the schema label must be exactly this contract's."""
    where = "a goal verification receipt"
    document = decode.document(obj, where=where, error=DecisionError)
    _exactly(
        document,
        {
            "schema",
            "decision",
            "status",
            "summary",
            "observation_sequence",
            "verifier",
            "evidence",
        },
        where=where,
    )
    schema = decode.text(document, "schema")
    if schema != GOAL_VERIFICATION_SCHEMA:
        raise DecisionError(f"{where} schema must be {GOAL_VERIFICATION_SCHEMA!r}, got {schema!r}")
    verifier = decode.document(
        document["verifier"], where="a verifier identity", error=DecisionError
    )
    _exactly(verifier, {"name", "version"}, where="a verifier identity")
    return GoalVerificationReceipt(
        decision=parse_decision_identity(document["decision"]),
        status=_member(
            TaskVerdict,
            decode.text(document, "status"),
            where=f"{where} status",
        ),
        summary=decode.text(document, "summary"),
        observation_sequence=ObservationSequence(decode.integer(document, "observation_sequence")),
        verifier=VerifierIdentity(
            name=decode.text(verifier, "name"),
            version=decode.text(verifier, "version"),
        ),
        evidence=decode.document(
            document["evidence"], where="goal verification evidence", error=DecisionError
        ),
    )
