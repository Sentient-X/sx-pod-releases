"""The supervision escalation ladder and verdict vocabulary.

Canonical origin: the `supervisors` engine. Lives here because the layer/verdict
labels are stamped onto training data and consumed by every repo that reads it.
"""

from enum import IntEnum, StrEnum
from typing import Final

from sx_contracts.action_source import ActionSource


class SupervisionLayer(IntEnum):
    """The four rungs of the supervision ladder, ordered by escalation priority.

    Lower rungs are cheap and always-on; higher rungs are expensive and consulted
    only when a lower rung escalates.
    """

    L0_HEURISTIC = 0
    L1_REWARD = 1
    L2_AGENTIC = 2
    L3_HUMAN = 3

    @property
    def escalates_to(self) -> "SupervisionLayer | None":
        """The next rung up the ladder, or `None` at the terminal (human) rung."""
        nxt = self.value + 1
        return SupervisionLayer(nxt) if nxt <= SupervisionLayer.L3_HUMAN.value else None


class Decision(StrEnum):
    """A supervisor's verdict on the step it was asked to assess."""

    PASS = "pass"
    """Nothing wrong — approve the proposed action and stop consulting the ladder."""
    FLAG = "flag"
    """Approve, but record a note (advisory; does not consult higher rungs)."""
    INTERVENE = "intervene"
    """This layer takes over — via an action override or a full takeover."""
    ESCALATE = "escalate"
    """Beyond this layer's competence — consult the next registered rung."""

    @property
    def severity(self) -> int:
        """Total order used to combine verdicts (most severe wins)."""
        return _DECISION_SEVERITY[self]


_DECISION_SEVERITY: Final[dict[Decision, int]] = {
    Decision.PASS: 0,
    Decision.FLAG: 1,
    Decision.INTERVENE: 2,
    Decision.ESCALATE: 3,
}


def source_for_layer(layer: SupervisionLayer) -> ActionSource:
    """The action-source label an intervention by `layer` stamps on its output."""
    match layer:
        case SupervisionLayer.L0_HEURISTIC | SupervisionLayer.L1_REWARD:
            return ActionSource.HEURISTIC_OVERRIDE
        case SupervisionLayer.L2_AGENTIC:
            return ActionSource.AGENT
        case SupervisionLayer.L3_HUMAN:
            return ActionSource.HUMAN_TELEOP
