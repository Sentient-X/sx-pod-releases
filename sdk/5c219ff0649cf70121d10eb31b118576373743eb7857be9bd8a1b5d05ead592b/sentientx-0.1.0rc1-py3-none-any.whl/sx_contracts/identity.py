"""`Ref[A] = SHA256(Bytes[A])` — the functor, written once.

`docs/ABSTRACTIONS.md` declares this in its notation table as if it were a single
operation. In the tree it was a single operation written out thirty-six times: every
package that mints a content identity re-typed the same `json.dumps` argument list and
the same `sha256(...).hexdigest()`, and five of them wrapped it in a function they each
independently named `canonical_json`. Six of those files carried a docstring promising
their exact bytes were frozen forever — six separate permanence guarantees for one
three-argument call.

The duplication was invisible to every clone detector, because the *code* legitimately
differed: each site encodes a different document. That is the per-type part and it stays
where it belongs, as the type's own `_content_dict()`. What is shared is the encoding and
the hash, and that is what lives here.

**These bytes are frozen.** Every persisted digest in the stack — task contracts, action
and state interfaces, embodiments, corpora, releases, calibrations — was minted over
exactly `json.dumps(document, ensure_ascii=False, separators=(",", ":"), sort_keys=True)`
encoded UTF-8. Changing any argument re-mints every id in every repo and silently breaks
every stored lineage edge. `tests/test_content_identity.py` pins the bytes and a golden
digest per type, so a change to this module fails there rather than in production.

The same argument applies to the *other* thing the stack hashes: raw bytes. `file_digest`
and `stream_blob` live here beside `content_digest` because the loop is the same loop —
nine packages had copied it, two of them twice — and because all three must agree on what
a digest *is*. They return `Sha256Digest`, not `str`, so the type survives the call: a
field that holds the result of one of these is annotated with what it holds, and the
64-hex check happens once, in the constructor, instead of at each of the forty-odd
`Field(pattern=...)` declarations that used to re-state it.

One divergence is recorded rather than repaired: `sx_autonomy.performance` omits
`ensure_ascii=False`, so a non-ASCII scorecard hashes differently there. It is left alone
for the same reason the rest are frozen — correcting it would change digests that already
exist. See the entry in `docs/ABSTRACTIONS.md`.
"""

from __future__ import annotations

import json
import math
from collections.abc import Callable, Iterable, Mapping
from hashlib import sha256
from pathlib import Path
from types import MappingProxyType
from typing import TypeAlias, TypeVar, cast

from sx_contracts.content import ContentBlob, Sha256Digest

JsonScalar: TypeAlias = None | bool | int | float | str
JsonValue: TypeAlias = (
    JsonScalar | Mapping[str, "JsonValue"] | list["JsonValue"] | tuple["JsonValue", ...]
)
JsonObject: TypeAlias = Mapping[str, JsonValue]
CanonicalDocument: TypeAlias = JsonObject | list[JsonValue] | tuple[JsonValue, ...]
FrozenJsonValue: TypeAlias = (
    JsonScalar | Mapping[str, "FrozenJsonValue"] | tuple["FrozenJsonValue", ...]
)
FrozenJsonObject: TypeAlias = Mapping[str, FrozenJsonValue]
"""A JSON-shaped document: what a value says about itself for identity purposes.

An object or an array — a few identities are taken over an ordered list rather than a
mapping (`SourceManifest.sha256` over its sorted objects). A bare string is not a
document; nothing in the stack mints an identity from one, and this alias does not
invite it.
"""


class CanonicalJsonError(ValueError):
    """A proposed identity document is not finite recursive JSON."""


def _normalize(value: object, path: str = "<root>") -> JsonValue:
    """Copy one JSON value into built-in containers and reject Python extensions.

    Canonical identity accepts mappings, lists, and tuples because those are the two
    mathematical JSON containers used by domain values.  It deliberately does not accept
    arbitrary ``Sequence`` implementations: strings, bytes, NumPy arrays, and framework
    containers must be projected by their owner instead of acquiring accidental wire rules.
    """

    if value is None or isinstance(value, (bool, str)):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise CanonicalJsonError(f"{path}: numbers must be finite")
        return value
    if isinstance(value, Mapping):
        source = cast(Mapping[object, object], value)
        normalized: dict[str, JsonValue] = {}
        for key, item in source.items():
            if not isinstance(key, str):
                raise CanonicalJsonError(f"{path}: object keys must be strings")
            normalized[key] = _normalize(item, f"{path}.{key}")
        return normalized
    if isinstance(value, (list, tuple)):
        source_items = cast(list[object] | tuple[object, ...], value)
        return [_normalize(item, f"{path}[{index}]") for index, item in enumerate(source_items)]
    raise CanonicalJsonError(f"{path}: unsupported JSON value {type(value).__name__}")


def _document(document: object) -> JsonObject | list[JsonValue]:
    normalized = _normalize(document)
    if not isinstance(normalized, (dict, list)):
        raise CanonicalJsonError("<root>: a canonical document must be an object or array")
    return normalized


def canonical_json(document: CanonicalDocument) -> str:
    """`Bytes[A]`, as text — the one canonical serialization, frozen forever."""
    return json.dumps(
        _document(document),
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    )


def ascii_canonical_json(document: CanonicalDocument) -> str:
    """The stack's *other* frozen canonical form: sorted keys, compact, ASCII-escaped.

    Two canonical encodings exist here, and pretending otherwise would be the lie that
    re-mints digests. Twenty-seven sites omit `ensure_ascii=False`, so a non-ASCII value
    escapes to ``\\uXXXX`` before hashing — a different byte string, and therefore a
    different id, from the same document under :func:`canonical_json`. Their digests are
    already persisted (`StationTarget.ref`, `capture_receipt_sha256`, and the
    operation/idempotency keys around them), so the
    divergence is named rather than repaired.

    **Do not choose this for new code.** It exists so the sites that already depend on it
    say which form they mean, instead of twenty-seven hand-written `json.dumps` calls
    that differ from the one above by an argument nobody notices is missing.
    """
    return json.dumps(_document(document), allow_nan=False, separators=(",", ":"), sort_keys=True)


def freeze_json(value: object) -> FrozenJsonValue:
    """Take a deeply immutable snapshot of open JSON evidence.

    Mappings are copied into read-only mapping proxies and arrays become tuples.  The same
    finite-JSON validation used for identities runs first, so an immutable snapshot can always
    be projected through :func:`canonical_json` without a later serialization surprise.

    The parameter is `object`, not `JsonValue`, because that validation *is* the point:
    this is what a boundary calls on evidence it has just parsed and cannot yet name.
    Demanding the caller prove the value is JSON before the function that proves it
    would put a `cast` at every honest use.
    """

    normalized = _normalize(value)
    return _freeze_normalized(normalized)


def _freeze_normalized(value: JsonValue) -> FrozenJsonValue:
    if isinstance(value, Mapping):
        return MappingProxyType({key: _freeze_normalized(item) for key, item in value.items()})
    if isinstance(value, list):
        return tuple(_freeze_normalized(item) for item in value)
    if isinstance(value, tuple):  # defensive: _normalize currently projects tuples to lists
        return tuple(_freeze_normalized(item) for item in value)
    return value


def canonical_bytes(document: CanonicalDocument) -> bytes:
    """`Bytes[A]` — the exact bytes every content identity in the stack is taken over."""
    return canonical_json(document).encode("utf-8")


def content_digest(document: CanonicalDocument) -> Sha256Digest:
    """The SHA-256 of a document's canonical bytes."""
    return Sha256Digest(sha256(canonical_bytes(document)).hexdigest())


#: What every hand-written file-hashing loop in the stack independently picked.
_CHUNK_BYTES = 1024 * 1024


def stream_blob(chunks: Iterable[bytes]) -> ContentBlob:
    """Measure and identify a byte stream in one pass, without holding it in memory.

    The stream form exists because three callers hash something that is not a file on
    disk: `sx_service.storage` hashes an upload *while* it lands it, `sxd`'s rerun-bundle
    emitter hashes an object body it is already iterating, and the factory's uploader
    hashes a source it is streaming out. Handing them a path would mean moving the bytes
    twice.

    It returns `ContentBlob` rather than a bare digest because the size falls out of the
    same pass, and every one of those callers wanted both — which is exactly the pair
    `ContentBlob` is declared to be.
    """
    digest = sha256()
    size_bytes = 0
    for chunk in chunks:
        digest.update(chunk)
        size_bytes += len(chunk)
    return ContentBlob(sha256=Sha256Digest(digest.hexdigest()), size_bytes=size_bytes)


def file_digest(path: Path) -> Sha256Digest:
    """The SHA-256 of a file's bytes.

    Nine packages each carried this loop, byte-identical down to the 1 MiB chunk size,
    and two of them carried it twice. It is one function. Callers that also want the size
    read it from `stat()`, which does not re-read the file.
    """
    with path.open("rb") as handle:
        return stream_blob(iter(lambda: handle.read(_CHUNK_BYTES), b"")).sha256


class RollingDigest:
    """`Ref[A]` over a sequence too long to hold — the streaming form of `content_digest`.

    A dataset snapshot's identity is taken over its members, and the whole point of a
    snapshot is that there may be ten million of them. `content_digest` wants the
    document; this wants one element at a time, and the elements need never coexist.

    The bytes are the same frozen bytes: each element goes through `canonical_bytes`, so
    a rolling identity and a whole-document one agree element for element, and the
    permanence guarantee at the top of this module covers both. What a caller must supply
    is the *order*, because a set has no canonical serialization — feed elements sorted,
    and say by what.

    Not `stream_blob`: that measures and identifies raw bytes a caller already has, and
    reports how many there were. This mints an identity from documents, and the count
    that matters to its callers is of elements, not of bytes.
    """

    __slots__ = ("_running",)

    def __init__(self) -> None:
        self._running = sha256()

    def update(self, element: CanonicalDocument) -> None:
        self._running.update(canonical_bytes(element))

    def seal(self) -> Sha256Digest:
        return Sha256Digest(self._running.hexdigest())


IdT = TypeVar("IdT", bound=str)


def content_id(mint: Callable[[str], IdT], document: CanonicalDocument) -> IdT:
    """`Ref[A]` — the typed content identity of one document.

    `mint` is the domain's own id type, so the identity stays named by the package that
    owns it while the derivation is shared::

        return content_id(ActionInterfaceId, _semantic_dict(interface))

    It is a `Callable[[str], IdT]` rather than a `type[IdT]` so that a `NewType` id and a
    validated `WireString` subclass are equally admissible — both are already spelled as
    a one-argument call at every mint site.
    """
    return mint(content_digest(document))
