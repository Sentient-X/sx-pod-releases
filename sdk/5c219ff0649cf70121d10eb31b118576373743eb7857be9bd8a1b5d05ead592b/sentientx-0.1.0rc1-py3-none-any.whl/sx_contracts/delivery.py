"""Dependency-free wire vocabulary for governed Experience delivery."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum
from typing import Literal, TypeAlias, cast
from uuid import UUID

from sx_contracts.content import Sha256Digest
from sx_contracts.identity import JsonValue, content_digest
from sx_contracts.ids import EpisodeId
from sx_contracts.operations import OperationFailure, OperationState
from sx_contracts.schemas import SchemaId
from sx_contracts.wire import WireString

DELIVERY_WORKFLOW = "SxCatalogDelivery"
"""The stable Temporal type that durably performs one admitted delivery."""


def delivery_workflow_id(delivery_id: UUID) -> str:
    """The one Temporal execution that owns this delivery run."""
    return f"catalog-delivery-{delivery_id}"


@dataclass(frozen=True, slots=True)
class DeliverySubmission:
    """The delivery identity Catalog commits and the executor resolves back."""

    delivery_id: UUID
    project_id: UUID


class DeliveryFormat(StrEnum):
    """Closed delivery formats selected by Experience destinations."""

    RRD_BUNDLE = "rrd_bundle"
    # Current persisted/deployed obligation: SXD deserializes routing_rules.output_format
    # through this enum and pins its mandatory universal-archive destination to the
    # emitter registry key ``rerun_bundle``. Experience owns its retirement. Delete
    # this value only in the same change that migrates persisted routes to RRD_BUNDLE,
    # moves archive delivery authority to Catalog, and removes SXD's emitter.
    RERUN_BUNDLE = "rerun_bundle"
    MCAP_BUNDLE = "mcap_bundle"
    LEROBOT_V3 = "lerobot_v3"


class SourceObjectRole(StrEnum):
    """Meaning of an immutable input object supplied to an export."""

    EPISODE_RRD = "episode_rrd"
    FUSED_MCAP = "fused_mcap"
    FIELD_METADATA = "field_metadata"
    AUXILIARY = "auxiliary"


class DeliverySourceContractVersion(StrEnum):
    """Closed versions of the SXD → Catalog delivery handoff."""

    V1 = "sx.delivery-source/v1"


DeliveryPart: TypeAlias = Literal["source", "prefix", "conversion"]


class DeliveryContractError(ValueError):
    """A governed delivery contract is incomplete or internally inconsistent.

    ``part`` names the failed contract part: a delivery ``source`` manifest or
    object, a customer object ``prefix``, or a standard ``conversion`` request.
    ``part`` defaults to ``source`` because that is what a one-argument
    construction has always meant here — the form the shared decode kit uses
    when a door names this type as its fail-closed error.
    """

    def __init__(self, message: str, part: DeliveryPart = "source") -> None:
        self.part: DeliveryPart = part
        super().__init__(message)


@dataclass(frozen=True, slots=True)
class ImmutableDeliveryObject:
    """Exact storage identity and content identity of one delivery input."""

    uri: str
    sha256: Sha256Digest
    size_bytes: int
    object_identity: str

    def __post_init__(self) -> None:
        if not self.uri.startswith("s3://"):
            raise DeliveryContractError("delivery source URI must use s3://")
        object.__setattr__(self, "sha256", Sha256Digest(self.sha256))
        if self.size_bytes < 0:
            raise DeliveryContractError("delivery source size_bytes must be >= 0")
        if not self.object_identity.strip():
            raise DeliveryContractError("delivery source object identity must be non-empty")


@dataclass(frozen=True, slots=True)
class DeliverySidecar:
    """One exact sidecar selected by SXD for customer delivery."""

    source: ImmutableDeliveryObject
    media_type: str
    destination_filename: str

    def __post_init__(self) -> None:
        if not self.media_type.strip():
            raise DeliveryContractError("delivery sidecar media type must be non-empty")
        filename = self.destination_filename
        parts = filename.split("/")
        if (
            not filename
            or filename.startswith("/")
            or filename.endswith("/")
            or "\\" in filename
            or any(not part or part in {".", ".."} for part in parts)
            or any(any(ord(char) < 32 or ord(char) == 127 for char in part) for part in parts)
        ):
            raise DeliveryContractError("delivery sidecar filename must be a safe relative path")


@dataclass(frozen=True, slots=True)
class DeliverySourceManifest:
    """Immutable SXD handoff admitted only after its native episode is READY."""

    episode_id: EpisodeId
    fused_mcap: ImmutableDeliveryObject
    sidecars: tuple[DeliverySidecar, ...]
    producer_version: str
    contract_version: DeliverySourceContractVersion = DeliverySourceContractVersion.V1

    def __post_init__(self) -> None:
        if not str(self.episode_id).strip():
            raise DeliveryContractError("delivery source episode id must be non-empty")
        if not self.producer_version.strip():
            raise DeliveryContractError("delivery source producer version must be non-empty")
        uris = [self.fused_mcap.uri, *(sidecar.source.uri for sidecar in self.sidecars)]
        if len(uris) != len(set(uris)):
            raise DeliveryContractError("delivery source manifest repeats an object URI")
        filenames = [sidecar.destination_filename for sidecar in self.sidecars]
        if len(filenames) != len(set(filenames)):
            raise DeliveryContractError("delivery source manifest repeats a destination filename")

    def to_dict(self) -> dict[str, JsonValue]:
        def source(value: ImmutableDeliveryObject) -> dict[str, JsonValue]:
            return {
                "uri": value.uri,
                "sha256": value.sha256,
                "size_bytes": value.size_bytes,
                "object_identity": value.object_identity,
            }

        return {
            "contract_version": self.contract_version.value,
            "episode_id": str(self.episode_id),
            "fused_mcap": source(self.fused_mcap),
            "sidecars": [
                {
                    **source(sidecar.source),
                    "media_type": sidecar.media_type,
                    "destination_filename": sidecar.destination_filename,
                }
                for sidecar in self.sidecars
            ],
            "producer_version": self.producer_version,
        }

    def sha256(self) -> str:
        return content_digest(self.to_dict())


def delivery_source_manifest_from_dict(value: Mapping[str, object]) -> DeliverySourceManifest:
    """Parse one untrusted wire document into the complete immutable contract."""

    def text(document: Mapping[str, object], field: str) -> str:
        raw = document.get(field)
        if not isinstance(raw, str):
            raise DeliveryContractError(f"delivery source {field} must be text")
        return raw

    def integer(document: Mapping[str, object], field: str) -> int:
        raw = document.get(field)
        if not isinstance(raw, int) or isinstance(raw, bool):
            raise DeliveryContractError(f"delivery source {field} must be an integer")
        return raw

    def source(document: Mapping[str, object]) -> ImmutableDeliveryObject:
        return ImmutableDeliveryObject(
            uri=text(document, "uri"),
            sha256=Sha256Digest(text(document, "sha256")),
            size_bytes=integer(document, "size_bytes"),
            object_identity=text(document, "object_identity"),
        )

    try:
        version = DeliverySourceContractVersion(text(value, "contract_version"))
    except ValueError as error:
        raise DeliveryContractError("delivery source contract version is unsupported") from error
    fused_raw = value.get("fused_mcap")
    sidecars_raw = value.get("sidecars")
    if not isinstance(fused_raw, dict) or not isinstance(sidecars_raw, list):
        raise DeliveryContractError("delivery source objects have an invalid shape")
    fused = source(cast(dict[str, object], fused_raw))
    sidecars: list[DeliverySidecar] = []
    for item in cast(list[object], sidecars_raw):
        if not isinstance(item, dict):
            raise DeliveryContractError("delivery source sidecar has an invalid shape")
        item_mapping = cast(dict[str, object], item)
        sidecars.append(
            DeliverySidecar(
                source=source(item_mapping),
                media_type=text(item_mapping, "media_type"),
                destination_filename=text(item_mapping, "destination_filename"),
            )
        )
    return DeliverySourceManifest(
        episode_id=EpisodeId(text(value, "episode_id")),
        fused_mcap=fused,
        sidecars=tuple(sidecars),
        producer_version=text(value, "producer_version"),
        contract_version=version,
    )


class ObjectPrefix(WireString):
    """Canonical empty-or-trailing-slash object-key prefix."""

    def __new__(cls, value: str) -> ObjectPrefix:
        if not value:
            return str.__new__(cls, "")
        if value.startswith("/") or not value.endswith("/"):
            raise DeliveryContractError("object prefix must be relative and end in '/'", "prefix")
        parts = value[:-1].split("/")
        if any(not part or part in {".", ".."} for part in parts):
            raise DeliveryContractError("object prefix contains an unsafe path element", "prefix")
        if any(any(ord(char) < 32 or ord(char) == 127 for char in part) for part in parts):
            raise DeliveryContractError("object prefix contains a control character", "prefix")
        return str.__new__(cls, value)

    def segment(self, segment_id: str) -> str:
        """Flatten one segment id ('rollout/episode') into a single key element.

        '__' rather than percent-encoding: a literal '%' in an object key makes
        every presign/fetch double-encode, and customers browse these buckets.
        """
        if not segment_id:
            raise DeliveryContractError("segment id is empty", "prefix")
        return f"{self}{segment_id.replace('/', '__')}/"


# ── one delivery, as the executor that performs it sees it ───────────────────
#
# The governance half of a delivery is `sx_catalog.server.deliveries`: which
# agreement, over which snapshot, from which sealed sources. The half below is what
# has to cross the wire for somebody else to *do* it, and it lives here for the same
# reason `WorkLease` and `RunReport` do — the catalog may not import the executor and
# the executor may not import the catalog, so a value both ends speak has exactly one
# definition or it has two that drift.


@dataclass(frozen=True, slots=True)
class DeliveredArtifact:
    """One object a worker says it wrote into the recipient's destination.

    `source_sha256` is echoed rather than looked up so the catalog can check it: the
    worker read the member out of the snapshot's own index, and a delivery whose
    reported source is not the member's own digest is a delivery of something else.
    """

    member_id: str
    key: str
    sha256: Sha256Digest
    size_bytes: int
    source_sha256: Sha256Digest


@dataclass(frozen=True, slots=True)
class DeliveryProgress:
    """The worker is writing, and these objects have landed so far."""

    artifacts: tuple[DeliveredArtifact, ...] = ()
    state: Literal[OperationState.RUNNING] = OperationState.RUNNING


@dataclass(frozen=True, slots=True)
class DeliveryComplete:
    """Every member landed, and the dataset-level validator accepted the result."""

    artifacts: tuple[DeliveredArtifact, ...] = ()
    state: Literal[OperationState.SUCCEEDED] = OperationState.SUCCEEDED


@dataclass(frozen=True, slots=True)
class DeliveryFailed:
    """The delivery failed, with the code and retry policy a caller acts on."""

    failure: OperationFailure
    artifacts: tuple[DeliveredArtifact, ...] = ()
    state: Literal[OperationState.FAILED] = OperationState.FAILED


@dataclass(frozen=True, slots=True)
class DeliveryCancelled:
    """Delivery converged on a cancellation and stopped here."""

    reason: str
    artifacts: tuple[DeliveredArtifact, ...] = ()
    state: Literal[OperationState.CANCELLED] = OperationState.CANCELLED


DeliveryReport: TypeAlias = DeliveryProgress | DeliveryComplete | DeliveryFailed | DeliveryCancelled
"""Everything a delivery worker may say, tagged by the state it moves the delivery to.

Every variant carries the objects that landed before it, because a failure that
discards what it managed to deliver is what makes a retry re-upload gigabytes it
already paid for. There is no `accepted` variant: admission is the catalog's act.
"""


@dataclass(frozen=True, slots=True)
class LeasedMember:
    """One member of a sealed membership, and the two exact places it exists.

    Both coordinates are grants rather than locations: `source_url` reads the
    immutable governed object and nothing else, `upload_url` writes the one delivered
    key and nothing else. That is the whole reason a delivery executor holds no
    customer credential — the catalog is still the only place one becomes bytes, and
    what crosses this wire is the authority to move exactly these bytes to exactly
    that key, expiring on its own.
    """

    member_id: str
    sha256: Sha256Digest
    size_bytes: int
    source_url: str
    key: str
    upload_url: str

    def __post_init__(self) -> None:
        if not self.member_id.strip():
            raise DeliveryContractError("a leased member must name the member it is")
        if not self.key.strip() or self.key.endswith("/"):
            raise DeliveryContractError(
                f"leased member {self.member_id!r} must name one delivered object key"
            )
        if not self.source_url.strip() or not self.upload_url.strip():
            raise DeliveryContractError(
                f"leased member {self.member_id!r} must carry both of its grants"
            )
        if self.size_bytes < 0:
            raise DeliveryContractError(f"leased member {self.member_id!r} has negative size")


@dataclass(frozen=True, slots=True)
class DeliveryLease:
    """One delivery, whole: what it is, what it may read, and where it lands.

    Everything an executor is allowed to know, and deliberately nothing more. The
    membership is *given* — it is the snapshot's own sealed index, established at
    admission — so the worker performs no episode-id or prefix discovery and has no
    way to: there is no bucket here to list and no name to guess.

    `delivered` is what earlier attempts already wrote for this same delivery digest,
    which is what makes a retry reuse rather than re-upload. It is a fact about the
    delivery rather than about the attempt, so it arrives with the lease rather than
    being asked for separately and racing it.
    """

    delivery_id: UUID
    project_id: UUID
    executor_id: str
    generation: int
    delivery_digest: Sha256Digest
    lineage_digest: Sha256Digest
    profile: str
    accepts: SchemaId
    produces: SchemaId
    members: tuple[LeasedMember, ...]
    delivered: tuple[DeliveredArtifact, ...]
    report_key: str
    report_url: str
    expires_at: datetime

    def __post_init__(self) -> None:
        if not self.executor_id.strip():
            raise DeliveryContractError("a lease must name the executor that owns it")
        if self.generation <= 0:
            raise DeliveryContractError("a lease generation must be positive")
        if not self.members:
            raise DeliveryContractError("a lease over no member authorizes no delivery")
        ids = [member.member_id for member in self.members]
        if len(set(ids)) != len(ids):
            raise DeliveryContractError("a lease names each member of the delivery once")
        keys = [member.key for member in self.members]
        if len(set(keys)) != len(keys):
            raise DeliveryContractError(
                "two members of this delivery flatten onto one delivered key"
            )
        if not self.report_key.strip() or not self.report_url.strip():
            raise DeliveryContractError("a lease must name where the delivery report lands")
        if self.report_key in set(keys):
            raise DeliveryContractError("the delivery report is not one of the delivered members")
        stray = sorted({item.member_id for item in self.delivered} - set(ids))
        if stray:
            raise DeliveryContractError(
                f"this delivery has already-written objects for non-members {stray}"
            )
        if self.expires_at.tzinfo is None:
            raise DeliveryContractError("a lease expiry must be timezone-aware")

    @property
    def exact(self) -> bool:
        """Whether this agreement hands over its source's own bytes, unconverted.

        Derived here for the same reason `DeliveryProfile.exact` is derived there: a
        profile that accepts exactly what it produces converts nothing, so the two
        contracts already say it and a third field could disagree with them.
        """
        return self.accepts == self.produces


@dataclass(frozen=True, slots=True)
class DeliverySourceObject:
    """One immutable source object required to produce a delivery."""

    uri: str
    role: SourceObjectRole
    sha256: Sha256Digest
    size_bytes: int

    def __post_init__(self) -> None:
        if not self.uri.startswith("s3://"):
            raise ValueError("delivery source URI must use s3://")
        object.__setattr__(self, "sha256", Sha256Digest(self.sha256))
        if self.size_bytes < 0:
            raise ValueError("delivery source size_bytes must be >= 0")


@dataclass(frozen=True, slots=True)
class SourceManifest:
    """Content-addressed set of exact objects an export may consume."""

    objects: tuple[DeliverySourceObject, ...]

    def __post_init__(self) -> None:
        if not self.objects:
            raise ValueError("source manifest must contain at least one object")
        if len({item.uri for item in self.objects}) != len(self.objects):
            raise ValueError("source manifest contains duplicate object URIs")

    def sha256(self) -> str:
        payload: list[JsonValue] = [
            {
                "role": item.role.value,
                "sha256": item.sha256,
                "size_bytes": item.size_bytes,
                "uri": item.uri,
            }
            for item in sorted(self.objects, key=lambda value: value.uri)
        ]
        return content_digest(payload)


@dataclass(frozen=True, slots=True)
class SegmentSource:
    """Exact immutable inputs for one Catalog segment.

    A dataset conversion carries these records instead of bucket credentials or
    database identifiers. This keeps conversion deterministic and makes it
    possible to run the same standard converter in-process or behind a worker
    boundary without changing its contract.
    """

    segment_id: str
    manifest: SourceManifest

    def __post_init__(self) -> None:
        if not self.segment_id:
            raise DeliveryContractError("conversion segment id is empty", "conversion")


@dataclass(frozen=True, slots=True)
class StandardConversion:
    """A content-addressed request for the uncustomized standard format.

    Customer shaping is deliberately not represented here. It is a separate
    audited step over these standard artifacts, so customer-specific code can
    never silently change what ``mcap_bundle`` or ``lerobot_v3`` means.
    """

    dataset_name: str
    output_format: DeliveryFormat
    segments: tuple[SegmentSource, ...]

    def __post_init__(self) -> None:
        if not self.dataset_name:
            raise DeliveryContractError("conversion dataset name is empty", "conversion")
        if len({item.segment_id for item in self.segments}) != len(self.segments):
            raise DeliveryContractError("conversion contains duplicate segment ids", "conversion")

    def sha256(self) -> str:
        payload: dict[str, JsonValue] = {
            "dataset_name": self.dataset_name,
            "output_format": self.output_format.value,
            "segments": [
                {
                    "segment_id": item.segment_id,
                    "source_manifest_sha256": item.manifest.sha256(),
                }
                for item in sorted(self.segments, key=lambda value: value.segment_id)
            ],
        }
        return content_digest(payload)
