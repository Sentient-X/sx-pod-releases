"""Dependency-free conversation values shared by durable agent doors.

The provider and harness are deliberately absent.  These values describe what a person
said, the durable evidence an agent produced, and the lifecycle of one acknowledged turn.
Execution credentials, local paths, provider events, and resumable SDK state never belong
here.

They are not a wire.  Both conversation doors answer with
``sentientx.sx.conversations.v1``, and ``sx_conversations.wire`` is the one transform onto
it.  The ``*_to_dict``/``*_from_dict`` pair that remains is the **durable** encoding
``sx_conversations.store`` reads and writes: a message part document, a turn-event payload
document, and the message and event rows assembled from their columns.  Re-spelling one
would re-mint state already on disk, which is why they stay after the JSON wire they once
also served has gone.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Literal, NewType, TypeAlias, cast

from sx_contracts import decode
from sx_contracts.content import ArtifactId, ContentRef, ContentRefError, Sha256Digest
from sx_contracts.identity import FrozenJsonObject, FrozenJsonValue, JsonValue, freeze_json
from sx_contracts.operations import OperationContractError, OperationRef, TraceId

ConversationId = NewType("ConversationId", str)
TurnId = NewType("TurnId", str)
MessageId = NewType("MessageId", str)
PartId = NewType("PartId", str)
ToolCallId = NewType("ToolCallId", str)
EffectId = NewType("EffectId", str)
ApprovalId = NewType("ApprovalId", str)
TurnFence = NewType("TurnFence", int)
EventCursor = NewType("EventCursor", int)
MessageCursor = NewType("MessageCursor", int)
PartRevision = NewType("PartRevision", int)


class ConversationContractError(ValueError):
    """A conversation value is incomplete, malformed, or from an unknown revision."""


def decision_effect_idempotency_key(effect_id: EffectId) -> str:
    """Project one generated DecisionTurn effect onto its collision-free owner key."""

    value = str(effect_id)
    prefix = "effect-"
    if not value.startswith(prefix):
        raise ConversationContractError("DecisionTurn effect id must use the effect- namespace")
    try:
        Sha256Digest(value.removeprefix(prefix))
    except ContentRefError as error:
        raise ConversationContractError(
            "DecisionTurn effect id must contain one lowercase SHA-256 digest"
        ) from error
    return f"sx:decision:{value}"


class ConversationRole(StrEnum):
    USER = "user"
    ASSISTANT = "assistant"


class TurnState(StrEnum):
    """The complete durable lifecycle of one acknowledged agent turn."""

    ACCEPTED = "accepted"
    RUNNING = "running"
    WAITING_FOR_APPROVAL = "waiting_for_approval"
    RECONCILING = "reconciling"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"


class EffectState(StrEnum):
    """Durable knowledge about one retry-stable DecisionTurn mutation."""

    PREPARED = "prepared"
    DISPATCHED = "dispatched"
    AMBIGUOUS = "ambiguous"
    RECONCILED = "reconciled"
    SETTLED = "settled"


class ApprovalDecision(StrEnum):
    APPROVED = "approved"
    REJECTED = "rejected"


class EventKind(StrEnum):
    TURN_ACCEPTED = "turn.accepted"
    TURN_RUNNING = "turn.running"
    TURN_WAITING_FOR_APPROVAL = "turn.waiting_for_approval"
    TURN_RECONCILING = "turn.reconciling"
    TURN_CANCEL_REQUESTED = "turn.cancel_requested"
    PART_UPSERTED = "part.upserted"
    OPERATION_ATTACHED = "operation.attached"
    ARTIFACT_ATTACHED = "artifact.attached"
    TURN_SUCCEEDED = "turn.succeeded"
    TURN_FAILED = "turn.failed"
    TURN_CANCELLED = "turn.cancelled"


def _text(value: str, noun: str) -> None:
    if not value.strip():
        raise ConversationContractError(f"{noun} must not be empty")


def _identity(value: str, noun: str) -> None:
    _text(value, noun)
    if any(character.isspace() for character in value):
        raise ConversationContractError(f"{noun} must not contain whitespace")


def _aware(value: datetime, noun: str) -> None:
    if value.tzinfo is None:
        raise ConversationContractError(f"{noun} must be timezone-aware")


def _part(part_id: PartId, revision: PartRevision) -> None:
    _identity(str(part_id), "part id")
    if int(revision) < 0:
        raise ConversationContractError("part revision must not be negative")


@dataclass(frozen=True, slots=True)
class ConversationFailure:
    code: str
    message: str
    retryable: bool

    def __post_init__(self) -> None:
        _identity(self.code, "failure code")
        _text(self.message, "failure message")


@dataclass(frozen=True, slots=True)
class TextPart:
    part_id: PartId
    text: str
    revision: PartRevision = PartRevision(0)
    kind: Literal["text"] = field(default="text", init=False)

    def __post_init__(self) -> None:
        _part(self.part_id, self.revision)
        _text(self.text, "text part")


@dataclass(frozen=True, slots=True)
class ToolCallPart:
    part_id: PartId
    call_id: ToolCallId
    effect_id: EffectId
    tool_name: str
    arguments: FrozenJsonObject
    revision: PartRevision = PartRevision(0)
    kind: Literal["tool_call"] = field(default="tool_call", init=False)

    def __post_init__(self) -> None:
        _part(self.part_id, self.revision)
        _identity(str(self.call_id), "tool call id")
        _identity(str(self.effect_id), "effect id")
        _identity(self.tool_name, "tool name")
        object.__setattr__(self, "arguments", _frozen_object(self.arguments, "tool arguments"))


@dataclass(frozen=True, slots=True)
class ToolResultPart:
    part_id: PartId
    call_id: ToolCallId
    effect_id: EffectId
    result: FrozenJsonValue
    revision: PartRevision = PartRevision(0)
    kind: Literal["tool_result"] = field(default="tool_result", init=False)

    def __post_init__(self) -> None:
        _part(self.part_id, self.revision)
        _identity(str(self.call_id), "tool call id")
        _identity(str(self.effect_id), "effect id")
        object.__setattr__(self, "result", freeze_json(self.result))


@dataclass(frozen=True, slots=True)
class ToolFailurePart:
    part_id: PartId
    call_id: ToolCallId
    effect_id: EffectId
    failure: ConversationFailure
    revision: PartRevision = PartRevision(0)
    kind: Literal["tool_failure"] = field(default="tool_failure", init=False)

    def __post_init__(self) -> None:
        _part(self.part_id, self.revision)
        _identity(str(self.call_id), "tool call id")
        _identity(str(self.effect_id), "effect id")


@dataclass(frozen=True, slots=True)
class ApprovalRequestPart:
    part_id: PartId
    approval_id: ApprovalId
    call_id: ToolCallId
    effect_id: EffectId
    tool_name: str
    arguments: FrozenJsonObject
    request_sha256: Sha256Digest
    expires_at: datetime
    revision: PartRevision = PartRevision(0)
    kind: Literal["approval_request"] = field(default="approval_request", init=False)

    def __post_init__(self) -> None:
        _part(self.part_id, self.revision)
        _identity(str(self.approval_id), "approval id")
        _identity(str(self.call_id), "tool call id")
        _identity(str(self.effect_id), "effect id")
        _identity(self.tool_name, "tool name")
        object.__setattr__(self, "arguments", _frozen_object(self.arguments, "tool arguments"))
        _aware(self.expires_at, "approval expiry")


@dataclass(frozen=True, slots=True)
class ApprovalResponsePart:
    part_id: PartId
    approval_id: ApprovalId
    request_sha256: Sha256Digest
    decision: ApprovalDecision
    resolved_at: datetime
    revision: PartRevision = PartRevision(0)
    kind: Literal["approval_response"] = field(default="approval_response", init=False)

    def __post_init__(self) -> None:
        _part(self.part_id, self.revision)
        _identity(str(self.approval_id), "approval id")
        _aware(self.resolved_at, "approval resolution")


@dataclass(frozen=True, slots=True)
class OperationPart:
    part_id: PartId
    operation: OperationRef[object, object]
    revision: PartRevision = PartRevision(0)
    kind: Literal["operation"] = field(default="operation", init=False)

    def __post_init__(self) -> None:
        _part(self.part_id, self.revision)


@dataclass(frozen=True, slots=True)
class ArtifactPart:
    part_id: PartId
    artifact: ContentRef
    revision: PartRevision = PartRevision(0)
    kind: Literal["artifact"] = field(default="artifact", init=False)

    def __post_init__(self) -> None:
        _part(self.part_id, self.revision)


MessagePart: TypeAlias = (
    TextPart
    | ToolCallPart
    | ToolResultPart
    | ToolFailurePart
    | ApprovalRequestPart
    | ApprovalResponsePart
    | OperationPart
    | ArtifactPart
)


@dataclass(frozen=True, slots=True)
class ConversationMessage:
    message_id: MessageId
    turn_id: TurnId
    role: ConversationRole
    created_at: datetime
    parts: tuple[MessagePart, ...]

    def __post_init__(self) -> None:
        _identity(str(self.message_id), "message id")
        _identity(str(self.turn_id), "turn id")
        _aware(self.created_at, "message timestamp")
        if not self.parts:
            raise ConversationContractError("a conversation message must contain a part")
        part_ids = [part.part_id for part in self.parts]
        if len(set(part_ids)) != len(part_ids):
            raise ConversationContractError("a message contains each part id at most once")


@dataclass(frozen=True, slots=True)
class TurnAccepted:
    message_id: MessageId
    request_sha256: Sha256Digest
    kind: Literal[EventKind.TURN_ACCEPTED] = field(default=EventKind.TURN_ACCEPTED, init=False)

    def __post_init__(self) -> None:
        _identity(str(self.message_id), "message id")


@dataclass(frozen=True, slots=True)
class TurnRunning:
    resume_key: str | None = None
    kind: Literal[EventKind.TURN_RUNNING] = field(default=EventKind.TURN_RUNNING, init=False)

    def __post_init__(self) -> None:
        if self.resume_key is not None:
            _identity(self.resume_key, "turn resume key")


@dataclass(frozen=True, slots=True)
class TurnWaitingForApproval:
    approval_id: ApprovalId
    kind: Literal[EventKind.TURN_WAITING_FOR_APPROVAL] = field(
        default=EventKind.TURN_WAITING_FOR_APPROVAL, init=False
    )

    def __post_init__(self) -> None:
        _identity(str(self.approval_id), "approval id")


@dataclass(frozen=True, slots=True)
class TurnReconciling:
    call_id: ToolCallId
    kind: Literal[EventKind.TURN_RECONCILING] = field(
        default=EventKind.TURN_RECONCILING, init=False
    )

    def __post_init__(self) -> None:
        _identity(str(self.call_id), "tool call id")


@dataclass(frozen=True, slots=True)
class TurnCancelRequested:
    reason: str
    kind: Literal[EventKind.TURN_CANCEL_REQUESTED] = field(
        default=EventKind.TURN_CANCEL_REQUESTED, init=False
    )

    def __post_init__(self) -> None:
        _text(self.reason, "cancellation reason")


@dataclass(frozen=True, slots=True)
class PartUpserted:
    message_id: MessageId
    part: (
        TextPart
        | ToolCallPart
        | ToolResultPart
        | ToolFailurePart
        | ApprovalRequestPart
        | ApprovalResponsePart
    )
    kind: Literal[EventKind.PART_UPSERTED] = field(default=EventKind.PART_UPSERTED, init=False)

    def __post_init__(self) -> None:
        _identity(str(self.message_id), "message id")


@dataclass(frozen=True, slots=True)
class OperationAttached:
    message_id: MessageId
    part: OperationPart
    kind: Literal[EventKind.OPERATION_ATTACHED] = field(
        default=EventKind.OPERATION_ATTACHED, init=False
    )

    def __post_init__(self) -> None:
        _identity(str(self.message_id), "message id")


@dataclass(frozen=True, slots=True)
class ArtifactAttached:
    message_id: MessageId
    part: ArtifactPart
    kind: Literal[EventKind.ARTIFACT_ATTACHED] = field(
        default=EventKind.ARTIFACT_ATTACHED, init=False
    )

    def __post_init__(self) -> None:
        _identity(str(self.message_id), "message id")


@dataclass(frozen=True, slots=True)
class TurnSucceeded:
    kind: Literal[EventKind.TURN_SUCCEEDED] = field(default=EventKind.TURN_SUCCEEDED, init=False)


@dataclass(frozen=True, slots=True)
class TurnFailed:
    failure: ConversationFailure
    kind: Literal[EventKind.TURN_FAILED] = field(default=EventKind.TURN_FAILED, init=False)


@dataclass(frozen=True, slots=True)
class TurnCancelled:
    reason: str
    kind: Literal[EventKind.TURN_CANCELLED] = field(default=EventKind.TURN_CANCELLED, init=False)

    def __post_init__(self) -> None:
        _text(self.reason, "cancellation reason")


TurnEventPayload: TypeAlias = (
    TurnAccepted
    | TurnRunning
    | TurnWaitingForApproval
    | TurnReconciling
    | TurnCancelRequested
    | PartUpserted
    | OperationAttached
    | ArtifactAttached
    | TurnSucceeded
    | TurnFailed
    | TurnCancelled
)


@dataclass(frozen=True, slots=True)
class TurnEvent:
    conversation_id: ConversationId
    turn_id: TurnId
    cursor: EventCursor
    occurred_at: datetime
    trace_id: TraceId
    payload: TurnEventPayload

    def __post_init__(self) -> None:
        _identity(str(self.conversation_id), "conversation id")
        _identity(str(self.turn_id), "turn id")
        _identity(str(self.trace_id), "trace id")
        if int(self.cursor) < 1:
            raise ConversationContractError("event cursor must be positive")
        _aware(self.occurred_at, "event timestamp")


@dataclass(frozen=True, slots=True)
class TurnAdmission:
    conversation_id: ConversationId
    turn_id: TurnId
    message_id: MessageId
    request_sha256: Sha256Digest
    cursor: EventCursor
    replayed: bool
    state: Literal[TurnState.ACCEPTED] = field(default=TurnState.ACCEPTED, init=False)

    def __post_init__(self) -> None:
        _identity(str(self.conversation_id), "conversation id")
        _identity(str(self.turn_id), "turn id")
        _identity(str(self.message_id), "message id")
        if int(self.cursor) < 1:
            raise ConversationContractError("admission cursor must be positive")


@dataclass(frozen=True, slots=True)
class MessagePage:
    messages: tuple[ConversationMessage, ...]
    next_before: MessageCursor | None

    def __post_init__(self) -> None:
        if self.next_before is not None and int(self.next_before) < 1:
            raise ConversationContractError("message page cursor must be positive")


@dataclass(frozen=True, slots=True)
class EventBatch:
    events: tuple[TurnEvent, ...]
    latest_cursor: EventCursor
    history_gap: Literal[False] = field(default=False, init=False)

    def __post_init__(self) -> None:
        if int(self.latest_cursor) < 0:
            raise ConversationContractError("latest event cursor must not be negative")
        cursors = tuple(int(event.cursor) for event in self.events)
        if cursors != tuple(sorted(cursors)) or len(set(cursors)) != len(cursors):
            raise ConversationContractError("event pages must be strictly cursor-ordered")
        if cursors and cursors[-1] > int(self.latest_cursor):
            raise ConversationContractError("an event page cannot exceed its latest cursor")


@dataclass(frozen=True, slots=True)
class ActiveTurnSnapshot:
    turn_id: TurnId
    state: TurnState
    cancel_requested: bool
    pending_approval_id: ApprovalId | None

    def __post_init__(self) -> None:
        _identity(str(self.turn_id), "turn id")
        if self.state in {TurnState.SUCCEEDED, TurnState.FAILED, TurnState.CANCELLED}:
            raise ConversationContractError("an active-turn snapshot cannot be terminal")
        if (
            self.pending_approval_id is not None
            and self.state is not TurnState.WAITING_FOR_APPROVAL
        ):
            raise ConversationContractError("only a waiting turn can expose a pending approval")


@dataclass(frozen=True, slots=True)
class EventHistoryGap:
    latest_cursor: EventCursor
    snapshot: tuple[ConversationMessage, ...]
    active_turn: ActiveTurnSnapshot | None
    history_gap: Literal[True] = field(default=True, init=False)

    def __post_init__(self) -> None:
        if int(self.latest_cursor) < 0:
            raise ConversationContractError("history-gap cursor must not be negative")


EventPage: TypeAlias = EventBatch | EventHistoryGap


@dataclass(frozen=True, slots=True)
class ApprovalResponse:
    approval_id: ApprovalId
    request_sha256: Sha256Digest
    decision: ApprovalDecision

    def __post_init__(self) -> None:
        _identity(str(self.approval_id), "approval id")


@dataclass(frozen=True, slots=True)
class TurnCancellation:
    reason: str

    def __post_init__(self) -> None:
        _text(self.reason, "cancellation reason")


def _instant(moment: datetime) -> str:
    """One instant, one spelling — the durable encoding cannot carry an offset.

    These strings are *compared as bytes*: `sx_conversations.store` refuses a part whose
    revision did not advance but whose canonical document did. A bare `isoformat()` spells
    the same instant differently depending on the offset its datetime happens to hold, and
    Postgres hands a `timestamptz` back in the session time zone — so a settlement written
    as `…+00:00` and replayed as `…-07:00` was one instant and two documents, which the
    store then read as a conflicting rewrite. Normalising to UTC here makes the encoding a
    function of the instant alone, and re-canonicalises every row already written.
    """

    return moment.astimezone(UTC).isoformat()


def message_part_to_dict(part: MessagePart) -> dict[str, JsonValue]:
    base: dict[str, JsonValue] = {
        "kind": part.kind,
        "part_id": str(part.part_id),
        "revision": int(part.revision),
    }
    if isinstance(part, TextPart):
        return {**base, "text": part.text}
    if isinstance(part, ToolCallPart):
        return {
            **base,
            "call_id": str(part.call_id),
            "effect_id": str(part.effect_id),
            "tool_name": part.tool_name,
            "arguments": part.arguments,
        }
    if isinstance(part, ToolResultPart):
        return {
            **base,
            "call_id": str(part.call_id),
            "effect_id": str(part.effect_id),
            "result": part.result,
        }
    if isinstance(part, ToolFailurePart):
        return {
            **base,
            "call_id": str(part.call_id),
            "effect_id": str(part.effect_id),
            "failure": _failure_to_dict(part.failure),
        }
    if isinstance(part, ApprovalRequestPart):
        return {
            **base,
            "approval_id": str(part.approval_id),
            "call_id": str(part.call_id),
            "effect_id": str(part.effect_id),
            "tool_name": part.tool_name,
            "arguments": part.arguments,
            "request_sha256": str(part.request_sha256),
            "expires_at": _instant(part.expires_at),
        }
    if isinstance(part, ApprovalResponsePart):
        return {
            **base,
            "approval_id": str(part.approval_id),
            "request_sha256": str(part.request_sha256),
            "decision": part.decision.value,
            "resolved_at": _instant(part.resolved_at),
        }
    if isinstance(part, OperationPart):
        return {**base, "operation": str(part.operation)}
    return {
        **base,
        "artifact": {
            "artifact_id": str(part.artifact.artifact_id),
            "sha256": str(part.artifact.sha256),
        },
    }


def message_part_from_dict(value: object) -> MessagePart:
    doc = decode.document(value, where="conversation part", error=ConversationContractError)
    kind = decode.text(doc, "kind")
    common = {"kind", "part_id", "revision"}
    part_id = PartId(decode.text(doc, "part_id"))
    revision = PartRevision(decode.integer(doc, "revision"))
    try:
        if kind == "text":
            doc = decode.exactly(doc, common | {"text"})
            return TextPart(part_id, decode.text(doc, "text"), revision)
        if kind == "tool_call":
            doc = decode.exactly(doc, common | {"call_id", "effect_id", "tool_name", "arguments"})
            arguments = _frozen_object(decode.mapping(doc, "arguments"), "tool arguments")
            return ToolCallPart(
                part_id,
                ToolCallId(decode.text(doc, "call_id")),
                EffectId(decode.text(doc, "effect_id")),
                decode.text(doc, "tool_name"),
                arguments,
                revision,
            )
        if kind == "tool_result":
            doc = decode.exactly(doc, common | {"call_id", "effect_id", "result"})
            return ToolResultPart(
                part_id,
                ToolCallId(decode.text(doc, "call_id")),
                EffectId(decode.text(doc, "effect_id")),
                freeze_json(doc["result"]),
                revision,
            )
        if kind == "tool_failure":
            doc = decode.exactly(doc, common | {"call_id", "effect_id", "failure"})
            return ToolFailurePart(
                part_id,
                ToolCallId(decode.text(doc, "call_id")),
                EffectId(decode.text(doc, "effect_id")),
                _failure_from_dict(decode.mapping(doc, "failure")),
                revision,
            )
        if kind == "approval_request":
            doc = decode.exactly(
                doc,
                common
                | {
                    "approval_id",
                    "call_id",
                    "effect_id",
                    "tool_name",
                    "arguments",
                    "request_sha256",
                    "expires_at",
                },
            )
            return ApprovalRequestPart(
                part_id,
                ApprovalId(decode.text(doc, "approval_id")),
                ToolCallId(decode.text(doc, "call_id")),
                EffectId(decode.text(doc, "effect_id")),
                decode.text(doc, "tool_name"),
                _frozen_object(decode.mapping(doc, "arguments"), "tool arguments"),
                Sha256Digest(decode.text(doc, "request_sha256")),
                _timestamp(decode.text(doc, "expires_at"), "approval expiry"),
                revision,
            )
        if kind == "approval_response":
            doc = decode.exactly(
                doc,
                common | {"approval_id", "request_sha256", "decision", "resolved_at"},
            )
            return ApprovalResponsePart(
                part_id,
                ApprovalId(decode.text(doc, "approval_id")),
                Sha256Digest(decode.text(doc, "request_sha256")),
                ApprovalDecision(decode.text(doc, "decision")),
                _timestamp(decode.text(doc, "resolved_at"), "approval resolution"),
                revision,
            )
        if kind == "operation":
            doc = decode.exactly(doc, common | {"operation"})
            return OperationPart(
                part_id,
                OperationRef.parse(decode.text(doc, "operation")),
                revision,
            )
        if kind == "artifact":
            doc = decode.exactly(doc, common | {"artifact"})
            artifact = decode.exactly(decode.mapping(doc, "artifact"), {"artifact_id", "sha256"})
            return ArtifactPart(
                part_id,
                ContentRef(
                    ArtifactId(decode.text(artifact, "artifact_id")),
                    Sha256Digest(decode.text(artifact, "sha256")),
                ),
                revision,
            )
    except (ValueError, ContentRefError, OperationContractError) as error:
        if isinstance(error, ConversationContractError):
            raise
        raise ConversationContractError(str(error)) from error
    raise ConversationContractError(f"unknown conversation part kind: {kind!r}")


def conversation_message_from_dict(value: object) -> ConversationMessage:
    doc = decode.exactly(
        value,
        {"message_id", "turn_id", "role", "created_at", "parts"},
        where="conversation message",
        error=ConversationContractError,
    )
    try:
        return ConversationMessage(
            MessageId(decode.text(doc, "message_id")),
            TurnId(decode.text(doc, "turn_id")),
            ConversationRole(decode.text(doc, "role")),
            _timestamp(decode.text(doc, "created_at"), "message timestamp"),
            tuple(message_part_from_dict(part) for part in decode.sequence(doc, "parts")),
        )
    except ValueError as error:
        if isinstance(error, ConversationContractError):
            raise
        raise ConversationContractError(str(error)) from error


def turn_event_from_dict(value: object) -> TurnEvent:
    doc = decode.exactly(
        value,
        {"conversation_id", "turn_id", "cursor", "occurred_at", "trace_id", "payload"},
        where="turn event",
        error=ConversationContractError,
    )
    return TurnEvent(
        ConversationId(decode.text(doc, "conversation_id")),
        TurnId(decode.text(doc, "turn_id")),
        EventCursor(decode.integer(doc, "cursor")),
        _timestamp(decode.text(doc, "occurred_at"), "event timestamp"),
        TraceId(decode.text(doc, "trace_id")),
        turn_event_payload_from_dict(decode.mapping(doc, "payload")),
    )


def turn_event_payload_to_dict(payload: TurnEventPayload) -> dict[str, JsonValue]:
    if isinstance(payload, TurnAccepted):
        return {
            "kind": payload.kind.value,
            "message_id": str(payload.message_id),
            "request_sha256": str(payload.request_sha256),
        }
    if isinstance(payload, TurnRunning):
        return {"kind": payload.kind.value, "resume_key": payload.resume_key}
    if isinstance(payload, TurnSucceeded):
        return {"kind": payload.kind.value}
    if isinstance(payload, TurnWaitingForApproval):
        return {"kind": payload.kind.value, "approval_id": str(payload.approval_id)}
    if isinstance(payload, TurnReconciling):
        return {"kind": payload.kind.value, "call_id": str(payload.call_id)}
    if isinstance(payload, TurnCancelRequested):
        return {"kind": payload.kind.value, "reason": payload.reason}
    if isinstance(payload, PartUpserted | OperationAttached | ArtifactAttached):
        return {
            "kind": payload.kind.value,
            "message_id": str(payload.message_id),
            "part": message_part_to_dict(payload.part),
        }
    if isinstance(payload, TurnFailed):
        return {"kind": payload.kind.value, "failure": _failure_to_dict(payload.failure)}
    return {"kind": payload.kind.value, "reason": payload.reason}


def turn_event_payload_from_dict(value: object) -> TurnEventPayload:
    doc = decode.document(value, where="turn event payload", error=ConversationContractError)
    kind = decode.text(doc, "kind")
    try:
        event_kind = EventKind(kind)
    except ValueError as error:
        raise ConversationContractError(f"unknown turn event kind: {kind!r}") from error
    if event_kind is EventKind.TURN_ACCEPTED:
        doc = decode.exactly(doc, {"kind", "message_id", "request_sha256"})
        return TurnAccepted(
            MessageId(decode.text(doc, "message_id")),
            Sha256Digest(decode.text(doc, "request_sha256")),
        )
    if event_kind is EventKind.TURN_RUNNING:
        doc = decode.exactly(doc, {"kind", "resume_key"})
        raw_resume = doc["resume_key"]
        if raw_resume is not None and not isinstance(raw_resume, str):
            raise ConversationContractError("turn resume key must be a string or null")
        return TurnRunning(raw_resume)
    if event_kind is EventKind.TURN_WAITING_FOR_APPROVAL:
        doc = decode.exactly(doc, {"kind", "approval_id"})
        return TurnWaitingForApproval(ApprovalId(decode.text(doc, "approval_id")))
    if event_kind is EventKind.TURN_RECONCILING:
        doc = decode.exactly(doc, {"kind", "call_id"})
        return TurnReconciling(ToolCallId(decode.text(doc, "call_id")))
    if event_kind is EventKind.TURN_CANCEL_REQUESTED:
        doc = decode.exactly(doc, {"kind", "reason"})
        return TurnCancelRequested(decode.text(doc, "reason"))
    if event_kind is EventKind.PART_UPSERTED:
        doc = decode.exactly(doc, {"kind", "message_id", "part"})
        part = message_part_from_dict(doc["part"])
        if isinstance(part, OperationPart | ArtifactPart):
            raise ConversationContractError(
                "operation and artifact parts use their attachment event"
            )
        return PartUpserted(MessageId(decode.text(doc, "message_id")), part)
    if event_kind is EventKind.OPERATION_ATTACHED:
        doc = decode.exactly(doc, {"kind", "message_id", "part"})
        operation = message_part_from_dict(doc["part"])
        if not isinstance(operation, OperationPart):
            raise ConversationContractError("operation attachment must carry an operation part")
        return OperationAttached(MessageId(decode.text(doc, "message_id")), operation)
    if event_kind is EventKind.ARTIFACT_ATTACHED:
        doc = decode.exactly(doc, {"kind", "message_id", "part"})
        artifact = message_part_from_dict(doc["part"])
        if not isinstance(artifact, ArtifactPart):
            raise ConversationContractError("artifact attachment must carry an artifact part")
        return ArtifactAttached(MessageId(decode.text(doc, "message_id")), artifact)
    if event_kind is EventKind.TURN_SUCCEEDED:
        decode.exactly(doc, {"kind"})
        return TurnSucceeded()
    if event_kind is EventKind.TURN_FAILED:
        doc = decode.exactly(doc, {"kind", "failure"})
        return TurnFailed(_failure_from_dict(decode.mapping(doc, "failure")))
    doc = decode.exactly(doc, {"kind", "reason"})
    return TurnCancelled(decode.text(doc, "reason"))


def _failure_to_dict(failure: ConversationFailure) -> dict[str, JsonValue]:
    return {
        "code": failure.code,
        "message": failure.message,
        "retryable": failure.retryable,
    }


def _failure_from_dict(value: object) -> ConversationFailure:
    doc = decode.exactly(value, {"code", "message", "retryable"})
    return ConversationFailure(
        decode.text(doc, "code"),
        decode.text(doc, "message"),
        decode.boolean(doc, "retryable"),
    )


def _frozen_object(value: object, noun: str) -> FrozenJsonObject:
    frozen = freeze_json(value)
    if not isinstance(frozen, Mapping):
        raise ConversationContractError(f"{noun} must be an object")
    return cast("FrozenJsonObject", frozen)


def _timestamp(value: str, noun: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError as error:
        raise ConversationContractError(f"{noun} must be an ISO-8601 timestamp") from error
    _aware(parsed, noun)
    return parsed
