"""Provider-neutral requests and terminal results for platform compute.

The owning pillar still owns the public operation.  This boundary says only what
that operation needs executed and what immutable Catalog artifacts came back; cloud
placement, vendor job ids, credentials, attempts, and billing rows remain private to
the compute control plane.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Literal, NewType, TypeAlias

from sx_contracts.content import ContentRef
from sx_contracts.images import BoundImage
from sx_contracts.operations import (
    IdempotencyKey,
    OperationFailure,
    OperationKind,
    OperationRef,
    OperationState,
)
from sx_contracts.pipelines import Resources
from sx_contracts.runtime import Runtime

ComputeExecutionId = NewType("ComputeExecutionId", str)
MAX_PLACEMENT_SECONDS = 24 * 60 * 60
MAX_RUNTIME_SECONDS = 31 * 24 * 60 * 60
MAX_RECOVERY_ATTEMPTS = 10


class ComputeExecutionState(StrEnum):
    """Provider-neutral finite lifecycle exposed to the owning operation."""

    ACCEPTED = "accepted"
    SUBMITTING = "submitting"
    RUNNING = "running"
    FINALIZING = "finalizing"
    CANCELLING = "cancelling"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"

    @property
    def terminal(self) -> bool:
        return self in {self.SUCCEEDED, self.FAILED, self.CANCELLED}


class ComputeContractError(ValueError):
    """A compute request or terminal result is incomplete or inconsistent."""


class ComputeWorkloadKind(StrEnum):
    TRAIN = "train"
    EVALUATION = "evaluation"
    GENERATION = "generation"
    BATCH_SHARD = "batch_shard"
    OFFLINE_INFERENCE = "offline_inference"
    RL_MONOLITH = "rl_monolith"


class ComputeOutputKind(StrEnum):
    """The transport slot an output occupies, not its semantic Catalog type.

    Bytes remain an attested compute product until the owning pillar submits them to
    the existing checkpoint, policy, episode, or model registration validator.
    """

    TRAINING_CHECKPOINT_CANDIDATE = "training_checkpoint_candidate"
    EVALUATION_BUNDLE = "evaluation_bundle"
    EPISODE_RRD_CANDIDATE = "episode_rrd_candidate"
    BATCH_RESULT_BUNDLE = "batch_result_bundle"
    MODEL_ARTIFACT_CANDIDATE = "model_artifact_candidate"


class ComputeNetwork(StrEnum):
    STANDARD = "standard"
    INFINIBAND = "infiniband"


class ComputeCapacity(StrEnum):
    ON_DEMAND = "on_demand"
    SPOT_PREFERRED = "spot_preferred"
    SPOT_REQUIRED = "spot_required"


@dataclass(frozen=True, slots=True)
class ComputeResources:
    """The homogeneous shape of one execution.

    ``Resources`` remains the canonical per-node declaration used by scheduling and
    metering.  This value adds only the genuinely distributed facts it cannot express.
    """

    nodes: int
    per_node: Resources
    network: ComputeNetwork = ComputeNetwork.STANDARD
    capacity: ComputeCapacity = ComputeCapacity.ON_DEMAND

    def __post_init__(self) -> None:
        if isinstance(self.nodes, bool) or self.nodes < 1:
            raise ComputeContractError(f"compute nodes are counted from 1: {self.nodes!r}")


@dataclass(frozen=True, slots=True)
class ComputeRequest:
    """One immutable request crossing from an owning pillar into compute.

    The authenticated boundary stamps the project.  A request cannot choose a cloud,
    carry a command, or carry credentials; the digest-bound image owns its entrypoint.
    """

    operation: OperationRef[object, object]
    idempotency_key: IdempotencyKey
    workload: ComputeWorkloadKind
    runtime: BoundImage
    inputs: tuple[ContentRef, ...]
    expected_outputs: tuple[ComputeOutputKind, ...]
    resources: ComputeResources
    max_placement_s: int
    max_runtime_s: int
    recovery_limit: int = 0

    def __post_init__(self) -> None:
        if self.operation.kind is OperationKind.SESSION:
            raise ComputeContractError(
                "session operations cannot use ComputeRequest; use the ephemeral "
                "session allocation contract"
            )
        if not str(self.idempotency_key).strip():
            raise ComputeContractError("compute idempotency key must not be empty")
        if not self.expected_outputs:
            raise ComputeContractError("compute must declare at least one expected output")
        if len(set(self.expected_outputs)) != len(self.expected_outputs):
            raise ComputeContractError("compute expected output kinds must be unique")
        canonical_outputs = tuple(sorted(self.expected_outputs, key=lambda kind: kind.value))
        if canonical_outputs != self.expected_outputs:
            raise ComputeContractError("compute expected output kinds must be canonically sorted")
        inputs = [(str(item.artifact_id), str(item.sha256)) for item in self.inputs]
        if len(set(inputs)) != len(inputs):
            raise ComputeContractError("compute inputs must be unique")
        if (
            isinstance(self.max_placement_s, bool)
            or not 1 <= self.max_placement_s <= MAX_PLACEMENT_SECONDS
        ):
            raise ComputeContractError(
                f"compute placement deadline must be 1..{MAX_PLACEMENT_SECONDS} seconds"
            )
        if (
            isinstance(self.max_runtime_s, bool)
            or not 1 <= self.max_runtime_s <= MAX_RUNTIME_SECONDS
        ):
            raise ComputeContractError(
                f"compute runtime limit must be 1..{MAX_RUNTIME_SECONDS} seconds"
            )
        if (
            isinstance(self.recovery_limit, bool)
            or not 0 <= self.recovery_limit <= MAX_RECOVERY_ATTEMPTS
        ):
            raise ComputeContractError(f"compute recovery limit must be 0..{MAX_RECOVERY_ATTEMPTS}")


@dataclass(frozen=True, slots=True)
class ComputeOutput:
    """One expected output slot bound to storage-attested immutable bytes."""

    kind: ComputeOutputKind
    content: ContentRef


def _execution_id(value: ComputeExecutionId) -> None:
    if not str(value).strip():
        raise ComputeContractError("compute execution id must not be empty")


def _opaque_capability(value: str, *, direction: str) -> None:
    if not value.strip():
        raise ComputeContractError(f"compute {direction} capability must not be empty")


@dataclass(frozen=True, slots=True)
class ComputeInputGrant:
    """One immutable input and the opaque capability that reads its exact bytes."""

    content: ContentRef
    get_url: str

    def __post_init__(self) -> None:
        _opaque_capability(self.get_url, direction="input GET")


@dataclass(frozen=True, slots=True)
class ComputeOutputGrant:
    """One expected output slot and its bounded opaque write capability."""

    kind: ComputeOutputKind
    put_url: str
    max_bytes: int

    def __post_init__(self) -> None:
        _opaque_capability(self.put_url, direction="output PUT")
        if isinstance(self.max_bytes, bool) or self.max_bytes < 1:
            raise ComputeContractError("compute output grant max_bytes must be positive")


@dataclass(frozen=True, slots=True)
class ComputeLease:
    """A fenced execution plus the complete capabilities needed to run its request.

    URLs are deliberately opaque strings: this contract neither parses their provider
    nor turns them into durable identity. The client boundary may keep them secret and
    must never persist them in an operation or artifact.
    """

    execution_id: ComputeExecutionId
    generation: int
    expires_at: datetime
    request: ComputeRequest
    input_grants: tuple[ComputeInputGrant, ...]
    output_grants: tuple[ComputeOutputGrant, ...]

    def __post_init__(self) -> None:
        _execution_id(self.execution_id)
        if isinstance(self.generation, bool) or self.generation < 1:
            raise ComputeContractError("compute lease generation is counted from 1")
        if self.expires_at.tzinfo is None:
            raise ComputeContractError("compute lease expiry must be timezone-aware")
        if tuple(grant.content for grant in self.input_grants) != self.request.inputs:
            raise ComputeContractError("compute input grants must exactly cover request inputs")
        if tuple(grant.kind for grant in self.output_grants) != self.request.expected_outputs:
            raise ComputeContractError(
                "compute output grants must exactly cover request expected outputs"
            )


@dataclass(frozen=True, slots=True)
class ComputeOutputReceipt:
    """The bytes written into one output grant, before Catalog finalizes them."""

    kind: ComputeOutputKind
    content: ContentRef
    size_bytes: int

    def __post_init__(self) -> None:
        if isinstance(self.size_bytes, bool) or self.size_bytes < 0:
            raise ComputeContractError("compute output receipt size_bytes must be non-negative")


@dataclass(frozen=True, slots=True)
class ComputeFinalized:
    """Storage-attested outputs for one fenced execution generation.

    Finalization proves digest, size, lease coverage, and promotion. It deliberately
    does not claim checkpoint/RRD/policy semantics; the owning pillar's existing typed
    registration path performs that validation and records lineage.
    """

    execution_id: ComputeExecutionId
    generation: int
    outputs: tuple[ComputeOutput, ...]

    def __post_init__(self) -> None:
        _execution_id(self.execution_id)
        if isinstance(self.generation, bool) or self.generation < 1:
            raise ComputeContractError("compute finalization generation is counted from 1")
        if not self.outputs:
            raise ComputeContractError("compute finalization must contain at least one output")
        kinds = [output.kind for output in self.outputs]
        if len(set(kinds)) != len(kinds):
            raise ComputeContractError("compute finalized output kinds must be unique")


@dataclass(frozen=True, slots=True)
class ComputeSucceeded:
    execution_id: ComputeExecutionId
    finalization: ComputeFinalized
    runtime: Runtime
    state: Literal[OperationState.SUCCEEDED] = field(default=OperationState.SUCCEEDED, init=False)

    def __post_init__(self) -> None:
        _execution_id(self.execution_id)
        if self.finalization.execution_id != self.execution_id:
            raise ComputeContractError(
                "successful compute finalization belongs to another execution"
            )

    @property
    def outputs(self) -> tuple[ComputeOutput, ...]:
        return self.finalization.outputs


@dataclass(frozen=True, slots=True)
class ComputeFailed:
    execution_id: ComputeExecutionId
    failure: OperationFailure
    state: Literal[OperationState.FAILED] = field(default=OperationState.FAILED, init=False)

    def __post_init__(self) -> None:
        _execution_id(self.execution_id)


@dataclass(frozen=True, slots=True)
class ComputeCancelled:
    execution_id: ComputeExecutionId
    reason: str
    teardown_confirmed_at: datetime
    state: Literal[OperationState.CANCELLED] = field(default=OperationState.CANCELLED, init=False)

    def __post_init__(self) -> None:
        _execution_id(self.execution_id)
        if not self.reason.strip():
            raise ComputeContractError("compute cancellation reason must not be empty")
        if self.teardown_confirmed_at.tzinfo is None:
            raise ComputeContractError("compute teardown confirmation must be timezone-aware")


ComputeResult: TypeAlias = ComputeSucceeded | ComputeFailed | ComputeCancelled
"""Every terminal answer from compute; accepted/running stay on the owning operation."""
