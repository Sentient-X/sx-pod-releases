"""The calibrated alarm: a threshold that states its own false-alarm rate.

Every escalation gate in the stack used to be a number somebody picked. `max_entropy=2.0`,
`confidence_threshold=0.5`, `floor=0.0` — each one a claim about when a run has gone wrong,
and not one of them able to say how often it would be wrong about that. A ladder built from
such numbers is tuned by watching it misfire, which means the tuning is only ever as good as
the failures already seen.

A :class:`NominalBand` is the same decision with the number derived instead of chosen. Fit it
on episodes that went *well*, and it answers one question — *is this monitor's score still
inside the envelope nominal episodes occupy?* — with a distribution-free guarantee attached:

    **Coverage.** For a nominal episode exchangeable with the ones it was fit on, the
    probability that its score never crosses the band anywhere in the episode is at least
    ``1 - alpha``.

So `alpha` is the false-alarm rate the operator asks for, and the thresholds are whatever
delivers it. That is the whole inversion: you state the error you will tolerate, not the
number you hope produces it.

Three properties of the construction earn their place, and each is a test:

* The band is **time-indexed**. A monitor's nominal envelope is not flat — early steps of an
  episode look alike and late ones diverge — so a scalar threshold is either deaf early or
  jumpy late. The guarantee is over the *whole trajectory* at once, not per step, which is why
  a band and not a sequence of independent thresholds.
* The band is **one-sided**, upper. Only "worse than nominal" is an alarm. A monitor whose
  bad direction is downward negates at its own boundary (a value floor becomes a value
  *deficit*), so this module has no direction flag and no second code path.
* The band is **content-addressed**. It is a fitted artifact with lineage — which episodes,
  which alpha — not a config literal, so :attr:`NominalBand.ref` identifies the exact
  calibration a deployment ran under.

What lives elsewhere: how the monitor score is computed and whether it accumulates (that is
the monitor's business — this calibrates whatever trajectory it is handed), and how the fit
set is grouped by task, fleet, or embodiment (that is the caller's, who assembles it).

Rederived from Diquigiovanni, Fontana and Vantini, *The Importance of Being a Band:
Finite-Sample Exact Distribution-Free Prediction Sets for Functional Data*
(arXiv:2102.06746), whose one-sided construction this implements directly. The robotics
application — calibrating a VLA failure monitor rather than a forecast — follows RL²-VLA
(arXiv:2607.26991); see `docs/plans/archive/rl2-vla-fusion-2026-08.md` for what was and
was not adopted, including why no code from that lineage is vendored here.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from math import ceil, isfinite
from typing import Final

from sx_contracts.identity import JsonValue, content_id
from sx_contracts.wire import HexDigest

__all__ = [
    "CalibrationError",
    "CalibrationId",
    "NominalBand",
    "fit_nominal_band",
]

_SHAPE_FRACTION: Final = 0.3
"""Share of the nominal set spent on the band's shape; the rest calibrates its width.

Two disjoint roles, and they must stay disjoint: trajectories that shaped the band cannot
also certify how often it is crossed, or the guarantee is measured against data the band was
drawn to fit.
"""

_MODULATION_FLOOR: Final = 1e-12
"""Keeps the width finite when nominal episodes agree exactly at some step.

Without it a step where every nominal trajectory took the same value divides by zero. With
it, such a step admits essentially no deviation — which is the honest reading of "every
nominal episode did exactly this here".
"""


class CalibrationError(ValueError):
    """A calibration input, or the guarantee asked of it, is not attainable."""


class CalibrationId(HexDigest):
    """The content identity of one fitted band."""

    error = CalibrationError
    noun = "calibration id"


@dataclass(frozen=True, slots=True)
class NominalBand:
    """A time-indexed alarm threshold carrying the false-alarm rate it was fit for.

    Higher scores mean *less* nominal, always. A monitor whose bad direction is downward
    negates before it gets here, so :meth:`alarms` has one comparison and no mode.
    """

    alpha: float
    """The false-alarm rate this band was calibrated for: the most nominal episodes it may
    flag, as a fraction."""

    thresholds: tuple[float, ...]
    """The alarm threshold at each step, from the episode's first decision point."""

    nominal_episodes: int
    """How many nominal trajectories were fit — the evidence behind the guarantee."""

    def __post_init__(self) -> None:
        if not 0.0 < self.alpha < 1.0:
            raise CalibrationError(f"alpha must lie in (0, 1), got {self.alpha}")
        if not self.thresholds:
            raise CalibrationError("a band covers at least one step")
        if not all(isfinite(threshold) for threshold in self.thresholds):
            raise CalibrationError("every band threshold must be finite")
        if self.nominal_episodes < 1:
            raise CalibrationError("a band is fit from at least one nominal episode")

    @property
    def steps(self) -> int:
        """How many steps the band was calibrated over."""
        return len(self.thresholds)

    def threshold(self, step: int) -> float:
        """The alarm threshold at ``step``, held flat past the calibrated horizon.

        An episode running longer than any it was calibrated on is outside the guarantee —
        there is no nominal evidence out there to have derived a threshold from. Holding the
        last one is the conservative reading (the envelope stops widening, so the alarm stays
        at least as sensitive), and :attr:`steps` is what a caller checks to know it happened.
        """
        if step < 0:
            raise CalibrationError(f"a step index is non-negative, got {step}")
        return self.thresholds[min(step, len(self.thresholds) - 1)]

    def alarms(self, step: int, score: float) -> bool:
        """Whether ``score`` has left the nominal envelope at ``step``."""
        if not isfinite(score):
            raise CalibrationError(f"a monitor score must be finite, got {score}")
        return score >= self.threshold(step)

    def _content_dict(self) -> dict[str, JsonValue]:
        return {
            "schema": "sx.nominal-band/v1",
            "alpha": self.alpha,
            "nominal_episodes": self.nominal_episodes,
            "thresholds": list(self.thresholds),
        }

    @property
    def ref(self) -> CalibrationId:
        """The content identity of this exact calibration."""
        return content_id(CalibrationId, self._content_dict())


def fit_nominal_band(nominal: Sequence[Sequence[float]], alpha: float) -> NominalBand:
    """Fit the band whose false-alarm rate on nominal episodes is at most ``alpha``.

    ``nominal`` is one monitor-score trajectory per episode that went well — the population
    the alarm is defined against. Failed episodes are deliberately not passed: a band
    describes what normal looks like, and mixing failures in would widen it to admit them.

    The construction, in four steps. Shorter trajectories are extended with their final value
    so every episode indexes the same steps. The first 30% of them give the
    band its *shape* — a centre trajectory and a modulation trajectory saying how much
    spread each step normally carries. The remainder give it its *width*: each contributes
    its worst modulation-normalized excursion above the centre, and the width is the
    ``ceil((n + 1) * (1 - alpha))``-th smallest of those. That exact rank, rather than a
    plain quantile, is what makes the coverage guarantee finite-sample rather than asymptotic
    — and it is why too few calibration episodes for the requested ``alpha`` is refused here
    instead of answered with a number that guarantees nothing.

    Raises:
        CalibrationError: the trajectories are unusable, or ``alpha`` is finer than
            ``1 / (calibration episodes + 1)`` and so cannot be certified by this many
            episodes.
    """
    if not 0.0 < alpha < 1.0:
        raise CalibrationError(f"alpha must lie in (0, 1), got {alpha}")
    trajectories = _aligned(nominal)

    split = max(1, int(len(trajectories) * _SHAPE_FRACTION))
    shape, calibration = trajectories[:split], trajectories[split:]
    if not calibration:
        raise CalibrationError(
            f"fitting a band needs episodes for its shape and others for its width; "
            f"{len(trajectories)} nominal episodes leave none to calibrate with"
        )

    centre = tuple(sum(values) / len(shape) for values in zip(*shape, strict=True))
    modulation = _modulation(shape, centre, alpha)

    excursions = sorted(
        max(
            (value - middle) / spread
            for value, middle, spread in zip(trajectory, centre, modulation, strict=True)
        )
        for trajectory in calibration
    )
    rank = ceil((len(excursions) + 1) * (1.0 - alpha))
    if rank > len(excursions):
        raise CalibrationError(
            f"a false-alarm rate of {alpha} needs at least {ceil(1 / alpha) - 1} calibration "
            f"episodes and this fit has {len(excursions)}; the finest rate {len(excursions)} "
            f"episodes can certify is {1 / (len(excursions) + 1):.4f}"
        )
    width = excursions[rank - 1]

    return NominalBand(
        alpha=alpha,
        thresholds=tuple(
            middle + width * spread for middle, spread in zip(centre, modulation, strict=True)
        ),
        nominal_episodes=len(trajectories),
    )


def _aligned(nominal: Sequence[Sequence[float]]) -> tuple[tuple[float, ...], ...]:
    """Every trajectory over one step index, short ones held at their final value.

    Episodes end when they end, so a nominal set is ragged. Extending with the last observed
    value — rather than truncating to the shortest — keeps the late steps a long episode
    actually visited, which is where a monitor's envelope is widest and an alarm most needs
    calibrating.
    """
    if not nominal:
        raise CalibrationError("fitting a band needs at least one nominal episode")
    if any(not trajectory for trajectory in nominal):
        raise CalibrationError("a nominal episode covers at least one step")
    for trajectory in nominal:
        if not all(isfinite(score) for score in trajectory):
            raise CalibrationError("every nominal monitor score must be finite")
    steps = max(len(trajectory) for trajectory in nominal)
    return tuple(
        tuple(trajectory) + (trajectory[-1],) * (steps - len(trajectory)) for trajectory in nominal
    )


def _modulation(
    shape: Sequence[Sequence[float]], centre: Sequence[float], alpha: float
) -> tuple[float, ...]:
    """How much spread each step normally carries — the band's shape, before its width.

    The envelope follows the data's own shape rather than sitting parallel to the centre: a
    step where nominal episodes disagree tolerates more before it alarms. Episodes whose worst
    deviation is itself extreme are dropped first, so one wild-but-successful run cannot
    inflate the envelope everywhere and blind the alarm.
    """
    deviations = [
        tuple(abs(value - middle) for value, middle in zip(trajectory, centre, strict=True))
        for trajectory in shape
    ]
    worst = [max(deviation) for deviation in deviations]
    rank = ceil((len(worst) + 1) * (1.0 - alpha))
    if rank > len(worst):
        kept = deviations  # too few to trim: every episode's shape counts
    else:
        gamma = sorted(worst)[rank - 1]
        kept = [
            deviation
            for deviation, extreme in zip(deviations, worst, strict=True)
            if extreme <= gamma
        ]
    return tuple(
        max(step_deviations) + _MODULATION_FLOOR for step_deviations in zip(*kept, strict=True)
    )
