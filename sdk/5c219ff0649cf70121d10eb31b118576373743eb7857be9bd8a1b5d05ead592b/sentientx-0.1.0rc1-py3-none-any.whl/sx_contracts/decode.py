"""Reading a JSON-shaped document, written once — the read side of `identity`.

`sx_contracts.identity` is the one way a value becomes bytes. This is the one way
bytes become a value again. Both existed already; only the write side had a home.

Twenty-nine private helpers across nine packages spelled the same four sentences —
"that field must be text", "…an integer", "…a number", "…an object" — each with its
own message wording, its own bool-is-not-an-int subtlety (some remembered it, some
did not), and its own answer to a missing key (usually a bare `KeyError` escaping a
codec whose whole job is to fail closed with a typed error). The check is not the
per-type part. The *document* is, and that stays in the codec that owns it.

A codec says what it is reading and how it fails **once**, where it parses::

    receipt = decode.document(payload, where="capture receipt", error=CaptureContractError)
    session = decode.text(receipt, "session_id")
    for episode in decode.documents(receipt, "episodes"):
        outcome = decode.text(episode, "outcome")

`document` is the entry point, and what it returns remembers its `where` and its
`error`, so every field read below it is the short sentence it means. Nesting keeps
that context: `decode.mapping(receipt, "policy")` reads `capture receipt.policy` and
still raises `CaptureContractError`. Both are keyword-overridable on any extractor
and both have plain defaults, so a one-off read of a raw mapping still works.

`error` is the same hook `HexDigest` carries: a codec names its own fail-closed type
so callers keep catching what they always caught. Binding it at the parse rather than
at each read is what makes it impossible to forget — a boundary cannot leak an
untyped failure by omitting a keyword. A domain error that subclasses `DecodeError`
keeps the two facts (`path`, `expected`); any other `Exception` type receives the
same sentence as its one message argument.

Every extractor is total on its declared domain and fails closed off it: a missing
key, a null, or a wrong type is a typed rejection, never a coerced value or a
`KeyError`. Absence is a domain fact only in `optional_text`, which says so.
"""

from __future__ import annotations

import math
from collections.abc import Iterator, Mapping
from typing import NoReturn, cast


class DecodeError(ValueError):
    """A document does not carry the value its reader requires.

    `path` locates the field the way a human would say it aloud (`capture
    receipt.session_id`); `expected` names what was required, never what arrived,
    so a rejection never spills a payload into a log.
    """

    def __init__(self, path: str, expected: str) -> None:
        self.path = path
        self.expected = expected
        super().__init__(f"{path}: expected {expected}")


class Document(Mapping[str, object]):
    """A mapping that has been parsed, and remembers what it was parsed as.

    Not a wrapper for its own sake: `where` and `error` are facts about *this*
    document that every field read under it needs, and a value that carries them is
    why a read is `decode.text(receipt, "session_id")` instead of the same two
    keywords repeated at every call site in the stack.
    """

    __slots__ = ("_entries", "error", "where")

    def __init__(self, entries: Mapping[str, object], where: str, error: type[Exception]) -> None:
        self._entries = entries
        self.where = where
        self.error = error

    def __getitem__(self, key: str) -> object:
        return self._entries[key]

    def __iter__(self) -> Iterator[str]:
        return iter(self._entries)

    def __len__(self) -> int:
        return len(self._entries)

    def __repr__(self) -> str:
        return f"Document({self.where or '<document>'}, {dict(self._entries)!r})"


def document(value: object, *, where: str = "", error: type[Exception] = DecodeError) -> Document:
    """Parse one untrusted object into a string-keyed mapping.

    The entry point: a codec calls this on the bytes it was handed before reaching
    for any field. Re-parsing an already-parsed `Document` inherits its context.
    """
    where, error = _context(value, where, error)
    if not isinstance(value, Mapping):
        _reject(where or "<document>", "an object", error)
    for key in cast("Mapping[object, object]", value):
        if not isinstance(key, str):
            _reject(where or "<document>", "an object with text keys", error)
    return Document(cast("Mapping[str, object]", value), where, error)


def exactly(
    value: object,
    keys: set[str],
    *,
    where: str = "",
    error: type[Exception] = DecodeError,
) -> Document:
    """Parse an object whose key vocabulary is closed and complete."""
    result = document(value, where=where, error=error)
    actual = set(result)
    if actual != keys:
        missing = sorted(keys - actual)
        unknown = sorted(actual - keys)
        _reject(
            result.where or "<document>",
            f"exactly these fields (missing={missing}, unknown={unknown})",
            result.error,
        )
    return result


def text(
    doc: Mapping[str, object], key: str, *, where: str = "", error: type[Exception] = DecodeError
) -> str:
    path, error, value = _field(doc, key, where, error)
    if not isinstance(value, str):
        _reject(path, "text", error)
    return value


def optional_text(
    doc: Mapping[str, object], key: str, *, where: str = "", error: type[Exception] = DecodeError
) -> str | None:
    """The one extractor whose absence is a domain fact rather than a rejection.

    A key that is missing or explicitly null reads as `None`; a key that is present
    and not text is still a rejection. Reach for this only where the document itself
    declares the field optional — everywhere else `text` is the honest call.
    """
    where, error = _context(doc, where, error)
    value = doc.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        _reject(_path(where, key), "text or null", error)
    return value


def integer(
    doc: Mapping[str, object], key: str, *, where: str = "", error: type[Exception] = DecodeError
) -> int:
    path, error, value = _field(doc, key, where, error)
    if isinstance(value, bool) or not isinstance(value, int):
        _reject(path, "an integer", error)
    return value


def number(
    doc: Mapping[str, object], key: str, *, where: str = "", error: type[Exception] = DecodeError
) -> float:
    """A finite JSON number, as a float.

    Finiteness is required because `identity.canonical_json` refuses to *write* a
    non-finite number: a document carrying one never came from this stack.
    """
    path, error, value = _field(doc, key, where, error)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        _reject(path, "a number", error)
    result = float(value)
    if not math.isfinite(result):
        _reject(path, "a finite number", error)
    return result


def optional_number(
    doc: Mapping[str, object],
    key: str,
    *,
    where: str = "",
    error: type[Exception] = DecodeError,
) -> float | None:
    """Read a nullable finite JSON number without coercing booleans."""
    where, error = _context(doc, where, error)
    value = doc.get(key)
    if value is None:
        return None
    path = _path(where, key)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        _reject(path, "a number or null", error)
    result = float(value)
    if not math.isfinite(result):
        _reject(path, "a finite number or null", error)
    return result


def boolean(
    doc: Mapping[str, object], key: str, *, where: str = "", error: type[Exception] = DecodeError
) -> bool:
    path, error, value = _field(doc, key, where, error)
    if not isinstance(value, bool):
        _reject(path, "a boolean", error)
    return value


def mapping(
    doc: Mapping[str, object], key: str, *, where: str = "", error: type[Exception] = DecodeError
) -> Document:
    path, error, value = _field(doc, key, where, error)
    return document(value, where=path, error=error)


def sequence(
    doc: Mapping[str, object], key: str, *, where: str = "", error: type[Exception] = DecodeError
) -> tuple[object, ...]:
    path, error, value = _field(doc, key, where, error)
    if not isinstance(value, (list, tuple)):
        _reject(path, "an array", error)
    return tuple(cast("list[object] | tuple[object, ...]", value))


def texts(
    doc: Mapping[str, object], key: str, *, where: str = "", error: type[Exception] = DecodeError
) -> tuple[str, ...]:
    path, error, _ = _field(doc, key, where, error)
    items = sequence(doc, key, where=where, error=error)
    for index, item in enumerate(items):
        if not isinstance(item, str):
            _reject(f"{path}[{index}]", "text", error)
    return cast("tuple[str, ...]", items)


def numbers(
    doc: Mapping[str, object],
    key: str,
    *,
    where: str = "",
    error: type[Exception] = DecodeError,
) -> tuple[float, ...]:
    """Read an array of finite JSON numbers."""
    path, error, _ = _field(doc, key, where, error)
    items = sequence(doc, key, where=where, error=error)
    result: list[float] = []
    for index, item in enumerate(items):
        if isinstance(item, bool) or not isinstance(item, (int, float)):
            _reject(f"{path}[{index}]", "a number", error)
        item_as_float = float(item)
        if not math.isfinite(item_as_float):
            _reject(f"{path}[{index}]", "a finite number", error)
        result.append(item_as_float)
    return tuple(result)


def documents(
    doc: Mapping[str, object], key: str, *, where: str = "", error: type[Exception] = DecodeError
) -> tuple[Document, ...]:
    """An array of objects, each parsed and each carrying its own indexed path."""
    path, error, _ = _field(doc, key, where, error)
    items = sequence(doc, key, where=where, error=error)
    return tuple(
        document(item, where=f"{path}[{index}]", error=error) for index, item in enumerate(items)
    )


def _context(source: object, where: str, error: type[Exception]) -> tuple[str, type[Exception]]:
    """A parsed document supplies whatever the caller did not override."""
    if isinstance(source, Document):
        return (where or source.where, source.error if error is DecodeError else error)
    return (where, error)


def _field(
    doc: Mapping[str, object], key: str, where: str, error: type[Exception]
) -> tuple[str, type[Exception], object]:
    where, error = _context(doc, where, error)
    path = _path(where, key)
    if key not in doc:
        _reject(path, "the field to be present", error)
    return (path, error, doc[key])


def _path(where: str, key: str) -> str:
    return f"{where}.{key}" if where else key


def _reject(path: str, expected: str, error: type[Exception]) -> NoReturn:
    """A domain error that *is* a `DecodeError` keeps the two facts; the rest get the sentence."""
    if issubclass(error, DecodeError):
        raise error(path, expected)
    raise error(str(DecodeError(path, expected)))
