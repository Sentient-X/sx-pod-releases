"""The workload-runtime identity: exactly which software environment executed.

The uv workspace is one lock and one venv, and only platform code lives there. A
workload whose dependency set cannot share that resolution — a sim engine, a
training recipe, a GPU scorer — runs in its own environment behind a process or
image boundary, and the artifact it produces records that environment as a
`Runtime`: either a `PythonRuntime` (a committed, locked uv project) or a
`BoundImage` (an OCI image pinned by digest). The full law lives in sx's
`docs/ABSTRACTIONS.md` ("The workload-runtime law").

Relation laws: `Runtime` says *in what* a workload executed. It is orthogonal to
the observed execution venue (`sx_worlds.ExecutionVenue`, *where* it executed —
evidence carries both) and to protocol identities such as a benchmark revision
(*what* it executed). Neither derives the others.

The wire form produced by `runtime_wire` is frozen forever (the suite-digest
precedent): produced artifacts embed it, so it never changes shape.
"""

import hashlib
from collections.abc import Mapping
from dataclasses import dataclass
from typing import TypeAlias, cast

from sx_contracts.content import ContentRefError, Sha256Digest
from sx_contracts.images import BoundImage, ImageContractError, ImageDigest, ImageName


class RuntimeContractError(ValueError):
    """A runtime record is incomplete or malformed."""


@dataclass(frozen=True, slots=True)
class PythonRuntime:
    """A committed, locked Python environment: a name, an interpreter, and a uv.lock digest."""

    name: str
    python: str
    lock_sha256: Sha256Digest

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise RuntimeContractError("python runtime name must not be empty")
        major, separator, minor = self.python.partition(".")
        if not separator or not major.isdigit() or not minor.isdigit():
            raise RuntimeContractError(
                f"python runtime version must be 'MAJOR.MINOR', got {self.python!r}"
            )


Runtime: TypeAlias = PythonRuntime | BoundImage


def python_runtime(name: str, python: str, lock_bytes: bytes) -> PythonRuntime:
    """Mint the runtime identity of a locked uv project from its exact lock bytes."""
    return PythonRuntime(name, python, Sha256Digest(hashlib.sha256(lock_bytes).hexdigest()))


def runtime_wire(runtime: Runtime) -> dict[str, str]:
    """The frozen canonical wire form — embed it in the artifact the execution produced."""
    match runtime:
        case PythonRuntime(name=name, python=python, lock_sha256=lock_sha256):
            return {
                "kind": "python",
                "name": name,
                "python": python,
                "lock_sha256": str(lock_sha256),
            }
        case BoundImage(name=image_name, digest=digest):
            return {"kind": "image", "name": str(image_name), "digest": str(digest)}


def parse_runtime(obj: object) -> Runtime:
    """Fail-closed parse of the wire form; a missing or unknown field is an error."""
    if not isinstance(obj, Mapping):
        raise RuntimeContractError(f"runtime wire form must be a mapping, got {type(obj).__name__}")
    fields: dict[str, str] = {}
    for key, value in cast("Mapping[object, object]", obj).items():
        if not isinstance(key, str) or not isinstance(value, str):
            raise RuntimeContractError("runtime wire form carries only string keys and values")
        fields[key] = value
    kind = fields.get("kind")
    try:
        match kind:
            case "python":
                if set(fields) != {"kind", "name", "python", "lock_sha256"}:
                    raise RuntimeContractError(
                        f"python runtime wire form has fields {sorted(fields)}"
                    )
                return PythonRuntime(
                    fields["name"], fields["python"], Sha256Digest(fields["lock_sha256"])
                )
            case "image":
                if set(fields) != {"kind", "name", "digest"}:
                    raise RuntimeContractError(
                        f"image runtime wire form has fields {sorted(fields)}"
                    )
                return BoundImage(ImageName(fields["name"]), ImageDigest(fields["digest"]))
            case _:
                raise RuntimeContractError(f"unknown runtime kind: {kind!r}")
    except (ContentRefError, ImageContractError) as error:
        raise RuntimeContractError(f"malformed runtime wire form: {error}") from error
