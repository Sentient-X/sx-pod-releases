"""The signal ladder: provenance of a training signal.

Orthogonal to the runtime escalation ladder in
:mod:`sx_contracts.supervision`: :class:`SupervisionLayer` orders *who is
consulted* at runtime (L0 heuristics → L3 human); :class:`SupervisionLevel`
orders *how rich the training signal is* (native predicate → agentic
critique). A supervision stack climbs both independently.

Rungs are the lineages the auto-perfect recipe merges: a simulator's native
predicate, an engineered binary verifier (ENPIRE), a learned reward
classifier (SERL), a graded reward model (Dyna-1), advantage estimates
(RECAP), and agentic critique.
"""

from enum import StrEnum
from typing import Final


class SupervisionLevel(StrEnum):
    """Provenance of a training signal: which rung of the signal ladder produced it."""

    NATIVE_PREDICATE = "native_predicate"
    """Simulator ground truth (e.g. RoboCasa's success predicate). Harness-only."""

    ENGINEERED_BINARY = "engineered_binary"
    """A hand-engineered perceptual success test (ENPIRE's EN Verifier)."""

    LEARNED_CLASSIFIER = "learned_classifier"
    """A reward classifier trained from success/failure examples (SERL)."""

    GRADED_REWARD_MODEL = "graded_reward_model"
    """A dense, graded reward model scoring progress and recovery (Dyna-1-style RM)."""

    ADVANTAGE = "advantage"
    """A value-function advantage estimate used for conditioning (pi*-0.6 / RECAP)."""

    AGENTIC = "agentic"
    """A coding-agent or VLM supervisor's judgment over a full episode."""


SIGNAL_LADDER: Final[tuple[SupervisionLevel, ...]] = (
    SupervisionLevel.NATIVE_PREDICATE,
    SupervisionLevel.ENGINEERED_BINARY,
    SupervisionLevel.LEARNED_CLASSIFIER,
    SupervisionLevel.GRADED_REWARD_MODEL,
    SupervisionLevel.ADVANTAGE,
    SupervisionLevel.AGENTIC,
)
"""The rungs ordered bottom (cheapest, coarsest) to top (richest, most expensive)."""
