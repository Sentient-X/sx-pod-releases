"""One exact deployable policy: VLA bytes plus an optional native inner agent.

The VLA artifact and checkpoint are independent because inference optimization may
produce several runnable artifacts from one trained checkpoint. When present, the native
inner-agent component adds its immutable bundle, exact Rust harness image, placement demand,
its fixed replanning interval, and how long it may think. The outer artifact identifies the
complete deployable bundle in either form.

The shape encodes the production states directly: a headless VLA, or that VLA composed with
one native inner agent. Agent-only policies have no production consumer; measurement scripts
remain scripts rather than weakening every policy, checkpoint, catalog, and serving boundary
with a nullable VLA.
"""

from dataclasses import dataclass
from enum import StrEnum

from sx_contracts import decode
from sx_contracts.content import (
    ArtifactId,
    ContentRef,
    ContentRefError,
    Sha256Digest,
)
from sx_contracts.decisions import DecisionError, ReplanInterval, parse_replan_interval
from sx_contracts.identity import JsonValue
from sx_contracts.images import BoundImage
from sx_contracts.runtime import RuntimeContractError, parse_runtime, runtime_wire

DEPLOYABLE_POLICY_SCHEMA_VERSION = "sx.deployable-policy/v5"
"""The one declaration of this wire's version.

Every door that carries the envelope names this rather than retyping the literal —
the string appeared in five mirrors and twice here before it had a home.
"""


class DeployablePolicyContractError(ValueError):
    """A deployable-policy wire document is malformed."""


class PlacementDemand(StrEnum):
    """Where the native inner agent must or should run."""

    EDGE = "edge"
    EDGE_PREFERRED = "edge_preferred"


@dataclass(frozen=True, slots=True)
class VlaPolicy:
    """Exact runnable VLA bytes together with their training lineage."""

    artifact: ContentRef
    checkpoint: ContentRef


@dataclass(frozen=True, slots=True)
class InnerAgent:
    """Exact native inner-agent bundle, harness image, placement, and replanning cadence.

    ``replan_interval`` fixes how long a VLA subgoal may run before the runtime asks for a
    replacement. ``decision_timeout_ms`` separately bounds how long the agent may think
    before the runtime fails the policy.

    The policy does not restate which command kinds the bundle may emit. The io/v6 endpoint
    admits the closed decision-tool vocabulary, and the runtime derives that capability from
    the actual decision source before composing it with executors.
    """

    bundle: ContentRef
    runtime: BoundImage
    demand: PlacementDemand
    replan_interval: ReplanInterval
    decision_timeout_ms: int

    def __post_init__(self) -> None:
        if self.decision_timeout_ms < 1:
            raise DeployablePolicyContractError(
                "an inner agent must be allowed at least one millisecond of thinking"
            )


@dataclass(frozen=True, slots=True)
class DeployablePolicy:
    """The complete deployable policy, with or without task-level intelligence."""

    artifact: ContentRef
    vla: VlaPolicy
    inner_agent: InnerAgent | None


def vla_policy_to_dict(policy: VlaPolicy) -> dict[str, JsonValue]:
    """The canonical wire projection of one runnable VLA."""

    return {
        "artifact": _content_to_dict(policy.artifact),
        "checkpoint": {
            "checkpoint_id": str(policy.checkpoint.artifact_id),
            "sha256": str(policy.checkpoint.sha256),
        },
    }


def vla_policy_from_dict(value: object) -> VlaPolicy:
    """Parse one runnable VLA through the same laws as a deployable policy."""

    return _vla_from_dict(value)


def inner_agent_to_dict(agent: InnerAgent) -> dict[str, JsonValue]:
    """The canonical wire projection of one native inner agent."""

    return {
        "bundle": _content_to_dict(agent.bundle),
        "runtime": runtime_wire(agent.runtime),
        "demand": agent.demand.value,
        "replan_interval": agent.replan_interval.to_wire(),
        "decision_timeout_ms": agent.decision_timeout_ms,
    }


def inner_agent_from_dict(value: object) -> InnerAgent:
    """Parse one native inner agent through the deployable-policy laws."""

    try:
        return _inner_agent_from_dict(value)
    except (ContentRefError, RuntimeContractError, DecisionError) as error:
        raise DeployablePolicyContractError(str(error)) from error


def deployable_policy_to_dict(policy: DeployablePolicy) -> dict[str, JsonValue]:
    """The one canonical deployable-policy wire projection."""
    inner_agent = policy.inner_agent
    return {
        "schema": DEPLOYABLE_POLICY_SCHEMA_VERSION,
        "artifact": _content_to_dict(policy.artifact),
        "vla": vla_policy_to_dict(policy.vla),
        "inner_agent": (None if inner_agent is None else inner_agent_to_dict(inner_agent)),
    }


def deployable_policy_from_dict(value: object) -> DeployablePolicy:
    """Parse untrusted canonical bytes once and fail closed on drift."""
    document = decode.document(
        value, where="deployable policy", error=DeployablePolicyContractError
    )
    if set(document) != {"schema", "artifact", "vla", "inner_agent"}:
        raise DeployablePolicyContractError(
            f"deployable policy has fields {sorted(str(key) for key in document)}"
        )
    if document["schema"] != DEPLOYABLE_POLICY_SCHEMA_VERSION:
        raise DeployablePolicyContractError(
            f"unsupported deployable-policy schema: {document['schema']!r}"
        )
    inner_agent_value = document["inner_agent"]
    try:
        artifact = _content_from_dict(document["artifact"], "deployable-policy artifact")
        vla_policy = _vla_from_dict(document["vla"])
        inner_agent = (
            None if inner_agent_value is None else _inner_agent_from_dict(inner_agent_value)
        )
        return DeployablePolicy(artifact, vla_policy, inner_agent)
    except (ContentRefError, RuntimeContractError, DecisionError) as error:
        raise DeployablePolicyContractError(str(error)) from error


def _vla_from_dict(value: object) -> VlaPolicy:
    vla = decode.document(value, where="VLA policy", error=DeployablePolicyContractError)
    if set(vla) != {"artifact", "checkpoint"}:
        raise DeployablePolicyContractError("VLA policy fields are incomplete")
    checkpoint = decode.mapping(vla, "checkpoint")
    if set(checkpoint) != {"checkpoint_id", "sha256"}:
        raise DeployablePolicyContractError("VLA checkpoint fields are incomplete")
    return VlaPolicy(
        _content_from_dict(vla["artifact"], "VLA artifact"),
        ContentRef(
            ArtifactId(decode.text(checkpoint, "checkpoint_id")),
            Sha256Digest(decode.text(checkpoint, "sha256")),
        ),
    )


def _inner_agent_from_dict(value: object) -> InnerAgent:
    document = decode.document(value, where="inner agent", error=DeployablePolicyContractError)
    if set(document) != {
        "bundle",
        "runtime",
        "demand",
        "replan_interval",
        "decision_timeout_ms",
    }:
        raise DeployablePolicyContractError("inner-agent fields are incomplete")
    runtime = parse_runtime(document["runtime"])
    if not isinstance(runtime, BoundImage):
        raise DeployablePolicyContractError("inner-agent runtime must be an image")
    try:
        demand = PlacementDemand(decode.text(document, "demand"))
    except ValueError as error:
        raise DeployablePolicyContractError(str(error)) from error
    silence = document["decision_timeout_ms"]
    if not isinstance(silence, int) or isinstance(silence, bool):
        raise DeployablePolicyContractError(
            "inner-agent decision_timeout_ms must be a whole number"
        )
    return InnerAgent(
        bundle=_content_from_dict(document["bundle"], "inner-agent bundle"),
        runtime=runtime,
        demand=demand,
        replan_interval=parse_replan_interval(document["replan_interval"]),
        decision_timeout_ms=silence,
    )


def _content_to_dict(content: ContentRef) -> dict[str, str]:
    return {
        "artifact_id": str(content.artifact_id),
        "sha256": str(content.sha256),
    }


def _content_from_dict(value: object, label: str) -> ContentRef:
    document = decode.document(value, where=label, error=DeployablePolicyContractError)
    if set(document) != {"artifact_id", "sha256"}:
        raise DeployablePolicyContractError(f"{label} fields are incomplete")
    return ContentRef(
        ArtifactId(decode.text(document, "artifact_id")),
        Sha256Digest(decode.text(document, "sha256")),
    )
