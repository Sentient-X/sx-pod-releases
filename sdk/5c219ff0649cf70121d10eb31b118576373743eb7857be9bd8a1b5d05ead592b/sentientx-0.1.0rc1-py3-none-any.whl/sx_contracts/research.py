"""The governed research-run lifecycle, shared by the pillar that runs it and the ones that read it.

A research run is one physical rollout on an enrolled Fleet station. Three vocabularies cross that
boundary on the wire, so all three live here rather than once per member:

* :class:`ResearchRunState` — what the run *is*, reported by the station, settled by Fleet
  control plane, and polled by auto-perfect's campaign harness (which must be able to tell
  "still going" from "finished" without guessing).
* :class:`DesiredResearchRunState` — what the control plane *wants*, the only thing travelling
  control plane → station. Advisory in the safety direction only: a station may always safe-stop on
  its own.
* :class:`CatalogRegistrationState` — where one research episode stands with the Experience
  catalog, carried on the run's evidence so a reader never confuses "not registered yet" with
  "registration failed".

These are wire values. Changing one is a data-contract break: the Fleet control plane persists
them (the ``research_runs`` state constraint), the station reports them, and the
campaign harness fails closed on a label it does not recognise rather than reading an unknown
state as "still running".
"""

from enum import StrEnum


class ResearchRunState(StrEnum):
    """One hosted research run's durable Fleet lifecycle."""

    ADMITTED = "admitted"
    PREPARING = "preparing"
    RUNNING = "running"
    WAITING_FOR_CONTROL = "waiting_for_control"
    RESETTING = "resetting"
    FINALIZING = "finalizing"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"


class DesiredResearchRunState(StrEnum):
    """A hosted operator's durable run intent; station safety may always stop.

    This is the only thing that travels control-plane → station, and it is advisory in the
    safety direction only: a station may always safe-stop on its own.
    """

    RUN = "run"
    STOP = "stop"


class CatalogRegistrationState(StrEnum):
    """Where one immutable station artifact stands in Catalog commitment."""

    PENDING = "pending"
    READY = "ready"
    FAILED = "failed"
