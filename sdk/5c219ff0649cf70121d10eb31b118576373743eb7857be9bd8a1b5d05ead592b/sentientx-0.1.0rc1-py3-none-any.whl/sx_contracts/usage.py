"""What work cost, in units nobody has priced yet.

Admission is measurement. A partition is admitted, or a provider call is settled, and in
the same act the platform records what that consumed — because a cost recorded later is
a cost recorded from memory, and the thing that remembers is the thing being billed.

**No prices live here, and none ever may.** These values carry *quantities* under a
named meter: milli-CPU-seconds, MiB-seconds, tokens. What a quantity is worth is a
billing-side price table, versioned and configured there, and a number here that had
already been multiplied by one would be a second opinion about money that nothing could
reconcile against the first. The same rule keeps prices out of plan identity: a plan is
what will be done, never what it will be charged.

**The project is stamped, never claimed.** :class:`ProjectRef` on an event is written by
the allocation owner from the authenticated request that produced the work. The
*catalog* serves no verb that accepts a :class:`UsageEvent` as a request body — billing's
ingest door does, from an explicitly authorized usage producer, because the events have
to reach billing somehow. What must not exist is a path where the party doing the work
also names who pays for it, and the catalog is where that party talks.

The real defence is downstream of both: billing re-derives the organization from the
project it was given and refuses an event whose two halves do not agree. A stamped field
is a good habit; a re-derivation is the thing that cannot be talked around.

**Reservation-based, and that is a decision rather than a shortcut.** An allocation's cost
basis is the resources its step *declared* multiplied by the wall time it held them, on
the control plane's clock. Not what it observed itself using: a worker measuring its own
consumption is a worker reporting its own bill, and the number that matters to a
scheduler is the capacity it reserved and nobody else could have. The declaration is
already immutable — it is inside the step digest — so the same partition costs the same
twice.

**Granularity is one second, and quantities are integers.** Duration is measured in
milliseconds and billed at whole seconds, floored at one: a call that took three
milliseconds still occupied a second of a machine nobody else could have. Every meter's
unit is chosen so the quantity is an exact integer — milli-CPU-seconds rather than
CPU-seconds — because a ledger that carries floats carries rounding disagreements
between the party that wrote the number and the party that charges for it.
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import StrEnum
from math import ceil
from typing import ClassVar, Literal, TypeAlias, assert_never
from uuid import UUID

from sx_contracts import decode
from sx_contracts.content import Sha256Digest
from sx_contracts.effects import UsageUnit
from sx_contracts.identity import content_digest
from sx_contracts.pipelines import Resources
from sx_contracts.wire import WireString

LEGACY_METER_VERSION = 1
METER_VERSION = 2
INTERACTIVE_METER_VERSION = 3
"""Which reading of "what work cost" every event below was computed under.

Pinned onto each event rather than assumed, because the meters are a *model* of cost and
models are revised: a later version may bill scratch, or count a held GPU differently.
An event carries the version that produced it so a bill can be recomputed, disputed, or
migrated without guessing which rules were in force. Billing pins it on ingestion; a
version it does not know is a refusal, never a silent reinterpretation.

Version 2 makes accelerator class part of the meter (for example,
``gpu.h100.milli_second``) and admits a compute allocation as a subject. Version 1
flattened every accelerator into ``gpu.milli_second`` and knew only pipeline partitions
and provider effects. A bounded legacy renderer remains below solely for immutable
Catalog outbox claims written before this upgrade; it may be removed only after the
Catalog removal-gate query proves there are no undelivered version-1 claims.

One limitation remains deliberately explicit:

* The ``provider.*`` token meters are model-blind. A token from a small model and a
  token from a large one are the same quantity here, so billing seeds them at cost zero
  rather than pricing a number that cannot mean one thing. Making tokens billable is a
  meter version that carries the model, on this side — not a price row on billing's.

Both are recorded rather than fixed because the quantities *are* being measured: a
version 2 can reprice history from the same events, whereas a quantity nobody wrote down
is gone.

**That sentence is a claim about the tree, so here is what has to be true for it.** An
event exists only where something delivers one. For a partition that is
`sx_catalog.server.work`; for a provider call it is `sx_catalog.server.effects.settle`,
which writes a claim whose subject is a :class:`ProviderEffectRef` in the transaction
that records the settlement. Until it did, the tokens stopped at the catalog's own
`provider_effect_usage` rows — a table billing has never read, behind a retention window
billing cannot see past — and repricing history would have meant asking another service
for numbers that no longer had to exist. The zero was still a decision; the *reason*
given for it was fiction.
"""


class UsageContractError(ValueError):
    """A usage value violates the law it declares."""


class StandardMeter(StrEnum):
    """The meters this platform defines for everyone.

    Closed, and the unit is in the name. `cpu.milli_second` is milli-CPUs multiplied by
    billed seconds — an integer — because the alternative is CPU-seconds as a float and
    a rounding argument between the ledger and the invoice.

    Scratch is metered and priced at zero today. That is not a placeholder: a quantity
    recorded from the start is a quantity that can be priced later without reopening
    every historical event, whereas one nobody recorded is gone.
    """

    CPU_MILLI_SECOND = "cpu.milli_second"
    MEMORY_MIB_SECOND = "memory.mib_second"
    SCRATCH_MIB_SECOND = "scratch.mib_second"
    STORAGE_MIB_SECOND = "storage.mib_second"

    PROVIDER_REQUEST = "provider.request"
    PROVIDER_INPUT_TOKEN = "provider.input_token"
    PROVIDER_OUTPUT_TOKEN = "provider.output_token"
    PROVIDER_CACHED_INPUT_TOKEN = "provider.cached_input_token"


_CUSTOM = re.compile(r"^custom\.[a-z][a-z0-9_.-]*$")
_ACCELERATOR = re.compile(r"^gpu\.[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*\.milli_second$")
_STANDARD = frozenset(member.value for member in StandardMeter)
LEGACY_GPU_METER = "gpu.milli_second"


class MeterId(WireString):
    """A standard meter, or one named after a scarce resource a step declared.

    Three families and one type, because a consumer does the same thing with each: look up
    a price, multiply, add. A closed enum alone could not name `custom.nvenc_channel`
    without this package having to know that NVENC exists — and a bare string would let
    a typo become a meter nobody prices and nobody notices.

    A custom meter is milli-units of the declared `Resource.amount` multiplied by billed
    seconds, exactly as the CPU meter is. Its name is the resource's own, so the thing a
    step asked the scheduler for and the thing an invoice charges for cannot drift apart.
    """

    __slots__ = ()
    error: ClassVar[type[Exception]] = UsageContractError
    noun: ClassVar[str] = "meter id"
    json_pattern: ClassVar[str | None] = r"^(?:[a-z][a-z0-9_.]*\.[a-z][a-z0-9_.-]*)$"

    def __new__(cls, value: str) -> MeterId:
        if (
            value not in _STANDARD
            and value != LEGACY_GPU_METER
            and _CUSTOM.fullmatch(value) is None
            and _ACCELERATOR.fullmatch(value) is None
        ):
            raise UsageContractError(
                "a meter is standard, 'gpu.<accelerator-kind>.milli_second', "
                f"or 'custom.<resource>': {value!r}"
            )
        return super().__new__(cls, value)


def accelerator_meter(accelerator_kind: str) -> MeterId:
    """The class-aware milli-device-second meter for one accelerator request."""
    return MeterId(f"gpu.{accelerator_kind}.milli_second")


_ALLOCATION_METERS = tuple(
    MeterId(member.value)
    for member in StandardMeter
    if member is not StandardMeter.STORAGE_MIB_SECOND
)

LEGACY_V1_METERS = (*_ALLOCATION_METERS, MeterId(LEGACY_GPU_METER))
"""Built-ins an immutable v1 Catalog claim may still need delivered under."""

V2_METERS = tuple([*_ALLOCATION_METERS] + [accelerator_meter(kind) for kind in ("h100", "h200")])
"""Built-ins Auth prices at initial v2 deployment; arbitrary classes fail closed."""

V3_METERS = tuple(
    [*_ALLOCATION_METERS, MeterId(StandardMeter.STORAGE_MIB_SECOND.value)]
    + [accelerator_meter(kind) for kind in ("h100", "h200", "l40s")]
)
"""Interactive allocation meters, including retained storage and L40S capacity."""

BILLABLE_METERS = tuple(
    [(meter, LEGACY_METER_VERSION) for meter in LEGACY_V1_METERS]
    + [(meter, METER_VERSION) for meter in V2_METERS]
    + [(meter, INTERACTIVE_METER_VERSION) for meter in V3_METERS]
)
"""Lago metrics required while v1 outbox claims can still be replayed.

Remove the v1 members only with the same Catalog zero-claim gate that permits removing
the v1 digest renderer. This is intentionally a tuple of explicit versioned identities,
not an alias from v1 names to v2 names.
"""


def custom_meter(resource_name: str) -> MeterId:
    """The meter that bills one declared custom resource.

    One spelling, here, because the catalog writes it and billing reads it: a prefix
    applied at two keyboards is a prefix that disagrees the first time somebody types
    ``custom_`` instead of ``custom.``.

    **Declaring a custom resource parks the claims that carry it, and nothing else.**
    Billing cannot have a price for a meter named after an arbitrary scarce thing, so an
    event carrying one is refused as retryable and the outbox holds it. That is the
    fail-closed direction on purpose — silently dropping a billable quantity is the worse
    error — so a step author adding ``Resource("nvenc_channel", …)`` owes an operator a
    price row, and should say so in the step's review rather than in the incident.

    What it must *not* do is stop anything else, and it used to do exactly that. The
    hold was taken per batch and the queue was ordered by age, so one unpriced meter sat
    at the head of every subsequent batch: the project delivered no usage again, its
    delivery lag grew without bound, and an hour later the lag gate refused its new runs
    with a `Retry-After` for something waiting could not fix. `sx_catalog.worker.outbox`
    now isolates a held claim from the batch it was in and excludes it from the lag the
    gate reads — a claim billing has said it cannot price is a configuration problem
    with an operator as its remedy, not a transport problem with a wait as its remedy.

    The same applies to any new :class:`StandardMeter` member: it lands here *and* in
    billing's seed, or every delivery carrying it parks.
    """
    return MeterId(f"custom.{resource_name}")


def provider_meter(unit: UsageUnit) -> MeterId:
    """The meter one provider-reported quantity is billed under.

    A total function over :class:`sx_contracts.effects.UsageUnit`, and the ``match`` is
    what makes that a *typed* claim: a member added there and not here fails Pyright at
    :func:`typing.assert_never` rather than raising in a settle path. It was a `dict`
    lookup, which strict Pyright accepts and which answers a new unit with `KeyError` —
    inside the transaction that records what a call cost.
    """
    match unit:
        case UsageUnit.REQUESTS:
            meter = StandardMeter.PROVIDER_REQUEST
        case UsageUnit.INPUT_TOKENS:
            meter = StandardMeter.PROVIDER_INPUT_TOKEN
        case UsageUnit.OUTPUT_TOKENS:
            meter = StandardMeter.PROVIDER_OUTPUT_TOKEN
        case UsageUnit.CACHED_INPUT_TOKENS:
            meter = StandardMeter.PROVIDER_CACHED_INPUT_TOKEN
        case _:
            assert_never(unit)
    return MeterId(meter.value)


@dataclass(frozen=True, slots=True, order=True)
class MeteredQuantity:
    """How much of one meter this work consumed. An integer, always."""

    meter: MeterId
    quantity: int

    def __post_init__(self) -> None:
        if isinstance(self.quantity, bool) or self.quantity < 0:
            raise UsageContractError(f"a metered quantity is non-negative: {self.quantity!r}")


@dataclass(frozen=True, slots=True)
class PlanEstimate:
    """What a plan would consume, and every assumption that number rests on.

    **Quantities, never money.** The catalog measures and billing prices, so a quote
    from this door is what the work would *consume* under one meter version. Turning it
    into a currency is billing's — it holds the price table, and a number here that had
    been multiplied by one would be the catalog's second opinion about money.

    The assumptions are part of the answer rather than a footnote. A duration nobody
    can know in advance is the whole uncertainty in an estimate, so it is stated back:
    a caller who disagrees changes it and asks again, instead of discovering later
    which number was guessed.
    """

    members: int
    assumed_partition_seconds: int
    meter_version: int
    per_partition: tuple[MeteredQuantity, ...]
    total: tuple[MeteredQuantity, ...]
    assumptions: tuple[str, ...]

    def __post_init__(self) -> None:
        if isinstance(self.members, bool) or self.members < 1:
            raise UsageContractError(f"an estimate quotes at least one member: {self.members!r}")
        if isinstance(self.assumed_partition_seconds, bool) or self.assumed_partition_seconds < 1:
            raise UsageContractError(
                f"an assumed partition duration is at least one second: "
                f"{self.assumed_partition_seconds!r}"
            )


def _metered_quantities(
    doc: Mapping[str, object], key: str, *, where: str
) -> tuple[MeteredQuantity, ...]:
    items = decode.sequence(doc, key, where=where, error=UsageContractError)
    quantities: list[MeteredQuantity] = []
    for index, item in enumerate(items):
        entry = decode.exactly(
            item, {"meter", "quantity"}, where=f"{where}.{key}[{index}]", error=UsageContractError
        )
        quantities.append(
            MeteredQuantity(
                meter=MeterId(decode.text(entry, "meter", error=UsageContractError)),
                quantity=decode.integer(entry, "quantity", error=UsageContractError),
            )
        )
    return tuple(quantities)


def plan_estimate_from_dict(value: object) -> PlanEstimate:
    """The one legal reader of an estimate's wire form — fail-closed, like every codec."""
    where = "plan_estimate"
    doc = decode.exactly(
        value,
        {
            "members",
            "assumed_partition_seconds",
            "meter_version",
            "per_partition",
            "total",
            "assumptions",
        },
        where=where,
        error=UsageContractError,
    )
    return PlanEstimate(
        members=decode.integer(doc, "members", error=UsageContractError),
        assumed_partition_seconds=decode.integer(
            doc, "assumed_partition_seconds", error=UsageContractError
        ),
        meter_version=decode.integer(doc, "meter_version", error=UsageContractError),
        per_partition=_metered_quantities(doc, "per_partition", where=where),
        total=_metered_quantities(doc, "total", where=where),
        assumptions=decode.texts(doc, "assumptions", error=UsageContractError),
    )


@dataclass(frozen=True, slots=True)
class ProjectRef:
    """Who is billed, as the catalog stamped it.

    Both halves come from the authenticated request that produced the work. The
    organization is derived from the project rather than carried beside it in anything a
    workload sends — `docs/PLATFORM-MODEL.md`'s rule that there is no caller-supplied
    tenant field, applied to the one place where getting it wrong means charging the
    wrong company.
    """

    organization_id: UUID
    project_id: UUID


@dataclass(frozen=True, slots=True)
class PartitionRef:
    """One fenced attempt at one member of a run's input."""

    run_id: UUID
    ordinal: int
    generation: int
    kind: Literal["partition"] = "partition"

    def __post_init__(self) -> None:
        if isinstance(self.ordinal, bool) or self.ordinal < 0:
            raise UsageContractError(
                f"a partition ordinal is a non-negative index: {self.ordinal!r}"
            )
        if isinstance(self.generation, bool) or self.generation < 1:
            raise UsageContractError(f"a fencing generation is counted from 1: {self.generation!r}")


@dataclass(frozen=True, slots=True)
class ProviderEffectRef:
    """One grant of one external call — the unit migration 0058 made a row."""

    effect_id: UUID
    attempt: int
    kind: Literal["provider_effect"] = "provider_effect"

    def __post_init__(self) -> None:
        if isinstance(self.attempt, bool) or self.attempt < 1:
            raise UsageContractError(f"an attempt is counted from 1: {self.attempt!r}")


@dataclass(frozen=True, slots=True)
class ExecutionAllocationRef:
    """One placement allocation within one attempt of a compute execution."""

    execution_id: UUID
    attempt: int
    allocation: int
    kind: Literal["execution_allocation"] = "execution_allocation"

    def __post_init__(self) -> None:
        if isinstance(self.attempt, bool) or self.attempt < 1:
            raise UsageContractError(f"an execution attempt is counted from 1: {self.attempt!r}")
        if isinstance(self.allocation, bool) or self.allocation < 0:
            raise UsageContractError(
                f"an execution allocation is a non-negative index: {self.allocation!r}"
            )


@dataclass(frozen=True, slots=True)
class InteractiveAllocationRef:
    """One billable VM allocation within a persistent interactive resource generation."""

    allocation_id: UUID
    generation: int
    allocation: int
    kind: Literal["interactive_allocation"] = "interactive_allocation"

    def __post_init__(self) -> None:
        if isinstance(self.generation, bool) or self.generation < 1:
            raise UsageContractError("interactive allocation generation is counted from 1")
        if isinstance(self.allocation, bool) or self.allocation < 0:
            raise UsageContractError(
                f"an interactive allocation is a non-negative index: {self.allocation!r}"
            )


@dataclass(frozen=True, slots=True)
class WorkspaceVolumeWindowRef:
    """One fenced periodic storage window for a retained workspace volume generation."""

    volume_id: UUID
    generation: int
    window: int
    kind: Literal["workspace_volume_window"] = "workspace_volume_window"

    def __post_init__(self) -> None:
        if isinstance(self.generation, bool) or self.generation < 1:
            raise UsageContractError("workspace volume generation is counted from 1")
        if isinstance(self.window, bool) or self.window < 0:
            raise UsageContractError(
                f"a workspace volume window is a non-negative index: {self.window!r}"
            )


UsageSubject: TypeAlias = (
    PartitionRef
    | ProviderEffectRef
    | ExecutionAllocationRef
    | InteractiveAllocationRef
    | WorkspaceVolumeWindowRef
)
"""What was measured. Tagged by ``kind``, because a bill has to name the work.

An identity rather than a description: a dispute is settled by going back to the run and
the attempt, and a usage line that could not be traced to one is a number nobody can
check.
"""


class UsageOutcome(StrEnum):
    """How the measured work ended.

    On the event because the same quantities mean different things: a succeeded
    partition bought a member, a failed one bought nothing, and both cost the machine
    the same. Billing does not need this to compute a charge — it needs it to answer
    "what did we pay for failures last month", which is the question that changes
    behaviour.

    ``cached`` remains absent because no worker-local content cache produces it. A
    retried allocation is not an outcome: it is two attempts or allocations, each with
    its own event.
    """

    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"


def billed_seconds(window_ms: int) -> int:
    """Whole seconds a window is charged at — Modal's granularity, floored at one.

    Rounded up because a second of a machine is the smallest thing anyone can buy, and
    floored at one because work that took three milliseconds still occupied capacity
    nobody else could have.
    """
    if isinstance(window_ms, bool) or window_ms < 0:
        raise UsageContractError(f"a measured window is non-negative milliseconds: {window_ms!r}")
    return max(1, ceil(window_ms / 1000))


def reserved_quantities(resources: Resources, window_ms: int) -> tuple[MeteredQuantity, ...]:
    """What holding one step's declared resources for this long consumed.

    The declaration, not an observation. A worker reporting its own consumption is a
    worker reporting its own bill, and the quantity that matters to whoever else wanted
    that machine is the capacity this work reserved — which is exactly what the step
    already froze inside its digest, so the same partition costs the same twice.

    Milli-units throughout: `cpus=1.5` for two seconds is 3000 milli-CPU-seconds, an
    integer, rather than 3.0 of something a ledger would have to round.
    """
    seconds = billed_seconds(window_ms)
    counted: list[MeteredQuantity] = [
        MeteredQuantity(
            MeterId(StandardMeter.CPU_MILLI_SECOND.value), round(resources.cpus * 1000) * seconds
        ),
        MeteredQuantity(
            MeterId(StandardMeter.MEMORY_MIB_SECOND.value), resources.memory_mib * seconds
        ),
    ]
    if resources.scratch_mib:
        counted.append(
            MeteredQuantity(
                MeterId(StandardMeter.SCRATCH_MIB_SECOND.value), resources.scratch_mib * seconds
            )
        )
    if resources.accelerator is not None:
        counted.append(
            MeteredQuantity(
                accelerator_meter(resources.accelerator.kind),
                round(resources.accelerator.count * 1000) * seconds,
            )
        )
    counted.extend(
        MeteredQuantity(custom_meter(resource.name), round(resource.amount * 1000) * seconds)
        for resource in resources.custom
    )
    return tuple(sorted(counted))


@dataclass(frozen=True, slots=True)
class UsageEvent:
    """One measured piece of work, addressed by what it says.

    Content-addressed on purpose: :attr:`digest` is the charge-once identity a billing
    ledger dedupes on, so at-least-once delivery of the same event is one charge without
    either side keeping a list of what it has already sent. Two *different* pieces of
    work cannot collide, because the subject is in the document.

    The window is carried rather than a duration, because the two endpoints are what let
    anyone recompute the quantities under a different meter version — a duration alone
    would make the numbers unauditable the moment the meters changed.
    """

    project: ProjectRef
    subject: UsageSubject
    outcome: UsageOutcome
    meter_version: int
    window_start: datetime
    window_end: datetime
    quantities: tuple[MeteredQuantity, ...]

    def __post_init__(self) -> None:
        meters = [item.meter for item in self.quantities]
        if len(set(meters)) != len(meters):
            raise UsageContractError("a usage event counts each meter at most once")
        object.__setattr__(self, "quantities", tuple(sorted(self.quantities)))
        if self.window_start.tzinfo is None or self.window_end.tzinfo is None:
            raise UsageContractError("usage window bounds must be timezone-aware")
        if self.window_end < self.window_start:
            raise UsageContractError("a usage window cannot end before it starts")
        if isinstance(self.meter_version, bool) or self.meter_version < 1:
            raise UsageContractError(f"a meter version is counted from 1: {self.meter_version!r}")
        if self.meter_version == LEGACY_METER_VERSION:
            if isinstance(
                self.subject,
                (ExecutionAllocationRef, InteractiveAllocationRef, WorkspaceVolumeWindowRef),
            ):
                raise UsageContractError("meter version 1 cannot identify an allocation")
            if self.outcome is UsageOutcome.CANCELLED:
                raise UsageContractError("meter version 1 cannot represent cancellation")
            if any(_ACCELERATOR.fullmatch(str(meter)) for meter in meters):
                raise UsageContractError("meter version 1 cannot identify accelerator class")
        else:
            if MeterId(LEGACY_GPU_METER) in meters:
                raise UsageContractError(
                    "meter versions after 1 require a class-aware accelerator meter"
                )
            if self.meter_version != INTERACTIVE_METER_VERSION and isinstance(
                self.subject, (InteractiveAllocationRef, WorkspaceVolumeWindowRef)
            ):
                raise UsageContractError("interactive usage subjects require meter version 3")
        storage_meter = MeterId(StandardMeter.STORAGE_MIB_SECOND.value)
        if isinstance(self.subject, WorkspaceVolumeWindowRef):
            if meters != [storage_meter]:
                raise UsageContractError(
                    "a workspace volume window measures exactly durable storage"
                )
        elif storage_meter in meters:
            raise UsageContractError(
                "durable storage is measured only by a workspace volume window"
            )

    @property
    def window_ms(self) -> int:
        """The measured window, in the milliseconds the quantities were derived from."""
        return round((self.window_end - self.window_start).total_seconds() * 1000)

    @property
    def digest(self) -> Sha256Digest:
        """This exact measurement's identity — the key a bill is charged once against."""
        # This branch is intentionally the exact historical rendering. It exists only
        # so a Catalog v1 claim that was POSTed before a crash has the same identity
        # when its immutable outbox row is retried by upgraded code. Remove it only
        # after Catalog's documented v1-claim removal gate reaches zero.
        schema = (
            "sx.pipeline-usage/v1"
            if self.meter_version == LEGACY_METER_VERSION
            else (
                "sx.usage/v3" if self.meter_version == INTERACTIVE_METER_VERSION else "sx.usage/v2"
            )
        )
        return content_digest(
            {
                "schema": schema,
                "organization_id": str(self.project.organization_id),
                "project_id": str(self.project.project_id),
                "subject": _subject_document(self.subject),
                "outcome": self.outcome.value,
                "meter_version": self.meter_version,
                # **Normalized, because a digest that depends on who rendered it is not
                # an identity.** These arrive from psycopg in the *session's* TimeZone,
                # so the same instant read by two connections produced two digests and
                # therefore two charges. Forcing UTC makes the document a function of the
                # moment rather than of the reader.
                "window_start": self.window_start.astimezone(UTC).isoformat(),
                "window_end": self.window_end.astimezone(UTC).isoformat(),
                "quantities": [
                    {"meter": str(item.meter), "quantity": item.quantity}
                    for item in self.quantities
                ],
            }
        )


def reconciliation_digest(digests: Iterable[Sha256Digest]) -> Sha256Digest:
    """The one fact that settles "did you ingest what I delivered".

    A count answers *whether* two sides agree; this answers it without either side
    trusting the other's bookkeeping, because it is taken over the identities
    themselves. Order-independent by sorting, so neither side has to have delivered in
    any order, and a disagreement is localized by halving the window and asking again.

    Here rather than in either service because it is a comparison *between* them: the
    catalog computes it over the digests it stamped on delivery, billing over the
    digests it ledgered, and a formula spelled twice is two answers to the one question
    the read exists to settle.
    """
    return content_digest({"usage_ids": tuple(sorted(str(digest) for digest in digests))})


def _subject_document(subject: UsageSubject) -> dict[str, str | int]:
    if isinstance(subject, PartitionRef):
        return {
            "kind": subject.kind,
            "run_id": str(subject.run_id),
            "ordinal": subject.ordinal,
            "generation": subject.generation,
        }
    if isinstance(subject, ProviderEffectRef):
        return {
            "kind": subject.kind,
            "effect_id": str(subject.effect_id),
            "attempt": subject.attempt,
        }
    if isinstance(subject, ExecutionAllocationRef):
        return {
            "kind": subject.kind,
            "execution_id": str(subject.execution_id),
            "attempt": subject.attempt,
            "allocation": subject.allocation,
        }
    if isinstance(subject, InteractiveAllocationRef):
        return {
            "kind": subject.kind,
            "allocation_id": str(subject.allocation_id),
            "generation": subject.generation,
            "allocation": subject.allocation,
        }
    return {
        "kind": subject.kind,
        "volume_id": str(subject.volume_id),
        "generation": subject.generation,
        "window": subject.window,
    }
