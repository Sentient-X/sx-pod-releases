"""OCI image identity: one logical name bound to one exact content digest.

`BoundImage` is the platform's single image-reference shape, shared by the Fleet
station-software contract (release bodies, drift laws) and the workload-runtime
vocabulary (`sx_contracts.runtime`). Registry authority is deliberately not a
field: which registry serves a digest is deployment configuration — the station
joins `{prefix}/{name}@{digest}` at its projection point — never part of the
image's identity.

`ImageDigest` keeps the OCI-native `"sha256:<hex>"` form because that is what
registry verifiers (zot, `OciRegistryVerifier`) consume; the bare-hex
`Sha256Digest` in `sx_contracts.content` stays for locally hashed bytes. Each
digest lives in the form its verifier reads — do not normalize one into the
other.
"""

from dataclasses import dataclass
from typing import Literal, NewType, TypeAlias

ImageName = NewType("ImageName", str)

ImagePart: TypeAlias = Literal["digest", "name"]


class ImageContractError(ValueError):
    """An OCI image identity value is malformed; fails closed.

    ``part`` names which identity fact was refused — the content ``digest`` or
    the logical ``name`` — and ``value`` carries the offending input so a
    boundary can report exactly what it rejected.
    """

    def __init__(self, part: ImagePart, value: str) -> None:
        self.part: ImagePart = part
        self.value = value
        message = (
            f"malformed OCI digest: {value!r}"
            if part == "digest"
            else f"image name is not a lowercase OCI-safe logical name: {value!r}"
        )
        super().__init__(message)


@dataclass(frozen=True, slots=True)
class ImageDigest:
    value: str

    def __post_init__(self) -> None:
        algorithm, separator, digest = self.value.partition(":")
        if (
            algorithm != "sha256"
            or separator != ":"
            or len(digest) != 64
            or any(character not in "0123456789abcdef" for character in digest)
        ):
            raise ImageContractError("digest", self.value)

    def __str__(self) -> str:
        return self.value

    @classmethod
    def __get_pydantic_core_schema__(cls, _source: object, _handler: object) -> object:
        """Parse from, and serialise to, the OCI string — the form the wire uses.

        Without this a door sees the dataclass shape (``{"value": "sha256:…"}``) and
        has to mirror the type to accept what `runtime_wire` actually emits. Imported
        inside the hook: this package stays dependency-free at import time.
        """
        from pydantic_core import core_schema

        return core_schema.no_info_after_validator_function(
            cls,
            core_schema.str_schema(),
            serialization=core_schema.to_string_ser_schema(),
        )


@dataclass(frozen=True, slots=True)
class BoundImage:
    name: ImageName
    digest: ImageDigest

    def __post_init__(self) -> None:
        name = str(self.name)
        if (
            not name
            or len(name) > 128
            or not (name[0].islower() or name[0].isdigit())
            or any(
                not (character.islower() or character.isdigit() or character in "._-")
                for character in name
            )
            or not name.isascii()
        ):
            raise ImageContractError("name", name)
