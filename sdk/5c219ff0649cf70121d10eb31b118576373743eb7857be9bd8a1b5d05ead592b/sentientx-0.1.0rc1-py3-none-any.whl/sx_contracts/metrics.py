"""Finite named measurements with one canonical ordering."""

from __future__ import annotations

import math
from collections.abc import Iterable, Iterator
from dataclasses import dataclass
from typing import NewType, overload

MetricName = NewType("MetricName", str)


class MetricError(ValueError):
    """A measurement is unnamed, non-finite, or duplicated."""


@dataclass(frozen=True, slots=True, order=True)
class Metric:
    name: MetricName
    value: float

    def __post_init__(self) -> None:
        if not str(self.name).strip():
            raise MetricError("metric name must not be empty")
        if isinstance(self.value, bool) or not math.isfinite(self.value):
            raise MetricError(f"metric {self.name!r} must have a finite numeric value")


@dataclass(frozen=True, slots=True)
class MetricSet:
    """A name-keyed set whose stored and canonical order is lexical by name."""

    metrics: tuple[Metric, ...] = ()

    def __post_init__(self) -> None:
        ordered = tuple(sorted(self.metrics, key=lambda metric: str(metric.name)))
        names = tuple(metric.name for metric in ordered)
        if len(set(names)) != len(names):
            raise MetricError("metric set repeats a name")
        object.__setattr__(self, "metrics", ordered)

    @classmethod
    def from_pairs(cls, values: Iterable[tuple[str, float]]) -> MetricSet:
        return cls(tuple(Metric(MetricName(name), value) for name, value in values))

    def __iter__(self) -> Iterator[Metric]:
        return iter(self.metrics)

    def __len__(self) -> int:
        return len(self.metrics)

    @overload
    def __getitem__(self, key: int) -> Metric: ...

    @overload
    def __getitem__(self, key: str) -> float: ...

    def __getitem__(self, key: int | str) -> Metric | float:
        if isinstance(key, int):
            return self.metrics[key]
        for metric in self.metrics:
            if metric.name == key:
                return metric.value
        raise KeyError(key)

    def to_dict(self) -> dict[str, float]:
        return {str(metric.name): metric.value for metric in self.metrics}
