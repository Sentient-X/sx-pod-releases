"""A value that must never leave the process by accident.

`sx_contracts.wire` is about strings a boundary may parse *into* the domain. This
is its opposite: a string the domain holds and no boundary may emit. The two live
next to each other because they answer the same question — what may cross a wire —
and a `str` answers it wrongly in both directions.

A credential typed `str` escapes through every default path a language offers. It
formats into an f-string in a log line, appears in a `repr` inside a traceback
frame, serializes into a JSON error body, and rides a Temporal payload into a
workflow history that outlives the incident. None of those are decisions anyone
made; they are what `str` does.

`Secret` does none of them. `reveal()` is the one way out, so every place a
credential is genuinely used says so in one word, and every place it merely passes
through is safe by construction::

    settings.s3_secret_key                    # Secret — prints as [REDACTED]
    f"key={settings.s3_secret_key}"           # "key=[REDACTED]"
    json.dumps({"k": settings.s3_secret_key}) # TypeError, not a leak
    client(secret=settings.s3_secret_key.reveal())   # the one deliberate use

It is deliberately **not** a `str` subclass. A subclass inherits exactly the paths
this type exists to close, and `Secret("x") == "x"` would let a comparison decide
that a credential and a plain string are the same value.
"""

from __future__ import annotations

from hmac import compare_digest
from typing import Any, final

REDACTED = "[REDACTED]"


class SecretExposedError(RuntimeError):
    """A secret was about to be serialized onto a wire that has no business holding it."""


@final
class Secret:
    """One held credential. ``reveal()`` is the only way to its value."""

    __slots__ = ("_value",)
    __hash__ = None  # type: ignore[assignment]  # unhashable: a dict key is a leak waiting

    def __init__(self, value: str) -> None:
        self._value = value

    def reveal(self) -> str:
        """The credential itself — say this exactly where it is used, and nowhere else."""
        return self._value

    def __str__(self) -> str:
        return REDACTED

    def __repr__(self) -> str:
        return f"Secret({REDACTED})"

    def __format__(self, _spec: str) -> str:
        return REDACTED

    def __bool__(self) -> bool:
        """Whether a credential was configured at all — never what it is."""
        return bool(self._value)

    def __eq__(self, other: object) -> bool:
        """Secrets compare with secrets, in constant time. A `str` is never equal."""
        if not isinstance(other, Secret):
            return NotImplemented
        return compare_digest(self._value, other._value)

    @classmethod
    def __get_pydantic_core_schema__(cls, _source: Any, _handler: Any) -> Any:
        """Parse from a string at a settings/request boundary; serialize redacted.

        A `model_dump` that reaches a log or an error body is the common accident,
        so the serialized form is the redaction. Code that needs the value calls
        `reveal()`, which is the point.
        """
        from pydantic_core import core_schema

        return core_schema.json_or_python_schema(
            json_schema=core_schema.no_info_after_validator_function(cls, core_schema.str_schema()),
            python_schema=core_schema.union_schema(
                [
                    core_schema.is_instance_schema(cls),
                    core_schema.no_info_after_validator_function(cls, core_schema.str_schema()),
                ]
            ),
            serialization=core_schema.plain_serializer_function_ser_schema(
                lambda _secret: REDACTED, return_schema=core_schema.str_schema()
            ),
        )

    @classmethod
    def __get_pydantic_json_schema__(cls, schema: Any, handler: Any) -> Any:
        """Describe itself to OpenAPI as what it is: a masked, write-only string.

        A door's generated client is downstream of this. `format: password` is
        what tells a browser to mask the input, and `writeOnly` is what says the
        value is sent and never returned — so a type that omitted them would
        quietly render a credential field as plain text in every console built
        from the schema.
        """
        json_schema = handler(schema)
        json_schema.update(format="password", writeOnly=True)
        return json_schema
