"""The human-annotation handoff: what the Label door tells the catalog.

The labeler owns annotation *work* (revisions, audits, claims — its own database);
the catalog owns annotation *facts about a governed segment*. This wire is that
handoff (design: docs/plans/partial/lance-semantic-index-2026-08.md S3b, closing the seam
catalog ARCHITECTURE §16 q4 left deliberately open): the reviewed episode-level
task facts plus the ordered, time-bounded subtasks, content-addressed so the same
annotation registered twice is the same fact.

Times are integer nanoseconds on the episode's primary timeline (`episode_time`),
the same clock every other segment fact speaks. The labeler's frame indices stay
home: a frame index is a contact-sheet coordinate, not an episode fact.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from sx_contracts import decode
from sx_contracts.content import Sha256Digest
from sx_contracts.identity import JsonValue, content_digest

ANNOTATION_SCHEMA = "sx.annotation/v1"


class AnnotationContractError(ValueError):
    """An annotation document violates the shared contract.

    A ``ValueError`` so a pydantic door parsing straight into these dataclasses
    rejects a violating body as a 422 instead of crashing the request.
    """


class AnnotationStage(StrEnum):
    """Which review stage produced the facts. The catalog stores the best stage it
    has been handed; ``customer`` is the gold sign-off."""

    ANNOTATOR = "annotator"
    QA = "qa"
    CUSTOMER = "customer"


class SubtaskStatus(StrEnum):
    SUCCESS = "success"
    MISTAKE = "mistake"
    UNCLEAR = "unclear"


@dataclass(frozen=True, slots=True)
class SubtaskAction:
    """One body part's contribution to a subtask."""

    part: str
    skill: str
    target_items: tuple[str, ...]
    target_location: str
    description: str

    def __post_init__(self) -> None:
        if not self.part:
            raise AnnotationContractError("a subtask action names its body part")


@dataclass(frozen=True, slots=True)
class AnnotatedSubtask:
    """One ordered semantic step with its time bounds on ``episode_time``.

    ``t_end_ns`` may be absent on legacy annotations (the labeler's gold method
    added explicit event ends later); consumers fall back to the next subtask's
    start. That absence is the wire's one legitimate optional, declared here.
    """

    ordinal: int
    t_start_ns: int
    t_end_ns: int | None
    status: SubtaskStatus
    description: str
    actions: tuple[SubtaskAction, ...]

    def __post_init__(self) -> None:
        if self.ordinal < 0:
            raise AnnotationContractError("subtask ordinal must be >= 0")
        if self.t_start_ns < 0:
            raise AnnotationContractError("subtask start precedes the episode")
        if self.t_end_ns is not None and self.t_end_ns < self.t_start_ns:
            raise AnnotationContractError("subtask ends before it starts")


@dataclass(frozen=True, slots=True)
class EpisodeAnnotation:
    """The reviewed annotation facts for one episode, complete and immutable."""

    episode_id: str
    stage: AnnotationStage
    task: str
    task_description: str
    scene: str
    scene_description: str
    success: bool
    subtasks: tuple[AnnotatedSubtask, ...]

    def __post_init__(self) -> None:
        if not self.episode_id:
            raise AnnotationContractError("annotation names no episode")
        ordinals = [subtask.ordinal for subtask in self.subtasks]
        if ordinals != sorted(set(ordinals)):
            raise AnnotationContractError("subtask ordinals must be strictly increasing")


def annotation_to_dict(annotation: EpisodeAnnotation) -> dict[str, JsonValue]:
    return {
        "schema": ANNOTATION_SCHEMA,
        "episode_id": annotation.episode_id,
        "stage": annotation.stage.value,
        "task": annotation.task,
        "task_description": annotation.task_description,
        "scene": annotation.scene,
        "scene_description": annotation.scene_description,
        "success": annotation.success,
        "subtasks": [
            {
                "ordinal": subtask.ordinal,
                "t_start_ns": subtask.t_start_ns,
                "t_end_ns": subtask.t_end_ns,
                "status": subtask.status.value,
                "description": subtask.description,
                "actions": [
                    {
                        "part": action.part,
                        "skill": action.skill,
                        "target_items": list(action.target_items),
                        "target_location": action.target_location,
                        "description": action.description,
                    }
                    for action in subtask.actions
                ],
            }
            for subtask in annotation.subtasks
        ],
    }


def annotation_from_dict(value: object) -> EpisodeAnnotation:
    doc = decode.exactly(
        value,
        {
            "schema",
            "episode_id",
            "stage",
            "task",
            "task_description",
            "scene",
            "scene_description",
            "success",
            "subtasks",
        },
        where="annotation",
        error=AnnotationContractError,
    )
    if decode.text(doc, "schema") != ANNOTATION_SCHEMA:
        raise AnnotationContractError(
            f"annotation schema is {doc['schema']!r}, this vocabulary is {ANNOTATION_SCHEMA!r}"
        )
    subtasks: list[AnnotatedSubtask] = []
    for raw in decode.documents(doc, "subtasks"):
        subtask = decode.exactly(
            raw,
            {"ordinal", "t_start_ns", "t_end_ns", "status", "description", "actions"},
            where="annotation.subtasks[]",
            error=AnnotationContractError,
        )
        end_raw = subtask["t_end_ns"]
        if end_raw is not None and (isinstance(end_raw, bool) or not isinstance(end_raw, int)):
            raise AnnotationContractError("subtask t_end_ns must be an integer or null")
        actions: list[SubtaskAction] = []
        for action_raw in decode.documents(subtask, "actions"):
            action = decode.exactly(
                action_raw,
                {"part", "skill", "target_items", "target_location", "description"},
                where="annotation.subtasks[].actions[]",
                error=AnnotationContractError,
            )
            actions.append(
                SubtaskAction(
                    part=decode.text(action, "part"),
                    skill=decode.text(action, "skill"),
                    target_items=tuple(decode.texts(action, "target_items")),
                    target_location=decode.text(action, "target_location"),
                    description=decode.text(action, "description"),
                )
            )
        subtasks.append(
            AnnotatedSubtask(
                ordinal=decode.integer(subtask, "ordinal"),
                t_start_ns=decode.integer(subtask, "t_start_ns"),
                t_end_ns=end_raw,
                status=SubtaskStatus(decode.text(subtask, "status")),
                description=decode.text(subtask, "description"),
                actions=tuple(actions),
            )
        )
    return EpisodeAnnotation(
        episode_id=decode.text(doc, "episode_id"),
        stage=AnnotationStage(decode.text(doc, "stage")),
        task=decode.text(doc, "task"),
        task_description=decode.text(doc, "task_description"),
        scene=decode.text(doc, "scene"),
        scene_description=decode.text(doc, "scene_description"),
        success=decode.boolean(doc, "success"),
        subtasks=tuple(subtasks),
    )


def annotation_sha256(annotation: EpisodeAnnotation) -> Sha256Digest:
    """The annotation's content identity — the same fact twice is one fact."""
    return content_digest(annotation_to_dict(annotation))
