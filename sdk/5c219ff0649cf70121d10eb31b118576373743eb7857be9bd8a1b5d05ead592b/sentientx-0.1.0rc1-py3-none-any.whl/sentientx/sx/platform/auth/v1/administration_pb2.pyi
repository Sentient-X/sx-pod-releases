import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.platform.auth.v1 import account_pb2 as _account_pb2
from sentientx.sx.platform.auth.v1 import organization_pb2 as _organization_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SeatKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SEAT_KIND_UNSPECIFIED: _ClassVar[SeatKind]
    SEAT_KIND_MEMBER: _ClassVar[SeatKind]
    SEAT_KIND_EMPLOYEE: _ClassVar[SeatKind]

class NodeKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    NODE_KIND_UNSPECIFIED: _ClassVar[NodeKind]
    NODE_KIND_POD: _ClassVar[NodeKind]
    NODE_KIND_CONTROLLER: _ClassVar[NodeKind]
    NODE_KIND_STATION: _ClassVar[NodeKind]
    NODE_KIND_UPLOADER: _ClassVar[NodeKind]
SEAT_KIND_UNSPECIFIED: SeatKind
SEAT_KIND_MEMBER: SeatKind
SEAT_KIND_EMPLOYEE: SeatKind
NODE_KIND_UNSPECIFIED: NodeKind
NODE_KIND_POD: NodeKind
NODE_KIND_CONTROLLER: NodeKind
NODE_KIND_STATION: NodeKind
NODE_KIND_UPLOADER: NodeKind

class PlatformOrganization(_message.Message):
    __slots__ = ("id", "slug", "display_name", "kind", "disabled")
    ID_FIELD_NUMBER: _ClassVar[int]
    SLUG_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    DISABLED_FIELD_NUMBER: _ClassVar[int]
    id: str
    slug: str
    display_name: str
    kind: _organization_pb2.OrgKind
    disabled: bool
    def __init__(self, id: _Optional[str] = ..., slug: _Optional[str] = ..., display_name: _Optional[str] = ..., kind: _Optional[_Union[_organization_pb2.OrgKind, str]] = ..., disabled: _Optional[bool] = ...) -> None: ...

class PlatformProject(_message.Message):
    __slots__ = ("id", "org_slug", "org_kind", "slug", "display_name", "objective", "disabled")
    ID_FIELD_NUMBER: _ClassVar[int]
    ORG_SLUG_FIELD_NUMBER: _ClassVar[int]
    ORG_KIND_FIELD_NUMBER: _ClassVar[int]
    SLUG_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    OBJECTIVE_FIELD_NUMBER: _ClassVar[int]
    DISABLED_FIELD_NUMBER: _ClassVar[int]
    id: str
    org_slug: str
    org_kind: _organization_pb2.OrgKind
    slug: str
    display_name: str
    objective: str
    disabled: bool
    def __init__(self, id: _Optional[str] = ..., org_slug: _Optional[str] = ..., org_kind: _Optional[_Union[_organization_pb2.OrgKind, str]] = ..., slug: _Optional[str] = ..., display_name: _Optional[str] = ..., objective: _Optional[str] = ..., disabled: _Optional[bool] = ...) -> None: ...

class PlatformUser(_message.Message):
    __slots__ = ("principal_id", "org_slug", "email", "display_name", "sso_only", "seat_kind", "disabled")
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    ORG_SLUG_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    SSO_ONLY_FIELD_NUMBER: _ClassVar[int]
    SEAT_KIND_FIELD_NUMBER: _ClassVar[int]
    DISABLED_FIELD_NUMBER: _ClassVar[int]
    principal_id: str
    org_slug: str
    email: str
    display_name: str
    sso_only: bool
    seat_kind: SeatKind
    disabled: bool
    def __init__(self, principal_id: _Optional[str] = ..., org_slug: _Optional[str] = ..., email: _Optional[str] = ..., display_name: _Optional[str] = ..., sso_only: _Optional[bool] = ..., seat_kind: _Optional[_Union[SeatKind, str]] = ..., disabled: _Optional[bool] = ...) -> None: ...

class ServicePrincipal(_message.Message):
    __slots__ = ("principal_id", "org_slug", "name", "description", "disabled")
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    ORG_SLUG_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DISABLED_FIELD_NUMBER: _ClassVar[int]
    principal_id: str
    org_slug: str
    name: str
    description: str
    disabled: bool
    def __init__(self, principal_id: _Optional[str] = ..., org_slug: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., disabled: _Optional[bool] = ...) -> None: ...

class MachineNode(_message.Message):
    __slots__ = ("principal_id", "org_slug", "kind", "node_id", "subject", "disabled")
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    ORG_SLUG_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    SUBJECT_FIELD_NUMBER: _ClassVar[int]
    DISABLED_FIELD_NUMBER: _ClassVar[int]
    principal_id: str
    org_slug: str
    kind: NodeKind
    node_id: str
    subject: str
    disabled: bool
    def __init__(self, principal_id: _Optional[str] = ..., org_slug: _Optional[str] = ..., kind: _Optional[_Union[NodeKind, str]] = ..., node_id: _Optional[str] = ..., subject: _Optional[str] = ..., disabled: _Optional[bool] = ...) -> None: ...

class PlatformGrant(_message.Message):
    __slots__ = ("id", "principal_id", "project_id", "project", "audience", "scope", "role", "revoked")
    ID_FIELD_NUMBER: _ClassVar[int]
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    AUDIENCE_FIELD_NUMBER: _ClassVar[int]
    SCOPE_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    REVOKED_FIELD_NUMBER: _ClassVar[int]
    id: str
    principal_id: str
    project_id: str
    project: str
    audience: str
    scope: str
    role: str
    revoked: bool
    def __init__(self, id: _Optional[str] = ..., principal_id: _Optional[str] = ..., project_id: _Optional[str] = ..., project: _Optional[str] = ..., audience: _Optional[str] = ..., scope: _Optional[str] = ..., role: _Optional[str] = ..., revoked: _Optional[bool] = ...) -> None: ...

class UnassignedGrant(_message.Message):
    __slots__ = ("id", "principal_id", "audience", "scope", "role", "revoked")
    ID_FIELD_NUMBER: _ClassVar[int]
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    AUDIENCE_FIELD_NUMBER: _ClassVar[int]
    SCOPE_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    REVOKED_FIELD_NUMBER: _ClassVar[int]
    id: str
    principal_id: str
    audience: str
    scope: str
    role: str
    revoked: bool
    def __init__(self, id: _Optional[str] = ..., principal_id: _Optional[str] = ..., audience: _Optional[str] = ..., scope: _Optional[str] = ..., role: _Optional[str] = ..., revoked: _Optional[bool] = ...) -> None: ...

class Audience(_message.Message):
    __slots__ = ("audience", "roles")
    AUDIENCE_FIELD_NUMBER: _ClassVar[int]
    ROLES_FIELD_NUMBER: _ClassVar[int]
    audience: str
    roles: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, audience: _Optional[str] = ..., roles: _Optional[_Iterable[str]] = ...) -> None: ...

class AudienceSeat(_message.Message):
    __slots__ = ("principal_id", "username", "email", "display_name", "roles", "disabled")
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    ROLES_FIELD_NUMBER: _ClassVar[int]
    DISABLED_FIELD_NUMBER: _ClassVar[int]
    principal_id: str
    username: str
    email: str
    display_name: str
    roles: _containers.RepeatedScalarFieldContainer[str]
    disabled: bool
    def __init__(self, principal_id: _Optional[str] = ..., username: _Optional[str] = ..., email: _Optional[str] = ..., display_name: _Optional[str] = ..., roles: _Optional[_Iterable[str]] = ..., disabled: _Optional[bool] = ...) -> None: ...

class ListPlatformOrganizationsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListPlatformOrganizationsResponse(_message.Message):
    __slots__ = ("organizations",)
    ORGANIZATIONS_FIELD_NUMBER: _ClassVar[int]
    organizations: _containers.RepeatedCompositeFieldContainer[PlatformOrganization]
    def __init__(self, organizations: _Optional[_Iterable[_Union[PlatformOrganization, _Mapping]]] = ...) -> None: ...

class CreatePlatformOrganizationRequest(_message.Message):
    __slots__ = ("slug", "display_name", "kind")
    SLUG_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    slug: str
    display_name: str
    kind: _organization_pb2.OrgKind
    def __init__(self, slug: _Optional[str] = ..., display_name: _Optional[str] = ..., kind: _Optional[_Union[_organization_pb2.OrgKind, str]] = ...) -> None: ...

class CreatePlatformOrganizationResponse(_message.Message):
    __slots__ = ("organization",)
    ORGANIZATION_FIELD_NUMBER: _ClassVar[int]
    organization: PlatformOrganization
    def __init__(self, organization: _Optional[_Union[PlatformOrganization, _Mapping]] = ...) -> None: ...

class DisablePlatformOrganizationRequest(_message.Message):
    __slots__ = ("slug",)
    SLUG_FIELD_NUMBER: _ClassVar[int]
    slug: str
    def __init__(self, slug: _Optional[str] = ...) -> None: ...

class DisablePlatformOrganizationResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListPlatformProjectsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListPlatformProjectsResponse(_message.Message):
    __slots__ = ("projects",)
    PROJECTS_FIELD_NUMBER: _ClassVar[int]
    projects: _containers.RepeatedCompositeFieldContainer[PlatformProject]
    def __init__(self, projects: _Optional[_Iterable[_Union[PlatformProject, _Mapping]]] = ...) -> None: ...

class DisablePlatformProjectRequest(_message.Message):
    __slots__ = ("project_id",)
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    def __init__(self, project_id: _Optional[str] = ...) -> None: ...

class DisablePlatformProjectResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListPlatformUsersRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListPlatformUsersResponse(_message.Message):
    __slots__ = ("users",)
    USERS_FIELD_NUMBER: _ClassVar[int]
    users: _containers.RepeatedCompositeFieldContainer[PlatformUser]
    def __init__(self, users: _Optional[_Iterable[_Union[PlatformUser, _Mapping]]] = ...) -> None: ...

class AccessRequest(_message.Message):
    __slots__ = ("id", "issuer", "subject", "email", "display_name", "requested_at", "last_seen_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    ISSUER_FIELD_NUMBER: _ClassVar[int]
    SUBJECT_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_AT_FIELD_NUMBER: _ClassVar[int]
    LAST_SEEN_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    issuer: str
    subject: str
    email: str
    display_name: str
    requested_at: _timestamp_pb2.Timestamp
    last_seen_at: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., issuer: _Optional[str] = ..., subject: _Optional[str] = ..., email: _Optional[str] = ..., display_name: _Optional[str] = ..., requested_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., last_seen_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ListAccessRequestsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListAccessRequestsResponse(_message.Message):
    __slots__ = ("requests",)
    REQUESTS_FIELD_NUMBER: _ClassVar[int]
    requests: _containers.RepeatedCompositeFieldContainer[AccessRequest]
    def __init__(self, requests: _Optional[_Iterable[_Union[AccessRequest, _Mapping]]] = ...) -> None: ...

class InviteOrganizationMemberRequest(_message.Message):
    __slots__ = ("organization_slug", "email", "display_name", "role")
    ORGANIZATION_SLUG_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    organization_slug: str
    email: str
    display_name: str
    role: _organization_pb2.OrganizationRole
    def __init__(self, organization_slug: _Optional[str] = ..., email: _Optional[str] = ..., display_name: _Optional[str] = ..., role: _Optional[_Union[_organization_pb2.OrganizationRole, str]] = ...) -> None: ...

class InviteOrganizationMemberResponse(_message.Message):
    __slots__ = ("member", "delivery")
    MEMBER_FIELD_NUMBER: _ClassVar[int]
    DELIVERY_FIELD_NUMBER: _ClassVar[int]
    member: _organization_pb2.OrganizationMember
    delivery: _organization_pb2.InvitationDelivery
    def __init__(self, member: _Optional[_Union[_organization_pb2.OrganizationMember, _Mapping]] = ..., delivery: _Optional[_Union[_organization_pb2.InvitationDelivery, str]] = ...) -> None: ...

class ListServicePrincipalsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListServicePrincipalsResponse(_message.Message):
    __slots__ = ("service_principals",)
    SERVICE_PRINCIPALS_FIELD_NUMBER: _ClassVar[int]
    service_principals: _containers.RepeatedCompositeFieldContainer[ServicePrincipal]
    def __init__(self, service_principals: _Optional[_Iterable[_Union[ServicePrincipal, _Mapping]]] = ...) -> None: ...

class ListPrincipalApiKeysRequest(_message.Message):
    __slots__ = ("principal_id",)
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    principal_id: str
    def __init__(self, principal_id: _Optional[str] = ...) -> None: ...

class ListPrincipalApiKeysResponse(_message.Message):
    __slots__ = ("keys",)
    KEYS_FIELD_NUMBER: _ClassVar[int]
    keys: _containers.RepeatedCompositeFieldContainer[_account_pb2.ApiKey]
    def __init__(self, keys: _Optional[_Iterable[_Union[_account_pb2.ApiKey, _Mapping]]] = ...) -> None: ...

class DisablePrincipalRequest(_message.Message):
    __slots__ = ("principal_id",)
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    principal_id: str
    def __init__(self, principal_id: _Optional[str] = ...) -> None: ...

class DisablePrincipalResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class EnablePrincipalRequest(_message.Message):
    __slots__ = ("principal_id",)
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    principal_id: str
    def __init__(self, principal_id: _Optional[str] = ...) -> None: ...

class EnablePrincipalResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SetPrincipalPasswordRequest(_message.Message):
    __slots__ = ("principal_id", "password")
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    PASSWORD_FIELD_NUMBER: _ClassVar[int]
    principal_id: str
    password: str
    def __init__(self, principal_id: _Optional[str] = ..., password: _Optional[str] = ...) -> None: ...

class SetPrincipalPasswordResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class RevokeUserSessionsRequest(_message.Message):
    __slots__ = ("email",)
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    email: str
    def __init__(self, email: _Optional[str] = ...) -> None: ...

class RevokeUserSessionsResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListPrincipalGrantsRequest(_message.Message):
    __slots__ = ("principal_id",)
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    principal_id: str
    def __init__(self, principal_id: _Optional[str] = ...) -> None: ...

class ListPrincipalGrantsResponse(_message.Message):
    __slots__ = ("grants",)
    GRANTS_FIELD_NUMBER: _ClassVar[int]
    grants: _containers.RepeatedCompositeFieldContainer[PlatformGrant]
    def __init__(self, grants: _Optional[_Iterable[_Union[PlatformGrant, _Mapping]]] = ...) -> None: ...

class ListUnassignedGrantsRequest(_message.Message):
    __slots__ = ("principal_id",)
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    principal_id: str
    def __init__(self, principal_id: _Optional[str] = ...) -> None: ...

class ListUnassignedGrantsResponse(_message.Message):
    __slots__ = ("grants",)
    GRANTS_FIELD_NUMBER: _ClassVar[int]
    grants: _containers.RepeatedCompositeFieldContainer[UnassignedGrant]
    def __init__(self, grants: _Optional[_Iterable[_Union[UnassignedGrant, _Mapping]]] = ...) -> None: ...

class CreateGrantRequest(_message.Message):
    __slots__ = ("principal_id", "project_id", "audience", "role", "scope")
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    AUDIENCE_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    SCOPE_FIELD_NUMBER: _ClassVar[int]
    principal_id: str
    project_id: str
    audience: str
    role: str
    scope: str
    def __init__(self, principal_id: _Optional[str] = ..., project_id: _Optional[str] = ..., audience: _Optional[str] = ..., role: _Optional[str] = ..., scope: _Optional[str] = ...) -> None: ...

class CreateGrantResponse(_message.Message):
    __slots__ = ("grant",)
    GRANT_FIELD_NUMBER: _ClassVar[int]
    grant: PlatformGrant
    def __init__(self, grant: _Optional[_Union[PlatformGrant, _Mapping]] = ...) -> None: ...

class BindGrantProjectRequest(_message.Message):
    __slots__ = ("grant_id", "project_id")
    GRANT_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    grant_id: str
    project_id: str
    def __init__(self, grant_id: _Optional[str] = ..., project_id: _Optional[str] = ...) -> None: ...

class BindGrantProjectResponse(_message.Message):
    __slots__ = ("grant",)
    GRANT_FIELD_NUMBER: _ClassVar[int]
    grant: PlatformGrant
    def __init__(self, grant: _Optional[_Union[PlatformGrant, _Mapping]] = ...) -> None: ...

class RevokeGrantRequest(_message.Message):
    __slots__ = ("grant_id",)
    GRANT_ID_FIELD_NUMBER: _ClassVar[int]
    grant_id: str
    def __init__(self, grant_id: _Optional[str] = ...) -> None: ...

class RevokeGrantResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListAudiencesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListAudiencesResponse(_message.Message):
    __slots__ = ("audiences",)
    AUDIENCES_FIELD_NUMBER: _ClassVar[int]
    audiences: _containers.RepeatedCompositeFieldContainer[Audience]
    def __init__(self, audiences: _Optional[_Iterable[_Union[Audience, _Mapping]]] = ...) -> None: ...

class ListAudienceSeatsRequest(_message.Message):
    __slots__ = ("audience",)
    AUDIENCE_FIELD_NUMBER: _ClassVar[int]
    audience: str
    def __init__(self, audience: _Optional[str] = ...) -> None: ...

class ListAudienceSeatsResponse(_message.Message):
    __slots__ = ("seats",)
    SEATS_FIELD_NUMBER: _ClassVar[int]
    seats: _containers.RepeatedCompositeFieldContainer[AudienceSeat]
    def __init__(self, seats: _Optional[_Iterable[_Union[AudienceSeat, _Mapping]]] = ...) -> None: ...

class SetAudienceSeatRoleRequest(_message.Message):
    __slots__ = ("audience", "principal_id", "role")
    AUDIENCE_FIELD_NUMBER: _ClassVar[int]
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    audience: str
    principal_id: str
    role: str
    def __init__(self, audience: _Optional[str] = ..., principal_id: _Optional[str] = ..., role: _Optional[str] = ...) -> None: ...

class SetAudienceSeatRoleResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListNodesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListNodesResponse(_message.Message):
    __slots__ = ("nodes",)
    NODES_FIELD_NUMBER: _ClassVar[int]
    nodes: _containers.RepeatedCompositeFieldContainer[MachineNode]
    def __init__(self, nodes: _Optional[_Iterable[_Union[MachineNode, _Mapping]]] = ...) -> None: ...

class DecommissionNodeRequest(_message.Message):
    __slots__ = ("subject",)
    SUBJECT_FIELD_NUMBER: _ClassVar[int]
    subject: str
    def __init__(self, subject: _Optional[str] = ...) -> None: ...

class DecommissionNodeResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
