from buf.validate import validate_pb2 as _validate_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class OrgKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ORG_KIND_UNSPECIFIED: _ClassVar[OrgKind]
    ORG_KIND_INTERNAL: _ClassVar[OrgKind]
    ORG_KIND_CUSTOMER: _ClassVar[OrgKind]
    ORG_KIND_VENDOR: _ClassVar[OrgKind]

class OrganizationRole(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ORGANIZATION_ROLE_UNSPECIFIED: _ClassVar[OrganizationRole]
    ORGANIZATION_ROLE_OWNER: _ClassVar[OrganizationRole]
    ORGANIZATION_ROLE_ADMIN: _ClassVar[OrganizationRole]
    ORGANIZATION_ROLE_BILLING_ADMIN: _ClassVar[OrganizationRole]
    ORGANIZATION_ROLE_MEMBER: _ClassVar[OrganizationRole]

class MembershipState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    MEMBERSHIP_STATE_UNSPECIFIED: _ClassVar[MembershipState]
    MEMBERSHIP_STATE_ACTIVE: _ClassVar[MembershipState]
    MEMBERSHIP_STATE_SUSPENDED: _ClassVar[MembershipState]
    MEMBERSHIP_STATE_REMOVED: _ClassVar[MembershipState]

class ProjectAccessRole(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PROJECT_ACCESS_ROLE_UNSPECIFIED: _ClassVar[ProjectAccessRole]
    PROJECT_ACCESS_ROLE_VIEWER: _ClassVar[ProjectAccessRole]
    PROJECT_ACCESS_ROLE_CONTRIBUTOR: _ClassVar[ProjectAccessRole]
    PROJECT_ACCESS_ROLE_ADMIN: _ClassVar[ProjectAccessRole]

class ProjectAccessSource(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PROJECT_ACCESS_SOURCE_UNSPECIFIED: _ClassVar[ProjectAccessSource]
    PROJECT_ACCESS_SOURCE_MANAGED: _ClassVar[ProjectAccessSource]
    PROJECT_ACCESS_SOURCE_ORGANIZATION_ROLE: _ClassVar[ProjectAccessSource]
    PROJECT_ACCESS_SOURCE_GRANT: _ClassVar[ProjectAccessSource]

class SearchKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SEARCH_KIND_UNSPECIFIED: _ClassVar[SearchKind]
    SEARCH_KIND_PROJECT: _ClassVar[SearchKind]
    SEARCH_KIND_TASK: _ClassVar[SearchKind]
    SEARCH_KIND_TASK_DRAFT: _ClassVar[SearchKind]
    SEARCH_KIND_COLLECTION_ORDER: _ClassVar[SearchKind]
    SEARCH_KIND_OBJECT: _ClassVar[SearchKind]
    SEARCH_KIND_DATASET: _ClassVar[SearchKind]
    SEARCH_KIND_ARTIFACT: _ClassVar[SearchKind]
    SEARCH_KIND_EPISODE: _ClassVar[SearchKind]
    SEARCH_KIND_ENVIRONMENT: _ClassVar[SearchKind]
    SEARCH_KIND_SCENE: _ClassVar[SearchKind]
    SEARCH_KIND_TRAINING_RUN: _ClassVar[SearchKind]
    SEARCH_KIND_CAMPAIGN: _ClassVar[SearchKind]
    SEARCH_KIND_CONVERSATION: _ClassVar[SearchKind]
    SEARCH_KIND_DEPLOYMENT_GROUP: _ClassVar[SearchKind]
    SEARCH_KIND_DEPLOYMENT: _ClassVar[SearchKind]
    SEARCH_KIND_ESCALATION: _ClassVar[SearchKind]
    SEARCH_KIND_DOCUMENTATION: _ClassVar[SearchKind]

class SearchSource(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SEARCH_SOURCE_UNSPECIFIED: _ClassVar[SearchSource]
    SEARCH_SOURCE_AUTH: _ClassVar[SearchSource]
    SEARCH_SOURCE_FACTORY: _ClassVar[SearchSource]
    SEARCH_SOURCE_CATALOG: _ClassVar[SearchSource]
    SEARCH_SOURCE_TASKPEDIA: _ClassVar[SearchSource]
    SEARCH_SOURCE_WORLDS: _ClassVar[SearchSource]
    SEARCH_SOURCE_AUTONOMY: _ClassVar[SearchSource]
    SEARCH_SOURCE_WADDLE: _ClassVar[SearchSource]
    SEARCH_SOURCE_FLEET: _ClassVar[SearchSource]
    SEARCH_SOURCE_DOCS: _ClassVar[SearchSource]

class InvitationDelivery(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    INVITATION_DELIVERY_UNSPECIFIED: _ClassVar[InvitationDelivery]
    INVITATION_DELIVERY_SENT: _ClassVar[InvitationDelivery]
    INVITATION_DELIVERY_ALREADY_SENT: _ClassVar[InvitationDelivery]
    INVITATION_DELIVERY_NOT_APPLICABLE: _ClassVar[InvitationDelivery]
ORG_KIND_UNSPECIFIED: OrgKind
ORG_KIND_INTERNAL: OrgKind
ORG_KIND_CUSTOMER: OrgKind
ORG_KIND_VENDOR: OrgKind
ORGANIZATION_ROLE_UNSPECIFIED: OrganizationRole
ORGANIZATION_ROLE_OWNER: OrganizationRole
ORGANIZATION_ROLE_ADMIN: OrganizationRole
ORGANIZATION_ROLE_BILLING_ADMIN: OrganizationRole
ORGANIZATION_ROLE_MEMBER: OrganizationRole
MEMBERSHIP_STATE_UNSPECIFIED: MembershipState
MEMBERSHIP_STATE_ACTIVE: MembershipState
MEMBERSHIP_STATE_SUSPENDED: MembershipState
MEMBERSHIP_STATE_REMOVED: MembershipState
PROJECT_ACCESS_ROLE_UNSPECIFIED: ProjectAccessRole
PROJECT_ACCESS_ROLE_VIEWER: ProjectAccessRole
PROJECT_ACCESS_ROLE_CONTRIBUTOR: ProjectAccessRole
PROJECT_ACCESS_ROLE_ADMIN: ProjectAccessRole
PROJECT_ACCESS_SOURCE_UNSPECIFIED: ProjectAccessSource
PROJECT_ACCESS_SOURCE_MANAGED: ProjectAccessSource
PROJECT_ACCESS_SOURCE_ORGANIZATION_ROLE: ProjectAccessSource
PROJECT_ACCESS_SOURCE_GRANT: ProjectAccessSource
SEARCH_KIND_UNSPECIFIED: SearchKind
SEARCH_KIND_PROJECT: SearchKind
SEARCH_KIND_TASK: SearchKind
SEARCH_KIND_TASK_DRAFT: SearchKind
SEARCH_KIND_COLLECTION_ORDER: SearchKind
SEARCH_KIND_OBJECT: SearchKind
SEARCH_KIND_DATASET: SearchKind
SEARCH_KIND_ARTIFACT: SearchKind
SEARCH_KIND_EPISODE: SearchKind
SEARCH_KIND_ENVIRONMENT: SearchKind
SEARCH_KIND_SCENE: SearchKind
SEARCH_KIND_TRAINING_RUN: SearchKind
SEARCH_KIND_CAMPAIGN: SearchKind
SEARCH_KIND_CONVERSATION: SearchKind
SEARCH_KIND_DEPLOYMENT_GROUP: SearchKind
SEARCH_KIND_DEPLOYMENT: SearchKind
SEARCH_KIND_ESCALATION: SearchKind
SEARCH_KIND_DOCUMENTATION: SearchKind
SEARCH_SOURCE_UNSPECIFIED: SearchSource
SEARCH_SOURCE_AUTH: SearchSource
SEARCH_SOURCE_FACTORY: SearchSource
SEARCH_SOURCE_CATALOG: SearchSource
SEARCH_SOURCE_TASKPEDIA: SearchSource
SEARCH_SOURCE_WORLDS: SearchSource
SEARCH_SOURCE_AUTONOMY: SearchSource
SEARCH_SOURCE_WADDLE: SearchSource
SEARCH_SOURCE_FLEET: SearchSource
SEARCH_SOURCE_DOCS: SearchSource
INVITATION_DELIVERY_UNSPECIFIED: InvitationDelivery
INVITATION_DELIVERY_SENT: InvitationDelivery
INVITATION_DELIVERY_ALREADY_SENT: InvitationDelivery
INVITATION_DELIVERY_NOT_APPLICABLE: InvitationDelivery

class Organization(_message.Message):
    __slots__ = ("id", "slug", "display_name", "kind", "role")
    ID_FIELD_NUMBER: _ClassVar[int]
    SLUG_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    id: str
    slug: str
    display_name: str
    kind: OrgKind
    role: OrganizationRole
    def __init__(self, id: _Optional[str] = ..., slug: _Optional[str] = ..., display_name: _Optional[str] = ..., kind: _Optional[_Union[OrgKind, str]] = ..., role: _Optional[_Union[OrganizationRole, str]] = ...) -> None: ...

class OrganizationMember(_message.Message):
    __slots__ = ("principal_id", "email", "display_name", "role", "status")
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    principal_id: str
    email: str
    display_name: str
    role: OrganizationRole
    status: MembershipState
    def __init__(self, principal_id: _Optional[str] = ..., email: _Optional[str] = ..., display_name: _Optional[str] = ..., role: _Optional[_Union[OrganizationRole, str]] = ..., status: _Optional[_Union[MembershipState, str]] = ...) -> None: ...

class Project(_message.Message):
    __slots__ = ("id", "organization_id", "organization_slug", "slug", "display_name", "objective", "disabled", "managed_access_role")
    ID_FIELD_NUMBER: _ClassVar[int]
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    ORGANIZATION_SLUG_FIELD_NUMBER: _ClassVar[int]
    SLUG_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    OBJECTIVE_FIELD_NUMBER: _ClassVar[int]
    DISABLED_FIELD_NUMBER: _ClassVar[int]
    MANAGED_ACCESS_ROLE_FIELD_NUMBER: _ClassVar[int]
    id: str
    organization_id: str
    organization_slug: str
    slug: str
    display_name: str
    objective: str
    disabled: bool
    managed_access_role: ProjectAccessRole
    def __init__(self, id: _Optional[str] = ..., organization_id: _Optional[str] = ..., organization_slug: _Optional[str] = ..., slug: _Optional[str] = ..., display_name: _Optional[str] = ..., objective: _Optional[str] = ..., disabled: _Optional[bool] = ..., managed_access_role: _Optional[_Union[ProjectAccessRole, str]] = ...) -> None: ...

class ProjectGrant(_message.Message):
    __slots__ = ("id", "audience", "scope", "role")
    ID_FIELD_NUMBER: _ClassVar[int]
    AUDIENCE_FIELD_NUMBER: _ClassVar[int]
    SCOPE_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    id: str
    audience: str
    scope: str
    role: str
    def __init__(self, id: _Optional[str] = ..., audience: _Optional[str] = ..., scope: _Optional[str] = ..., role: _Optional[str] = ...) -> None: ...

class ProjectMember(_message.Message):
    __slots__ = ("principal_id", "email", "display_name", "organization_role", "project_role", "source", "grants")
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    ORGANIZATION_ROLE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ROLE_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    GRANTS_FIELD_NUMBER: _ClassVar[int]
    principal_id: str
    email: str
    display_name: str
    organization_role: OrganizationRole
    project_role: ProjectAccessRole
    source: ProjectAccessSource
    grants: _containers.RepeatedCompositeFieldContainer[ProjectGrant]
    def __init__(self, principal_id: _Optional[str] = ..., email: _Optional[str] = ..., display_name: _Optional[str] = ..., organization_role: _Optional[_Union[OrganizationRole, str]] = ..., project_role: _Optional[_Union[ProjectAccessRole, str]] = ..., source: _Optional[_Union[ProjectAccessSource, str]] = ..., grants: _Optional[_Iterable[_Union[ProjectGrant, _Mapping]]] = ...) -> None: ...

class SearchHit(_message.Message):
    __slots__ = ("source", "kind", "project_id", "resource_id", "label", "detail")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    RESOURCE_ID_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    DETAIL_FIELD_NUMBER: _ClassVar[int]
    source: SearchSource
    kind: SearchKind
    project_id: str
    resource_id: str
    label: str
    detail: str
    def __init__(self, source: _Optional[_Union[SearchSource, str]] = ..., kind: _Optional[_Union[SearchKind, str]] = ..., project_id: _Optional[str] = ..., resource_id: _Optional[str] = ..., label: _Optional[str] = ..., detail: _Optional[str] = ...) -> None: ...

class ListOrganizationsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListOrganizationsResponse(_message.Message):
    __slots__ = ("organizations",)
    ORGANIZATIONS_FIELD_NUMBER: _ClassVar[int]
    organizations: _containers.RepeatedCompositeFieldContainer[Organization]
    def __init__(self, organizations: _Optional[_Iterable[_Union[Organization, _Mapping]]] = ...) -> None: ...

class CreateOrganizationRequest(_message.Message):
    __slots__ = ("slug", "display_name")
    SLUG_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    slug: str
    display_name: str
    def __init__(self, slug: _Optional[str] = ..., display_name: _Optional[str] = ...) -> None: ...

class CreateOrganizationResponse(_message.Message):
    __slots__ = ("organization",)
    ORGANIZATION_FIELD_NUMBER: _ClassVar[int]
    organization: Organization
    def __init__(self, organization: _Optional[_Union[Organization, _Mapping]] = ...) -> None: ...

class ListOrganizationMembersRequest(_message.Message):
    __slots__ = ("organization_id",)
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    def __init__(self, organization_id: _Optional[str] = ...) -> None: ...

class ListOrganizationMembersResponse(_message.Message):
    __slots__ = ("members",)
    MEMBERS_FIELD_NUMBER: _ClassVar[int]
    members: _containers.RepeatedCompositeFieldContainer[OrganizationMember]
    def __init__(self, members: _Optional[_Iterable[_Union[OrganizationMember, _Mapping]]] = ...) -> None: ...

class PutOrganizationMemberRequest(_message.Message):
    __slots__ = ("organization_id", "email", "display_name", "role")
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    email: str
    display_name: str
    role: OrganizationRole
    def __init__(self, organization_id: _Optional[str] = ..., email: _Optional[str] = ..., display_name: _Optional[str] = ..., role: _Optional[_Union[OrganizationRole, str]] = ...) -> None: ...

class PutOrganizationMemberResponse(_message.Message):
    __slots__ = ("member", "delivery")
    MEMBER_FIELD_NUMBER: _ClassVar[int]
    DELIVERY_FIELD_NUMBER: _ClassVar[int]
    member: OrganizationMember
    delivery: InvitationDelivery
    def __init__(self, member: _Optional[_Union[OrganizationMember, _Mapping]] = ..., delivery: _Optional[_Union[InvitationDelivery, str]] = ...) -> None: ...

class ListProjectAccessRolesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ProjectAccessRoleGrant(_message.Message):
    __slots__ = ("role", "audience", "grant_role", "scope")
    ROLE_FIELD_NUMBER: _ClassVar[int]
    AUDIENCE_FIELD_NUMBER: _ClassVar[int]
    GRANT_ROLE_FIELD_NUMBER: _ClassVar[int]
    SCOPE_FIELD_NUMBER: _ClassVar[int]
    role: ProjectAccessRole
    audience: str
    grant_role: str
    scope: str
    def __init__(self, role: _Optional[_Union[ProjectAccessRole, str]] = ..., audience: _Optional[str] = ..., grant_role: _Optional[str] = ..., scope: _Optional[str] = ...) -> None: ...

class ListProjectAccessRolesResponse(_message.Message):
    __slots__ = ("grants",)
    GRANTS_FIELD_NUMBER: _ClassVar[int]
    grants: _containers.RepeatedCompositeFieldContainer[ProjectAccessRoleGrant]
    def __init__(self, grants: _Optional[_Iterable[_Union[ProjectAccessRoleGrant, _Mapping]]] = ...) -> None: ...

class RemoveOrganizationMemberRequest(_message.Message):
    __slots__ = ("organization_id", "principal_id")
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    principal_id: str
    def __init__(self, organization_id: _Optional[str] = ..., principal_id: _Optional[str] = ...) -> None: ...

class RemoveOrganizationMemberResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListOrganizationProjectsRequest(_message.Message):
    __slots__ = ("organization_id",)
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    def __init__(self, organization_id: _Optional[str] = ...) -> None: ...

class ListOrganizationProjectsResponse(_message.Message):
    __slots__ = ("projects",)
    PROJECTS_FIELD_NUMBER: _ClassVar[int]
    projects: _containers.RepeatedCompositeFieldContainer[Project]
    def __init__(self, projects: _Optional[_Iterable[_Union[Project, _Mapping]]] = ...) -> None: ...

class CreateProjectRequest(_message.Message):
    __slots__ = ("organization_id", "slug", "display_name", "objective")
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    SLUG_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    OBJECTIVE_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    slug: str
    display_name: str
    objective: str
    def __init__(self, organization_id: _Optional[str] = ..., slug: _Optional[str] = ..., display_name: _Optional[str] = ..., objective: _Optional[str] = ...) -> None: ...

class CreateProjectResponse(_message.Message):
    __slots__ = ("project",)
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    project: Project
    def __init__(self, project: _Optional[_Union[Project, _Mapping]] = ...) -> None: ...

class GetProjectRequest(_message.Message):
    __slots__ = ("project_id",)
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    def __init__(self, project_id: _Optional[str] = ...) -> None: ...

class GetProjectResponse(_message.Message):
    __slots__ = ("project",)
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    project: Project
    def __init__(self, project: _Optional[_Union[Project, _Mapping]] = ...) -> None: ...

class PutProjectObjectiveRequest(_message.Message):
    __slots__ = ("project_id", "objective")
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    OBJECTIVE_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    objective: str
    def __init__(self, project_id: _Optional[str] = ..., objective: _Optional[str] = ...) -> None: ...

class PutProjectObjectiveResponse(_message.Message):
    __slots__ = ("project",)
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    project: Project
    def __init__(self, project: _Optional[_Union[Project, _Mapping]] = ...) -> None: ...

class ListProjectMembersRequest(_message.Message):
    __slots__ = ("project_id",)
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    def __init__(self, project_id: _Optional[str] = ...) -> None: ...

class ListProjectMembersResponse(_message.Message):
    __slots__ = ("members",)
    MEMBERS_FIELD_NUMBER: _ClassVar[int]
    members: _containers.RepeatedCompositeFieldContainer[ProjectMember]
    def __init__(self, members: _Optional[_Iterable[_Union[ProjectMember, _Mapping]]] = ...) -> None: ...

class ProjectAccess(_message.Message):
    __slots__ = ("project_id", "source", "role")
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    source: ProjectAccessSource
    role: ProjectAccessRole
    def __init__(self, project_id: _Optional[str] = ..., source: _Optional[_Union[ProjectAccessSource, str]] = ..., role: _Optional[_Union[ProjectAccessRole, str]] = ...) -> None: ...

class OrganizationAccess(_message.Message):
    __slots__ = ("member", "projects")
    MEMBER_FIELD_NUMBER: _ClassVar[int]
    PROJECTS_FIELD_NUMBER: _ClassVar[int]
    member: OrganizationMember
    projects: _containers.RepeatedCompositeFieldContainer[ProjectAccess]
    def __init__(self, member: _Optional[_Union[OrganizationMember, _Mapping]] = ..., projects: _Optional[_Iterable[_Union[ProjectAccess, _Mapping]]] = ...) -> None: ...

class ListOrganizationAccessRequest(_message.Message):
    __slots__ = ("organization_id",)
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    def __init__(self, organization_id: _Optional[str] = ...) -> None: ...

class ListOrganizationAccessResponse(_message.Message):
    __slots__ = ("projects", "people")
    PROJECTS_FIELD_NUMBER: _ClassVar[int]
    PEOPLE_FIELD_NUMBER: _ClassVar[int]
    projects: _containers.RepeatedCompositeFieldContainer[Project]
    people: _containers.RepeatedCompositeFieldContainer[OrganizationAccess]
    def __init__(self, projects: _Optional[_Iterable[_Union[Project, _Mapping]]] = ..., people: _Optional[_Iterable[_Union[OrganizationAccess, _Mapping]]] = ...) -> None: ...

class ListProjectMemberCandidatesRequest(_message.Message):
    __slots__ = ("project_id",)
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    def __init__(self, project_id: _Optional[str] = ...) -> None: ...

class ListProjectMemberCandidatesResponse(_message.Message):
    __slots__ = ("candidates",)
    CANDIDATES_FIELD_NUMBER: _ClassVar[int]
    candidates: _containers.RepeatedCompositeFieldContainer[OrganizationMember]
    def __init__(self, candidates: _Optional[_Iterable[_Union[OrganizationMember, _Mapping]]] = ...) -> None: ...

class PutProjectMemberRequest(_message.Message):
    __slots__ = ("project_id", "principal_id", "role")
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    principal_id: str
    role: ProjectAccessRole
    def __init__(self, project_id: _Optional[str] = ..., principal_id: _Optional[str] = ..., role: _Optional[_Union[ProjectAccessRole, str]] = ...) -> None: ...

class PutProjectMemberResponse(_message.Message):
    __slots__ = ("member",)
    MEMBER_FIELD_NUMBER: _ClassVar[int]
    member: ProjectMember
    def __init__(self, member: _Optional[_Union[ProjectMember, _Mapping]] = ...) -> None: ...

class RemoveProjectMemberRequest(_message.Message):
    __slots__ = ("project_id", "principal_id")
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    principal_id: str
    def __init__(self, project_id: _Optional[str] = ..., principal_id: _Optional[str] = ...) -> None: ...

class RemoveProjectMemberResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SearchRequest(_message.Message):
    __slots__ = ("query", "limit")
    QUERY_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    query: str
    limit: int
    def __init__(self, query: _Optional[str] = ..., limit: _Optional[int] = ...) -> None: ...

class ListProjectsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListProjectsResponse(_message.Message):
    __slots__ = ("projects",)
    PROJECTS_FIELD_NUMBER: _ClassVar[int]
    projects: _containers.RepeatedCompositeFieldContainer[Project]
    def __init__(self, projects: _Optional[_Iterable[_Union[Project, _Mapping]]] = ...) -> None: ...

class VerifyProjectAccessRequest(_message.Message):
    __slots__ = ("project_id",)
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    def __init__(self, project_id: _Optional[str] = ...) -> None: ...

class VerifyProjectAccessResponse(_message.Message):
    __slots__ = ("project",)
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    project: Project
    def __init__(self, project: _Optional[_Union[Project, _Mapping]] = ...) -> None: ...

class SearchResponse(_message.Message):
    __slots__ = ("results", "unavailable_sources")
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    UNAVAILABLE_SOURCES_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SearchHit]
    unavailable_sources: _containers.RepeatedScalarFieldContainer[SearchSource]
    def __init__(self, results: _Optional[_Iterable[_Union[SearchHit, _Mapping]]] = ..., unavailable_sources: _Optional[_Iterable[_Union[SearchSource, str]]] = ...) -> None: ...
