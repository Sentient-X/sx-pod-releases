import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class BillingPlan(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    BILLING_PLAN_UNSPECIFIED: _ClassVar[BillingPlan]
    BILLING_PLAN_USAGE_BASED: _ClassVar[BillingPlan]

class BillingAccountStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    BILLING_ACCOUNT_STATUS_UNSPECIFIED: _ClassVar[BillingAccountStatus]
    BILLING_ACCOUNT_STATUS_ACTIVE: _ClassVar[BillingAccountStatus]
    BILLING_ACCOUNT_STATUS_PAST_DUE: _ClassVar[BillingAccountStatus]
    BILLING_ACCOUNT_STATUS_CLOSED: _ClassVar[BillingAccountStatus]

class ProjectBillingSetup(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PROJECT_BILLING_SETUP_UNSPECIFIED: _ClassVar[ProjectBillingSetup]
    PROJECT_BILLING_SETUP_ORGANIZATION: _ClassVar[ProjectBillingSetup]
    PROJECT_BILLING_SETUP_PROJECT: _ClassVar[ProjectBillingSetup]

class BillingAuditDimension(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    BILLING_AUDIT_DIMENSION_UNSPECIFIED: _ClassVar[BillingAuditDimension]
    BILLING_AUDIT_DIMENSION_CATEGORY: _ClassVar[BillingAuditDimension]
    BILLING_AUDIT_DIMENSION_METER: _ClassVar[BillingAuditDimension]
    BILLING_AUDIT_DIMENSION_SOURCE: _ClassVar[BillingAuditDimension]
    BILLING_AUDIT_DIMENSION_PROJECT: _ClassVar[BillingAuditDimension]
    BILLING_AUDIT_DIMENSION_DATE: _ClassVar[BillingAuditDimension]

class BillingOutcome(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    BILLING_OUTCOME_UNSPECIFIED: _ClassVar[BillingOutcome]
    BILLING_OUTCOME_SUCCEEDED: _ClassVar[BillingOutcome]
    BILLING_OUTCOME_FAILED: _ClassVar[BillingOutcome]
    BILLING_OUTCOME_CANCELLED: _ClassVar[BillingOutcome]
BILLING_PLAN_UNSPECIFIED: BillingPlan
BILLING_PLAN_USAGE_BASED: BillingPlan
BILLING_ACCOUNT_STATUS_UNSPECIFIED: BillingAccountStatus
BILLING_ACCOUNT_STATUS_ACTIVE: BillingAccountStatus
BILLING_ACCOUNT_STATUS_PAST_DUE: BillingAccountStatus
BILLING_ACCOUNT_STATUS_CLOSED: BillingAccountStatus
PROJECT_BILLING_SETUP_UNSPECIFIED: ProjectBillingSetup
PROJECT_BILLING_SETUP_ORGANIZATION: ProjectBillingSetup
PROJECT_BILLING_SETUP_PROJECT: ProjectBillingSetup
BILLING_AUDIT_DIMENSION_UNSPECIFIED: BillingAuditDimension
BILLING_AUDIT_DIMENSION_CATEGORY: BillingAuditDimension
BILLING_AUDIT_DIMENSION_METER: BillingAuditDimension
BILLING_AUDIT_DIMENSION_SOURCE: BillingAuditDimension
BILLING_AUDIT_DIMENSION_PROJECT: BillingAuditDimension
BILLING_AUDIT_DIMENSION_DATE: BillingAuditDimension
BILLING_OUTCOME_UNSPECIFIED: BillingOutcome
BILLING_OUTCOME_SUCCEEDED: BillingOutcome
BILLING_OUTCOME_FAILED: BillingOutcome
BILLING_OUTCOME_CANCELLED: BillingOutcome

class BillingAccount(_message.Message):
    __slots__ = ("organization_id", "plan", "status")
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    PLAN_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    plan: BillingPlan
    status: BillingAccountStatus
    def __init__(self, organization_id: _Optional[str] = ..., plan: _Optional[_Union[BillingPlan, str]] = ..., status: _Optional[_Union[BillingAccountStatus, str]] = ...) -> None: ...

class OrganizationBillingState(_message.Message):
    __slots__ = ("unconfigured_organization_id", "configured")
    UNCONFIGURED_ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    CONFIGURED_FIELD_NUMBER: _ClassVar[int]
    unconfigured_organization_id: str
    configured: BillingAccount
    def __init__(self, unconfigured_organization_id: _Optional[str] = ..., configured: _Optional[_Union[BillingAccount, _Mapping]] = ...) -> None: ...

class BillingAuditBreakdown(_message.Message):
    __slots__ = ("dimension", "key", "label", "amount", "quantity", "event_count")
    DIMENSION_FIELD_NUMBER: _ClassVar[int]
    KEY_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    EVENT_COUNT_FIELD_NUMBER: _ClassVar[int]
    dimension: BillingAuditDimension
    key: str
    label: str
    amount: str
    quantity: int
    event_count: int
    def __init__(self, dimension: _Optional[_Union[BillingAuditDimension, str]] = ..., key: _Optional[str] = ..., label: _Optional[str] = ..., amount: _Optional[str] = ..., quantity: _Optional[int] = ..., event_count: _Optional[int] = ...) -> None: ...

class BillingAuditLine(_message.Message):
    __slots__ = ("usage_id", "project_id", "project_name", "window_start", "window_end", "subject_kind", "subject", "outcome", "source_principal_id", "source_kind", "source_name", "meter", "meter_version", "quantity", "priced_from", "cost_per_unit", "markup", "amount", "currency", "billing_delivered_at")
    USAGE_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_NAME_FIELD_NUMBER: _ClassVar[int]
    WINDOW_START_FIELD_NUMBER: _ClassVar[int]
    WINDOW_END_FIELD_NUMBER: _ClassVar[int]
    SUBJECT_KIND_FIELD_NUMBER: _ClassVar[int]
    SUBJECT_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    SOURCE_PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_KIND_FIELD_NUMBER: _ClassVar[int]
    SOURCE_NAME_FIELD_NUMBER: _ClassVar[int]
    METER_FIELD_NUMBER: _ClassVar[int]
    METER_VERSION_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    PRICED_FROM_FIELD_NUMBER: _ClassVar[int]
    COST_PER_UNIT_FIELD_NUMBER: _ClassVar[int]
    MARKUP_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    BILLING_DELIVERED_AT_FIELD_NUMBER: _ClassVar[int]
    usage_id: str
    project_id: str
    project_name: str
    window_start: _timestamp_pb2.Timestamp
    window_end: _timestamp_pb2.Timestamp
    subject_kind: str
    subject: str
    outcome: BillingOutcome
    source_principal_id: str
    source_kind: str
    source_name: str
    meter: str
    meter_version: int
    quantity: int
    priced_from: _timestamp_pb2.Timestamp
    cost_per_unit: str
    markup: str
    amount: str
    currency: str
    billing_delivered_at: _timestamp_pb2.Timestamp
    def __init__(self, usage_id: _Optional[str] = ..., project_id: _Optional[str] = ..., project_name: _Optional[str] = ..., window_start: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., window_end: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., subject_kind: _Optional[str] = ..., subject: _Optional[str] = ..., outcome: _Optional[_Union[BillingOutcome, str]] = ..., source_principal_id: _Optional[str] = ..., source_kind: _Optional[str] = ..., source_name: _Optional[str] = ..., meter: _Optional[str] = ..., meter_version: _Optional[int] = ..., quantity: _Optional[int] = ..., priced_from: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., cost_per_unit: _Optional[str] = ..., markup: _Optional[str] = ..., amount: _Optional[str] = ..., currency: _Optional[str] = ..., billing_delivered_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class BillingAudit(_message.Message):
    __slots__ = ("window_start", "window_end", "page", "page_size", "total_lines", "total_amount", "delivered_amount", "lines", "breakdowns")
    WINDOW_START_FIELD_NUMBER: _ClassVar[int]
    WINDOW_END_FIELD_NUMBER: _ClassVar[int]
    PAGE_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    TOTAL_LINES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    DELIVERED_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    LINES_FIELD_NUMBER: _ClassVar[int]
    BREAKDOWNS_FIELD_NUMBER: _ClassVar[int]
    window_start: _timestamp_pb2.Timestamp
    window_end: _timestamp_pb2.Timestamp
    page: int
    page_size: int
    total_lines: int
    total_amount: str
    delivered_amount: str
    lines: _containers.RepeatedCompositeFieldContainer[BillingAuditLine]
    breakdowns: _containers.RepeatedCompositeFieldContainer[BillingAuditBreakdown]
    def __init__(self, window_start: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., window_end: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., page: _Optional[int] = ..., page_size: _Optional[int] = ..., total_lines: _Optional[int] = ..., total_amount: _Optional[str] = ..., delivered_amount: _Optional[str] = ..., lines: _Optional[_Iterable[_Union[BillingAuditLine, _Mapping]]] = ..., breakdowns: _Optional[_Iterable[_Union[BillingAuditBreakdown, _Mapping]]] = ...) -> None: ...

class ProjectBillingLimits(_message.Message):
    __slots__ = ("warning_cents", "critical_cents", "hard_limit_cents")
    WARNING_CENTS_FIELD_NUMBER: _ClassVar[int]
    CRITICAL_CENTS_FIELD_NUMBER: _ClassVar[int]
    HARD_LIMIT_CENTS_FIELD_NUMBER: _ClassVar[int]
    warning_cents: int
    critical_cents: int
    hard_limit_cents: int
    def __init__(self, warning_cents: _Optional[int] = ..., critical_cents: _Optional[int] = ..., hard_limit_cents: _Optional[int] = ...) -> None: ...

class ProjectBillingCharge(_message.Message):
    __slots__ = ("name", "code", "units", "events_count", "amount_cents")
    NAME_FIELD_NUMBER: _ClassVar[int]
    CODE_FIELD_NUMBER: _ClassVar[int]
    UNITS_FIELD_NUMBER: _ClassVar[int]
    EVENTS_COUNT_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_CENTS_FIELD_NUMBER: _ClassVar[int]
    name: str
    code: str
    units: str
    events_count: int
    amount_cents: int
    def __init__(self, name: _Optional[str] = ..., code: _Optional[str] = ..., units: _Optional[str] = ..., events_count: _Optional[int] = ..., amount_cents: _Optional[int] = ...) -> None: ...

class ProjectBillingPeriod(_message.Message):
    __slots__ = ("period_start", "period_end", "amount_cents")
    PERIOD_START_FIELD_NUMBER: _ClassVar[int]
    PERIOD_END_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_CENTS_FIELD_NUMBER: _ClassVar[int]
    period_start: _timestamp_pb2.Timestamp
    period_end: _timestamp_pb2.Timestamp
    amount_cents: int
    def __init__(self, period_start: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., period_end: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., amount_cents: _Optional[int] = ...) -> None: ...

class ProjectBillingConfigured(_message.Message):
    __slots__ = ("project_id", "plan", "period_start", "period_end", "amount_cents", "projected_amount_cents", "currency", "limits", "charges", "history")
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    PLAN_FIELD_NUMBER: _ClassVar[int]
    PERIOD_START_FIELD_NUMBER: _ClassVar[int]
    PERIOD_END_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_CENTS_FIELD_NUMBER: _ClassVar[int]
    PROJECTED_AMOUNT_CENTS_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LIMITS_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    HISTORY_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    plan: BillingPlan
    period_start: _timestamp_pb2.Timestamp
    period_end: _timestamp_pb2.Timestamp
    amount_cents: int
    projected_amount_cents: int
    currency: str
    limits: ProjectBillingLimits
    charges: _containers.RepeatedCompositeFieldContainer[ProjectBillingCharge]
    history: _containers.RepeatedCompositeFieldContainer[ProjectBillingPeriod]
    def __init__(self, project_id: _Optional[str] = ..., plan: _Optional[_Union[BillingPlan, str]] = ..., period_start: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., period_end: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., amount_cents: _Optional[int] = ..., projected_amount_cents: _Optional[int] = ..., currency: _Optional[str] = ..., limits: _Optional[_Union[ProjectBillingLimits, _Mapping]] = ..., charges: _Optional[_Iterable[_Union[ProjectBillingCharge, _Mapping]]] = ..., history: _Optional[_Iterable[_Union[ProjectBillingPeriod, _Mapping]]] = ...) -> None: ...

class ProjectBillingUnconfigured(_message.Message):
    __slots__ = ("project_id", "setup")
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    SETUP_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    setup: ProjectBillingSetup
    def __init__(self, project_id: _Optional[str] = ..., setup: _Optional[_Union[ProjectBillingSetup, str]] = ...) -> None: ...

class ProjectBillingState(_message.Message):
    __slots__ = ("unconfigured", "configured")
    UNCONFIGURED_FIELD_NUMBER: _ClassVar[int]
    CONFIGURED_FIELD_NUMBER: _ClassVar[int]
    unconfigured: ProjectBillingUnconfigured
    configured: ProjectBillingConfigured
    def __init__(self, unconfigured: _Optional[_Union[ProjectBillingUnconfigured, _Mapping]] = ..., configured: _Optional[_Union[ProjectBillingConfigured, _Mapping]] = ...) -> None: ...

class BillingWalletTransaction(_message.Message):
    __slots__ = ("transaction_id", "status", "transaction_status", "transaction_type", "amount", "credit_amount", "remaining_amount_cents", "settled_at", "created_at", "name", "metadata")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    TRANSACTION_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TRANSACTION_STATUS_FIELD_NUMBER: _ClassVar[int]
    TRANSACTION_TYPE_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    CREDIT_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    REMAINING_AMOUNT_CENTS_FIELD_NUMBER: _ClassVar[int]
    SETTLED_AT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    transaction_id: str
    status: str
    transaction_status: str
    transaction_type: str
    amount: str
    credit_amount: str
    remaining_amount_cents: int
    settled_at: _timestamp_pb2.Timestamp
    created_at: _timestamp_pb2.Timestamp
    name: str
    metadata: _containers.ScalarMap[str, str]
    def __init__(self, transaction_id: _Optional[str] = ..., status: _Optional[str] = ..., transaction_status: _Optional[str] = ..., transaction_type: _Optional[str] = ..., amount: _Optional[str] = ..., credit_amount: _Optional[str] = ..., remaining_amount_cents: _Optional[int] = ..., settled_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., name: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ...) -> None: ...

class BillingWalletConfigured(_message.Message):
    __slots__ = ("organization_id", "name", "code", "balance_cents", "ongoing_balance_cents", "ongoing_usage_balance_cents", "currency", "last_balance_sync_at", "transactions")
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CODE_FIELD_NUMBER: _ClassVar[int]
    BALANCE_CENTS_FIELD_NUMBER: _ClassVar[int]
    ONGOING_BALANCE_CENTS_FIELD_NUMBER: _ClassVar[int]
    ONGOING_USAGE_BALANCE_CENTS_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LAST_BALANCE_SYNC_AT_FIELD_NUMBER: _ClassVar[int]
    TRANSACTIONS_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    name: str
    code: str
    balance_cents: int
    ongoing_balance_cents: int
    ongoing_usage_balance_cents: int
    currency: str
    last_balance_sync_at: _timestamp_pb2.Timestamp
    transactions: _containers.RepeatedCompositeFieldContainer[BillingWalletTransaction]
    def __init__(self, organization_id: _Optional[str] = ..., name: _Optional[str] = ..., code: _Optional[str] = ..., balance_cents: _Optional[int] = ..., ongoing_balance_cents: _Optional[int] = ..., ongoing_usage_balance_cents: _Optional[int] = ..., currency: _Optional[str] = ..., last_balance_sync_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., transactions: _Optional[_Iterable[_Union[BillingWalletTransaction, _Mapping]]] = ...) -> None: ...

class BillingWalletState(_message.Message):
    __slots__ = ("unconfigured_organization_id", "configured")
    UNCONFIGURED_ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    CONFIGURED_FIELD_NUMBER: _ClassVar[int]
    unconfigured_organization_id: str
    configured: BillingWalletConfigured
    def __init__(self, unconfigured_organization_id: _Optional[str] = ..., configured: _Optional[_Union[BillingWalletConfigured, _Mapping]] = ...) -> None: ...

class BillingAuditFilter(_message.Message):
    __slots__ = ("window_start", "window_end", "subject_kind", "meter", "outcome", "source_principal_id", "project_id", "page", "page_size")
    WINDOW_START_FIELD_NUMBER: _ClassVar[int]
    WINDOW_END_FIELD_NUMBER: _ClassVar[int]
    SUBJECT_KIND_FIELD_NUMBER: _ClassVar[int]
    METER_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    SOURCE_PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    PAGE_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    window_start: _timestamp_pb2.Timestamp
    window_end: _timestamp_pb2.Timestamp
    subject_kind: str
    meter: str
    outcome: BillingOutcome
    source_principal_id: str
    project_id: str
    page: int
    page_size: int
    def __init__(self, window_start: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., window_end: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., subject_kind: _Optional[str] = ..., meter: _Optional[str] = ..., outcome: _Optional[_Union[BillingOutcome, str]] = ..., source_principal_id: _Optional[str] = ..., project_id: _Optional[str] = ..., page: _Optional[int] = ..., page_size: _Optional[int] = ...) -> None: ...

class GetOrganizationBillingRequest(_message.Message):
    __slots__ = ("organization_id",)
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    def __init__(self, organization_id: _Optional[str] = ...) -> None: ...

class GetOrganizationBillingResponse(_message.Message):
    __slots__ = ("billing",)
    BILLING_FIELD_NUMBER: _ClassVar[int]
    billing: OrganizationBillingState
    def __init__(self, billing: _Optional[_Union[OrganizationBillingState, _Mapping]] = ...) -> None: ...

class SetupOrganizationBillingRequest(_message.Message):
    __slots__ = ("organization_id",)
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    def __init__(self, organization_id: _Optional[str] = ...) -> None: ...

class SetupOrganizationBillingResponse(_message.Message):
    __slots__ = ("account",)
    ACCOUNT_FIELD_NUMBER: _ClassVar[int]
    account: BillingAccount
    def __init__(self, account: _Optional[_Union[BillingAccount, _Mapping]] = ...) -> None: ...

class GetOrganizationWalletRequest(_message.Message):
    __slots__ = ("organization_id",)
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    def __init__(self, organization_id: _Optional[str] = ...) -> None: ...

class GetOrganizationWalletResponse(_message.Message):
    __slots__ = ("wallet",)
    WALLET_FIELD_NUMBER: _ClassVar[int]
    wallet: BillingWalletState
    def __init__(self, wallet: _Optional[_Union[BillingWalletState, _Mapping]] = ...) -> None: ...

class SetupOrganizationWalletRequest(_message.Message):
    __slots__ = ("organization_id",)
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    def __init__(self, organization_id: _Optional[str] = ...) -> None: ...

class SetupOrganizationWalletResponse(_message.Message):
    __slots__ = ("wallet",)
    WALLET_FIELD_NUMBER: _ClassVar[int]
    wallet: BillingWalletConfigured
    def __init__(self, wallet: _Optional[_Union[BillingWalletConfigured, _Mapping]] = ...) -> None: ...

class GetOrganizationBillingAuditRequest(_message.Message):
    __slots__ = ("organization_id", "filter")
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    FILTER_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    filter: BillingAuditFilter
    def __init__(self, organization_id: _Optional[str] = ..., filter: _Optional[_Union[BillingAuditFilter, _Mapping]] = ...) -> None: ...

class GetOrganizationBillingAuditResponse(_message.Message):
    __slots__ = ("audit",)
    AUDIT_FIELD_NUMBER: _ClassVar[int]
    audit: BillingAudit
    def __init__(self, audit: _Optional[_Union[BillingAudit, _Mapping]] = ...) -> None: ...

class GetProjectBillingRequest(_message.Message):
    __slots__ = ("project_id",)
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    def __init__(self, project_id: _Optional[str] = ...) -> None: ...

class GetProjectBillingResponse(_message.Message):
    __slots__ = ("billing",)
    BILLING_FIELD_NUMBER: _ClassVar[int]
    billing: ProjectBillingState
    def __init__(self, billing: _Optional[_Union[ProjectBillingState, _Mapping]] = ...) -> None: ...

class SetupProjectBillingRequest(_message.Message):
    __slots__ = ("project_id",)
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    def __init__(self, project_id: _Optional[str] = ...) -> None: ...

class SetupProjectBillingResponse(_message.Message):
    __slots__ = ("project_id",)
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    def __init__(self, project_id: _Optional[str] = ...) -> None: ...

class GetProjectBillingAuditRequest(_message.Message):
    __slots__ = ("project_id", "filter")
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    FILTER_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    filter: BillingAuditFilter
    def __init__(self, project_id: _Optional[str] = ..., filter: _Optional[_Union[BillingAuditFilter, _Mapping]] = ...) -> None: ...

class GetProjectBillingAuditResponse(_message.Message):
    __slots__ = ("audit",)
    AUDIT_FIELD_NUMBER: _ClassVar[int]
    audit: BillingAudit
    def __init__(self, audit: _Optional[_Union[BillingAudit, _Mapping]] = ...) -> None: ...

class PutProjectBillingLimitsRequest(_message.Message):
    __slots__ = ("project_id", "limits")
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    LIMITS_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    limits: ProjectBillingLimits
    def __init__(self, project_id: _Optional[str] = ..., limits: _Optional[_Union[ProjectBillingLimits, _Mapping]] = ...) -> None: ...

class PutProjectBillingLimitsResponse(_message.Message):
    __slots__ = ("billing",)
    BILLING_FIELD_NUMBER: _ClassVar[int]
    billing: ProjectBillingConfigured
    def __init__(self, billing: _Optional[_Union[ProjectBillingConfigured, _Mapping]] = ...) -> None: ...

class RemoveProjectBillingLimitsRequest(_message.Message):
    __slots__ = ("project_id",)
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    def __init__(self, project_id: _Optional[str] = ...) -> None: ...

class RemoveProjectBillingLimitsResponse(_message.Message):
    __slots__ = ("billing",)
    BILLING_FIELD_NUMBER: _ClassVar[int]
    billing: ProjectBillingConfigured
    def __init__(self, billing: _Optional[_Union[ProjectBillingConfigured, _Mapping]] = ...) -> None: ...

class GrantOrganizationCreditsRequest(_message.Message):
    __slots__ = ("organization_id", "grant_id", "credits_cents", "campaign", "reason")
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    GRANT_ID_FIELD_NUMBER: _ClassVar[int]
    CREDITS_CENTS_FIELD_NUMBER: _ClassVar[int]
    CAMPAIGN_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    grant_id: str
    credits_cents: int
    campaign: str
    reason: str
    def __init__(self, organization_id: _Optional[str] = ..., grant_id: _Optional[str] = ..., credits_cents: _Optional[int] = ..., campaign: _Optional[str] = ..., reason: _Optional[str] = ...) -> None: ...

class GrantOrganizationCreditsResponse(_message.Message):
    __slots__ = ("transaction",)
    TRANSACTION_FIELD_NUMBER: _ClassVar[int]
    transaction: BillingWalletTransaction
    def __init__(self, transaction: _Optional[_Union[BillingWalletTransaction, _Mapping]] = ...) -> None: ...
