import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.fleet.controlplane.v1 import controlplane_pb2 as _controlplane_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SeatRole(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SEAT_ROLE_UNSPECIFIED: _ClassVar[SeatRole]
    SEAT_ROLE_ADMIN: _ClassVar[SeatRole]
    SEAT_ROLE_MEMBER: _ClassVar[SeatRole]
    SEAT_ROLE_TELEOPERATOR: _ClassVar[SeatRole]

class SeatOrgKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SEAT_ORG_KIND_UNSPECIFIED: _ClassVar[SeatOrgKind]
    SEAT_ORG_KIND_SENTIENT: _ClassVar[SeatOrgKind]
    SEAT_ORG_KIND_DEPLOYMENT_COMPANY: _ClassVar[SeatOrgKind]
    SEAT_ORG_KIND_TELEOP_VENDOR: _ClassVar[SeatOrgKind]

class TeleopFleet(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TELEOP_FLEET_UNSPECIFIED: _ClassVar[TeleopFleet]
    TELEOP_FLEET_SENTIENT: _ClassVar[TeleopFleet]
    TELEOP_FLEET_CUSTOMER: _ClassVar[TeleopFleet]
    TELEOP_FLEET_THIRD_PARTY: _ClassVar[TeleopFleet]

class TicketState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TICKET_STATE_UNSPECIFIED: _ClassVar[TicketState]
    TICKET_STATE_OPEN: _ClassVar[TicketState]
    TICKET_STATE_CLAIMED: _ClassVar[TicketState]
    TICKET_STATE_RESOLVED: _ClassVar[TicketState]

class OperatingMode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    OPERATING_MODE_UNSPECIFIED: _ClassVar[OperatingMode]
    OPERATING_MODE_REAL_RL: _ClassVar[OperatingMode]
    OPERATING_MODE_SIM_RL: _ClassVar[OperatingMode]
    OPERATING_MODE_DEPLOYMENT: _ClassVar[OperatingMode]

class Decision(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DECISION_UNSPECIFIED: _ClassVar[Decision]
    DECISION_PASS: _ClassVar[Decision]
    DECISION_FLAG: _ClassVar[Decision]
    DECISION_INTERVENE: _ClassVar[Decision]
    DECISION_ESCALATE: _ClassVar[Decision]

class TeleopTransport(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TELEOP_TRANSPORT_UNSPECIFIED: _ClassVar[TeleopTransport]
    TELEOP_TRANSPORT_DIRECT_LIVEKIT: _ClassVar[TeleopTransport]
    TELEOP_TRANSPORT_PORTAL: _ClassVar[TeleopTransport]

class WorkloadRolloutState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    WORKLOAD_ROLLOUT_STATE_UNSPECIFIED: _ClassVar[WorkloadRolloutState]
    WORKLOAD_ROLLOUT_STATE_STAGED: _ClassVar[WorkloadRolloutState]
    WORKLOAD_ROLLOUT_STATE_ADVANCING: _ClassVar[WorkloadRolloutState]
    WORKLOAD_ROLLOUT_STATE_HALTED: _ClassVar[WorkloadRolloutState]
    WORKLOAD_ROLLOUT_STATE_COMPLETE: _ClassVar[WorkloadRolloutState]
    WORKLOAD_ROLLOUT_STATE_ROLLING_BACK: _ClassVar[WorkloadRolloutState]
    WORKLOAD_ROLLOUT_STATE_ROLLED_BACK: _ClassVar[WorkloadRolloutState]

class WorkloadDriftKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    WORKLOAD_DRIFT_KIND_UNSPECIFIED: _ClassVar[WorkloadDriftKind]
    WORKLOAD_DRIFT_KIND_TARGET: _ClassVar[WorkloadDriftKind]
    WORKLOAD_DRIFT_KIND_HOST: _ClassVar[WorkloadDriftKind]
    WORKLOAD_DRIFT_KIND_STATION_AGENT: _ClassVar[WorkloadDriftKind]
    WORKLOAD_DRIFT_KIND_RELEASE: _ClassVar[WorkloadDriftKind]
    WORKLOAD_DRIFT_KIND_APPLICATION: _ClassVar[WorkloadDriftKind]
    WORKLOAD_DRIFT_KIND_SUPERVISION_POLICY: _ClassVar[WorkloadDriftKind]
    WORKLOAD_DRIFT_KIND_WORKLOADS: _ClassVar[WorkloadDriftKind]
    WORKLOAD_DRIFT_KIND_TRUST: _ClassVar[WorkloadDriftKind]
    WORKLOAD_DRIFT_KIND_HEALTH: _ClassVar[WorkloadDriftKind]

class MonitorChannel(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    MONITOR_CHANNEL_UNSPECIFIED: _ClassVar[MonitorChannel]
    MONITOR_CHANNEL_ENTROPY: _ClassVar[MonitorChannel]
    MONITOR_CHANNEL_ENSEMBLE_STD: _ClassVar[MonitorChannel]
    MONITOR_CHANNEL_VALUE_DEFICIT: _ClassVar[MonitorChannel]

class AgentJobKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    AGENT_JOB_KIND_UNSPECIFIED: _ClassVar[AgentJobKind]
    AGENT_JOB_KIND_FAILURE_ANALYSIS: _ClassVar[AgentJobKind]
    AGENT_JOB_KIND_CODE_AS_POLICY_PATCH: _ClassVar[AgentJobKind]
    AGENT_JOB_KIND_TRAINING_RUN: _ClassVar[AgentJobKind]

class EnrolledNodeKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ENROLLED_NODE_KIND_UNSPECIFIED: _ClassVar[EnrolledNodeKind]
    ENROLLED_NODE_KIND_POD: _ClassVar[EnrolledNodeKind]
    ENROLLED_NODE_KIND_CONTROLLER: _ClassVar[EnrolledNodeKind]
    ENROLLED_NODE_KIND_STATION: _ClassVar[EnrolledNodeKind]
    ENROLLED_NODE_KIND_UPLOADER: _ClassVar[EnrolledNodeKind]
SEAT_ROLE_UNSPECIFIED: SeatRole
SEAT_ROLE_ADMIN: SeatRole
SEAT_ROLE_MEMBER: SeatRole
SEAT_ROLE_TELEOPERATOR: SeatRole
SEAT_ORG_KIND_UNSPECIFIED: SeatOrgKind
SEAT_ORG_KIND_SENTIENT: SeatOrgKind
SEAT_ORG_KIND_DEPLOYMENT_COMPANY: SeatOrgKind
SEAT_ORG_KIND_TELEOP_VENDOR: SeatOrgKind
TELEOP_FLEET_UNSPECIFIED: TeleopFleet
TELEOP_FLEET_SENTIENT: TeleopFleet
TELEOP_FLEET_CUSTOMER: TeleopFleet
TELEOP_FLEET_THIRD_PARTY: TeleopFleet
TICKET_STATE_UNSPECIFIED: TicketState
TICKET_STATE_OPEN: TicketState
TICKET_STATE_CLAIMED: TicketState
TICKET_STATE_RESOLVED: TicketState
OPERATING_MODE_UNSPECIFIED: OperatingMode
OPERATING_MODE_REAL_RL: OperatingMode
OPERATING_MODE_SIM_RL: OperatingMode
OPERATING_MODE_DEPLOYMENT: OperatingMode
DECISION_UNSPECIFIED: Decision
DECISION_PASS: Decision
DECISION_FLAG: Decision
DECISION_INTERVENE: Decision
DECISION_ESCALATE: Decision
TELEOP_TRANSPORT_UNSPECIFIED: TeleopTransport
TELEOP_TRANSPORT_DIRECT_LIVEKIT: TeleopTransport
TELEOP_TRANSPORT_PORTAL: TeleopTransport
WORKLOAD_ROLLOUT_STATE_UNSPECIFIED: WorkloadRolloutState
WORKLOAD_ROLLOUT_STATE_STAGED: WorkloadRolloutState
WORKLOAD_ROLLOUT_STATE_ADVANCING: WorkloadRolloutState
WORKLOAD_ROLLOUT_STATE_HALTED: WorkloadRolloutState
WORKLOAD_ROLLOUT_STATE_COMPLETE: WorkloadRolloutState
WORKLOAD_ROLLOUT_STATE_ROLLING_BACK: WorkloadRolloutState
WORKLOAD_ROLLOUT_STATE_ROLLED_BACK: WorkloadRolloutState
WORKLOAD_DRIFT_KIND_UNSPECIFIED: WorkloadDriftKind
WORKLOAD_DRIFT_KIND_TARGET: WorkloadDriftKind
WORKLOAD_DRIFT_KIND_HOST: WorkloadDriftKind
WORKLOAD_DRIFT_KIND_STATION_AGENT: WorkloadDriftKind
WORKLOAD_DRIFT_KIND_RELEASE: WorkloadDriftKind
WORKLOAD_DRIFT_KIND_APPLICATION: WorkloadDriftKind
WORKLOAD_DRIFT_KIND_SUPERVISION_POLICY: WorkloadDriftKind
WORKLOAD_DRIFT_KIND_WORKLOADS: WorkloadDriftKind
WORKLOAD_DRIFT_KIND_TRUST: WorkloadDriftKind
WORKLOAD_DRIFT_KIND_HEALTH: WorkloadDriftKind
MONITOR_CHANNEL_UNSPECIFIED: MonitorChannel
MONITOR_CHANNEL_ENTROPY: MonitorChannel
MONITOR_CHANNEL_ENSEMBLE_STD: MonitorChannel
MONITOR_CHANNEL_VALUE_DEFICIT: MonitorChannel
AGENT_JOB_KIND_UNSPECIFIED: AgentJobKind
AGENT_JOB_KIND_FAILURE_ANALYSIS: AgentJobKind
AGENT_JOB_KIND_CODE_AS_POLICY_PATCH: AgentJobKind
AGENT_JOB_KIND_TRAINING_RUN: AgentJobKind
ENROLLED_NODE_KIND_UNSPECIFIED: EnrolledNodeKind
ENROLLED_NODE_KIND_POD: EnrolledNodeKind
ENROLLED_NODE_KIND_CONTROLLER: EnrolledNodeKind
ENROLLED_NODE_KIND_STATION: EnrolledNodeKind
ENROLLED_NODE_KIND_UPLOADER: EnrolledNodeKind

class Seat(_message.Message):
    __slots__ = ("principal_id", "email", "display_name", "project_id", "role", "org_kind", "org_slug")
    PRINCIPAL_ID_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    ORG_KIND_FIELD_NUMBER: _ClassVar[int]
    ORG_SLUG_FIELD_NUMBER: _ClassVar[int]
    principal_id: str
    email: str
    display_name: str
    project_id: str
    role: SeatRole
    org_kind: SeatOrgKind
    org_slug: str
    def __init__(self, principal_id: _Optional[str] = ..., email: _Optional[str] = ..., display_name: _Optional[str] = ..., project_id: _Optional[str] = ..., role: _Optional[_Union[SeatRole, str]] = ..., org_kind: _Optional[_Union[SeatOrgKind, str]] = ..., org_slug: _Optional[str] = ...) -> None: ...

class GetSeatRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetSeatResponse(_message.Message):
    __slots__ = ("seat",)
    SEAT_FIELD_NUMBER: _ClassVar[int]
    seat: Seat
    def __init__(self, seat: _Optional[_Union[Seat, _Mapping]] = ...) -> None: ...

class Ticket(_message.Message):
    __slots__ = ("id", "fleet", "station", "episode", "step", "mode", "purpose", "reasons", "status", "claimed_by", "control_expires_at_us", "resolution", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    FLEET_FIELD_NUMBER: _ClassVar[int]
    STATION_FIELD_NUMBER: _ClassVar[int]
    EPISODE_FIELD_NUMBER: _ClassVar[int]
    STEP_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    PURPOSE_FIELD_NUMBER: _ClassVar[int]
    REASONS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CLAIMED_BY_FIELD_NUMBER: _ClassVar[int]
    CONTROL_EXPIRES_AT_US_FIELD_NUMBER: _ClassVar[int]
    RESOLUTION_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: int
    fleet: TeleopFleet
    station: str
    episode: str
    step: int
    mode: OperatingMode
    purpose: _controlplane_pb2.ControlPurpose
    reasons: _containers.RepeatedScalarFieldContainer[str]
    status: TicketState
    claimed_by: str
    control_expires_at_us: int
    resolution: str
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[int] = ..., fleet: _Optional[_Union[TeleopFleet, str]] = ..., station: _Optional[str] = ..., episode: _Optional[str] = ..., step: _Optional[int] = ..., mode: _Optional[_Union[OperatingMode, str]] = ..., purpose: _Optional[_Union[_controlplane_pb2.ControlPurpose, str]] = ..., reasons: _Optional[_Iterable[str]] = ..., status: _Optional[_Union[TicketState, str]] = ..., claimed_by: _Optional[str] = ..., control_expires_at_us: _Optional[int] = ..., resolution: _Optional[str] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ListTicketsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListTicketsResponse(_message.Message):
    __slots__ = ("tickets",)
    TICKETS_FIELD_NUMBER: _ClassVar[int]
    tickets: _containers.RepeatedCompositeFieldContainer[Ticket]
    def __init__(self, tickets: _Optional[_Iterable[_Union[Ticket, _Mapping]]] = ...) -> None: ...

class ClaimTicketRequest(_message.Message):
    __slots__ = ("ticket_id",)
    TICKET_ID_FIELD_NUMBER: _ClassVar[int]
    ticket_id: int
    def __init__(self, ticket_id: _Optional[int] = ...) -> None: ...

class ClaimTicketResponse(_message.Message):
    __slots__ = ("ticket",)
    TICKET_FIELD_NUMBER: _ClassVar[int]
    ticket: Ticket
    def __init__(self, ticket: _Optional[_Union[Ticket, _Mapping]] = ...) -> None: ...

class ResolveTicketRequest(_message.Message):
    __slots__ = ("ticket_id", "resolution")
    TICKET_ID_FIELD_NUMBER: _ClassVar[int]
    RESOLUTION_FIELD_NUMBER: _ClassVar[int]
    ticket_id: int
    resolution: str
    def __init__(self, ticket_id: _Optional[int] = ..., resolution: _Optional[str] = ...) -> None: ...

class ResolveTicketResponse(_message.Message):
    __slots__ = ("ticket",)
    TICKET_FIELD_NUMBER: _ClassVar[int]
    ticket: Ticket
    def __init__(self, ticket: _Optional[_Union[Ticket, _Mapping]] = ...) -> None: ...

class ControlLease(_message.Message):
    __slots__ = ("station", "ticket_id", "episode", "lease_id", "session_id", "generation", "holder_identity", "participant_identity", "expires_at_us")
    STATION_FIELD_NUMBER: _ClassVar[int]
    TICKET_ID_FIELD_NUMBER: _ClassVar[int]
    EPISODE_FIELD_NUMBER: _ClassVar[int]
    LEASE_ID_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    HOLDER_IDENTITY_FIELD_NUMBER: _ClassVar[int]
    PARTICIPANT_IDENTITY_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_US_FIELD_NUMBER: _ClassVar[int]
    station: str
    ticket_id: int
    episode: str
    lease_id: str
    session_id: str
    generation: int
    holder_identity: str
    participant_identity: str
    expires_at_us: int
    def __init__(self, station: _Optional[str] = ..., ticket_id: _Optional[int] = ..., episode: _Optional[str] = ..., lease_id: _Optional[str] = ..., session_id: _Optional[str] = ..., generation: _Optional[int] = ..., holder_identity: _Optional[str] = ..., participant_identity: _Optional[str] = ..., expires_at_us: _Optional[int] = ...) -> None: ...

class RenewControlLeaseRequest(_message.Message):
    __slots__ = ("ticket_id", "lease_id", "generation")
    TICKET_ID_FIELD_NUMBER: _ClassVar[int]
    LEASE_ID_FIELD_NUMBER: _ClassVar[int]
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    ticket_id: int
    lease_id: str
    generation: int
    def __init__(self, ticket_id: _Optional[int] = ..., lease_id: _Optional[str] = ..., generation: _Optional[int] = ...) -> None: ...

class RenewControlLeaseResponse(_message.Message):
    __slots__ = ("lease",)
    LEASE_FIELD_NUMBER: _ClassVar[int]
    lease: ControlLease
    def __init__(self, lease: _Optional[_Union[ControlLease, _Mapping]] = ...) -> None: ...

class ReleaseControlLeaseRequest(_message.Message):
    __slots__ = ("ticket_id", "lease_id", "generation")
    TICKET_ID_FIELD_NUMBER: _ClassVar[int]
    LEASE_ID_FIELD_NUMBER: _ClassVar[int]
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    ticket_id: int
    lease_id: str
    generation: int
    def __init__(self, ticket_id: _Optional[int] = ..., lease_id: _Optional[str] = ..., generation: _Optional[int] = ...) -> None: ...

class ReleaseControlLeaseResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class TeleopSession(_message.Message):
    __slots__ = ("url", "room", "token", "identity", "transport", "protocol_version", "command_deadline_ms", "lease")
    URL_FIELD_NUMBER: _ClassVar[int]
    ROOM_FIELD_NUMBER: _ClassVar[int]
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    IDENTITY_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_FIELD_NUMBER: _ClassVar[int]
    PROTOCOL_VERSION_FIELD_NUMBER: _ClassVar[int]
    COMMAND_DEADLINE_MS_FIELD_NUMBER: _ClassVar[int]
    LEASE_FIELD_NUMBER: _ClassVar[int]
    url: str
    room: str
    token: str
    identity: str
    transport: TeleopTransport
    protocol_version: int
    command_deadline_ms: int
    lease: ControlLease
    def __init__(self, url: _Optional[str] = ..., room: _Optional[str] = ..., token: _Optional[str] = ..., identity: _Optional[str] = ..., transport: _Optional[_Union[TeleopTransport, str]] = ..., protocol_version: _Optional[int] = ..., command_deadline_ms: _Optional[int] = ..., lease: _Optional[_Union[ControlLease, _Mapping]] = ...) -> None: ...

class OpenTeleopSessionRequest(_message.Message):
    __slots__ = ("ticket_id", "transport")
    TICKET_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_FIELD_NUMBER: _ClassVar[int]
    ticket_id: int
    transport: TeleopTransport
    def __init__(self, ticket_id: _Optional[int] = ..., transport: _Optional[_Union[TeleopTransport, str]] = ...) -> None: ...

class OpenTeleopSessionResponse(_message.Message):
    __slots__ = ("session",)
    SESSION_FIELD_NUMBER: _ClassVar[int]
    session: TeleopSession
    def __init__(self, session: _Optional[_Union[TeleopSession, _Mapping]] = ...) -> None: ...

class SupervisedStation(_message.Message):
    __slots__ = ("station", "fleet", "connected", "mode", "episode", "step", "last_decision", "last_reason", "returns", "last_seen")
    STATION_FIELD_NUMBER: _ClassVar[int]
    FLEET_FIELD_NUMBER: _ClassVar[int]
    CONNECTED_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    EPISODE_FIELD_NUMBER: _ClassVar[int]
    STEP_FIELD_NUMBER: _ClassVar[int]
    LAST_DECISION_FIELD_NUMBER: _ClassVar[int]
    LAST_REASON_FIELD_NUMBER: _ClassVar[int]
    RETURNS_FIELD_NUMBER: _ClassVar[int]
    LAST_SEEN_FIELD_NUMBER: _ClassVar[int]
    station: str
    fleet: TeleopFleet
    connected: bool
    mode: OperatingMode
    episode: str
    step: int
    last_decision: Decision
    last_reason: str
    returns: _containers.RepeatedScalarFieldContainer[float]
    last_seen: _timestamp_pb2.Timestamp
    def __init__(self, station: _Optional[str] = ..., fleet: _Optional[_Union[TeleopFleet, str]] = ..., connected: _Optional[bool] = ..., mode: _Optional[_Union[OperatingMode, str]] = ..., episode: _Optional[str] = ..., step: _Optional[int] = ..., last_decision: _Optional[_Union[Decision, str]] = ..., last_reason: _Optional[str] = ..., returns: _Optional[_Iterable[float]] = ..., last_seen: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ListSupervisedStationsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListSupervisedStationsResponse(_message.Message):
    __slots__ = ("stations",)
    STATIONS_FIELD_NUMBER: _ClassVar[int]
    stations: _containers.RepeatedCompositeFieldContainer[SupervisedStation]
    def __init__(self, stations: _Optional[_Iterable[_Union[SupervisedStation, _Mapping]]] = ...) -> None: ...

class SupervisedEpisode(_message.Message):
    __slots__ = ("episode", "mode", "started_at", "ended_at", "frames", "interventions", "episode_return", "success")
    EPISODE_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    ENDED_AT_FIELD_NUMBER: _ClassVar[int]
    FRAMES_FIELD_NUMBER: _ClassVar[int]
    INTERVENTIONS_FIELD_NUMBER: _ClassVar[int]
    EPISODE_RETURN_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    episode: str
    mode: OperatingMode
    started_at: _timestamp_pb2.Timestamp
    ended_at: _timestamp_pb2.Timestamp
    frames: int
    interventions: int
    episode_return: float
    success: bool
    def __init__(self, episode: _Optional[str] = ..., mode: _Optional[_Union[OperatingMode, str]] = ..., started_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., ended_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., frames: _Optional[int] = ..., interventions: _Optional[int] = ..., episode_return: _Optional[float] = ..., success: _Optional[bool] = ...) -> None: ...

class ListStationEpisodesRequest(_message.Message):
    __slots__ = ("station",)
    STATION_FIELD_NUMBER: _ClassVar[int]
    station: str
    def __init__(self, station: _Optional[str] = ...) -> None: ...

class ListStationEpisodesResponse(_message.Message):
    __slots__ = ("episodes",)
    EPISODES_FIELD_NUMBER: _ClassVar[int]
    episodes: _containers.RepeatedCompositeFieldContainer[SupervisedEpisode]
    def __init__(self, episodes: _Optional[_Iterable[_Union[SupervisedEpisode, _Mapping]]] = ...) -> None: ...

class SupervisionOverview(_message.Message):
    __slots__ = ("open_tickets", "claimed_tickets", "resolved_tickets", "ladders")
    OPEN_TICKETS_FIELD_NUMBER: _ClassVar[int]
    CLAIMED_TICKETS_FIELD_NUMBER: _ClassVar[int]
    RESOLVED_TICKETS_FIELD_NUMBER: _ClassVar[int]
    LADDERS_FIELD_NUMBER: _ClassVar[int]
    open_tickets: int
    claimed_tickets: int
    resolved_tickets: int
    ladders: int
    def __init__(self, open_tickets: _Optional[int] = ..., claimed_tickets: _Optional[int] = ..., resolved_tickets: _Optional[int] = ..., ladders: _Optional[int] = ...) -> None: ...

class GetSupervisionOverviewRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetSupervisionOverviewResponse(_message.Message):
    __slots__ = ("overview",)
    OVERVIEW_FIELD_NUMBER: _ClassVar[int]
    overview: SupervisionOverview
    def __init__(self, overview: _Optional[_Union[SupervisionOverview, _Mapping]] = ...) -> None: ...

class SessionOpened(_message.Message):
    __slots__ = ("ladder",)
    LADDER_FIELD_NUMBER: _ClassVar[int]
    ladder: str
    def __init__(self, ladder: _Optional[str] = ...) -> None: ...

class EpisodeStarted(_message.Message):
    __slots__ = ("episode", "mode")
    EPISODE_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    episode: str
    mode: OperatingMode
    def __init__(self, episode: _Optional[str] = ..., mode: _Optional[_Union[OperatingMode, str]] = ...) -> None: ...

class FrameAssessed(_message.Message):
    __slots__ = ("episode", "step", "decision", "reason")
    EPISODE_FIELD_NUMBER: _ClassVar[int]
    STEP_FIELD_NUMBER: _ClassVar[int]
    DECISION_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    episode: str
    step: int
    decision: Decision
    reason: str
    def __init__(self, episode: _Optional[str] = ..., step: _Optional[int] = ..., decision: _Optional[_Union[Decision, str]] = ..., reason: _Optional[str] = ...) -> None: ...

class EpisodeEnded(_message.Message):
    __slots__ = ("episode", "episode_return", "success")
    EPISODE_FIELD_NUMBER: _ClassVar[int]
    EPISODE_RETURN_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    episode: str
    episode_return: float
    success: bool
    def __init__(self, episode: _Optional[str] = ..., episode_return: _Optional[float] = ..., success: _Optional[bool] = ...) -> None: ...

class SessionClosed(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class TelemetryEvent(_message.Message):
    __slots__ = ("station", "at", "session_opened", "episode_started", "frame_assessed", "episode_ended", "session_closed")
    STATION_FIELD_NUMBER: _ClassVar[int]
    AT_FIELD_NUMBER: _ClassVar[int]
    SESSION_OPENED_FIELD_NUMBER: _ClassVar[int]
    EPISODE_STARTED_FIELD_NUMBER: _ClassVar[int]
    FRAME_ASSESSED_FIELD_NUMBER: _ClassVar[int]
    EPISODE_ENDED_FIELD_NUMBER: _ClassVar[int]
    SESSION_CLOSED_FIELD_NUMBER: _ClassVar[int]
    station: str
    at: _timestamp_pb2.Timestamp
    session_opened: SessionOpened
    episode_started: EpisodeStarted
    frame_assessed: FrameAssessed
    episode_ended: EpisodeEnded
    session_closed: SessionClosed
    def __init__(self, station: _Optional[str] = ..., at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., session_opened: _Optional[_Union[SessionOpened, _Mapping]] = ..., episode_started: _Optional[_Union[EpisodeStarted, _Mapping]] = ..., frame_assessed: _Optional[_Union[FrameAssessed, _Mapping]] = ..., episode_ended: _Optional[_Union[EpisodeEnded, _Mapping]] = ..., session_closed: _Optional[_Union[SessionClosed, _Mapping]] = ...) -> None: ...

class WorkloadRolloutEvent(_message.Message):
    __slots__ = ("rollout_ref", "state", "current_wave", "rollback_stations")
    ROLLOUT_REF_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    CURRENT_WAVE_FIELD_NUMBER: _ClassVar[int]
    ROLLBACK_STATIONS_FIELD_NUMBER: _ClassVar[int]
    rollout_ref: str
    state: WorkloadRolloutState
    current_wave: int
    rollback_stations: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, rollout_ref: _Optional[str] = ..., state: _Optional[_Union[WorkloadRolloutState, str]] = ..., current_wave: _Optional[int] = ..., rollback_stations: _Optional[_Iterable[str]] = ...) -> None: ...

class WorkloadDriftEvent(_message.Message):
    __slots__ = ("station", "release_ref", "kinds")
    STATION_FIELD_NUMBER: _ClassVar[int]
    RELEASE_REF_FIELD_NUMBER: _ClassVar[int]
    KINDS_FIELD_NUMBER: _ClassVar[int]
    station: str
    release_ref: str
    kinds: _containers.RepeatedScalarFieldContainer[WorkloadDriftKind]
    def __init__(self, station: _Optional[str] = ..., release_ref: _Optional[str] = ..., kinds: _Optional[_Iterable[_Union[WorkloadDriftKind, str]]] = ...) -> None: ...

class BandAlarmConfig(_message.Message):
    __slots__ = ("channel", "alpha", "thresholds", "nominal_episodes")
    CHANNEL_FIELD_NUMBER: _ClassVar[int]
    ALPHA_FIELD_NUMBER: _ClassVar[int]
    THRESHOLDS_FIELD_NUMBER: _ClassVar[int]
    NOMINAL_EPISODES_FIELD_NUMBER: _ClassVar[int]
    channel: MonitorChannel
    alpha: float
    thresholds: _containers.RepeatedScalarFieldContainer[float]
    nominal_episodes: int
    def __init__(self, channel: _Optional[_Union[MonitorChannel, str]] = ..., alpha: _Optional[float] = ..., thresholds: _Optional[_Iterable[float]] = ..., nominal_episodes: _Optional[int] = ...) -> None: ...

class ActionLimitsConfig(_message.Message):
    __slots__ = ("lower", "upper")
    LOWER_FIELD_NUMBER: _ClassVar[int]
    UPPER_FIELD_NUMBER: _ClassVar[int]
    lower: _containers.RepeatedScalarFieldContainer[float]
    upper: _containers.RepeatedScalarFieldContainer[float]
    def __init__(self, lower: _Optional[_Iterable[float]] = ..., upper: _Optional[_Iterable[float]] = ...) -> None: ...

class RewardCurveGateConfig(_message.Message):
    __slots__ = ("window", "min_improvement", "collapse_fraction")
    WINDOW_FIELD_NUMBER: _ClassVar[int]
    MIN_IMPROVEMENT_FIELD_NUMBER: _ClassVar[int]
    COLLAPSE_FRACTION_FIELD_NUMBER: _ClassVar[int]
    window: int
    min_improvement: float
    collapse_fraction: float
    def __init__(self, window: _Optional[int] = ..., min_improvement: _Optional[float] = ..., collapse_fraction: _Optional[float] = ...) -> None: ...

class ValueFloorGateConfig(_message.Message):
    __slots__ = ("floor",)
    FLOOR_FIELD_NUMBER: _ClassVar[int]
    floor: float
    def __init__(self, floor: _Optional[float] = ...) -> None: ...

class RarmProgressConfig(_message.Message):
    __slots__ = ("reference", "temperature", "confidence_threshold", "stall_patience", "regression_tolerance")
    REFERENCE_FIELD_NUMBER: _ClassVar[int]
    TEMPERATURE_FIELD_NUMBER: _ClassVar[int]
    CONFIDENCE_THRESHOLD_FIELD_NUMBER: _ClassVar[int]
    STALL_PATIENCE_FIELD_NUMBER: _ClassVar[int]
    REGRESSION_TOLERANCE_FIELD_NUMBER: _ClassVar[int]
    reference: str
    temperature: float
    confidence_threshold: float
    stall_patience: int
    regression_tolerance: float
    def __init__(self, reference: _Optional[str] = ..., temperature: _Optional[float] = ..., confidence_threshold: _Optional[float] = ..., stall_patience: _Optional[int] = ..., regression_tolerance: _Optional[float] = ...) -> None: ...

class RobometerProgressConfig(_message.Message):
    __slots__ = ("endpoint", "instruction", "camera", "sample_every", "clip_frames", "timeout_s", "warmup_samples", "regression_tolerance", "confirm_samples", "stall_patience", "success_floor", "collapse_fraction", "token_env")
    ENDPOINT_FIELD_NUMBER: _ClassVar[int]
    INSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_EVERY_FIELD_NUMBER: _ClassVar[int]
    CLIP_FRAMES_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_S_FIELD_NUMBER: _ClassVar[int]
    WARMUP_SAMPLES_FIELD_NUMBER: _ClassVar[int]
    REGRESSION_TOLERANCE_FIELD_NUMBER: _ClassVar[int]
    CONFIRM_SAMPLES_FIELD_NUMBER: _ClassVar[int]
    STALL_PATIENCE_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FLOOR_FIELD_NUMBER: _ClassVar[int]
    COLLAPSE_FRACTION_FIELD_NUMBER: _ClassVar[int]
    TOKEN_ENV_FIELD_NUMBER: _ClassVar[int]
    endpoint: str
    instruction: str
    camera: str
    sample_every: int
    clip_frames: int
    timeout_s: float
    warmup_samples: int
    regression_tolerance: float
    confirm_samples: int
    stall_patience: int
    success_floor: float
    collapse_fraction: float
    token_env: str
    def __init__(self, endpoint: _Optional[str] = ..., instruction: _Optional[str] = ..., camera: _Optional[str] = ..., sample_every: _Optional[int] = ..., clip_frames: _Optional[int] = ..., timeout_s: _Optional[float] = ..., warmup_samples: _Optional[int] = ..., regression_tolerance: _Optional[float] = ..., confirm_samples: _Optional[int] = ..., stall_patience: _Optional[int] = ..., success_floor: _Optional[float] = ..., collapse_fraction: _Optional[float] = ..., token_env: _Optional[str] = ...) -> None: ...

class AgenticConfig(_message.Message):
    __slots__ = ("webhook_url", "job_kind", "allow_in_deployment", "timeout_s")
    WEBHOOK_URL_FIELD_NUMBER: _ClassVar[int]
    JOB_KIND_FIELD_NUMBER: _ClassVar[int]
    ALLOW_IN_DEPLOYMENT_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_S_FIELD_NUMBER: _ClassVar[int]
    webhook_url: str
    job_kind: AgentJobKind
    allow_in_deployment: bool
    timeout_s: float
    def __init__(self, webhook_url: _Optional[str] = ..., job_kind: _Optional[_Union[AgentJobKind, str]] = ..., allow_in_deployment: _Optional[bool] = ..., timeout_s: _Optional[float] = ...) -> None: ...

class HumanTeleopConfig(_message.Message):
    __slots__ = ("webhook_url", "fleet", "timeout_s")
    WEBHOOK_URL_FIELD_NUMBER: _ClassVar[int]
    FLEET_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_S_FIELD_NUMBER: _ClassVar[int]
    webhook_url: str
    fleet: TeleopFleet
    timeout_s: float
    def __init__(self, webhook_url: _Optional[str] = ..., fleet: _Optional[_Union[TeleopFleet, str]] = ..., timeout_s: _Optional[float] = ...) -> None: ...

class SupervisorMethod(_message.Message):
    __slots__ = ("band_alarm", "action_limits", "reward_curve", "value_floor", "rarm_progress", "robometer_progress", "agentic", "human_teleop")
    BAND_ALARM_FIELD_NUMBER: _ClassVar[int]
    ACTION_LIMITS_FIELD_NUMBER: _ClassVar[int]
    REWARD_CURVE_FIELD_NUMBER: _ClassVar[int]
    VALUE_FLOOR_FIELD_NUMBER: _ClassVar[int]
    RARM_PROGRESS_FIELD_NUMBER: _ClassVar[int]
    ROBOMETER_PROGRESS_FIELD_NUMBER: _ClassVar[int]
    AGENTIC_FIELD_NUMBER: _ClassVar[int]
    HUMAN_TELEOP_FIELD_NUMBER: _ClassVar[int]
    band_alarm: BandAlarmConfig
    action_limits: ActionLimitsConfig
    reward_curve: RewardCurveGateConfig
    value_floor: ValueFloorGateConfig
    rarm_progress: RarmProgressConfig
    robometer_progress: RobometerProgressConfig
    agentic: AgenticConfig
    human_teleop: HumanTeleopConfig
    def __init__(self, band_alarm: _Optional[_Union[BandAlarmConfig, _Mapping]] = ..., action_limits: _Optional[_Union[ActionLimitsConfig, _Mapping]] = ..., reward_curve: _Optional[_Union[RewardCurveGateConfig, _Mapping]] = ..., value_floor: _Optional[_Union[ValueFloorGateConfig, _Mapping]] = ..., rarm_progress: _Optional[_Union[RarmProgressConfig, _Mapping]] = ..., robometer_progress: _Optional[_Union[RobometerProgressConfig, _Mapping]] = ..., agentic: _Optional[_Union[AgenticConfig, _Mapping]] = ..., human_teleop: _Optional[_Union[HumanTeleopConfig, _Mapping]] = ...) -> None: ...

class LadderConfig(_message.Message):
    __slots__ = ("name", "version", "supervisors")
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    SUPERVISORS_FIELD_NUMBER: _ClassVar[int]
    name: str
    version: int
    supervisors: _containers.RepeatedCompositeFieldContainer[SupervisorMethod]
    def __init__(self, name: _Optional[str] = ..., version: _Optional[int] = ..., supervisors: _Optional[_Iterable[_Union[SupervisorMethod, _Mapping]]] = ...) -> None: ...

class Ladder(_message.Message):
    __slots__ = ("config", "updated_by", "updated_at")
    CONFIG_FIELD_NUMBER: _ClassVar[int]
    UPDATED_BY_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    config: LadderConfig
    updated_by: str
    updated_at: _timestamp_pb2.Timestamp
    def __init__(self, config: _Optional[_Union[LadderConfig, _Mapping]] = ..., updated_by: _Optional[str] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ListLaddersRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListLaddersResponse(_message.Message):
    __slots__ = ("ladders",)
    LADDERS_FIELD_NUMBER: _ClassVar[int]
    ladders: _containers.RepeatedCompositeFieldContainer[Ladder]
    def __init__(self, ladders: _Optional[_Iterable[_Union[Ladder, _Mapping]]] = ...) -> None: ...

class SaveLadderRequest(_message.Message):
    __slots__ = ("config",)
    CONFIG_FIELD_NUMBER: _ClassVar[int]
    config: LadderConfig
    def __init__(self, config: _Optional[_Union[LadderConfig, _Mapping]] = ...) -> None: ...

class SaveLadderResponse(_message.Message):
    __slots__ = ("ladder",)
    LADDER_FIELD_NUMBER: _ClassVar[int]
    ladder: Ladder
    def __init__(self, ladder: _Optional[_Union[Ladder, _Mapping]] = ...) -> None: ...

class FitBandAlarmRequest(_message.Message):
    __slots__ = ("fleet", "channel", "alpha")
    FLEET_FIELD_NUMBER: _ClassVar[int]
    CHANNEL_FIELD_NUMBER: _ClassVar[int]
    ALPHA_FIELD_NUMBER: _ClassVar[int]
    fleet: TeleopFleet
    channel: MonitorChannel
    alpha: float
    def __init__(self, fleet: _Optional[_Union[TeleopFleet, str]] = ..., channel: _Optional[_Union[MonitorChannel, str]] = ..., alpha: _Optional[float] = ...) -> None: ...

class FitBandAlarmResponse(_message.Message):
    __slots__ = ("config",)
    CONFIG_FIELD_NUMBER: _ClassVar[int]
    config: BandAlarmConfig
    def __init__(self, config: _Optional[_Union[BandAlarmConfig, _Mapping]] = ...) -> None: ...

class JoinCode(_message.Message):
    __slots__ = ("code", "organization_id", "project_id", "kind", "node_id", "audiences", "expires_at")
    CODE_FIELD_NUMBER: _ClassVar[int]
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    AUDIENCES_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    code: str
    organization_id: str
    project_id: str
    kind: EnrolledNodeKind
    node_id: str
    audiences: _containers.RepeatedScalarFieldContainer[str]
    expires_at: _timestamp_pb2.Timestamp
    def __init__(self, code: _Optional[str] = ..., organization_id: _Optional[str] = ..., project_id: _Optional[str] = ..., kind: _Optional[_Union[EnrolledNodeKind, str]] = ..., node_id: _Optional[str] = ..., audiences: _Optional[_Iterable[str]] = ..., expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class CreateNodeJoinCodeRequest(_message.Message):
    __slots__ = ("kind", "node_id", "ttl_s")
    KIND_FIELD_NUMBER: _ClassVar[int]
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    TTL_S_FIELD_NUMBER: _ClassVar[int]
    kind: EnrolledNodeKind
    node_id: str
    ttl_s: int
    def __init__(self, kind: _Optional[_Union[EnrolledNodeKind, str]] = ..., node_id: _Optional[str] = ..., ttl_s: _Optional[int] = ...) -> None: ...

class CreateNodeJoinCodeResponse(_message.Message):
    __slots__ = ("join_code",)
    JOIN_CODE_FIELD_NUMBER: _ClassVar[int]
    join_code: JoinCode
    def __init__(self, join_code: _Optional[_Union[JoinCode, _Mapping]] = ...) -> None: ...
