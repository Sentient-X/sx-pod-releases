import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from sentientx.sx.common.v1 import outcomes_pb2 as _outcomes_pb2
from sentientx.sx.common.v1 import stations_pb2 as _stations_pb2
from sentientx.sx.operations.v1 import operations_pb2 as _operations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ResearchPodRole(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    RESEARCH_POD_ROLE_UNSPECIFIED: _ClassVar[ResearchPodRole]
    RESEARCH_POD_ROLE_FOLLOWER: _ClassVar[ResearchPodRole]
    RESEARCH_POD_ROLE_EXO_CAMERA: _ClassVar[ResearchPodRole]
    RESEARCH_POD_ROLE_WRIST_CAMERA: _ClassVar[ResearchPodRole]
    RESEARCH_POD_ROLE_LOCAL_LEADER: _ClassVar[ResearchPodRole]

class ControllerHealth(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONTROLLER_HEALTH_UNSPECIFIED: _ClassVar[ControllerHealth]
    CONTROLLER_HEALTH_READY: _ClassVar[ControllerHealth]
    CONTROLLER_HEALTH_OFFLINE: _ClassVar[ControllerHealth]
    CONTROLLER_HEALTH_IN_USE: _ClassVar[ControllerHealth]

class ControllerKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONTROLLER_KIND_UNSPECIFIED: _ClassVar[ControllerKind]
    CONTROLLER_KIND_SO101_LEADER: _ClassVar[ControllerKind]

class DeviceKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DEVICE_KIND_UNSPECIFIED: _ClassVar[DeviceKind]
    DEVICE_KIND_FEETECH_BUS: _ClassVar[DeviceKind]
    DEVICE_KIND_REALSENSE: _ClassVar[DeviceKind]
    DEVICE_KIND_OAK_D: _ClassVar[DeviceKind]

class DeviceHealth(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DEVICE_HEALTH_UNSPECIFIED: _ClassVar[DeviceHealth]
    DEVICE_HEALTH_READY: _ClassVar[DeviceHealth]
    DEVICE_HEALTH_DEGRADED: _ClassVar[DeviceHealth]
    DEVICE_HEALTH_UNAVAILABLE: _ClassVar[DeviceHealth]

class DeviceCapability(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DEVICE_CAPABILITY_UNSPECIFIED: _ClassVar[DeviceCapability]
    DEVICE_CAPABILITY_ACTUATOR_CONTROL: _ClassVar[DeviceCapability]
    DEVICE_CAPABILITY_SAFE_STOP: _ClassVar[DeviceCapability]
    DEVICE_CAPABILITY_VIDEO_STREAM: _ClassVar[DeviceCapability]
    DEVICE_CAPABILITY_HUMAN_INPUT: _ClassVar[DeviceCapability]

class StationReadiness(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    STATION_READINESS_UNSPECIFIED: _ClassVar[StationReadiness]
    STATION_READINESS_READY: _ClassVar[StationReadiness]
    STATION_READINESS_DEGRADED: _ClassVar[StationReadiness]
    STATION_READINESS_OFFLINE: _ClassVar[StationReadiness]
    STATION_READINESS_SAFE_STOPPED: _ClassVar[StationReadiness]

class DeploymentState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DEPLOYMENT_STATE_UNSPECIFIED: _ClassVar[DeploymentState]
    DEPLOYMENT_STATE_ROLLING_OUT: _ClassVar[DeploymentState]
    DEPLOYMENT_STATE_ACTIVE: _ClassVar[DeploymentState]
    DEPLOYMENT_STATE_SAFE_STOPPED: _ClassVar[DeploymentState]
    DEPLOYMENT_STATE_FAILED: _ClassVar[DeploymentState]
    DEPLOYMENT_STATE_RETIRED: _ClassVar[DeploymentState]

class DeploymentStage(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DEPLOYMENT_STAGE_UNSPECIFIED: _ClassVar[DeploymentStage]
    DEPLOYMENT_STAGE_CANARY: _ClassVar[DeploymentStage]
    DEPLOYMENT_STAGE_PRODUCTION: _ClassVar[DeploymentStage]

class ResearchRunState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    RESEARCH_RUN_STATE_UNSPECIFIED: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_ADMITTED: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_PREPARING: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_RUNNING: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_WAITING_FOR_CONTROL: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_RESETTING: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_FINALIZING: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_SUCCEEDED: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_FAILED: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_CANCELLED: _ClassVar[ResearchRunState]

class CatalogRegistrationState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CATALOG_REGISTRATION_STATE_UNSPECIFIED: _ClassVar[CatalogRegistrationState]
    CATALOG_REGISTRATION_STATE_PENDING: _ClassVar[CatalogRegistrationState]
    CATALOG_REGISTRATION_STATE_READY: _ClassVar[CatalogRegistrationState]
    CATALOG_REGISTRATION_STATE_FAILED: _ClassVar[CatalogRegistrationState]

class ControlPurpose(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONTROL_PURPOSE_UNSPECIFIED: _ClassVar[ControlPurpose]
    CONTROL_PURPOSE_SUPERVISION_ESCALATION: _ClassVar[ControlPurpose]
    CONTROL_PURPOSE_TERMINAL_VERIFICATION: _ClassVar[ControlPurpose]
    CONTROL_PURPOSE_RESET: _ClassVar[ControlPurpose]

class ControlCause(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONTROL_CAUSE_UNSPECIFIED: _ClassVar[ControlCause]
    CONTROL_CAUSE_SUPERVISOR_STOP: _ClassVar[ControlCause]
    CONTROL_CAUSE_ROBOMETER_UNKNOWN: _ClassVar[ControlCause]
    CONTROL_CAUSE_RESET_REQUIRED: _ClassVar[ControlCause]
    CONTROL_CAUSE_RESET_VERIFICATION_UNKNOWN: _ClassVar[ControlCause]

class ControlModality(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONTROL_MODALITY_UNSPECIFIED: _ClassVar[ControlModality]
    CONTROL_MODALITY_LOCAL_LEADER: _ClassVar[ControlModality]
    CONTROL_MODALITY_REMOTE_TELEOPERATOR: _ClassVar[ControlModality]
    CONTROL_MODALITY_HANDS: _ClassVar[ControlModality]
    CONTROL_MODALITY_AUTOMATED_RESET: _ClassVar[ControlModality]

class ControlRequestState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONTROL_REQUEST_STATE_UNSPECIFIED: _ClassVar[ControlRequestState]
    CONTROL_REQUEST_STATE_PENDING: _ClassVar[ControlRequestState]
    CONTROL_REQUEST_STATE_OFFERED: _ClassVar[ControlRequestState]
    CONTROL_REQUEST_STATE_LEASED: _ClassVar[ControlRequestState]
    CONTROL_REQUEST_STATE_AWAITING_VERDICT: _ClassVar[ControlRequestState]
    CONTROL_REQUEST_STATE_COMPLETED: _ClassVar[ControlRequestState]
    CONTROL_REQUEST_STATE_EXPIRED: _ClassVar[ControlRequestState]
    CONTROL_REQUEST_STATE_CANCELLED: _ClassVar[ControlRequestState]

class ResetExecutorKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    RESET_EXECUTOR_KIND_UNSPECIFIED: _ClassVar[ResetExecutorKind]
    RESET_EXECUTOR_KIND_AUTOMATED: _ClassVar[ResetExecutorKind]
    RESET_EXECUTOR_KIND_TELEOPERATOR: _ClassVar[ResetExecutorKind]
    RESET_EXECUTOR_KIND_LOCAL_RESEARCHER: _ClassVar[ResetExecutorKind]

class RewardHealth(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    REWARD_HEALTH_UNSPECIFIED: _ClassVar[RewardHealth]
    REWARD_HEALTH_HEALTHY: _ClassVar[RewardHealth]
    REWARD_HEALTH_DEGRADED: _ClassVar[RewardHealth]
    REWARD_HEALTH_UNAVAILABLE: _ClassVar[RewardHealth]

class EndpointProtocol(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ENDPOINT_PROTOCOL_UNSPECIFIED: _ClassVar[EndpointProtocol]
    ENDPOINT_PROTOCOL_HTTP: _ClassVar[EndpointProtocol]
    ENDPOINT_PROTOCOL_WEBSOCKET: _ClassVar[EndpointProtocol]
RESEARCH_POD_ROLE_UNSPECIFIED: ResearchPodRole
RESEARCH_POD_ROLE_FOLLOWER: ResearchPodRole
RESEARCH_POD_ROLE_EXO_CAMERA: ResearchPodRole
RESEARCH_POD_ROLE_WRIST_CAMERA: ResearchPodRole
RESEARCH_POD_ROLE_LOCAL_LEADER: ResearchPodRole
CONTROLLER_HEALTH_UNSPECIFIED: ControllerHealth
CONTROLLER_HEALTH_READY: ControllerHealth
CONTROLLER_HEALTH_OFFLINE: ControllerHealth
CONTROLLER_HEALTH_IN_USE: ControllerHealth
CONTROLLER_KIND_UNSPECIFIED: ControllerKind
CONTROLLER_KIND_SO101_LEADER: ControllerKind
DEVICE_KIND_UNSPECIFIED: DeviceKind
DEVICE_KIND_FEETECH_BUS: DeviceKind
DEVICE_KIND_REALSENSE: DeviceKind
DEVICE_KIND_OAK_D: DeviceKind
DEVICE_HEALTH_UNSPECIFIED: DeviceHealth
DEVICE_HEALTH_READY: DeviceHealth
DEVICE_HEALTH_DEGRADED: DeviceHealth
DEVICE_HEALTH_UNAVAILABLE: DeviceHealth
DEVICE_CAPABILITY_UNSPECIFIED: DeviceCapability
DEVICE_CAPABILITY_ACTUATOR_CONTROL: DeviceCapability
DEVICE_CAPABILITY_SAFE_STOP: DeviceCapability
DEVICE_CAPABILITY_VIDEO_STREAM: DeviceCapability
DEVICE_CAPABILITY_HUMAN_INPUT: DeviceCapability
STATION_READINESS_UNSPECIFIED: StationReadiness
STATION_READINESS_READY: StationReadiness
STATION_READINESS_DEGRADED: StationReadiness
STATION_READINESS_OFFLINE: StationReadiness
STATION_READINESS_SAFE_STOPPED: StationReadiness
DEPLOYMENT_STATE_UNSPECIFIED: DeploymentState
DEPLOYMENT_STATE_ROLLING_OUT: DeploymentState
DEPLOYMENT_STATE_ACTIVE: DeploymentState
DEPLOYMENT_STATE_SAFE_STOPPED: DeploymentState
DEPLOYMENT_STATE_FAILED: DeploymentState
DEPLOYMENT_STATE_RETIRED: DeploymentState
DEPLOYMENT_STAGE_UNSPECIFIED: DeploymentStage
DEPLOYMENT_STAGE_CANARY: DeploymentStage
DEPLOYMENT_STAGE_PRODUCTION: DeploymentStage
RESEARCH_RUN_STATE_UNSPECIFIED: ResearchRunState
RESEARCH_RUN_STATE_ADMITTED: ResearchRunState
RESEARCH_RUN_STATE_PREPARING: ResearchRunState
RESEARCH_RUN_STATE_RUNNING: ResearchRunState
RESEARCH_RUN_STATE_WAITING_FOR_CONTROL: ResearchRunState
RESEARCH_RUN_STATE_RESETTING: ResearchRunState
RESEARCH_RUN_STATE_FINALIZING: ResearchRunState
RESEARCH_RUN_STATE_SUCCEEDED: ResearchRunState
RESEARCH_RUN_STATE_FAILED: ResearchRunState
RESEARCH_RUN_STATE_CANCELLED: ResearchRunState
CATALOG_REGISTRATION_STATE_UNSPECIFIED: CatalogRegistrationState
CATALOG_REGISTRATION_STATE_PENDING: CatalogRegistrationState
CATALOG_REGISTRATION_STATE_READY: CatalogRegistrationState
CATALOG_REGISTRATION_STATE_FAILED: CatalogRegistrationState
CONTROL_PURPOSE_UNSPECIFIED: ControlPurpose
CONTROL_PURPOSE_SUPERVISION_ESCALATION: ControlPurpose
CONTROL_PURPOSE_TERMINAL_VERIFICATION: ControlPurpose
CONTROL_PURPOSE_RESET: ControlPurpose
CONTROL_CAUSE_UNSPECIFIED: ControlCause
CONTROL_CAUSE_SUPERVISOR_STOP: ControlCause
CONTROL_CAUSE_ROBOMETER_UNKNOWN: ControlCause
CONTROL_CAUSE_RESET_REQUIRED: ControlCause
CONTROL_CAUSE_RESET_VERIFICATION_UNKNOWN: ControlCause
CONTROL_MODALITY_UNSPECIFIED: ControlModality
CONTROL_MODALITY_LOCAL_LEADER: ControlModality
CONTROL_MODALITY_REMOTE_TELEOPERATOR: ControlModality
CONTROL_MODALITY_HANDS: ControlModality
CONTROL_MODALITY_AUTOMATED_RESET: ControlModality
CONTROL_REQUEST_STATE_UNSPECIFIED: ControlRequestState
CONTROL_REQUEST_STATE_PENDING: ControlRequestState
CONTROL_REQUEST_STATE_OFFERED: ControlRequestState
CONTROL_REQUEST_STATE_LEASED: ControlRequestState
CONTROL_REQUEST_STATE_AWAITING_VERDICT: ControlRequestState
CONTROL_REQUEST_STATE_COMPLETED: ControlRequestState
CONTROL_REQUEST_STATE_EXPIRED: ControlRequestState
CONTROL_REQUEST_STATE_CANCELLED: ControlRequestState
RESET_EXECUTOR_KIND_UNSPECIFIED: ResetExecutorKind
RESET_EXECUTOR_KIND_AUTOMATED: ResetExecutorKind
RESET_EXECUTOR_KIND_TELEOPERATOR: ResetExecutorKind
RESET_EXECUTOR_KIND_LOCAL_RESEARCHER: ResetExecutorKind
REWARD_HEALTH_UNSPECIFIED: RewardHealth
REWARD_HEALTH_HEALTHY: RewardHealth
REWARD_HEALTH_DEGRADED: RewardHealth
REWARD_HEALTH_UNAVAILABLE: RewardHealth
ENDPOINT_PROTOCOL_UNSPECIFIED: EndpointProtocol
ENDPOINT_PROTOCOL_HTTP: EndpointProtocol
ENDPOINT_PROTOCOL_WEBSOCKET: EndpointProtocol

class DeployRequest(_message.Message):
    __slots__ = ("deployment_group_ref", "application_ref", "qualification_ref", "approval_refs", "timeout")
    DEPLOYMENT_GROUP_REF_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_REF_FIELD_NUMBER: _ClassVar[int]
    QUALIFICATION_REF_FIELD_NUMBER: _ClassVar[int]
    APPROVAL_REFS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    deployment_group_ref: str
    application_ref: str
    qualification_ref: str
    approval_refs: _containers.RepeatedScalarFieldContainer[str]
    timeout: _duration_pb2.Duration
    def __init__(self, deployment_group_ref: _Optional[str] = ..., application_ref: _Optional[str] = ..., qualification_ref: _Optional[str] = ..., approval_refs: _Optional[_Iterable[str]] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class DeployResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: FleetOperation
    def __init__(self, operation: _Optional[_Union[FleetOperation, _Mapping]] = ...) -> None: ...

class RollbackRequest(_message.Message):
    __slots__ = ("deployment_ref", "timeout")
    DEPLOYMENT_REF_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    deployment_ref: str
    timeout: _duration_pb2.Duration
    def __init__(self, deployment_ref: _Optional[str] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class RollbackResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: FleetOperation
    def __init__(self, operation: _Optional[_Union[FleetOperation, _Mapping]] = ...) -> None: ...

class RunBudget(_message.Message):
    __slots__ = ("max_episodes", "max_duration")
    MAX_EPISODES_FIELD_NUMBER: _ClassVar[int]
    MAX_DURATION_FIELD_NUMBER: _ClassVar[int]
    max_episodes: int
    max_duration: _duration_pb2.Duration
    def __init__(self, max_episodes: _Optional[int] = ..., max_duration: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class SubmitResearchRunRequest(_message.Message):
    __slots__ = ("deployment_ref", "approval_ref", "budget")
    DEPLOYMENT_REF_FIELD_NUMBER: _ClassVar[int]
    APPROVAL_REF_FIELD_NUMBER: _ClassVar[int]
    BUDGET_FIELD_NUMBER: _ClassVar[int]
    deployment_ref: str
    approval_ref: str
    budget: RunBudget
    def __init__(self, deployment_ref: _Optional[str] = ..., approval_ref: _Optional[str] = ..., budget: _Optional[_Union[RunBudget, _Mapping]] = ...) -> None: ...

class SubmitResearchRunResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: FleetOperation
    def __init__(self, operation: _Optional[_Union[FleetOperation, _Mapping]] = ...) -> None: ...

class ContentRef(_message.Message):
    __slots__ = ("artifact_id", "sha256")
    ARTIFACT_ID_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    artifact_id: str
    sha256: str
    def __init__(self, artifact_id: _Optional[str] = ..., sha256: _Optional[str] = ...) -> None: ...

class DeviceRoleBinding(_message.Message):
    __slots__ = ("role", "device_id")
    ROLE_FIELD_NUMBER: _ClassVar[int]
    DEVICE_ID_FIELD_NUMBER: _ClassVar[int]
    role: ResearchPodRole
    device_id: str
    def __init__(self, role: _Optional[_Union[ResearchPodRole, str]] = ..., device_id: _Optional[str] = ...) -> None: ...

class CalibrationBinding(_message.Message):
    __slots__ = ("role", "artifact")
    ROLE_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_FIELD_NUMBER: _ClassVar[int]
    role: ResearchPodRole
    artifact: ContentRef
    def __init__(self, role: _Optional[_Union[ResearchPodRole, str]] = ..., artifact: _Optional[_Union[ContentRef, _Mapping]] = ...) -> None: ...

class ResearchPodCommit(_message.Message):
    __slots__ = ("pod_id", "station_id", "bindings", "calibrations", "dataset")
    POD_ID_FIELD_NUMBER: _ClassVar[int]
    STATION_ID_FIELD_NUMBER: _ClassVar[int]
    BINDINGS_FIELD_NUMBER: _ClassVar[int]
    CALIBRATIONS_FIELD_NUMBER: _ClassVar[int]
    DATASET_FIELD_NUMBER: _ClassVar[int]
    pod_id: str
    station_id: str
    bindings: _containers.RepeatedCompositeFieldContainer[DeviceRoleBinding]
    calibrations: _containers.RepeatedCompositeFieldContainer[CalibrationBinding]
    dataset: str
    def __init__(self, pod_id: _Optional[str] = ..., station_id: _Optional[str] = ..., bindings: _Optional[_Iterable[_Union[DeviceRoleBinding, _Mapping]]] = ..., calibrations: _Optional[_Iterable[_Union[CalibrationBinding, _Mapping]]] = ..., dataset: _Optional[str] = ...) -> None: ...

class ResearchPod(_message.Message):
    __slots__ = ("pod_id", "revision", "station_id", "bindings", "calibrations", "dataset", "committed_at")
    POD_ID_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    STATION_ID_FIELD_NUMBER: _ClassVar[int]
    BINDINGS_FIELD_NUMBER: _ClassVar[int]
    CALIBRATIONS_FIELD_NUMBER: _ClassVar[int]
    DATASET_FIELD_NUMBER: _ClassVar[int]
    COMMITTED_AT_FIELD_NUMBER: _ClassVar[int]
    pod_id: str
    revision: int
    station_id: str
    bindings: _containers.RepeatedCompositeFieldContainer[DeviceRoleBinding]
    calibrations: _containers.RepeatedCompositeFieldContainer[CalibrationBinding]
    dataset: str
    committed_at: _timestamp_pb2.Timestamp
    def __init__(self, pod_id: _Optional[str] = ..., revision: _Optional[int] = ..., station_id: _Optional[str] = ..., bindings: _Optional[_Iterable[_Union[DeviceRoleBinding, _Mapping]]] = ..., calibrations: _Optional[_Iterable[_Union[CalibrationBinding, _Mapping]]] = ..., dataset: _Optional[str] = ..., committed_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class CommissioningReadiness(_message.Message):
    __slots__ = ("ready", "checks", "failures")
    READY_FIELD_NUMBER: _ClassVar[int]
    CHECKS_FIELD_NUMBER: _ClassVar[int]
    FAILURES_FIELD_NUMBER: _ClassVar[int]
    ready: bool
    checks: _containers.RepeatedScalarFieldContainer[str]
    failures: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, ready: _Optional[bool] = ..., checks: _Optional[_Iterable[str]] = ..., failures: _Optional[_Iterable[str]] = ...) -> None: ...

class StationController(_message.Message):
    __slots__ = ("kind", "controller_id", "station_id", "device_id", "health")
    KIND_FIELD_NUMBER: _ClassVar[int]
    CONTROLLER_ID_FIELD_NUMBER: _ClassVar[int]
    STATION_ID_FIELD_NUMBER: _ClassVar[int]
    DEVICE_ID_FIELD_NUMBER: _ClassVar[int]
    HEALTH_FIELD_NUMBER: _ClassVar[int]
    kind: ControllerKind
    controller_id: str
    station_id: str
    device_id: str
    health: ControllerHealth
    def __init__(self, kind: _Optional[_Union[ControllerKind, str]] = ..., controller_id: _Optional[str] = ..., station_id: _Optional[str] = ..., device_id: _Optional[str] = ..., health: _Optional[_Union[ControllerHealth, str]] = ...) -> None: ...

class BridgedController(_message.Message):
    __slots__ = ("kind", "controller_id", "bridge_subject", "health")
    KIND_FIELD_NUMBER: _ClassVar[int]
    CONTROLLER_ID_FIELD_NUMBER: _ClassVar[int]
    BRIDGE_SUBJECT_FIELD_NUMBER: _ClassVar[int]
    HEALTH_FIELD_NUMBER: _ClassVar[int]
    kind: ControllerKind
    controller_id: str
    bridge_subject: str
    health: ControllerHealth
    def __init__(self, kind: _Optional[_Union[ControllerKind, str]] = ..., controller_id: _Optional[str] = ..., bridge_subject: _Optional[str] = ..., health: _Optional[_Union[ControllerHealth, str]] = ...) -> None: ...

class Controller(_message.Message):
    __slots__ = ("station", "bridged")
    STATION_FIELD_NUMBER: _ClassVar[int]
    BRIDGED_FIELD_NUMBER: _ClassVar[int]
    station: StationController
    bridged: BridgedController
    def __init__(self, station: _Optional[_Union[StationController, _Mapping]] = ..., bridged: _Optional[_Union[BridgedController, _Mapping]] = ...) -> None: ...

class CheckResearchPodReadinessRequest(_message.Message):
    __slots__ = ("commit",)
    COMMIT_FIELD_NUMBER: _ClassVar[int]
    commit: ResearchPodCommit
    def __init__(self, commit: _Optional[_Union[ResearchPodCommit, _Mapping]] = ...) -> None: ...

class CheckResearchPodReadinessResponse(_message.Message):
    __slots__ = ("readiness",)
    READINESS_FIELD_NUMBER: _ClassVar[int]
    readiness: CommissioningReadiness
    def __init__(self, readiness: _Optional[_Union[CommissioningReadiness, _Mapping]] = ...) -> None: ...

class CommitResearchPodRequest(_message.Message):
    __slots__ = ("commit",)
    COMMIT_FIELD_NUMBER: _ClassVar[int]
    commit: ResearchPodCommit
    def __init__(self, commit: _Optional[_Union[ResearchPodCommit, _Mapping]] = ...) -> None: ...

class CommitResearchPodResponse(_message.Message):
    __slots__ = ("pod",)
    POD_FIELD_NUMBER: _ClassVar[int]
    pod: ResearchPod
    def __init__(self, pod: _Optional[_Union[ResearchPod, _Mapping]] = ...) -> None: ...

class CommitStationControllerRequest(_message.Message):
    __slots__ = ("controller_id", "station_id", "device_id")
    CONTROLLER_ID_FIELD_NUMBER: _ClassVar[int]
    STATION_ID_FIELD_NUMBER: _ClassVar[int]
    DEVICE_ID_FIELD_NUMBER: _ClassVar[int]
    controller_id: str
    station_id: str
    device_id: str
    def __init__(self, controller_id: _Optional[str] = ..., station_id: _Optional[str] = ..., device_id: _Optional[str] = ...) -> None: ...

class CommitStationControllerResponse(_message.Message):
    __slots__ = ("controller",)
    CONTROLLER_FIELD_NUMBER: _ClassVar[int]
    controller: Controller
    def __init__(self, controller: _Optional[_Union[Controller, _Mapping]] = ...) -> None: ...

class DiscoveredDevice(_message.Message):
    __slots__ = ("device_id", "kind", "health", "capabilities", "observed_at")
    DEVICE_ID_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    HEALTH_FIELD_NUMBER: _ClassVar[int]
    CAPABILITIES_FIELD_NUMBER: _ClassVar[int]
    OBSERVED_AT_FIELD_NUMBER: _ClassVar[int]
    device_id: str
    kind: DeviceKind
    health: DeviceHealth
    capabilities: _containers.RepeatedScalarFieldContainer[DeviceCapability]
    observed_at: _timestamp_pb2.Timestamp
    def __init__(self, device_id: _Optional[str] = ..., kind: _Optional[_Union[DeviceKind, str]] = ..., health: _Optional[_Union[DeviceHealth, str]] = ..., capabilities: _Optional[_Iterable[_Union[DeviceCapability, str]]] = ..., observed_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class StationLabel(_message.Message):
    __slots__ = ("key", "value")
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: str
    value: str
    def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...

class EvidenceCapacity(_message.Message):
    __slots__ = ("total", "available", "uncommitted", "reserve")
    TOTAL_FIELD_NUMBER: _ClassVar[int]
    AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    UNCOMMITTED_FIELD_NUMBER: _ClassVar[int]
    RESERVE_FIELD_NUMBER: _ClassVar[int]
    total: int
    available: int
    uncommitted: int
    reserve: int
    def __init__(self, total: _Optional[int] = ..., available: _Optional[int] = ..., uncommitted: _Optional[int] = ..., reserve: _Optional[int] = ...) -> None: ...

class Station(_message.Message):
    __slots__ = ("station_id", "target", "labels", "inventory_revision", "inventory_observed_at", "devices", "health", "active_application", "active_task_lease", "evidence")
    STATION_ID_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    LABELS_FIELD_NUMBER: _ClassVar[int]
    INVENTORY_REVISION_FIELD_NUMBER: _ClassVar[int]
    INVENTORY_OBSERVED_AT_FIELD_NUMBER: _ClassVar[int]
    DEVICES_FIELD_NUMBER: _ClassVar[int]
    HEALTH_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_APPLICATION_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_TASK_LEASE_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_FIELD_NUMBER: _ClassVar[int]
    station_id: str
    target: _stations_pb2.StationTarget
    labels: _containers.RepeatedCompositeFieldContainer[StationLabel]
    inventory_revision: int
    inventory_observed_at: _timestamp_pb2.Timestamp
    devices: _containers.RepeatedCompositeFieldContainer[DiscoveredDevice]
    health: StationReadiness
    active_application: str
    active_task_lease: str
    evidence: EvidenceCapacity
    def __init__(self, station_id: _Optional[str] = ..., target: _Optional[_Union[_stations_pb2.StationTarget, _Mapping]] = ..., labels: _Optional[_Iterable[_Union[StationLabel, _Mapping]]] = ..., inventory_revision: _Optional[int] = ..., inventory_observed_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., devices: _Optional[_Iterable[_Union[DiscoveredDevice, _Mapping]]] = ..., health: _Optional[_Union[StationReadiness, str]] = ..., active_application: _Optional[str] = ..., active_task_lease: _Optional[str] = ..., evidence: _Optional[_Union[EvidenceCapacity, _Mapping]] = ...) -> None: ...

class ListStationsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListStationsResponse(_message.Message):
    __slots__ = ("stations",)
    STATIONS_FIELD_NUMBER: _ClassVar[int]
    stations: _containers.RepeatedCompositeFieldContainer[Station]
    def __init__(self, stations: _Optional[_Iterable[_Union[Station, _Mapping]]] = ...) -> None: ...

class ListResearchPodsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListResearchPodsResponse(_message.Message):
    __slots__ = ("pods",)
    PODS_FIELD_NUMBER: _ClassVar[int]
    pods: _containers.RepeatedCompositeFieldContainer[ResearchPod]
    def __init__(self, pods: _Optional[_Iterable[_Union[ResearchPod, _Mapping]]] = ...) -> None: ...

class ListControllersRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListControllersResponse(_message.Message):
    __slots__ = ("controllers",)
    CONTROLLERS_FIELD_NUMBER: _ClassVar[int]
    controllers: _containers.RepeatedCompositeFieldContainer[Controller]
    def __init__(self, controllers: _Optional[_Iterable[_Union[Controller, _Mapping]]] = ...) -> None: ...

class RolloutWave(_message.Message):
    __slots__ = ("index", "stations")
    INDEX_FIELD_NUMBER: _ClassVar[int]
    STATIONS_FIELD_NUMBER: _ClassVar[int]
    index: int
    stations: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, index: _Optional[int] = ..., stations: _Optional[_Iterable[str]] = ...) -> None: ...

class ApplicationDeployment(_message.Message):
    __slots__ = ("deployment_ref", "deployment_group_ref", "application_ref", "approval_refs", "supervision_policy_ref", "rollout_ref", "state", "waves")
    DEPLOYMENT_REF_FIELD_NUMBER: _ClassVar[int]
    DEPLOYMENT_GROUP_REF_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_REF_FIELD_NUMBER: _ClassVar[int]
    APPROVAL_REFS_FIELD_NUMBER: _ClassVar[int]
    SUPERVISION_POLICY_REF_FIELD_NUMBER: _ClassVar[int]
    ROLLOUT_REF_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    WAVES_FIELD_NUMBER: _ClassVar[int]
    deployment_ref: str
    deployment_group_ref: str
    application_ref: str
    approval_refs: _containers.RepeatedScalarFieldContainer[str]
    supervision_policy_ref: str
    rollout_ref: str
    state: DeploymentState
    waves: _containers.RepeatedCompositeFieldContainer[RolloutWave]
    def __init__(self, deployment_ref: _Optional[str] = ..., deployment_group_ref: _Optional[str] = ..., application_ref: _Optional[str] = ..., approval_refs: _Optional[_Iterable[str]] = ..., supervision_policy_ref: _Optional[str] = ..., rollout_ref: _Optional[str] = ..., state: _Optional[_Union[DeploymentState, str]] = ..., waves: _Optional[_Iterable[_Union[RolloutWave, _Mapping]]] = ...) -> None: ...

class RuntimeCriteria(_message.Message):
    __slots__ = ("clean_process_starts", "warmup_samples_per_start", "measured_samples_per_start", "sustained_duration_s", "latency_deadline_ms", "maximum_quality_regression")
    CLEAN_PROCESS_STARTS_FIELD_NUMBER: _ClassVar[int]
    WARMUP_SAMPLES_PER_START_FIELD_NUMBER: _ClassVar[int]
    MEASURED_SAMPLES_PER_START_FIELD_NUMBER: _ClassVar[int]
    SUSTAINED_DURATION_S_FIELD_NUMBER: _ClassVar[int]
    LATENCY_DEADLINE_MS_FIELD_NUMBER: _ClassVar[int]
    MAXIMUM_QUALITY_REGRESSION_FIELD_NUMBER: _ClassVar[int]
    clean_process_starts: int
    warmup_samples_per_start: int
    measured_samples_per_start: int
    sustained_duration_s: float
    latency_deadline_ms: float
    maximum_quality_regression: float
    def __init__(self, clean_process_starts: _Optional[int] = ..., warmup_samples_per_start: _Optional[int] = ..., measured_samples_per_start: _Optional[int] = ..., sustained_duration_s: _Optional[float] = ..., latency_deadline_ms: _Optional[float] = ..., maximum_quality_regression: _Optional[float] = ...) -> None: ...

class ExecutionLimits(_message.Message):
    __slots__ = ("maximum_action_horizon", "maximum_linear_velocity", "maximum_angular_velocity")
    MAXIMUM_ACTION_HORIZON_FIELD_NUMBER: _ClassVar[int]
    MAXIMUM_LINEAR_VELOCITY_FIELD_NUMBER: _ClassVar[int]
    MAXIMUM_ANGULAR_VELOCITY_FIELD_NUMBER: _ClassVar[int]
    maximum_action_horizon: int
    maximum_linear_velocity: float
    maximum_angular_velocity: float
    def __init__(self, maximum_action_horizon: _Optional[int] = ..., maximum_linear_velocity: _Optional[float] = ..., maximum_angular_velocity: _Optional[float] = ...) -> None: ...

class CanaryCriteria(_message.Message):
    __slots__ = ("required_consecutive_successful_trials", "maximum_failed_attempts", "minimum_supervision_coverage")
    REQUIRED_CONSECUTIVE_SUCCESSFUL_TRIALS_FIELD_NUMBER: _ClassVar[int]
    MAXIMUM_FAILED_ATTEMPTS_FIELD_NUMBER: _ClassVar[int]
    MINIMUM_SUPERVISION_COVERAGE_FIELD_NUMBER: _ClassVar[int]
    required_consecutive_successful_trials: int
    maximum_failed_attempts: int
    minimum_supervision_coverage: float
    def __init__(self, required_consecutive_successful_trials: _Optional[int] = ..., maximum_failed_attempts: _Optional[int] = ..., minimum_supervision_coverage: _Optional[float] = ...) -> None: ...

class DeploymentGroupDeclaration(_message.Message):
    __slots__ = ("stage", "station_target", "embodiment_id", "action_interface_ids", "supervision_policy_ref", "execution_limits", "selector", "wave_size", "qualification_station", "runtime_criteria", "canary_criteria")
    STAGE_FIELD_NUMBER: _ClassVar[int]
    STATION_TARGET_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ACTION_INTERFACE_IDS_FIELD_NUMBER: _ClassVar[int]
    SUPERVISION_POLICY_REF_FIELD_NUMBER: _ClassVar[int]
    EXECUTION_LIMITS_FIELD_NUMBER: _ClassVar[int]
    SELECTOR_FIELD_NUMBER: _ClassVar[int]
    WAVE_SIZE_FIELD_NUMBER: _ClassVar[int]
    QUALIFICATION_STATION_FIELD_NUMBER: _ClassVar[int]
    RUNTIME_CRITERIA_FIELD_NUMBER: _ClassVar[int]
    CANARY_CRITERIA_FIELD_NUMBER: _ClassVar[int]
    stage: DeploymentStage
    station_target: _stations_pb2.StationTarget
    embodiment_id: str
    action_interface_ids: _containers.RepeatedScalarFieldContainer[str]
    supervision_policy_ref: str
    execution_limits: ExecutionLimits
    selector: _containers.RepeatedCompositeFieldContainer[StationLabel]
    wave_size: int
    qualification_station: str
    runtime_criteria: RuntimeCriteria
    canary_criteria: CanaryCriteria
    def __init__(self, stage: _Optional[_Union[DeploymentStage, str]] = ..., station_target: _Optional[_Union[_stations_pb2.StationTarget, _Mapping]] = ..., embodiment_id: _Optional[str] = ..., action_interface_ids: _Optional[_Iterable[str]] = ..., supervision_policy_ref: _Optional[str] = ..., execution_limits: _Optional[_Union[ExecutionLimits, _Mapping]] = ..., selector: _Optional[_Iterable[_Union[StationLabel, _Mapping]]] = ..., wave_size: _Optional[int] = ..., qualification_station: _Optional[str] = ..., runtime_criteria: _Optional[_Union[RuntimeCriteria, _Mapping]] = ..., canary_criteria: _Optional[_Union[CanaryCriteria, _Mapping]] = ...) -> None: ...

class DeploymentGroupDeployment(_message.Message):
    __slots__ = ("deployment_ref", "application_ref", "qualification_ref", "approval_refs", "state")
    DEPLOYMENT_REF_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_REF_FIELD_NUMBER: _ClassVar[int]
    QUALIFICATION_REF_FIELD_NUMBER: _ClassVar[int]
    APPROVAL_REFS_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    deployment_ref: str
    application_ref: str
    qualification_ref: str
    approval_refs: _containers.RepeatedScalarFieldContainer[str]
    state: DeploymentState
    def __init__(self, deployment_ref: _Optional[str] = ..., application_ref: _Optional[str] = ..., qualification_ref: _Optional[str] = ..., approval_refs: _Optional[_Iterable[str]] = ..., state: _Optional[_Union[DeploymentState, str]] = ...) -> None: ...

class DeploymentGroup(_message.Message):
    __slots__ = ("deployment_group_ref", "declaration", "declared_by", "deployments")
    DEPLOYMENT_GROUP_REF_FIELD_NUMBER: _ClassVar[int]
    DECLARATION_FIELD_NUMBER: _ClassVar[int]
    DECLARED_BY_FIELD_NUMBER: _ClassVar[int]
    DEPLOYMENTS_FIELD_NUMBER: _ClassVar[int]
    deployment_group_ref: str
    declaration: DeploymentGroupDeclaration
    declared_by: str
    deployments: _containers.RepeatedCompositeFieldContainer[DeploymentGroupDeployment]
    def __init__(self, deployment_group_ref: _Optional[str] = ..., declaration: _Optional[_Union[DeploymentGroupDeclaration, _Mapping]] = ..., declared_by: _Optional[str] = ..., deployments: _Optional[_Iterable[_Union[DeploymentGroupDeployment, _Mapping]]] = ...) -> None: ...

class ListDeploymentGroupsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListDeploymentGroupsResponse(_message.Message):
    __slots__ = ("groups",)
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    groups: _containers.RepeatedCompositeFieldContainer[DeploymentGroup]
    def __init__(self, groups: _Optional[_Iterable[_Union[DeploymentGroup, _Mapping]]] = ...) -> None: ...

class GetDeploymentGroupRequest(_message.Message):
    __slots__ = ("deployment_group_ref",)
    DEPLOYMENT_GROUP_REF_FIELD_NUMBER: _ClassVar[int]
    deployment_group_ref: str
    def __init__(self, deployment_group_ref: _Optional[str] = ...) -> None: ...

class GetDeploymentGroupResponse(_message.Message):
    __slots__ = ("group",)
    GROUP_FIELD_NUMBER: _ClassVar[int]
    group: DeploymentGroup
    def __init__(self, group: _Optional[_Union[DeploymentGroup, _Mapping]] = ...) -> None: ...

class DeclareDeploymentGroupRequest(_message.Message):
    __slots__ = ("deployment_group_ref", "declaration")
    DEPLOYMENT_GROUP_REF_FIELD_NUMBER: _ClassVar[int]
    DECLARATION_FIELD_NUMBER: _ClassVar[int]
    deployment_group_ref: str
    declaration: DeploymentGroupDeclaration
    def __init__(self, deployment_group_ref: _Optional[str] = ..., declaration: _Optional[_Union[DeploymentGroupDeclaration, _Mapping]] = ...) -> None: ...

class DeclareDeploymentGroupResponse(_message.Message):
    __slots__ = ("group",)
    GROUP_FIELD_NUMBER: _ClassVar[int]
    group: DeploymentGroup
    def __init__(self, group: _Optional[_Union[DeploymentGroup, _Mapping]] = ...) -> None: ...

class ObservationActionSpan(_message.Message):
    __slots__ = ("first_observation", "last_observation", "action_receipts")
    FIRST_OBSERVATION_FIELD_NUMBER: _ClassVar[int]
    LAST_OBSERVATION_FIELD_NUMBER: _ClassVar[int]
    ACTION_RECEIPTS_FIELD_NUMBER: _ClassVar[int]
    first_observation: str
    last_observation: str
    action_receipts: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, first_observation: _Optional[str] = ..., last_observation: _Optional[str] = ..., action_receipts: _Optional[_Iterable[str]] = ...) -> None: ...

class ControlRequest(_message.Message):
    __slots__ = ("request_id", "purpose", "cause", "run_id", "episode_id", "station_id", "route", "route_index", "selected_modality", "deadline", "lease_id", "evidence_span", "state")
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    PURPOSE_FIELD_NUMBER: _ClassVar[int]
    CAUSE_FIELD_NUMBER: _ClassVar[int]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    EPISODE_ID_FIELD_NUMBER: _ClassVar[int]
    STATION_ID_FIELD_NUMBER: _ClassVar[int]
    ROUTE_FIELD_NUMBER: _ClassVar[int]
    ROUTE_INDEX_FIELD_NUMBER: _ClassVar[int]
    SELECTED_MODALITY_FIELD_NUMBER: _ClassVar[int]
    DEADLINE_FIELD_NUMBER: _ClassVar[int]
    LEASE_ID_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_SPAN_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    request_id: str
    purpose: ControlPurpose
    cause: ControlCause
    run_id: str
    episode_id: str
    station_id: str
    route: _containers.RepeatedScalarFieldContainer[ControlModality]
    route_index: int
    selected_modality: ControlModality
    deadline: _timestamp_pb2.Timestamp
    lease_id: str
    evidence_span: ObservationActionSpan
    state: ControlRequestState
    def __init__(self, request_id: _Optional[str] = ..., purpose: _Optional[_Union[ControlPurpose, str]] = ..., cause: _Optional[_Union[ControlCause, str]] = ..., run_id: _Optional[str] = ..., episode_id: _Optional[str] = ..., station_id: _Optional[str] = ..., route: _Optional[_Iterable[_Union[ControlModality, str]]] = ..., route_index: _Optional[int] = ..., selected_modality: _Optional[_Union[ControlModality, str]] = ..., deadline: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., lease_id: _Optional[str] = ..., evidence_span: _Optional[_Union[ObservationActionSpan, _Mapping]] = ..., state: _Optional[_Union[ControlRequestState, str]] = ...) -> None: ...

class HumanTaskVerdictReceipt(_message.Message):
    __slots__ = ("verdict", "control_request", "control_lease", "controller_identity", "episode", "observation_action_span", "issued_at", "note")
    VERDICT_FIELD_NUMBER: _ClassVar[int]
    CONTROL_REQUEST_FIELD_NUMBER: _ClassVar[int]
    CONTROL_LEASE_FIELD_NUMBER: _ClassVar[int]
    CONTROLLER_IDENTITY_FIELD_NUMBER: _ClassVar[int]
    EPISODE_FIELD_NUMBER: _ClassVar[int]
    OBSERVATION_ACTION_SPAN_FIELD_NUMBER: _ClassVar[int]
    ISSUED_AT_FIELD_NUMBER: _ClassVar[int]
    NOTE_FIELD_NUMBER: _ClassVar[int]
    verdict: _outcomes_pb2.TaskVerdict
    control_request: str
    control_lease: str
    controller_identity: str
    episode: str
    observation_action_span: ObservationActionSpan
    issued_at: _timestamp_pb2.Timestamp
    note: str
    def __init__(self, verdict: _Optional[_Union[_outcomes_pb2.TaskVerdict, str]] = ..., control_request: _Optional[str] = ..., control_lease: _Optional[str] = ..., controller_identity: _Optional[str] = ..., episode: _Optional[str] = ..., observation_action_span: _Optional[_Union[ObservationActionSpan, _Mapping]] = ..., issued_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., note: _Optional[str] = ...) -> None: ...

class RewardEvidence(_message.Message):
    __slots__ = ("model", "episode_id", "observation_ids", "progress", "success", "episode_complete", "health", "started_at_us", "completed_at_us", "detail")
    MODEL_FIELD_NUMBER: _ClassVar[int]
    EPISODE_ID_FIELD_NUMBER: _ClassVar[int]
    OBSERVATION_IDS_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    EPISODE_COMPLETE_FIELD_NUMBER: _ClassVar[int]
    HEALTH_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_US_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_US_FIELD_NUMBER: _ClassVar[int]
    DETAIL_FIELD_NUMBER: _ClassVar[int]
    model: ContentRef
    episode_id: str
    observation_ids: _containers.RepeatedScalarFieldContainer[str]
    progress: _containers.RepeatedScalarFieldContainer[float]
    success: _containers.RepeatedScalarFieldContainer[float]
    episode_complete: bool
    health: RewardHealth
    started_at_us: int
    completed_at_us: int
    detail: str
    def __init__(self, model: _Optional[_Union[ContentRef, _Mapping]] = ..., episode_id: _Optional[str] = ..., observation_ids: _Optional[_Iterable[str]] = ..., progress: _Optional[_Iterable[float]] = ..., success: _Optional[_Iterable[float]] = ..., episode_complete: _Optional[bool] = ..., health: _Optional[_Union[RewardHealth, str]] = ..., started_at_us: _Optional[int] = ..., completed_at_us: _Optional[int] = ..., detail: _Optional[str] = ...) -> None: ...

class CatalogCommit(_message.Message):
    __slots__ = ("content", "registration_id", "state", "receipt")
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_ID_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    RECEIPT_FIELD_NUMBER: _ClassVar[int]
    content: ContentRef
    registration_id: str
    state: CatalogRegistrationState
    receipt: str
    def __init__(self, content: _Optional[_Union[ContentRef, _Mapping]] = ..., registration_id: _Optional[str] = ..., state: _Optional[_Union[CatalogRegistrationState, str]] = ..., receipt: _Optional[str] = ...) -> None: ...

class EpisodeCommit(_message.Message):
    __slots__ = ("episode", "index", "outcome", "raw_capture", "canonical_episode")
    EPISODE_FIELD_NUMBER: _ClassVar[int]
    INDEX_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    RAW_CAPTURE_FIELD_NUMBER: _ClassVar[int]
    CANONICAL_EPISODE_FIELD_NUMBER: _ClassVar[int]
    episode: str
    index: int
    outcome: _outcomes_pb2.TaskVerdict
    raw_capture: CatalogCommit
    canonical_episode: CatalogCommit
    def __init__(self, episode: _Optional[str] = ..., index: _Optional[int] = ..., outcome: _Optional[_Union[_outcomes_pb2.TaskVerdict, str]] = ..., raw_capture: _Optional[_Union[CatalogCommit, _Mapping]] = ..., canonical_episode: _Optional[_Union[CatalogCommit, _Mapping]] = ...) -> None: ...

class TaskLease(_message.Message):
    __slots__ = ("lease_ref", "deployment_ref", "approval_ref", "sequence", "issued_at", "expires_at")
    LEASE_REF_FIELD_NUMBER: _ClassVar[int]
    DEPLOYMENT_REF_FIELD_NUMBER: _ClassVar[int]
    APPROVAL_REF_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    ISSUED_AT_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    lease_ref: str
    deployment_ref: str
    approval_ref: str
    sequence: int
    issued_at: _timestamp_pb2.Timestamp
    expires_at: _timestamp_pb2.Timestamp
    def __init__(self, lease_ref: _Optional[str] = ..., deployment_ref: _Optional[str] = ..., approval_ref: _Optional[str] = ..., sequence: _Optional[int] = ..., issued_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ApplicationProof(_message.Message):
    __slots__ = ("deployment_ref", "application_ref", "approval_ref", "task_lease", "supervision_policy_ref", "calibrations")
    DEPLOYMENT_REF_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_REF_FIELD_NUMBER: _ClassVar[int]
    APPROVAL_REF_FIELD_NUMBER: _ClassVar[int]
    TASK_LEASE_FIELD_NUMBER: _ClassVar[int]
    SUPERVISION_POLICY_REF_FIELD_NUMBER: _ClassVar[int]
    CALIBRATIONS_FIELD_NUMBER: _ClassVar[int]
    deployment_ref: str
    application_ref: str
    approval_ref: str
    task_lease: TaskLease
    supervision_policy_ref: str
    calibrations: _containers.RepeatedCompositeFieldContainer[ContentRef]
    def __init__(self, deployment_ref: _Optional[str] = ..., application_ref: _Optional[str] = ..., approval_ref: _Optional[str] = ..., task_lease: _Optional[_Union[TaskLease, _Mapping]] = ..., supervision_policy_ref: _Optional[str] = ..., calibrations: _Optional[_Iterable[_Union[ContentRef, _Mapping]]] = ...) -> None: ...

class ResolvedService(_message.Message):
    __slots__ = ("workload", "endpoint", "protocol")
    WORKLOAD_FIELD_NUMBER: _ClassVar[int]
    ENDPOINT_FIELD_NUMBER: _ClassVar[int]
    PROTOCOL_FIELD_NUMBER: _ClassVar[int]
    workload: str
    endpoint: str
    protocol: EndpointProtocol
    def __init__(self, workload: _Optional[str] = ..., endpoint: _Optional[str] = ..., protocol: _Optional[_Union[EndpointProtocol, str]] = ...) -> None: ...

class ResearchRun(_message.Message):
    __slots__ = ("run_id", "operation_id", "idempotency_key", "trace_id", "deployment_group_ref", "station_id", "pod_id", "pod_revision", "dataset", "application", "services", "budget", "state", "last_sequence", "episodes", "active_control_request", "created_at", "updated_at", "reason")
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    OPERATION_ID_FIELD_NUMBER: _ClassVar[int]
    IDEMPOTENCY_KEY_FIELD_NUMBER: _ClassVar[int]
    TRACE_ID_FIELD_NUMBER: _ClassVar[int]
    DEPLOYMENT_GROUP_REF_FIELD_NUMBER: _ClassVar[int]
    STATION_ID_FIELD_NUMBER: _ClassVar[int]
    POD_ID_FIELD_NUMBER: _ClassVar[int]
    POD_REVISION_FIELD_NUMBER: _ClassVar[int]
    DATASET_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_FIELD_NUMBER: _ClassVar[int]
    SERVICES_FIELD_NUMBER: _ClassVar[int]
    BUDGET_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    LAST_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    EPISODES_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_CONTROL_REQUEST_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    run_id: str
    operation_id: str
    idempotency_key: str
    trace_id: str
    deployment_group_ref: str
    station_id: str
    pod_id: str
    pod_revision: int
    dataset: str
    application: ApplicationProof
    services: _containers.RepeatedCompositeFieldContainer[ResolvedService]
    budget: RunBudget
    state: ResearchRunState
    last_sequence: int
    episodes: _containers.RepeatedCompositeFieldContainer[EpisodeCommit]
    active_control_request: ControlRequest
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    reason: str
    def __init__(self, run_id: _Optional[str] = ..., operation_id: _Optional[str] = ..., idempotency_key: _Optional[str] = ..., trace_id: _Optional[str] = ..., deployment_group_ref: _Optional[str] = ..., station_id: _Optional[str] = ..., pod_id: _Optional[str] = ..., pod_revision: _Optional[int] = ..., dataset: _Optional[str] = ..., application: _Optional[_Union[ApplicationProof, _Mapping]] = ..., services: _Optional[_Iterable[_Union[ResolvedService, _Mapping]]] = ..., budget: _Optional[_Union[RunBudget, _Mapping]] = ..., state: _Optional[_Union[ResearchRunState, str]] = ..., last_sequence: _Optional[int] = ..., episodes: _Optional[_Iterable[_Union[EpisodeCommit, _Mapping]]] = ..., active_control_request: _Optional[_Union[ControlRequest, _Mapping]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., reason: _Optional[str] = ...) -> None: ...

class ResearchProgress(_message.Message):
    __slots__ = ("run_state", "episodes", "max_episodes")
    RUN_STATE_FIELD_NUMBER: _ClassVar[int]
    EPISODES_FIELD_NUMBER: _ClassVar[int]
    MAX_EPISODES_FIELD_NUMBER: _ClassVar[int]
    run_state: ResearchRunState
    episodes: int
    max_episodes: int
    def __init__(self, run_state: _Optional[_Union[ResearchRunState, str]] = ..., episodes: _Optional[int] = ..., max_episodes: _Optional[int] = ...) -> None: ...

class FleetOperation(_message.Message):
    __slots__ = ("metadata", "lifecycle", "research_progress")
    METADATA_FIELD_NUMBER: _ClassVar[int]
    LIFECYCLE_FIELD_NUMBER: _ClassVar[int]
    RESEARCH_PROGRESS_FIELD_NUMBER: _ClassVar[int]
    metadata: _operations_pb2.OperationMetadata
    lifecycle: _operations_pb2.OperationLifecycle
    research_progress: ResearchProgress
    def __init__(self, metadata: _Optional[_Union[_operations_pb2.OperationMetadata, _Mapping]] = ..., lifecycle: _Optional[_Union[_operations_pb2.OperationLifecycle, _Mapping]] = ..., research_progress: _Optional[_Union[ResearchProgress, _Mapping]] = ...) -> None: ...

class FleetOperationResult(_message.Message):
    __slots__ = ("deployment", "research_run")
    DEPLOYMENT_FIELD_NUMBER: _ClassVar[int]
    RESEARCH_RUN_FIELD_NUMBER: _ClassVar[int]
    deployment: ApplicationDeployment
    research_run: ResearchRun
    def __init__(self, deployment: _Optional[_Union[ApplicationDeployment, _Mapping]] = ..., research_run: _Optional[_Union[ResearchRun, _Mapping]] = ...) -> None: ...

class GetFleetOperationRequest(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class GetFleetOperationResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: FleetOperation
    def __init__(self, operation: _Optional[_Union[FleetOperation, _Mapping]] = ...) -> None: ...

class GetFleetOperationUpdatesRequest(_message.Message):
    __slots__ = ("operation", "after_cursor", "limit", "wait_timeout")
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    AFTER_CURSOR_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    WAIT_TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    after_cursor: int
    limit: int
    wait_timeout: _duration_pb2.Duration
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., after_cursor: _Optional[int] = ..., limit: _Optional[int] = ..., wait_timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class FleetOperationUpdatePage(_message.Message):
    __slots__ = ("updates", "next_cursor", "has_more")
    UPDATES_FIELD_NUMBER: _ClassVar[int]
    NEXT_CURSOR_FIELD_NUMBER: _ClassVar[int]
    HAS_MORE_FIELD_NUMBER: _ClassVar[int]
    updates: _containers.RepeatedCompositeFieldContainer[FleetOperation]
    next_cursor: int
    has_more: bool
    def __init__(self, updates: _Optional[_Iterable[_Union[FleetOperation, _Mapping]]] = ..., next_cursor: _Optional[int] = ..., has_more: _Optional[bool] = ...) -> None: ...

class GetFleetOperationUpdatesResponse(_message.Message):
    __slots__ = ("page", "history_gap")
    PAGE_FIELD_NUMBER: _ClassVar[int]
    HISTORY_GAP_FIELD_NUMBER: _ClassVar[int]
    page: FleetOperationUpdatePage
    history_gap: _operations_pb2.OperationHistoryGap
    def __init__(self, page: _Optional[_Union[FleetOperationUpdatePage, _Mapping]] = ..., history_gap: _Optional[_Union[_operations_pb2.OperationHistoryGap, _Mapping]] = ...) -> None: ...

class GetFleetOperationResultRequest(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class GetFleetOperationResultResponse(_message.Message):
    __slots__ = ("result",)
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: FleetOperationResult
    def __init__(self, result: _Optional[_Union[FleetOperationResult, _Mapping]] = ...) -> None: ...

class CancelFleetOperationRequest(_message.Message):
    __slots__ = ("operation", "reason")
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    reason: str
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., reason: _Optional[str] = ...) -> None: ...

class CancelFleetOperationResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: FleetOperation
    def __init__(self, operation: _Optional[_Union[FleetOperation, _Mapping]] = ...) -> None: ...
