import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TeleopFleet(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TELEOP_FLEET_UNSPECIFIED: _ClassVar[TeleopFleet]
    TELEOP_FLEET_SENTIENT: _ClassVar[TeleopFleet]
    TELEOP_FLEET_CUSTOMER: _ClassVar[TeleopFleet]
    TELEOP_FLEET_THIRD_PARTY: _ClassVar[TeleopFleet]

class CpuArchitecture(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CPU_ARCHITECTURE_UNSPECIFIED: _ClassVar[CpuArchitecture]
    CPU_ARCHITECTURE_X86_64: _ClassVar[CpuArchitecture]
    CPU_ARCHITECTURE_AARCH64: _ClassVar[CpuArchitecture]

class Accelerator(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ACCELERATOR_UNSPECIFIED: _ClassVar[Accelerator]
    ACCELERATOR_RTX_5090: _ClassVar[Accelerator]
    ACCELERATOR_DGX_SPARK_GB10: _ClassVar[Accelerator]
    ACCELERATOR_JETSON_THOR_T5000: _ClassVar[Accelerator]
    ACCELERATOR_ROCKCHIP_RK3588_NPU: _ClassVar[Accelerator]

class SecurityProfile(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SECURITY_PROFILE_UNSPECIFIED: _ClassVar[SecurityProfile]
    SECURITY_PROFILE_ISOLATED_COMPUTE: _ClassVar[SecurityProfile]
    SECURITY_PROFILE_ACCELERATOR_COMPUTE: _ClassVar[SecurityProfile]
    SECURITY_PROFILE_ROBOT_IO_CONFORMER: _ClassVar[SecurityProfile]
    SECURITY_PROFILE_TRUSTED_PLATFORM_RUNTIME: _ClassVar[SecurityProfile]

class WorkloadNetwork(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    WORKLOAD_NETWORK_UNSPECIFIED: _ClassVar[WorkloadNetwork]
    WORKLOAD_NETWORK_ISOLATED: _ClassVar[WorkloadNetwork]
    WORKLOAD_NETWORK_HOST: _ClassVar[WorkloadNetwork]

class EndpointProtocol(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ENDPOINT_PROTOCOL_UNSPECIFIED: _ClassVar[EndpointProtocol]
    ENDPOINT_PROTOCOL_HTTP: _ClassVar[EndpointProtocol]
    ENDPOINT_PROTOCOL_WEBSOCKET: _ClassVar[EndpointProtocol]

class StationHealth(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    STATION_HEALTH_UNSPECIFIED: _ClassVar[StationHealth]
    STATION_HEALTH_HEALTHY: _ClassVar[StationHealth]
    STATION_HEALTH_DEGRADED: _ClassVar[StationHealth]

class StationActivity(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    STATION_ACTIVITY_UNSPECIFIED: _ClassVar[StationActivity]
    STATION_ACTIVITY_IDLE: _ClassVar[StationActivity]
    STATION_ACTIVITY_EPISODE_ACTIVE: _ClassVar[StationActivity]

class ApplyErrorCode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    APPLY_ERROR_CODE_UNSPECIFIED: _ClassVar[ApplyErrorCode]
    APPLY_ERROR_CODE_COMMAND_FAILED: _ClassVar[ApplyErrorCode]
    APPLY_ERROR_CODE_COMMAND_TIMEOUT: _ClassVar[ApplyErrorCode]
    APPLY_ERROR_CODE_FACT_UNAVAILABLE: _ClassVar[ApplyErrorCode]
    APPLY_ERROR_CODE_HOST_MISMATCH: _ClassVar[ApplyErrorCode]
    APPLY_ERROR_CODE_DIGEST_MISMATCH: _ClassVar[ApplyErrorCode]
    APPLY_ERROR_CODE_ARTIFACT_UNAVAILABLE: _ClassVar[ApplyErrorCode]
    APPLY_ERROR_CODE_STATION_AGENT_FAILED: _ClassVar[ApplyErrorCode]
    APPLY_ERROR_CODE_SIGNATURE_INVALID: _ClassVar[ApplyErrorCode]
    APPLY_ERROR_CODE_ANTI_ROLLBACK: _ClassVar[ApplyErrorCode]
    APPLY_ERROR_CODE_HEALTHCHECK_FAILED: _ClassVar[ApplyErrorCode]
    APPLY_ERROR_CODE_ROLLBACK_UNAVAILABLE: _ClassVar[ApplyErrorCode]

class NoAssignmentReason(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    NO_ASSIGNMENT_REASON_UNSPECIFIED: _ClassVar[NoAssignmentReason]
    NO_ASSIGNMENT_REASON_NOT_TARGETED: _ClassVar[NoAssignmentReason]
    NO_ASSIGNMENT_REASON_PENDING_WAVE: _ClassVar[NoAssignmentReason]
    NO_ASSIGNMENT_REASON_ROLLOUT_HALTED: _ClassVar[NoAssignmentReason]
    NO_ASSIGNMENT_REASON_ROLLOUT_ROLLED_BACK: _ClassVar[NoAssignmentReason]

class ApplyWindow(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    APPLY_WINDOW_UNSPECIFIED: _ClassVar[ApplyWindow]
    APPLY_WINDOW_APPLY_NOW: _ClassVar[ApplyWindow]
    APPLY_WINDOW_DEFER_EPISODE_ACTIVE: _ClassVar[ApplyWindow]

class DeviceKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DEVICE_KIND_UNSPECIFIED: _ClassVar[DeviceKind]
    DEVICE_KIND_FEETECH_BUS: _ClassVar[DeviceKind]
    DEVICE_KIND_REALSENSE: _ClassVar[DeviceKind]
    DEVICE_KIND_OAK_D: _ClassVar[DeviceKind]

class DeviceHealth(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DEVICE_HEALTH_UNSPECIFIED: _ClassVar[DeviceHealth]
    DEVICE_HEALTH_READY: _ClassVar[DeviceHealth]
    DEVICE_HEALTH_DEGRADED: _ClassVar[DeviceHealth]
    DEVICE_HEALTH_UNAVAILABLE: _ClassVar[DeviceHealth]

class DeviceCapability(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DEVICE_CAPABILITY_UNSPECIFIED: _ClassVar[DeviceCapability]
    DEVICE_CAPABILITY_ACTUATOR_CONTROL: _ClassVar[DeviceCapability]
    DEVICE_CAPABILITY_SAFE_STOP: _ClassVar[DeviceCapability]
    DEVICE_CAPABILITY_VIDEO_STREAM: _ClassVar[DeviceCapability]
    DEVICE_CAPABILITY_HUMAN_INPUT: _ClassVar[DeviceCapability]

class StationReadiness(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    STATION_READINESS_UNSPECIFIED: _ClassVar[StationReadiness]
    STATION_READINESS_READY: _ClassVar[StationReadiness]
    STATION_READINESS_DEGRADED: _ClassVar[StationReadiness]
    STATION_READINESS_OFFLINE: _ClassVar[StationReadiness]
    STATION_READINESS_SAFE_STOPPED: _ClassVar[StationReadiness]

class ResearchRunState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    RESEARCH_RUN_STATE_UNSPECIFIED: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_ADMITTED: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_PREPARING: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_RUNNING: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_WAITING_FOR_CONTROL: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_RESETTING: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_FINALIZING: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_SUCCEEDED: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_FAILED: _ClassVar[ResearchRunState]
    RESEARCH_RUN_STATE_CANCELLED: _ClassVar[ResearchRunState]

class ControlPurpose(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONTROL_PURPOSE_UNSPECIFIED: _ClassVar[ControlPurpose]
    CONTROL_PURPOSE_SUPERVISION_ESCALATION: _ClassVar[ControlPurpose]
    CONTROL_PURPOSE_TERMINAL_VERIFICATION: _ClassVar[ControlPurpose]
    CONTROL_PURPOSE_RESET: _ClassVar[ControlPurpose]

class ControlCause(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONTROL_CAUSE_UNSPECIFIED: _ClassVar[ControlCause]
    CONTROL_CAUSE_SUPERVISOR_STOP: _ClassVar[ControlCause]
    CONTROL_CAUSE_ROBOMETER_UNKNOWN: _ClassVar[ControlCause]
    CONTROL_CAUSE_RESET_REQUIRED: _ClassVar[ControlCause]
    CONTROL_CAUSE_RESET_VERIFICATION_UNKNOWN: _ClassVar[ControlCause]

class ControlModality(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONTROL_MODALITY_UNSPECIFIED: _ClassVar[ControlModality]
    CONTROL_MODALITY_LOCAL_LEADER: _ClassVar[ControlModality]
    CONTROL_MODALITY_REMOTE_TELEOPERATOR: _ClassVar[ControlModality]
    CONTROL_MODALITY_HANDS: _ClassVar[ControlModality]
    CONTROL_MODALITY_AUTOMATED_RESET: _ClassVar[ControlModality]

class ControlRequestState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONTROL_REQUEST_STATE_UNSPECIFIED: _ClassVar[ControlRequestState]
    CONTROL_REQUEST_STATE_PENDING: _ClassVar[ControlRequestState]
    CONTROL_REQUEST_STATE_OFFERED: _ClassVar[ControlRequestState]
    CONTROL_REQUEST_STATE_LEASED: _ClassVar[ControlRequestState]
    CONTROL_REQUEST_STATE_AWAITING_VERDICT: _ClassVar[ControlRequestState]
    CONTROL_REQUEST_STATE_COMPLETED: _ClassVar[ControlRequestState]
    CONTROL_REQUEST_STATE_EXPIRED: _ClassVar[ControlRequestState]
    CONTROL_REQUEST_STATE_CANCELLED: _ClassVar[ControlRequestState]

class TaskVerdict(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TASK_VERDICT_UNSPECIFIED: _ClassVar[TaskVerdict]
    TASK_VERDICT_SATISFIED: _ClassVar[TaskVerdict]
    TASK_VERDICT_NOT_SATISFIED: _ClassVar[TaskVerdict]
    TASK_VERDICT_UNKNOWN: _ClassVar[TaskVerdict]

class ResetExecutorKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    RESET_EXECUTOR_KIND_UNSPECIFIED: _ClassVar[ResetExecutorKind]
    RESET_EXECUTOR_KIND_AUTOMATED: _ClassVar[ResetExecutorKind]
    RESET_EXECUTOR_KIND_TELEOPERATOR: _ClassVar[ResetExecutorKind]
    RESET_EXECUTOR_KIND_LOCAL_RESEARCHER: _ClassVar[ResetExecutorKind]

class RewardHealth(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    REWARD_HEALTH_UNSPECIFIED: _ClassVar[RewardHealth]
    REWARD_HEALTH_HEALTHY: _ClassVar[RewardHealth]
    REWARD_HEALTH_DEGRADED: _ClassVar[RewardHealth]
    REWARD_HEALTH_UNAVAILABLE: _ClassVar[RewardHealth]

class CatalogRegistrationState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CATALOG_REGISTRATION_STATE_UNSPECIFIED: _ClassVar[CatalogRegistrationState]
    CATALOG_REGISTRATION_STATE_PENDING: _ClassVar[CatalogRegistrationState]
    CATALOG_REGISTRATION_STATE_READY: _ClassVar[CatalogRegistrationState]
    CATALOG_REGISTRATION_STATE_FAILED: _ClassVar[CatalogRegistrationState]
TELEOP_FLEET_UNSPECIFIED: TeleopFleet
TELEOP_FLEET_SENTIENT: TeleopFleet
TELEOP_FLEET_CUSTOMER: TeleopFleet
TELEOP_FLEET_THIRD_PARTY: TeleopFleet
CPU_ARCHITECTURE_UNSPECIFIED: CpuArchitecture
CPU_ARCHITECTURE_X86_64: CpuArchitecture
CPU_ARCHITECTURE_AARCH64: CpuArchitecture
ACCELERATOR_UNSPECIFIED: Accelerator
ACCELERATOR_RTX_5090: Accelerator
ACCELERATOR_DGX_SPARK_GB10: Accelerator
ACCELERATOR_JETSON_THOR_T5000: Accelerator
ACCELERATOR_ROCKCHIP_RK3588_NPU: Accelerator
SECURITY_PROFILE_UNSPECIFIED: SecurityProfile
SECURITY_PROFILE_ISOLATED_COMPUTE: SecurityProfile
SECURITY_PROFILE_ACCELERATOR_COMPUTE: SecurityProfile
SECURITY_PROFILE_ROBOT_IO_CONFORMER: SecurityProfile
SECURITY_PROFILE_TRUSTED_PLATFORM_RUNTIME: SecurityProfile
WORKLOAD_NETWORK_UNSPECIFIED: WorkloadNetwork
WORKLOAD_NETWORK_ISOLATED: WorkloadNetwork
WORKLOAD_NETWORK_HOST: WorkloadNetwork
ENDPOINT_PROTOCOL_UNSPECIFIED: EndpointProtocol
ENDPOINT_PROTOCOL_HTTP: EndpointProtocol
ENDPOINT_PROTOCOL_WEBSOCKET: EndpointProtocol
STATION_HEALTH_UNSPECIFIED: StationHealth
STATION_HEALTH_HEALTHY: StationHealth
STATION_HEALTH_DEGRADED: StationHealth
STATION_ACTIVITY_UNSPECIFIED: StationActivity
STATION_ACTIVITY_IDLE: StationActivity
STATION_ACTIVITY_EPISODE_ACTIVE: StationActivity
APPLY_ERROR_CODE_UNSPECIFIED: ApplyErrorCode
APPLY_ERROR_CODE_COMMAND_FAILED: ApplyErrorCode
APPLY_ERROR_CODE_COMMAND_TIMEOUT: ApplyErrorCode
APPLY_ERROR_CODE_FACT_UNAVAILABLE: ApplyErrorCode
APPLY_ERROR_CODE_HOST_MISMATCH: ApplyErrorCode
APPLY_ERROR_CODE_DIGEST_MISMATCH: ApplyErrorCode
APPLY_ERROR_CODE_ARTIFACT_UNAVAILABLE: ApplyErrorCode
APPLY_ERROR_CODE_STATION_AGENT_FAILED: ApplyErrorCode
APPLY_ERROR_CODE_SIGNATURE_INVALID: ApplyErrorCode
APPLY_ERROR_CODE_ANTI_ROLLBACK: ApplyErrorCode
APPLY_ERROR_CODE_HEALTHCHECK_FAILED: ApplyErrorCode
APPLY_ERROR_CODE_ROLLBACK_UNAVAILABLE: ApplyErrorCode
NO_ASSIGNMENT_REASON_UNSPECIFIED: NoAssignmentReason
NO_ASSIGNMENT_REASON_NOT_TARGETED: NoAssignmentReason
NO_ASSIGNMENT_REASON_PENDING_WAVE: NoAssignmentReason
NO_ASSIGNMENT_REASON_ROLLOUT_HALTED: NoAssignmentReason
NO_ASSIGNMENT_REASON_ROLLOUT_ROLLED_BACK: NoAssignmentReason
APPLY_WINDOW_UNSPECIFIED: ApplyWindow
APPLY_WINDOW_APPLY_NOW: ApplyWindow
APPLY_WINDOW_DEFER_EPISODE_ACTIVE: ApplyWindow
DEVICE_KIND_UNSPECIFIED: DeviceKind
DEVICE_KIND_FEETECH_BUS: DeviceKind
DEVICE_KIND_REALSENSE: DeviceKind
DEVICE_KIND_OAK_D: DeviceKind
DEVICE_HEALTH_UNSPECIFIED: DeviceHealth
DEVICE_HEALTH_READY: DeviceHealth
DEVICE_HEALTH_DEGRADED: DeviceHealth
DEVICE_HEALTH_UNAVAILABLE: DeviceHealth
DEVICE_CAPABILITY_UNSPECIFIED: DeviceCapability
DEVICE_CAPABILITY_ACTUATOR_CONTROL: DeviceCapability
DEVICE_CAPABILITY_SAFE_STOP: DeviceCapability
DEVICE_CAPABILITY_VIDEO_STREAM: DeviceCapability
DEVICE_CAPABILITY_HUMAN_INPUT: DeviceCapability
STATION_READINESS_UNSPECIFIED: StationReadiness
STATION_READINESS_READY: StationReadiness
STATION_READINESS_DEGRADED: StationReadiness
STATION_READINESS_OFFLINE: StationReadiness
STATION_READINESS_SAFE_STOPPED: StationReadiness
RESEARCH_RUN_STATE_UNSPECIFIED: ResearchRunState
RESEARCH_RUN_STATE_ADMITTED: ResearchRunState
RESEARCH_RUN_STATE_PREPARING: ResearchRunState
RESEARCH_RUN_STATE_RUNNING: ResearchRunState
RESEARCH_RUN_STATE_WAITING_FOR_CONTROL: ResearchRunState
RESEARCH_RUN_STATE_RESETTING: ResearchRunState
RESEARCH_RUN_STATE_FINALIZING: ResearchRunState
RESEARCH_RUN_STATE_SUCCEEDED: ResearchRunState
RESEARCH_RUN_STATE_FAILED: ResearchRunState
RESEARCH_RUN_STATE_CANCELLED: ResearchRunState
CONTROL_PURPOSE_UNSPECIFIED: ControlPurpose
CONTROL_PURPOSE_SUPERVISION_ESCALATION: ControlPurpose
CONTROL_PURPOSE_TERMINAL_VERIFICATION: ControlPurpose
CONTROL_PURPOSE_RESET: ControlPurpose
CONTROL_CAUSE_UNSPECIFIED: ControlCause
CONTROL_CAUSE_SUPERVISOR_STOP: ControlCause
CONTROL_CAUSE_ROBOMETER_UNKNOWN: ControlCause
CONTROL_CAUSE_RESET_REQUIRED: ControlCause
CONTROL_CAUSE_RESET_VERIFICATION_UNKNOWN: ControlCause
CONTROL_MODALITY_UNSPECIFIED: ControlModality
CONTROL_MODALITY_LOCAL_LEADER: ControlModality
CONTROL_MODALITY_REMOTE_TELEOPERATOR: ControlModality
CONTROL_MODALITY_HANDS: ControlModality
CONTROL_MODALITY_AUTOMATED_RESET: ControlModality
CONTROL_REQUEST_STATE_UNSPECIFIED: ControlRequestState
CONTROL_REQUEST_STATE_PENDING: ControlRequestState
CONTROL_REQUEST_STATE_OFFERED: ControlRequestState
CONTROL_REQUEST_STATE_LEASED: ControlRequestState
CONTROL_REQUEST_STATE_AWAITING_VERDICT: ControlRequestState
CONTROL_REQUEST_STATE_COMPLETED: ControlRequestState
CONTROL_REQUEST_STATE_EXPIRED: ControlRequestState
CONTROL_REQUEST_STATE_CANCELLED: ControlRequestState
TASK_VERDICT_UNSPECIFIED: TaskVerdict
TASK_VERDICT_SATISFIED: TaskVerdict
TASK_VERDICT_NOT_SATISFIED: TaskVerdict
TASK_VERDICT_UNKNOWN: TaskVerdict
RESET_EXECUTOR_KIND_UNSPECIFIED: ResetExecutorKind
RESET_EXECUTOR_KIND_AUTOMATED: ResetExecutorKind
RESET_EXECUTOR_KIND_TELEOPERATOR: ResetExecutorKind
RESET_EXECUTOR_KIND_LOCAL_RESEARCHER: ResetExecutorKind
REWARD_HEALTH_UNSPECIFIED: RewardHealth
REWARD_HEALTH_HEALTHY: RewardHealth
REWARD_HEALTH_DEGRADED: RewardHealth
REWARD_HEALTH_UNAVAILABLE: RewardHealth
CATALOG_REGISTRATION_STATE_UNSPECIFIED: CatalogRegistrationState
CATALOG_REGISTRATION_STATE_PENDING: CatalogRegistrationState
CATALOG_REGISTRATION_STATE_READY: CatalogRegistrationState
CATALOG_REGISTRATION_STATE_FAILED: CatalogRegistrationState

class StationTarget(_message.Message):
    __slots__ = ("cpu", "accelerator", "minimum_memory_mib", "runtime_abi", "power_mode")
    CPU_FIELD_NUMBER: _ClassVar[int]
    ACCELERATOR_FIELD_NUMBER: _ClassVar[int]
    MINIMUM_MEMORY_MIB_FIELD_NUMBER: _ClassVar[int]
    RUNTIME_ABI_FIELD_NUMBER: _ClassVar[int]
    POWER_MODE_FIELD_NUMBER: _ClassVar[int]
    cpu: CpuArchitecture
    accelerator: Accelerator
    minimum_memory_mib: int
    runtime_abi: str
    power_mode: str
    def __init__(self, cpu: _Optional[_Union[CpuArchitecture, str]] = ..., accelerator: _Optional[_Union[Accelerator, str]] = ..., minimum_memory_mib: _Optional[int] = ..., runtime_abi: _Optional[str] = ..., power_mode: _Optional[str] = ...) -> None: ...

class HostRequirements(_message.Message):
    __slots__ = ("board_revision", "os_release", "kernel_abi", "accelerator_abi", "docker_version", "runtime_toolkit_version", "required_devices")
    BOARD_REVISION_FIELD_NUMBER: _ClassVar[int]
    OS_RELEASE_FIELD_NUMBER: _ClassVar[int]
    KERNEL_ABI_FIELD_NUMBER: _ClassVar[int]
    ACCELERATOR_ABI_FIELD_NUMBER: _ClassVar[int]
    DOCKER_VERSION_FIELD_NUMBER: _ClassVar[int]
    RUNTIME_TOOLKIT_VERSION_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_DEVICES_FIELD_NUMBER: _ClassVar[int]
    board_revision: str
    os_release: str
    kernel_abi: str
    accelerator_abi: str
    docker_version: str
    runtime_toolkit_version: str
    required_devices: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, board_revision: _Optional[str] = ..., os_release: _Optional[str] = ..., kernel_abi: _Optional[str] = ..., accelerator_abi: _Optional[str] = ..., docker_version: _Optional[str] = ..., runtime_toolkit_version: _Optional[str] = ..., required_devices: _Optional[_Iterable[str]] = ...) -> None: ...

class RunningWorkload(_message.Message):
    __slots__ = ("name", "image", "digest")
    NAME_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    DIGEST_FIELD_NUMBER: _ClassVar[int]
    name: str
    image: str
    digest: str
    def __init__(self, name: _Optional[str] = ..., image: _Optional[str] = ..., digest: _Optional[str] = ...) -> None: ...

class ResourceBudget(_message.Message):
    __slots__ = ("cpu_millis", "memory_mib", "cpu_affinity", "pids_limit")
    CPU_MILLIS_FIELD_NUMBER: _ClassVar[int]
    MEMORY_MIB_FIELD_NUMBER: _ClassVar[int]
    CPU_AFFINITY_FIELD_NUMBER: _ClassVar[int]
    PIDS_LIMIT_FIELD_NUMBER: _ClassVar[int]
    cpu_millis: int
    memory_mib: int
    cpu_affinity: _containers.RepeatedScalarFieldContainer[int]
    pids_limit: int
    def __init__(self, cpu_millis: _Optional[int] = ..., memory_mib: _Optional[int] = ..., cpu_affinity: _Optional[_Iterable[int]] = ..., pids_limit: _Optional[int] = ...) -> None: ...

class WorkloadArtifact(_message.Message):
    __slots__ = ("name", "repository", "digest", "content")
    NAME_FIELD_NUMBER: _ClassVar[int]
    REPOSITORY_FIELD_NUMBER: _ClassVar[int]
    DIGEST_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    name: str
    repository: str
    digest: str
    content: ContentRef
    def __init__(self, name: _Optional[str] = ..., repository: _Optional[str] = ..., digest: _Optional[str] = ..., content: _Optional[_Union[ContentRef, _Mapping]] = ...) -> None: ...

class GetApplicationInputRequest(_message.Message):
    __slots__ = ("release_ref", "workload", "slot")
    RELEASE_REF_FIELD_NUMBER: _ClassVar[int]
    WORKLOAD_FIELD_NUMBER: _ClassVar[int]
    SLOT_FIELD_NUMBER: _ClassVar[int]
    release_ref: str
    workload: str
    slot: str
    def __init__(self, release_ref: _Optional[str] = ..., workload: _Optional[str] = ..., slot: _Optional[str] = ...) -> None: ...

class GetApplicationInputResponse(_message.Message):
    __slots__ = ("content", "url")
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    content: ContentRef
    url: str
    def __init__(self, content: _Optional[_Union[ContentRef, _Mapping]] = ..., url: _Optional[str] = ...) -> None: ...

class StationAgentArtifact(_message.Message):
    __slots__ = ("repository", "digest")
    REPOSITORY_FIELD_NUMBER: _ClassVar[int]
    DIGEST_FIELD_NUMBER: _ClassVar[int]
    repository: str
    digest: str
    def __init__(self, repository: _Optional[str] = ..., digest: _Optional[str] = ...) -> None: ...

class EnvironmentEntry(_message.Message):
    __slots__ = ("name", "value")
    NAME_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    name: str
    value: str
    def __init__(self, name: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...

class WorkloadEndpoint(_message.Message):
    __slots__ = ("name", "protocol", "container_port")
    NAME_FIELD_NUMBER: _ClassVar[int]
    PROTOCOL_FIELD_NUMBER: _ClassVar[int]
    CONTAINER_PORT_FIELD_NUMBER: _ClassVar[int]
    name: str
    protocol: EndpointProtocol
    container_port: int
    def __init__(self, name: _Optional[str] = ..., protocol: _Optional[_Union[EndpointProtocol, str]] = ..., container_port: _Optional[int] = ...) -> None: ...

class WorkloadImage(_message.Message):
    __slots__ = ("name", "image", "digest", "resources", "security", "grants", "endpoints", "network", "depends_on", "artifacts", "environment", "host_environment")
    NAME_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    DIGEST_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_FIELD_NUMBER: _ClassVar[int]
    SECURITY_FIELD_NUMBER: _ClassVar[int]
    GRANTS_FIELD_NUMBER: _ClassVar[int]
    ENDPOINTS_FIELD_NUMBER: _ClassVar[int]
    NETWORK_FIELD_NUMBER: _ClassVar[int]
    DEPENDS_ON_FIELD_NUMBER: _ClassVar[int]
    ARTIFACTS_FIELD_NUMBER: _ClassVar[int]
    ENVIRONMENT_FIELD_NUMBER: _ClassVar[int]
    HOST_ENVIRONMENT_FIELD_NUMBER: _ClassVar[int]
    name: str
    image: str
    digest: str
    resources: ResourceBudget
    security: SecurityProfile
    grants: _containers.RepeatedScalarFieldContainer[str]
    endpoints: _containers.RepeatedCompositeFieldContainer[WorkloadEndpoint]
    network: WorkloadNetwork
    depends_on: _containers.RepeatedScalarFieldContainer[str]
    artifacts: _containers.RepeatedCompositeFieldContainer[WorkloadArtifact]
    environment: _containers.RepeatedCompositeFieldContainer[EnvironmentEntry]
    host_environment: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, name: _Optional[str] = ..., image: _Optional[str] = ..., digest: _Optional[str] = ..., resources: _Optional[_Union[ResourceBudget, _Mapping]] = ..., security: _Optional[_Union[SecurityProfile, str]] = ..., grants: _Optional[_Iterable[str]] = ..., endpoints: _Optional[_Iterable[_Union[WorkloadEndpoint, _Mapping]]] = ..., network: _Optional[_Union[WorkloadNetwork, str]] = ..., depends_on: _Optional[_Iterable[str]] = ..., artifacts: _Optional[_Iterable[_Union[WorkloadArtifact, _Mapping]]] = ..., environment: _Optional[_Iterable[_Union[EnvironmentEntry, _Mapping]]] = ..., host_environment: _Optional[_Iterable[str]] = ...) -> None: ...

class HealthPolicy(_message.Message):
    __slots__ = ("settle_timeout_s", "poll_interval_s")
    SETTLE_TIMEOUT_S_FIELD_NUMBER: _ClassVar[int]
    POLL_INTERVAL_S_FIELD_NUMBER: _ClassVar[int]
    settle_timeout_s: int
    poll_interval_s: int
    def __init__(self, settle_timeout_s: _Optional[int] = ..., poll_interval_s: _Optional[int] = ...) -> None: ...

class WorkloadRelease(_message.Message):
    __slots__ = ("release_ref", "application_ref", "supervision_policy_ref", "sequence", "target", "host", "station_agent", "workloads", "health", "previous_release_ref", "notes")
    RELEASE_REF_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_REF_FIELD_NUMBER: _ClassVar[int]
    SUPERVISION_POLICY_REF_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    HOST_FIELD_NUMBER: _ClassVar[int]
    STATION_AGENT_FIELD_NUMBER: _ClassVar[int]
    WORKLOADS_FIELD_NUMBER: _ClassVar[int]
    HEALTH_FIELD_NUMBER: _ClassVar[int]
    PREVIOUS_RELEASE_REF_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    release_ref: str
    application_ref: str
    supervision_policy_ref: str
    sequence: int
    target: StationTarget
    host: HostRequirements
    station_agent: StationAgentArtifact
    workloads: _containers.RepeatedCompositeFieldContainer[WorkloadImage]
    health: HealthPolicy
    previous_release_ref: str
    notes: str
    def __init__(self, release_ref: _Optional[str] = ..., application_ref: _Optional[str] = ..., supervision_policy_ref: _Optional[str] = ..., sequence: _Optional[int] = ..., target: _Optional[_Union[StationTarget, _Mapping]] = ..., host: _Optional[_Union[HostRequirements, _Mapping]] = ..., station_agent: _Optional[_Union[StationAgentArtifact, _Mapping]] = ..., workloads: _Optional[_Iterable[_Union[WorkloadImage, _Mapping]]] = ..., health: _Optional[_Union[HealthPolicy, _Mapping]] = ..., previous_release_ref: _Optional[str] = ..., notes: _Optional[str] = ...) -> None: ...

class NoReleaseAcknowledgement(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReleaseAppliedAcknowledgement(_message.Message):
    __slots__ = ("release_ref",)
    RELEASE_REF_FIELD_NUMBER: _ClassVar[int]
    release_ref: str
    def __init__(self, release_ref: _Optional[str] = ...) -> None: ...

class ReleaseFailedAcknowledgement(_message.Message):
    __slots__ = ("release_ref", "error")
    RELEASE_REF_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    release_ref: str
    error: ApplyErrorCode
    def __init__(self, release_ref: _Optional[str] = ..., error: _Optional[_Union[ApplyErrorCode, str]] = ...) -> None: ...

class RollbackAppliedAcknowledgement(_message.Message):
    __slots__ = ("release_ref",)
    RELEASE_REF_FIELD_NUMBER: _ClassVar[int]
    release_ref: str
    def __init__(self, release_ref: _Optional[str] = ...) -> None: ...

class RollbackFailedAcknowledgement(_message.Message):
    __slots__ = ("release_ref", "error")
    RELEASE_REF_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    release_ref: str
    error: ApplyErrorCode
    def __init__(self, release_ref: _Optional[str] = ..., error: _Optional[_Union[ApplyErrorCode, str]] = ...) -> None: ...

class ReleaseAcknowledgement(_message.Message):
    __slots__ = ("none", "release_applied", "release_failed", "rollback_applied", "rollback_failed")
    NONE_FIELD_NUMBER: _ClassVar[int]
    RELEASE_APPLIED_FIELD_NUMBER: _ClassVar[int]
    RELEASE_FAILED_FIELD_NUMBER: _ClassVar[int]
    ROLLBACK_APPLIED_FIELD_NUMBER: _ClassVar[int]
    ROLLBACK_FAILED_FIELD_NUMBER: _ClassVar[int]
    none: NoReleaseAcknowledgement
    release_applied: ReleaseAppliedAcknowledgement
    release_failed: ReleaseFailedAcknowledgement
    rollback_applied: RollbackAppliedAcknowledgement
    rollback_failed: RollbackFailedAcknowledgement
    def __init__(self, none: _Optional[_Union[NoReleaseAcknowledgement, _Mapping]] = ..., release_applied: _Optional[_Union[ReleaseAppliedAcknowledgement, _Mapping]] = ..., release_failed: _Optional[_Union[ReleaseFailedAcknowledgement, _Mapping]] = ..., rollback_applied: _Optional[_Union[RollbackAppliedAcknowledgement, _Mapping]] = ..., rollback_failed: _Optional[_Union[RollbackFailedAcknowledgement, _Mapping]] = ...) -> None: ...

class HeartbeatRequest(_message.Message):
    __slots__ = ("station", "fleet", "target", "host", "station_agent_digest", "active_release_ref", "active_application_ref", "active_supervision_policy_ref", "trusted_sequence", "workloads", "health", "activity", "acknowledgement")
    STATION_FIELD_NUMBER: _ClassVar[int]
    FLEET_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    HOST_FIELD_NUMBER: _ClassVar[int]
    STATION_AGENT_DIGEST_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_RELEASE_REF_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_APPLICATION_REF_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_SUPERVISION_POLICY_REF_FIELD_NUMBER: _ClassVar[int]
    TRUSTED_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    WORKLOADS_FIELD_NUMBER: _ClassVar[int]
    HEALTH_FIELD_NUMBER: _ClassVar[int]
    ACTIVITY_FIELD_NUMBER: _ClassVar[int]
    ACKNOWLEDGEMENT_FIELD_NUMBER: _ClassVar[int]
    station: str
    fleet: TeleopFleet
    target: StationTarget
    host: HostRequirements
    station_agent_digest: str
    active_release_ref: str
    active_application_ref: str
    active_supervision_policy_ref: str
    trusted_sequence: int
    workloads: _containers.RepeatedCompositeFieldContainer[RunningWorkload]
    health: StationHealth
    activity: StationActivity
    acknowledgement: ReleaseAcknowledgement
    def __init__(self, station: _Optional[str] = ..., fleet: _Optional[_Union[TeleopFleet, str]] = ..., target: _Optional[_Union[StationTarget, _Mapping]] = ..., host: _Optional[_Union[HostRequirements, _Mapping]] = ..., station_agent_digest: _Optional[str] = ..., active_release_ref: _Optional[str] = ..., active_application_ref: _Optional[str] = ..., active_supervision_policy_ref: _Optional[str] = ..., trusted_sequence: _Optional[int] = ..., workloads: _Optional[_Iterable[_Union[RunningWorkload, _Mapping]]] = ..., health: _Optional[_Union[StationHealth, str]] = ..., activity: _Optional[_Union[StationActivity, str]] = ..., acknowledgement: _Optional[_Union[ReleaseAcknowledgement, _Mapping]] = ...) -> None: ...

class NoWorkloadAssignment(_message.Message):
    __slots__ = ("reason",)
    REASON_FIELD_NUMBER: _ClassVar[int]
    reason: NoAssignmentReason
    def __init__(self, reason: _Optional[_Union[NoAssignmentReason, str]] = ...) -> None: ...

class WorkloadReleaseAssignment(_message.Message):
    __slots__ = ("release", "apply_window")
    RELEASE_FIELD_NUMBER: _ClassVar[int]
    APPLY_WINDOW_FIELD_NUMBER: _ClassVar[int]
    release: WorkloadRelease
    apply_window: ApplyWindow
    def __init__(self, release: _Optional[_Union[WorkloadRelease, _Mapping]] = ..., apply_window: _Optional[_Union[ApplyWindow, str]] = ...) -> None: ...

class WorkloadRollbackAssignment(_message.Message):
    __slots__ = ("release_ref", "apply_window")
    RELEASE_REF_FIELD_NUMBER: _ClassVar[int]
    APPLY_WINDOW_FIELD_NUMBER: _ClassVar[int]
    release_ref: str
    apply_window: ApplyWindow
    def __init__(self, release_ref: _Optional[str] = ..., apply_window: _Optional[_Union[ApplyWindow, str]] = ...) -> None: ...

class HeartbeatResponse(_message.Message):
    __slots__ = ("none", "release", "rollback")
    NONE_FIELD_NUMBER: _ClassVar[int]
    RELEASE_FIELD_NUMBER: _ClassVar[int]
    ROLLBACK_FIELD_NUMBER: _ClassVar[int]
    none: NoWorkloadAssignment
    release: WorkloadReleaseAssignment
    rollback: WorkloadRollbackAssignment
    def __init__(self, none: _Optional[_Union[NoWorkloadAssignment, _Mapping]] = ..., release: _Optional[_Union[WorkloadReleaseAssignment, _Mapping]] = ..., rollback: _Optional[_Union[WorkloadRollbackAssignment, _Mapping]] = ...) -> None: ...

class DiscoveredDevice(_message.Message):
    __slots__ = ("device_id", "kind", "health", "capabilities", "observed_at")
    DEVICE_ID_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    HEALTH_FIELD_NUMBER: _ClassVar[int]
    CAPABILITIES_FIELD_NUMBER: _ClassVar[int]
    OBSERVED_AT_FIELD_NUMBER: _ClassVar[int]
    device_id: str
    kind: DeviceKind
    health: DeviceHealth
    capabilities: _containers.RepeatedScalarFieldContainer[DeviceCapability]
    observed_at: _timestamp_pb2.Timestamp
    def __init__(self, device_id: _Optional[str] = ..., kind: _Optional[_Union[DeviceKind, str]] = ..., health: _Optional[_Union[DeviceHealth, str]] = ..., capabilities: _Optional[_Iterable[_Union[DeviceCapability, str]]] = ..., observed_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class EvidenceCapacity(_message.Message):
    __slots__ = ("total", "available", "uncommitted", "reserve")
    TOTAL_FIELD_NUMBER: _ClassVar[int]
    AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    UNCOMMITTED_FIELD_NUMBER: _ClassVar[int]
    RESERVE_FIELD_NUMBER: _ClassVar[int]
    total: int
    available: int
    uncommitted: int
    reserve: int
    def __init__(self, total: _Optional[int] = ..., available: _Optional[int] = ..., uncommitted: _Optional[int] = ..., reserve: _Optional[int] = ...) -> None: ...

class ReportInventoryRequest(_message.Message):
    __slots__ = ("target", "inventory_revision", "inventory_observed_at", "devices", "health", "active_application", "active_task_lease", "evidence")
    TARGET_FIELD_NUMBER: _ClassVar[int]
    INVENTORY_REVISION_FIELD_NUMBER: _ClassVar[int]
    INVENTORY_OBSERVED_AT_FIELD_NUMBER: _ClassVar[int]
    DEVICES_FIELD_NUMBER: _ClassVar[int]
    HEALTH_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_APPLICATION_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_TASK_LEASE_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_FIELD_NUMBER: _ClassVar[int]
    target: StationTarget
    inventory_revision: int
    inventory_observed_at: _timestamp_pb2.Timestamp
    devices: _containers.RepeatedCompositeFieldContainer[DiscoveredDevice]
    health: StationReadiness
    active_application: str
    active_task_lease: str
    evidence: EvidenceCapacity
    def __init__(self, target: _Optional[_Union[StationTarget, _Mapping]] = ..., inventory_revision: _Optional[int] = ..., inventory_observed_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., devices: _Optional[_Iterable[_Union[DiscoveredDevice, _Mapping]]] = ..., health: _Optional[_Union[StationReadiness, str]] = ..., active_application: _Optional[str] = ..., active_task_lease: _Optional[str] = ..., evidence: _Optional[_Union[EvidenceCapacity, _Mapping]] = ...) -> None: ...

class ReportInventoryResponse(_message.Message):
    __slots__ = ("accepted_revision", "newly_applied")
    ACCEPTED_REVISION_FIELD_NUMBER: _ClassVar[int]
    NEWLY_APPLIED_FIELD_NUMBER: _ClassVar[int]
    accepted_revision: int
    newly_applied: bool
    def __init__(self, accepted_revision: _Optional[int] = ..., newly_applied: _Optional[bool] = ...) -> None: ...

class RunBudget(_message.Message):
    __slots__ = ("max_episodes", "max_duration_s")
    MAX_EPISODES_FIELD_NUMBER: _ClassVar[int]
    MAX_DURATION_S_FIELD_NUMBER: _ClassVar[int]
    max_episodes: int
    max_duration_s: float
    def __init__(self, max_episodes: _Optional[int] = ..., max_duration_s: _Optional[float] = ...) -> None: ...

class TaskLease(_message.Message):
    __slots__ = ("lease_ref", "deployment", "approval", "sequence", "issued_at", "expires_at")
    LEASE_REF_FIELD_NUMBER: _ClassVar[int]
    DEPLOYMENT_FIELD_NUMBER: _ClassVar[int]
    APPROVAL_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    ISSUED_AT_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    lease_ref: str
    deployment: str
    approval: str
    sequence: int
    issued_at: _timestamp_pb2.Timestamp
    expires_at: _timestamp_pb2.Timestamp
    def __init__(self, lease_ref: _Optional[str] = ..., deployment: _Optional[str] = ..., approval: _Optional[str] = ..., sequence: _Optional[int] = ..., issued_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ResolvedService(_message.Message):
    __slots__ = ("workload", "endpoint", "protocol")
    WORKLOAD_FIELD_NUMBER: _ClassVar[int]
    ENDPOINT_FIELD_NUMBER: _ClassVar[int]
    PROTOCOL_FIELD_NUMBER: _ClassVar[int]
    workload: str
    endpoint: str
    protocol: EndpointProtocol
    def __init__(self, workload: _Optional[str] = ..., endpoint: _Optional[str] = ..., protocol: _Optional[_Union[EndpointProtocol, str]] = ...) -> None: ...

class ContentRef(_message.Message):
    __slots__ = ("artifact_id", "sha256")
    ARTIFACT_ID_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    artifact_id: str
    sha256: str
    def __init__(self, artifact_id: _Optional[str] = ..., sha256: _Optional[str] = ...) -> None: ...

class ApplicationProof(_message.Message):
    __slots__ = ("deployment", "application", "approval", "task_lease", "supervision_policy", "calibrations")
    DEPLOYMENT_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_FIELD_NUMBER: _ClassVar[int]
    APPROVAL_FIELD_NUMBER: _ClassVar[int]
    TASK_LEASE_FIELD_NUMBER: _ClassVar[int]
    SUPERVISION_POLICY_FIELD_NUMBER: _ClassVar[int]
    CALIBRATIONS_FIELD_NUMBER: _ClassVar[int]
    deployment: str
    application: str
    approval: str
    task_lease: TaskLease
    supervision_policy: str
    calibrations: _containers.RepeatedCompositeFieldContainer[ContentRef]
    def __init__(self, deployment: _Optional[str] = ..., application: _Optional[str] = ..., approval: _Optional[str] = ..., task_lease: _Optional[_Union[TaskLease, _Mapping]] = ..., supervision_policy: _Optional[str] = ..., calibrations: _Optional[_Iterable[_Union[ContentRef, _Mapping]]] = ...) -> None: ...

class StationRunAssignment(_message.Message):
    __slots__ = ("run_id", "station_id", "pod_id", "pod_revision", "dataset", "application", "services", "budget")
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    STATION_ID_FIELD_NUMBER: _ClassVar[int]
    POD_ID_FIELD_NUMBER: _ClassVar[int]
    POD_REVISION_FIELD_NUMBER: _ClassVar[int]
    DATASET_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_FIELD_NUMBER: _ClassVar[int]
    SERVICES_FIELD_NUMBER: _ClassVar[int]
    BUDGET_FIELD_NUMBER: _ClassVar[int]
    run_id: str
    station_id: str
    pod_id: str
    pod_revision: int
    dataset: str
    application: ApplicationProof
    services: _containers.RepeatedCompositeFieldContainer[ResolvedService]
    budget: RunBudget
    def __init__(self, run_id: _Optional[str] = ..., station_id: _Optional[str] = ..., pod_id: _Optional[str] = ..., pod_revision: _Optional[int] = ..., dataset: _Optional[str] = ..., application: _Optional[_Union[ApplicationProof, _Mapping]] = ..., services: _Optional[_Iterable[_Union[ResolvedService, _Mapping]]] = ..., budget: _Optional[_Union[RunBudget, _Mapping]] = ...) -> None: ...

class GetActiveResearchAssignmentRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetActiveResearchAssignmentResponse(_message.Message):
    __slots__ = ("assignment",)
    ASSIGNMENT_FIELD_NUMBER: _ClassVar[int]
    assignment: StationRunAssignment
    def __init__(self, assignment: _Optional[_Union[StationRunAssignment, _Mapping]] = ...) -> None: ...

class ObservationActionSpan(_message.Message):
    __slots__ = ("first_observation", "last_observation", "action_receipts")
    FIRST_OBSERVATION_FIELD_NUMBER: _ClassVar[int]
    LAST_OBSERVATION_FIELD_NUMBER: _ClassVar[int]
    ACTION_RECEIPTS_FIELD_NUMBER: _ClassVar[int]
    first_observation: str
    last_observation: str
    action_receipts: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, first_observation: _Optional[str] = ..., last_observation: _Optional[str] = ..., action_receipts: _Optional[_Iterable[str]] = ...) -> None: ...

class ControlRequest(_message.Message):
    __slots__ = ("request_id", "purpose", "cause", "run_id", "episode_id", "station_id", "route", "route_index", "selected_modality", "deadline", "lease_id", "evidence_span", "state")
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    PURPOSE_FIELD_NUMBER: _ClassVar[int]
    CAUSE_FIELD_NUMBER: _ClassVar[int]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    EPISODE_ID_FIELD_NUMBER: _ClassVar[int]
    STATION_ID_FIELD_NUMBER: _ClassVar[int]
    ROUTE_FIELD_NUMBER: _ClassVar[int]
    ROUTE_INDEX_FIELD_NUMBER: _ClassVar[int]
    SELECTED_MODALITY_FIELD_NUMBER: _ClassVar[int]
    DEADLINE_FIELD_NUMBER: _ClassVar[int]
    LEASE_ID_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_SPAN_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    request_id: str
    purpose: ControlPurpose
    cause: ControlCause
    run_id: str
    episode_id: str
    station_id: str
    route: _containers.RepeatedScalarFieldContainer[ControlModality]
    route_index: int
    selected_modality: ControlModality
    deadline: _timestamp_pb2.Timestamp
    lease_id: str
    evidence_span: ObservationActionSpan
    state: ControlRequestState
    def __init__(self, request_id: _Optional[str] = ..., purpose: _Optional[_Union[ControlPurpose, str]] = ..., cause: _Optional[_Union[ControlCause, str]] = ..., run_id: _Optional[str] = ..., episode_id: _Optional[str] = ..., station_id: _Optional[str] = ..., route: _Optional[_Iterable[_Union[ControlModality, str]]] = ..., route_index: _Optional[int] = ..., selected_modality: _Optional[_Union[ControlModality, str]] = ..., deadline: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., lease_id: _Optional[str] = ..., evidence_span: _Optional[_Union[ObservationActionSpan, _Mapping]] = ..., state: _Optional[_Union[ControlRequestState, str]] = ...) -> None: ...

class HumanTaskVerdictReceipt(_message.Message):
    __slots__ = ("verdict", "control_request", "control_lease", "controller_identity", "episode", "observation_action_span", "issued_at", "note")
    VERDICT_FIELD_NUMBER: _ClassVar[int]
    CONTROL_REQUEST_FIELD_NUMBER: _ClassVar[int]
    CONTROL_LEASE_FIELD_NUMBER: _ClassVar[int]
    CONTROLLER_IDENTITY_FIELD_NUMBER: _ClassVar[int]
    EPISODE_FIELD_NUMBER: _ClassVar[int]
    OBSERVATION_ACTION_SPAN_FIELD_NUMBER: _ClassVar[int]
    ISSUED_AT_FIELD_NUMBER: _ClassVar[int]
    NOTE_FIELD_NUMBER: _ClassVar[int]
    verdict: TaskVerdict
    control_request: str
    control_lease: str
    controller_identity: str
    episode: str
    observation_action_span: ObservationActionSpan
    issued_at: _timestamp_pb2.Timestamp
    note: str
    def __init__(self, verdict: _Optional[_Union[TaskVerdict, str]] = ..., control_request: _Optional[str] = ..., control_lease: _Optional[str] = ..., controller_identity: _Optional[str] = ..., episode: _Optional[str] = ..., observation_action_span: _Optional[_Union[ObservationActionSpan, _Mapping]] = ..., issued_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., note: _Optional[str] = ...) -> None: ...

class RewardEvidence(_message.Message):
    __slots__ = ("model", "episode_id", "observation_ids", "progress", "success", "episode_complete", "health", "started_at_us", "completed_at_us", "detail")
    MODEL_FIELD_NUMBER: _ClassVar[int]
    EPISODE_ID_FIELD_NUMBER: _ClassVar[int]
    OBSERVATION_IDS_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    EPISODE_COMPLETE_FIELD_NUMBER: _ClassVar[int]
    HEALTH_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_US_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_US_FIELD_NUMBER: _ClassVar[int]
    DETAIL_FIELD_NUMBER: _ClassVar[int]
    model: ContentRef
    episode_id: str
    observation_ids: _containers.RepeatedScalarFieldContainer[str]
    progress: _containers.RepeatedScalarFieldContainer[float]
    success: _containers.RepeatedScalarFieldContainer[float]
    episode_complete: bool
    health: RewardHealth
    started_at_us: int
    completed_at_us: int
    detail: str
    def __init__(self, model: _Optional[_Union[ContentRef, _Mapping]] = ..., episode_id: _Optional[str] = ..., observation_ids: _Optional[_Iterable[str]] = ..., progress: _Optional[_Iterable[float]] = ..., success: _Optional[_Iterable[float]] = ..., episode_complete: _Optional[bool] = ..., health: _Optional[_Union[RewardHealth, str]] = ..., started_at_us: _Optional[int] = ..., completed_at_us: _Optional[int] = ..., detail: _Optional[str] = ...) -> None: ...

class CatalogCommit(_message.Message):
    __slots__ = ("content", "registration_id", "state", "receipt")
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_ID_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    RECEIPT_FIELD_NUMBER: _ClassVar[int]
    content: ContentRef
    registration_id: str
    state: CatalogRegistrationState
    receipt: str
    def __init__(self, content: _Optional[_Union[ContentRef, _Mapping]] = ..., registration_id: _Optional[str] = ..., state: _Optional[_Union[CatalogRegistrationState, str]] = ..., receipt: _Optional[str] = ...) -> None: ...

class EpisodeCommit(_message.Message):
    __slots__ = ("episode", "index", "outcome", "raw_capture", "canonical_episode")
    EPISODE_FIELD_NUMBER: _ClassVar[int]
    INDEX_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    RAW_CAPTURE_FIELD_NUMBER: _ClassVar[int]
    CANONICAL_EPISODE_FIELD_NUMBER: _ClassVar[int]
    episode: str
    index: int
    outcome: TaskVerdict
    raw_capture: CatalogCommit
    canonical_episode: CatalogCommit
    def __init__(self, episode: _Optional[str] = ..., index: _Optional[int] = ..., outcome: _Optional[_Union[TaskVerdict, str]] = ..., raw_capture: _Optional[_Union[CatalogCommit, _Mapping]] = ..., canonical_episode: _Optional[_Union[CatalogCommit, _Mapping]] = ...) -> None: ...

class ReportResearchRunEventRequest(_message.Message):
    __slots__ = ("run_id", "sequence", "state", "observed_at", "reason", "control_request", "human_verdict", "reset_executor", "reset_evidence", "reset_verdict", "episode")
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    OBSERVED_AT_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    CONTROL_REQUEST_FIELD_NUMBER: _ClassVar[int]
    HUMAN_VERDICT_FIELD_NUMBER: _ClassVar[int]
    RESET_EXECUTOR_FIELD_NUMBER: _ClassVar[int]
    RESET_EVIDENCE_FIELD_NUMBER: _ClassVar[int]
    RESET_VERDICT_FIELD_NUMBER: _ClassVar[int]
    EPISODE_FIELD_NUMBER: _ClassVar[int]
    run_id: str
    sequence: int
    state: ResearchRunState
    observed_at: _timestamp_pb2.Timestamp
    reason: str
    control_request: ControlRequest
    human_verdict: HumanTaskVerdictReceipt
    reset_executor: ResetExecutorKind
    reset_evidence: RewardEvidence
    reset_verdict: TaskVerdict
    episode: EpisodeCommit
    def __init__(self, run_id: _Optional[str] = ..., sequence: _Optional[int] = ..., state: _Optional[_Union[ResearchRunState, str]] = ..., observed_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., reason: _Optional[str] = ..., control_request: _Optional[_Union[ControlRequest, _Mapping]] = ..., human_verdict: _Optional[_Union[HumanTaskVerdictReceipt, _Mapping]] = ..., reset_executor: _Optional[_Union[ResetExecutorKind, str]] = ..., reset_evidence: _Optional[_Union[RewardEvidence, _Mapping]] = ..., reset_verdict: _Optional[_Union[TaskVerdict, str]] = ..., episode: _Optional[_Union[EpisodeCommit, _Mapping]] = ...) -> None: ...

class ReportResearchRunEventResponse(_message.Message):
    __slots__ = ("accepted_sequence", "newly_applied")
    ACCEPTED_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    NEWLY_APPLIED_FIELD_NUMBER: _ClassVar[int]
    accepted_sequence: int
    newly_applied: bool
    def __init__(self, accepted_sequence: _Optional[int] = ..., newly_applied: _Optional[bool] = ...) -> None: ...
