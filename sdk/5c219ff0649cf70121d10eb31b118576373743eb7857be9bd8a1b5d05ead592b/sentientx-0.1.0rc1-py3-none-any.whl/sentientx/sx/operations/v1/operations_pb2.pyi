import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class OperationMetadata(_message.Message):
    __slots__ = ("ref", "resource", "trace_id", "cursor", "idempotency_key", "created_at", "updated_at")
    REF_FIELD_NUMBER: _ClassVar[int]
    RESOURCE_FIELD_NUMBER: _ClassVar[int]
    TRACE_ID_FIELD_NUMBER: _ClassVar[int]
    CURSOR_FIELD_NUMBER: _ClassVar[int]
    IDEMPOTENCY_KEY_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    ref: _common_pb2.OperationRef
    resource: _common_pb2.ResourceRef
    trace_id: str
    cursor: int
    idempotency_key: str
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    def __init__(self, ref: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., resource: _Optional[_Union[_common_pb2.ResourceRef, _Mapping]] = ..., trace_id: _Optional[str] = ..., cursor: _Optional[int] = ..., idempotency_key: _Optional[str] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class CancellationRequest(_message.Message):
    __slots__ = ("reason", "requested_at")
    REASON_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_AT_FIELD_NUMBER: _ClassVar[int]
    reason: str
    requested_at: _timestamp_pb2.Timestamp
    def __init__(self, reason: _Optional[str] = ..., requested_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class AcceptedOperation(_message.Message):
    __slots__ = ("cancellation",)
    CANCELLATION_FIELD_NUMBER: _ClassVar[int]
    cancellation: CancellationRequest
    def __init__(self, cancellation: _Optional[_Union[CancellationRequest, _Mapping]] = ...) -> None: ...

class RunningOperation(_message.Message):
    __slots__ = ("cancellation",)
    CANCELLATION_FIELD_NUMBER: _ClassVar[int]
    cancellation: CancellationRequest
    def __init__(self, cancellation: _Optional[_Union[CancellationRequest, _Mapping]] = ...) -> None: ...

class SucceededOperation(_message.Message):
    __slots__ = ("completed_at",)
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    completed_at: _timestamp_pb2.Timestamp
    def __init__(self, completed_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class OperationFailure(_message.Message):
    __slots__ = ("code", "message", "retryable")
    CODE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    RETRYABLE_FIELD_NUMBER: _ClassVar[int]
    code: str
    message: str
    retryable: bool
    def __init__(self, code: _Optional[str] = ..., message: _Optional[str] = ..., retryable: _Optional[bool] = ...) -> None: ...

class FailedOperation(_message.Message):
    __slots__ = ("failure", "failed_at")
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    FAILED_AT_FIELD_NUMBER: _ClassVar[int]
    failure: OperationFailure
    failed_at: _timestamp_pb2.Timestamp
    def __init__(self, failure: _Optional[_Union[OperationFailure, _Mapping]] = ..., failed_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class CancelledOperation(_message.Message):
    __slots__ = ("reason", "cancelled_at")
    REASON_FIELD_NUMBER: _ClassVar[int]
    CANCELLED_AT_FIELD_NUMBER: _ClassVar[int]
    reason: str
    cancelled_at: _timestamp_pb2.Timestamp
    def __init__(self, reason: _Optional[str] = ..., cancelled_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class OperationLifecycle(_message.Message):
    __slots__ = ("accepted", "running", "succeeded", "failed", "cancelled")
    ACCEPTED_FIELD_NUMBER: _ClassVar[int]
    RUNNING_FIELD_NUMBER: _ClassVar[int]
    SUCCEEDED_FIELD_NUMBER: _ClassVar[int]
    FAILED_FIELD_NUMBER: _ClassVar[int]
    CANCELLED_FIELD_NUMBER: _ClassVar[int]
    accepted: AcceptedOperation
    running: RunningOperation
    succeeded: SucceededOperation
    failed: FailedOperation
    cancelled: CancelledOperation
    def __init__(self, accepted: _Optional[_Union[AcceptedOperation, _Mapping]] = ..., running: _Optional[_Union[RunningOperation, _Mapping]] = ..., succeeded: _Optional[_Union[SucceededOperation, _Mapping]] = ..., failed: _Optional[_Union[FailedOperation, _Mapping]] = ..., cancelled: _Optional[_Union[CancelledOperation, _Mapping]] = ...) -> None: ...

class OperationHistoryGap(_message.Message):
    __slots__ = ("requested_after_cursor", "earliest_available_cursor", "latest_cursor", "requested_after")
    REQUESTED_AFTER_CURSOR_FIELD_NUMBER: _ClassVar[int]
    EARLIEST_AVAILABLE_CURSOR_FIELD_NUMBER: _ClassVar[int]
    LATEST_CURSOR_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_AFTER_FIELD_NUMBER: _ClassVar[int]
    requested_after_cursor: int
    earliest_available_cursor: int
    latest_cursor: int
    requested_after: int
    def __init__(self, requested_after_cursor: _Optional[int] = ..., earliest_available_cursor: _Optional[int] = ..., latest_cursor: _Optional[int] = ..., requested_after: _Optional[int] = ...) -> None: ...
