import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from sentientx.sx.common.v1 import assets_pb2 as _assets_pb2
from sentientx.sx.common.v1 import capabilities_pb2 as _capabilities_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from sentientx.sx.common.v1 import tasks_pb2 as _tasks_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class EmbodimentKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EMBODIMENT_KIND_UNSPECIFIED: _ClassVar[EmbodimentKind]
    EMBODIMENT_KIND_ROBOT: _ClassVar[EmbodimentKind]
    EMBODIMENT_KIND_CAPTURE_RIG: _ClassVar[EmbodimentKind]
    EMBODIMENT_KIND_TELEOP_STATION: _ClassVar[EmbodimentKind]

class EmbodimentOwnership(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EMBODIMENT_OWNERSHIP_UNSPECIFIED: _ClassVar[EmbodimentOwnership]
    EMBODIMENT_OWNERSHIP_PLATFORM: _ClassVar[EmbodimentOwnership]
    EMBODIMENT_OWNERSHIP_PROJECT: _ClassVar[EmbodimentOwnership]

class EmbodimentQualification(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EMBODIMENT_QUALIFICATION_UNSPECIFIED: _ClassVar[EmbodimentQualification]
    EMBODIMENT_QUALIFICATION_QUALIFIED: _ClassVar[EmbodimentQualification]
    EMBODIMENT_QUALIFICATION_REGISTERED: _ClassVar[EmbodimentQualification]
    EMBODIMENT_QUALIFICATION_DEVELOPMENT: _ClassVar[EmbodimentQualification]

class DevelopmentQualificationReason(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DEVELOPMENT_QUALIFICATION_REASON_UNSPECIFIED: _ClassVar[DevelopmentQualificationReason]
    DEVELOPMENT_QUALIFICATION_REASON_MISSING_AUTHORITATIVE_DESCRIPTION: _ClassVar[DevelopmentQualificationReason]
    DEVELOPMENT_QUALIFICATION_REASON_MISSING_CAMERA_CALIBRATION: _ClassVar[DevelopmentQualificationReason]
    DEVELOPMENT_QUALIFICATION_REASON_MISSING_CAMERA_INSTALLATION: _ClassVar[DevelopmentQualificationReason]
    DEVELOPMENT_QUALIFICATION_REASON_MISSING_JOINT_LIMITS: _ClassVar[DevelopmentQualificationReason]

class PartOrigin(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PART_ORIGIN_UNSPECIFIED: _ClassVar[PartOrigin]
    PART_ORIGIN_FIRST_PARTY: _ClassVar[PartOrigin]
    PART_ORIGIN_ADMITTED: _ClassVar[PartOrigin]

class CoordinateUnit(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    COORDINATE_UNIT_UNSPECIFIED: _ClassVar[CoordinateUnit]
    COORDINATE_UNIT_RADIAN: _ClassVar[CoordinateUnit]
    COORDINATE_UNIT_METER: _ClassVar[CoordinateUnit]
    COORDINATE_UNIT_RADIANS_PER_SECOND: _ClassVar[CoordinateUnit]
    COORDINATE_UNIT_METERS_PER_SECOND: _ClassVar[CoordinateUnit]
    COORDINATE_UNIT_NEWTON_METER: _ClassVar[CoordinateUnit]
    COORDINATE_UNIT_UNITLESS: _ClassVar[CoordinateUnit]

class ActuatorModel(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ACTUATOR_MODEL_UNSPECIFIED: _ClassVar[ActuatorModel]
    ACTUATOR_MODEL_FEETECH_STS3215: _ClassVar[ActuatorModel]

class ActuatorBus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ACTUATOR_BUS_UNSPECIFIED: _ClassVar[ActuatorBus]
    ACTUATOR_BUS_FEETECH_SERIAL: _ClassVar[ActuatorBus]

class ActuatorDirection(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ACTUATOR_DIRECTION_UNSPECIFIED: _ClassVar[ActuatorDirection]
    ACTUATOR_DIRECTION_FORWARD: _ClassVar[ActuatorDirection]
    ACTUATOR_DIRECTION_REVERSED: _ClassVar[ActuatorDirection]

class GraspKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    GRASP_KIND_UNSPECIFIED: _ClassVar[GraspKind]
    GRASP_KIND_PARALLEL: _ClassVar[GraspKind]
    GRASP_KIND_DEXTEROUS: _ClassVar[GraspKind]

class SensorModel(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SENSOR_MODEL_UNSPECIFIED: _ClassVar[SensorModel]
    SENSOR_MODEL_UVC_MONO: _ClassVar[SensorModel]
    SENSOR_MODEL_REALSENSE_D405: _ClassVar[SensorModel]
    SENSOR_MODEL_REALSENSE_D435: _ClassVar[SensorModel]
    SENSOR_MODEL_QUEST3_RGB: _ClassVar[SensorModel]
    SENSOR_MODEL_INSTA360_X5: _ClassVar[SensorModel]

class CameraModality(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CAMERA_MODALITY_UNSPECIFIED: _ClassVar[CameraModality]
    CAMERA_MODALITY_RGB: _ClassVar[CameraModality]
    CAMERA_MODALITY_DEPTH: _ClassVar[CameraModality]
    CAMERA_MODALITY_RGBD: _ClassVar[CameraModality]

class CameraOpticsAuthority(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CAMERA_OPTICS_AUTHORITY_UNSPECIFIED: _ClassVar[CameraOpticsAuthority]
    CAMERA_OPTICS_AUTHORITY_MODEL_NOMINAL: _ClassVar[CameraOpticsAuthority]
    CAMERA_OPTICS_AUTHORITY_REFERENCE_UNIT: _ClassVar[CameraOpticsAuthority]

class DistortionModel(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DISTORTION_MODEL_UNSPECIFIED: _ClassVar[DistortionModel]
    DISTORTION_MODEL_NONE: _ClassVar[DistortionModel]
    DISTORTION_MODEL_PLUMB_BOB: _ClassVar[DistortionModel]
    DISTORTION_MODEL_RATIONAL_POLYNOMIAL: _ClassVar[DistortionModel]
    DISTORTION_MODEL_EQUIDISTANT: _ClassVar[DistortionModel]
    DISTORTION_MODEL_KANNALA_BRANDT: _ClassVar[DistortionModel]

class MountKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    MOUNT_KIND_UNSPECIFIED: _ClassVar[MountKind]
    MOUNT_KIND_BOLT_DOWN: _ClassVar[MountKind]
    MOUNT_KIND_FREE_STANDING: _ClassVar[MountKind]
    MOUNT_KIND_MOBILE: _ClassVar[MountKind]
    MOUNT_KIND_CLAMP_EDGE: _ClassVar[MountKind]

class OperatorSite(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    OPERATOR_SITE_UNSPECIFIED: _ClassVar[OperatorSite]
    OPERATOR_SITE_HEAD: _ClassVar[OperatorSite]
    OPERATOR_SITE_LEFT_HAND: _ClassVar[OperatorSite]
    OPERATOR_SITE_RIGHT_HAND: _ClassVar[OperatorSite]

class SemanticDatasetKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SEMANTIC_DATASET_KIND_UNSPECIFIED: _ClassVar[SemanticDatasetKind]
    SEMANTIC_DATASET_KIND_ONLINE: _ClassVar[SemanticDatasetKind]
    SEMANTIC_DATASET_KIND_CORRECTION: _ClassVar[SemanticDatasetKind]
    SEMANTIC_DATASET_KIND_DEMO: _ClassVar[SemanticDatasetKind]

class SemanticFrameAnchor(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SEMANTIC_FRAME_ANCHOR_UNSPECIFIED: _ClassVar[SemanticFrameAnchor]
    SEMANTIC_FRAME_ANCHOR_EVENT: _ClassVar[SemanticFrameAnchor]
    SEMANTIC_FRAME_ANCHOR_MOTION: _ClassVar[SemanticFrameAnchor]
    SEMANTIC_FRAME_ANCHOR_UNIFORM: _ClassVar[SemanticFrameAnchor]

class SemanticPhaseSource(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SEMANTIC_PHASE_SOURCE_UNSPECIFIED: _ClassVar[SemanticPhaseSource]
    SEMANTIC_PHASE_SOURCE_ANNOTATION: _ClassVar[SemanticPhaseSource]
    SEMANTIC_PHASE_SOURCE_MODEL: _ClassVar[SemanticPhaseSource]

class SemanticTextSourceKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SEMANTIC_TEXT_SOURCE_KIND_UNSPECIFIED: _ClassVar[SemanticTextSourceKind]
    SEMANTIC_TEXT_SOURCE_KIND_TASK_CONTRACT: _ClassVar[SemanticTextSourceKind]
    SEMANTIC_TEXT_SOURCE_KIND_AGENT_LAYER: _ClassVar[SemanticTextSourceKind]
    SEMANTIC_TEXT_SOURCE_KIND_EPISODE_META: _ClassVar[SemanticTextSourceKind]
    SEMANTIC_TEXT_SOURCE_KIND_ANNOTATION: _ClassVar[SemanticTextSourceKind]

class SemanticAtlasPointKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SEMANTIC_ATLAS_POINT_KIND_UNSPECIFIED: _ClassVar[SemanticAtlasPointKind]
    SEMANTIC_ATLAS_POINT_KIND_FRAME: _ClassVar[SemanticAtlasPointKind]
    SEMANTIC_ATLAS_POINT_KIND_EPISODE: _ClassVar[SemanticAtlasPointKind]
EMBODIMENT_KIND_UNSPECIFIED: EmbodimentKind
EMBODIMENT_KIND_ROBOT: EmbodimentKind
EMBODIMENT_KIND_CAPTURE_RIG: EmbodimentKind
EMBODIMENT_KIND_TELEOP_STATION: EmbodimentKind
EMBODIMENT_OWNERSHIP_UNSPECIFIED: EmbodimentOwnership
EMBODIMENT_OWNERSHIP_PLATFORM: EmbodimentOwnership
EMBODIMENT_OWNERSHIP_PROJECT: EmbodimentOwnership
EMBODIMENT_QUALIFICATION_UNSPECIFIED: EmbodimentQualification
EMBODIMENT_QUALIFICATION_QUALIFIED: EmbodimentQualification
EMBODIMENT_QUALIFICATION_REGISTERED: EmbodimentQualification
EMBODIMENT_QUALIFICATION_DEVELOPMENT: EmbodimentQualification
DEVELOPMENT_QUALIFICATION_REASON_UNSPECIFIED: DevelopmentQualificationReason
DEVELOPMENT_QUALIFICATION_REASON_MISSING_AUTHORITATIVE_DESCRIPTION: DevelopmentQualificationReason
DEVELOPMENT_QUALIFICATION_REASON_MISSING_CAMERA_CALIBRATION: DevelopmentQualificationReason
DEVELOPMENT_QUALIFICATION_REASON_MISSING_CAMERA_INSTALLATION: DevelopmentQualificationReason
DEVELOPMENT_QUALIFICATION_REASON_MISSING_JOINT_LIMITS: DevelopmentQualificationReason
PART_ORIGIN_UNSPECIFIED: PartOrigin
PART_ORIGIN_FIRST_PARTY: PartOrigin
PART_ORIGIN_ADMITTED: PartOrigin
COORDINATE_UNIT_UNSPECIFIED: CoordinateUnit
COORDINATE_UNIT_RADIAN: CoordinateUnit
COORDINATE_UNIT_METER: CoordinateUnit
COORDINATE_UNIT_RADIANS_PER_SECOND: CoordinateUnit
COORDINATE_UNIT_METERS_PER_SECOND: CoordinateUnit
COORDINATE_UNIT_NEWTON_METER: CoordinateUnit
COORDINATE_UNIT_UNITLESS: CoordinateUnit
ACTUATOR_MODEL_UNSPECIFIED: ActuatorModel
ACTUATOR_MODEL_FEETECH_STS3215: ActuatorModel
ACTUATOR_BUS_UNSPECIFIED: ActuatorBus
ACTUATOR_BUS_FEETECH_SERIAL: ActuatorBus
ACTUATOR_DIRECTION_UNSPECIFIED: ActuatorDirection
ACTUATOR_DIRECTION_FORWARD: ActuatorDirection
ACTUATOR_DIRECTION_REVERSED: ActuatorDirection
GRASP_KIND_UNSPECIFIED: GraspKind
GRASP_KIND_PARALLEL: GraspKind
GRASP_KIND_DEXTEROUS: GraspKind
SENSOR_MODEL_UNSPECIFIED: SensorModel
SENSOR_MODEL_UVC_MONO: SensorModel
SENSOR_MODEL_REALSENSE_D405: SensorModel
SENSOR_MODEL_REALSENSE_D435: SensorModel
SENSOR_MODEL_QUEST3_RGB: SensorModel
SENSOR_MODEL_INSTA360_X5: SensorModel
CAMERA_MODALITY_UNSPECIFIED: CameraModality
CAMERA_MODALITY_RGB: CameraModality
CAMERA_MODALITY_DEPTH: CameraModality
CAMERA_MODALITY_RGBD: CameraModality
CAMERA_OPTICS_AUTHORITY_UNSPECIFIED: CameraOpticsAuthority
CAMERA_OPTICS_AUTHORITY_MODEL_NOMINAL: CameraOpticsAuthority
CAMERA_OPTICS_AUTHORITY_REFERENCE_UNIT: CameraOpticsAuthority
DISTORTION_MODEL_UNSPECIFIED: DistortionModel
DISTORTION_MODEL_NONE: DistortionModel
DISTORTION_MODEL_PLUMB_BOB: DistortionModel
DISTORTION_MODEL_RATIONAL_POLYNOMIAL: DistortionModel
DISTORTION_MODEL_EQUIDISTANT: DistortionModel
DISTORTION_MODEL_KANNALA_BRANDT: DistortionModel
MOUNT_KIND_UNSPECIFIED: MountKind
MOUNT_KIND_BOLT_DOWN: MountKind
MOUNT_KIND_FREE_STANDING: MountKind
MOUNT_KIND_MOBILE: MountKind
MOUNT_KIND_CLAMP_EDGE: MountKind
OPERATOR_SITE_UNSPECIFIED: OperatorSite
OPERATOR_SITE_HEAD: OperatorSite
OPERATOR_SITE_LEFT_HAND: OperatorSite
OPERATOR_SITE_RIGHT_HAND: OperatorSite
SEMANTIC_DATASET_KIND_UNSPECIFIED: SemanticDatasetKind
SEMANTIC_DATASET_KIND_ONLINE: SemanticDatasetKind
SEMANTIC_DATASET_KIND_CORRECTION: SemanticDatasetKind
SEMANTIC_DATASET_KIND_DEMO: SemanticDatasetKind
SEMANTIC_FRAME_ANCHOR_UNSPECIFIED: SemanticFrameAnchor
SEMANTIC_FRAME_ANCHOR_EVENT: SemanticFrameAnchor
SEMANTIC_FRAME_ANCHOR_MOTION: SemanticFrameAnchor
SEMANTIC_FRAME_ANCHOR_UNIFORM: SemanticFrameAnchor
SEMANTIC_PHASE_SOURCE_UNSPECIFIED: SemanticPhaseSource
SEMANTIC_PHASE_SOURCE_ANNOTATION: SemanticPhaseSource
SEMANTIC_PHASE_SOURCE_MODEL: SemanticPhaseSource
SEMANTIC_TEXT_SOURCE_KIND_UNSPECIFIED: SemanticTextSourceKind
SEMANTIC_TEXT_SOURCE_KIND_TASK_CONTRACT: SemanticTextSourceKind
SEMANTIC_TEXT_SOURCE_KIND_AGENT_LAYER: SemanticTextSourceKind
SEMANTIC_TEXT_SOURCE_KIND_EPISODE_META: SemanticTextSourceKind
SEMANTIC_TEXT_SOURCE_KIND_ANNOTATION: SemanticTextSourceKind
SEMANTIC_ATLAS_POINT_KIND_UNSPECIFIED: SemanticAtlasPointKind
SEMANTIC_ATLAS_POINT_KIND_FRAME: SemanticAtlasPointKind
SEMANTIC_ATLAS_POINT_KIND_EPISODE: SemanticAtlasPointKind

class Lineage(_message.Message):
    __slots__ = ("family", "variant", "revision")
    FAMILY_FIELD_NUMBER: _ClassVar[int]
    VARIANT_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    family: str
    variant: str
    revision: str
    def __init__(self, family: _Optional[str] = ..., variant: _Optional[str] = ..., revision: _Optional[str] = ...) -> None: ...

class BoundedCoordinate(_message.Message):
    __slots__ = ("lower", "upper")
    LOWER_FIELD_NUMBER: _ClassVar[int]
    UPPER_FIELD_NUMBER: _ClassVar[int]
    lower: float
    upper: float
    def __init__(self, lower: _Optional[float] = ..., upper: _Optional[float] = ...) -> None: ...

class UnboundedCoordinate(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CoordinateBounds(_message.Message):
    __slots__ = ("bounded", "unbounded")
    BOUNDED_FIELD_NUMBER: _ClassVar[int]
    UNBOUNDED_FIELD_NUMBER: _ClassVar[int]
    bounded: BoundedCoordinate
    unbounded: UnboundedCoordinate
    def __init__(self, bounded: _Optional[_Union[BoundedCoordinate, _Mapping]] = ..., unbounded: _Optional[_Union[UnboundedCoordinate, _Mapping]] = ...) -> None: ...

class ActuatorBinding(_message.Message):
    __slots__ = ("model", "bus", "bus_id", "direction", "zero_offset", "reduction")
    MODEL_FIELD_NUMBER: _ClassVar[int]
    BUS_FIELD_NUMBER: _ClassVar[int]
    BUS_ID_FIELD_NUMBER: _ClassVar[int]
    DIRECTION_FIELD_NUMBER: _ClassVar[int]
    ZERO_OFFSET_FIELD_NUMBER: _ClassVar[int]
    REDUCTION_FIELD_NUMBER: _ClassVar[int]
    model: ActuatorModel
    bus: ActuatorBus
    bus_id: int
    direction: ActuatorDirection
    zero_offset: float
    reduction: float
    def __init__(self, model: _Optional[_Union[ActuatorModel, str]] = ..., bus: _Optional[_Union[ActuatorBus, str]] = ..., bus_id: _Optional[int] = ..., direction: _Optional[_Union[ActuatorDirection, str]] = ..., zero_offset: _Optional[float] = ..., reduction: _Optional[float] = ...) -> None: ...

class JointAxis(_message.Message):
    __slots__ = ("name", "unit", "bounds", "actuator")
    NAME_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    BOUNDS_FIELD_NUMBER: _ClassVar[int]
    ACTUATOR_FIELD_NUMBER: _ClassVar[int]
    name: str
    unit: CoordinateUnit
    bounds: CoordinateBounds
    actuator: ActuatorBinding
    def __init__(self, name: _Optional[str] = ..., unit: _Optional[_Union[CoordinateUnit, str]] = ..., bounds: _Optional[_Union[CoordinateBounds, _Mapping]] = ..., actuator: _Optional[_Union[ActuatorBinding, _Mapping]] = ...) -> None: ...

class JointLayout(_message.Message):
    __slots__ = ("axes",)
    AXES_FIELD_NUMBER: _ClassVar[int]
    axes: _containers.RepeatedCompositeFieldContainer[JointAxis]
    def __init__(self, axes: _Optional[_Iterable[_Union[JointAxis, _Mapping]]] = ...) -> None: ...

class JointConfiguration(_message.Message):
    __slots__ = ("values",)
    VALUES_FIELD_NUMBER: _ClassVar[int]
    values: _containers.RepeatedScalarFieldContainer[float]
    def __init__(self, values: _Optional[_Iterable[float]] = ...) -> None: ...

class PhysicalSpec(_message.Message):
    __slots__ = ("payload_kg", "reach_m", "mass_kg")
    PAYLOAD_KG_FIELD_NUMBER: _ClassVar[int]
    REACH_M_FIELD_NUMBER: _ClassVar[int]
    MASS_KG_FIELD_NUMBER: _ClassVar[int]
    payload_kg: float
    reach_m: float
    mass_kg: float
    def __init__(self, payload_kg: _Optional[float] = ..., reach_m: _Optional[float] = ..., mass_kg: _Optional[float] = ...) -> None: ...

class CurveKnot(_message.Message):
    __slots__ = ("x", "y")
    X_FIELD_NUMBER: _ClassVar[int]
    Y_FIELD_NUMBER: _ClassVar[int]
    x: float
    y: float
    def __init__(self, x: _Optional[float] = ..., y: _Optional[float] = ...) -> None: ...

class Curve1D(_message.Message):
    __slots__ = ("knots",)
    KNOTS_FIELD_NUMBER: _ClassVar[int]
    knots: _containers.RepeatedCompositeFieldContainer[CurveKnot]
    def __init__(self, knots: _Optional[_Iterable[_Union[CurveKnot, _Mapping]]] = ...) -> None: ...

class GripperTravel(_message.Message):
    __slots__ = ("closed_m", "open_m")
    CLOSED_M_FIELD_NUMBER: _ClassVar[int]
    OPEN_M_FIELD_NUMBER: _ClassVar[int]
    closed_m: float
    open_m: float
    def __init__(self, closed_m: _Optional[float] = ..., open_m: _Optional[float] = ...) -> None: ...

class Position3(_message.Message):
    __slots__ = ("x", "y", "z")
    X_FIELD_NUMBER: _ClassVar[int]
    Y_FIELD_NUMBER: _ClassVar[int]
    Z_FIELD_NUMBER: _ClassVar[int]
    x: float
    y: float
    z: float
    def __init__(self, x: _Optional[float] = ..., y: _Optional[float] = ..., z: _Optional[float] = ...) -> None: ...

class MimicJoint(_message.Message):
    __slots__ = ("name", "of", "multiplier")
    NAME_FIELD_NUMBER: _ClassVar[int]
    OF_FIELD_NUMBER: _ClassVar[int]
    MULTIPLIER_FIELD_NUMBER: _ClassVar[int]
    name: str
    of: str
    multiplier: float
    def __init__(self, name: _Optional[str] = ..., of: _Optional[str] = ..., multiplier: _Optional[float] = ...) -> None: ...

class ArmSpec(_message.Message):
    __slots__ = ("layout", "home", "ready", "physical")
    LAYOUT_FIELD_NUMBER: _ClassVar[int]
    HOME_FIELD_NUMBER: _ClassVar[int]
    READY_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_FIELD_NUMBER: _ClassVar[int]
    layout: JointLayout
    home: JointConfiguration
    ready: JointConfiguration
    physical: PhysicalSpec
    def __init__(self, layout: _Optional[_Union[JointLayout, _Mapping]] = ..., home: _Optional[_Union[JointConfiguration, _Mapping]] = ..., ready: _Optional[_Union[JointConfiguration, _Mapping]] = ..., physical: _Optional[_Union[PhysicalSpec, _Mapping]] = ...) -> None: ...

class JointGroupSpec(_message.Message):
    __slots__ = ("layout", "home")
    LAYOUT_FIELD_NUMBER: _ClassVar[int]
    HOME_FIELD_NUMBER: _ClassVar[int]
    layout: JointLayout
    home: JointConfiguration
    def __init__(self, layout: _Optional[_Union[JointLayout, _Mapping]] = ..., home: _Optional[_Union[JointConfiguration, _Mapping]] = ...) -> None: ...

class GripperSpec(_message.Message):
    __slots__ = ("grasp", "layout", "travel", "grasp_centre_m", "mimic_joints", "gap_curve", "physical")
    GRASP_FIELD_NUMBER: _ClassVar[int]
    LAYOUT_FIELD_NUMBER: _ClassVar[int]
    TRAVEL_FIELD_NUMBER: _ClassVar[int]
    GRASP_CENTRE_M_FIELD_NUMBER: _ClassVar[int]
    MIMIC_JOINTS_FIELD_NUMBER: _ClassVar[int]
    GAP_CURVE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_FIELD_NUMBER: _ClassVar[int]
    grasp: GraspKind
    layout: JointLayout
    travel: GripperTravel
    grasp_centre_m: Position3
    mimic_joints: _containers.RepeatedCompositeFieldContainer[MimicJoint]
    gap_curve: Curve1D
    physical: PhysicalSpec
    def __init__(self, grasp: _Optional[_Union[GraspKind, str]] = ..., layout: _Optional[_Union[JointLayout, _Mapping]] = ..., travel: _Optional[_Union[GripperTravel, _Mapping]] = ..., grasp_centre_m: _Optional[_Union[Position3, _Mapping]] = ..., mimic_joints: _Optional[_Iterable[_Union[MimicJoint, _Mapping]]] = ..., gap_curve: _Optional[_Union[Curve1D, _Mapping]] = ..., physical: _Optional[_Union[PhysicalSpec, _Mapping]] = ...) -> None: ...

class FactSource(_message.Message):
    __slots__ = ("repository", "revision", "path")
    REPOSITORY_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    repository: str
    revision: str
    path: str
    def __init__(self, repository: _Optional[str] = ..., revision: _Optional[str] = ..., path: _Optional[str] = ...) -> None: ...

class CameraOptics(_message.Message):
    __slots__ = ("width", "height", "image_from_camera", "distortion_model", "distortion_coefficients", "authority", "source")
    WIDTH_FIELD_NUMBER: _ClassVar[int]
    HEIGHT_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FROM_CAMERA_FIELD_NUMBER: _ClassVar[int]
    DISTORTION_MODEL_FIELD_NUMBER: _ClassVar[int]
    DISTORTION_COEFFICIENTS_FIELD_NUMBER: _ClassVar[int]
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    width: int
    height: int
    image_from_camera: _containers.RepeatedScalarFieldContainer[float]
    distortion_model: DistortionModel
    distortion_coefficients: _containers.RepeatedScalarFieldContainer[float]
    authority: CameraOpticsAuthority
    source: FactSource
    def __init__(self, width: _Optional[int] = ..., height: _Optional[int] = ..., image_from_camera: _Optional[_Iterable[float]] = ..., distortion_model: _Optional[_Union[DistortionModel, str]] = ..., distortion_coefficients: _Optional[_Iterable[float]] = ..., authority: _Optional[_Union[CameraOpticsAuthority, str]] = ..., source: _Optional[_Union[FactSource, _Mapping]] = ...) -> None: ...

class CameraSpec(_message.Message):
    __slots__ = ("sensor_model", "modality", "fps", "optics")
    SENSOR_MODEL_FIELD_NUMBER: _ClassVar[int]
    MODALITY_FIELD_NUMBER: _ClassVar[int]
    FPS_FIELD_NUMBER: _ClassVar[int]
    OPTICS_FIELD_NUMBER: _ClassVar[int]
    sensor_model: SensorModel
    modality: CameraModality
    fps: float
    optics: CameraOptics
    def __init__(self, sensor_model: _Optional[_Union[SensorModel, str]] = ..., modality: _Optional[_Union[CameraModality, str]] = ..., fps: _Optional[float] = ..., optics: _Optional[_Union[CameraOptics, _Mapping]] = ...) -> None: ...

class MobileBaseSpec(_message.Message):
    __slots__ = ("layout",)
    LAYOUT_FIELD_NUMBER: _ClassVar[int]
    layout: JointLayout
    def __init__(self, layout: _Optional[_Union[JointLayout, _Mapping]] = ...) -> None: ...

class ForceTorqueSpec(_message.Message):
    __slots__ = ("rate_hz",)
    RATE_HZ_FIELD_NUMBER: _ClassVar[int]
    rate_hz: float
    def __init__(self, rate_hz: _Optional[float] = ...) -> None: ...

class DeviceSpec(_message.Message):
    __slots__ = ("description",)
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    description: str
    def __init__(self, description: _Optional[str] = ...) -> None: ...

class Part(_message.Message):
    __slots__ = ("part_id", "arm", "joint_group", "gripper", "camera", "mobile_base", "force_torque", "device")
    PART_ID_FIELD_NUMBER: _ClassVar[int]
    ARM_FIELD_NUMBER: _ClassVar[int]
    JOINT_GROUP_FIELD_NUMBER: _ClassVar[int]
    GRIPPER_FIELD_NUMBER: _ClassVar[int]
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    MOBILE_BASE_FIELD_NUMBER: _ClassVar[int]
    FORCE_TORQUE_FIELD_NUMBER: _ClassVar[int]
    DEVICE_FIELD_NUMBER: _ClassVar[int]
    part_id: str
    arm: ArmSpec
    joint_group: JointGroupSpec
    gripper: GripperSpec
    camera: CameraSpec
    mobile_base: MobileBaseSpec
    force_torque: ForceTorqueSpec
    device: DeviceSpec
    def __init__(self, part_id: _Optional[str] = ..., arm: _Optional[_Union[ArmSpec, _Mapping]] = ..., joint_group: _Optional[_Union[JointGroupSpec, _Mapping]] = ..., gripper: _Optional[_Union[GripperSpec, _Mapping]] = ..., camera: _Optional[_Union[CameraSpec, _Mapping]] = ..., mobile_base: _Optional[_Union[MobileBaseSpec, _Mapping]] = ..., force_torque: _Optional[_Union[ForceTorqueSpec, _Mapping]] = ..., device: _Optional[_Union[DeviceSpec, _Mapping]] = ...) -> None: ...

class ComposablePart(_message.Message):
    __slots__ = ("part_id", "arm", "joint_group", "gripper", "mobile_base")
    PART_ID_FIELD_NUMBER: _ClassVar[int]
    ARM_FIELD_NUMBER: _ClassVar[int]
    JOINT_GROUP_FIELD_NUMBER: _ClassVar[int]
    GRIPPER_FIELD_NUMBER: _ClassVar[int]
    MOBILE_BASE_FIELD_NUMBER: _ClassVar[int]
    part_id: str
    arm: ArmSpec
    joint_group: JointGroupSpec
    gripper: GripperSpec
    mobile_base: MobileBaseSpec
    def __init__(self, part_id: _Optional[str] = ..., arm: _Optional[_Union[ArmSpec, _Mapping]] = ..., joint_group: _Optional[_Union[JointGroupSpec, _Mapping]] = ..., gripper: _Optional[_Union[GripperSpec, _Mapping]] = ..., mobile_base: _Optional[_Union[MobileBaseSpec, _Mapping]] = ...) -> None: ...

class RootMount(_message.Message):
    __slots__ = ("frame",)
    FRAME_FIELD_NUMBER: _ClassVar[int]
    frame: str
    def __init__(self, frame: _Optional[str] = ...) -> None: ...

class MountedOn(_message.Message):
    __slots__ = ("parent", "frame")
    PARENT_FIELD_NUMBER: _ClassVar[int]
    FRAME_FIELD_NUMBER: _ClassVar[int]
    parent: str
    frame: str
    def __init__(self, parent: _Optional[str] = ..., frame: _Optional[str] = ...) -> None: ...

class ComponentMount(_message.Message):
    __slots__ = ("root", "mounted_on")
    ROOT_FIELD_NUMBER: _ClassVar[int]
    MOUNTED_ON_FIELD_NUMBER: _ClassVar[int]
    root: RootMount
    mounted_on: MountedOn
    def __init__(self, root: _Optional[_Union[RootMount, _Mapping]] = ..., mounted_on: _Optional[_Union[MountedOn, _Mapping]] = ...) -> None: ...

class Component(_message.Message):
    __slots__ = ("instance", "body", "leader", "sensor", "mount")
    INSTANCE_FIELD_NUMBER: _ClassVar[int]
    BODY_FIELD_NUMBER: _ClassVar[int]
    LEADER_FIELD_NUMBER: _ClassVar[int]
    SENSOR_FIELD_NUMBER: _ClassVar[int]
    MOUNT_FIELD_NUMBER: _ClassVar[int]
    instance: str
    body: Part
    leader: Part
    sensor: Part
    mount: ComponentMount
    def __init__(self, instance: _Optional[str] = ..., body: _Optional[_Union[Part, _Mapping]] = ..., leader: _Optional[_Union[Part, _Mapping]] = ..., sensor: _Optional[_Union[Part, _Mapping]] = ..., mount: _Optional[_Union[ComponentMount, _Mapping]] = ...) -> None: ...

class ControlRates(_message.Message):
    __slots__ = ("policy_hz", "low_level_hz")
    POLICY_HZ_FIELD_NUMBER: _ClassVar[int]
    LOW_LEVEL_HZ_FIELD_NUMBER: _ClassVar[int]
    policy_hz: float
    low_level_hz: float
    def __init__(self, policy_hz: _Optional[float] = ..., low_level_hz: _Optional[float] = ...) -> None: ...

class BaseMount(_message.Message):
    __slots__ = ("kind", "frame", "half_extent_x_m", "half_extent_y_m", "centre_x_m", "centre_y_m", "clearance_m")
    KIND_FIELD_NUMBER: _ClassVar[int]
    FRAME_FIELD_NUMBER: _ClassVar[int]
    HALF_EXTENT_X_M_FIELD_NUMBER: _ClassVar[int]
    HALF_EXTENT_Y_M_FIELD_NUMBER: _ClassVar[int]
    CENTRE_X_M_FIELD_NUMBER: _ClassVar[int]
    CENTRE_Y_M_FIELD_NUMBER: _ClassVar[int]
    CLEARANCE_M_FIELD_NUMBER: _ClassVar[int]
    kind: MountKind
    frame: str
    half_extent_x_m: float
    half_extent_y_m: float
    centre_x_m: float
    centre_y_m: float
    clearance_m: float
    def __init__(self, kind: _Optional[_Union[MountKind, str]] = ..., frame: _Optional[str] = ..., half_extent_x_m: _Optional[float] = ..., half_extent_y_m: _Optional[float] = ..., centre_x_m: _Optional[float] = ..., centre_y_m: _Optional[float] = ..., clearance_m: _Optional[float] = ...) -> None: ...

class OperatorMount(_message.Message):
    __slots__ = ("site", "root_frame", "attachment_frame")
    SITE_FIELD_NUMBER: _ClassVar[int]
    ROOT_FRAME_FIELD_NUMBER: _ClassVar[int]
    ATTACHMENT_FRAME_FIELD_NUMBER: _ClassVar[int]
    site: OperatorSite
    root_frame: str
    attachment_frame: str
    def __init__(self, site: _Optional[_Union[OperatorSite, str]] = ..., root_frame: _Optional[str] = ..., attachment_frame: _Optional[str] = ...) -> None: ...

class Embodiment(_message.Message):
    __slots__ = ("schema_version", "id", "name", "label", "kind", "lineage", "components", "rates", "base_mount", "operator_mounts", "assets")
    SCHEMA_VERSION_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    LINEAGE_FIELD_NUMBER: _ClassVar[int]
    COMPONENTS_FIELD_NUMBER: _ClassVar[int]
    RATES_FIELD_NUMBER: _ClassVar[int]
    BASE_MOUNT_FIELD_NUMBER: _ClassVar[int]
    OPERATOR_MOUNTS_FIELD_NUMBER: _ClassVar[int]
    ASSETS_FIELD_NUMBER: _ClassVar[int]
    schema_version: int
    id: str
    name: str
    label: str
    kind: EmbodimentKind
    lineage: Lineage
    components: _containers.RepeatedCompositeFieldContainer[Component]
    rates: ControlRates
    base_mount: BaseMount
    operator_mounts: _containers.RepeatedCompositeFieldContainer[OperatorMount]
    assets: _containers.RepeatedCompositeFieldContainer[_assets_pb2.ProvenancedAsset]
    def __init__(self, schema_version: _Optional[int] = ..., id: _Optional[str] = ..., name: _Optional[str] = ..., label: _Optional[str] = ..., kind: _Optional[_Union[EmbodimentKind, str]] = ..., lineage: _Optional[_Union[Lineage, _Mapping]] = ..., components: _Optional[_Iterable[_Union[Component, _Mapping]]] = ..., rates: _Optional[_Union[ControlRates, _Mapping]] = ..., base_mount: _Optional[_Union[BaseMount, _Mapping]] = ..., operator_mounts: _Optional[_Iterable[_Union[OperatorMount, _Mapping]]] = ..., assets: _Optional[_Iterable[_Union[_assets_pb2.ProvenancedAsset, _Mapping]]] = ...) -> None: ...

class EmbodimentResource(_message.Message):
    __slots__ = ("name", "embodiment", "ownership", "qualification", "created_at")
    NAME_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_FIELD_NUMBER: _ClassVar[int]
    OWNERSHIP_FIELD_NUMBER: _ClassVar[int]
    QUALIFICATION_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    name: str
    embodiment: Embodiment
    ownership: EmbodimentOwnership
    qualification: EmbodimentQualification
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, name: _Optional[str] = ..., embodiment: _Optional[_Union[Embodiment, _Mapping]] = ..., ownership: _Optional[_Union[EmbodimentOwnership, str]] = ..., qualification: _Optional[_Union[EmbodimentQualification, str]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class EmbodimentRef(_message.Message):
    __slots__ = ("name", "content_id", "label")
    NAME_FIELD_NUMBER: _ClassVar[int]
    CONTENT_ID_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    name: str
    content_id: str
    label: str
    def __init__(self, name: _Optional[str] = ..., content_id: _Optional[str] = ..., label: _Optional[str] = ...) -> None: ...

class ComposablePartResource(_message.Message):
    __slots__ = ("part", "drivable", "origin")
    PART_FIELD_NUMBER: _ClassVar[int]
    DRIVABLE_FIELD_NUMBER: _ClassVar[int]
    ORIGIN_FIELD_NUMBER: _ClassVar[int]
    part: ComposablePart
    drivable: bool
    origin: PartOrigin
    def __init__(self, part: _Optional[_Union[ComposablePart, _Mapping]] = ..., drivable: _Optional[bool] = ..., origin: _Optional[_Union[PartOrigin, str]] = ...) -> None: ...

class AssemblyAttachment(_message.Message):
    __slots__ = ("instance", "part_id", "mount")
    INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PART_ID_FIELD_NUMBER: _ClassVar[int]
    MOUNT_FIELD_NUMBER: _ClassVar[int]
    instance: str
    part_id: str
    mount: ComponentMount
    def __init__(self, instance: _Optional[str] = ..., part_id: _Optional[str] = ..., mount: _Optional[_Union[ComponentMount, _Mapping]] = ...) -> None: ...

class AssemblyDefinition(_message.Message):
    __slots__ = ("name", "label", "kind", "lineage", "attachments", "assets", "rates", "base_mount")
    NAME_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    LINEAGE_FIELD_NUMBER: _ClassVar[int]
    ATTACHMENTS_FIELD_NUMBER: _ClassVar[int]
    ASSETS_FIELD_NUMBER: _ClassVar[int]
    RATES_FIELD_NUMBER: _ClassVar[int]
    BASE_MOUNT_FIELD_NUMBER: _ClassVar[int]
    name: str
    label: str
    kind: EmbodimentKind
    lineage: Lineage
    attachments: _containers.RepeatedCompositeFieldContainer[AssemblyAttachment]
    assets: _containers.RepeatedCompositeFieldContainer[_assets_pb2.ProvenancedAsset]
    rates: ControlRates
    base_mount: BaseMount
    def __init__(self, name: _Optional[str] = ..., label: _Optional[str] = ..., kind: _Optional[_Union[EmbodimentKind, str]] = ..., lineage: _Optional[_Union[Lineage, _Mapping]] = ..., attachments: _Optional[_Iterable[_Union[AssemblyAttachment, _Mapping]]] = ..., assets: _Optional[_Iterable[_Union[_assets_pb2.ProvenancedAsset, _Mapping]]] = ..., rates: _Optional[_Union[ControlRates, _Mapping]] = ..., base_mount: _Optional[_Union[BaseMount, _Mapping]] = ...) -> None: ...

class TaskAdmissibility(_message.Message):
    __slots__ = ("task", "assignments")
    TASK_FIELD_NUMBER: _ClassVar[int]
    ASSIGNMENTS_FIELD_NUMBER: _ClassVar[int]
    task: _common_pb2.TaskContractRef
    assignments: _containers.RepeatedCompositeFieldContainer[_capabilities_pb2.TaskRoleBinding]
    def __init__(self, task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., assignments: _Optional[_Iterable[_Union[_capabilities_pb2.TaskRoleBinding, _Mapping]]] = ...) -> None: ...

class CandidateCompatible(_message.Message):
    __slots__ = ("task", "embodiment", "assignments")
    TASK_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_FIELD_NUMBER: _ClassVar[int]
    ASSIGNMENTS_FIELD_NUMBER: _ClassVar[int]
    task: _common_pb2.TaskContractRef
    embodiment: EmbodimentRef
    assignments: _containers.RepeatedCompositeFieldContainer[_capabilities_pb2.TaskRoleBinding]
    def __init__(self, task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., embodiment: _Optional[_Union[EmbodimentRef, _Mapping]] = ..., assignments: _Optional[_Iterable[_Union[_capabilities_pb2.TaskRoleBinding, _Mapping]]] = ...) -> None: ...

class CandidateShortfall(_message.Message):
    __slots__ = ("task", "embodiment", "missing_roles", "recovery")
    TASK_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_FIELD_NUMBER: _ClassVar[int]
    MISSING_ROLES_FIELD_NUMBER: _ClassVar[int]
    RECOVERY_FIELD_NUMBER: _ClassVar[int]
    task: _common_pb2.TaskContractRef
    embodiment: EmbodimentRef
    missing_roles: _containers.RepeatedScalarFieldContainer[str]
    recovery: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., embodiment: _Optional[_Union[EmbodimentRef, _Mapping]] = ..., missing_roles: _Optional[_Iterable[str]] = ..., recovery: _Optional[_Iterable[str]] = ...) -> None: ...

class CandidateBodyNotFound(_message.Message):
    __slots__ = ("requested_body_name", "recovery")
    REQUESTED_BODY_NAME_FIELD_NUMBER: _ClassVar[int]
    RECOVERY_FIELD_NUMBER: _ClassVar[int]
    requested_body_name: str
    recovery: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, requested_body_name: _Optional[str] = ..., recovery: _Optional[_Iterable[str]] = ...) -> None: ...

class CandidateInvalidCapabilityProfile(_message.Message):
    __slots__ = ("embodiment", "recovery")
    EMBODIMENT_FIELD_NUMBER: _ClassVar[int]
    RECOVERY_FIELD_NUMBER: _ClassVar[int]
    embodiment: EmbodimentRef
    recovery: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, embodiment: _Optional[_Union[EmbodimentRef, _Mapping]] = ..., recovery: _Optional[_Iterable[str]] = ...) -> None: ...

class CandidateUnavailable(_message.Message):
    __slots__ = ("task", "body_not_found", "invalid_capability_profile")
    TASK_FIELD_NUMBER: _ClassVar[int]
    BODY_NOT_FOUND_FIELD_NUMBER: _ClassVar[int]
    INVALID_CAPABILITY_PROFILE_FIELD_NUMBER: _ClassVar[int]
    task: _common_pb2.TaskContractRef
    body_not_found: CandidateBodyNotFound
    invalid_capability_profile: CandidateInvalidCapabilityProfile
    def __init__(self, task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., body_not_found: _Optional[_Union[CandidateBodyNotFound, _Mapping]] = ..., invalid_capability_profile: _Optional[_Union[CandidateInvalidCapabilityProfile, _Mapping]] = ...) -> None: ...

class CandidateAdmissibility(_message.Message):
    __slots__ = ("compatible", "shortfall", "unavailable")
    COMPATIBLE_FIELD_NUMBER: _ClassVar[int]
    SHORTFALL_FIELD_NUMBER: _ClassVar[int]
    UNAVAILABLE_FIELD_NUMBER: _ClassVar[int]
    compatible: CandidateCompatible
    shortfall: CandidateShortfall
    unavailable: CandidateUnavailable
    def __init__(self, compatible: _Optional[_Union[CandidateCompatible, _Mapping]] = ..., shortfall: _Optional[_Union[CandidateShortfall, _Mapping]] = ..., unavailable: _Optional[_Union[CandidateUnavailable, _Mapping]] = ...) -> None: ...

class BodyAdmissibility(_message.Message):
    __slots__ = ("embodiment", "assignments")
    EMBODIMENT_FIELD_NUMBER: _ClassVar[int]
    ASSIGNMENTS_FIELD_NUMBER: _ClassVar[int]
    embodiment: EmbodimentRef
    assignments: _containers.RepeatedCompositeFieldContainer[_capabilities_pb2.TaskRoleBinding]
    def __init__(self, embodiment: _Optional[_Union[EmbodimentRef, _Mapping]] = ..., assignments: _Optional[_Iterable[_Union[_capabilities_pb2.TaskRoleBinding, _Mapping]]] = ...) -> None: ...

class PartCandidate(_message.Message):
    __slots__ = ("part_id", "origin", "drivable", "provides")
    PART_ID_FIELD_NUMBER: _ClassVar[int]
    ORIGIN_FIELD_NUMBER: _ClassVar[int]
    DRIVABLE_FIELD_NUMBER: _ClassVar[int]
    PROVIDES_FIELD_NUMBER: _ClassVar[int]
    part_id: str
    origin: PartOrigin
    drivable: bool
    provides: _containers.RepeatedScalarFieldContainer[_capabilities_pb2.Capability]
    def __init__(self, part_id: _Optional[str] = ..., origin: _Optional[_Union[PartOrigin, str]] = ..., drivable: _Optional[bool] = ..., provides: _Optional[_Iterable[_Union[_capabilities_pb2.Capability, str]]] = ...) -> None: ...

class BodyShortfall(_message.Message):
    __slots__ = ("embodiment", "missing_roles", "missing_capabilities", "candidates", "candidates_considered")
    EMBODIMENT_FIELD_NUMBER: _ClassVar[int]
    MISSING_ROLES_FIELD_NUMBER: _ClassVar[int]
    MISSING_CAPABILITIES_FIELD_NUMBER: _ClassVar[int]
    CANDIDATES_FIELD_NUMBER: _ClassVar[int]
    CANDIDATES_CONSIDERED_FIELD_NUMBER: _ClassVar[int]
    embodiment: EmbodimentRef
    missing_roles: _containers.RepeatedScalarFieldContainer[str]
    missing_capabilities: _containers.RepeatedScalarFieldContainer[_capabilities_pb2.Capability]
    candidates: _containers.RepeatedCompositeFieldContainer[PartCandidate]
    candidates_considered: int
    def __init__(self, embodiment: _Optional[_Union[EmbodimentRef, _Mapping]] = ..., missing_roles: _Optional[_Iterable[str]] = ..., missing_capabilities: _Optional[_Iterable[_Union[_capabilities_pb2.Capability, str]]] = ..., candidates: _Optional[_Iterable[_Union[PartCandidate, _Mapping]]] = ..., candidates_considered: _Optional[int] = ...) -> None: ...

class TaskAdmissibilityRow(_message.Message):
    __slots__ = ("task", "family", "name", "bodies", "shortfalls", "goal", "success", "horizon", "operator", "stations", "evaluation")
    TASK_FIELD_NUMBER: _ClassVar[int]
    FAMILY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BODIES_FIELD_NUMBER: _ClassVar[int]
    SHORTFALLS_FIELD_NUMBER: _ClassVar[int]
    GOAL_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    HORIZON_FIELD_NUMBER: _ClassVar[int]
    OPERATOR_FIELD_NUMBER: _ClassVar[int]
    STATIONS_FIELD_NUMBER: _ClassVar[int]
    EVALUATION_FIELD_NUMBER: _ClassVar[int]
    task: _common_pb2.TaskContractRef
    family: str
    name: str
    bodies: _containers.RepeatedCompositeFieldContainer[BodyAdmissibility]
    shortfalls: _containers.RepeatedCompositeFieldContainer[BodyShortfall]
    goal: _tasks_pb2.TaskGoal
    success: str
    horizon: _tasks_pb2.TaskHorizon
    operator: _tasks_pb2.OperatorTier
    stations: _containers.RepeatedScalarFieldContainer[str]
    evaluation: _tasks_pb2.TaskEvaluationCriteria
    def __init__(self, task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., family: _Optional[str] = ..., name: _Optional[str] = ..., bodies: _Optional[_Iterable[_Union[BodyAdmissibility, _Mapping]]] = ..., shortfalls: _Optional[_Iterable[_Union[BodyShortfall, _Mapping]]] = ..., goal: _Optional[_Union[_tasks_pb2.TaskGoal, _Mapping]] = ..., success: _Optional[str] = ..., horizon: _Optional[_Union[_tasks_pb2.TaskHorizon, str]] = ..., operator: _Optional[_Union[_tasks_pb2.OperatorTier, str]] = ..., stations: _Optional[_Iterable[str]] = ..., evaluation: _Optional[_Union[_tasks_pb2.TaskEvaluationCriteria, _Mapping]] = ...) -> None: ...

class AdmissibilityScorecard(_message.Message):
    __slots__ = ("tasks", "unmatched_bodies")
    TASKS_FIELD_NUMBER: _ClassVar[int]
    UNMATCHED_BODIES_FIELD_NUMBER: _ClassVar[int]
    tasks: _containers.RepeatedCompositeFieldContainer[TaskAdmissibilityRow]
    unmatched_bodies: _containers.RepeatedCompositeFieldContainer[EmbodimentRef]
    def __init__(self, tasks: _Optional[_Iterable[_Union[TaskAdmissibilityRow, _Mapping]]] = ..., unmatched_bodies: _Optional[_Iterable[_Union[EmbodimentRef, _Mapping]]] = ...) -> None: ...

class EmbodimentReadiness(_message.Message):
    __slots__ = ("name", "embodiment_id", "episodes", "conformant_episodes", "episode_seconds", "family", "family_episodes", "action_interfaces", "conformant_scenes", "teleop_mounts")
    NAME_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    EPISODES_FIELD_NUMBER: _ClassVar[int]
    CONFORMANT_EPISODES_FIELD_NUMBER: _ClassVar[int]
    EPISODE_SECONDS_FIELD_NUMBER: _ClassVar[int]
    FAMILY_FIELD_NUMBER: _ClassVar[int]
    FAMILY_EPISODES_FIELD_NUMBER: _ClassVar[int]
    ACTION_INTERFACES_FIELD_NUMBER: _ClassVar[int]
    CONFORMANT_SCENES_FIELD_NUMBER: _ClassVar[int]
    TELEOP_MOUNTS_FIELD_NUMBER: _ClassVar[int]
    name: str
    embodiment_id: str
    episodes: int
    conformant_episodes: int
    episode_seconds: float
    family: str
    family_episodes: int
    action_interfaces: int
    conformant_scenes: int
    teleop_mounts: int
    def __init__(self, name: _Optional[str] = ..., embodiment_id: _Optional[str] = ..., episodes: _Optional[int] = ..., conformant_episodes: _Optional[int] = ..., episode_seconds: _Optional[float] = ..., family: _Optional[str] = ..., family_episodes: _Optional[int] = ..., action_interfaces: _Optional[int] = ..., conformant_scenes: _Optional[int] = ..., teleop_mounts: _Optional[int] = ...) -> None: ...

class FrontierCandidate(_message.Message):
    __slots__ = ("base", "added", "axes", "driven", "coverage", "admissible_tasks", "added_admitted", "frontier")
    BASE_FIELD_NUMBER: _ClassVar[int]
    ADDED_FIELD_NUMBER: _ClassVar[int]
    AXES_FIELD_NUMBER: _ClassVar[int]
    DRIVEN_FIELD_NUMBER: _ClassVar[int]
    COVERAGE_FIELD_NUMBER: _ClassVar[int]
    ADMISSIBLE_TASKS_FIELD_NUMBER: _ClassVar[int]
    ADDED_ADMITTED_FIELD_NUMBER: _ClassVar[int]
    FRONTIER_FIELD_NUMBER: _ClassVar[int]
    base: EmbodimentRef
    added: _containers.RepeatedScalarFieldContainer[str]
    axes: int
    driven: int
    coverage: int
    admissible_tasks: _containers.RepeatedCompositeFieldContainer[_common_pb2.TaskContractRef]
    added_admitted: int
    frontier: bool
    def __init__(self, base: _Optional[_Union[EmbodimentRef, _Mapping]] = ..., added: _Optional[_Iterable[str]] = ..., axes: _Optional[int] = ..., driven: _Optional[int] = ..., coverage: _Optional[int] = ..., admissible_tasks: _Optional[_Iterable[_Union[_common_pb2.TaskContractRef, _Mapping]]] = ..., added_admitted: _Optional[int] = ..., frontier: _Optional[bool] = ...) -> None: ...

class EmbodimentFrontier(_message.Message):
    __slots__ = ("evaluated", "refused", "eligible_parts", "candidates")
    EVALUATED_FIELD_NUMBER: _ClassVar[int]
    REFUSED_FIELD_NUMBER: _ClassVar[int]
    ELIGIBLE_PARTS_FIELD_NUMBER: _ClassVar[int]
    CANDIDATES_FIELD_NUMBER: _ClassVar[int]
    evaluated: int
    refused: int
    eligible_parts: _containers.RepeatedScalarFieldContainer[str]
    candidates: _containers.RepeatedCompositeFieldContainer[FrontierCandidate]
    def __init__(self, evaluated: _Optional[int] = ..., refused: _Optional[int] = ..., eligible_parts: _Optional[_Iterable[str]] = ..., candidates: _Optional[_Iterable[_Union[FrontierCandidate, _Mapping]]] = ...) -> None: ...

class DevelopmentEmbodiment(_message.Message):
    __slots__ = ("name", "label", "kind", "lineage", "ownership", "qualification", "qualification_reason")
    NAME_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    LINEAGE_FIELD_NUMBER: _ClassVar[int]
    OWNERSHIP_FIELD_NUMBER: _ClassVar[int]
    QUALIFICATION_FIELD_NUMBER: _ClassVar[int]
    QUALIFICATION_REASON_FIELD_NUMBER: _ClassVar[int]
    name: str
    label: str
    kind: EmbodimentKind
    lineage: Lineage
    ownership: EmbodimentOwnership
    qualification: EmbodimentQualification
    qualification_reason: DevelopmentQualificationReason
    def __init__(self, name: _Optional[str] = ..., label: _Optional[str] = ..., kind: _Optional[_Union[EmbodimentKind, str]] = ..., lineage: _Optional[_Union[Lineage, _Mapping]] = ..., ownership: _Optional[_Union[EmbodimentOwnership, str]] = ..., qualification: _Optional[_Union[EmbodimentQualification, str]] = ..., qualification_reason: _Optional[_Union[DevelopmentQualificationReason, str]] = ...) -> None: ...

class RegisterEmbodimentRequest(_message.Message):
    __slots__ = ("name", "embodiment")
    NAME_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_FIELD_NUMBER: _ClassVar[int]
    name: str
    embodiment: Embodiment
    def __init__(self, name: _Optional[str] = ..., embodiment: _Optional[_Union[Embodiment, _Mapping]] = ...) -> None: ...

class RegisterEmbodimentResponse(_message.Message):
    __slots__ = ("embodiment",)
    EMBODIMENT_FIELD_NUMBER: _ClassVar[int]
    embodiment: EmbodimentResource
    def __init__(self, embodiment: _Optional[_Union[EmbodimentResource, _Mapping]] = ...) -> None: ...

class ListComposablePartsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListComposablePartsResponse(_message.Message):
    __slots__ = ("parts",)
    PARTS_FIELD_NUMBER: _ClassVar[int]
    parts: _containers.RepeatedCompositeFieldContainer[ComposablePartResource]
    def __init__(self, parts: _Optional[_Iterable[_Union[ComposablePartResource, _Mapping]]] = ...) -> None: ...

class PreviewCandidateAdmissibilityRequest(_message.Message):
    __slots__ = ("task", "body_name")
    TASK_FIELD_NUMBER: _ClassVar[int]
    BODY_NAME_FIELD_NUMBER: _ClassVar[int]
    task: _tasks_pb2.TaskContract
    body_name: str
    def __init__(self, task: _Optional[_Union[_tasks_pb2.TaskContract, _Mapping]] = ..., body_name: _Optional[str] = ...) -> None: ...

class PreviewCandidateAdmissibilityResponse(_message.Message):
    __slots__ = ("admissibility",)
    ADMISSIBILITY_FIELD_NUMBER: _ClassVar[int]
    admissibility: CandidateAdmissibility
    def __init__(self, admissibility: _Optional[_Union[CandidateAdmissibility, _Mapping]] = ...) -> None: ...

class GetEmbodimentAdmissibilityRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetEmbodimentAdmissibilityResponse(_message.Message):
    __slots__ = ("scorecard",)
    SCORECARD_FIELD_NUMBER: _ClassVar[int]
    scorecard: AdmissibilityScorecard
    def __init__(self, scorecard: _Optional[_Union[AdmissibilityScorecard, _Mapping]] = ...) -> None: ...

class GetEmbodimentFrontierRequest(_message.Message):
    __slots__ = ("depth",)
    DEPTH_FIELD_NUMBER: _ClassVar[int]
    depth: int
    def __init__(self, depth: _Optional[int] = ...) -> None: ...

class GetEmbodimentFrontierResponse(_message.Message):
    __slots__ = ("frontier",)
    FRONTIER_FIELD_NUMBER: _ClassVar[int]
    frontier: EmbodimentFrontier
    def __init__(self, frontier: _Optional[_Union[EmbodimentFrontier, _Mapping]] = ...) -> None: ...

class GetEmbodimentReadinessRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetEmbodimentReadinessResponse(_message.Message):
    __slots__ = ("embodiments",)
    EMBODIMENTS_FIELD_NUMBER: _ClassVar[int]
    embodiments: _containers.RepeatedCompositeFieldContainer[EmbodimentReadiness]
    def __init__(self, embodiments: _Optional[_Iterable[_Union[EmbodimentReadiness, _Mapping]]] = ...) -> None: ...

class AdmitEmbodimentPartRequest(_message.Message):
    __slots__ = ("part", "urdf", "assets")
    PART_FIELD_NUMBER: _ClassVar[int]
    URDF_FIELD_NUMBER: _ClassVar[int]
    ASSETS_FIELD_NUMBER: _ClassVar[int]
    part: ComposablePart
    urdf: bytes
    assets: _containers.RepeatedCompositeFieldContainer[_assets_pb2.ProvenancedAsset]
    def __init__(self, part: _Optional[_Union[ComposablePart, _Mapping]] = ..., urdf: _Optional[bytes] = ..., assets: _Optional[_Iterable[_Union[_assets_pb2.ProvenancedAsset, _Mapping]]] = ...) -> None: ...

class AdmitEmbodimentPartResponse(_message.Message):
    __slots__ = ("part", "replayed")
    PART_FIELD_NUMBER: _ClassVar[int]
    REPLAYED_FIELD_NUMBER: _ClassVar[int]
    part: ComposablePartResource
    replayed: bool
    def __init__(self, part: _Optional[_Union[ComposablePartResource, _Mapping]] = ..., replayed: _Optional[bool] = ...) -> None: ...

class ValidateEmbodimentAssemblyRequest(_message.Message):
    __slots__ = ("definition", "urdf")
    DEFINITION_FIELD_NUMBER: _ClassVar[int]
    URDF_FIELD_NUMBER: _ClassVar[int]
    definition: AssemblyDefinition
    urdf: bytes
    def __init__(self, definition: _Optional[_Union[AssemblyDefinition, _Mapping]] = ..., urdf: _Optional[bytes] = ...) -> None: ...

class ValidateEmbodimentAssemblyResponse(_message.Message):
    __slots__ = ("embodiment", "admissible_tasks")
    EMBODIMENT_FIELD_NUMBER: _ClassVar[int]
    ADMISSIBLE_TASKS_FIELD_NUMBER: _ClassVar[int]
    embodiment: Embodiment
    admissible_tasks: _containers.RepeatedCompositeFieldContainer[TaskAdmissibility]
    def __init__(self, embodiment: _Optional[_Union[Embodiment, _Mapping]] = ..., admissible_tasks: _Optional[_Iterable[_Union[TaskAdmissibility, _Mapping]]] = ...) -> None: ...

class RegisterAssembledEmbodimentRequest(_message.Message):
    __slots__ = ("definition", "urdf")
    DEFINITION_FIELD_NUMBER: _ClassVar[int]
    URDF_FIELD_NUMBER: _ClassVar[int]
    definition: AssemblyDefinition
    urdf: bytes
    def __init__(self, definition: _Optional[_Union[AssemblyDefinition, _Mapping]] = ..., urdf: _Optional[bytes] = ...) -> None: ...

class RegisterAssembledEmbodimentResponse(_message.Message):
    __slots__ = ("embodiment", "admissible_tasks")
    EMBODIMENT_FIELD_NUMBER: _ClassVar[int]
    ADMISSIBLE_TASKS_FIELD_NUMBER: _ClassVar[int]
    embodiment: EmbodimentResource
    admissible_tasks: _containers.RepeatedCompositeFieldContainer[TaskAdmissibility]
    def __init__(self, embodiment: _Optional[_Union[EmbodimentResource, _Mapping]] = ..., admissible_tasks: _Optional[_Iterable[_Union[TaskAdmissibility, _Mapping]]] = ...) -> None: ...

class ListDevelopmentEmbodimentsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListDevelopmentEmbodimentsResponse(_message.Message):
    __slots__ = ("embodiments",)
    EMBODIMENTS_FIELD_NUMBER: _ClassVar[int]
    embodiments: _containers.RepeatedCompositeFieldContainer[DevelopmentEmbodiment]
    def __init__(self, embodiments: _Optional[_Iterable[_Union[DevelopmentEmbodiment, _Mapping]]] = ...) -> None: ...

class ListEmbodimentsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListEmbodimentsResponse(_message.Message):
    __slots__ = ("embodiments",)
    EMBODIMENTS_FIELD_NUMBER: _ClassVar[int]
    embodiments: _containers.RepeatedCompositeFieldContainer[EmbodimentResource]
    def __init__(self, embodiments: _Optional[_Iterable[_Union[EmbodimentResource, _Mapping]]] = ...) -> None: ...

class ResolveEmbodimentRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class ResolveEmbodimentResponse(_message.Message):
    __slots__ = ("embodiment",)
    EMBODIMENT_FIELD_NUMBER: _ClassVar[int]
    embodiment: EmbodimentResource
    def __init__(self, embodiment: _Optional[_Union[EmbodimentResource, _Mapping]] = ...) -> None: ...

class GetEmbodimentRequest(_message.Message):
    __slots__ = ("name",)
    NAME_FIELD_NUMBER: _ClassVar[int]
    name: str
    def __init__(self, name: _Optional[str] = ...) -> None: ...

class GetEmbodimentResponse(_message.Message):
    __slots__ = ("embodiment",)
    EMBODIMENT_FIELD_NUMBER: _ClassVar[int]
    embodiment: EmbodimentResource
    def __init__(self, embodiment: _Optional[_Union[EmbodimentResource, _Mapping]] = ...) -> None: ...

class TaskContractResource(_message.Message):
    __slots__ = ("contract", "created_at", "reference")
    CONTRACT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    REFERENCE_FIELD_NUMBER: _ClassVar[int]
    contract: _tasks_pb2.TaskContract
    created_at: _timestamp_pb2.Timestamp
    reference: _common_pb2.TaskContractRef
    def __init__(self, contract: _Optional[_Union[_tasks_pb2.TaskContract, _Mapping]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., reference: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ...) -> None: ...

class ProjectTaskAdmission(_message.Message):
    __slots__ = ("task", "admitted_by", "admitted_at", "predecessor_task_id", "source_draft_ref")
    TASK_FIELD_NUMBER: _ClassVar[int]
    ADMITTED_BY_FIELD_NUMBER: _ClassVar[int]
    ADMITTED_AT_FIELD_NUMBER: _ClassVar[int]
    PREDECESSOR_TASK_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_DRAFT_REF_FIELD_NUMBER: _ClassVar[int]
    task: _common_pb2.TaskContractRef
    admitted_by: str
    admitted_at: _timestamp_pb2.Timestamp
    predecessor_task_id: str
    source_draft_ref: str
    def __init__(self, task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., admitted_by: _Optional[str] = ..., admitted_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., predecessor_task_id: _Optional[str] = ..., source_draft_ref: _Optional[str] = ...) -> None: ...

class ProjectTaskResource(_message.Message):
    __slots__ = ("definition", "admission")
    DEFINITION_FIELD_NUMBER: _ClassVar[int]
    ADMISSION_FIELD_NUMBER: _ClassVar[int]
    definition: TaskContractResource
    admission: ProjectTaskAdmission
    def __init__(self, definition: _Optional[_Union[TaskContractResource, _Mapping]] = ..., admission: _Optional[_Union[ProjectTaskAdmission, _Mapping]] = ...) -> None: ...

class ListTaskLibraryRequest(_message.Message):
    __slots__ = ("after_task_id", "limit")
    AFTER_TASK_ID_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    after_task_id: str
    limit: int
    def __init__(self, after_task_id: _Optional[str] = ..., limit: _Optional[int] = ...) -> None: ...

class ListTaskLibraryResponse(_message.Message):
    __slots__ = ("tasks", "next_page_after", "request")
    TASKS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_AFTER_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    tasks: _containers.RepeatedCompositeFieldContainer[TaskContractResource]
    next_page_after: str
    request: ListTaskLibraryRequest
    def __init__(self, tasks: _Optional[_Iterable[_Union[TaskContractResource, _Mapping]]] = ..., next_page_after: _Optional[str] = ..., request: _Optional[_Union[ListTaskLibraryRequest, _Mapping]] = ...) -> None: ...

class GetLibraryTaskRequest(_message.Message):
    __slots__ = ("task_id",)
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    def __init__(self, task_id: _Optional[str] = ...) -> None: ...

class GetLibraryTaskResponse(_message.Message):
    __slots__ = ("task", "request")
    TASK_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    task: TaskContractResource
    request: GetLibraryTaskRequest
    def __init__(self, task: _Optional[_Union[TaskContractResource, _Mapping]] = ..., request: _Optional[_Union[GetLibraryTaskRequest, _Mapping]] = ...) -> None: ...

class PublishTaskRequest(_message.Message):
    __slots__ = ("contract",)
    CONTRACT_FIELD_NUMBER: _ClassVar[int]
    contract: _tasks_pb2.TaskContract
    def __init__(self, contract: _Optional[_Union[_tasks_pb2.TaskContract, _Mapping]] = ...) -> None: ...

class PublishTaskResponse(_message.Message):
    __slots__ = ("task", "request")
    TASK_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    task: ProjectTaskResource
    request: PublishTaskRequest
    def __init__(self, task: _Optional[_Union[ProjectTaskResource, _Mapping]] = ..., request: _Optional[_Union[PublishTaskRequest, _Mapping]] = ...) -> None: ...

class ListProjectTasksRequest(_message.Message):
    __slots__ = ("after_task_id", "limit")
    AFTER_TASK_ID_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    after_task_id: str
    limit: int
    def __init__(self, after_task_id: _Optional[str] = ..., limit: _Optional[int] = ...) -> None: ...

class ListProjectTasksResponse(_message.Message):
    __slots__ = ("tasks", "next_page_after", "request")
    TASKS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_AFTER_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    tasks: _containers.RepeatedCompositeFieldContainer[ProjectTaskResource]
    next_page_after: str
    request: ListProjectTasksRequest
    def __init__(self, tasks: _Optional[_Iterable[_Union[ProjectTaskResource, _Mapping]]] = ..., next_page_after: _Optional[str] = ..., request: _Optional[_Union[ListProjectTasksRequest, _Mapping]] = ...) -> None: ...

class GetProjectTaskRequest(_message.Message):
    __slots__ = ("task_id",)
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    def __init__(self, task_id: _Optional[str] = ...) -> None: ...

class GetProjectTaskResponse(_message.Message):
    __slots__ = ("task", "request")
    TASK_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    task: ProjectTaskResource
    request: GetProjectTaskRequest
    def __init__(self, task: _Optional[_Union[ProjectTaskResource, _Mapping]] = ..., request: _Optional[_Union[GetProjectTaskRequest, _Mapping]] = ...) -> None: ...

class AdmitProjectTaskRequest(_message.Message):
    __slots__ = ("task", "predecessor_task_id", "source_draft_ref")
    TASK_FIELD_NUMBER: _ClassVar[int]
    PREDECESSOR_TASK_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_DRAFT_REF_FIELD_NUMBER: _ClassVar[int]
    task: _common_pb2.TaskContractRef
    predecessor_task_id: str
    source_draft_ref: str
    def __init__(self, task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., predecessor_task_id: _Optional[str] = ..., source_draft_ref: _Optional[str] = ...) -> None: ...

class AdmitProjectTaskResponse(_message.Message):
    __slots__ = ("admission", "request")
    ADMISSION_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    admission: ProjectTaskAdmission
    request: AdmitProjectTaskRequest
    def __init__(self, admission: _Optional[_Union[ProjectTaskAdmission, _Mapping]] = ..., request: _Optional[_Union[AdmitProjectTaskRequest, _Mapping]] = ...) -> None: ...

class SemanticFilters(_message.Message):
    __slots__ = ("datasets", "dataset_kinds", "embodiment_id", "registered_after", "registered_before")
    DATASETS_FIELD_NUMBER: _ClassVar[int]
    DATASET_KINDS_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    REGISTERED_AFTER_FIELD_NUMBER: _ClassVar[int]
    REGISTERED_BEFORE_FIELD_NUMBER: _ClassVar[int]
    datasets: _containers.RepeatedScalarFieldContainer[str]
    dataset_kinds: _containers.RepeatedScalarFieldContainer[SemanticDatasetKind]
    embodiment_id: str
    registered_after: _timestamp_pb2.Timestamp
    registered_before: _timestamp_pb2.Timestamp
    def __init__(self, datasets: _Optional[_Iterable[str]] = ..., dataset_kinds: _Optional[_Iterable[_Union[SemanticDatasetKind, str]]] = ..., embodiment_id: _Optional[str] = ..., registered_after: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., registered_before: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class SemanticTextQuery(_message.Message):
    __slots__ = ("text",)
    TEXT_FIELD_NUMBER: _ClassVar[int]
    text: str
    def __init__(self, text: _Optional[str] = ...) -> None: ...

class SemanticFrameReference(_message.Message):
    __slots__ = ("dataset", "segment_id", "entity_path", "time_ns")
    DATASET_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_PATH_FIELD_NUMBER: _ClassVar[int]
    TIME_NS_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    segment_id: str
    entity_path: str
    time_ns: int
    def __init__(self, dataset: _Optional[str] = ..., segment_id: _Optional[str] = ..., entity_path: _Optional[str] = ..., time_ns: _Optional[int] = ...) -> None: ...

class SemanticFrameQuery(_message.Message):
    __slots__ = ("text", "frame")
    TEXT_FIELD_NUMBER: _ClassVar[int]
    FRAME_FIELD_NUMBER: _ClassVar[int]
    text: SemanticTextQuery
    frame: SemanticFrameReference
    def __init__(self, text: _Optional[_Union[SemanticTextQuery, _Mapping]] = ..., frame: _Optional[_Union[SemanticFrameReference, _Mapping]] = ...) -> None: ...

class SearchFramesRequest(_message.Message):
    __slots__ = ("query", "filters", "limit")
    QUERY_FIELD_NUMBER: _ClassVar[int]
    FILTERS_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    query: SemanticFrameQuery
    filters: SemanticFilters
    limit: int
    def __init__(self, query: _Optional[_Union[SemanticFrameQuery, _Mapping]] = ..., filters: _Optional[_Union[SemanticFilters, _Mapping]] = ..., limit: _Optional[int] = ...) -> None: ...

class SearchClipsRequest(_message.Message):
    __slots__ = ("query", "filters", "limit")
    QUERY_FIELD_NUMBER: _ClassVar[int]
    FILTERS_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    query: SemanticTextQuery
    filters: SemanticFilters
    limit: int
    def __init__(self, query: _Optional[_Union[SemanticTextQuery, _Mapping]] = ..., filters: _Optional[_Union[SemanticFilters, _Mapping]] = ..., limit: _Optional[int] = ...) -> None: ...

class SearchTextRequest(_message.Message):
    __slots__ = ("query", "filters", "limit")
    QUERY_FIELD_NUMBER: _ClassVar[int]
    FILTERS_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    query: SemanticTextQuery
    filters: SemanticFilters
    limit: int
    def __init__(self, query: _Optional[_Union[SemanticTextQuery, _Mapping]] = ..., filters: _Optional[_Union[SemanticFilters, _Mapping]] = ..., limit: _Optional[int] = ...) -> None: ...

class SearchSegmentsRequest(_message.Message):
    __slots__ = ("query", "filters", "limit")
    QUERY_FIELD_NUMBER: _ClassVar[int]
    FILTERS_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    query: SemanticTextQuery
    filters: SemanticFilters
    limit: int
    def __init__(self, query: _Optional[_Union[SemanticTextQuery, _Mapping]] = ..., filters: _Optional[_Union[SemanticFilters, _Mapping]] = ..., limit: _Optional[int] = ...) -> None: ...

class SemanticCoverage(_message.Message):
    __slots__ = ("indexed_segments", "embedder_version")
    INDEXED_SEGMENTS_FIELD_NUMBER: _ClassVar[int]
    EMBEDDER_VERSION_FIELD_NUMBER: _ClassVar[int]
    indexed_segments: int
    embedder_version: int
    def __init__(self, indexed_segments: _Optional[int] = ..., embedder_version: _Optional[int] = ...) -> None: ...

class SemanticDetection(_message.Message):
    __slots__ = ("label", "x_min", "y_min", "x_max", "y_max", "confidence")
    LABEL_FIELD_NUMBER: _ClassVar[int]
    X_MIN_FIELD_NUMBER: _ClassVar[int]
    Y_MIN_FIELD_NUMBER: _ClassVar[int]
    X_MAX_FIELD_NUMBER: _ClassVar[int]
    Y_MAX_FIELD_NUMBER: _ClassVar[int]
    CONFIDENCE_FIELD_NUMBER: _ClassVar[int]
    label: str
    x_min: float
    y_min: float
    x_max: float
    y_max: float
    confidence: float
    def __init__(self, label: _Optional[str] = ..., x_min: _Optional[float] = ..., y_min: _Optional[float] = ..., x_max: _Optional[float] = ..., y_max: _Optional[float] = ..., confidence: _Optional[float] = ...) -> None: ...

class SemanticFrameHit(_message.Message):
    __slots__ = ("dataset", "segment_id", "entity_path", "time_ns", "score", "anchor", "detections", "thumbnail_url", "viewer_url")
    DATASET_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_PATH_FIELD_NUMBER: _ClassVar[int]
    TIME_NS_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    ANCHOR_FIELD_NUMBER: _ClassVar[int]
    DETECTIONS_FIELD_NUMBER: _ClassVar[int]
    THUMBNAIL_URL_FIELD_NUMBER: _ClassVar[int]
    VIEWER_URL_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    segment_id: str
    entity_path: str
    time_ns: int
    score: float
    anchor: SemanticFrameAnchor
    detections: _containers.RepeatedCompositeFieldContainer[SemanticDetection]
    thumbnail_url: str
    viewer_url: str
    def __init__(self, dataset: _Optional[str] = ..., segment_id: _Optional[str] = ..., entity_path: _Optional[str] = ..., time_ns: _Optional[int] = ..., score: _Optional[float] = ..., anchor: _Optional[_Union[SemanticFrameAnchor, str]] = ..., detections: _Optional[_Iterable[_Union[SemanticDetection, _Mapping]]] = ..., thumbnail_url: _Optional[str] = ..., viewer_url: _Optional[str] = ...) -> None: ...

class SearchFramesResponse(_message.Message):
    __slots__ = ("hits", "coverage", "expires_in_seconds", "request")
    HITS_FIELD_NUMBER: _ClassVar[int]
    COVERAGE_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_IN_SECONDS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    hits: _containers.RepeatedCompositeFieldContainer[SemanticFrameHit]
    coverage: SemanticCoverage
    expires_in_seconds: int
    request: SearchFramesRequest
    def __init__(self, hits: _Optional[_Iterable[_Union[SemanticFrameHit, _Mapping]]] = ..., coverage: _Optional[_Union[SemanticCoverage, _Mapping]] = ..., expires_in_seconds: _Optional[int] = ..., request: _Optional[_Union[SearchFramesRequest, _Mapping]] = ...) -> None: ...

class SemanticClipHit(_message.Message):
    __slots__ = ("dataset", "segment_id", "start_time_ns", "end_time_ns", "phase", "phase_source", "score", "viewer_url")
    DATASET_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_ID_FIELD_NUMBER: _ClassVar[int]
    START_TIME_NS_FIELD_NUMBER: _ClassVar[int]
    END_TIME_NS_FIELD_NUMBER: _ClassVar[int]
    PHASE_FIELD_NUMBER: _ClassVar[int]
    PHASE_SOURCE_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    VIEWER_URL_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    segment_id: str
    start_time_ns: int
    end_time_ns: int
    phase: str
    phase_source: SemanticPhaseSource
    score: float
    viewer_url: str
    def __init__(self, dataset: _Optional[str] = ..., segment_id: _Optional[str] = ..., start_time_ns: _Optional[int] = ..., end_time_ns: _Optional[int] = ..., phase: _Optional[str] = ..., phase_source: _Optional[_Union[SemanticPhaseSource, str]] = ..., score: _Optional[float] = ..., viewer_url: _Optional[str] = ...) -> None: ...

class SearchClipsResponse(_message.Message):
    __slots__ = ("hits", "coverage", "request")
    HITS_FIELD_NUMBER: _ClassVar[int]
    COVERAGE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    hits: _containers.RepeatedCompositeFieldContainer[SemanticClipHit]
    coverage: SemanticCoverage
    request: SearchClipsRequest
    def __init__(self, hits: _Optional[_Iterable[_Union[SemanticClipHit, _Mapping]]] = ..., coverage: _Optional[_Union[SemanticCoverage, _Mapping]] = ..., request: _Optional[_Union[SearchClipsRequest, _Mapping]] = ...) -> None: ...

class SemanticTextHit(_message.Message):
    __slots__ = ("dataset", "segment_id", "source_kind", "source_ref", "text", "score")
    DATASET_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_KIND_FIELD_NUMBER: _ClassVar[int]
    SOURCE_REF_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    segment_id: str
    source_kind: SemanticTextSourceKind
    source_ref: str
    text: str
    score: float
    def __init__(self, dataset: _Optional[str] = ..., segment_id: _Optional[str] = ..., source_kind: _Optional[_Union[SemanticTextSourceKind, str]] = ..., source_ref: _Optional[str] = ..., text: _Optional[str] = ..., score: _Optional[float] = ...) -> None: ...

class SearchTextResponse(_message.Message):
    __slots__ = ("hits", "coverage", "request")
    HITS_FIELD_NUMBER: _ClassVar[int]
    COVERAGE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    hits: _containers.RepeatedCompositeFieldContainer[SemanticTextHit]
    coverage: SemanticCoverage
    request: SearchTextRequest
    def __init__(self, hits: _Optional[_Iterable[_Union[SemanticTextHit, _Mapping]]] = ..., coverage: _Optional[_Union[SemanticCoverage, _Mapping]] = ..., request: _Optional[_Union[SearchTextRequest, _Mapping]] = ...) -> None: ...

class SemanticSegmentHit(_message.Message):
    __slots__ = ("dataset", "segment_id", "task_ref", "duration_seconds", "frame_count", "score", "viewer_url")
    DATASET_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_REF_FIELD_NUMBER: _ClassVar[int]
    DURATION_SECONDS_FIELD_NUMBER: _ClassVar[int]
    FRAME_COUNT_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    VIEWER_URL_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    segment_id: str
    task_ref: str
    duration_seconds: float
    frame_count: int
    score: float
    viewer_url: str
    def __init__(self, dataset: _Optional[str] = ..., segment_id: _Optional[str] = ..., task_ref: _Optional[str] = ..., duration_seconds: _Optional[float] = ..., frame_count: _Optional[int] = ..., score: _Optional[float] = ..., viewer_url: _Optional[str] = ...) -> None: ...

class SearchSegmentsResponse(_message.Message):
    __slots__ = ("hits", "coverage", "request")
    HITS_FIELD_NUMBER: _ClassVar[int]
    COVERAGE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    hits: _containers.RepeatedCompositeFieldContainer[SemanticSegmentHit]
    coverage: SemanticCoverage
    request: SearchSegmentsRequest
    def __init__(self, hits: _Optional[_Iterable[_Union[SemanticSegmentHit, _Mapping]]] = ..., coverage: _Optional[_Union[SemanticCoverage, _Mapping]] = ..., request: _Optional[_Union[SearchSegmentsRequest, _Mapping]] = ...) -> None: ...

class GetTaskMapRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class TaskMapClusterTask(_message.Message):
    __slots__ = ("task_ref", "episodes")
    TASK_REF_FIELD_NUMBER: _ClassVar[int]
    EPISODES_FIELD_NUMBER: _ClassVar[int]
    task_ref: str
    episodes: int
    def __init__(self, task_ref: _Optional[str] = ..., episodes: _Optional[int] = ...) -> None: ...

class TaskMapCluster(_message.Message):
    __slots__ = ("cluster_id", "episodes", "mean_distance", "tasks")
    CLUSTER_ID_FIELD_NUMBER: _ClassVar[int]
    EPISODES_FIELD_NUMBER: _ClassVar[int]
    MEAN_DISTANCE_FIELD_NUMBER: _ClassVar[int]
    TASKS_FIELD_NUMBER: _ClassVar[int]
    cluster_id: int
    episodes: int
    mean_distance: float
    tasks: _containers.RepeatedCompositeFieldContainer[TaskMapClusterTask]
    def __init__(self, cluster_id: _Optional[int] = ..., episodes: _Optional[int] = ..., mean_distance: _Optional[float] = ..., tasks: _Optional[_Iterable[_Union[TaskMapClusterTask, _Mapping]]] = ...) -> None: ...

class TaskMapContract(_message.Message):
    __slots__ = ("task_ref", "episodes")
    TASK_REF_FIELD_NUMBER: _ClassVar[int]
    EPISODES_FIELD_NUMBER: _ClassVar[int]
    task_ref: str
    episodes: int
    def __init__(self, task_ref: _Optional[str] = ..., episodes: _Optional[int] = ...) -> None: ...

class TaskMapGaps(_message.Message):
    __slots__ = ("uncovered_contracts", "unnamed_clusters")
    UNCOVERED_CONTRACTS_FIELD_NUMBER: _ClassVar[int]
    UNNAMED_CLUSTERS_FIELD_NUMBER: _ClassVar[int]
    uncovered_contracts: _containers.RepeatedScalarFieldContainer[str]
    unnamed_clusters: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, uncovered_contracts: _Optional[_Iterable[str]] = ..., unnamed_clusters: _Optional[_Iterable[int]] = ...) -> None: ...

class GetTaskMapResponse(_message.Message):
    __slots__ = ("clusters", "contracts", "gaps", "coverage", "request")
    CLUSTERS_FIELD_NUMBER: _ClassVar[int]
    CONTRACTS_FIELD_NUMBER: _ClassVar[int]
    GAPS_FIELD_NUMBER: _ClassVar[int]
    COVERAGE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    clusters: _containers.RepeatedCompositeFieldContainer[TaskMapCluster]
    contracts: _containers.RepeatedCompositeFieldContainer[TaskMapContract]
    gaps: TaskMapGaps
    coverage: SemanticCoverage
    request: GetTaskMapRequest
    def __init__(self, clusters: _Optional[_Iterable[_Union[TaskMapCluster, _Mapping]]] = ..., contracts: _Optional[_Iterable[_Union[TaskMapContract, _Mapping]]] = ..., gaps: _Optional[_Union[TaskMapGaps, _Mapping]] = ..., coverage: _Optional[_Union[SemanticCoverage, _Mapping]] = ..., request: _Optional[_Union[GetTaskMapRequest, _Mapping]] = ...) -> None: ...

class GetSemanticAtlasRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SemanticAtlasDataset(_message.Message):
    __slots__ = ("dataset", "viewer_url")
    DATASET_FIELD_NUMBER: _ClassVar[int]
    VIEWER_URL_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    viewer_url: str
    def __init__(self, dataset: _Optional[str] = ..., viewer_url: _Optional[str] = ...) -> None: ...

class SemanticAtlasSubcluster(_message.Message):
    __slots__ = ("subcluster_id", "points", "x", "y", "radius", "topics")
    SUBCLUSTER_ID_FIELD_NUMBER: _ClassVar[int]
    POINTS_FIELD_NUMBER: _ClassVar[int]
    X_FIELD_NUMBER: _ClassVar[int]
    Y_FIELD_NUMBER: _ClassVar[int]
    RADIUS_FIELD_NUMBER: _ClassVar[int]
    TOPICS_FIELD_NUMBER: _ClassVar[int]
    subcluster_id: int
    points: int
    x: float
    y: float
    radius: float
    topics: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, subcluster_id: _Optional[int] = ..., points: _Optional[int] = ..., x: _Optional[float] = ..., y: _Optional[float] = ..., radius: _Optional[float] = ..., topics: _Optional[_Iterable[str]] = ...) -> None: ...

class SemanticAtlasCluster(_message.Message):
    __slots__ = ("cluster_id", "points", "episodes", "x", "y", "radius", "topics", "exemplar_thumbnails", "subclusters")
    CLUSTER_ID_FIELD_NUMBER: _ClassVar[int]
    POINTS_FIELD_NUMBER: _ClassVar[int]
    EPISODES_FIELD_NUMBER: _ClassVar[int]
    X_FIELD_NUMBER: _ClassVar[int]
    Y_FIELD_NUMBER: _ClassVar[int]
    RADIUS_FIELD_NUMBER: _ClassVar[int]
    TOPICS_FIELD_NUMBER: _ClassVar[int]
    EXEMPLAR_THUMBNAILS_FIELD_NUMBER: _ClassVar[int]
    SUBCLUSTERS_FIELD_NUMBER: _ClassVar[int]
    cluster_id: int
    points: int
    episodes: int
    x: float
    y: float
    radius: float
    topics: _containers.RepeatedScalarFieldContainer[str]
    exemplar_thumbnails: _containers.RepeatedScalarFieldContainer[str]
    subclusters: _containers.RepeatedCompositeFieldContainer[SemanticAtlasSubcluster]
    def __init__(self, cluster_id: _Optional[int] = ..., points: _Optional[int] = ..., episodes: _Optional[int] = ..., x: _Optional[float] = ..., y: _Optional[float] = ..., radius: _Optional[float] = ..., topics: _Optional[_Iterable[str]] = ..., exemplar_thumbnails: _Optional[_Iterable[str]] = ..., subclusters: _Optional[_Iterable[_Union[SemanticAtlasSubcluster, _Mapping]]] = ...) -> None: ...

class GetSemanticAtlasResponse(_message.Message):
    __slots__ = ("clusters", "total_points", "placed_points", "total_frames", "datasets", "coverage", "request")
    CLUSTERS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_POINTS_FIELD_NUMBER: _ClassVar[int]
    PLACED_POINTS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_FRAMES_FIELD_NUMBER: _ClassVar[int]
    DATASETS_FIELD_NUMBER: _ClassVar[int]
    COVERAGE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    clusters: _containers.RepeatedCompositeFieldContainer[SemanticAtlasCluster]
    total_points: int
    placed_points: int
    total_frames: int
    datasets: _containers.RepeatedCompositeFieldContainer[SemanticAtlasDataset]
    coverage: SemanticCoverage
    request: GetSemanticAtlasRequest
    def __init__(self, clusters: _Optional[_Iterable[_Union[SemanticAtlasCluster, _Mapping]]] = ..., total_points: _Optional[int] = ..., placed_points: _Optional[int] = ..., total_frames: _Optional[int] = ..., datasets: _Optional[_Iterable[_Union[SemanticAtlasDataset, _Mapping]]] = ..., coverage: _Optional[_Union[SemanticCoverage, _Mapping]] = ..., request: _Optional[_Union[GetSemanticAtlasRequest, _Mapping]] = ...) -> None: ...

class ListSemanticAtlasPointsRequest(_message.Message):
    __slots__ = ("cluster_id", "offset", "limit")
    CLUSTER_ID_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    cluster_id: int
    offset: int
    limit: int
    def __init__(self, cluster_id: _Optional[int] = ..., offset: _Optional[int] = ..., limit: _Optional[int] = ...) -> None: ...

class SemanticAtlasPoint(_message.Message):
    __slots__ = ("kind", "x", "y", "cluster_id", "subcluster_id", "dataset", "segment_id", "entity_path", "time_ns", "anchor", "thumbnail_sha256", "task_ref", "terms")
    KIND_FIELD_NUMBER: _ClassVar[int]
    X_FIELD_NUMBER: _ClassVar[int]
    Y_FIELD_NUMBER: _ClassVar[int]
    CLUSTER_ID_FIELD_NUMBER: _ClassVar[int]
    SUBCLUSTER_ID_FIELD_NUMBER: _ClassVar[int]
    DATASET_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_PATH_FIELD_NUMBER: _ClassVar[int]
    TIME_NS_FIELD_NUMBER: _ClassVar[int]
    ANCHOR_FIELD_NUMBER: _ClassVar[int]
    THUMBNAIL_SHA256_FIELD_NUMBER: _ClassVar[int]
    TASK_REF_FIELD_NUMBER: _ClassVar[int]
    TERMS_FIELD_NUMBER: _ClassVar[int]
    kind: SemanticAtlasPointKind
    x: float
    y: float
    cluster_id: int
    subcluster_id: int
    dataset: str
    segment_id: str
    entity_path: str
    time_ns: int
    anchor: SemanticFrameAnchor
    thumbnail_sha256: str
    task_ref: str
    terms: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, kind: _Optional[_Union[SemanticAtlasPointKind, str]] = ..., x: _Optional[float] = ..., y: _Optional[float] = ..., cluster_id: _Optional[int] = ..., subcluster_id: _Optional[int] = ..., dataset: _Optional[str] = ..., segment_id: _Optional[str] = ..., entity_path: _Optional[str] = ..., time_ns: _Optional[int] = ..., anchor: _Optional[_Union[SemanticFrameAnchor, str]] = ..., thumbnail_sha256: _Optional[str] = ..., task_ref: _Optional[str] = ..., terms: _Optional[_Iterable[str]] = ...) -> None: ...

class ListSemanticAtlasPointsResponse(_message.Message):
    __slots__ = ("cluster_id", "points", "total", "offset", "request")
    CLUSTER_ID_FIELD_NUMBER: _ClassVar[int]
    POINTS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    cluster_id: int
    points: _containers.RepeatedCompositeFieldContainer[SemanticAtlasPoint]
    total: int
    offset: int
    request: ListSemanticAtlasPointsRequest
    def __init__(self, cluster_id: _Optional[int] = ..., points: _Optional[_Iterable[_Union[SemanticAtlasPoint, _Mapping]]] = ..., total: _Optional[int] = ..., offset: _Optional[int] = ..., request: _Optional[_Union[ListSemanticAtlasPointsRequest, _Mapping]] = ...) -> None: ...
