import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from sentientx.sx.operations.v1 import operations_pb2 as _operations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class DeliveredArtifact(_message.Message):
    __slots__ = ("member_id", "key", "sha256", "size_bytes", "source_sha256")
    MEMBER_ID_FIELD_NUMBER: _ClassVar[int]
    KEY_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    SOURCE_SHA256_FIELD_NUMBER: _ClassVar[int]
    member_id: str
    key: str
    sha256: str
    size_bytes: int
    source_sha256: str
    def __init__(self, member_id: _Optional[str] = ..., key: _Optional[str] = ..., sha256: _Optional[str] = ..., size_bytes: _Optional[int] = ..., source_sha256: _Optional[str] = ...) -> None: ...

class LeasedMember(_message.Message):
    __slots__ = ("member_id", "sha256", "size_bytes", "source_url", "key", "upload_url")
    MEMBER_ID_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    SOURCE_URL_FIELD_NUMBER: _ClassVar[int]
    KEY_FIELD_NUMBER: _ClassVar[int]
    UPLOAD_URL_FIELD_NUMBER: _ClassVar[int]
    member_id: str
    sha256: str
    size_bytes: int
    source_url: str
    key: str
    upload_url: str
    def __init__(self, member_id: _Optional[str] = ..., sha256: _Optional[str] = ..., size_bytes: _Optional[int] = ..., source_url: _Optional[str] = ..., key: _Optional[str] = ..., upload_url: _Optional[str] = ...) -> None: ...

class DeliveryLease(_message.Message):
    __slots__ = ("delivery_id", "project_id", "delivery_digest", "lineage_digest", "profile", "accepts", "produces", "members", "delivered", "report_key", "report_url", "expires_at", "executor_id", "generation")
    DELIVERY_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    DELIVERY_DIGEST_FIELD_NUMBER: _ClassVar[int]
    LINEAGE_DIGEST_FIELD_NUMBER: _ClassVar[int]
    PROFILE_FIELD_NUMBER: _ClassVar[int]
    ACCEPTS_FIELD_NUMBER: _ClassVar[int]
    PRODUCES_FIELD_NUMBER: _ClassVar[int]
    MEMBERS_FIELD_NUMBER: _ClassVar[int]
    DELIVERED_FIELD_NUMBER: _ClassVar[int]
    REPORT_KEY_FIELD_NUMBER: _ClassVar[int]
    REPORT_URL_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    EXECUTOR_ID_FIELD_NUMBER: _ClassVar[int]
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    delivery_id: str
    project_id: str
    delivery_digest: str
    lineage_digest: str
    profile: str
    accepts: str
    produces: str
    members: _containers.RepeatedCompositeFieldContainer[LeasedMember]
    delivered: _containers.RepeatedCompositeFieldContainer[DeliveredArtifact]
    report_key: str
    report_url: str
    expires_at: _timestamp_pb2.Timestamp
    executor_id: str
    generation: int
    def __init__(self, delivery_id: _Optional[str] = ..., project_id: _Optional[str] = ..., delivery_digest: _Optional[str] = ..., lineage_digest: _Optional[str] = ..., profile: _Optional[str] = ..., accepts: _Optional[str] = ..., produces: _Optional[str] = ..., members: _Optional[_Iterable[_Union[LeasedMember, _Mapping]]] = ..., delivered: _Optional[_Iterable[_Union[DeliveredArtifact, _Mapping]]] = ..., report_key: _Optional[str] = ..., report_url: _Optional[str] = ..., expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., executor_id: _Optional[str] = ..., generation: _Optional[int] = ...) -> None: ...

class DeliveryProgress(_message.Message):
    __slots__ = ("artifacts",)
    ARTIFACTS_FIELD_NUMBER: _ClassVar[int]
    artifacts: _containers.RepeatedCompositeFieldContainer[DeliveredArtifact]
    def __init__(self, artifacts: _Optional[_Iterable[_Union[DeliveredArtifact, _Mapping]]] = ...) -> None: ...

class DeliveryComplete(_message.Message):
    __slots__ = ("artifacts",)
    ARTIFACTS_FIELD_NUMBER: _ClassVar[int]
    artifacts: _containers.RepeatedCompositeFieldContainer[DeliveredArtifact]
    def __init__(self, artifacts: _Optional[_Iterable[_Union[DeliveredArtifact, _Mapping]]] = ...) -> None: ...

class DeliveryFailed(_message.Message):
    __slots__ = ("failure", "artifacts")
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    ARTIFACTS_FIELD_NUMBER: _ClassVar[int]
    failure: _operations_pb2.OperationFailure
    artifacts: _containers.RepeatedCompositeFieldContainer[DeliveredArtifact]
    def __init__(self, failure: _Optional[_Union[_operations_pb2.OperationFailure, _Mapping]] = ..., artifacts: _Optional[_Iterable[_Union[DeliveredArtifact, _Mapping]]] = ...) -> None: ...

class DeliveryCancelled(_message.Message):
    __slots__ = ("reason", "artifacts")
    REASON_FIELD_NUMBER: _ClassVar[int]
    ARTIFACTS_FIELD_NUMBER: _ClassVar[int]
    reason: str
    artifacts: _containers.RepeatedCompositeFieldContainer[DeliveredArtifact]
    def __init__(self, reason: _Optional[str] = ..., artifacts: _Optional[_Iterable[_Union[DeliveredArtifact, _Mapping]]] = ...) -> None: ...

class DeliveryReport(_message.Message):
    __slots__ = ("progress", "complete", "failed", "cancelled")
    PROGRESS_FIELD_NUMBER: _ClassVar[int]
    COMPLETE_FIELD_NUMBER: _ClassVar[int]
    FAILED_FIELD_NUMBER: _ClassVar[int]
    CANCELLED_FIELD_NUMBER: _ClassVar[int]
    progress: DeliveryProgress
    complete: DeliveryComplete
    failed: DeliveryFailed
    cancelled: DeliveryCancelled
    def __init__(self, progress: _Optional[_Union[DeliveryProgress, _Mapping]] = ..., complete: _Optional[_Union[DeliveryComplete, _Mapping]] = ..., failed: _Optional[_Union[DeliveryFailed, _Mapping]] = ..., cancelled: _Optional[_Union[DeliveryCancelled, _Mapping]] = ...) -> None: ...

class ClaimDeliveryRequest(_message.Message):
    __slots__ = ("delivery_id", "executor_id")
    DELIVERY_ID_FIELD_NUMBER: _ClassVar[int]
    EXECUTOR_ID_FIELD_NUMBER: _ClassVar[int]
    delivery_id: str
    executor_id: str
    def __init__(self, delivery_id: _Optional[str] = ..., executor_id: _Optional[str] = ...) -> None: ...

class ClaimDeliveryResponse(_message.Message):
    __slots__ = ("lease", "request")
    LEASE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    lease: DeliveryLease
    request: ClaimDeliveryRequest
    def __init__(self, lease: _Optional[_Union[DeliveryLease, _Mapping]] = ..., request: _Optional[_Union[ClaimDeliveryRequest, _Mapping]] = ...) -> None: ...

class ReportDeliveryRequest(_message.Message):
    __slots__ = ("delivery_id", "report", "executor_id", "generation")
    DELIVERY_ID_FIELD_NUMBER: _ClassVar[int]
    REPORT_FIELD_NUMBER: _ClassVar[int]
    EXECUTOR_ID_FIELD_NUMBER: _ClassVar[int]
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    delivery_id: str
    report: DeliveryReport
    executor_id: str
    generation: int
    def __init__(self, delivery_id: _Optional[str] = ..., report: _Optional[_Union[DeliveryReport, _Mapping]] = ..., executor_id: _Optional[str] = ..., generation: _Optional[int] = ...) -> None: ...

class ReportDeliveryResponse(_message.Message):
    __slots__ = ("lifecycle", "request")
    LIFECYCLE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    lifecycle: _operations_pb2.OperationLifecycle
    request: ReportDeliveryRequest
    def __init__(self, lifecycle: _Optional[_Union[_operations_pb2.OperationLifecycle, _Mapping]] = ..., request: _Optional[_Union[ReportDeliveryRequest, _Mapping]] = ...) -> None: ...
