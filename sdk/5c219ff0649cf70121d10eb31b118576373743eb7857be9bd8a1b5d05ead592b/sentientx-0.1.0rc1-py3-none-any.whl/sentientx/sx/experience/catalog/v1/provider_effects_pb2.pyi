import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from sentientx.sx.operations.v1 import operations_pb2 as _operations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ProviderEffectClass(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PROVIDER_EFFECT_CLASS_UNSPECIFIED: _ClassVar[ProviderEffectClass]
    PROVIDER_EFFECT_CLASS_READ_ONLY: _ClassVar[ProviderEffectClass]
    PROVIDER_EFFECT_CLASS_PROVIDER_IDEMPOTENT_MUTATION: _ClassVar[ProviderEffectClass]
    PROVIDER_EFFECT_CLASS_RECONCILED_MUTATION: _ClassVar[ProviderEffectClass]

class ProviderUsageUnit(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PROVIDER_USAGE_UNIT_UNSPECIFIED: _ClassVar[ProviderUsageUnit]
    PROVIDER_USAGE_UNIT_REQUESTS: _ClassVar[ProviderUsageUnit]
    PROVIDER_USAGE_UNIT_INPUT_TOKENS: _ClassVar[ProviderUsageUnit]
    PROVIDER_USAGE_UNIT_OUTPUT_TOKENS: _ClassVar[ProviderUsageUnit]
    PROVIDER_USAGE_UNIT_CACHED_INPUT_TOKENS: _ClassVar[ProviderUsageUnit]

class ProviderEffectRecovery(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PROVIDER_EFFECT_RECOVERY_UNSPECIFIED: _ClassVar[ProviderEffectRecovery]
    PROVIDER_EFFECT_RECOVERY_REPLAY_UNDER_KEY: _ClassVar[ProviderEffectRecovery]
    PROVIDER_EFFECT_RECOVERY_PROVIDER_QUERY: _ClassVar[ProviderEffectRecovery]
    PROVIDER_EFFECT_RECOVERY_UNRECONCILABLE: _ClassVar[ProviderEffectRecovery]
PROVIDER_EFFECT_CLASS_UNSPECIFIED: ProviderEffectClass
PROVIDER_EFFECT_CLASS_READ_ONLY: ProviderEffectClass
PROVIDER_EFFECT_CLASS_PROVIDER_IDEMPOTENT_MUTATION: ProviderEffectClass
PROVIDER_EFFECT_CLASS_RECONCILED_MUTATION: ProviderEffectClass
PROVIDER_USAGE_UNIT_UNSPECIFIED: ProviderUsageUnit
PROVIDER_USAGE_UNIT_REQUESTS: ProviderUsageUnit
PROVIDER_USAGE_UNIT_INPUT_TOKENS: ProviderUsageUnit
PROVIDER_USAGE_UNIT_OUTPUT_TOKENS: ProviderUsageUnit
PROVIDER_USAGE_UNIT_CACHED_INPUT_TOKENS: ProviderUsageUnit
PROVIDER_EFFECT_RECOVERY_UNSPECIFIED: ProviderEffectRecovery
PROVIDER_EFFECT_RECOVERY_REPLAY_UNDER_KEY: ProviderEffectRecovery
PROVIDER_EFFECT_RECOVERY_PROVIDER_QUERY: ProviderEffectRecovery
PROVIDER_EFFECT_RECOVERY_UNRECONCILABLE: ProviderEffectRecovery

class ProviderUsageFact(_message.Message):
    __slots__ = ("unit", "quantity")
    UNIT_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    unit: ProviderUsageUnit
    quantity: int
    def __init__(self, unit: _Optional[_Union[ProviderUsageUnit, str]] = ..., quantity: _Optional[int] = ...) -> None: ...

class ProviderEffectLeaseRequest(_message.Message):
    __slots__ = ("credential_slot", "operation", "call_budget_s", "idempotency_key", "effects")
    CREDENTIAL_SLOT_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    CALL_BUDGET_S_FIELD_NUMBER: _ClassVar[int]
    IDEMPOTENCY_KEY_FIELD_NUMBER: _ClassVar[int]
    EFFECTS_FIELD_NUMBER: _ClassVar[int]
    credential_slot: str
    operation: str
    call_budget_s: int
    idempotency_key: str
    effects: ProviderEffectClass
    def __init__(self, credential_slot: _Optional[str] = ..., operation: _Optional[str] = ..., call_budget_s: _Optional[int] = ..., idempotency_key: _Optional[str] = ..., effects: _Optional[_Union[ProviderEffectClass, str]] = ...) -> None: ...

class ProviderRateWindow(_message.Message):
    __slots__ = ("window_s", "granted", "limit")
    WINDOW_S_FIELD_NUMBER: _ClassVar[int]
    GRANTED_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    window_s: int
    granted: int
    limit: int
    def __init__(self, window_s: _Optional[int] = ..., granted: _Optional[int] = ..., limit: _Optional[int] = ...) -> None: ...

class ProviderEffectLease(_message.Message):
    __slots__ = ("effect_id", "provider", "credential_slot", "operation", "idempotency_key", "attempt", "window", "outstanding", "max_outstanding", "expires_at")
    EFFECT_ID_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    CREDENTIAL_SLOT_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    IDEMPOTENCY_KEY_FIELD_NUMBER: _ClassVar[int]
    ATTEMPT_FIELD_NUMBER: _ClassVar[int]
    WINDOW_FIELD_NUMBER: _ClassVar[int]
    OUTSTANDING_FIELD_NUMBER: _ClassVar[int]
    MAX_OUTSTANDING_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    effect_id: str
    provider: str
    credential_slot: str
    operation: str
    idempotency_key: str
    attempt: int
    window: ProviderRateWindow
    outstanding: int
    max_outstanding: int
    expires_at: _timestamp_pb2.Timestamp
    def __init__(self, effect_id: _Optional[str] = ..., provider: _Optional[str] = ..., credential_slot: _Optional[str] = ..., operation: _Optional[str] = ..., idempotency_key: _Optional[str] = ..., attempt: _Optional[int] = ..., window: _Optional[_Union[ProviderRateWindow, _Mapping]] = ..., outstanding: _Optional[int] = ..., max_outstanding: _Optional[int] = ..., expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ProviderEffectSucceeded(_message.Message):
    __slots__ = ("usage", "provider_response_id", "response_sha256")
    USAGE_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_RESPONSE_ID_FIELD_NUMBER: _ClassVar[int]
    RESPONSE_SHA256_FIELD_NUMBER: _ClassVar[int]
    usage: _containers.RepeatedCompositeFieldContainer[ProviderUsageFact]
    provider_response_id: str
    response_sha256: str
    def __init__(self, usage: _Optional[_Iterable[_Union[ProviderUsageFact, _Mapping]]] = ..., provider_response_id: _Optional[str] = ..., response_sha256: _Optional[str] = ...) -> None: ...

class ProviderEffectFailed(_message.Message):
    __slots__ = ("usage", "failure")
    USAGE_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    usage: _containers.RepeatedCompositeFieldContainer[ProviderUsageFact]
    failure: _operations_pb2.OperationFailure
    def __init__(self, usage: _Optional[_Iterable[_Union[ProviderUsageFact, _Mapping]]] = ..., failure: _Optional[_Union[_operations_pb2.OperationFailure, _Mapping]] = ...) -> None: ...

class ProviderEffectAmbiguous(_message.Message):
    __slots__ = ("usage", "failure", "recovery", "provider_handle")
    USAGE_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    RECOVERY_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_HANDLE_FIELD_NUMBER: _ClassVar[int]
    usage: _containers.RepeatedCompositeFieldContainer[ProviderUsageFact]
    failure: _operations_pb2.OperationFailure
    recovery: ProviderEffectRecovery
    provider_handle: str
    def __init__(self, usage: _Optional[_Iterable[_Union[ProviderUsageFact, _Mapping]]] = ..., failure: _Optional[_Union[_operations_pb2.OperationFailure, _Mapping]] = ..., recovery: _Optional[_Union[ProviderEffectRecovery, str]] = ..., provider_handle: _Optional[str] = ...) -> None: ...

class ProviderEffectSettlement(_message.Message):
    __slots__ = ("succeeded", "failed", "ambiguous")
    SUCCEEDED_FIELD_NUMBER: _ClassVar[int]
    FAILED_FIELD_NUMBER: _ClassVar[int]
    AMBIGUOUS_FIELD_NUMBER: _ClassVar[int]
    succeeded: ProviderEffectSucceeded
    failed: ProviderEffectFailed
    ambiguous: ProviderEffectAmbiguous
    def __init__(self, succeeded: _Optional[_Union[ProviderEffectSucceeded, _Mapping]] = ..., failed: _Optional[_Union[ProviderEffectFailed, _Mapping]] = ..., ambiguous: _Optional[_Union[ProviderEffectAmbiguous, _Mapping]] = ...) -> None: ...

class ProviderEffectReceipt(_message.Message):
    __slots__ = ("effect_id", "provider", "credential_slot", "operation", "idempotency_key", "attempt", "settlement", "granted_at", "settled_at")
    EFFECT_ID_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    CREDENTIAL_SLOT_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    IDEMPOTENCY_KEY_FIELD_NUMBER: _ClassVar[int]
    ATTEMPT_FIELD_NUMBER: _ClassVar[int]
    SETTLEMENT_FIELD_NUMBER: _ClassVar[int]
    GRANTED_AT_FIELD_NUMBER: _ClassVar[int]
    SETTLED_AT_FIELD_NUMBER: _ClassVar[int]
    effect_id: str
    provider: str
    credential_slot: str
    operation: str
    idempotency_key: str
    attempt: int
    settlement: ProviderEffectSettlement
    granted_at: _timestamp_pb2.Timestamp
    settled_at: _timestamp_pb2.Timestamp
    def __init__(self, effect_id: _Optional[str] = ..., provider: _Optional[str] = ..., credential_slot: _Optional[str] = ..., operation: _Optional[str] = ..., idempotency_key: _Optional[str] = ..., attempt: _Optional[int] = ..., settlement: _Optional[_Union[ProviderEffectSettlement, _Mapping]] = ..., granted_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., settled_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ProviderEffectAdmission(_message.Message):
    __slots__ = ("lease", "receipt")
    LEASE_FIELD_NUMBER: _ClassVar[int]
    RECEIPT_FIELD_NUMBER: _ClassVar[int]
    lease: ProviderEffectLease
    receipt: ProviderEffectReceipt
    def __init__(self, lease: _Optional[_Union[ProviderEffectLease, _Mapping]] = ..., receipt: _Optional[_Union[ProviderEffectReceipt, _Mapping]] = ...) -> None: ...

class AcquireEffectRequest(_message.Message):
    __slots__ = ("provider", "lease")
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    LEASE_FIELD_NUMBER: _ClassVar[int]
    provider: str
    lease: ProviderEffectLeaseRequest
    def __init__(self, provider: _Optional[str] = ..., lease: _Optional[_Union[ProviderEffectLeaseRequest, _Mapping]] = ...) -> None: ...

class AcquireEffectResponse(_message.Message):
    __slots__ = ("admission", "request")
    ADMISSION_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    admission: ProviderEffectAdmission
    request: AcquireEffectRequest
    def __init__(self, admission: _Optional[_Union[ProviderEffectAdmission, _Mapping]] = ..., request: _Optional[_Union[AcquireEffectRequest, _Mapping]] = ...) -> None: ...

class SettleEffectRequest(_message.Message):
    __slots__ = ("provider", "effect_id", "attempt", "settlement")
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    EFFECT_ID_FIELD_NUMBER: _ClassVar[int]
    ATTEMPT_FIELD_NUMBER: _ClassVar[int]
    SETTLEMENT_FIELD_NUMBER: _ClassVar[int]
    provider: str
    effect_id: str
    attempt: int
    settlement: ProviderEffectSettlement
    def __init__(self, provider: _Optional[str] = ..., effect_id: _Optional[str] = ..., attempt: _Optional[int] = ..., settlement: _Optional[_Union[ProviderEffectSettlement, _Mapping]] = ...) -> None: ...

class SettleEffectResponse(_message.Message):
    __slots__ = ("receipt", "request")
    RECEIPT_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    receipt: ProviderEffectReceipt
    request: SettleEffectRequest
    def __init__(self, receipt: _Optional[_Union[ProviderEffectReceipt, _Mapping]] = ..., request: _Optional[_Union[SettleEffectRequest, _Mapping]] = ...) -> None: ...
