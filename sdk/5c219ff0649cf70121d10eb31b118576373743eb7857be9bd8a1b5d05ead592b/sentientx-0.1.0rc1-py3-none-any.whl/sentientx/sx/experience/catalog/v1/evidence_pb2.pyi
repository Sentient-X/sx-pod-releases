import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class WorldRunDocument(_message.Message):
    __slots__ = ("run_id", "canonical_json")
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    CANONICAL_JSON_FIELD_NUMBER: _ClassVar[int]
    run_id: str
    canonical_json: bytes
    def __init__(self, run_id: _Optional[str] = ..., canonical_json: _Optional[bytes] = ...) -> None: ...

class WorldRunResource(_message.Message):
    __slots__ = ("name", "run", "created_at")
    NAME_FIELD_NUMBER: _ClassVar[int]
    RUN_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    name: str
    run: WorldRunDocument
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, name: _Optional[str] = ..., run: _Optional[_Union[WorldRunDocument, _Mapping]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class GetWorldRunRequest(_message.Message):
    __slots__ = ("run_id",)
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    run_id: str
    def __init__(self, run_id: _Optional[str] = ...) -> None: ...

class GetWorldRunResponse(_message.Message):
    __slots__ = ("run", "request")
    RUN_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    run: WorldRunResource
    request: GetWorldRunRequest
    def __init__(self, run: _Optional[_Union[WorldRunResource, _Mapping]] = ..., request: _Optional[_Union[GetWorldRunRequest, _Mapping]] = ...) -> None: ...

class RegisterWorldRunRequest(_message.Message):
    __slots__ = ("run",)
    RUN_FIELD_NUMBER: _ClassVar[int]
    run: WorldRunDocument
    def __init__(self, run: _Optional[_Union[WorldRunDocument, _Mapping]] = ...) -> None: ...

class RegisterWorldRunResponse(_message.Message):
    __slots__ = ("run", "request")
    RUN_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    run: WorldRunResource
    request: RegisterWorldRunRequest
    def __init__(self, run: _Optional[_Union[WorldRunResource, _Mapping]] = ..., request: _Optional[_Union[RegisterWorldRunRequest, _Mapping]] = ...) -> None: ...
