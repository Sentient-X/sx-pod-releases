import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from sentientx.sx.common.v1 import assets_pb2 as _assets_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from sentientx.sx.operations.v1 import operations_pb2 as _operations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PlacementDemand(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PLACEMENT_DEMAND_UNSPECIFIED: _ClassVar[PlacementDemand]
    PLACEMENT_DEMAND_EDGE: _ClassVar[PlacementDemand]
    PLACEMENT_DEMAND_EDGE_PREFERRED: _ClassVar[PlacementDemand]

class SegmentSourceFormat(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SEGMENT_SOURCE_FORMAT_UNSPECIFIED: _ClassVar[SegmentSourceFormat]
    SEGMENT_SOURCE_FORMAT_RRD: _ClassVar[SegmentSourceFormat]

class DuplicateSegmentPolicy(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DUPLICATE_SEGMENT_POLICY_UNSPECIFIED: _ClassVar[DuplicateSegmentPolicy]
    DUPLICATE_SEGMENT_POLICY_ERROR: _ClassVar[DuplicateSegmentPolicy]
    DUPLICATE_SEGMENT_POLICY_OVERWRITE: _ClassVar[DuplicateSegmentPolicy]

class CaptureArtifactFormat(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CAPTURE_ARTIFACT_FORMAT_UNSPECIFIED: _ClassVar[CaptureArtifactFormat]
    CAPTURE_ARTIFACT_FORMAT_MCAP: _ClassVar[CaptureArtifactFormat]
    CAPTURE_ARTIFACT_FORMAT_LEROBOT_V3_TAR: _ClassVar[CaptureArtifactFormat]
    CAPTURE_ARTIFACT_FORMAT_SIMULATION_JSON: _ClassVar[CaptureArtifactFormat]
PLACEMENT_DEMAND_UNSPECIFIED: PlacementDemand
PLACEMENT_DEMAND_EDGE: PlacementDemand
PLACEMENT_DEMAND_EDGE_PREFERRED: PlacementDemand
SEGMENT_SOURCE_FORMAT_UNSPECIFIED: SegmentSourceFormat
SEGMENT_SOURCE_FORMAT_RRD: SegmentSourceFormat
DUPLICATE_SEGMENT_POLICY_UNSPECIFIED: DuplicateSegmentPolicy
DUPLICATE_SEGMENT_POLICY_ERROR: DuplicateSegmentPolicy
DUPLICATE_SEGMENT_POLICY_OVERWRITE: DuplicateSegmentPolicy
CAPTURE_ARTIFACT_FORMAT_UNSPECIFIED: CaptureArtifactFormat
CAPTURE_ARTIFACT_FORMAT_MCAP: CaptureArtifactFormat
CAPTURE_ARTIFACT_FORMAT_LEROBOT_V3_TAR: CaptureArtifactFormat
CAPTURE_ARTIFACT_FORMAT_SIMULATION_JSON: CaptureArtifactFormat

class PolicyRuntimeImage(_message.Message):
    __slots__ = ("name", "digest")
    NAME_FIELD_NUMBER: _ClassVar[int]
    DIGEST_FIELD_NUMBER: _ClassVar[int]
    name: str
    digest: str
    def __init__(self, name: _Optional[str] = ..., digest: _Optional[str] = ...) -> None: ...

class PolicyReplanInterval(_message.Message):
    __slots__ = ("chunks", "wall_ms")
    CHUNKS_FIELD_NUMBER: _ClassVar[int]
    WALL_MS_FIELD_NUMBER: _ClassVar[int]
    chunks: int
    wall_ms: int
    def __init__(self, chunks: _Optional[int] = ..., wall_ms: _Optional[int] = ...) -> None: ...

class VlaPolicy(_message.Message):
    __slots__ = ("artifact", "checkpoint")
    ARTIFACT_FIELD_NUMBER: _ClassVar[int]
    CHECKPOINT_FIELD_NUMBER: _ClassVar[int]
    artifact: _common_pb2.ContentRef
    checkpoint: _common_pb2.ContentRef
    def __init__(self, artifact: _Optional[_Union[_common_pb2.ContentRef, _Mapping]] = ..., checkpoint: _Optional[_Union[_common_pb2.ContentRef, _Mapping]] = ...) -> None: ...

class InnerAgent(_message.Message):
    __slots__ = ("bundle", "runtime", "demand", "replan_interval", "decision_timeout_ms")
    BUNDLE_FIELD_NUMBER: _ClassVar[int]
    RUNTIME_FIELD_NUMBER: _ClassVar[int]
    DEMAND_FIELD_NUMBER: _ClassVar[int]
    REPLAN_INTERVAL_FIELD_NUMBER: _ClassVar[int]
    DECISION_TIMEOUT_MS_FIELD_NUMBER: _ClassVar[int]
    bundle: _common_pb2.ContentRef
    runtime: PolicyRuntimeImage
    demand: PlacementDemand
    replan_interval: PolicyReplanInterval
    decision_timeout_ms: int
    def __init__(self, bundle: _Optional[_Union[_common_pb2.ContentRef, _Mapping]] = ..., runtime: _Optional[_Union[PolicyRuntimeImage, _Mapping]] = ..., demand: _Optional[_Union[PlacementDemand, str]] = ..., replan_interval: _Optional[_Union[PolicyReplanInterval, _Mapping]] = ..., decision_timeout_ms: _Optional[int] = ...) -> None: ...

class DeployablePolicy(_message.Message):
    __slots__ = ("schema_version", "artifact", "vla", "inner_agent")
    SCHEMA_VERSION_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_FIELD_NUMBER: _ClassVar[int]
    VLA_FIELD_NUMBER: _ClassVar[int]
    INNER_AGENT_FIELD_NUMBER: _ClassVar[int]
    schema_version: str
    artifact: _common_pb2.ContentRef
    vla: VlaPolicy
    inner_agent: InnerAgent
    def __init__(self, schema_version: _Optional[str] = ..., artifact: _Optional[_Union[_common_pb2.ContentRef, _Mapping]] = ..., vla: _Optional[_Union[VlaPolicy, _Mapping]] = ..., inner_agent: _Optional[_Union[InnerAgent, _Mapping]] = ...) -> None: ...

class DeployablePolicyResource(_message.Message):
    __slots__ = ("id", "name", "policy", "size_bytes", "task", "embodiment_name", "embodiment_id", "action_interface_name", "action_interface_id", "dataset", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    POLICY_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    TASK_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_NAME_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ACTION_INTERFACE_NAME_FIELD_NUMBER: _ClassVar[int]
    ACTION_INTERFACE_ID_FIELD_NUMBER: _ClassVar[int]
    DATASET_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    policy: DeployablePolicy
    size_bytes: int
    task: _common_pb2.TaskContractRef
    embodiment_name: str
    embodiment_id: str
    action_interface_name: str
    action_interface_id: str
    dataset: str
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., policy: _Optional[_Union[DeployablePolicy, _Mapping]] = ..., size_bytes: _Optional[int] = ..., task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., embodiment_name: _Optional[str] = ..., embodiment_id: _Optional[str] = ..., action_interface_name: _Optional[str] = ..., action_interface_id: _Optional[str] = ..., dataset: _Optional[str] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class TrainingCheckpoint(_message.Message):
    __slots__ = ("id", "name", "checkpoint", "size_bytes", "corpus", "corpus_sha256", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CHECKPOINT_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    CORPUS_FIELD_NUMBER: _ClassVar[int]
    CORPUS_SHA256_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    checkpoint: _common_pb2.ContentRef
    size_bytes: int
    corpus: str
    corpus_sha256: str
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., checkpoint: _Optional[_Union[_common_pb2.ContentRef, _Mapping]] = ..., size_bytes: _Optional[int] = ..., corpus: _Optional[str] = ..., corpus_sha256: _Optional[str] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class CatalogOperation(_message.Message):
    __slots__ = ("metadata", "lifecycle")
    METADATA_FIELD_NUMBER: _ClassVar[int]
    LIFECYCLE_FIELD_NUMBER: _ClassVar[int]
    metadata: _operations_pb2.OperationMetadata
    lifecycle: _operations_pb2.OperationLifecycle
    def __init__(self, metadata: _Optional[_Union[_operations_pb2.OperationMetadata, _Mapping]] = ..., lifecycle: _Optional[_Union[_operations_pb2.OperationLifecycle, _Mapping]] = ...) -> None: ...

class CatalogSegmentRef(_message.Message):
    __slots__ = ("dataset_id", "segment_id", "base_sha256")
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_ID_FIELD_NUMBER: _ClassVar[int]
    BASE_SHA256_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    segment_id: str
    base_sha256: str
    def __init__(self, dataset_id: _Optional[str] = ..., segment_id: _Optional[str] = ..., base_sha256: _Optional[str] = ...) -> None: ...

class BatchRegistrationResult(_message.Message):
    __slots__ = ("batch_id", "segment_ids")
    BATCH_ID_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_IDS_FIELD_NUMBER: _ClassVar[int]
    batch_id: str
    segment_ids: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, batch_id: _Optional[str] = ..., segment_ids: _Optional[_Iterable[str]] = ...) -> None: ...

class AssetRegistrationResult(_message.Message):
    __slots__ = ("sha256", "object_key")
    SHA256_FIELD_NUMBER: _ClassVar[int]
    OBJECT_KEY_FIELD_NUMBER: _ClassVar[int]
    sha256: str
    object_key: str
    def __init__(self, sha256: _Optional[str] = ..., object_key: _Optional[str] = ...) -> None: ...

class CaptureRegistrationResult(_message.Message):
    __slots__ = ("session_id", "receipt_sha256", "receipt_key")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    RECEIPT_SHA256_FIELD_NUMBER: _ClassVar[int]
    RECEIPT_KEY_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    receipt_sha256: str
    receipt_key: str
    def __init__(self, session_id: _Optional[str] = ..., receipt_sha256: _Optional[str] = ..., receipt_key: _Optional[str] = ...) -> None: ...

class ExportResult(_message.Message):
    __slots__ = ("segments", "bucket", "target_kind", "credential_id", "standard_conversion_sha256")
    SEGMENTS_FIELD_NUMBER: _ClassVar[int]
    BUCKET_FIELD_NUMBER: _ClassVar[int]
    TARGET_KIND_FIELD_NUMBER: _ClassVar[int]
    CREDENTIAL_ID_FIELD_NUMBER: _ClassVar[int]
    STANDARD_CONVERSION_SHA256_FIELD_NUMBER: _ClassVar[int]
    segments: int
    bucket: str
    target_kind: str
    credential_id: str
    standard_conversion_sha256: str
    def __init__(self, segments: _Optional[int] = ..., bucket: _Optional[str] = ..., target_kind: _Optional[str] = ..., credential_id: _Optional[str] = ..., standard_conversion_sha256: _Optional[str] = ...) -> None: ...

class RetentionResult(_message.Message):
    __slots__ = ("deleted", "ttl_days")
    DELETED_FIELD_NUMBER: _ClassVar[int]
    TTL_DAYS_FIELD_NUMBER: _ClassVar[int]
    deleted: int
    ttl_days: int
    def __init__(self, deleted: _Optional[int] = ..., ttl_days: _Optional[int] = ...) -> None: ...

class ExportCredentialValidationResult(_message.Message):
    __slots__ = ("credential_id", "state")
    CREDENTIAL_ID_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    credential_id: str
    state: str
    def __init__(self, credential_id: _Optional[str] = ..., state: _Optional[str] = ...) -> None: ...

class IngestConversionResult(_message.Message):
    __slots__ = ("ray_submission_id", "receipt_json")
    RAY_SUBMISSION_ID_FIELD_NUMBER: _ClassVar[int]
    RECEIPT_JSON_FIELD_NUMBER: _ClassVar[int]
    ray_submission_id: str
    receipt_json: bytes
    def __init__(self, ray_submission_id: _Optional[str] = ..., receipt_json: _Optional[bytes] = ...) -> None: ...

class SemanticStagedTable(_message.Message):
    __slots__ = ("table", "rows", "size_bytes")
    TABLE_FIELD_NUMBER: _ClassVar[int]
    ROWS_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    table: str
    rows: int
    size_bytes: int
    def __init__(self, table: _Optional[str] = ..., rows: _Optional[int] = ..., size_bytes: _Optional[int] = ...) -> None: ...

class SemanticIndexResult(_message.Message):
    __slots__ = ("frame_count", "texts_rows", "gpu_seconds", "embedder_version", "detector_version", "staged")
    FRAME_COUNT_FIELD_NUMBER: _ClassVar[int]
    TEXTS_ROWS_FIELD_NUMBER: _ClassVar[int]
    GPU_SECONDS_FIELD_NUMBER: _ClassVar[int]
    EMBEDDER_VERSION_FIELD_NUMBER: _ClassVar[int]
    DETECTOR_VERSION_FIELD_NUMBER: _ClassVar[int]
    STAGED_FIELD_NUMBER: _ClassVar[int]
    frame_count: int
    texts_rows: int
    gpu_seconds: float
    embedder_version: int
    detector_version: int
    staged: _containers.RepeatedCompositeFieldContainer[SemanticStagedTable]
    def __init__(self, frame_count: _Optional[int] = ..., texts_rows: _Optional[int] = ..., gpu_seconds: _Optional[float] = ..., embedder_version: _Optional[int] = ..., detector_version: _Optional[int] = ..., staged: _Optional[_Iterable[_Union[SemanticStagedTable, _Mapping]]] = ...) -> None: ...

class SemanticSweepResult(_message.Message):
    __slots__ = ("enqueued", "remaining")
    ENQUEUED_FIELD_NUMBER: _ClassVar[int]
    REMAINING_FIELD_NUMBER: _ClassVar[int]
    enqueued: int
    remaining: int
    def __init__(self, enqueued: _Optional[int] = ..., remaining: _Optional[int] = ...) -> None: ...

class SemanticTaskMapResult(_message.Message):
    __slots__ = ("episodes", "clusters", "atlas_points", "atlas_frames_total")
    EPISODES_FIELD_NUMBER: _ClassVar[int]
    CLUSTERS_FIELD_NUMBER: _ClassVar[int]
    ATLAS_POINTS_FIELD_NUMBER: _ClassVar[int]
    ATLAS_FRAMES_TOTAL_FIELD_NUMBER: _ClassVar[int]
    episodes: int
    clusters: int
    atlas_points: int
    atlas_frames_total: int
    def __init__(self, episodes: _Optional[int] = ..., clusters: _Optional[int] = ..., atlas_points: _Optional[int] = ..., atlas_frames_total: _Optional[int] = ...) -> None: ...

class CatalogOperationResult(_message.Message):
    __slots__ = ("segment", "batch", "asset", "capture", "policy", "checkpoint", "export", "retention", "export_credential", "ingest_conversion", "semantic_index", "semantic_sweep", "semantic_task_map")
    SEGMENT_FIELD_NUMBER: _ClassVar[int]
    BATCH_FIELD_NUMBER: _ClassVar[int]
    ASSET_FIELD_NUMBER: _ClassVar[int]
    CAPTURE_FIELD_NUMBER: _ClassVar[int]
    POLICY_FIELD_NUMBER: _ClassVar[int]
    CHECKPOINT_FIELD_NUMBER: _ClassVar[int]
    EXPORT_FIELD_NUMBER: _ClassVar[int]
    RETENTION_FIELD_NUMBER: _ClassVar[int]
    EXPORT_CREDENTIAL_FIELD_NUMBER: _ClassVar[int]
    INGEST_CONVERSION_FIELD_NUMBER: _ClassVar[int]
    SEMANTIC_INDEX_FIELD_NUMBER: _ClassVar[int]
    SEMANTIC_SWEEP_FIELD_NUMBER: _ClassVar[int]
    SEMANTIC_TASK_MAP_FIELD_NUMBER: _ClassVar[int]
    segment: CatalogSegmentRef
    batch: BatchRegistrationResult
    asset: AssetRegistrationResult
    capture: CaptureRegistrationResult
    policy: DeployablePolicyResource
    checkpoint: TrainingCheckpoint
    export: ExportResult
    retention: RetentionResult
    export_credential: ExportCredentialValidationResult
    ingest_conversion: IngestConversionResult
    semantic_index: SemanticIndexResult
    semantic_sweep: SemanticSweepResult
    semantic_task_map: SemanticTaskMapResult
    def __init__(self, segment: _Optional[_Union[CatalogSegmentRef, _Mapping]] = ..., batch: _Optional[_Union[BatchRegistrationResult, _Mapping]] = ..., asset: _Optional[_Union[AssetRegistrationResult, _Mapping]] = ..., capture: _Optional[_Union[CaptureRegistrationResult, _Mapping]] = ..., policy: _Optional[_Union[DeployablePolicyResource, _Mapping]] = ..., checkpoint: _Optional[_Union[TrainingCheckpoint, _Mapping]] = ..., export: _Optional[_Union[ExportResult, _Mapping]] = ..., retention: _Optional[_Union[RetentionResult, _Mapping]] = ..., export_credential: _Optional[_Union[ExportCredentialValidationResult, _Mapping]] = ..., ingest_conversion: _Optional[_Union[IngestConversionResult, _Mapping]] = ..., semantic_index: _Optional[_Union[SemanticIndexResult, _Mapping]] = ..., semantic_sweep: _Optional[_Union[SemanticSweepResult, _Mapping]] = ..., semantic_task_map: _Optional[_Union[SemanticTaskMapResult, _Mapping]] = ...) -> None: ...

class RegisterAssetRequest(_message.Message):
    __slots__ = ("source_uri", "asset", "timeout")
    SOURCE_URI_FIELD_NUMBER: _ClassVar[int]
    ASSET_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    source_uri: str
    asset: _assets_pb2.ProvenancedAsset
    timeout: _duration_pb2.Duration
    def __init__(self, source_uri: _Optional[str] = ..., asset: _Optional[_Union[_assets_pb2.ProvenancedAsset, _Mapping]] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class RegisterAssetResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: CatalogOperation
    def __init__(self, operation: _Optional[_Union[CatalogOperation, _Mapping]] = ...) -> None: ...

class RegisterPolicyRequest(_message.Message):
    __slots__ = ("name", "source_uri", "size_bytes", "policy", "task", "embodiment_id", "action_interface_id", "dataset", "timeout")
    NAME_FIELD_NUMBER: _ClassVar[int]
    SOURCE_URI_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    POLICY_FIELD_NUMBER: _ClassVar[int]
    TASK_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ACTION_INTERFACE_ID_FIELD_NUMBER: _ClassVar[int]
    DATASET_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    name: str
    source_uri: str
    size_bytes: int
    policy: DeployablePolicy
    task: _common_pb2.TaskContractRef
    embodiment_id: str
    action_interface_id: str
    dataset: str
    timeout: _duration_pb2.Duration
    def __init__(self, name: _Optional[str] = ..., source_uri: _Optional[str] = ..., size_bytes: _Optional[int] = ..., policy: _Optional[_Union[DeployablePolicy, _Mapping]] = ..., task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., embodiment_id: _Optional[str] = ..., action_interface_id: _Optional[str] = ..., dataset: _Optional[str] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class RegisterPolicyResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: CatalogOperation
    def __init__(self, operation: _Optional[_Union[CatalogOperation, _Mapping]] = ...) -> None: ...

class RegisterTrainingCheckpointRequest(_message.Message):
    __slots__ = ("name", "source_uri", "size_bytes", "checkpoint", "corpus", "corpus_sha256", "timeout")
    NAME_FIELD_NUMBER: _ClassVar[int]
    SOURCE_URI_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    CHECKPOINT_FIELD_NUMBER: _ClassVar[int]
    CORPUS_FIELD_NUMBER: _ClassVar[int]
    CORPUS_SHA256_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    name: str
    source_uri: str
    size_bytes: int
    checkpoint: _common_pb2.ContentRef
    corpus: str
    corpus_sha256: str
    timeout: _duration_pb2.Duration
    def __init__(self, name: _Optional[str] = ..., source_uri: _Optional[str] = ..., size_bytes: _Optional[int] = ..., checkpoint: _Optional[_Union[_common_pb2.ContentRef, _Mapping]] = ..., corpus: _Optional[str] = ..., corpus_sha256: _Optional[str] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class RegisterTrainingCheckpointResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: CatalogOperation
    def __init__(self, operation: _Optional[_Union[CatalogOperation, _Mapping]] = ...) -> None: ...

class MediaLineageRef(_message.Message):
    __slots__ = ("uri", "sha256")
    URI_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    uri: str
    sha256: str
    def __init__(self, uri: _Optional[str] = ..., sha256: _Optional[str] = ...) -> None: ...

class SegmentLineageRefs(_message.Message):
    __slots__ = ("deployment", "capability_approval", "training_run", "media")
    DEPLOYMENT_FIELD_NUMBER: _ClassVar[int]
    CAPABILITY_APPROVAL_FIELD_NUMBER: _ClassVar[int]
    TRAINING_RUN_FIELD_NUMBER: _ClassVar[int]
    MEDIA_FIELD_NUMBER: _ClassVar[int]
    deployment: str
    capability_approval: str
    training_run: str
    media: _containers.RepeatedCompositeFieldContainer[MediaLineageRef]
    def __init__(self, deployment: _Optional[str] = ..., capability_approval: _Optional[str] = ..., training_run: _Optional[str] = ..., media: _Optional[_Iterable[_Union[MediaLineageRef, _Mapping]]] = ...) -> None: ...

class CaptureEvidence(_message.Message):
    __slots__ = ("receipt_json", "episode_id")
    RECEIPT_JSON_FIELD_NUMBER: _ClassVar[int]
    EPISODE_ID_FIELD_NUMBER: _ClassVar[int]
    receipt_json: bytes
    episode_id: str
    def __init__(self, receipt_json: _Optional[bytes] = ..., episode_id: _Optional[str] = ...) -> None: ...

class RegisterSegmentRequest(_message.Message):
    __slots__ = ("dataset", "source_uri", "source_format", "source_sha256", "layer", "on_duplicate", "lineage_refs", "capture", "timeout")
    DATASET_FIELD_NUMBER: _ClassVar[int]
    SOURCE_URI_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FORMAT_FIELD_NUMBER: _ClassVar[int]
    SOURCE_SHA256_FIELD_NUMBER: _ClassVar[int]
    LAYER_FIELD_NUMBER: _ClassVar[int]
    ON_DUPLICATE_FIELD_NUMBER: _ClassVar[int]
    LINEAGE_REFS_FIELD_NUMBER: _ClassVar[int]
    CAPTURE_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    source_uri: str
    source_format: SegmentSourceFormat
    source_sha256: str
    layer: str
    on_duplicate: DuplicateSegmentPolicy
    lineage_refs: SegmentLineageRefs
    capture: CaptureEvidence
    timeout: _duration_pb2.Duration
    def __init__(self, dataset: _Optional[str] = ..., source_uri: _Optional[str] = ..., source_format: _Optional[_Union[SegmentSourceFormat, str]] = ..., source_sha256: _Optional[str] = ..., layer: _Optional[str] = ..., on_duplicate: _Optional[_Union[DuplicateSegmentPolicy, str]] = ..., lineage_refs: _Optional[_Union[SegmentLineageRefs, _Mapping]] = ..., capture: _Optional[_Union[CaptureEvidence, _Mapping]] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class RegisterSegmentResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: CatalogOperation
    def __init__(self, operation: _Optional[_Union[CatalogOperation, _Mapping]] = ...) -> None: ...

class BatchEpisode(_message.Message):
    __slots__ = ("episode_id", "upload_id", "source_sha256")
    EPISODE_ID_FIELD_NUMBER: _ClassVar[int]
    UPLOAD_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_SHA256_FIELD_NUMBER: _ClassVar[int]
    episode_id: str
    upload_id: str
    source_sha256: str
    def __init__(self, episode_id: _Optional[str] = ..., upload_id: _Optional[str] = ..., source_sha256: _Optional[str] = ...) -> None: ...

class RegisterBatchRequest(_message.Message):
    __slots__ = ("dataset", "idempotency_key", "batch_ref", "episodes", "timeout")
    DATASET_FIELD_NUMBER: _ClassVar[int]
    IDEMPOTENCY_KEY_FIELD_NUMBER: _ClassVar[int]
    BATCH_REF_FIELD_NUMBER: _ClassVar[int]
    EPISODES_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    idempotency_key: str
    batch_ref: str
    episodes: _containers.RepeatedCompositeFieldContainer[BatchEpisode]
    timeout: _duration_pb2.Duration
    def __init__(self, dataset: _Optional[str] = ..., idempotency_key: _Optional[str] = ..., batch_ref: _Optional[str] = ..., episodes: _Optional[_Iterable[_Union[BatchEpisode, _Mapping]]] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class RegisterBatchResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: CatalogOperation
    def __init__(self, operation: _Optional[_Union[CatalogOperation, _Mapping]] = ...) -> None: ...

class CaptureArtifactFile(_message.Message):
    __slots__ = ("path", "sha256", "size_bytes")
    PATH_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    path: str
    sha256: str
    size_bytes: int
    def __init__(self, path: _Optional[str] = ..., sha256: _Optional[str] = ..., size_bytes: _Optional[int] = ...) -> None: ...

class CaptureArtifactManifest(_message.Message):
    __slots__ = ("schema_version", "format", "sha256", "size_bytes", "episode_ids", "files")
    SCHEMA_VERSION_FIELD_NUMBER: _ClassVar[int]
    FORMAT_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    EPISODE_IDS_FIELD_NUMBER: _ClassVar[int]
    FILES_FIELD_NUMBER: _ClassVar[int]
    schema_version: str
    format: CaptureArtifactFormat
    sha256: str
    size_bytes: int
    episode_ids: _containers.RepeatedScalarFieldContainer[str]
    files: _containers.RepeatedCompositeFieldContainer[CaptureArtifactFile]
    def __init__(self, schema_version: _Optional[str] = ..., format: _Optional[_Union[CaptureArtifactFormat, str]] = ..., sha256: _Optional[str] = ..., size_bytes: _Optional[int] = ..., episode_ids: _Optional[_Iterable[str]] = ..., files: _Optional[_Iterable[_Union[CaptureArtifactFile, _Mapping]]] = ...) -> None: ...

class CaptureArtifact(_message.Message):
    __slots__ = ("source_uri", "manifest")
    SOURCE_URI_FIELD_NUMBER: _ClassVar[int]
    MANIFEST_FIELD_NUMBER: _ClassVar[int]
    source_uri: str
    manifest: CaptureArtifactManifest
    def __init__(self, source_uri: _Optional[str] = ..., manifest: _Optional[_Union[CaptureArtifactManifest, _Mapping]] = ...) -> None: ...

class RegisterCaptureRequest(_message.Message):
    __slots__ = ("receipt_json", "instruction", "artifacts", "timeout")
    RECEIPT_JSON_FIELD_NUMBER: _ClassVar[int]
    INSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    ARTIFACTS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    receipt_json: bytes
    instruction: str
    artifacts: _containers.RepeatedCompositeFieldContainer[CaptureArtifact]
    timeout: _duration_pb2.Duration
    def __init__(self, receipt_json: _Optional[bytes] = ..., instruction: _Optional[str] = ..., artifacts: _Optional[_Iterable[_Union[CaptureArtifact, _Mapping]]] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class RegisterCaptureResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: CatalogOperation
    def __init__(self, operation: _Optional[_Union[CatalogOperation, _Mapping]] = ...) -> None: ...

class ExportPlan(_message.Message):
    __slots__ = ("target", "prefix", "dataset_kinds", "timeout")
    TARGET_FIELD_NUMBER: _ClassVar[int]
    PREFIX_FIELD_NUMBER: _ClassVar[int]
    DATASET_KINDS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    target: str
    prefix: str
    dataset_kinds: _containers.RepeatedScalarFieldContainer[str]
    timeout: _duration_pb2.Duration
    def __init__(self, target: _Optional[str] = ..., prefix: _Optional[str] = ..., dataset_kinds: _Optional[_Iterable[str]] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class StartDatasetExportRequest(_message.Message):
    __slots__ = ("dataset", "plan")
    DATASET_FIELD_NUMBER: _ClassVar[int]
    PLAN_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    plan: ExportPlan
    def __init__(self, dataset: _Optional[str] = ..., plan: _Optional[_Union[ExportPlan, _Mapping]] = ...) -> None: ...

class StartDatasetExportResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: CatalogOperation
    def __init__(self, operation: _Optional[_Union[CatalogOperation, _Mapping]] = ...) -> None: ...

class StartSegmentExportRequest(_message.Message):
    __slots__ = ("dataset", "segment_id", "plan")
    DATASET_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_ID_FIELD_NUMBER: _ClassVar[int]
    PLAN_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    segment_id: str
    plan: ExportPlan
    def __init__(self, dataset: _Optional[str] = ..., segment_id: _Optional[str] = ..., plan: _Optional[_Union[ExportPlan, _Mapping]] = ...) -> None: ...

class StartSegmentExportResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: CatalogOperation
    def __init__(self, operation: _Optional[_Union[CatalogOperation, _Mapping]] = ...) -> None: ...

class StartRetentionRequest(_message.Message):
    __slots__ = ("ttl_days", "timeout")
    TTL_DAYS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    ttl_days: int
    timeout: _duration_pb2.Duration
    def __init__(self, ttl_days: _Optional[int] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class StartRetentionResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: CatalogOperation
    def __init__(self, operation: _Optional[_Union[CatalogOperation, _Mapping]] = ...) -> None: ...

class GetCatalogOperationRequest(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class GetCatalogOperationResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: CatalogOperation
    def __init__(self, operation: _Optional[_Union[CatalogOperation, _Mapping]] = ...) -> None: ...

class GetCatalogOperationUpdatesRequest(_message.Message):
    __slots__ = ("operation", "after_cursor", "limit", "wait_timeout")
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    AFTER_CURSOR_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    WAIT_TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    after_cursor: int
    limit: int
    wait_timeout: _duration_pb2.Duration
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., after_cursor: _Optional[int] = ..., limit: _Optional[int] = ..., wait_timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class CatalogOperationUpdatePage(_message.Message):
    __slots__ = ("updates", "next_cursor", "has_more")
    UPDATES_FIELD_NUMBER: _ClassVar[int]
    NEXT_CURSOR_FIELD_NUMBER: _ClassVar[int]
    HAS_MORE_FIELD_NUMBER: _ClassVar[int]
    updates: _containers.RepeatedCompositeFieldContainer[CatalogOperation]
    next_cursor: int
    has_more: bool
    def __init__(self, updates: _Optional[_Iterable[_Union[CatalogOperation, _Mapping]]] = ..., next_cursor: _Optional[int] = ..., has_more: _Optional[bool] = ...) -> None: ...

class GetCatalogOperationUpdatesResponse(_message.Message):
    __slots__ = ("page", "history_gap")
    PAGE_FIELD_NUMBER: _ClassVar[int]
    HISTORY_GAP_FIELD_NUMBER: _ClassVar[int]
    page: CatalogOperationUpdatePage
    history_gap: _operations_pb2.OperationHistoryGap
    def __init__(self, page: _Optional[_Union[CatalogOperationUpdatePage, _Mapping]] = ..., history_gap: _Optional[_Union[_operations_pb2.OperationHistoryGap, _Mapping]] = ...) -> None: ...

class GetCatalogOperationResultRequest(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class GetCatalogOperationResultResponse(_message.Message):
    __slots__ = ("result", "operation", "resource")
    RESULT_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    RESOURCE_FIELD_NUMBER: _ClassVar[int]
    result: CatalogOperationResult
    operation: _common_pb2.OperationRef
    resource: _common_pb2.ResourceRef
    def __init__(self, result: _Optional[_Union[CatalogOperationResult, _Mapping]] = ..., operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., resource: _Optional[_Union[_common_pb2.ResourceRef, _Mapping]] = ...) -> None: ...

class CancelCatalogOperationRequest(_message.Message):
    __slots__ = ("operation", "reason")
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    reason: str
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., reason: _Optional[str] = ...) -> None: ...

class CancelCatalogOperationResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: CatalogOperation
    def __init__(self, operation: _Optional[_Union[CatalogOperation, _Mapping]] = ...) -> None: ...

class GetPolicyRequest(_message.Message):
    __slots__ = ("artifact_id",)
    ARTIFACT_ID_FIELD_NUMBER: _ClassVar[int]
    artifact_id: str
    def __init__(self, artifact_id: _Optional[str] = ...) -> None: ...

class GetPolicyResponse(_message.Message):
    __slots__ = ("policy",)
    POLICY_FIELD_NUMBER: _ClassVar[int]
    policy: DeployablePolicyResource
    def __init__(self, policy: _Optional[_Union[DeployablePolicyResource, _Mapping]] = ...) -> None: ...

class GetPolicyArtifactUrlRequest(_message.Message):
    __slots__ = ("artifact_id",)
    ARTIFACT_ID_FIELD_NUMBER: _ClassVar[int]
    artifact_id: str
    def __init__(self, artifact_id: _Optional[str] = ...) -> None: ...

class GetPolicyArtifactUrlResponse(_message.Message):
    __slots__ = ("url", "expires_in", "object_key", "sha256")
    URL_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_IN_FIELD_NUMBER: _ClassVar[int]
    OBJECT_KEY_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    url: str
    expires_in: _duration_pb2.Duration
    object_key: str
    sha256: str
    def __init__(self, url: _Optional[str] = ..., expires_in: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ..., object_key: _Optional[str] = ..., sha256: _Optional[str] = ...) -> None: ...
