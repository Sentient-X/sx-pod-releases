import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class AmbiguityRecovery(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    AMBIGUITY_RECOVERY_UNSPECIFIED: _ClassVar[AmbiguityRecovery]
    AMBIGUITY_RECOVERY_REPLAY_UNDER_KEY: _ClassVar[AmbiguityRecovery]
    AMBIGUITY_RECOVERY_PROVIDER_QUERY: _ClassVar[AmbiguityRecovery]
    AMBIGUITY_RECOVERY_UNRECONCILABLE: _ClassVar[AmbiguityRecovery]
AMBIGUITY_RECOVERY_UNSPECIFIED: AmbiguityRecovery
AMBIGUITY_RECOVERY_REPLAY_UNDER_KEY: AmbiguityRecovery
AMBIGUITY_RECOVERY_PROVIDER_QUERY: AmbiguityRecovery
AMBIGUITY_RECOVERY_UNRECONCILABLE: AmbiguityRecovery

class ClaimsByCode(_message.Message):
    __slots__ = ("code", "claims")
    CODE_FIELD_NUMBER: _ClassVar[int]
    CLAIMS_FIELD_NUMBER: _ClassVar[int]
    code: str
    claims: int
    def __init__(self, code: _Optional[str] = ..., claims: _Optional[int] = ...) -> None: ...

class HeldUsage(_message.Message):
    __slots__ = ("unbindable", "held", "refused", "deliverable", "past_settlement")
    UNBINDABLE_FIELD_NUMBER: _ClassVar[int]
    HELD_FIELD_NUMBER: _ClassVar[int]
    REFUSED_FIELD_NUMBER: _ClassVar[int]
    DELIVERABLE_FIELD_NUMBER: _ClassVar[int]
    PAST_SETTLEMENT_FIELD_NUMBER: _ClassVar[int]
    unbindable: int
    held: _containers.RepeatedCompositeFieldContainer[ClaimsByCode]
    refused: _containers.RepeatedCompositeFieldContainer[ClaimsByCode]
    deliverable: int
    past_settlement: int
    def __init__(self, unbindable: _Optional[int] = ..., held: _Optional[_Iterable[_Union[ClaimsByCode, _Mapping]]] = ..., refused: _Optional[_Iterable[_Union[ClaimsByCode, _Mapping]]] = ..., deliverable: _Optional[int] = ..., past_settlement: _Optional[int] = ...) -> None: ...

class GetHeldUsageRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetHeldUsageResponse(_message.Message):
    __slots__ = ("usage", "request")
    USAGE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    usage: HeldUsage
    request: GetHeldUsageRequest
    def __init__(self, usage: _Optional[_Union[HeldUsage, _Mapping]] = ..., request: _Optional[_Union[GetHeldUsageRequest, _Mapping]] = ...) -> None: ...

class AmbiguousEffect(_message.Message):
    __slots__ = ("effect_id", "operation", "attempt", "recovery", "provider_handle", "granted_at", "settled_at", "idempotency_key")
    EFFECT_ID_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    ATTEMPT_FIELD_NUMBER: _ClassVar[int]
    RECOVERY_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_HANDLE_FIELD_NUMBER: _ClassVar[int]
    GRANTED_AT_FIELD_NUMBER: _ClassVar[int]
    SETTLED_AT_FIELD_NUMBER: _ClassVar[int]
    IDEMPOTENCY_KEY_FIELD_NUMBER: _ClassVar[int]
    effect_id: str
    operation: str
    attempt: int
    recovery: AmbiguityRecovery
    provider_handle: str
    granted_at: _timestamp_pb2.Timestamp
    settled_at: _timestamp_pb2.Timestamp
    idempotency_key: str
    def __init__(self, effect_id: _Optional[str] = ..., operation: _Optional[str] = ..., attempt: _Optional[int] = ..., recovery: _Optional[_Union[AmbiguityRecovery, str]] = ..., provider_handle: _Optional[str] = ..., granted_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., settled_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., idempotency_key: _Optional[str] = ...) -> None: ...

class ListAmbiguousEffectsRequest(_message.Message):
    __slots__ = ("provider",)
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    provider: str
    def __init__(self, provider: _Optional[str] = ...) -> None: ...

class ListAmbiguousEffectsResponse(_message.Message):
    __slots__ = ("effects", "request")
    EFFECTS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    effects: _containers.RepeatedCompositeFieldContainer[AmbiguousEffect]
    request: ListAmbiguousEffectsRequest
    def __init__(self, effects: _Optional[_Iterable[_Union[AmbiguousEffect, _Mapping]]] = ..., request: _Optional[_Union[ListAmbiguousEffectsRequest, _Mapping]] = ...) -> None: ...
