import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class EvidenceAttestation(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EVIDENCE_ATTESTATION_UNSPECIFIED: _ClassVar[EvidenceAttestation]
    EVIDENCE_ATTESTATION_CATALOG: _ClassVar[EvidenceAttestation]
EVIDENCE_ATTESTATION_UNSPECIFIED: EvidenceAttestation
EVIDENCE_ATTESTATION_CATALOG: EvidenceAttestation

class RobotApplicationDocument(_message.Message):
    __slots__ = ("application_ref", "canonical_application")
    APPLICATION_REF_FIELD_NUMBER: _ClassVar[int]
    CANONICAL_APPLICATION_FIELD_NUMBER: _ClassVar[int]
    application_ref: str
    canonical_application: bytes
    def __init__(self, application_ref: _Optional[str] = ..., canonical_application: _Optional[bytes] = ...) -> None: ...

class RobotApplicationResource(_message.Message):
    __slots__ = ("name", "application", "created_at")
    NAME_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    name: str
    application: RobotApplicationDocument
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, name: _Optional[str] = ..., application: _Optional[_Union[RobotApplicationDocument, _Mapping]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ListApplicationsRequest(_message.Message):
    __slots__ = ("after_application_ref", "limit")
    AFTER_APPLICATION_REF_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    after_application_ref: str
    limit: int
    def __init__(self, after_application_ref: _Optional[str] = ..., limit: _Optional[int] = ...) -> None: ...

class ListApplicationsResponse(_message.Message):
    __slots__ = ("applications", "next_page_after", "request")
    APPLICATIONS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_AFTER_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    applications: _containers.RepeatedCompositeFieldContainer[RobotApplicationResource]
    next_page_after: str
    request: ListApplicationsRequest
    def __init__(self, applications: _Optional[_Iterable[_Union[RobotApplicationResource, _Mapping]]] = ..., next_page_after: _Optional[str] = ..., request: _Optional[_Union[ListApplicationsRequest, _Mapping]] = ...) -> None: ...

class RegisterApplicationRequest(_message.Message):
    __slots__ = ("name", "application")
    NAME_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_FIELD_NUMBER: _ClassVar[int]
    name: str
    application: RobotApplicationDocument
    def __init__(self, name: _Optional[str] = ..., application: _Optional[_Union[RobotApplicationDocument, _Mapping]] = ...) -> None: ...

class RegisterApplicationResponse(_message.Message):
    __slots__ = ("application", "request")
    APPLICATION_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    application: RobotApplicationResource
    request: RegisterApplicationRequest
    def __init__(self, application: _Optional[_Union[RobotApplicationResource, _Mapping]] = ..., request: _Optional[_Union[RegisterApplicationRequest, _Mapping]] = ...) -> None: ...

class GetApplicationRequest(_message.Message):
    __slots__ = ("application_ref",)
    APPLICATION_REF_FIELD_NUMBER: _ClassVar[int]
    application_ref: str
    def __init__(self, application_ref: _Optional[str] = ...) -> None: ...

class GetApplicationResponse(_message.Message):
    __slots__ = ("application", "request")
    APPLICATION_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    application: RobotApplicationResource
    request: GetApplicationRequest
    def __init__(self, application: _Optional[_Union[RobotApplicationResource, _Mapping]] = ..., request: _Optional[_Union[GetApplicationRequest, _Mapping]] = ...) -> None: ...

class CapabilityApprovalDocument(_message.Message):
    __slots__ = ("approval_ref", "canonical_approval")
    APPROVAL_REF_FIELD_NUMBER: _ClassVar[int]
    CANONICAL_APPROVAL_FIELD_NUMBER: _ClassVar[int]
    approval_ref: str
    canonical_approval: bytes
    def __init__(self, approval_ref: _Optional[str] = ..., canonical_approval: _Optional[bytes] = ...) -> None: ...

class CapabilityApprovalResource(_message.Message):
    __slots__ = ("name", "approval", "evidence_attestation", "created_at")
    NAME_FIELD_NUMBER: _ClassVar[int]
    APPROVAL_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_ATTESTATION_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    name: str
    approval: CapabilityApprovalDocument
    evidence_attestation: EvidenceAttestation
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, name: _Optional[str] = ..., approval: _Optional[_Union[CapabilityApprovalDocument, _Mapping]] = ..., evidence_attestation: _Optional[_Union[EvidenceAttestation, str]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class RegisterCapabilityApprovalRequest(_message.Message):
    __slots__ = ("name", "approval")
    NAME_FIELD_NUMBER: _ClassVar[int]
    APPROVAL_FIELD_NUMBER: _ClassVar[int]
    name: str
    approval: CapabilityApprovalDocument
    def __init__(self, name: _Optional[str] = ..., approval: _Optional[_Union[CapabilityApprovalDocument, _Mapping]] = ...) -> None: ...

class RegisterCapabilityApprovalResponse(_message.Message):
    __slots__ = ("approval", "request")
    APPROVAL_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    approval: CapabilityApprovalResource
    request: RegisterCapabilityApprovalRequest
    def __init__(self, approval: _Optional[_Union[CapabilityApprovalResource, _Mapping]] = ..., request: _Optional[_Union[RegisterCapabilityApprovalRequest, _Mapping]] = ...) -> None: ...

class GetCapabilityApprovalRequest(_message.Message):
    __slots__ = ("approval_ref",)
    APPROVAL_REF_FIELD_NUMBER: _ClassVar[int]
    approval_ref: str
    def __init__(self, approval_ref: _Optional[str] = ...) -> None: ...

class GetCapabilityApprovalResponse(_message.Message):
    __slots__ = ("approval", "request")
    APPROVAL_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    approval: CapabilityApprovalResource
    request: GetCapabilityApprovalRequest
    def __init__(self, approval: _Optional[_Union[CapabilityApprovalResource, _Mapping]] = ..., request: _Optional[_Union[GetCapabilityApprovalRequest, _Mapping]] = ...) -> None: ...

class ApplicationQualificationDocument(_message.Message):
    __slots__ = ("qualification_ref", "canonical_qualification")
    QUALIFICATION_REF_FIELD_NUMBER: _ClassVar[int]
    CANONICAL_QUALIFICATION_FIELD_NUMBER: _ClassVar[int]
    qualification_ref: str
    canonical_qualification: bytes
    def __init__(self, qualification_ref: _Optional[str] = ..., canonical_qualification: _Optional[bytes] = ...) -> None: ...

class ApplicationQualificationResource(_message.Message):
    __slots__ = ("qualification", "created_at")
    QUALIFICATION_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    qualification: ApplicationQualificationDocument
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, qualification: _Optional[_Union[ApplicationQualificationDocument, _Mapping]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class RegisterApplicationQualificationRequest(_message.Message):
    __slots__ = ("qualification",)
    QUALIFICATION_FIELD_NUMBER: _ClassVar[int]
    qualification: ApplicationQualificationDocument
    def __init__(self, qualification: _Optional[_Union[ApplicationQualificationDocument, _Mapping]] = ...) -> None: ...

class RegisterApplicationQualificationResponse(_message.Message):
    __slots__ = ("qualification", "request")
    QUALIFICATION_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    qualification: ApplicationQualificationResource
    request: RegisterApplicationQualificationRequest
    def __init__(self, qualification: _Optional[_Union[ApplicationQualificationResource, _Mapping]] = ..., request: _Optional[_Union[RegisterApplicationQualificationRequest, _Mapping]] = ...) -> None: ...

class GetApplicationQualificationRequest(_message.Message):
    __slots__ = ("qualification_ref",)
    QUALIFICATION_REF_FIELD_NUMBER: _ClassVar[int]
    qualification_ref: str
    def __init__(self, qualification_ref: _Optional[str] = ...) -> None: ...

class GetApplicationQualificationResponse(_message.Message):
    __slots__ = ("qualification", "request")
    QUALIFICATION_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    qualification: ApplicationQualificationResource
    request: GetApplicationQualificationRequest
    def __init__(self, qualification: _Optional[_Union[ApplicationQualificationResource, _Mapping]] = ..., request: _Optional[_Union[GetApplicationQualificationRequest, _Mapping]] = ...) -> None: ...
