import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CatalogGrantRole(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CATALOG_GRANT_ROLE_UNSPECIFIED: _ClassVar[CatalogGrantRole]
    CATALOG_GRANT_ROLE_READER: _ClassVar[CatalogGrantRole]
    CATALOG_GRANT_ROLE_WRITER: _ClassVar[CatalogGrantRole]
    CATALOG_GRANT_ROLE_EXPORTER: _ClassVar[CatalogGrantRole]
    CATALOG_GRANT_ROLE_OWNER: _ClassVar[CatalogGrantRole]
    CATALOG_GRANT_ROLE_ADMIN: _ClassVar[CatalogGrantRole]

class CatalogEntryKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CATALOG_ENTRY_KIND_UNSPECIFIED: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_DATASET: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_TABLE: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_EMBODIMENT: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_ASSET_PACK: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_PART: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_CORPUS: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_DEPLOYABLE_POLICY: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_TRAINING_CHECKPOINT: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_ACTION_INTERFACE: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_ROBOT_APPLICATION: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_CAPABILITY_APPROVAL: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_WORLD_RUN: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_EVAL_SUITE: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_POLICY_ARTIFACT: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_SCENE: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_ENVIRONMENT: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_OBJECT_ASSET: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_BASE_WEIGHTS: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_CAPTURE: _ClassVar[CatalogEntryKind]
    CATALOG_ENTRY_KIND_DATASET_SNAPSHOT: _ClassVar[CatalogEntryKind]

class CatalogDatasetKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CATALOG_DATASET_KIND_UNSPECIFIED: _ClassVar[CatalogDatasetKind]
    CATALOG_DATASET_KIND_ONLINE: _ClassVar[CatalogDatasetKind]
    CATALOG_DATASET_KIND_CORRECTION: _ClassVar[CatalogDatasetKind]
    CATALOG_DATASET_KIND_DEMO: _ClassVar[CatalogDatasetKind]

class CatalogActionSource(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CATALOG_ACTION_SOURCE_UNSPECIFIED: _ClassVar[CatalogActionSource]
    CATALOG_ACTION_SOURCE_POLICY: _ClassVar[CatalogActionSource]
    CATALOG_ACTION_SOURCE_HEURISTIC_OVERRIDE: _ClassVar[CatalogActionSource]
    CATALOG_ACTION_SOURCE_AGENT: _ClassVar[CatalogActionSource]
    CATALOG_ACTION_SOURCE_HUMAN_TELEOP: _ClassVar[CatalogActionSource]
    CATALOG_ACTION_SOURCE_SCRIPTED: _ClassVar[CatalogActionSource]
    CATALOG_ACTION_SOURCE_SIM_AUGMENTED: _ClassVar[CatalogActionSource]

class CatalogSegmentState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CATALOG_SEGMENT_STATE_UNSPECIFIED: _ClassVar[CatalogSegmentState]
    CATALOG_SEGMENT_STATE_REGISTERING: _ClassVar[CatalogSegmentState]
    CATALOG_SEGMENT_STATE_READY: _ClassVar[CatalogSegmentState]
    CATALOG_SEGMENT_STATE_FAILED: _ClassVar[CatalogSegmentState]

class CatalogEpisodeUse(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CATALOG_EPISODE_USE_UNSPECIFIED: _ClassVar[CatalogEpisodeUse]
    CATALOG_EPISODE_USE_TRAINING: _ClassVar[CatalogEpisodeUse]
    CATALOG_EPISODE_USE_EVALUATION: _ClassVar[CatalogEpisodeUse]

class CatalogEpisodeConformance(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CATALOG_EPISODE_CONFORMANCE_UNSPECIFIED: _ClassVar[CatalogEpisodeConformance]
    CATALOG_EPISODE_CONFORMANCE_LEGACY: _ClassVar[CatalogEpisodeConformance]
    CATALOG_EPISODE_CONFORMANCE_CONFORMANT: _ClassVar[CatalogEpisodeConformance]

class CatalogTransformKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CATALOG_TRANSFORM_KIND_UNSPECIFIED: _ClassVar[CatalogTransformKind]
    CATALOG_TRANSFORM_KIND_REGISTER: _ClassVar[CatalogTransformKind]
    CATALOG_TRANSFORM_KIND_BATCH_REGISTER: _ClassVar[CatalogTransformKind]
    CATALOG_TRANSFORM_KIND_ASSET_REGISTER: _ClassVar[CatalogTransformKind]
    CATALOG_TRANSFORM_KIND_CAPTURE_REGISTER: _ClassVar[CatalogTransformKind]
    CATALOG_TRANSFORM_KIND_POLICY_REGISTER: _ClassVar[CatalogTransformKind]
    CATALOG_TRANSFORM_KIND_TRAINING_CHECKPOINT_REGISTER: _ClassVar[CatalogTransformKind]
    CATALOG_TRANSFORM_KIND_EXPORT_CREDENTIAL_VALIDATE: _ClassVar[CatalogTransformKind]
    CATALOG_TRANSFORM_KIND_INGEST_CONVERT: _ClassVar[CatalogTransformKind]
    CATALOG_TRANSFORM_KIND_EXPORT: _ClassVar[CatalogTransformKind]
    CATALOG_TRANSFORM_KIND_RETENTION: _ClassVar[CatalogTransformKind]
    CATALOG_TRANSFORM_KIND_COMPACT: _ClassVar[CatalogTransformKind]
    CATALOG_TRANSFORM_KIND_REINDEX: _ClassVar[CatalogTransformKind]
    CATALOG_TRANSFORM_KIND_SEMANTIC_INDEX: _ClassVar[CatalogTransformKind]
    CATALOG_TRANSFORM_KIND_SEMANTIC_INDEX_SWEEP: _ClassVar[CatalogTransformKind]
    CATALOG_TRANSFORM_KIND_SEMANTIC_TASK_MAP: _ClassVar[CatalogTransformKind]

class CatalogOperationState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CATALOG_OPERATION_STATE_UNSPECIFIED: _ClassVar[CatalogOperationState]
    CATALOG_OPERATION_STATE_ACCEPTED: _ClassVar[CatalogOperationState]
    CATALOG_OPERATION_STATE_RUNNING: _ClassVar[CatalogOperationState]
    CATALOG_OPERATION_STATE_COMPLETED: _ClassVar[CatalogOperationState]
    CATALOG_OPERATION_STATE_FAILED: _ClassVar[CatalogOperationState]
    CATALOG_OPERATION_STATE_CANCELLED: _ClassVar[CatalogOperationState]

class CatalogRetentionClass(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CATALOG_RETENTION_CLASS_UNSPECIFIED: _ClassVar[CatalogRetentionClass]
    CATALOG_RETENTION_CLASS_RAW_FROZEN: _ClassVar[CatalogRetentionClass]
    CATALOG_RETENTION_CLASS_ARCHIVE: _ClassVar[CatalogRetentionClass]
    CATALOG_RETENTION_CLASS_MANAGED: _ClassVar[CatalogRetentionClass]
    CATALOG_RETENTION_CLASS_SCRATCH: _ClassVar[CatalogRetentionClass]

class CatalogExportTargetKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CATALOG_EXPORT_TARGET_KIND_UNSPECIFIED: _ClassVar[CatalogExportTargetKind]
    CATALOG_EXPORT_TARGET_KIND_R2: _ClassVar[CatalogExportTargetKind]
    CATALOG_EXPORT_TARGET_KIND_S3: _ClassVar[CatalogExportTargetKind]
    CATALOG_EXPORT_TARGET_KIND_GCS: _ClassVar[CatalogExportTargetKind]

class CatalogDeliveryFormat(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CATALOG_DELIVERY_FORMAT_UNSPECIFIED: _ClassVar[CatalogDeliveryFormat]
    CATALOG_DELIVERY_FORMAT_RRD_BUNDLE: _ClassVar[CatalogDeliveryFormat]
    CATALOG_DELIVERY_FORMAT_RERUN_BUNDLE: _ClassVar[CatalogDeliveryFormat]
    CATALOG_DELIVERY_FORMAT_MCAP_BUNDLE: _ClassVar[CatalogDeliveryFormat]
    CATALOG_DELIVERY_FORMAT_LEROBOT_V3: _ClassVar[CatalogDeliveryFormat]

class CatalogExportCredentialState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CATALOG_EXPORT_CREDENTIAL_STATE_UNSPECIFIED: _ClassVar[CatalogExportCredentialState]
    CATALOG_EXPORT_CREDENTIAL_STATE_PENDING: _ClassVar[CatalogExportCredentialState]
    CATALOG_EXPORT_CREDENTIAL_STATE_STORED: _ClassVar[CatalogExportCredentialState]
    CATALOG_EXPORT_CREDENTIAL_STATE_ACTIVE: _ClassVar[CatalogExportCredentialState]
    CATALOG_EXPORT_CREDENTIAL_STATE_RETIRED: _ClassVar[CatalogExportCredentialState]
    CATALOG_EXPORT_CREDENTIAL_STATE_INVALID: _ClassVar[CatalogExportCredentialState]

class CatalogLineageNodeKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CATALOG_LINEAGE_NODE_KIND_UNSPECIFIED: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_SOURCE: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_SEGMENT: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_DELIVERY: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_DATASET: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_TASK: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_DEPLOYMENT: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_ROBOT_APPLICATION: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_CAPABILITY_APPROVAL: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_WORLD_RUN: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_MEDIA: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_CAPTURE_SESSION: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_CAPTURE_ARTIFACT: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_EMBODIMENT: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_ACTION_INTERFACE: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_DEPLOYABLE_POLICY: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_TRAINING_CHECKPOINT: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_CORPUS: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_TRAINING_RUN: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_DATA_BATCH: _ClassVar[CatalogLineageNodeKind]
    CATALOG_LINEAGE_NODE_KIND_PIPELINE_RUN: _ClassVar[CatalogLineageNodeKind]
CATALOG_GRANT_ROLE_UNSPECIFIED: CatalogGrantRole
CATALOG_GRANT_ROLE_READER: CatalogGrantRole
CATALOG_GRANT_ROLE_WRITER: CatalogGrantRole
CATALOG_GRANT_ROLE_EXPORTER: CatalogGrantRole
CATALOG_GRANT_ROLE_OWNER: CatalogGrantRole
CATALOG_GRANT_ROLE_ADMIN: CatalogGrantRole
CATALOG_ENTRY_KIND_UNSPECIFIED: CatalogEntryKind
CATALOG_ENTRY_KIND_DATASET: CatalogEntryKind
CATALOG_ENTRY_KIND_TABLE: CatalogEntryKind
CATALOG_ENTRY_KIND_EMBODIMENT: CatalogEntryKind
CATALOG_ENTRY_KIND_ASSET_PACK: CatalogEntryKind
CATALOG_ENTRY_KIND_PART: CatalogEntryKind
CATALOG_ENTRY_KIND_CORPUS: CatalogEntryKind
CATALOG_ENTRY_KIND_DEPLOYABLE_POLICY: CatalogEntryKind
CATALOG_ENTRY_KIND_TRAINING_CHECKPOINT: CatalogEntryKind
CATALOG_ENTRY_KIND_ACTION_INTERFACE: CatalogEntryKind
CATALOG_ENTRY_KIND_ROBOT_APPLICATION: CatalogEntryKind
CATALOG_ENTRY_KIND_CAPABILITY_APPROVAL: CatalogEntryKind
CATALOG_ENTRY_KIND_WORLD_RUN: CatalogEntryKind
CATALOG_ENTRY_KIND_EVAL_SUITE: CatalogEntryKind
CATALOG_ENTRY_KIND_POLICY_ARTIFACT: CatalogEntryKind
CATALOG_ENTRY_KIND_SCENE: CatalogEntryKind
CATALOG_ENTRY_KIND_ENVIRONMENT: CatalogEntryKind
CATALOG_ENTRY_KIND_OBJECT_ASSET: CatalogEntryKind
CATALOG_ENTRY_KIND_BASE_WEIGHTS: CatalogEntryKind
CATALOG_ENTRY_KIND_CAPTURE: CatalogEntryKind
CATALOG_ENTRY_KIND_DATASET_SNAPSHOT: CatalogEntryKind
CATALOG_DATASET_KIND_UNSPECIFIED: CatalogDatasetKind
CATALOG_DATASET_KIND_ONLINE: CatalogDatasetKind
CATALOG_DATASET_KIND_CORRECTION: CatalogDatasetKind
CATALOG_DATASET_KIND_DEMO: CatalogDatasetKind
CATALOG_ACTION_SOURCE_UNSPECIFIED: CatalogActionSource
CATALOG_ACTION_SOURCE_POLICY: CatalogActionSource
CATALOG_ACTION_SOURCE_HEURISTIC_OVERRIDE: CatalogActionSource
CATALOG_ACTION_SOURCE_AGENT: CatalogActionSource
CATALOG_ACTION_SOURCE_HUMAN_TELEOP: CatalogActionSource
CATALOG_ACTION_SOURCE_SCRIPTED: CatalogActionSource
CATALOG_ACTION_SOURCE_SIM_AUGMENTED: CatalogActionSource
CATALOG_SEGMENT_STATE_UNSPECIFIED: CatalogSegmentState
CATALOG_SEGMENT_STATE_REGISTERING: CatalogSegmentState
CATALOG_SEGMENT_STATE_READY: CatalogSegmentState
CATALOG_SEGMENT_STATE_FAILED: CatalogSegmentState
CATALOG_EPISODE_USE_UNSPECIFIED: CatalogEpisodeUse
CATALOG_EPISODE_USE_TRAINING: CatalogEpisodeUse
CATALOG_EPISODE_USE_EVALUATION: CatalogEpisodeUse
CATALOG_EPISODE_CONFORMANCE_UNSPECIFIED: CatalogEpisodeConformance
CATALOG_EPISODE_CONFORMANCE_LEGACY: CatalogEpisodeConformance
CATALOG_EPISODE_CONFORMANCE_CONFORMANT: CatalogEpisodeConformance
CATALOG_TRANSFORM_KIND_UNSPECIFIED: CatalogTransformKind
CATALOG_TRANSFORM_KIND_REGISTER: CatalogTransformKind
CATALOG_TRANSFORM_KIND_BATCH_REGISTER: CatalogTransformKind
CATALOG_TRANSFORM_KIND_ASSET_REGISTER: CatalogTransformKind
CATALOG_TRANSFORM_KIND_CAPTURE_REGISTER: CatalogTransformKind
CATALOG_TRANSFORM_KIND_POLICY_REGISTER: CatalogTransformKind
CATALOG_TRANSFORM_KIND_TRAINING_CHECKPOINT_REGISTER: CatalogTransformKind
CATALOG_TRANSFORM_KIND_EXPORT_CREDENTIAL_VALIDATE: CatalogTransformKind
CATALOG_TRANSFORM_KIND_INGEST_CONVERT: CatalogTransformKind
CATALOG_TRANSFORM_KIND_EXPORT: CatalogTransformKind
CATALOG_TRANSFORM_KIND_RETENTION: CatalogTransformKind
CATALOG_TRANSFORM_KIND_COMPACT: CatalogTransformKind
CATALOG_TRANSFORM_KIND_REINDEX: CatalogTransformKind
CATALOG_TRANSFORM_KIND_SEMANTIC_INDEX: CatalogTransformKind
CATALOG_TRANSFORM_KIND_SEMANTIC_INDEX_SWEEP: CatalogTransformKind
CATALOG_TRANSFORM_KIND_SEMANTIC_TASK_MAP: CatalogTransformKind
CATALOG_OPERATION_STATE_UNSPECIFIED: CatalogOperationState
CATALOG_OPERATION_STATE_ACCEPTED: CatalogOperationState
CATALOG_OPERATION_STATE_RUNNING: CatalogOperationState
CATALOG_OPERATION_STATE_COMPLETED: CatalogOperationState
CATALOG_OPERATION_STATE_FAILED: CatalogOperationState
CATALOG_OPERATION_STATE_CANCELLED: CatalogOperationState
CATALOG_RETENTION_CLASS_UNSPECIFIED: CatalogRetentionClass
CATALOG_RETENTION_CLASS_RAW_FROZEN: CatalogRetentionClass
CATALOG_RETENTION_CLASS_ARCHIVE: CatalogRetentionClass
CATALOG_RETENTION_CLASS_MANAGED: CatalogRetentionClass
CATALOG_RETENTION_CLASS_SCRATCH: CatalogRetentionClass
CATALOG_EXPORT_TARGET_KIND_UNSPECIFIED: CatalogExportTargetKind
CATALOG_EXPORT_TARGET_KIND_R2: CatalogExportTargetKind
CATALOG_EXPORT_TARGET_KIND_S3: CatalogExportTargetKind
CATALOG_EXPORT_TARGET_KIND_GCS: CatalogExportTargetKind
CATALOG_DELIVERY_FORMAT_UNSPECIFIED: CatalogDeliveryFormat
CATALOG_DELIVERY_FORMAT_RRD_BUNDLE: CatalogDeliveryFormat
CATALOG_DELIVERY_FORMAT_RERUN_BUNDLE: CatalogDeliveryFormat
CATALOG_DELIVERY_FORMAT_MCAP_BUNDLE: CatalogDeliveryFormat
CATALOG_DELIVERY_FORMAT_LEROBOT_V3: CatalogDeliveryFormat
CATALOG_EXPORT_CREDENTIAL_STATE_UNSPECIFIED: CatalogExportCredentialState
CATALOG_EXPORT_CREDENTIAL_STATE_PENDING: CatalogExportCredentialState
CATALOG_EXPORT_CREDENTIAL_STATE_STORED: CatalogExportCredentialState
CATALOG_EXPORT_CREDENTIAL_STATE_ACTIVE: CatalogExportCredentialState
CATALOG_EXPORT_CREDENTIAL_STATE_RETIRED: CatalogExportCredentialState
CATALOG_EXPORT_CREDENTIAL_STATE_INVALID: CatalogExportCredentialState
CATALOG_LINEAGE_NODE_KIND_UNSPECIFIED: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_SOURCE: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_SEGMENT: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_DELIVERY: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_DATASET: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_TASK: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_DEPLOYMENT: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_ROBOT_APPLICATION: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_CAPABILITY_APPROVAL: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_WORLD_RUN: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_MEDIA: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_CAPTURE_SESSION: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_CAPTURE_ARTIFACT: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_EMBODIMENT: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_ACTION_INTERFACE: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_DEPLOYABLE_POLICY: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_TRAINING_CHECKPOINT: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_CORPUS: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_TRAINING_RUN: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_DATA_BATCH: CatalogLineageNodeKind
CATALOG_LINEAGE_NODE_KIND_PIPELINE_RUN: CatalogLineageNodeKind

class GetCatalogAccessRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CatalogGrant(_message.Message):
    __slots__ = ("scope", "role")
    SCOPE_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    scope: str
    role: CatalogGrantRole
    def __init__(self, scope: _Optional[str] = ..., role: _Optional[_Union[CatalogGrantRole, str]] = ...) -> None: ...

class GetCatalogAccessResponse(_message.Message):
    __slots__ = ("subject", "tenant_slug", "scopes")
    SUBJECT_FIELD_NUMBER: _ClassVar[int]
    TENANT_SLUG_FIELD_NUMBER: _ClassVar[int]
    SCOPES_FIELD_NUMBER: _ClassVar[int]
    subject: str
    tenant_slug: str
    scopes: _containers.RepeatedCompositeFieldContainer[CatalogGrant]
    def __init__(self, subject: _Optional[str] = ..., tenant_slug: _Optional[str] = ..., scopes: _Optional[_Iterable[_Union[CatalogGrant, _Mapping]]] = ...) -> None: ...

class GetCatalogOverviewRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CatalogTenant(_message.Message):
    __slots__ = ("id", "slug", "display_name")
    ID_FIELD_NUMBER: _ClassVar[int]
    SLUG_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    id: str
    slug: str
    display_name: str
    def __init__(self, id: _Optional[str] = ..., slug: _Optional[str] = ..., display_name: _Optional[str] = ...) -> None: ...

class CatalogKpis(_message.Message):
    __slots__ = ("datasets", "segments", "total_bytes", "tables", "assets", "running_transforms")
    DATASETS_FIELD_NUMBER: _ClassVar[int]
    SEGMENTS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_BYTES_FIELD_NUMBER: _ClassVar[int]
    TABLES_FIELD_NUMBER: _ClassVar[int]
    ASSETS_FIELD_NUMBER: _ClassVar[int]
    RUNNING_TRANSFORMS_FIELD_NUMBER: _ClassVar[int]
    datasets: int
    segments: int
    total_bytes: int
    tables: int
    assets: int
    running_transforms: int
    def __init__(self, datasets: _Optional[int] = ..., segments: _Optional[int] = ..., total_bytes: _Optional[int] = ..., tables: _Optional[int] = ..., assets: _Optional[int] = ..., running_transforms: _Optional[int] = ...) -> None: ...

class CatalogOverviewEntry(_message.Message):
    __slots__ = ("id", "name", "kind", "segment_count", "size_bytes", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_COUNT_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    kind: CatalogEntryKind
    segment_count: int
    size_bytes: int
    updated_at: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., kind: _Optional[_Union[CatalogEntryKind, str]] = ..., segment_count: _Optional[int] = ..., size_bytes: _Optional[int] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class GetCatalogOverviewResponse(_message.Message):
    __slots__ = ("tenant", "kpis", "entries")
    TENANT_FIELD_NUMBER: _ClassVar[int]
    KPIS_FIELD_NUMBER: _ClassVar[int]
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    tenant: CatalogTenant
    kpis: CatalogKpis
    entries: _containers.RepeatedCompositeFieldContainer[CatalogOverviewEntry]
    def __init__(self, tenant: _Optional[_Union[CatalogTenant, _Mapping]] = ..., kpis: _Optional[_Union[CatalogKpis, _Mapping]] = ..., entries: _Optional[_Iterable[_Union[CatalogOverviewEntry, _Mapping]]] = ...) -> None: ...

class GetDatasetDetailRequest(_message.Message):
    __slots__ = ("name",)
    NAME_FIELD_NUMBER: _ClassVar[int]
    name: str
    def __init__(self, name: _Optional[str] = ...) -> None: ...

class CatalogRetention(_message.Message):
    __slots__ = ("name", "ttl_days")
    NAME_FIELD_NUMBER: _ClassVar[int]
    CLASS_FIELD_NUMBER: _ClassVar[int]
    TTL_DAYS_FIELD_NUMBER: _ClassVar[int]
    name: str
    ttl_days: int
    def __init__(self, name: _Optional[str] = ..., ttl_days: _Optional[int] = ..., **kwargs) -> None: ...

class CatalogLayer(_message.Message):
    __slots__ = ("layer", "object_key", "sha256", "size_bytes", "rrd_version", "registered_at")
    LAYER_FIELD_NUMBER: _ClassVar[int]
    OBJECT_KEY_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    RRD_VERSION_FIELD_NUMBER: _ClassVar[int]
    REGISTERED_AT_FIELD_NUMBER: _ClassVar[int]
    layer: str
    object_key: str
    sha256: str
    size_bytes: int
    rrd_version: str
    registered_at: _timestamp_pb2.Timestamp
    def __init__(self, layer: _Optional[str] = ..., object_key: _Optional[str] = ..., sha256: _Optional[str] = ..., size_bytes: _Optional[int] = ..., rrd_version: _Optional[str] = ..., registered_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class CatalogSegmentIndex(_message.Message):
    __slots__ = ("timelines", "entity_paths", "component_count", "indexer_version", "indexed_at")
    class TimelinesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _struct_pb2.Struct
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...
    TIMELINES_FIELD_NUMBER: _ClassVar[int]
    ENTITY_PATHS_FIELD_NUMBER: _ClassVar[int]
    COMPONENT_COUNT_FIELD_NUMBER: _ClassVar[int]
    INDEXER_VERSION_FIELD_NUMBER: _ClassVar[int]
    INDEXED_AT_FIELD_NUMBER: _ClassVar[int]
    timelines: _containers.MessageMap[str, _struct_pb2.Struct]
    entity_paths: _containers.RepeatedScalarFieldContainer[str]
    component_count: int
    indexer_version: int
    indexed_at: _timestamp_pb2.Timestamp
    def __init__(self, timelines: _Optional[_Mapping[str, _struct_pb2.Struct]] = ..., entity_paths: _Optional[_Iterable[str]] = ..., component_count: _Optional[int] = ..., indexer_version: _Optional[int] = ..., indexed_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class CatalogSegment(_message.Message):
    __slots__ = ("segment_id", "status", "registered_at", "source_uri", "provenance", "action_sources", "dataset_kinds", "episode_use", "data_version", "embodiment_id", "action_interface_name", "action_interface_id", "rrd_schema", "conformance_status", "camera_calibration_sha256", "duration_s", "row_count", "size_bytes", "layers", "index")
    SEGMENT_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REGISTERED_AT_FIELD_NUMBER: _ClassVar[int]
    SOURCE_URI_FIELD_NUMBER: _ClassVar[int]
    PROVENANCE_FIELD_NUMBER: _ClassVar[int]
    ACTION_SOURCES_FIELD_NUMBER: _ClassVar[int]
    DATASET_KINDS_FIELD_NUMBER: _ClassVar[int]
    EPISODE_USE_FIELD_NUMBER: _ClassVar[int]
    DATA_VERSION_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ACTION_INTERFACE_NAME_FIELD_NUMBER: _ClassVar[int]
    ACTION_INTERFACE_ID_FIELD_NUMBER: _ClassVar[int]
    RRD_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    CONFORMANCE_STATUS_FIELD_NUMBER: _ClassVar[int]
    CAMERA_CALIBRATION_SHA256_FIELD_NUMBER: _ClassVar[int]
    DURATION_S_FIELD_NUMBER: _ClassVar[int]
    ROW_COUNT_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    LAYERS_FIELD_NUMBER: _ClassVar[int]
    INDEX_FIELD_NUMBER: _ClassVar[int]
    segment_id: str
    status: CatalogSegmentState
    registered_at: _timestamp_pb2.Timestamp
    source_uri: str
    provenance: _struct_pb2.Struct
    action_sources: _containers.RepeatedScalarFieldContainer[CatalogActionSource]
    dataset_kinds: _containers.RepeatedScalarFieldContainer[CatalogDatasetKind]
    episode_use: CatalogEpisodeUse
    data_version: str
    embodiment_id: str
    action_interface_name: str
    action_interface_id: str
    rrd_schema: str
    conformance_status: CatalogEpisodeConformance
    camera_calibration_sha256: _containers.RepeatedScalarFieldContainer[str]
    duration_s: float
    row_count: int
    size_bytes: int
    layers: _containers.RepeatedCompositeFieldContainer[CatalogLayer]
    index: CatalogSegmentIndex
    def __init__(self, segment_id: _Optional[str] = ..., status: _Optional[_Union[CatalogSegmentState, str]] = ..., registered_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., source_uri: _Optional[str] = ..., provenance: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., action_sources: _Optional[_Iterable[_Union[CatalogActionSource, str]]] = ..., dataset_kinds: _Optional[_Iterable[_Union[CatalogDatasetKind, str]]] = ..., episode_use: _Optional[_Union[CatalogEpisodeUse, str]] = ..., data_version: _Optional[str] = ..., embodiment_id: _Optional[str] = ..., action_interface_name: _Optional[str] = ..., action_interface_id: _Optional[str] = ..., rrd_schema: _Optional[str] = ..., conformance_status: _Optional[_Union[CatalogEpisodeConformance, str]] = ..., camera_calibration_sha256: _Optional[_Iterable[str]] = ..., duration_s: _Optional[float] = ..., row_count: _Optional[int] = ..., size_bytes: _Optional[int] = ..., layers: _Optional[_Iterable[_Union[CatalogLayer, _Mapping]]] = ..., index: _Optional[_Union[CatalogSegmentIndex, _Mapping]] = ...) -> None: ...

class CatalogArrowField(_message.Message):
    __slots__ = ("entity", "archetype", "component", "type", "static")
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    ARCHETYPE_FIELD_NUMBER: _ClassVar[int]
    COMPONENT_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    STATIC_FIELD_NUMBER: _ClassVar[int]
    entity: str
    archetype: str
    component: str
    type: str
    static: bool
    def __init__(self, entity: _Optional[str] = ..., archetype: _Optional[str] = ..., component: _Optional[str] = ..., type: _Optional[str] = ..., static: _Optional[bool] = ...) -> None: ...

class CatalogDatasetDetail(_message.Message):
    __slots__ = ("id", "name", "updated_at", "exclusive", "schema_id", "default_blueprint", "retention", "segments", "arrow_schema")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    EXCLUSIVE_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_ID_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_BLUEPRINT_FIELD_NUMBER: _ClassVar[int]
    RETENTION_FIELD_NUMBER: _ClassVar[int]
    SEGMENTS_FIELD_NUMBER: _ClassVar[int]
    ARROW_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    updated_at: _timestamp_pb2.Timestamp
    exclusive: bool
    schema_id: str
    default_blueprint: str
    retention: CatalogRetention
    segments: _containers.RepeatedCompositeFieldContainer[CatalogSegment]
    arrow_schema: _containers.RepeatedCompositeFieldContainer[CatalogArrowField]
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., exclusive: _Optional[bool] = ..., schema_id: _Optional[str] = ..., default_blueprint: _Optional[str] = ..., retention: _Optional[_Union[CatalogRetention, _Mapping]] = ..., segments: _Optional[_Iterable[_Union[CatalogSegment, _Mapping]]] = ..., arrow_schema: _Optional[_Iterable[_Union[CatalogArrowField, _Mapping]]] = ...) -> None: ...

class GetDatasetDetailResponse(_message.Message):
    __slots__ = ("dataset",)
    DATASET_FIELD_NUMBER: _ClassVar[int]
    dataset: CatalogDatasetDetail
    def __init__(self, dataset: _Optional[_Union[CatalogDatasetDetail, _Mapping]] = ...) -> None: ...

class ListCatalogTransformsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CatalogTransformRun(_message.Message):
    __slots__ = ("id", "workflow_id", "kind", "status", "started_at", "finished_at", "inputs", "outputs", "versions")
    ID_FIELD_NUMBER: _ClassVar[int]
    WORKFLOW_ID_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    FINISHED_AT_FIELD_NUMBER: _ClassVar[int]
    INPUTS_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    VERSIONS_FIELD_NUMBER: _ClassVar[int]
    id: str
    workflow_id: str
    kind: CatalogTransformKind
    status: CatalogOperationState
    started_at: _timestamp_pb2.Timestamp
    finished_at: _timestamp_pb2.Timestamp
    inputs: _struct_pb2.Struct
    outputs: _struct_pb2.Struct
    versions: _struct_pb2.Struct
    def __init__(self, id: _Optional[str] = ..., workflow_id: _Optional[str] = ..., kind: _Optional[_Union[CatalogTransformKind, str]] = ..., status: _Optional[_Union[CatalogOperationState, str]] = ..., started_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., finished_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., inputs: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., outputs: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., versions: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class CatalogDailyCount(_message.Message):
    __slots__ = ("date", "count")
    DATE_FIELD_NUMBER: _ClassVar[int]
    COUNT_FIELD_NUMBER: _ClassVar[int]
    date: str
    count: int
    def __init__(self, date: _Optional[str] = ..., count: _Optional[int] = ...) -> None: ...

class ListCatalogTransformsResponse(_message.Message):
    __slots__ = ("runs", "daily_registrations")
    RUNS_FIELD_NUMBER: _ClassVar[int]
    DAILY_REGISTRATIONS_FIELD_NUMBER: _ClassVar[int]
    runs: _containers.RepeatedCompositeFieldContainer[CatalogTransformRun]
    daily_registrations: _containers.RepeatedCompositeFieldContainer[CatalogDailyCount]
    def __init__(self, runs: _Optional[_Iterable[_Union[CatalogTransformRun, _Mapping]]] = ..., daily_registrations: _Optional[_Iterable[_Union[CatalogDailyCount, _Mapping]]] = ...) -> None: ...

class ListExportTargetsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CatalogExportCredential(_message.Message):
    __slots__ = ("id", "state", "provider_identity", "created_at", "stored_at", "validated_at", "activated_at", "retired_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_IDENTITY_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    STORED_AT_FIELD_NUMBER: _ClassVar[int]
    VALIDATED_AT_FIELD_NUMBER: _ClassVar[int]
    ACTIVATED_AT_FIELD_NUMBER: _ClassVar[int]
    RETIRED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    state: CatalogExportCredentialState
    provider_identity: str
    created_at: _timestamp_pb2.Timestamp
    stored_at: _timestamp_pb2.Timestamp
    validated_at: _timestamp_pb2.Timestamp
    activated_at: _timestamp_pb2.Timestamp
    retired_at: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., state: _Optional[_Union[CatalogExportCredentialState, str]] = ..., provider_identity: _Optional[str] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., stored_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., validated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., activated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., retired_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class CatalogExportTarget(_message.Message):
    __slots__ = ("id", "name", "kind", "endpoint", "bucket", "output_format", "delivery_prefix", "active_credential")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    ENDPOINT_FIELD_NUMBER: _ClassVar[int]
    BUCKET_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_FORMAT_FIELD_NUMBER: _ClassVar[int]
    DELIVERY_PREFIX_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_CREDENTIAL_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    kind: CatalogExportTargetKind
    endpoint: str
    bucket: str
    output_format: CatalogDeliveryFormat
    delivery_prefix: str
    active_credential: CatalogExportCredential
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., kind: _Optional[_Union[CatalogExportTargetKind, str]] = ..., endpoint: _Optional[str] = ..., bucket: _Optional[str] = ..., output_format: _Optional[_Union[CatalogDeliveryFormat, str]] = ..., delivery_prefix: _Optional[str] = ..., active_credential: _Optional[_Union[CatalogExportCredential, _Mapping]] = ...) -> None: ...

class ListExportTargetsResponse(_message.Message):
    __slots__ = ("targets",)
    TARGETS_FIELD_NUMBER: _ClassVar[int]
    targets: _containers.RepeatedCompositeFieldContainer[CatalogExportTarget]
    def __init__(self, targets: _Optional[_Iterable[_Union[CatalogExportTarget, _Mapping]]] = ...) -> None: ...

class CreateExportTargetRequest(_message.Message):
    __slots__ = ("name", "kind", "endpoint", "bucket", "output_format", "delivery_prefix")
    NAME_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    ENDPOINT_FIELD_NUMBER: _ClassVar[int]
    BUCKET_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_FORMAT_FIELD_NUMBER: _ClassVar[int]
    DELIVERY_PREFIX_FIELD_NUMBER: _ClassVar[int]
    name: str
    kind: CatalogExportTargetKind
    endpoint: str
    bucket: str
    output_format: CatalogDeliveryFormat
    delivery_prefix: str
    def __init__(self, name: _Optional[str] = ..., kind: _Optional[_Union[CatalogExportTargetKind, str]] = ..., endpoint: _Optional[str] = ..., bucket: _Optional[str] = ..., output_format: _Optional[_Union[CatalogDeliveryFormat, str]] = ..., delivery_prefix: _Optional[str] = ...) -> None: ...

class CreateExportTargetResponse(_message.Message):
    __slots__ = ("target",)
    TARGET_FIELD_NUMBER: _ClassVar[int]
    target: CatalogExportTarget
    def __init__(self, target: _Optional[_Union[CatalogExportTarget, _Mapping]] = ...) -> None: ...

class SearchCatalogRequest(_message.Message):
    __slots__ = ("query", "dataset_kinds", "action_sources", "embodiment_id", "data_version", "entity_path", "status", "registered_after", "registered_before", "min_size_bytes", "max_size_bytes", "limit")
    QUERY_FIELD_NUMBER: _ClassVar[int]
    DATASET_KINDS_FIELD_NUMBER: _ClassVar[int]
    ACTION_SOURCES_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_VERSION_FIELD_NUMBER: _ClassVar[int]
    ENTITY_PATH_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REGISTERED_AFTER_FIELD_NUMBER: _ClassVar[int]
    REGISTERED_BEFORE_FIELD_NUMBER: _ClassVar[int]
    MIN_SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    MAX_SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    query: str
    dataset_kinds: _containers.RepeatedScalarFieldContainer[CatalogDatasetKind]
    action_sources: _containers.RepeatedScalarFieldContainer[CatalogActionSource]
    embodiment_id: str
    data_version: str
    entity_path: str
    status: CatalogSegmentState
    registered_after: _timestamp_pb2.Timestamp
    registered_before: _timestamp_pb2.Timestamp
    min_size_bytes: int
    max_size_bytes: int
    limit: int
    def __init__(self, query: _Optional[str] = ..., dataset_kinds: _Optional[_Iterable[_Union[CatalogDatasetKind, str]]] = ..., action_sources: _Optional[_Iterable[_Union[CatalogActionSource, str]]] = ..., embodiment_id: _Optional[str] = ..., data_version: _Optional[str] = ..., entity_path: _Optional[str] = ..., status: _Optional[_Union[CatalogSegmentState, str]] = ..., registered_after: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., registered_before: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., min_size_bytes: _Optional[int] = ..., max_size_bytes: _Optional[int] = ..., limit: _Optional[int] = ...) -> None: ...

class CatalogSearchDatasetHit(_message.Message):
    __slots__ = ("id", "name", "kind", "segment_count", "size_bytes", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_COUNT_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    kind: CatalogEntryKind
    segment_count: int
    size_bytes: int
    updated_at: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., kind: _Optional[_Union[CatalogEntryKind, str]] = ..., segment_count: _Optional[int] = ..., size_bytes: _Optional[int] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class CatalogSearchSegmentHit(_message.Message):
    __slots__ = ("dataset_id", "dataset_name", "segment_id", "status", "dataset_kinds", "action_sources", "embodiment_id", "data_version", "registered_at", "size_bytes", "row_count", "duration_s", "entity_paths")
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    DATASET_NAME_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    DATASET_KINDS_FIELD_NUMBER: _ClassVar[int]
    ACTION_SOURCES_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_VERSION_FIELD_NUMBER: _ClassVar[int]
    REGISTERED_AT_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    ROW_COUNT_FIELD_NUMBER: _ClassVar[int]
    DURATION_S_FIELD_NUMBER: _ClassVar[int]
    ENTITY_PATHS_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    dataset_name: str
    segment_id: str
    status: CatalogSegmentState
    dataset_kinds: _containers.RepeatedScalarFieldContainer[CatalogDatasetKind]
    action_sources: _containers.RepeatedScalarFieldContainer[CatalogActionSource]
    embodiment_id: str
    data_version: str
    registered_at: _timestamp_pb2.Timestamp
    size_bytes: int
    row_count: int
    duration_s: float
    entity_paths: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, dataset_id: _Optional[str] = ..., dataset_name: _Optional[str] = ..., segment_id: _Optional[str] = ..., status: _Optional[_Union[CatalogSegmentState, str]] = ..., dataset_kinds: _Optional[_Iterable[_Union[CatalogDatasetKind, str]]] = ..., action_sources: _Optional[_Iterable[_Union[CatalogActionSource, str]]] = ..., embodiment_id: _Optional[str] = ..., data_version: _Optional[str] = ..., registered_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., size_bytes: _Optional[int] = ..., row_count: _Optional[int] = ..., duration_s: _Optional[float] = ..., entity_paths: _Optional[_Iterable[str]] = ...) -> None: ...

class CatalogSearchFacet(_message.Message):
    __slots__ = ("value", "count")
    VALUE_FIELD_NUMBER: _ClassVar[int]
    COUNT_FIELD_NUMBER: _ClassVar[int]
    value: str
    count: int
    def __init__(self, value: _Optional[str] = ..., count: _Optional[int] = ...) -> None: ...

class CatalogSearchFacetGroup(_message.Message):
    __slots__ = ("facets",)
    FACETS_FIELD_NUMBER: _ClassVar[int]
    facets: _containers.RepeatedCompositeFieldContainer[CatalogSearchFacet]
    def __init__(self, facets: _Optional[_Iterable[_Union[CatalogSearchFacet, _Mapping]]] = ...) -> None: ...

class SearchCatalogResponse(_message.Message):
    __slots__ = ("datasets", "segments", "total_segments", "facets")
    class FacetsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: CatalogSearchFacetGroup
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[CatalogSearchFacetGroup, _Mapping]] = ...) -> None: ...
    DATASETS_FIELD_NUMBER: _ClassVar[int]
    SEGMENTS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_SEGMENTS_FIELD_NUMBER: _ClassVar[int]
    FACETS_FIELD_NUMBER: _ClassVar[int]
    datasets: _containers.RepeatedCompositeFieldContainer[CatalogSearchDatasetHit]
    segments: _containers.RepeatedCompositeFieldContainer[CatalogSearchSegmentHit]
    total_segments: int
    facets: _containers.MessageMap[str, CatalogSearchFacetGroup]
    def __init__(self, datasets: _Optional[_Iterable[_Union[CatalogSearchDatasetHit, _Mapping]]] = ..., segments: _Optional[_Iterable[_Union[CatalogSearchSegmentHit, _Mapping]]] = ..., total_segments: _Optional[int] = ..., facets: _Optional[_Mapping[str, CatalogSearchFacetGroup]] = ...) -> None: ...

class ListCatalogOperationsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CatalogOperationView(_message.Message):
    __slots__ = ("id", "workflow_id", "kind", "status", "started_at", "finished_at", "elapsed_s", "inputs", "outputs")
    ID_FIELD_NUMBER: _ClassVar[int]
    WORKFLOW_ID_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    FINISHED_AT_FIELD_NUMBER: _ClassVar[int]
    ELAPSED_S_FIELD_NUMBER: _ClassVar[int]
    INPUTS_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    id: str
    workflow_id: str
    kind: CatalogTransformKind
    status: CatalogOperationState
    started_at: _timestamp_pb2.Timestamp
    finished_at: _timestamp_pb2.Timestamp
    elapsed_s: float
    inputs: _struct_pb2.Struct
    outputs: _struct_pb2.Struct
    def __init__(self, id: _Optional[str] = ..., workflow_id: _Optional[str] = ..., kind: _Optional[_Union[CatalogTransformKind, str]] = ..., status: _Optional[_Union[CatalogOperationState, str]] = ..., started_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., finished_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., elapsed_s: _Optional[float] = ..., inputs: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., outputs: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class ListCatalogOperationsResponse(_message.Message):
    __slots__ = ("running", "recent")
    RUNNING_FIELD_NUMBER: _ClassVar[int]
    RECENT_FIELD_NUMBER: _ClassVar[int]
    running: _containers.RepeatedCompositeFieldContainer[CatalogOperationView]
    recent: _containers.RepeatedCompositeFieldContainer[CatalogOperationView]
    def __init__(self, running: _Optional[_Iterable[_Union[CatalogOperationView, _Mapping]]] = ..., recent: _Optional[_Iterable[_Union[CatalogOperationView, _Mapping]]] = ...) -> None: ...

class GetDatasetLineageRequest(_message.Message):
    __slots__ = ("name",)
    NAME_FIELD_NUMBER: _ClassVar[int]
    name: str
    def __init__(self, name: _Optional[str] = ...) -> None: ...

class CatalogLineageNode(_message.Message):
    __slots__ = ("ref", "kind", "label")
    REF_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    ref: str
    kind: CatalogLineageNodeKind
    label: str
    def __init__(self, ref: _Optional[str] = ..., kind: _Optional[_Union[CatalogLineageNodeKind, str]] = ..., label: _Optional[str] = ...) -> None: ...

class CatalogLineageEdge(_message.Message):
    __slots__ = ("relation", "parent", "child", "workflow_id", "detail")
    RELATION_FIELD_NUMBER: _ClassVar[int]
    PARENT_FIELD_NUMBER: _ClassVar[int]
    CHILD_FIELD_NUMBER: _ClassVar[int]
    WORKFLOW_ID_FIELD_NUMBER: _ClassVar[int]
    DETAIL_FIELD_NUMBER: _ClassVar[int]
    relation: str
    parent: str
    child: str
    workflow_id: str
    detail: _struct_pb2.Struct
    def __init__(self, relation: _Optional[str] = ..., parent: _Optional[str] = ..., child: _Optional[str] = ..., workflow_id: _Optional[str] = ..., detail: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class GetDatasetLineageResponse(_message.Message):
    __slots__ = ("dataset", "nodes", "edges", "upstream_count", "downstream_count")
    DATASET_FIELD_NUMBER: _ClassVar[int]
    NODES_FIELD_NUMBER: _ClassVar[int]
    EDGES_FIELD_NUMBER: _ClassVar[int]
    UPSTREAM_COUNT_FIELD_NUMBER: _ClassVar[int]
    DOWNSTREAM_COUNT_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    nodes: _containers.RepeatedCompositeFieldContainer[CatalogLineageNode]
    edges: _containers.RepeatedCompositeFieldContainer[CatalogLineageEdge]
    upstream_count: int
    downstream_count: int
    def __init__(self, dataset: _Optional[str] = ..., nodes: _Optional[_Iterable[_Union[CatalogLineageNode, _Mapping]]] = ..., edges: _Optional[_Iterable[_Union[CatalogLineageEdge, _Mapping]]] = ..., upstream_count: _Optional[int] = ..., downstream_count: _Optional[int] = ...) -> None: ...

class GetRetentionOverviewRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CatalogRetentionPolicy(_message.Message):
    __slots__ = ("name", "ttl_days", "dataset_count")
    NAME_FIELD_NUMBER: _ClassVar[int]
    CLASS_FIELD_NUMBER: _ClassVar[int]
    TTL_DAYS_FIELD_NUMBER: _ClassVar[int]
    DATASET_COUNT_FIELD_NUMBER: _ClassVar[int]
    name: str
    ttl_days: int
    dataset_count: int
    def __init__(self, name: _Optional[str] = ..., ttl_days: _Optional[int] = ..., dataset_count: _Optional[int] = ..., **kwargs) -> None: ...

class CatalogGovernanceRow(_message.Message):
    __slots__ = ("id", "name", "exclusive", "retention_class", "ttl_days", "segment_count", "size_bytes", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    EXCLUSIVE_FIELD_NUMBER: _ClassVar[int]
    RETENTION_CLASS_FIELD_NUMBER: _ClassVar[int]
    TTL_DAYS_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_COUNT_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    exclusive: bool
    retention_class: CatalogRetentionClass
    ttl_days: int
    segment_count: int
    size_bytes: int
    updated_at: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., exclusive: _Optional[bool] = ..., retention_class: _Optional[_Union[CatalogRetentionClass, str]] = ..., ttl_days: _Optional[int] = ..., segment_count: _Optional[int] = ..., size_bytes: _Optional[int] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class GetRetentionOverviewResponse(_message.Message):
    __slots__ = ("policies", "datasets")
    POLICIES_FIELD_NUMBER: _ClassVar[int]
    DATASETS_FIELD_NUMBER: _ClassVar[int]
    policies: _containers.RepeatedCompositeFieldContainer[CatalogRetentionPolicy]
    datasets: _containers.RepeatedCompositeFieldContainer[CatalogGovernanceRow]
    def __init__(self, policies: _Optional[_Iterable[_Union[CatalogRetentionPolicy, _Mapping]]] = ..., datasets: _Optional[_Iterable[_Union[CatalogGovernanceRow, _Mapping]]] = ...) -> None: ...

class SetDatasetGovernanceRequest(_message.Message):
    __slots__ = ("name", "exclusive", "retention_class", "ttl_days")
    NAME_FIELD_NUMBER: _ClassVar[int]
    EXCLUSIVE_FIELD_NUMBER: _ClassVar[int]
    RETENTION_CLASS_FIELD_NUMBER: _ClassVar[int]
    TTL_DAYS_FIELD_NUMBER: _ClassVar[int]
    name: str
    exclusive: bool
    retention_class: CatalogRetentionClass
    ttl_days: int
    def __init__(self, name: _Optional[str] = ..., exclusive: _Optional[bool] = ..., retention_class: _Optional[_Union[CatalogRetentionClass, str]] = ..., ttl_days: _Optional[int] = ...) -> None: ...

class SetDatasetGovernanceResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
