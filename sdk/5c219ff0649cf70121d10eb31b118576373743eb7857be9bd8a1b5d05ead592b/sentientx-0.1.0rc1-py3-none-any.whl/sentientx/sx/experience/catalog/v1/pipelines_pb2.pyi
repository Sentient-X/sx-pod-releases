from buf.validate import validate_pb2 as _validate_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from sentientx.sx.operations.v1 import operations_pb2 as _operations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SchemaCompatibility(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SCHEMA_COMPATIBILITY_UNSPECIFIED: _ClassVar[SchemaCompatibility]
    SCHEMA_COMPATIBILITY_IDENTICAL: _ClassVar[SchemaCompatibility]
    SCHEMA_COMPATIBILITY_READ_COMPATIBLE: _ClassVar[SchemaCompatibility]
    SCHEMA_COMPATIBILITY_MIGRATION_REQUIRED: _ClassVar[SchemaCompatibility]
    SCHEMA_COMPATIBILITY_INCOMPATIBLE: _ClassVar[SchemaCompatibility]

class RunPhase(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    RUN_PHASE_UNSPECIFIED: _ClassVar[RunPhase]
    RUN_PHASE_PLANNING: _ClassVar[RunPhase]
    RUN_PHASE_WAITING_FOR_CAPACITY: _ClassVar[RunPhase]
    RUN_PHASE_EXECUTING: _ClassVar[RunPhase]
    RUN_PHASE_VALIDATING: _ClassVar[RunPhase]
    RUN_PHASE_PUBLISHING: _ClassVar[RunPhase]
    RUN_PHASE_CANCELLING: _ClassVar[RunPhase]
SCHEMA_COMPATIBILITY_UNSPECIFIED: SchemaCompatibility
SCHEMA_COMPATIBILITY_IDENTICAL: SchemaCompatibility
SCHEMA_COMPATIBILITY_READ_COMPATIBLE: SchemaCompatibility
SCHEMA_COMPATIBILITY_MIGRATION_REQUIRED: SchemaCompatibility
SCHEMA_COMPATIBILITY_INCOMPATIBLE: SchemaCompatibility
RUN_PHASE_UNSPECIFIED: RunPhase
RUN_PHASE_PLANNING: RunPhase
RUN_PHASE_WAITING_FOR_CAPACITY: RunPhase
RUN_PHASE_EXECUTING: RunPhase
RUN_PHASE_VALIDATING: RunPhase
RUN_PHASE_PUBLISHING: RunPhase
RUN_PHASE_CANCELLING: RunPhase

class PipelineInputBinding(_message.Message):
    __slots__ = ("input_name", "snapshot")
    INPUT_NAME_FIELD_NUMBER: _ClassVar[int]
    SNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    input_name: str
    snapshot: str
    def __init__(self, input_name: _Optional[str] = ..., snapshot: _Optional[str] = ...) -> None: ...

class PipelinePlan(_message.Message):
    __slots__ = ("canonical_pipeline", "inputs", "destination")
    CANONICAL_PIPELINE_FIELD_NUMBER: _ClassVar[int]
    INPUTS_FIELD_NUMBER: _ClassVar[int]
    DESTINATION_FIELD_NUMBER: _ClassVar[int]
    canonical_pipeline: bytes
    inputs: _containers.RepeatedCompositeFieldContainer[PipelineInputBinding]
    destination: str
    def __init__(self, canonical_pipeline: _Optional[bytes] = ..., inputs: _Optional[_Iterable[_Union[PipelineInputBinding, _Mapping]]] = ..., destination: _Optional[str] = ...) -> None: ...

class ResolvedInput(_message.Message):
    __slots__ = ("input_name", "snapshot", "schema_id", "members")
    INPUT_NAME_FIELD_NUMBER: _ClassVar[int]
    SNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_ID_FIELD_NUMBER: _ClassVar[int]
    MEMBERS_FIELD_NUMBER: _ClassVar[int]
    input_name: str
    snapshot: str
    schema_id: str
    members: int
    def __init__(self, input_name: _Optional[str] = ..., snapshot: _Optional[str] = ..., schema_id: _Optional[str] = ..., members: _Optional[int] = ...) -> None: ...

class PlanStage(_message.Message):
    __slots__ = ("node", "produces")
    NODE_FIELD_NUMBER: _ClassVar[int]
    PRODUCES_FIELD_NUMBER: _ClassVar[int]
    node: str
    produces: str
    def __init__(self, node: _Optional[str] = ..., produces: _Optional[str] = ...) -> None: ...

class AdmittedPlan(_message.Message):
    __slots__ = ("plan_digest", "inputs", "stages", "produces", "destination", "outlet")
    PLAN_DIGEST_FIELD_NUMBER: _ClassVar[int]
    INPUTS_FIELD_NUMBER: _ClassVar[int]
    STAGES_FIELD_NUMBER: _ClassVar[int]
    PRODUCES_FIELD_NUMBER: _ClassVar[int]
    DESTINATION_FIELD_NUMBER: _ClassVar[int]
    OUTLET_FIELD_NUMBER: _ClassVar[int]
    plan_digest: str
    inputs: _containers.RepeatedCompositeFieldContainer[ResolvedInput]
    stages: _containers.RepeatedCompositeFieldContainer[PlanStage]
    produces: str
    destination: str
    outlet: SchemaCompatibility
    def __init__(self, plan_digest: _Optional[str] = ..., inputs: _Optional[_Iterable[_Union[ResolvedInput, _Mapping]]] = ..., stages: _Optional[_Iterable[_Union[PlanStage, _Mapping]]] = ..., produces: _Optional[str] = ..., destination: _Optional[str] = ..., outlet: _Optional[_Union[SchemaCompatibility, str]] = ...) -> None: ...

class MeteredQuantity(_message.Message):
    __slots__ = ("meter", "quantity")
    METER_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    meter: str
    quantity: int
    def __init__(self, meter: _Optional[str] = ..., quantity: _Optional[int] = ...) -> None: ...

class PlanEstimate(_message.Message):
    __slots__ = ("members", "assumed_partition_seconds", "meter_version", "per_partition", "total", "assumptions")
    MEMBERS_FIELD_NUMBER: _ClassVar[int]
    ASSUMED_PARTITION_SECONDS_FIELD_NUMBER: _ClassVar[int]
    METER_VERSION_FIELD_NUMBER: _ClassVar[int]
    PER_PARTITION_FIELD_NUMBER: _ClassVar[int]
    TOTAL_FIELD_NUMBER: _ClassVar[int]
    ASSUMPTIONS_FIELD_NUMBER: _ClassVar[int]
    members: int
    assumed_partition_seconds: int
    meter_version: int
    per_partition: _containers.RepeatedCompositeFieldContainer[MeteredQuantity]
    total: _containers.RepeatedCompositeFieldContainer[MeteredQuantity]
    assumptions: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, members: _Optional[int] = ..., assumed_partition_seconds: _Optional[int] = ..., meter_version: _Optional[int] = ..., per_partition: _Optional[_Iterable[_Union[MeteredQuantity, _Mapping]]] = ..., total: _Optional[_Iterable[_Union[MeteredQuantity, _Mapping]]] = ..., assumptions: _Optional[_Iterable[str]] = ...) -> None: ...

class PipelineRun(_message.Message):
    __slots__ = ("metadata", "lifecycle", "plan_digest", "destination", "phase", "output_snapshot_id")
    METADATA_FIELD_NUMBER: _ClassVar[int]
    LIFECYCLE_FIELD_NUMBER: _ClassVar[int]
    PLAN_DIGEST_FIELD_NUMBER: _ClassVar[int]
    DESTINATION_FIELD_NUMBER: _ClassVar[int]
    PHASE_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_SNAPSHOT_ID_FIELD_NUMBER: _ClassVar[int]
    metadata: _operations_pb2.OperationMetadata
    lifecycle: _operations_pb2.OperationLifecycle
    plan_digest: str
    destination: str
    phase: RunPhase
    output_snapshot_id: str
    def __init__(self, metadata: _Optional[_Union[_operations_pb2.OperationMetadata, _Mapping]] = ..., lifecycle: _Optional[_Union[_operations_pb2.OperationLifecycle, _Mapping]] = ..., plan_digest: _Optional[str] = ..., destination: _Optional[str] = ..., phase: _Optional[_Union[RunPhase, str]] = ..., output_snapshot_id: _Optional[str] = ...) -> None: ...

class EstimatePlanRequest(_message.Message):
    __slots__ = ("plan", "assumed_partition_seconds")
    PLAN_FIELD_NUMBER: _ClassVar[int]
    ASSUMED_PARTITION_SECONDS_FIELD_NUMBER: _ClassVar[int]
    plan: PipelinePlan
    assumed_partition_seconds: int
    def __init__(self, plan: _Optional[_Union[PipelinePlan, _Mapping]] = ..., assumed_partition_seconds: _Optional[int] = ...) -> None: ...

class EstimatePlanResponse(_message.Message):
    __slots__ = ("estimate", "request")
    ESTIMATE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    estimate: PlanEstimate
    request: EstimatePlanRequest
    def __init__(self, estimate: _Optional[_Union[PlanEstimate, _Mapping]] = ..., request: _Optional[_Union[EstimatePlanRequest, _Mapping]] = ...) -> None: ...

class ValidatePlanRequest(_message.Message):
    __slots__ = ("plan",)
    PLAN_FIELD_NUMBER: _ClassVar[int]
    plan: PipelinePlan
    def __init__(self, plan: _Optional[_Union[PipelinePlan, _Mapping]] = ...) -> None: ...

class ValidatePlanResponse(_message.Message):
    __slots__ = ("plan", "request")
    PLAN_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    plan: AdmittedPlan
    request: ValidatePlanRequest
    def __init__(self, plan: _Optional[_Union[AdmittedPlan, _Mapping]] = ..., request: _Optional[_Union[ValidatePlanRequest, _Mapping]] = ...) -> None: ...

class SubmitRunRequest(_message.Message):
    __slots__ = ("plan",)
    PLAN_FIELD_NUMBER: _ClassVar[int]
    plan: PipelinePlan
    def __init__(self, plan: _Optional[_Union[PipelinePlan, _Mapping]] = ...) -> None: ...

class SubmitRunResponse(_message.Message):
    __slots__ = ("run", "request")
    RUN_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    run: PipelineRun
    request: SubmitRunRequest
    def __init__(self, run: _Optional[_Union[PipelineRun, _Mapping]] = ..., request: _Optional[_Union[SubmitRunRequest, _Mapping]] = ...) -> None: ...

class GetRunRequest(_message.Message):
    __slots__ = ("run",)
    RUN_FIELD_NUMBER: _ClassVar[int]
    run: _common_pb2.OperationRef
    def __init__(self, run: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class GetRunResponse(_message.Message):
    __slots__ = ("run", "request")
    RUN_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    run: PipelineRun
    request: GetRunRequest
    def __init__(self, run: _Optional[_Union[PipelineRun, _Mapping]] = ..., request: _Optional[_Union[GetRunRequest, _Mapping]] = ...) -> None: ...

class CancelRunRequest(_message.Message):
    __slots__ = ("run", "reason")
    RUN_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    run: _common_pb2.OperationRef
    reason: str
    def __init__(self, run: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., reason: _Optional[str] = ...) -> None: ...

class CancelRunResponse(_message.Message):
    __slots__ = ("run", "request")
    RUN_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    run: PipelineRun
    request: CancelRunRequest
    def __init__(self, run: _Optional[_Union[PipelineRun, _Mapping]] = ..., request: _Optional[_Union[CancelRunRequest, _Mapping]] = ...) -> None: ...

class GetPlanRequest(_message.Message):
    __slots__ = ("plan_digest",)
    PLAN_DIGEST_FIELD_NUMBER: _ClassVar[int]
    plan_digest: str
    def __init__(self, plan_digest: _Optional[str] = ...) -> None: ...

class GetPlanResponse(_message.Message):
    __slots__ = ("plan", "plan_digest", "request")
    PLAN_FIELD_NUMBER: _ClassVar[int]
    PLAN_DIGEST_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    plan: PipelinePlan
    plan_digest: str
    request: GetPlanRequest
    def __init__(self, plan: _Optional[_Union[PipelinePlan, _Mapping]] = ..., plan_digest: _Optional[str] = ..., request: _Optional[_Union[GetPlanRequest, _Mapping]] = ...) -> None: ...

class RunProgressReport(_message.Message):
    __slots__ = ("phase",)
    PHASE_FIELD_NUMBER: _ClassVar[int]
    phase: RunPhase
    def __init__(self, phase: _Optional[_Union[RunPhase, str]] = ...) -> None: ...

class RunPublishedReport(_message.Message):
    __slots__ = ("snapshot_id",)
    SNAPSHOT_ID_FIELD_NUMBER: _ClassVar[int]
    snapshot_id: str
    def __init__(self, snapshot_id: _Optional[str] = ...) -> None: ...

class RunFailedReport(_message.Message):
    __slots__ = ("failure",)
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    failure: _operations_pb2.OperationFailure
    def __init__(self, failure: _Optional[_Union[_operations_pb2.OperationFailure, _Mapping]] = ...) -> None: ...

class RunCancelledReport(_message.Message):
    __slots__ = ("reason",)
    REASON_FIELD_NUMBER: _ClassVar[int]
    reason: str
    def __init__(self, reason: _Optional[str] = ...) -> None: ...

class RunReport(_message.Message):
    __slots__ = ("progress", "published", "failed", "cancelled")
    PROGRESS_FIELD_NUMBER: _ClassVar[int]
    PUBLISHED_FIELD_NUMBER: _ClassVar[int]
    FAILED_FIELD_NUMBER: _ClassVar[int]
    CANCELLED_FIELD_NUMBER: _ClassVar[int]
    progress: RunProgressReport
    published: RunPublishedReport
    failed: RunFailedReport
    cancelled: RunCancelledReport
    def __init__(self, progress: _Optional[_Union[RunProgressReport, _Mapping]] = ..., published: _Optional[_Union[RunPublishedReport, _Mapping]] = ..., failed: _Optional[_Union[RunFailedReport, _Mapping]] = ..., cancelled: _Optional[_Union[RunCancelledReport, _Mapping]] = ...) -> None: ...

class ReportRunRequest(_message.Message):
    __slots__ = ("run", "report")
    RUN_FIELD_NUMBER: _ClassVar[int]
    REPORT_FIELD_NUMBER: _ClassVar[int]
    run: _common_pb2.OperationRef
    report: RunReport
    def __init__(self, run: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., report: _Optional[_Union[RunReport, _Mapping]] = ...) -> None: ...

class ReportRunResponse(_message.Message):
    __slots__ = ("run", "request")
    RUN_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    run: PipelineRun
    request: ReportRunRequest
    def __init__(self, run: _Optional[_Union[PipelineRun, _Mapping]] = ..., request: _Optional[_Union[ReportRunRequest, _Mapping]] = ...) -> None: ...

class PublishRunRequest(_message.Message):
    __slots__ = ("run",)
    RUN_FIELD_NUMBER: _ClassVar[int]
    run: _common_pb2.OperationRef
    def __init__(self, run: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class PublishRunResponse(_message.Message):
    __slots__ = ("run", "request")
    RUN_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    run: PipelineRun
    request: PublishRunRequest
    def __init__(self, run: _Optional[_Union[PipelineRun, _Mapping]] = ..., request: _Optional[_Union[PublishRunRequest, _Mapping]] = ...) -> None: ...
