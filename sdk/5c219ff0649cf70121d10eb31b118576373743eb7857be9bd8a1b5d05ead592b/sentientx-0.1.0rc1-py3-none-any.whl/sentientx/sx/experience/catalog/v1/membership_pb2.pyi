import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class DatasetScope(_message.Message):
    __slots__ = ("dataset_id", "dataset")
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    DATASET_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    dataset: str
    def __init__(self, dataset_id: _Optional[str] = ..., dataset: _Optional[str] = ...) -> None: ...

class SelectionScope(_message.Message):
    __slots__ = ("embodiment_id", "action_interface_id")
    EMBODIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ACTION_INTERFACE_ID_FIELD_NUMBER: _ClassVar[int]
    embodiment_id: str
    action_interface_id: str
    def __init__(self, embodiment_id: _Optional[str] = ..., action_interface_id: _Optional[str] = ...) -> None: ...

class DatasetSnapshot(_message.Message):
    __slots__ = ("id", "name", "dataset", "selection", "digest", "schema_id", "members", "member_bytes", "parts", "parent_id", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATASET_FIELD_NUMBER: _ClassVar[int]
    SELECTION_FIELD_NUMBER: _ClassVar[int]
    DIGEST_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_ID_FIELD_NUMBER: _ClassVar[int]
    MEMBERS_FIELD_NUMBER: _ClassVar[int]
    MEMBER_BYTES_FIELD_NUMBER: _ClassVar[int]
    PARTS_FIELD_NUMBER: _ClassVar[int]
    PARENT_ID_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    dataset: DatasetScope
    selection: SelectionScope
    digest: str
    schema_id: str
    members: int
    member_bytes: int
    parts: int
    parent_id: str
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., dataset: _Optional[_Union[DatasetScope, _Mapping]] = ..., selection: _Optional[_Union[SelectionScope, _Mapping]] = ..., digest: _Optional[str] = ..., schema_id: _Optional[str] = ..., members: _Optional[int] = ..., member_bytes: _Optional[int] = ..., parts: _Optional[int] = ..., parent_id: _Optional[str] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class SelectionMember(_message.Message):
    __slots__ = ("dataset", "segment_id")
    DATASET_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_ID_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    segment_id: str
    def __init__(self, dataset: _Optional[str] = ..., segment_id: _Optional[str] = ...) -> None: ...

class CorpusSnapshot(_message.Message):
    __slots__ = ("name", "sha256", "canonical_manifest")
    NAME_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    CANONICAL_MANIFEST_FIELD_NUMBER: _ClassVar[int]
    name: str
    sha256: str
    canonical_manifest: bytes
    def __init__(self, name: _Optional[str] = ..., sha256: _Optional[str] = ..., canonical_manifest: _Optional[bytes] = ...) -> None: ...

class CorpusResource(_message.Message):
    __slots__ = ("corpus", "id", "created_at")
    CORPUS_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    corpus: CorpusSnapshot
    id: str
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, corpus: _Optional[_Union[CorpusSnapshot, _Mapping]] = ..., id: _Optional[str] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class CorpusDomain(_message.Message):
    __slots__ = ("name", "snapshot", "weight")
    NAME_FIELD_NUMBER: _ClassVar[int]
    SNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    WEIGHT_FIELD_NUMBER: _ClassVar[int]
    name: str
    snapshot: str
    weight: float
    def __init__(self, name: _Optional[str] = ..., snapshot: _Optional[str] = ..., weight: _Optional[float] = ...) -> None: ...

class ObjectRead(_message.Message):
    __slots__ = ("sha256", "url")
    SHA256_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    sha256: str
    url: str
    def __init__(self, sha256: _Optional[str] = ..., url: _Optional[str] = ...) -> None: ...

class SnapshotDatasetRequest(_message.Message):
    __slots__ = ("dataset", "task")
    DATASET_FIELD_NUMBER: _ClassVar[int]
    TASK_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    task: _common_pb2.TaskContractRef
    def __init__(self, dataset: _Optional[str] = ..., task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ...) -> None: ...

class SnapshotDatasetResponse(_message.Message):
    __slots__ = ("corpus", "request")
    CORPUS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    corpus: CorpusSnapshot
    request: SnapshotDatasetRequest
    def __init__(self, corpus: _Optional[_Union[CorpusSnapshot, _Mapping]] = ..., request: _Optional[_Union[SnapshotDatasetRequest, _Mapping]] = ...) -> None: ...

class SnapshotSelectionRequest(_message.Message):
    __slots__ = ("members",)
    MEMBERS_FIELD_NUMBER: _ClassVar[int]
    members: _containers.RepeatedCompositeFieldContainer[SelectionMember]
    def __init__(self, members: _Optional[_Iterable[_Union[SelectionMember, _Mapping]]] = ...) -> None: ...

class SnapshotSelectionResponse(_message.Message):
    __slots__ = ("snapshot", "request")
    SNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    snapshot: DatasetSnapshot
    request: SnapshotSelectionRequest
    def __init__(self, snapshot: _Optional[_Union[DatasetSnapshot, _Mapping]] = ..., request: _Optional[_Union[SnapshotSelectionRequest, _Mapping]] = ...) -> None: ...

class TakeDatasetSnapshotRequest(_message.Message):
    __slots__ = ("dataset",)
    DATASET_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    def __init__(self, dataset: _Optional[str] = ...) -> None: ...

class TakeDatasetSnapshotResponse(_message.Message):
    __slots__ = ("snapshot", "request")
    SNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    snapshot: DatasetSnapshot
    request: TakeDatasetSnapshotRequest
    def __init__(self, snapshot: _Optional[_Union[DatasetSnapshot, _Mapping]] = ..., request: _Optional[_Union[TakeDatasetSnapshotRequest, _Mapping]] = ...) -> None: ...

class ListDatasetSnapshotsRequest(_message.Message):
    __slots__ = ("dataset",)
    DATASET_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    def __init__(self, dataset: _Optional[str] = ...) -> None: ...

class ListDatasetSnapshotsResponse(_message.Message):
    __slots__ = ("snapshots", "request")
    SNAPSHOTS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    snapshots: _containers.RepeatedCompositeFieldContainer[DatasetSnapshot]
    request: ListDatasetSnapshotsRequest
    def __init__(self, snapshots: _Optional[_Iterable[_Union[DatasetSnapshot, _Mapping]]] = ..., request: _Optional[_Union[ListDatasetSnapshotsRequest, _Mapping]] = ...) -> None: ...

class MoveDatasetHeadRequest(_message.Message):
    __slots__ = ("dataset", "snapshot_id")
    DATASET_FIELD_NUMBER: _ClassVar[int]
    SNAPSHOT_ID_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    snapshot_id: str
    def __init__(self, dataset: _Optional[str] = ..., snapshot_id: _Optional[str] = ...) -> None: ...

class MoveDatasetHeadResponse(_message.Message):
    __slots__ = ("head", "request")
    HEAD_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    head: DatasetSnapshot
    request: MoveDatasetHeadRequest
    def __init__(self, head: _Optional[_Union[DatasetSnapshot, _Mapping]] = ..., request: _Optional[_Union[MoveDatasetHeadRequest, _Mapping]] = ...) -> None: ...

class GetSnapshotRequest(_message.Message):
    __slots__ = ("snapshot",)
    SNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    snapshot: str
    def __init__(self, snapshot: _Optional[str] = ...) -> None: ...

class GetSnapshotResponse(_message.Message):
    __slots__ = ("snapshot", "request")
    SNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    snapshot: DatasetSnapshot
    request: GetSnapshotRequest
    def __init__(self, snapshot: _Optional[_Union[DatasetSnapshot, _Mapping]] = ..., request: _Optional[_Union[GetSnapshotRequest, _Mapping]] = ...) -> None: ...

class GrantSnapshotObjectsRequest(_message.Message):
    __slots__ = ("snapshot", "part", "sha256")
    SNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    PART_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    snapshot: str
    part: int
    sha256: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, snapshot: _Optional[str] = ..., part: _Optional[int] = ..., sha256: _Optional[_Iterable[str]] = ...) -> None: ...

class GrantSnapshotObjectsResponse(_message.Message):
    __slots__ = ("objects", "expires_in", "request")
    OBJECTS_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_IN_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    objects: _containers.RepeatedCompositeFieldContainer[ObjectRead]
    expires_in: _duration_pb2.Duration
    request: GrantSnapshotObjectsRequest
    def __init__(self, objects: _Optional[_Iterable[_Union[ObjectRead, _Mapping]]] = ..., expires_in: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ..., request: _Optional[_Union[GrantSnapshotObjectsRequest, _Mapping]] = ...) -> None: ...

class CreateCorpusRequest(_message.Message):
    __slots__ = ("name", "domains")
    NAME_FIELD_NUMBER: _ClassVar[int]
    DOMAINS_FIELD_NUMBER: _ClassVar[int]
    name: str
    domains: _containers.RepeatedCompositeFieldContainer[CorpusDomain]
    def __init__(self, name: _Optional[str] = ..., domains: _Optional[_Iterable[_Union[CorpusDomain, _Mapping]]] = ...) -> None: ...

class CreateCorpusResponse(_message.Message):
    __slots__ = ("corpus", "request")
    CORPUS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    corpus: CorpusResource
    request: CreateCorpusRequest
    def __init__(self, corpus: _Optional[_Union[CorpusResource, _Mapping]] = ..., request: _Optional[_Union[CreateCorpusRequest, _Mapping]] = ...) -> None: ...

class GetCorpusRequest(_message.Message):
    __slots__ = ("name",)
    NAME_FIELD_NUMBER: _ClassVar[int]
    name: str
    def __init__(self, name: _Optional[str] = ...) -> None: ...

class GetCorpusResponse(_message.Message):
    __slots__ = ("corpus", "request")
    CORPUS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    corpus: CorpusResource
    request: GetCorpusRequest
    def __init__(self, corpus: _Optional[_Union[CorpusResource, _Mapping]] = ..., request: _Optional[_Union[GetCorpusRequest, _Mapping]] = ...) -> None: ...
