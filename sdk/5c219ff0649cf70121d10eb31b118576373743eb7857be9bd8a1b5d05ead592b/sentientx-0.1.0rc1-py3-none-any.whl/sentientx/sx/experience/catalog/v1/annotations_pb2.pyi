import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class AnnotationStage(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ANNOTATION_STAGE_UNSPECIFIED: _ClassVar[AnnotationStage]
    ANNOTATION_STAGE_ANNOTATOR: _ClassVar[AnnotationStage]
    ANNOTATION_STAGE_QA: _ClassVar[AnnotationStage]
    ANNOTATION_STAGE_CUSTOMER: _ClassVar[AnnotationStage]

class SubtaskStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SUBTASK_STATUS_UNSPECIFIED: _ClassVar[SubtaskStatus]
    SUBTASK_STATUS_SUCCESS: _ClassVar[SubtaskStatus]
    SUBTASK_STATUS_MISTAKE: _ClassVar[SubtaskStatus]
    SUBTASK_STATUS_UNCLEAR: _ClassVar[SubtaskStatus]
ANNOTATION_STAGE_UNSPECIFIED: AnnotationStage
ANNOTATION_STAGE_ANNOTATOR: AnnotationStage
ANNOTATION_STAGE_QA: AnnotationStage
ANNOTATION_STAGE_CUSTOMER: AnnotationStage
SUBTASK_STATUS_UNSPECIFIED: SubtaskStatus
SUBTASK_STATUS_SUCCESS: SubtaskStatus
SUBTASK_STATUS_MISTAKE: SubtaskStatus
SUBTASK_STATUS_UNCLEAR: SubtaskStatus

class SubtaskAction(_message.Message):
    __slots__ = ("part", "skill", "target_items", "target_location", "description")
    PART_FIELD_NUMBER: _ClassVar[int]
    SKILL_FIELD_NUMBER: _ClassVar[int]
    TARGET_ITEMS_FIELD_NUMBER: _ClassVar[int]
    TARGET_LOCATION_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    part: str
    skill: str
    target_items: _containers.RepeatedScalarFieldContainer[str]
    target_location: str
    description: str
    def __init__(self, part: _Optional[str] = ..., skill: _Optional[str] = ..., target_items: _Optional[_Iterable[str]] = ..., target_location: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class AnnotatedSubtask(_message.Message):
    __slots__ = ("ordinal", "t_start_ns", "t_end_ns", "status", "description", "actions")
    ORDINAL_FIELD_NUMBER: _ClassVar[int]
    T_START_NS_FIELD_NUMBER: _ClassVar[int]
    T_END_NS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    ACTIONS_FIELD_NUMBER: _ClassVar[int]
    ordinal: int
    t_start_ns: int
    t_end_ns: int
    status: SubtaskStatus
    description: str
    actions: _containers.RepeatedCompositeFieldContainer[SubtaskAction]
    def __init__(self, ordinal: _Optional[int] = ..., t_start_ns: _Optional[int] = ..., t_end_ns: _Optional[int] = ..., status: _Optional[_Union[SubtaskStatus, str]] = ..., description: _Optional[str] = ..., actions: _Optional[_Iterable[_Union[SubtaskAction, _Mapping]]] = ...) -> None: ...

class EpisodeAnnotation(_message.Message):
    __slots__ = ("episode_id", "stage", "task", "task_description", "scene", "scene_description", "success", "subtasks")
    EPISODE_ID_FIELD_NUMBER: _ClassVar[int]
    STAGE_FIELD_NUMBER: _ClassVar[int]
    TASK_FIELD_NUMBER: _ClassVar[int]
    TASK_DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SCENE_FIELD_NUMBER: _ClassVar[int]
    SCENE_DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    SUBTASKS_FIELD_NUMBER: _ClassVar[int]
    episode_id: str
    stage: AnnotationStage
    task: str
    task_description: str
    scene: str
    scene_description: str
    success: bool
    subtasks: _containers.RepeatedCompositeFieldContainer[AnnotatedSubtask]
    def __init__(self, episode_id: _Optional[str] = ..., stage: _Optional[_Union[AnnotationStage, str]] = ..., task: _Optional[str] = ..., task_description: _Optional[str] = ..., scene: _Optional[str] = ..., scene_description: _Optional[str] = ..., success: _Optional[bool] = ..., subtasks: _Optional[_Iterable[_Union[AnnotatedSubtask, _Mapping]]] = ...) -> None: ...

class SegmentAnnotationResource(_message.Message):
    __slots__ = ("dataset", "segment_id", "stage", "annotation_sha256", "annotated_at")
    DATASET_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_ID_FIELD_NUMBER: _ClassVar[int]
    STAGE_FIELD_NUMBER: _ClassVar[int]
    ANNOTATION_SHA256_FIELD_NUMBER: _ClassVar[int]
    ANNOTATED_AT_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    segment_id: str
    stage: AnnotationStage
    annotation_sha256: str
    annotated_at: _timestamp_pb2.Timestamp
    def __init__(self, dataset: _Optional[str] = ..., segment_id: _Optional[str] = ..., stage: _Optional[_Union[AnnotationStage, str]] = ..., annotation_sha256: _Optional[str] = ..., annotated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class RegisterAnnotationRequest(_message.Message):
    __slots__ = ("dataset", "segment_id", "annotation", "annotation_sha256")
    DATASET_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ANNOTATION_FIELD_NUMBER: _ClassVar[int]
    ANNOTATION_SHA256_FIELD_NUMBER: _ClassVar[int]
    dataset: str
    segment_id: str
    annotation: EpisodeAnnotation
    annotation_sha256: str
    def __init__(self, dataset: _Optional[str] = ..., segment_id: _Optional[str] = ..., annotation: _Optional[_Union[EpisodeAnnotation, _Mapping]] = ..., annotation_sha256: _Optional[str] = ...) -> None: ...

class RegisterAnnotationResponse(_message.Message):
    __slots__ = ("annotation", "request")
    ANNOTATION_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    annotation: SegmentAnnotationResource
    request: RegisterAnnotationRequest
    def __init__(self, annotation: _Optional[_Union[SegmentAnnotationResource, _Mapping]] = ..., request: _Optional[_Union[RegisterAnnotationRequest, _Mapping]] = ...) -> None: ...
