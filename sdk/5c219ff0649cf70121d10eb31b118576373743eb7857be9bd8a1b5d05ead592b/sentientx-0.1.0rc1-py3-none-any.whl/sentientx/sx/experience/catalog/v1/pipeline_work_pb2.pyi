import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from sentientx.sx.experience.catalog.v1 import pipelines_pb2 as _pipelines_pb2
from sentientx.sx.operations.v1 import operations_pb2 as _operations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Scarcity(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SCARCITY_UNSPECIFIED: _ClassVar[Scarcity]
    SCARCITY_CPUS: _ClassVar[Scarcity]
    SCARCITY_MEMORY_MIB: _ClassVar[Scarcity]
    SCARCITY_SCRATCH_MIB: _ClassVar[Scarcity]
    SCARCITY_ACCELERATOR: _ClassVar[Scarcity]
    SCARCITY_ACCELERATOR_MEMORY_MIB: _ClassVar[Scarcity]
    SCARCITY_CUSTOM: _ClassVar[Scarcity]
SCARCITY_UNSPECIFIED: Scarcity
SCARCITY_CPUS: Scarcity
SCARCITY_MEMORY_MIB: Scarcity
SCARCITY_SCRATCH_MIB: Scarcity
SCARCITY_ACCELERATOR: Scarcity
SCARCITY_ACCELERATOR_MEMORY_MIB: Scarcity
SCARCITY_CUSTOM: Scarcity

class WorkerCapacity(_message.Message):
    __slots__ = ("cpus", "memory_mib", "scratch_mib", "accelerators", "custom")
    CPUS_FIELD_NUMBER: _ClassVar[int]
    MEMORY_MIB_FIELD_NUMBER: _ClassVar[int]
    SCRATCH_MIB_FIELD_NUMBER: _ClassVar[int]
    ACCELERATORS_FIELD_NUMBER: _ClassVar[int]
    CUSTOM_FIELD_NUMBER: _ClassVar[int]
    cpus: float
    memory_mib: int
    scratch_mib: int
    accelerators: _containers.RepeatedCompositeFieldContainer[OfferedAccelerator]
    custom: _containers.RepeatedCompositeFieldContainer[OfferedResource]
    def __init__(self, cpus: _Optional[float] = ..., memory_mib: _Optional[int] = ..., scratch_mib: _Optional[int] = ..., accelerators: _Optional[_Iterable[_Union[OfferedAccelerator, _Mapping]]] = ..., custom: _Optional[_Iterable[_Union[OfferedResource, _Mapping]]] = ...) -> None: ...

class OfferedAccelerator(_message.Message):
    __slots__ = ("kind", "ray_resource", "count", "memory_mib", "runtime_abi")
    KIND_FIELD_NUMBER: _ClassVar[int]
    RAY_RESOURCE_FIELD_NUMBER: _ClassVar[int]
    COUNT_FIELD_NUMBER: _ClassVar[int]
    MEMORY_MIB_FIELD_NUMBER: _ClassVar[int]
    RUNTIME_ABI_FIELD_NUMBER: _ClassVar[int]
    kind: str
    ray_resource: str
    count: float
    memory_mib: int
    runtime_abi: str
    def __init__(self, kind: _Optional[str] = ..., ray_resource: _Optional[str] = ..., count: _Optional[float] = ..., memory_mib: _Optional[int] = ..., runtime_abi: _Optional[str] = ...) -> None: ...

class OfferedResource(_message.Message):
    __slots__ = ("name", "amount")
    NAME_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    name: str
    amount: float
    def __init__(self, name: _Optional[str] = ..., amount: _Optional[float] = ...) -> None: ...

class LeasedObject(_message.Message):
    __slots__ = ("input_name", "schema_id", "sha256", "size_bytes", "url")
    INPUT_NAME_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_ID_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    input_name: str
    schema_id: str
    sha256: str
    size_bytes: int
    url: str
    def __init__(self, input_name: _Optional[str] = ..., schema_id: _Optional[str] = ..., sha256: _Optional[str] = ..., size_bytes: _Optional[int] = ..., url: _Optional[str] = ...) -> None: ...

class PartitionLease(_message.Message):
    __slots__ = ("plan_digest", "ordinal", "generation", "attempt", "inputs", "output_url", "output_max_bytes", "report_url", "expires_at")
    PLAN_DIGEST_FIELD_NUMBER: _ClassVar[int]
    ORDINAL_FIELD_NUMBER: _ClassVar[int]
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    ATTEMPT_FIELD_NUMBER: _ClassVar[int]
    INPUTS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_URL_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_MAX_BYTES_FIELD_NUMBER: _ClassVar[int]
    REPORT_URL_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    plan_digest: str
    ordinal: int
    generation: int
    attempt: int
    inputs: _containers.RepeatedCompositeFieldContainer[LeasedObject]
    output_url: str
    output_max_bytes: int
    report_url: str
    expires_at: _timestamp_pb2.Timestamp
    def __init__(self, plan_digest: _Optional[str] = ..., ordinal: _Optional[int] = ..., generation: _Optional[int] = ..., attempt: _Optional[int] = ..., inputs: _Optional[_Iterable[_Union[LeasedObject, _Mapping]]] = ..., output_url: _Optional[str] = ..., output_max_bytes: _Optional[int] = ..., report_url: _Optional[str] = ..., expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ProducedMember(_message.Message):
    __slots__ = ("ordinal", "generation", "sha256", "size_bytes", "validator_digest", "report_sha256")
    ORDINAL_FIELD_NUMBER: _ClassVar[int]
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    VALIDATOR_DIGEST_FIELD_NUMBER: _ClassVar[int]
    REPORT_SHA256_FIELD_NUMBER: _ClassVar[int]
    ordinal: int
    generation: int
    sha256: str
    size_bytes: int
    validator_digest: str
    report_sha256: str
    def __init__(self, ordinal: _Optional[int] = ..., generation: _Optional[int] = ..., sha256: _Optional[str] = ..., size_bytes: _Optional[int] = ..., validator_digest: _Optional[str] = ..., report_sha256: _Optional[str] = ...) -> None: ...

class AdmittedMember(_message.Message):
    __slots__ = ("ordinal", "segment_id", "schema_id", "sha256", "size_bytes", "verdict", "replayed")
    ORDINAL_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_ID_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_ID_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    VERDICT_FIELD_NUMBER: _ClassVar[int]
    REPLAYED_FIELD_NUMBER: _ClassVar[int]
    ordinal: int
    segment_id: str
    schema_id: str
    sha256: str
    size_bytes: int
    verdict: _pipelines_pb2.SchemaCompatibility
    replayed: bool
    def __init__(self, ordinal: _Optional[int] = ..., segment_id: _Optional[str] = ..., schema_id: _Optional[str] = ..., sha256: _Optional[str] = ..., size_bytes: _Optional[int] = ..., verdict: _Optional[_Union[_pipelines_pb2.SchemaCompatibility, str]] = ..., replayed: _Optional[bool] = ...) -> None: ...

class PartitionFailure(_message.Message):
    __slots__ = ("ordinal", "generation", "failure")
    ORDINAL_FIELD_NUMBER: _ClassVar[int]
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    ordinal: int
    generation: int
    failure: _operations_pb2.OperationFailure
    def __init__(self, ordinal: _Optional[int] = ..., generation: _Optional[int] = ..., failure: _Optional[_Union[_operations_pb2.OperationFailure, _Mapping]] = ...) -> None: ...

class Shortfall(_message.Message):
    __slots__ = ("scarcity", "name", "needed", "offered")
    SCARCITY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NEEDED_FIELD_NUMBER: _ClassVar[int]
    OFFERED_FIELD_NUMBER: _ClassVar[int]
    scarcity: Scarcity
    name: str
    needed: float
    offered: float
    def __init__(self, scarcity: _Optional[_Union[Scarcity, str]] = ..., name: _Optional[str] = ..., needed: _Optional[float] = ..., offered: _Optional[float] = ...) -> None: ...

class RefusedCapacity(_message.Message):
    __slots__ = ("capacity", "last_holder", "refusals", "first_refused_at", "last_refused_at", "missing")
    CAPACITY_FIELD_NUMBER: _ClassVar[int]
    LAST_HOLDER_FIELD_NUMBER: _ClassVar[int]
    REFUSALS_FIELD_NUMBER: _ClassVar[int]
    FIRST_REFUSED_AT_FIELD_NUMBER: _ClassVar[int]
    LAST_REFUSED_AT_FIELD_NUMBER: _ClassVar[int]
    MISSING_FIELD_NUMBER: _ClassVar[int]
    capacity: WorkerCapacity
    last_holder: str
    refusals: int
    first_refused_at: _timestamp_pb2.Timestamp
    last_refused_at: _timestamp_pb2.Timestamp
    missing: _containers.RepeatedCompositeFieldContainer[Shortfall]
    def __init__(self, capacity: _Optional[_Union[WorkerCapacity, _Mapping]] = ..., last_holder: _Optional[str] = ..., refusals: _Optional[int] = ..., first_refused_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., last_refused_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., missing: _Optional[_Iterable[_Union[Shortfall, _Mapping]]] = ...) -> None: ...

class UnschedulableWork(_message.Message):
    __slots__ = ("runnable", "refused", "refused_omitted")
    RUNNABLE_FIELD_NUMBER: _ClassVar[int]
    REFUSED_FIELD_NUMBER: _ClassVar[int]
    REFUSED_OMITTED_FIELD_NUMBER: _ClassVar[int]
    runnable: int
    refused: _containers.RepeatedCompositeFieldContainer[RefusedCapacity]
    refused_omitted: int
    def __init__(self, runnable: _Optional[int] = ..., refused: _Optional[_Iterable[_Union[RefusedCapacity, _Mapping]]] = ..., refused_omitted: _Optional[int] = ...) -> None: ...

class MaterializePartitionsRequest(_message.Message):
    __slots__ = ("run",)
    RUN_FIELD_NUMBER: _ClassVar[int]
    run: _common_pb2.OperationRef
    def __init__(self, run: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class MaterializePartitionsResponse(_message.Message):
    __slots__ = ("partitions", "request")
    PARTITIONS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    partitions: int
    request: MaterializePartitionsRequest
    def __init__(self, partitions: _Optional[int] = ..., request: _Optional[_Union[MaterializePartitionsRequest, _Mapping]] = ...) -> None: ...

class ClaimPartitionRequest(_message.Message):
    __slots__ = ("run", "capacity")
    RUN_FIELD_NUMBER: _ClassVar[int]
    CAPACITY_FIELD_NUMBER: _ClassVar[int]
    run: _common_pb2.OperationRef
    capacity: WorkerCapacity
    def __init__(self, run: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., capacity: _Optional[_Union[WorkerCapacity, _Mapping]] = ...) -> None: ...

class NothingClaimable(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ClaimPartitionResponse(_message.Message):
    __slots__ = ("lease", "nothing_claimable", "request")
    LEASE_FIELD_NUMBER: _ClassVar[int]
    NOTHING_CLAIMABLE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    lease: PartitionLease
    nothing_claimable: NothingClaimable
    request: ClaimPartitionRequest
    def __init__(self, lease: _Optional[_Union[PartitionLease, _Mapping]] = ..., nothing_claimable: _Optional[_Union[NothingClaimable, _Mapping]] = ..., request: _Optional[_Union[ClaimPartitionRequest, _Mapping]] = ...) -> None: ...

class BeatPartitionRequest(_message.Message):
    __slots__ = ("run", "ordinal", "generation")
    RUN_FIELD_NUMBER: _ClassVar[int]
    ORDINAL_FIELD_NUMBER: _ClassVar[int]
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    run: _common_pb2.OperationRef
    ordinal: int
    generation: int
    def __init__(self, run: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., ordinal: _Optional[int] = ..., generation: _Optional[int] = ...) -> None: ...

class BeatPartitionResponse(_message.Message):
    __slots__ = ("expires_at", "request")
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    expires_at: _timestamp_pb2.Timestamp
    request: BeatPartitionRequest
    def __init__(self, expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., request: _Optional[_Union[BeatPartitionRequest, _Mapping]] = ...) -> None: ...

class CompletePartitionRequest(_message.Message):
    __slots__ = ("run", "member")
    RUN_FIELD_NUMBER: _ClassVar[int]
    MEMBER_FIELD_NUMBER: _ClassVar[int]
    run: _common_pb2.OperationRef
    member: ProducedMember
    def __init__(self, run: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., member: _Optional[_Union[ProducedMember, _Mapping]] = ...) -> None: ...

class CompletePartitionResponse(_message.Message):
    __slots__ = ("member", "request")
    MEMBER_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    member: AdmittedMember
    request: CompletePartitionRequest
    def __init__(self, member: _Optional[_Union[AdmittedMember, _Mapping]] = ..., request: _Optional[_Union[CompletePartitionRequest, _Mapping]] = ...) -> None: ...

class FailPartitionRequest(_message.Message):
    __slots__ = ("run", "failure")
    RUN_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    run: _common_pb2.OperationRef
    failure: PartitionFailure
    def __init__(self, run: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., failure: _Optional[_Union[PartitionFailure, _Mapping]] = ...) -> None: ...

class FailPartitionResponse(_message.Message):
    __slots__ = ("request",)
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    request: FailPartitionRequest
    def __init__(self, request: _Optional[_Union[FailPartitionRequest, _Mapping]] = ...) -> None: ...

class GetUnschedulableWorkRequest(_message.Message):
    __slots__ = ("run",)
    RUN_FIELD_NUMBER: _ClassVar[int]
    run: _common_pb2.OperationRef
    def __init__(self, run: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class GetUnschedulableWorkResponse(_message.Message):
    __slots__ = ("work", "request")
    WORK_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    work: UnschedulableWork
    request: GetUnschedulableWorkRequest
    def __init__(self, work: _Optional[_Union[UnschedulableWork, _Mapping]] = ..., request: _Optional[_Union[GetUnschedulableWorkRequest, _Mapping]] = ...) -> None: ...
