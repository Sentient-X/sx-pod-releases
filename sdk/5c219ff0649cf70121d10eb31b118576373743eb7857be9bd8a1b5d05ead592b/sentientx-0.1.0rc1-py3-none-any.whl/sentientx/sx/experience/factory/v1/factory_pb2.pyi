import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from sentientx.sx.operations.v1 import operations_pb2 as _operations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CaptureAnnotationMode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CAPTURE_ANNOTATION_MODE_UNSPECIFIED: _ClassVar[CaptureAnnotationMode]
    CAPTURE_ANNOTATION_MODE_NONE: _ClassVar[CaptureAnnotationMode]
    CAPTURE_ANNOTATION_MODE_BOUNDARY_HINTS: _ClassVar[CaptureAnnotationMode]

class CollectorPromptScope(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    COLLECTOR_PROMPT_SCOPE_UNSPECIFIED: _ClassVar[CollectorPromptScope]
    COLLECTOR_PROMPT_SCOPE_EPISODE: _ClassVar[CollectorPromptScope]
    COLLECTOR_PROMPT_SCOPE_BATCH: _ClassVar[CollectorPromptScope]

class TerminationReason(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TERMINATION_REASON_UNSPECIFIED: _ClassVar[TerminationReason]
    TERMINATION_REASON_SUCCESS: _ClassVar[TerminationReason]
    TERMINATION_REASON_FAILURE: _ClassVar[TerminationReason]
    TERMINATION_REASON_SAFETY_VIOLATION: _ClassVar[TerminationReason]
    TERMINATION_REASON_MAX_STEPS: _ClassVar[TerminationReason]
    TERMINATION_REASON_STOPPED: _ClassVar[TerminationReason]
    TERMINATION_REASON_POLICY_FAILURE: _ClassVar[TerminationReason]

class TaskVerdict(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TASK_VERDICT_UNSPECIFIED: _ClassVar[TaskVerdict]
    TASK_VERDICT_SATISFIED: _ClassVar[TaskVerdict]
    TASK_VERDICT_NOT_SATISFIED: _ClassVar[TaskVerdict]
    TASK_VERDICT_UNKNOWN: _ClassVar[TaskVerdict]

class CaptureOrderState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CAPTURE_ORDER_STATE_UNSPECIFIED: _ClassVar[CaptureOrderState]
    CAPTURE_ORDER_STATE_PENDING: _ClassVar[CaptureOrderState]
    CAPTURE_ORDER_STATE_COLLECTING: _ClassVar[CaptureOrderState]
    CAPTURE_ORDER_STATE_QA: _ClassVar[CaptureOrderState]
    CAPTURE_ORDER_STATE_DELIVERING: _ClassVar[CaptureOrderState]
    CAPTURE_ORDER_STATE_COMPLETE: _ClassVar[CaptureOrderState]
    CAPTURE_ORDER_STATE_CANCELLED: _ClassVar[CaptureOrderState]
    CAPTURE_ORDER_STATE_FAILED: _ClassVar[CaptureOrderState]

class DiversificationScheme(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DIVERSIFICATION_SCHEME_UNSPECIFIED: _ClassVar[DiversificationScheme]
    DIVERSIFICATION_SCHEME_COVERAGE_DESIGN: _ClassVar[DiversificationScheme]
    DIVERSIFICATION_SCHEME_FULL_FACTORIAL: _ClassVar[DiversificationScheme]
    DIVERSIFICATION_SCHEME_SCRIPTED: _ClassVar[DiversificationScheme]

class AdaptationKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ADAPTATION_KIND_UNSPECIFIED: _ClassVar[AdaptationKind]
    ADAPTATION_KIND_NONE: _ClassVar[AdaptationKind]
    ADAPTATION_KIND_FAILURE_SEEKING: _ClassVar[AdaptationKind]

class ObjectRole(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    OBJECT_ROLE_UNSPECIFIED: _ClassVar[ObjectRole]
    OBJECT_ROLE_FOCUS: _ClassVar[ObjectRole]
    OBJECT_ROLE_FIXTURE: _ClassVar[ObjectRole]
    OBJECT_ROLE_TOOL: _ClassVar[ObjectRole]
    OBJECT_ROLE_CONTAINER: _ClassVar[ObjectRole]
CAPTURE_ANNOTATION_MODE_UNSPECIFIED: CaptureAnnotationMode
CAPTURE_ANNOTATION_MODE_NONE: CaptureAnnotationMode
CAPTURE_ANNOTATION_MODE_BOUNDARY_HINTS: CaptureAnnotationMode
COLLECTOR_PROMPT_SCOPE_UNSPECIFIED: CollectorPromptScope
COLLECTOR_PROMPT_SCOPE_EPISODE: CollectorPromptScope
COLLECTOR_PROMPT_SCOPE_BATCH: CollectorPromptScope
TERMINATION_REASON_UNSPECIFIED: TerminationReason
TERMINATION_REASON_SUCCESS: TerminationReason
TERMINATION_REASON_FAILURE: TerminationReason
TERMINATION_REASON_SAFETY_VIOLATION: TerminationReason
TERMINATION_REASON_MAX_STEPS: TerminationReason
TERMINATION_REASON_STOPPED: TerminationReason
TERMINATION_REASON_POLICY_FAILURE: TerminationReason
TASK_VERDICT_UNSPECIFIED: TaskVerdict
TASK_VERDICT_SATISFIED: TaskVerdict
TASK_VERDICT_NOT_SATISFIED: TaskVerdict
TASK_VERDICT_UNKNOWN: TaskVerdict
CAPTURE_ORDER_STATE_UNSPECIFIED: CaptureOrderState
CAPTURE_ORDER_STATE_PENDING: CaptureOrderState
CAPTURE_ORDER_STATE_COLLECTING: CaptureOrderState
CAPTURE_ORDER_STATE_QA: CaptureOrderState
CAPTURE_ORDER_STATE_DELIVERING: CaptureOrderState
CAPTURE_ORDER_STATE_COMPLETE: CaptureOrderState
CAPTURE_ORDER_STATE_CANCELLED: CaptureOrderState
CAPTURE_ORDER_STATE_FAILED: CaptureOrderState
DIVERSIFICATION_SCHEME_UNSPECIFIED: DiversificationScheme
DIVERSIFICATION_SCHEME_COVERAGE_DESIGN: DiversificationScheme
DIVERSIFICATION_SCHEME_FULL_FACTORIAL: DiversificationScheme
DIVERSIFICATION_SCHEME_SCRIPTED: DiversificationScheme
ADAPTATION_KIND_UNSPECIFIED: AdaptationKind
ADAPTATION_KIND_NONE: AdaptationKind
ADAPTATION_KIND_FAILURE_SEEKING: AdaptationKind
OBJECT_ROLE_UNSPECIFIED: ObjectRole
OBJECT_ROLE_FOCUS: ObjectRole
OBJECT_ROLE_FIXTURE: ObjectRole
OBJECT_ROLE_TOOL: ObjectRole
OBJECT_ROLE_CONTAINER: ObjectRole

class BooleanPrompt(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SingleChoicePrompt(_message.Message):
    __slots__ = ("choices",)
    CHOICES_FIELD_NUMBER: _ClassVar[int]
    choices: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, choices: _Optional[_Iterable[str]] = ...) -> None: ...

class ShortTextPrompt(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CollectorPrompt(_message.Message):
    __slots__ = ("id", "label", "scope", "required", "boolean_prompt", "single_choice_prompt", "short_text_prompt")
    ID_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    SCOPE_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_FIELD_NUMBER: _ClassVar[int]
    BOOLEAN_PROMPT_FIELD_NUMBER: _ClassVar[int]
    SINGLE_CHOICE_PROMPT_FIELD_NUMBER: _ClassVar[int]
    SHORT_TEXT_PROMPT_FIELD_NUMBER: _ClassVar[int]
    id: str
    label: str
    scope: CollectorPromptScope
    required: bool
    boolean_prompt: BooleanPrompt
    single_choice_prompt: SingleChoicePrompt
    short_text_prompt: ShortTextPrompt
    def __init__(self, id: _Optional[str] = ..., label: _Optional[str] = ..., scope: _Optional[_Union[CollectorPromptScope, str]] = ..., required: _Optional[bool] = ..., boolean_prompt: _Optional[_Union[BooleanPrompt, _Mapping]] = ..., single_choice_prompt: _Optional[_Union[SingleChoicePrompt, _Mapping]] = ..., short_text_prompt: _Optional[_Union[ShortTextPrompt, _Mapping]] = ...) -> None: ...

class CapturePolicy(_message.Message):
    __slots__ = ("annotation_mode", "prompts")
    ANNOTATION_MODE_FIELD_NUMBER: _ClassVar[int]
    PROMPTS_FIELD_NUMBER: _ClassVar[int]
    annotation_mode: CaptureAnnotationMode
    prompts: _containers.RepeatedCompositeFieldContainer[CollectorPrompt]
    def __init__(self, annotation_mode: _Optional[_Union[CaptureAnnotationMode, str]] = ..., prompts: _Optional[_Iterable[_Union[CollectorPrompt, _Mapping]]] = ...) -> None: ...

class BooleanAnswer(_message.Message):
    __slots__ = ("value",)
    VALUE_FIELD_NUMBER: _ClassVar[int]
    value: bool
    def __init__(self, value: _Optional[bool] = ...) -> None: ...

class ChoiceAnswer(_message.Message):
    __slots__ = ("value",)
    VALUE_FIELD_NUMBER: _ClassVar[int]
    value: str
    def __init__(self, value: _Optional[str] = ...) -> None: ...

class TextAnswer(_message.Message):
    __slots__ = ("value",)
    VALUE_FIELD_NUMBER: _ClassVar[int]
    value: str
    def __init__(self, value: _Optional[str] = ...) -> None: ...

class CollectorAnswer(_message.Message):
    __slots__ = ("prompt_id", "boolean_answer", "choice_answer", "text_answer")
    PROMPT_ID_FIELD_NUMBER: _ClassVar[int]
    BOOLEAN_ANSWER_FIELD_NUMBER: _ClassVar[int]
    CHOICE_ANSWER_FIELD_NUMBER: _ClassVar[int]
    TEXT_ANSWER_FIELD_NUMBER: _ClassVar[int]
    prompt_id: str
    boolean_answer: BooleanAnswer
    choice_answer: ChoiceAnswer
    text_answer: TextAnswer
    def __init__(self, prompt_id: _Optional[str] = ..., boolean_answer: _Optional[_Union[BooleanAnswer, _Mapping]] = ..., choice_answer: _Optional[_Union[ChoiceAnswer, _Mapping]] = ..., text_answer: _Optional[_Union[TextAnswer, _Mapping]] = ...) -> None: ...

class TerminatedEpisode(_message.Message):
    __slots__ = ("reason", "verdict")
    REASON_FIELD_NUMBER: _ClassVar[int]
    VERDICT_FIELD_NUMBER: _ClassVar[int]
    reason: TerminationReason
    verdict: TaskVerdict
    def __init__(self, reason: _Optional[_Union[TerminationReason, str]] = ..., verdict: _Optional[_Union[TaskVerdict, str]] = ...) -> None: ...

class TruncatedEpisode(_message.Message):
    __slots__ = ("reason", "verdict")
    REASON_FIELD_NUMBER: _ClassVar[int]
    VERDICT_FIELD_NUMBER: _ClassVar[int]
    reason: TerminationReason
    verdict: TaskVerdict
    def __init__(self, reason: _Optional[_Union[TerminationReason, str]] = ..., verdict: _Optional[_Union[TaskVerdict, str]] = ...) -> None: ...

class EpisodeEnd(_message.Message):
    __slots__ = ("terminated", "truncated")
    TERMINATED_FIELD_NUMBER: _ClassVar[int]
    TRUNCATED_FIELD_NUMBER: _ClassVar[int]
    terminated: TerminatedEpisode
    truncated: TruncatedEpisode
    def __init__(self, terminated: _Optional[_Union[TerminatedEpisode, _Mapping]] = ..., truncated: _Optional[_Union[TruncatedEpisode, _Mapping]] = ...) -> None: ...

class SubtaskBoundaryHint(_message.Message):
    __slots__ = ("step_index", "occurrence", "recorded_at")
    STEP_INDEX_FIELD_NUMBER: _ClassVar[int]
    OCCURRENCE_FIELD_NUMBER: _ClassVar[int]
    RECORDED_AT_FIELD_NUMBER: _ClassVar[int]
    step_index: int
    occurrence: int
    recorded_at: _timestamp_pb2.Timestamp
    def __init__(self, step_index: _Optional[int] = ..., occurrence: _Optional[int] = ..., recorded_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class CaptureEpisodeReceipt(_message.Message):
    __slots__ = ("episode_id", "source_episode_index", "artifact_uri", "frame_count", "end", "attention", "note", "boundary_hints", "answers")
    EPISODE_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_EPISODE_INDEX_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_URI_FIELD_NUMBER: _ClassVar[int]
    FRAME_COUNT_FIELD_NUMBER: _ClassVar[int]
    END_FIELD_NUMBER: _ClassVar[int]
    ATTENTION_FIELD_NUMBER: _ClassVar[int]
    NOTE_FIELD_NUMBER: _ClassVar[int]
    BOUNDARY_HINTS_FIELD_NUMBER: _ClassVar[int]
    ANSWERS_FIELD_NUMBER: _ClassVar[int]
    episode_id: str
    source_episode_index: int
    artifact_uri: str
    frame_count: int
    end: EpisodeEnd
    attention: bool
    note: str
    boundary_hints: _containers.RepeatedCompositeFieldContainer[SubtaskBoundaryHint]
    answers: _containers.RepeatedCompositeFieldContainer[CollectorAnswer]
    def __init__(self, episode_id: _Optional[str] = ..., source_episode_index: _Optional[int] = ..., artifact_uri: _Optional[str] = ..., frame_count: _Optional[int] = ..., end: _Optional[_Union[EpisodeEnd, _Mapping]] = ..., attention: _Optional[bool] = ..., note: _Optional[str] = ..., boundary_hints: _Optional[_Iterable[_Union[SubtaskBoundaryHint, _Mapping]]] = ..., answers: _Optional[_Iterable[_Union[CollectorAnswer, _Mapping]]] = ...) -> None: ...

class CaptureSessionReceipt(_message.Message):
    __slots__ = ("schema_version", "session_id", "assignment_id", "task", "collector_id", "dataset_uri", "started_at", "finalized_at", "policy", "episodes", "answers")
    SCHEMA_VERSION_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    ASSIGNMENT_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_FIELD_NUMBER: _ClassVar[int]
    COLLECTOR_ID_FIELD_NUMBER: _ClassVar[int]
    DATASET_URI_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    FINALIZED_AT_FIELD_NUMBER: _ClassVar[int]
    POLICY_FIELD_NUMBER: _ClassVar[int]
    EPISODES_FIELD_NUMBER: _ClassVar[int]
    ANSWERS_FIELD_NUMBER: _ClassVar[int]
    schema_version: str
    session_id: str
    assignment_id: str
    task: _common_pb2.TaskContractRef
    collector_id: str
    dataset_uri: str
    started_at: _timestamp_pb2.Timestamp
    finalized_at: _timestamp_pb2.Timestamp
    policy: CapturePolicy
    episodes: _containers.RepeatedCompositeFieldContainer[CaptureEpisodeReceipt]
    answers: _containers.RepeatedCompositeFieldContainer[CollectorAnswer]
    def __init__(self, schema_version: _Optional[str] = ..., session_id: _Optional[str] = ..., assignment_id: _Optional[str] = ..., task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., collector_id: _Optional[str] = ..., dataset_uri: _Optional[str] = ..., started_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., finalized_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., policy: _Optional[_Union[CapturePolicy, _Mapping]] = ..., episodes: _Optional[_Iterable[_Union[CaptureEpisodeReceipt, _Mapping]]] = ..., answers: _Optional[_Iterable[_Union[CollectorAnswer, _Mapping]]] = ...) -> None: ...

class StartCaptureRequest(_message.Message):
    __slots__ = ("task", "embodiment_id", "episodes", "timeout", "policy")
    TASK_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    EPISODES_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    POLICY_FIELD_NUMBER: _ClassVar[int]
    task: _common_pb2.TaskContractRef
    embodiment_id: str
    episodes: int
    timeout: _duration_pb2.Duration
    policy: CapturePolicy
    def __init__(self, task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., embodiment_id: _Optional[str] = ..., episodes: _Optional[int] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ..., policy: _Optional[_Union[CapturePolicy, _Mapping]] = ...) -> None: ...

class StartCaptureResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: CaptureOperation
    def __init__(self, operation: _Optional[_Union[CaptureOperation, _Mapping]] = ...) -> None: ...

class ObjectDiversification(_message.Message):
    __slots__ = ("role", "instances", "justification")
    ROLE_FIELD_NUMBER: _ClassVar[int]
    INSTANCES_FIELD_NUMBER: _ClassVar[int]
    JUSTIFICATION_FIELD_NUMBER: _ClassVar[int]
    role: ObjectRole
    instances: _containers.RepeatedScalarFieldContainer[str]
    justification: str
    def __init__(self, role: _Optional[_Union[ObjectRole, str]] = ..., instances: _Optional[_Iterable[str]] = ..., justification: _Optional[str] = ...) -> None: ...

class DiversificationPlan(_message.Message):
    __slots__ = ("scheme", "budget", "adapt", "object_scheme")
    SCHEME_FIELD_NUMBER: _ClassVar[int]
    BUDGET_FIELD_NUMBER: _ClassVar[int]
    ADAPT_FIELD_NUMBER: _ClassVar[int]
    OBJECT_SCHEME_FIELD_NUMBER: _ClassVar[int]
    scheme: DiversificationScheme
    budget: int
    adapt: AdaptationKind
    object_scheme: ObjectDiversification
    def __init__(self, scheme: _Optional[_Union[DiversificationScheme, str]] = ..., budget: _Optional[int] = ..., adapt: _Optional[_Union[AdaptationKind, str]] = ..., object_scheme: _Optional[_Union[ObjectDiversification, _Mapping]] = ...) -> None: ...

class CaptureScope(_message.Message):
    __slots__ = ("scenes", "lighting", "subtasks", "diversification")
    SCENES_FIELD_NUMBER: _ClassVar[int]
    LIGHTING_FIELD_NUMBER: _ClassVar[int]
    SUBTASKS_FIELD_NUMBER: _ClassVar[int]
    DIVERSIFICATION_FIELD_NUMBER: _ClassVar[int]
    scenes: _containers.RepeatedScalarFieldContainer[str]
    lighting: _containers.RepeatedScalarFieldContainer[str]
    subtasks: _containers.RepeatedScalarFieldContainer[str]
    diversification: DiversificationPlan
    def __init__(self, scenes: _Optional[_Iterable[str]] = ..., lighting: _Optional[_Iterable[str]] = ..., subtasks: _Optional[_Iterable[str]] = ..., diversification: _Optional[_Union[DiversificationPlan, _Mapping]] = ...) -> None: ...

class CaptureOrder(_message.Message):
    __slots__ = ("order_id", "customer", "skill", "task", "state", "embodiment_id", "episodes_target", "episodes_completed", "scope", "created_at", "sla_due_at", "completed_at")
    ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    CUSTOMER_FIELD_NUMBER: _ClassVar[int]
    SKILL_FIELD_NUMBER: _ClassVar[int]
    TASK_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    EPISODES_TARGET_FIELD_NUMBER: _ClassVar[int]
    EPISODES_COMPLETED_FIELD_NUMBER: _ClassVar[int]
    SCOPE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    SLA_DUE_AT_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    order_id: str
    customer: str
    skill: str
    task: _common_pb2.TaskContractRef
    state: CaptureOrderState
    embodiment_id: str
    episodes_target: int
    episodes_completed: int
    scope: CaptureScope
    created_at: _timestamp_pb2.Timestamp
    sla_due_at: _timestamp_pb2.Timestamp
    completed_at: _timestamp_pb2.Timestamp
    def __init__(self, order_id: _Optional[str] = ..., customer: _Optional[str] = ..., skill: _Optional[str] = ..., task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., state: _Optional[_Union[CaptureOrderState, str]] = ..., embodiment_id: _Optional[str] = ..., episodes_target: _Optional[int] = ..., episodes_completed: _Optional[int] = ..., scope: _Optional[_Union[CaptureScope, _Mapping]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., sla_due_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., completed_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class GetCaptureOrderRequest(_message.Message):
    __slots__ = ("order_id",)
    ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    order_id: str
    def __init__(self, order_id: _Optional[str] = ...) -> None: ...

class GetCaptureOrderResponse(_message.Message):
    __slots__ = ("order",)
    ORDER_FIELD_NUMBER: _ClassVar[int]
    order: CaptureOrder
    def __init__(self, order: _Optional[_Union[CaptureOrder, _Mapping]] = ...) -> None: ...

class CaptureProgress(_message.Message):
    __slots__ = ("state", "episodes_target", "episodes_completed")
    STATE_FIELD_NUMBER: _ClassVar[int]
    EPISODES_TARGET_FIELD_NUMBER: _ClassVar[int]
    EPISODES_COMPLETED_FIELD_NUMBER: _ClassVar[int]
    state: CaptureOrderState
    episodes_target: int
    episodes_completed: int
    def __init__(self, state: _Optional[_Union[CaptureOrderState, str]] = ..., episodes_target: _Optional[int] = ..., episodes_completed: _Optional[int] = ...) -> None: ...

class CaptureOperation(_message.Message):
    __slots__ = ("metadata", "lifecycle", "capture_progress")
    METADATA_FIELD_NUMBER: _ClassVar[int]
    LIFECYCLE_FIELD_NUMBER: _ClassVar[int]
    CAPTURE_PROGRESS_FIELD_NUMBER: _ClassVar[int]
    metadata: _operations_pb2.OperationMetadata
    lifecycle: _operations_pb2.OperationLifecycle
    capture_progress: CaptureProgress
    def __init__(self, metadata: _Optional[_Union[_operations_pb2.OperationMetadata, _Mapping]] = ..., lifecycle: _Optional[_Union[_operations_pb2.OperationLifecycle, _Mapping]] = ..., capture_progress: _Optional[_Union[CaptureProgress, _Mapping]] = ...) -> None: ...

class CaptureOrderResult(_message.Message):
    __slots__ = ("order_id", "session_receipts")
    ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    SESSION_RECEIPTS_FIELD_NUMBER: _ClassVar[int]
    order_id: str
    session_receipts: _containers.RepeatedCompositeFieldContainer[CaptureSessionReceipt]
    def __init__(self, order_id: _Optional[str] = ..., session_receipts: _Optional[_Iterable[_Union[CaptureSessionReceipt, _Mapping]]] = ...) -> None: ...

class CaptureOperationResult(_message.Message):
    __slots__ = ("capture_order",)
    CAPTURE_ORDER_FIELD_NUMBER: _ClassVar[int]
    capture_order: CaptureOrderResult
    def __init__(self, capture_order: _Optional[_Union[CaptureOrderResult, _Mapping]] = ...) -> None: ...

class GetCaptureOperationRequest(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class GetCaptureOperationResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: CaptureOperation
    def __init__(self, operation: _Optional[_Union[CaptureOperation, _Mapping]] = ...) -> None: ...

class GetCaptureOperationUpdatesRequest(_message.Message):
    __slots__ = ("operation", "after_cursor", "limit", "wait_timeout")
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    AFTER_CURSOR_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    WAIT_TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    after_cursor: int
    limit: int
    wait_timeout: _duration_pb2.Duration
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., after_cursor: _Optional[int] = ..., limit: _Optional[int] = ..., wait_timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class CaptureOperationUpdatePage(_message.Message):
    __slots__ = ("updates", "next_cursor", "has_more")
    UPDATES_FIELD_NUMBER: _ClassVar[int]
    NEXT_CURSOR_FIELD_NUMBER: _ClassVar[int]
    HAS_MORE_FIELD_NUMBER: _ClassVar[int]
    updates: _containers.RepeatedCompositeFieldContainer[CaptureOperation]
    next_cursor: int
    has_more: bool
    def __init__(self, updates: _Optional[_Iterable[_Union[CaptureOperation, _Mapping]]] = ..., next_cursor: _Optional[int] = ..., has_more: _Optional[bool] = ...) -> None: ...

class GetCaptureOperationUpdatesResponse(_message.Message):
    __slots__ = ("page", "history_gap")
    PAGE_FIELD_NUMBER: _ClassVar[int]
    HISTORY_GAP_FIELD_NUMBER: _ClassVar[int]
    page: CaptureOperationUpdatePage
    history_gap: _operations_pb2.OperationHistoryGap
    def __init__(self, page: _Optional[_Union[CaptureOperationUpdatePage, _Mapping]] = ..., history_gap: _Optional[_Union[_operations_pb2.OperationHistoryGap, _Mapping]] = ...) -> None: ...

class GetCaptureOperationResultRequest(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class GetCaptureOperationResultResponse(_message.Message):
    __slots__ = ("result",)
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: CaptureOperationResult
    def __init__(self, result: _Optional[_Union[CaptureOperationResult, _Mapping]] = ...) -> None: ...

class CancelCaptureOperationRequest(_message.Message):
    __slots__ = ("operation", "reason")
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    reason: str
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., reason: _Optional[str] = ...) -> None: ...

class CancelCaptureOperationResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: CaptureOperation
    def __init__(self, operation: _Optional[_Union[CaptureOperation, _Mapping]] = ...) -> None: ...
