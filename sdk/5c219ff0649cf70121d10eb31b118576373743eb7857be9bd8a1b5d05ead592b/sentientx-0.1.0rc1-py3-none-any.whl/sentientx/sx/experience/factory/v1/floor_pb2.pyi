import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from sentientx.sx.experience.factory.v1 import factory_pb2 as _factory_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class FloorRole(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    FLOOR_ROLE_UNSPECIFIED: _ClassVar[FloorRole]
    FLOOR_ROLE_OPERATOR: _ClassVar[FloorRole]
    FLOOR_ROLE_FLOOR_MANAGER: _ClassVar[FloorRole]
    FLOOR_ROLE_ADMIN: _ClassVar[FloorRole]

class RigFamily(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    RIG_FAMILY_UNSPECIFIED: _ClassVar[RigFamily]
    RIG_FAMILY_YUBI: _ClassVar[RigFamily]
    RIG_FAMILY_TELEOP: _ClassVar[RigFamily]

class PodState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    POD_STATE_UNSPECIFIED: _ClassVar[PodState]
    POD_STATE_OFFLINE: _ClassVar[PodState]
    POD_STATE_IDLE: _ClassVar[PodState]
    POD_STATE_COLLECTING: _ClassVar[PodState]
    POD_STATE_MAINTENANCE: _ClassVar[PodState]
    POD_STATE_FAULT: _ClassVar[PodState]

class PodPool(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    POD_POOL_UNSPECIFIED: _ClassVar[PodPool]
    POD_POOL_CUSTOMER: _ClassVar[PodPool]
    POD_POOL_GENERAL: _ClassVar[PodPool]

class PodEgressIntent(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    POD_EGRESS_INTENT_UNSPECIFIED: _ClassVar[PodEgressIntent]
    POD_EGRESS_INTENT_PROVISION: _ClassVar[PodEgressIntent]
    POD_EGRESS_INTENT_WITHDRAW: _ClassVar[PodEgressIntent]

class PodEgressState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    POD_EGRESS_STATE_UNSPECIFIED: _ClassVar[PodEgressState]
    POD_EGRESS_STATE_DIRECT: _ClassVar[PodEgressState]
    POD_EGRESS_STATE_UNKNOWN: _ClassVar[PodEgressState]
    POD_EGRESS_STATE_PENDING: _ClassVar[PodEgressState]
    POD_EGRESS_STATE_READY: _ClassVar[PodEgressState]
    POD_EGRESS_STATE_REJECTED: _ClassVar[PodEgressState]
    POD_EGRESS_STATE_WITHDRAWN: _ClassVar[PodEgressState]

class TaskState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TASK_STATE_UNSPECIFIED: _ClassVar[TaskState]
    TASK_STATE_QUEUED: _ClassVar[TaskState]
    TASK_STATE_ACTIVE: _ClassVar[TaskState]
    TASK_STATE_PAUSED: _ClassVar[TaskState]
    TASK_STATE_DONE: _ClassVar[TaskState]

class OrderState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ORDER_STATE_UNSPECIFIED: _ClassVar[OrderState]
    ORDER_STATE_PENDING: _ClassVar[OrderState]
    ORDER_STATE_COLLECTING: _ClassVar[OrderState]
    ORDER_STATE_QA: _ClassVar[OrderState]
    ORDER_STATE_DELIVERING: _ClassVar[OrderState]
    ORDER_STATE_COMPLETE: _ClassVar[OrderState]
    ORDER_STATE_CANCELLED: _ClassVar[OrderState]
    ORDER_STATE_FAILED: _ClassVar[OrderState]

class CreatedVia(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CREATED_VIA_UNSPECIFIED: _ClassVar[CreatedVia]
    CREATED_VIA_UI: _ClassVar[CreatedVia]
    CREATED_VIA_MCP: _ClassVar[CreatedVia]

class Transport(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TRANSPORT_UNSPECIFIED: _ClassVar[Transport]
    TRANSPORT_NETWORK: _ClassVar[Transport]
    TRANSPORT_DRIVE: _ClassVar[Transport]

class Rigidity(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    RIGIDITY_UNSPECIFIED: _ClassVar[Rigidity]
    RIGIDITY_RIGID: _ClassVar[Rigidity]
    RIGIDITY_DEFORMABLE: _ClassVar[Rigidity]
    RIGIDITY_ARTICULATED: _ClassVar[Rigidity]

class EmbodimentSource(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EMBODIMENT_SOURCE_UNSPECIFIED: _ClassVar[EmbodimentSource]
    EMBODIMENT_SOURCE_BUILTIN: _ClassVar[EmbodimentSource]
    EMBODIMENT_SOURCE_GITHUB: _ClassVar[EmbodimentSource]
    EMBODIMENT_SOURCE_LINK: _ClassVar[EmbodimentSource]
    EMBODIMENT_SOURCE_UPLOAD: _ClassVar[EmbodimentSource]

class EmbodimentState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EMBODIMENT_STATE_UNSPECIFIED: _ClassVar[EmbodimentState]
    EMBODIMENT_STATE_READY: _ClassVar[EmbodimentState]
    EMBODIMENT_STATE_ERROR: _ClassVar[EmbodimentState]

class BatchState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    BATCH_STATE_UNSPECIFIED: _ClassVar[BatchState]
    BATCH_STATE_BUFFERING: _ClassVar[BatchState]
    BATCH_STATE_UPLOADING: _ClassVar[BatchState]
    BATCH_STATE_UPLOADED: _ClassVar[BatchState]
    BATCH_STATE_DRIVE_PREP: _ClassVar[BatchState]
    BATCH_STATE_SHIPPED: _ClassVar[BatchState]
    BATCH_STATE_RECEIVED: _ClassVar[BatchState]
    BATCH_STATE_VERIFIED: _ClassVar[BatchState]
    BATCH_STATE_REGISTERING: _ClassVar[BatchState]
    BATCH_STATE_READY: _ClassVar[BatchState]
    BATCH_STATE_FAILED: _ClassVar[BatchState]

class EpisodeDeliveryState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EPISODE_DELIVERY_STATE_UNSPECIFIED: _ClassVar[EpisodeDeliveryState]
    EPISODE_DELIVERY_STATE_AWAITING_SESSION_SEAL: _ClassVar[EpisodeDeliveryState]
    EPISODE_DELIVERY_STATE_AWAITING_ARTIFACT_SEAL: _ClassVar[EpisodeDeliveryState]
    EPISODE_DELIVERY_STATE_SEALED: _ClassVar[EpisodeDeliveryState]
    EPISODE_DELIVERY_STATE_STORED_NAS: _ClassVar[EpisodeDeliveryState]
    EPISODE_DELIVERY_STATE_REPLICATING: _ClassVar[EpisodeDeliveryState]
    EPISODE_DELIVERY_STATE_AWAITING_UPLOAD: _ClassVar[EpisodeDeliveryState]
    EPISODE_DELIVERY_STATE_UPLOADING: _ClassVar[EpisodeDeliveryState]
    EPISODE_DELIVERY_STATE_AWAITING_DRIVE: _ClassVar[EpisodeDeliveryState]
    EPISODE_DELIVERY_STATE_COPYING_TO_DRIVE: _ClassVar[EpisodeDeliveryState]
    EPISODE_DELIVERY_STATE_READY_TO_SHIP: _ClassVar[EpisodeDeliveryState]
    EPISODE_DELIVERY_STATE_IN_TRANSIT: _ClassVar[EpisodeDeliveryState]
    EPISODE_DELIVERY_STATE_RECEIVED: _ClassVar[EpisodeDeliveryState]
    EPISODE_DELIVERY_STATE_VERIFYING: _ClassVar[EpisodeDeliveryState]
    EPISODE_DELIVERY_STATE_REGISTERING_RAW: _ClassVar[EpisodeDeliveryState]
    EPISODE_DELIVERY_STATE_RAW_DURABLE: _ClassVar[EpisodeDeliveryState]
    EPISODE_DELIVERY_STATE_RETRYING: _ClassVar[EpisodeDeliveryState]
    EPISODE_DELIVERY_STATE_SOURCE_UNAVAILABLE: _ClassVar[EpisodeDeliveryState]

class ShipmentState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SHIPMENT_STATE_UNSPECIFIED: _ClassVar[ShipmentState]
    SHIPMENT_STATE_AWAITING_DRIVE: _ClassVar[ShipmentState]
    SHIPMENT_STATE_COPYING: _ClassVar[ShipmentState]
    SHIPMENT_STATE_READY_TO_DISPATCH: _ClassVar[ShipmentState]
    SHIPMENT_STATE_IN_TRANSIT: _ClassVar[ShipmentState]
    SHIPMENT_STATE_RECEIVED: _ClassVar[ShipmentState]
    SHIPMENT_STATE_VERIFYING: _ClassVar[ShipmentState]
    SHIPMENT_STATE_VERIFIED: _ClassVar[ShipmentState]

class CaptureArtifactFormat(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CAPTURE_ARTIFACT_FORMAT_UNSPECIFIED: _ClassVar[CaptureArtifactFormat]
    CAPTURE_ARTIFACT_FORMAT_MCAP: _ClassVar[CaptureArtifactFormat]
    CAPTURE_ARTIFACT_FORMAT_LEROBOT_V3_TAR: _ClassVar[CaptureArtifactFormat]
    CAPTURE_ARTIFACT_FORMAT_SIMULATION_JSON: _ClassVar[CaptureArtifactFormat]
FLOOR_ROLE_UNSPECIFIED: FloorRole
FLOOR_ROLE_OPERATOR: FloorRole
FLOOR_ROLE_FLOOR_MANAGER: FloorRole
FLOOR_ROLE_ADMIN: FloorRole
RIG_FAMILY_UNSPECIFIED: RigFamily
RIG_FAMILY_YUBI: RigFamily
RIG_FAMILY_TELEOP: RigFamily
POD_STATE_UNSPECIFIED: PodState
POD_STATE_OFFLINE: PodState
POD_STATE_IDLE: PodState
POD_STATE_COLLECTING: PodState
POD_STATE_MAINTENANCE: PodState
POD_STATE_FAULT: PodState
POD_POOL_UNSPECIFIED: PodPool
POD_POOL_CUSTOMER: PodPool
POD_POOL_GENERAL: PodPool
POD_EGRESS_INTENT_UNSPECIFIED: PodEgressIntent
POD_EGRESS_INTENT_PROVISION: PodEgressIntent
POD_EGRESS_INTENT_WITHDRAW: PodEgressIntent
POD_EGRESS_STATE_UNSPECIFIED: PodEgressState
POD_EGRESS_STATE_DIRECT: PodEgressState
POD_EGRESS_STATE_UNKNOWN: PodEgressState
POD_EGRESS_STATE_PENDING: PodEgressState
POD_EGRESS_STATE_READY: PodEgressState
POD_EGRESS_STATE_REJECTED: PodEgressState
POD_EGRESS_STATE_WITHDRAWN: PodEgressState
TASK_STATE_UNSPECIFIED: TaskState
TASK_STATE_QUEUED: TaskState
TASK_STATE_ACTIVE: TaskState
TASK_STATE_PAUSED: TaskState
TASK_STATE_DONE: TaskState
ORDER_STATE_UNSPECIFIED: OrderState
ORDER_STATE_PENDING: OrderState
ORDER_STATE_COLLECTING: OrderState
ORDER_STATE_QA: OrderState
ORDER_STATE_DELIVERING: OrderState
ORDER_STATE_COMPLETE: OrderState
ORDER_STATE_CANCELLED: OrderState
ORDER_STATE_FAILED: OrderState
CREATED_VIA_UNSPECIFIED: CreatedVia
CREATED_VIA_UI: CreatedVia
CREATED_VIA_MCP: CreatedVia
TRANSPORT_UNSPECIFIED: Transport
TRANSPORT_NETWORK: Transport
TRANSPORT_DRIVE: Transport
RIGIDITY_UNSPECIFIED: Rigidity
RIGIDITY_RIGID: Rigidity
RIGIDITY_DEFORMABLE: Rigidity
RIGIDITY_ARTICULATED: Rigidity
EMBODIMENT_SOURCE_UNSPECIFIED: EmbodimentSource
EMBODIMENT_SOURCE_BUILTIN: EmbodimentSource
EMBODIMENT_SOURCE_GITHUB: EmbodimentSource
EMBODIMENT_SOURCE_LINK: EmbodimentSource
EMBODIMENT_SOURCE_UPLOAD: EmbodimentSource
EMBODIMENT_STATE_UNSPECIFIED: EmbodimentState
EMBODIMENT_STATE_READY: EmbodimentState
EMBODIMENT_STATE_ERROR: EmbodimentState
BATCH_STATE_UNSPECIFIED: BatchState
BATCH_STATE_BUFFERING: BatchState
BATCH_STATE_UPLOADING: BatchState
BATCH_STATE_UPLOADED: BatchState
BATCH_STATE_DRIVE_PREP: BatchState
BATCH_STATE_SHIPPED: BatchState
BATCH_STATE_RECEIVED: BatchState
BATCH_STATE_VERIFIED: BatchState
BATCH_STATE_REGISTERING: BatchState
BATCH_STATE_READY: BatchState
BATCH_STATE_FAILED: BatchState
EPISODE_DELIVERY_STATE_UNSPECIFIED: EpisodeDeliveryState
EPISODE_DELIVERY_STATE_AWAITING_SESSION_SEAL: EpisodeDeliveryState
EPISODE_DELIVERY_STATE_AWAITING_ARTIFACT_SEAL: EpisodeDeliveryState
EPISODE_DELIVERY_STATE_SEALED: EpisodeDeliveryState
EPISODE_DELIVERY_STATE_STORED_NAS: EpisodeDeliveryState
EPISODE_DELIVERY_STATE_REPLICATING: EpisodeDeliveryState
EPISODE_DELIVERY_STATE_AWAITING_UPLOAD: EpisodeDeliveryState
EPISODE_DELIVERY_STATE_UPLOADING: EpisodeDeliveryState
EPISODE_DELIVERY_STATE_AWAITING_DRIVE: EpisodeDeliveryState
EPISODE_DELIVERY_STATE_COPYING_TO_DRIVE: EpisodeDeliveryState
EPISODE_DELIVERY_STATE_READY_TO_SHIP: EpisodeDeliveryState
EPISODE_DELIVERY_STATE_IN_TRANSIT: EpisodeDeliveryState
EPISODE_DELIVERY_STATE_RECEIVED: EpisodeDeliveryState
EPISODE_DELIVERY_STATE_VERIFYING: EpisodeDeliveryState
EPISODE_DELIVERY_STATE_REGISTERING_RAW: EpisodeDeliveryState
EPISODE_DELIVERY_STATE_RAW_DURABLE: EpisodeDeliveryState
EPISODE_DELIVERY_STATE_RETRYING: EpisodeDeliveryState
EPISODE_DELIVERY_STATE_SOURCE_UNAVAILABLE: EpisodeDeliveryState
SHIPMENT_STATE_UNSPECIFIED: ShipmentState
SHIPMENT_STATE_AWAITING_DRIVE: ShipmentState
SHIPMENT_STATE_COPYING: ShipmentState
SHIPMENT_STATE_READY_TO_DISPATCH: ShipmentState
SHIPMENT_STATE_IN_TRANSIT: ShipmentState
SHIPMENT_STATE_RECEIVED: ShipmentState
SHIPMENT_STATE_VERIFYING: ShipmentState
SHIPMENT_STATE_VERIFIED: ShipmentState
CAPTURE_ARTIFACT_FORMAT_UNSPECIFIED: CaptureArtifactFormat
CAPTURE_ARTIFACT_FORMAT_MCAP: CaptureArtifactFormat
CAPTURE_ARTIFACT_FORMAT_LEROBOT_V3_TAR: CaptureArtifactFormat
CAPTURE_ARTIFACT_FORMAT_SIMULATION_JSON: CaptureArtifactFormat

class GetFloorGrantsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetFloorGrantsResponse(_message.Message):
    __slots__ = ("role",)
    ROLE_FIELD_NUMBER: _ClassVar[int]
    role: FloorRole
    def __init__(self, role: _Optional[_Union[FloorRole, str]] = ...) -> None: ...

class FloorSummary(_message.Message):
    __slots__ = ("pods_total", "pods_online", "pods_collecting", "pods_general_pool", "episodes_today", "orders_active", "orders_at_risk", "nas_buffered_gb", "batches_in_transit")
    PODS_TOTAL_FIELD_NUMBER: _ClassVar[int]
    PODS_ONLINE_FIELD_NUMBER: _ClassVar[int]
    PODS_COLLECTING_FIELD_NUMBER: _ClassVar[int]
    PODS_GENERAL_POOL_FIELD_NUMBER: _ClassVar[int]
    EPISODES_TODAY_FIELD_NUMBER: _ClassVar[int]
    ORDERS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    ORDERS_AT_RISK_FIELD_NUMBER: _ClassVar[int]
    NAS_BUFFERED_GB_FIELD_NUMBER: _ClassVar[int]
    BATCHES_IN_TRANSIT_FIELD_NUMBER: _ClassVar[int]
    pods_total: int
    pods_online: int
    pods_collecting: int
    pods_general_pool: int
    episodes_today: int
    orders_active: int
    orders_at_risk: int
    nas_buffered_gb: float
    batches_in_transit: int
    def __init__(self, pods_total: _Optional[int] = ..., pods_online: _Optional[int] = ..., pods_collecting: _Optional[int] = ..., pods_general_pool: _Optional[int] = ..., episodes_today: _Optional[int] = ..., orders_active: _Optional[int] = ..., orders_at_risk: _Optional[int] = ..., nas_buffered_gb: _Optional[float] = ..., batches_in_transit: _Optional[int] = ...) -> None: ...

class GetFloorSummaryRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetFloorSummaryResponse(_message.Message):
    __slots__ = ("summary",)
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    summary: FloorSummary
    def __init__(self, summary: _Optional[_Union[FloorSummary, _Mapping]] = ...) -> None: ...

class FloorEvent(_message.Message):
    __slots__ = ("event_id", "at", "kind", "subject_id", "message")
    EVENT_ID_FIELD_NUMBER: _ClassVar[int]
    AT_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    SUBJECT_ID_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    event_id: int
    at: _timestamp_pb2.Timestamp
    kind: str
    subject_id: str
    message: str
    def __init__(self, event_id: _Optional[int] = ..., at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., kind: _Optional[str] = ..., subject_id: _Optional[str] = ..., message: _Optional[str] = ...) -> None: ...

class ListFloorEventsRequest(_message.Message):
    __slots__ = ("limit",)
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    limit: int
    def __init__(self, limit: _Optional[int] = ...) -> None: ...

class ListFloorEventsResponse(_message.Message):
    __slots__ = ("events",)
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    events: _containers.RepeatedCompositeFieldContainer[FloorEvent]
    def __init__(self, events: _Optional[_Iterable[_Union[FloorEvent, _Mapping]]] = ...) -> None: ...

class RigType(_message.Message):
    __slots__ = ("rig_type_id", "name", "family", "variant", "capabilities")
    RIG_TYPE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    FAMILY_FIELD_NUMBER: _ClassVar[int]
    VARIANT_FIELD_NUMBER: _ClassVar[int]
    CAPABILITIES_FIELD_NUMBER: _ClassVar[int]
    rig_type_id: str
    name: str
    family: RigFamily
    variant: str
    capabilities: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, rig_type_id: _Optional[str] = ..., name: _Optional[str] = ..., family: _Optional[_Union[RigFamily, str]] = ..., variant: _Optional[str] = ..., capabilities: _Optional[_Iterable[str]] = ...) -> None: ...

class ListRigTypesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListRigTypesResponse(_message.Message):
    __slots__ = ("rig_types",)
    RIG_TYPES_FIELD_NUMBER: _ClassVar[int]
    rig_types: _containers.RepeatedCompositeFieldContainer[RigType]
    def __init__(self, rig_types: _Optional[_Iterable[_Union[RigType, _Mapping]]] = ...) -> None: ...

class KitObject(_message.Message):
    __slots__ = ("object_id", "name")
    OBJECT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    object_id: str
    name: str
    def __init__(self, object_id: _Optional[str] = ..., name: _Optional[str] = ...) -> None: ...

class TaskAssignment(_message.Message):
    __slots__ = ("task_assignment_id", "order_id", "pod_id", "state", "skill", "instruction", "scene", "object_kit", "episodes_target", "episodes_done")
    TASK_ASSIGNMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    POD_ID_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    SKILL_FIELD_NUMBER: _ClassVar[int]
    INSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    SCENE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_KIT_FIELD_NUMBER: _ClassVar[int]
    EPISODES_TARGET_FIELD_NUMBER: _ClassVar[int]
    EPISODES_DONE_FIELD_NUMBER: _ClassVar[int]
    task_assignment_id: str
    order_id: str
    pod_id: str
    state: TaskState
    skill: str
    instruction: str
    scene: str
    object_kit: _containers.RepeatedCompositeFieldContainer[KitObject]
    episodes_target: int
    episodes_done: int
    def __init__(self, task_assignment_id: _Optional[str] = ..., order_id: _Optional[str] = ..., pod_id: _Optional[str] = ..., state: _Optional[_Union[TaskState, str]] = ..., skill: _Optional[str] = ..., instruction: _Optional[str] = ..., scene: _Optional[str] = ..., object_kit: _Optional[_Iterable[_Union[KitObject, _Mapping]]] = ..., episodes_target: _Optional[int] = ..., episodes_done: _Optional[int] = ...) -> None: ...

class Pod(_message.Message):
    __slots__ = ("pod_id", "name", "state", "pool", "rig_type", "laptop_hostname", "tailscale_ip", "operator_name", "episodes_today", "episodes_total", "last_heartbeat", "current_task", "egress_intent", "egress_state", "egress_detail", "egress_observed_at")
    POD_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    POOL_FIELD_NUMBER: _ClassVar[int]
    RIG_TYPE_FIELD_NUMBER: _ClassVar[int]
    LAPTOP_HOSTNAME_FIELD_NUMBER: _ClassVar[int]
    TAILSCALE_IP_FIELD_NUMBER: _ClassVar[int]
    OPERATOR_NAME_FIELD_NUMBER: _ClassVar[int]
    EPISODES_TODAY_FIELD_NUMBER: _ClassVar[int]
    EPISODES_TOTAL_FIELD_NUMBER: _ClassVar[int]
    LAST_HEARTBEAT_FIELD_NUMBER: _ClassVar[int]
    CURRENT_TASK_FIELD_NUMBER: _ClassVar[int]
    EGRESS_INTENT_FIELD_NUMBER: _ClassVar[int]
    EGRESS_STATE_FIELD_NUMBER: _ClassVar[int]
    EGRESS_DETAIL_FIELD_NUMBER: _ClassVar[int]
    EGRESS_OBSERVED_AT_FIELD_NUMBER: _ClassVar[int]
    pod_id: str
    name: str
    state: PodState
    pool: PodPool
    rig_type: RigType
    laptop_hostname: str
    tailscale_ip: str
    operator_name: str
    episodes_today: int
    episodes_total: int
    last_heartbeat: _timestamp_pb2.Timestamp
    current_task: TaskAssignment
    egress_intent: PodEgressIntent
    egress_state: PodEgressState
    egress_detail: str
    egress_observed_at: _timestamp_pb2.Timestamp
    def __init__(self, pod_id: _Optional[str] = ..., name: _Optional[str] = ..., state: _Optional[_Union[PodState, str]] = ..., pool: _Optional[_Union[PodPool, str]] = ..., rig_type: _Optional[_Union[RigType, _Mapping]] = ..., laptop_hostname: _Optional[str] = ..., tailscale_ip: _Optional[str] = ..., operator_name: _Optional[str] = ..., episodes_today: _Optional[int] = ..., episodes_total: _Optional[int] = ..., last_heartbeat: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., current_task: _Optional[_Union[TaskAssignment, _Mapping]] = ..., egress_intent: _Optional[_Union[PodEgressIntent, str]] = ..., egress_state: _Optional[_Union[PodEgressState, str]] = ..., egress_detail: _Optional[str] = ..., egress_observed_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ListPodsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListPodsResponse(_message.Message):
    __slots__ = ("pods",)
    PODS_FIELD_NUMBER: _ClassVar[int]
    pods: _containers.RepeatedCompositeFieldContainer[Pod]
    def __init__(self, pods: _Optional[_Iterable[_Union[Pod, _Mapping]]] = ...) -> None: ...

class RigTypeAssignment(_message.Message):
    __slots__ = ("rig_type_id", "cleared")
    RIG_TYPE_ID_FIELD_NUMBER: _ClassVar[int]
    CLEARED_FIELD_NUMBER: _ClassVar[int]
    rig_type_id: str
    cleared: bool
    def __init__(self, rig_type_id: _Optional[str] = ..., cleared: _Optional[bool] = ...) -> None: ...

class UpdatePodRequest(_message.Message):
    __slots__ = ("pod_id", "state", "pool", "operator_name", "rig_type")
    POD_ID_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    POOL_FIELD_NUMBER: _ClassVar[int]
    OPERATOR_NAME_FIELD_NUMBER: _ClassVar[int]
    RIG_TYPE_FIELD_NUMBER: _ClassVar[int]
    pod_id: str
    state: PodState
    pool: PodPool
    operator_name: str
    rig_type: RigTypeAssignment
    def __init__(self, pod_id: _Optional[str] = ..., state: _Optional[_Union[PodState, str]] = ..., pool: _Optional[_Union[PodPool, str]] = ..., operator_name: _Optional[str] = ..., rig_type: _Optional[_Union[RigTypeAssignment, _Mapping]] = ...) -> None: ...

class UpdatePodResponse(_message.Message):
    __slots__ = ("pod",)
    POD_FIELD_NUMBER: _ClassVar[int]
    pod: Pod
    def __init__(self, pod: _Optional[_Union[Pod, _Mapping]] = ...) -> None: ...

class ProvisionPodEgressRequest(_message.Message):
    __slots__ = ("pod_id",)
    POD_ID_FIELD_NUMBER: _ClassVar[int]
    pod_id: str
    def __init__(self, pod_id: _Optional[str] = ...) -> None: ...

class ProvisionPodEgressResponse(_message.Message):
    __slots__ = ("pod",)
    POD_FIELD_NUMBER: _ClassVar[int]
    pod: Pod
    def __init__(self, pod: _Optional[_Union[Pod, _Mapping]] = ...) -> None: ...

class WithdrawPodEgressRequest(_message.Message):
    __slots__ = ("pod_id",)
    POD_ID_FIELD_NUMBER: _ClassVar[int]
    pod_id: str
    def __init__(self, pod_id: _Optional[str] = ...) -> None: ...

class WithdrawPodEgressResponse(_message.Message):
    __slots__ = ("pod",)
    POD_FIELD_NUMBER: _ClassVar[int]
    pod: Pod
    def __init__(self, pod: _Optional[_Union[Pod, _Mapping]] = ...) -> None: ...

class CreatePodJoinCodeRequest(_message.Message):
    __slots__ = ("pod_id", "ttl_s")
    POD_ID_FIELD_NUMBER: _ClassVar[int]
    TTL_S_FIELD_NUMBER: _ClassVar[int]
    pod_id: str
    ttl_s: int
    def __init__(self, pod_id: _Optional[str] = ..., ttl_s: _Optional[int] = ...) -> None: ...

class CreatePodJoinCodeResponse(_message.Message):
    __slots__ = ("join_code",)
    JOIN_CODE_FIELD_NUMBER: _ClassVar[int]
    join_code: PodJoinCode
    def __init__(self, join_code: _Optional[_Union[PodJoinCode, _Mapping]] = ...) -> None: ...

class PodJoinCode(_message.Message):
    __slots__ = ("code", "pod_id", "expires_at")
    CODE_FIELD_NUMBER: _ClassVar[int]
    POD_ID_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    code: str
    pod_id: str
    expires_at: _timestamp_pb2.Timestamp
    def __init__(self, code: _Optional[str] = ..., pod_id: _Optional[str] = ..., expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class AssignKitRequest(_message.Message):
    __slots__ = ("pod_id", "object_ids")
    POD_ID_FIELD_NUMBER: _ClassVar[int]
    OBJECT_IDS_FIELD_NUMBER: _ClassVar[int]
    pod_id: str
    object_ids: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, pod_id: _Optional[str] = ..., object_ids: _Optional[_Iterable[str]] = ...) -> None: ...

class AssignKitResponse(_message.Message):
    __slots__ = ("task",)
    TASK_FIELD_NUMBER: _ClassVar[int]
    task: TaskAssignment
    def __init__(self, task: _Optional[_Union[TaskAssignment, _Mapping]] = ...) -> None: ...

class DiversitySpec(_message.Message):
    __slots__ = ("scenes", "object_categories", "objects_per_scene")
    SCENES_FIELD_NUMBER: _ClassVar[int]
    OBJECT_CATEGORIES_FIELD_NUMBER: _ClassVar[int]
    OBJECTS_PER_SCENE_FIELD_NUMBER: _ClassVar[int]
    scenes: _containers.RepeatedScalarFieldContainer[str]
    object_categories: _containers.RepeatedScalarFieldContainer[str]
    objects_per_scene: int
    def __init__(self, scenes: _Optional[_Iterable[str]] = ..., object_categories: _Optional[_Iterable[str]] = ..., objects_per_scene: _Optional[int] = ...) -> None: ...

class CaptureRequirements(_message.Message):
    __slots__ = ("families", "rig_types", "capabilities")
    FAMILIES_FIELD_NUMBER: _ClassVar[int]
    RIG_TYPES_FIELD_NUMBER: _ClassVar[int]
    CAPABILITIES_FIELD_NUMBER: _ClassVar[int]
    families: _containers.RepeatedScalarFieldContainer[RigFamily]
    rig_types: _containers.RepeatedScalarFieldContainer[str]
    capabilities: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, families: _Optional[_Iterable[_Union[RigFamily, str]]] = ..., rig_types: _Optional[_Iterable[str]] = ..., capabilities: _Optional[_Iterable[str]] = ...) -> None: ...

class Order(_message.Message):
    __slots__ = ("order_id", "customer", "skill", "task", "state", "exclusive", "embodiment_id", "episodes_target", "episodes_done", "diversity", "capture_requirements", "created_via", "created_at", "sla_due_at", "tasks")
    ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    CUSTOMER_FIELD_NUMBER: _ClassVar[int]
    SKILL_FIELD_NUMBER: _ClassVar[int]
    TASK_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    EXCLUSIVE_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    EPISODES_TARGET_FIELD_NUMBER: _ClassVar[int]
    EPISODES_DONE_FIELD_NUMBER: _ClassVar[int]
    DIVERSITY_FIELD_NUMBER: _ClassVar[int]
    CAPTURE_REQUIREMENTS_FIELD_NUMBER: _ClassVar[int]
    CREATED_VIA_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    SLA_DUE_AT_FIELD_NUMBER: _ClassVar[int]
    TASKS_FIELD_NUMBER: _ClassVar[int]
    order_id: str
    customer: str
    skill: str
    task: _common_pb2.TaskContractRef
    state: OrderState
    exclusive: bool
    embodiment_id: str
    episodes_target: int
    episodes_done: int
    diversity: DiversitySpec
    capture_requirements: CaptureRequirements
    created_via: CreatedVia
    created_at: _timestamp_pb2.Timestamp
    sla_due_at: _timestamp_pb2.Timestamp
    tasks: _containers.RepeatedCompositeFieldContainer[TaskAssignment]
    def __init__(self, order_id: _Optional[str] = ..., customer: _Optional[str] = ..., skill: _Optional[str] = ..., task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., state: _Optional[_Union[OrderState, str]] = ..., exclusive: _Optional[bool] = ..., embodiment_id: _Optional[str] = ..., episodes_target: _Optional[int] = ..., episodes_done: _Optional[int] = ..., diversity: _Optional[_Union[DiversitySpec, _Mapping]] = ..., capture_requirements: _Optional[_Union[CaptureRequirements, _Mapping]] = ..., created_via: _Optional[_Union[CreatedVia, str]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., sla_due_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., tasks: _Optional[_Iterable[_Union[TaskAssignment, _Mapping]]] = ...) -> None: ...

class OrderDraft(_message.Message):
    __slots__ = ("customer", "skill", "task", "episodes_target", "exclusive", "priority", "diversity", "capture_requirements", "embodiment_id", "timeout_s")
    CUSTOMER_FIELD_NUMBER: _ClassVar[int]
    SKILL_FIELD_NUMBER: _ClassVar[int]
    TASK_FIELD_NUMBER: _ClassVar[int]
    EPISODES_TARGET_FIELD_NUMBER: _ClassVar[int]
    EXCLUSIVE_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    DIVERSITY_FIELD_NUMBER: _ClassVar[int]
    CAPTURE_REQUIREMENTS_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_S_FIELD_NUMBER: _ClassVar[int]
    customer: str
    skill: str
    task: _common_pb2.TaskContractRef
    episodes_target: int
    exclusive: bool
    priority: int
    diversity: DiversitySpec
    capture_requirements: CaptureRequirements
    embodiment_id: str
    timeout_s: int
    def __init__(self, customer: _Optional[str] = ..., skill: _Optional[str] = ..., task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., episodes_target: _Optional[int] = ..., exclusive: _Optional[bool] = ..., priority: _Optional[int] = ..., diversity: _Optional[_Union[DiversitySpec, _Mapping]] = ..., capture_requirements: _Optional[_Union[CaptureRequirements, _Mapping]] = ..., embodiment_id: _Optional[str] = ..., timeout_s: _Optional[int] = ...) -> None: ...

class ListOrdersRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListOrdersResponse(_message.Message):
    __slots__ = ("orders",)
    ORDERS_FIELD_NUMBER: _ClassVar[int]
    orders: _containers.RepeatedCompositeFieldContainer[Order]
    def __init__(self, orders: _Optional[_Iterable[_Union[Order, _Mapping]]] = ...) -> None: ...

class GetOrderRequest(_message.Message):
    __slots__ = ("order_id",)
    ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    order_id: str
    def __init__(self, order_id: _Optional[str] = ...) -> None: ...

class GetOrderResponse(_message.Message):
    __slots__ = ("order",)
    ORDER_FIELD_NUMBER: _ClassVar[int]
    order: Order
    def __init__(self, order: _Optional[_Union[Order, _Mapping]] = ...) -> None: ...

class Quote(_message.Message):
    __slots__ = ("pods_allocatable", "total_days", "transport", "est_size_gb")
    PODS_ALLOCATABLE_FIELD_NUMBER: _ClassVar[int]
    TOTAL_DAYS_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_FIELD_NUMBER: _ClassVar[int]
    EST_SIZE_GB_FIELD_NUMBER: _ClassVar[int]
    pods_allocatable: int
    total_days: float
    transport: Transport
    est_size_gb: float
    def __init__(self, pods_allocatable: _Optional[int] = ..., total_days: _Optional[float] = ..., transport: _Optional[_Union[Transport, str]] = ..., est_size_gb: _Optional[float] = ...) -> None: ...

class QuoteOrderRequest(_message.Message):
    __slots__ = ("draft",)
    DRAFT_FIELD_NUMBER: _ClassVar[int]
    draft: OrderDraft
    def __init__(self, draft: _Optional[_Union[OrderDraft, _Mapping]] = ...) -> None: ...

class QuoteOrderResponse(_message.Message):
    __slots__ = ("quote",)
    QUOTE_FIELD_NUMBER: _ClassVar[int]
    quote: Quote
    def __init__(self, quote: _Optional[_Union[Quote, _Mapping]] = ...) -> None: ...

class CreateOrderRequest(_message.Message):
    __slots__ = ("draft",)
    DRAFT_FIELD_NUMBER: _ClassVar[int]
    draft: OrderDraft
    def __init__(self, draft: _Optional[_Union[OrderDraft, _Mapping]] = ...) -> None: ...

class CreateOrderResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: _factory_pb2.CaptureOperation
    def __init__(self, operation: _Optional[_Union[_factory_pb2.CaptureOperation, _Mapping]] = ...) -> None: ...

class CancelOrderRequest(_message.Message):
    __slots__ = ("order_id",)
    ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    order_id: str
    def __init__(self, order_id: _Optional[str] = ...) -> None: ...

class CancelOrderResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: _factory_pb2.CaptureOperation
    def __init__(self, operation: _Optional[_Union[_factory_pb2.CaptureOperation, _Mapping]] = ...) -> None: ...

class Embodiment(_message.Message):
    __slots__ = ("embodiment_id", "name", "content_id", "source", "mesh_base", "state", "dof", "links", "created_at")
    EMBODIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CONTENT_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    MESH_BASE_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    DOF_FIELD_NUMBER: _ClassVar[int]
    LINKS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    embodiment_id: str
    name: str
    content_id: str
    source: EmbodimentSource
    mesh_base: str
    state: EmbodimentState
    dof: int
    links: int
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, embodiment_id: _Optional[str] = ..., name: _Optional[str] = ..., content_id: _Optional[str] = ..., source: _Optional[_Union[EmbodimentSource, str]] = ..., mesh_base: _Optional[str] = ..., state: _Optional[_Union[EmbodimentState, str]] = ..., dof: _Optional[int] = ..., links: _Optional[int] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ListEmbodimentsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListEmbodimentsResponse(_message.Message):
    __slots__ = ("embodiments",)
    EMBODIMENTS_FIELD_NUMBER: _ClassVar[int]
    embodiments: _containers.RepeatedCompositeFieldContainer[Embodiment]
    def __init__(self, embodiments: _Optional[_Iterable[_Union[Embodiment, _Mapping]]] = ...) -> None: ...

class RegisterEmbodimentLinkRequest(_message.Message):
    __slots__ = ("embodiment_url", "urdf_url")
    EMBODIMENT_URL_FIELD_NUMBER: _ClassVar[int]
    URDF_URL_FIELD_NUMBER: _ClassVar[int]
    embodiment_url: str
    urdf_url: str
    def __init__(self, embodiment_url: _Optional[str] = ..., urdf_url: _Optional[str] = ...) -> None: ...

class RegisterEmbodimentLinkResponse(_message.Message):
    __slots__ = ("embodiment",)
    EMBODIMENT_FIELD_NUMBER: _ClassVar[int]
    embodiment: Embodiment
    def __init__(self, embodiment: _Optional[_Union[Embodiment, _Mapping]] = ...) -> None: ...

class DeleteEmbodimentRequest(_message.Message):
    __slots__ = ("embodiment_id",)
    EMBODIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    embodiment_id: str
    def __init__(self, embodiment_id: _Optional[str] = ...) -> None: ...

class DeleteEmbodimentResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CatalogObject(_message.Message):
    __slots__ = ("object_id", "name", "category", "weight_g", "dims_mm", "rigidity", "mesh_url", "purchase_url", "unit_price_usd", "quantity", "home_shelf", "tags")
    OBJECT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    WEIGHT_G_FIELD_NUMBER: _ClassVar[int]
    DIMS_MM_FIELD_NUMBER: _ClassVar[int]
    RIGIDITY_FIELD_NUMBER: _ClassVar[int]
    MESH_URL_FIELD_NUMBER: _ClassVar[int]
    PURCHASE_URL_FIELD_NUMBER: _ClassVar[int]
    UNIT_PRICE_USD_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    HOME_SHELF_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    object_id: str
    name: str
    category: str
    weight_g: float
    dims_mm: str
    rigidity: Rigidity
    mesh_url: str
    purchase_url: str
    unit_price_usd: float
    quantity: int
    home_shelf: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, object_id: _Optional[str] = ..., name: _Optional[str] = ..., category: _Optional[str] = ..., weight_g: _Optional[float] = ..., dims_mm: _Optional[str] = ..., rigidity: _Optional[_Union[Rigidity, str]] = ..., mesh_url: _Optional[str] = ..., purchase_url: _Optional[str] = ..., unit_price_usd: _Optional[float] = ..., quantity: _Optional[int] = ..., home_shelf: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ...) -> None: ...

class ListObjectsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListObjectsResponse(_message.Message):
    __slots__ = ("objects",)
    OBJECTS_FIELD_NUMBER: _ClassVar[int]
    objects: _containers.RepeatedCompositeFieldContainer[CatalogObject]
    def __init__(self, objects: _Optional[_Iterable[_Union[CatalogObject, _Mapping]]] = ...) -> None: ...

class EpisodeDelivery(_message.Message):
    __slots__ = ("episode_id", "session_id", "pod_id", "state_updated_at", "artifact_id", "artifact_format", "state", "transport", "shipment_id", "shipment_state")
    EPISODE_ID_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    POD_ID_FIELD_NUMBER: _ClassVar[int]
    STATE_UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_ID_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_FORMAT_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_FIELD_NUMBER: _ClassVar[int]
    SHIPMENT_ID_FIELD_NUMBER: _ClassVar[int]
    SHIPMENT_STATE_FIELD_NUMBER: _ClassVar[int]
    episode_id: str
    session_id: str
    pod_id: str
    state_updated_at: _timestamp_pb2.Timestamp
    artifact_id: str
    artifact_format: CaptureArtifactFormat
    state: EpisodeDeliveryState
    transport: Transport
    shipment_id: str
    shipment_state: ShipmentState
    def __init__(self, episode_id: _Optional[str] = ..., session_id: _Optional[str] = ..., pod_id: _Optional[str] = ..., state_updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., artifact_id: _Optional[str] = ..., artifact_format: _Optional[_Union[CaptureArtifactFormat, str]] = ..., state: _Optional[_Union[EpisodeDeliveryState, str]] = ..., transport: _Optional[_Union[Transport, str]] = ..., shipment_id: _Optional[str] = ..., shipment_state: _Optional[_Union[ShipmentState, str]] = ...) -> None: ...

class ListEpisodeDeliveriesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListEpisodeDeliveriesResponse(_message.Message):
    __slots__ = ("episodes",)
    EPISODES_FIELD_NUMBER: _ClassVar[int]
    episodes: _containers.RepeatedCompositeFieldContainer[EpisodeDelivery]
    def __init__(self, episodes: _Optional[_Iterable[_Union[EpisodeDelivery, _Mapping]]] = ...) -> None: ...

class ArtifactShipment(_message.Message):
    __slots__ = ("shipment_id", "artifact_ids", "state", "drive_serial", "carrier", "tracking_number", "updated_at")
    SHIPMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_IDS_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    DRIVE_SERIAL_FIELD_NUMBER: _ClassVar[int]
    CARRIER_FIELD_NUMBER: _ClassVar[int]
    TRACKING_NUMBER_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    shipment_id: str
    artifact_ids: _containers.RepeatedScalarFieldContainer[str]
    state: ShipmentState
    drive_serial: str
    carrier: str
    tracking_number: str
    updated_at: _timestamp_pb2.Timestamp
    def __init__(self, shipment_id: _Optional[str] = ..., artifact_ids: _Optional[_Iterable[str]] = ..., state: _Optional[_Union[ShipmentState, str]] = ..., drive_serial: _Optional[str] = ..., carrier: _Optional[str] = ..., tracking_number: _Optional[str] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ListArtifactShipmentsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListArtifactShipmentsResponse(_message.Message):
    __slots__ = ("shipments",)
    SHIPMENTS_FIELD_NUMBER: _ClassVar[int]
    shipments: _containers.RepeatedCompositeFieldContainer[ArtifactShipment]
    def __init__(self, shipments: _Optional[_Iterable[_Union[ArtifactShipment, _Mapping]]] = ...) -> None: ...

class NativeBatch(_message.Message):
    __slots__ = ("batch_id", "order_id", "dataset", "label", "size_gb", "episodes", "transport", "state", "drive_serial", "tracking_number", "est_hours", "created_at")
    BATCH_ID_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_FIELD_NUMBER: _ClassVar[int]
    DATASET_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    SIZE_GB_FIELD_NUMBER: _ClassVar[int]
    EPISODES_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    DRIVE_SERIAL_FIELD_NUMBER: _ClassVar[int]
    TRACKING_NUMBER_FIELD_NUMBER: _ClassVar[int]
    EST_HOURS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    batch_id: str
    order_id: str
    dataset: str
    label: str
    size_gb: float
    episodes: int
    transport: Transport
    state: BatchState
    drive_serial: str
    tracking_number: str
    est_hours: float
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, batch_id: _Optional[str] = ..., order_id: _Optional[str] = ..., dataset: _Optional[str] = ..., label: _Optional[str] = ..., size_gb: _Optional[float] = ..., episodes: _Optional[int] = ..., transport: _Optional[_Union[Transport, str]] = ..., state: _Optional[_Union[BatchState, str]] = ..., drive_serial: _Optional[str] = ..., tracking_number: _Optional[str] = ..., est_hours: _Optional[float] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ListNativeBatchesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListNativeBatchesResponse(_message.Message):
    __slots__ = ("batches",)
    BATCHES_FIELD_NUMBER: _ClassVar[int]
    batches: _containers.RepeatedCompositeFieldContainer[NativeBatch]
    def __init__(self, batches: _Optional[_Iterable[_Union[NativeBatch, _Mapping]]] = ...) -> None: ...

class AdvanceNativeBatchRequest(_message.Message):
    __slots__ = ("batch_id", "expected_state", "drive_serial", "tracking_number")
    BATCH_ID_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_STATE_FIELD_NUMBER: _ClassVar[int]
    DRIVE_SERIAL_FIELD_NUMBER: _ClassVar[int]
    TRACKING_NUMBER_FIELD_NUMBER: _ClassVar[int]
    batch_id: str
    expected_state: BatchState
    drive_serial: str
    tracking_number: str
    def __init__(self, batch_id: _Optional[str] = ..., expected_state: _Optional[_Union[BatchState, str]] = ..., drive_serial: _Optional[str] = ..., tracking_number: _Optional[str] = ...) -> None: ...

class AdvanceNativeBatchResponse(_message.Message):
    __slots__ = ("batch",)
    BATCH_FIELD_NUMBER: _ClassVar[int]
    batch: NativeBatch
    def __init__(self, batch: _Optional[_Union[NativeBatch, _Mapping]] = ...) -> None: ...
