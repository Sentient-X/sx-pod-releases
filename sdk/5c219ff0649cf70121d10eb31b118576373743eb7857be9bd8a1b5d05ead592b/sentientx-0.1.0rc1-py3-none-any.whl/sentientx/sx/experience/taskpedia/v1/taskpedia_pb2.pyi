import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from sentientx.sx.common.v1 import capabilities_pb2 as _capabilities_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from sentientx.sx.common.v1 import tasks_pb2 as _tasks_pb2
from sentientx.sx.operations.v1 import operations_pb2 as _operations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class DraftStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DRAFT_STATUS_UNSPECIFIED: _ClassVar[DraftStatus]
    DRAFT_STATUS_OPEN: _ClassVar[DraftStatus]
    DRAFT_STATUS_PUBLISHED: _ClassVar[DraftStatus]
    DRAFT_STATUS_ARCHIVED: _ClassVar[DraftStatus]

class IssueSeverity(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ISSUE_SEVERITY_UNSPECIFIED: _ClassVar[IssueSeverity]
    ISSUE_SEVERITY_ERROR: _ClassVar[IssueSeverity]
    ISSUE_SEVERITY_WARNING: _ClassVar[IssueSeverity]

class ProofState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PROOF_STATE_UNSPECIFIED: _ClassVar[ProofState]
    PROOF_STATE_PASS: _ClassVar[ProofState]
    PROOF_STATE_WARNING: _ClassVar[ProofState]
    PROOF_STATE_BLOCKED: _ClassVar[ProofState]
    PROOF_STATE_UNAVAILABLE: _ClassVar[ProofState]

class ProofOwner(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PROOF_OWNER_UNSPECIFIED: _ClassVar[ProofOwner]
    PROOF_OWNER_TASKPEDIA: _ClassVar[ProofOwner]
    PROOF_OWNER_CATALOG: _ClassVar[ProofOwner]
    PROOF_OWNER_WORLDS: _ClassVar[ProofOwner]

class SemanticChangeKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SEMANTIC_CHANGE_KIND_UNSPECIFIED: _ClassVar[SemanticChangeKind]
    SEMANTIC_CHANGE_KIND_ADDED: _ClassVar[SemanticChangeKind]
    SEMANTIC_CHANGE_KIND_REMOVED: _ClassVar[SemanticChangeKind]
    SEMANTIC_CHANGE_KIND_CHANGED: _ClassVar[SemanticChangeKind]
DRAFT_STATUS_UNSPECIFIED: DraftStatus
DRAFT_STATUS_OPEN: DraftStatus
DRAFT_STATUS_PUBLISHED: DraftStatus
DRAFT_STATUS_ARCHIVED: DraftStatus
ISSUE_SEVERITY_UNSPECIFIED: IssueSeverity
ISSUE_SEVERITY_ERROR: IssueSeverity
ISSUE_SEVERITY_WARNING: IssueSeverity
PROOF_STATE_UNSPECIFIED: ProofState
PROOF_STATE_PASS: ProofState
PROOF_STATE_WARNING: ProofState
PROOF_STATE_BLOCKED: ProofState
PROOF_STATE_UNAVAILABLE: ProofState
PROOF_OWNER_UNSPECIFIED: ProofOwner
PROOF_OWNER_TASKPEDIA: ProofOwner
PROOF_OWNER_CATALOG: ProofOwner
PROOF_OWNER_WORLDS: ProofOwner
SEMANTIC_CHANGE_KIND_UNSPECIFIED: SemanticChangeKind
SEMANTIC_CHANGE_KIND_ADDED: SemanticChangeKind
SEMANTIC_CHANGE_KIND_REMOVED: SemanticChangeKind
SEMANTIC_CHANGE_KIND_CHANGED: SemanticChangeKind

class TaskDraftIssue(_message.Message):
    __slots__ = ("code", "severity", "field_path", "message", "recovery")
    CODE_FIELD_NUMBER: _ClassVar[int]
    SEVERITY_FIELD_NUMBER: _ClassVar[int]
    FIELD_PATH_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    RECOVERY_FIELD_NUMBER: _ClassVar[int]
    code: str
    severity: IssueSeverity
    field_path: str
    message: str
    recovery: str
    def __init__(self, code: _Optional[str] = ..., severity: _Optional[_Union[IssueSeverity, str]] = ..., field_path: _Optional[str] = ..., message: _Optional[str] = ..., recovery: _Optional[str] = ...) -> None: ...

class ProofResult(_message.Message):
    __slots__ = ("owner", "state", "summary", "issues", "source_refs")
    OWNER_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    ISSUES_FIELD_NUMBER: _ClassVar[int]
    SOURCE_REFS_FIELD_NUMBER: _ClassVar[int]
    owner: ProofOwner
    state: ProofState
    summary: str
    issues: _containers.RepeatedCompositeFieldContainer[TaskDraftIssue]
    source_refs: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, owner: _Optional[_Union[ProofOwner, str]] = ..., state: _Optional[_Union[ProofState, str]] = ..., summary: _Optional[str] = ..., issues: _Optional[_Iterable[_Union[TaskDraftIssue, _Mapping]]] = ..., source_refs: _Optional[_Iterable[str]] = ...) -> None: ...

class TaskDraftEvaluation(_message.Message):
    __slots__ = ("revision", "taskpedia", "catalog", "worlds", "issues", "canonical_ref")
    REVISION_FIELD_NUMBER: _ClassVar[int]
    TASKPEDIA_FIELD_NUMBER: _ClassVar[int]
    CATALOG_FIELD_NUMBER: _ClassVar[int]
    WORLDS_FIELD_NUMBER: _ClassVar[int]
    ISSUES_FIELD_NUMBER: _ClassVar[int]
    CANONICAL_REF_FIELD_NUMBER: _ClassVar[int]
    revision: int
    taskpedia: ProofResult
    catalog: ProofResult
    worlds: ProofResult
    issues: _containers.RepeatedCompositeFieldContainer[TaskDraftIssue]
    canonical_ref: _common_pb2.TaskContractRef
    def __init__(self, revision: _Optional[int] = ..., taskpedia: _Optional[_Union[ProofResult, _Mapping]] = ..., catalog: _Optional[_Union[ProofResult, _Mapping]] = ..., worlds: _Optional[_Union[ProofResult, _Mapping]] = ..., issues: _Optional[_Iterable[_Union[TaskDraftIssue, _Mapping]]] = ..., canonical_ref: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ...) -> None: ...

class SemanticChange(_message.Message):
    __slots__ = ("field_path", "kind", "before_display", "after_display")
    FIELD_PATH_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    BEFORE_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    AFTER_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    field_path: str
    kind: SemanticChangeKind
    before_display: str
    after_display: str
    def __init__(self, field_path: _Optional[str] = ..., kind: _Optional[_Union[SemanticChangeKind, str]] = ..., before_display: _Optional[str] = ..., after_display: _Optional[str] = ...) -> None: ...

class TaskDraftReview(_message.Message):
    __slots__ = ("revision", "canonical_ref", "baseline_ref", "changes", "contract")
    REVISION_FIELD_NUMBER: _ClassVar[int]
    CANONICAL_REF_FIELD_NUMBER: _ClassVar[int]
    BASELINE_REF_FIELD_NUMBER: _ClassVar[int]
    CHANGES_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_FIELD_NUMBER: _ClassVar[int]
    revision: int
    canonical_ref: _common_pb2.TaskContractRef
    baseline_ref: str
    changes: _containers.RepeatedCompositeFieldContainer[SemanticChange]
    contract: _tasks_pb2.TaskContract
    def __init__(self, revision: _Optional[int] = ..., canonical_ref: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., baseline_ref: _Optional[str] = ..., changes: _Optional[_Iterable[_Union[SemanticChange, _Mapping]]] = ..., contract: _Optional[_Union[_tasks_pb2.TaskContract, _Mapping]] = ...) -> None: ...

class BlankDraftStart(_message.Message):
    __slots__ = ("outcome",)
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    outcome: str
    def __init__(self, outcome: _Optional[str] = ...) -> None: ...

class OpportunityDraftStart(_message.Message):
    __slots__ = ("opportunity_id",)
    OPPORTUNITY_ID_FIELD_NUMBER: _ClassVar[int]
    opportunity_id: str
    def __init__(self, opportunity_id: _Optional[str] = ...) -> None: ...

class ExistingTaskDraftStart(_message.Message):
    __slots__ = ("task_id",)
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    def __init__(self, task_id: _Optional[str] = ...) -> None: ...

class TaskDraftStart(_message.Message):
    __slots__ = ("blank", "opportunity", "existing_task")
    BLANK_FIELD_NUMBER: _ClassVar[int]
    OPPORTUNITY_FIELD_NUMBER: _ClassVar[int]
    EXISTING_TASK_FIELD_NUMBER: _ClassVar[int]
    blank: BlankDraftStart
    opportunity: OpportunityDraftStart
    existing_task: ExistingTaskDraftStart
    def __init__(self, blank: _Optional[_Union[BlankDraftStart, _Mapping]] = ..., opportunity: _Optional[_Union[OpportunityDraftStart, _Mapping]] = ..., existing_task: _Optional[_Union[ExistingTaskDraftStart, _Mapping]] = ...) -> None: ...

class WorldObjectRef(_message.Message):
    __slots__ = ("object_id", "label", "object_head")
    OBJECT_ID_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HEAD_FIELD_NUMBER: _ClassVar[int]
    object_id: str
    label: str
    object_head: str
    def __init__(self, object_id: _Optional[str] = ..., label: _Optional[str] = ..., object_head: _Optional[str] = ...) -> None: ...

class SceneSelection(_message.Message):
    __slots__ = ("scene_ref", "objects")
    SCENE_REF_FIELD_NUMBER: _ClassVar[int]
    OBJECTS_FIELD_NUMBER: _ClassVar[int]
    scene_ref: str
    objects: _containers.RepeatedCompositeFieldContainer[WorldObjectRef]
    def __init__(self, scene_ref: _Optional[str] = ..., objects: _Optional[_Iterable[_Union[WorldObjectRef, _Mapping]]] = ...) -> None: ...

class AuthoringContext(_message.Message):
    __slots__ = ("scenes", "body_ref", "predecessor_task_id", "opportunity_id")
    SCENES_FIELD_NUMBER: _ClassVar[int]
    BODY_REF_FIELD_NUMBER: _ClassVar[int]
    PREDECESSOR_TASK_ID_FIELD_NUMBER: _ClassVar[int]
    OPPORTUNITY_ID_FIELD_NUMBER: _ClassVar[int]
    scenes: _containers.RepeatedCompositeFieldContainer[SceneSelection]
    body_ref: str
    predecessor_task_id: str
    opportunity_id: str
    def __init__(self, scenes: _Optional[_Iterable[_Union[SceneSelection, _Mapping]]] = ..., body_ref: _Optional[str] = ..., predecessor_task_id: _Optional[str] = ..., opportunity_id: _Optional[str] = ...) -> None: ...

class TaskIntentDraft(_message.Message):
    __slots__ = ("task_id", "name", "outcome", "family", "horizon", "reasoning", "operator", "taskpedia_codes")
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    FAMILY_FIELD_NUMBER: _ClassVar[int]
    HORIZON_FIELD_NUMBER: _ClassVar[int]
    REASONING_FIELD_NUMBER: _ClassVar[int]
    OPERATOR_FIELD_NUMBER: _ClassVar[int]
    TASKPEDIA_CODES_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    name: str
    outcome: str
    family: str
    horizon: _tasks_pb2.TaskHorizon
    reasoning: _tasks_pb2.ReasoningKind
    operator: _tasks_pb2.OperatorTier
    taskpedia_codes: _containers.RepeatedCompositeFieldContainer[_tasks_pb2.TaskpediaCodeRef]
    def __init__(self, task_id: _Optional[str] = ..., name: _Optional[str] = ..., outcome: _Optional[str] = ..., family: _Optional[str] = ..., horizon: _Optional[_Union[_tasks_pb2.TaskHorizon, str]] = ..., reasoning: _Optional[_Union[_tasks_pb2.ReasoningKind, str]] = ..., operator: _Optional[_Union[_tasks_pb2.OperatorTier, str]] = ..., taskpedia_codes: _Optional[_Iterable[_Union[_tasks_pb2.TaskpediaCodeRef, _Mapping]]] = ...) -> None: ...

class TaskGroundingDraft(_message.Message):
    __slots__ = ("rigs", "objects", "environment", "embodiment")
    RIGS_FIELD_NUMBER: _ClassVar[int]
    OBJECTS_FIELD_NUMBER: _ClassVar[int]
    ENVIRONMENT_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_FIELD_NUMBER: _ClassVar[int]
    rigs: _containers.RepeatedScalarFieldContainer[str]
    objects: _containers.RepeatedCompositeFieldContainer[_tasks_pb2.TaskObject]
    environment: _tasks_pb2.TaskEnvironment
    embodiment: _capabilities_pb2.TaskCapabilityRequirements
    def __init__(self, rigs: _Optional[_Iterable[str]] = ..., objects: _Optional[_Iterable[_Union[_tasks_pb2.TaskObject, _Mapping]]] = ..., environment: _Optional[_Union[_tasks_pb2.TaskEnvironment, _Mapping]] = ..., embodiment: _Optional[_Union[_capabilities_pb2.TaskCapabilityRequirements, _Mapping]] = ...) -> None: ...

class TaskProcedureDraft(_message.Message):
    __slots__ = ("steps",)
    STEPS_FIELD_NUMBER: _ClassVar[int]
    steps: _containers.RepeatedCompositeFieldContainer[_tasks_pb2.TaskStep]
    def __init__(self, steps: _Optional[_Iterable[_Union[_tasks_pb2.TaskStep, _Mapping]]] = ...) -> None: ...

class TaskProofDraft(_message.Message):
    __slots__ = ("success", "goal", "distractors", "initial_poses", "diversification", "variation", "capture", "evaluation", "complexity", "failure_conditions", "safety")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    GOAL_FIELD_NUMBER: _ClassVar[int]
    DISTRACTORS_FIELD_NUMBER: _ClassVar[int]
    INITIAL_POSES_FIELD_NUMBER: _ClassVar[int]
    DIVERSIFICATION_FIELD_NUMBER: _ClassVar[int]
    VARIATION_FIELD_NUMBER: _ClassVar[int]
    CAPTURE_FIELD_NUMBER: _ClassVar[int]
    EVALUATION_FIELD_NUMBER: _ClassVar[int]
    COMPLEXITY_FIELD_NUMBER: _ClassVar[int]
    FAILURE_CONDITIONS_FIELD_NUMBER: _ClassVar[int]
    SAFETY_FIELD_NUMBER: _ClassVar[int]
    success: str
    goal: _tasks_pb2.TaskGoal
    distractors: _tasks_pb2.DistractorPlan
    initial_poses: _tasks_pb2.InitialPosePlan
    diversification: _tasks_pb2.DiversificationPlan
    variation: _tasks_pb2.VariationPlan
    capture: _tasks_pb2.CapturePlan
    evaluation: _tasks_pb2.TaskEvaluationCriteria
    complexity: _containers.RepeatedScalarFieldContainer[_tasks_pb2.ComplexityAxis]
    failure_conditions: _containers.RepeatedCompositeFieldContainer[_tasks_pb2.FailureCondition]
    safety: str
    def __init__(self, success: _Optional[str] = ..., goal: _Optional[_Union[_tasks_pb2.TaskGoal, _Mapping]] = ..., distractors: _Optional[_Union[_tasks_pb2.DistractorPlan, _Mapping]] = ..., initial_poses: _Optional[_Union[_tasks_pb2.InitialPosePlan, _Mapping]] = ..., diversification: _Optional[_Union[_tasks_pb2.DiversificationPlan, _Mapping]] = ..., variation: _Optional[_Union[_tasks_pb2.VariationPlan, _Mapping]] = ..., capture: _Optional[_Union[_tasks_pb2.CapturePlan, _Mapping]] = ..., evaluation: _Optional[_Union[_tasks_pb2.TaskEvaluationCriteria, _Mapping]] = ..., complexity: _Optional[_Iterable[_Union[_tasks_pb2.ComplexityAxis, str]]] = ..., failure_conditions: _Optional[_Iterable[_Union[_tasks_pb2.FailureCondition, _Mapping]]] = ..., safety: _Optional[str] = ...) -> None: ...

class TaskDraftContent(_message.Message):
    __slots__ = ("intent", "grounding", "procedure", "proof")
    INTENT_FIELD_NUMBER: _ClassVar[int]
    GROUNDING_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_FIELD_NUMBER: _ClassVar[int]
    PROOF_FIELD_NUMBER: _ClassVar[int]
    intent: TaskIntentDraft
    grounding: TaskGroundingDraft
    procedure: TaskProcedureDraft
    proof: TaskProofDraft
    def __init__(self, intent: _Optional[_Union[TaskIntentDraft, _Mapping]] = ..., grounding: _Optional[_Union[TaskGroundingDraft, _Mapping]] = ..., procedure: _Optional[_Union[TaskProcedureDraft, _Mapping]] = ..., proof: _Optional[_Union[TaskProofDraft, _Mapping]] = ...) -> None: ...

class TaskDraftBaseline(_message.Message):
    __slots__ = ("source_ref", "contract")
    SOURCE_REF_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_FIELD_NUMBER: _ClassVar[int]
    source_ref: str
    contract: _tasks_pb2.TaskContract
    def __init__(self, source_ref: _Optional[str] = ..., contract: _Optional[_Union[_tasks_pb2.TaskContract, _Mapping]] = ...) -> None: ...

class TaskDraft(_message.Message):
    __slots__ = ("id", "project_id", "status", "revision", "title", "origin", "content", "context", "baseline", "created_by", "updated_by", "created_at", "updated_at", "published_ref")
    ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    ORIGIN_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    BASELINE_FIELD_NUMBER: _ClassVar[int]
    CREATED_BY_FIELD_NUMBER: _ClassVar[int]
    UPDATED_BY_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    PUBLISHED_REF_FIELD_NUMBER: _ClassVar[int]
    id: str
    project_id: str
    status: DraftStatus
    revision: int
    title: str
    origin: TaskDraftStart
    content: TaskDraftContent
    context: AuthoringContext
    baseline: TaskDraftBaseline
    created_by: str
    updated_by: str
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    published_ref: _common_pb2.TaskContractRef
    def __init__(self, id: _Optional[str] = ..., project_id: _Optional[str] = ..., status: _Optional[_Union[DraftStatus, str]] = ..., revision: _Optional[int] = ..., title: _Optional[str] = ..., origin: _Optional[_Union[TaskDraftStart, _Mapping]] = ..., content: _Optional[_Union[TaskDraftContent, _Mapping]] = ..., context: _Optional[_Union[AuthoringContext, _Mapping]] = ..., baseline: _Optional[_Union[TaskDraftBaseline, _Mapping]] = ..., created_by: _Optional[str] = ..., updated_by: _Optional[str] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., published_ref: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ...) -> None: ...

class TaskOpportunity(_message.Message):
    __slots__ = ("id", "task_id", "outcome", "family", "demand_rank", "taskpedia_codes", "matched_objects", "unmatched_object_heads", "body_state", "worlds_state", "blockers", "source_refs")
    ID_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    FAMILY_FIELD_NUMBER: _ClassVar[int]
    DEMAND_RANK_FIELD_NUMBER: _ClassVar[int]
    TASKPEDIA_CODES_FIELD_NUMBER: _ClassVar[int]
    MATCHED_OBJECTS_FIELD_NUMBER: _ClassVar[int]
    UNMATCHED_OBJECT_HEADS_FIELD_NUMBER: _ClassVar[int]
    BODY_STATE_FIELD_NUMBER: _ClassVar[int]
    WORLDS_STATE_FIELD_NUMBER: _ClassVar[int]
    BLOCKERS_FIELD_NUMBER: _ClassVar[int]
    SOURCE_REFS_FIELD_NUMBER: _ClassVar[int]
    id: str
    task_id: str
    outcome: str
    family: str
    demand_rank: int
    taskpedia_codes: _containers.RepeatedScalarFieldContainer[str]
    matched_objects: _containers.RepeatedCompositeFieldContainer[WorldObjectRef]
    unmatched_object_heads: _containers.RepeatedScalarFieldContainer[str]
    body_state: ProofState
    worlds_state: ProofState
    blockers: _containers.RepeatedScalarFieldContainer[str]
    source_refs: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, id: _Optional[str] = ..., task_id: _Optional[str] = ..., outcome: _Optional[str] = ..., family: _Optional[str] = ..., demand_rank: _Optional[int] = ..., taskpedia_codes: _Optional[_Iterable[str]] = ..., matched_objects: _Optional[_Iterable[_Union[WorldObjectRef, _Mapping]]] = ..., unmatched_object_heads: _Optional[_Iterable[str]] = ..., body_state: _Optional[_Union[ProofState, str]] = ..., worlds_state: _Optional[_Union[ProofState, str]] = ..., blockers: _Optional[_Iterable[str]] = ..., source_refs: _Optional[_Iterable[str]] = ...) -> None: ...

class TaskDraftProposal(_message.Message):
    __slots__ = ("id", "draft_id", "base_revision", "content", "rationale", "conversation_id", "turn_id", "tool_receipts", "evidence_refs", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    BASE_REVISION_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    RATIONALE_FIELD_NUMBER: _ClassVar[int]
    CONVERSATION_ID_FIELD_NUMBER: _ClassVar[int]
    TURN_ID_FIELD_NUMBER: _ClassVar[int]
    TOOL_RECEIPTS_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_REFS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    draft_id: str
    base_revision: int
    content: TaskDraftContent
    rationale: str
    conversation_id: str
    turn_id: str
    tool_receipts: _containers.RepeatedScalarFieldContainer[str]
    evidence_refs: _containers.RepeatedScalarFieldContainer[str]
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., draft_id: _Optional[str] = ..., base_revision: _Optional[int] = ..., content: _Optional[_Union[TaskDraftContent, _Mapping]] = ..., rationale: _Optional[str] = ..., conversation_id: _Optional[str] = ..., turn_id: _Optional[str] = ..., tool_receipts: _Optional[_Iterable[str]] = ..., evidence_refs: _Optional[_Iterable[str]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class TaskPublicationProgress(_message.Message):
    __slots__ = ("draft_revision", "attempts", "contract")
    DRAFT_REVISION_FIELD_NUMBER: _ClassVar[int]
    ATTEMPTS_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_FIELD_NUMBER: _ClassVar[int]
    draft_revision: int
    attempts: int
    contract: _common_pb2.TaskContractRef
    def __init__(self, draft_revision: _Optional[int] = ..., attempts: _Optional[int] = ..., contract: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ...) -> None: ...

class TaskPublication(_message.Message):
    __slots__ = ("metadata", "lifecycle", "progress")
    METADATA_FIELD_NUMBER: _ClassVar[int]
    LIFECYCLE_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_FIELD_NUMBER: _ClassVar[int]
    metadata: _operations_pb2.OperationMetadata
    lifecycle: _operations_pb2.OperationLifecycle
    progress: TaskPublicationProgress
    def __init__(self, metadata: _Optional[_Union[_operations_pb2.OperationMetadata, _Mapping]] = ..., lifecycle: _Optional[_Union[_operations_pb2.OperationLifecycle, _Mapping]] = ..., progress: _Optional[_Union[TaskPublicationProgress, _Mapping]] = ...) -> None: ...

class TaskPublicationResult(_message.Message):
    __slots__ = ("draft_id", "draft_revision", "contract")
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    DRAFT_REVISION_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    draft_revision: int
    contract: _common_pb2.TaskContractRef
    def __init__(self, draft_id: _Optional[str] = ..., draft_revision: _Optional[int] = ..., contract: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ...) -> None: ...

class ListTaskDraftsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListTaskDraftsResponse(_message.Message):
    __slots__ = ("drafts",)
    DRAFTS_FIELD_NUMBER: _ClassVar[int]
    drafts: _containers.RepeatedCompositeFieldContainer[TaskDraft]
    def __init__(self, drafts: _Optional[_Iterable[_Union[TaskDraft, _Mapping]]] = ...) -> None: ...

class CreateTaskDraftRequest(_message.Message):
    __slots__ = ("start", "context")
    START_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    start: TaskDraftStart
    context: AuthoringContext
    def __init__(self, start: _Optional[_Union[TaskDraftStart, _Mapping]] = ..., context: _Optional[_Union[AuthoringContext, _Mapping]] = ...) -> None: ...

class CreateTaskDraftResponse(_message.Message):
    __slots__ = ("draft",)
    DRAFT_FIELD_NUMBER: _ClassVar[int]
    draft: TaskDraft
    def __init__(self, draft: _Optional[_Union[TaskDraft, _Mapping]] = ...) -> None: ...

class GetTaskDraftRequest(_message.Message):
    __slots__ = ("draft_id",)
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    def __init__(self, draft_id: _Optional[str] = ...) -> None: ...

class GetTaskDraftResponse(_message.Message):
    __slots__ = ("draft",)
    DRAFT_FIELD_NUMBER: _ClassVar[int]
    draft: TaskDraft
    def __init__(self, draft: _Optional[_Union[TaskDraft, _Mapping]] = ...) -> None: ...

class UpdateTaskDraftRequest(_message.Message):
    __slots__ = ("draft_id", "expected_revision", "content", "context")
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_REVISION_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    expected_revision: int
    content: TaskDraftContent
    context: AuthoringContext
    def __init__(self, draft_id: _Optional[str] = ..., expected_revision: _Optional[int] = ..., content: _Optional[_Union[TaskDraftContent, _Mapping]] = ..., context: _Optional[_Union[AuthoringContext, _Mapping]] = ...) -> None: ...

class UpdateTaskDraftResponse(_message.Message):
    __slots__ = ("draft",)
    DRAFT_FIELD_NUMBER: _ClassVar[int]
    draft: TaskDraft
    def __init__(self, draft: _Optional[_Union[TaskDraft, _Mapping]] = ...) -> None: ...

class CheckTaskDraftRequest(_message.Message):
    __slots__ = ("draft_id",)
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    def __init__(self, draft_id: _Optional[str] = ...) -> None: ...

class CheckTaskDraftResponse(_message.Message):
    __slots__ = ("evaluation",)
    EVALUATION_FIELD_NUMBER: _ClassVar[int]
    evaluation: TaskDraftEvaluation
    def __init__(self, evaluation: _Optional[_Union[TaskDraftEvaluation, _Mapping]] = ...) -> None: ...

class GetLatestTaskDraftPublicationRequest(_message.Message):
    __slots__ = ("draft_id",)
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    def __init__(self, draft_id: _Optional[str] = ...) -> None: ...

class TaskDraftHasNoPublication(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetLatestTaskDraftPublicationResponse(_message.Message):
    __slots__ = ("publication", "not_started")
    PUBLICATION_FIELD_NUMBER: _ClassVar[int]
    NOT_STARTED_FIELD_NUMBER: _ClassVar[int]
    publication: TaskPublication
    not_started: TaskDraftHasNoPublication
    def __init__(self, publication: _Optional[_Union[TaskPublication, _Mapping]] = ..., not_started: _Optional[_Union[TaskDraftHasNoPublication, _Mapping]] = ...) -> None: ...

class ReviewTaskDraftRequest(_message.Message):
    __slots__ = ("draft_id",)
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    def __init__(self, draft_id: _Optional[str] = ...) -> None: ...

class ReviewTaskDraftResponse(_message.Message):
    __slots__ = ("review",)
    REVIEW_FIELD_NUMBER: _ClassVar[int]
    review: TaskDraftReview
    def __init__(self, review: _Optional[_Union[TaskDraftReview, _Mapping]] = ...) -> None: ...

class SearchTaskOpportunitiesRequest(_message.Message):
    __slots__ = ("scenes", "body_ref")
    SCENES_FIELD_NUMBER: _ClassVar[int]
    BODY_REF_FIELD_NUMBER: _ClassVar[int]
    scenes: _containers.RepeatedCompositeFieldContainer[SceneSelection]
    body_ref: str
    def __init__(self, scenes: _Optional[_Iterable[_Union[SceneSelection, _Mapping]]] = ..., body_ref: _Optional[str] = ...) -> None: ...

class SearchTaskOpportunitiesResponse(_message.Message):
    __slots__ = ("opportunities",)
    OPPORTUNITIES_FIELD_NUMBER: _ClassVar[int]
    opportunities: _containers.RepeatedCompositeFieldContainer[TaskOpportunity]
    def __init__(self, opportunities: _Optional[_Iterable[_Union[TaskOpportunity, _Mapping]]] = ...) -> None: ...

class ListTaskDraftProposalsRequest(_message.Message):
    __slots__ = ("draft_id",)
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    def __init__(self, draft_id: _Optional[str] = ...) -> None: ...

class ListTaskDraftProposalsResponse(_message.Message):
    __slots__ = ("proposals",)
    PROPOSALS_FIELD_NUMBER: _ClassVar[int]
    proposals: _containers.RepeatedCompositeFieldContainer[TaskDraftProposal]
    def __init__(self, proposals: _Optional[_Iterable[_Union[TaskDraftProposal, _Mapping]]] = ...) -> None: ...

class CreateTaskDraftProposalRequest(_message.Message):
    __slots__ = ("draft_id", "base_revision", "content", "rationale", "conversation_id", "turn_id", "tool_receipts", "evidence_refs")
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    BASE_REVISION_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    RATIONALE_FIELD_NUMBER: _ClassVar[int]
    CONVERSATION_ID_FIELD_NUMBER: _ClassVar[int]
    TURN_ID_FIELD_NUMBER: _ClassVar[int]
    TOOL_RECEIPTS_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_REFS_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    base_revision: int
    content: TaskDraftContent
    rationale: str
    conversation_id: str
    turn_id: str
    tool_receipts: _containers.RepeatedScalarFieldContainer[str]
    evidence_refs: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, draft_id: _Optional[str] = ..., base_revision: _Optional[int] = ..., content: _Optional[_Union[TaskDraftContent, _Mapping]] = ..., rationale: _Optional[str] = ..., conversation_id: _Optional[str] = ..., turn_id: _Optional[str] = ..., tool_receipts: _Optional[_Iterable[str]] = ..., evidence_refs: _Optional[_Iterable[str]] = ...) -> None: ...

class CreateTaskDraftProposalResponse(_message.Message):
    __slots__ = ("proposal",)
    PROPOSAL_FIELD_NUMBER: _ClassVar[int]
    proposal: TaskDraftProposal
    def __init__(self, proposal: _Optional[_Union[TaskDraftProposal, _Mapping]] = ...) -> None: ...

class ApplyTaskDraftProposalRequest(_message.Message):
    __slots__ = ("draft_id", "proposal_id", "expected_revision")
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    PROPOSAL_ID_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_REVISION_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    proposal_id: str
    expected_revision: int
    def __init__(self, draft_id: _Optional[str] = ..., proposal_id: _Optional[str] = ..., expected_revision: _Optional[int] = ...) -> None: ...

class ApplyTaskDraftProposalResponse(_message.Message):
    __slots__ = ("draft",)
    DRAFT_FIELD_NUMBER: _ClassVar[int]
    draft: TaskDraft
    def __init__(self, draft: _Optional[_Union[TaskDraft, _Mapping]] = ...) -> None: ...

class ReviewTaskDraftProposalRequest(_message.Message):
    __slots__ = ("draft_id", "proposal_id")
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    PROPOSAL_ID_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    proposal_id: str
    def __init__(self, draft_id: _Optional[str] = ..., proposal_id: _Optional[str] = ...) -> None: ...

class ReviewTaskDraftProposalResponse(_message.Message):
    __slots__ = ("review",)
    REVIEW_FIELD_NUMBER: _ClassVar[int]
    review: TaskDraftReview
    def __init__(self, review: _Optional[_Union[TaskDraftReview, _Mapping]] = ...) -> None: ...

class PublishTaskDraftRequest(_message.Message):
    __slots__ = ("draft_id", "expected_revision", "acknowledged_warning_codes")
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_REVISION_FIELD_NUMBER: _ClassVar[int]
    ACKNOWLEDGED_WARNING_CODES_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    expected_revision: int
    acknowledged_warning_codes: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, draft_id: _Optional[str] = ..., expected_revision: _Optional[int] = ..., acknowledged_warning_codes: _Optional[_Iterable[str]] = ...) -> None: ...

class PublishTaskDraftResponse(_message.Message):
    __slots__ = ("publication",)
    PUBLICATION_FIELD_NUMBER: _ClassVar[int]
    publication: TaskPublication
    def __init__(self, publication: _Optional[_Union[TaskPublication, _Mapping]] = ...) -> None: ...

class GetTaskPublicationRequest(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class GetTaskPublicationResponse(_message.Message):
    __slots__ = ("publication",)
    PUBLICATION_FIELD_NUMBER: _ClassVar[int]
    publication: TaskPublication
    def __init__(self, publication: _Optional[_Union[TaskPublication, _Mapping]] = ...) -> None: ...

class GetTaskPublicationResultRequest(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class GetTaskPublicationResultResponse(_message.Message):
    __slots__ = ("result",)
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: TaskPublicationResult
    def __init__(self, result: _Optional[_Union[TaskPublicationResult, _Mapping]] = ...) -> None: ...

class GetTaskPublicationUpdatesRequest(_message.Message):
    __slots__ = ("operation", "after_cursor", "limit", "wait_timeout")
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    AFTER_CURSOR_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    WAIT_TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    after_cursor: int
    limit: int
    wait_timeout: _duration_pb2.Duration
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., after_cursor: _Optional[int] = ..., limit: _Optional[int] = ..., wait_timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class TaskPublicationUpdatePage(_message.Message):
    __slots__ = ("updates", "next_cursor", "has_more")
    UPDATES_FIELD_NUMBER: _ClassVar[int]
    NEXT_CURSOR_FIELD_NUMBER: _ClassVar[int]
    HAS_MORE_FIELD_NUMBER: _ClassVar[int]
    updates: _containers.RepeatedCompositeFieldContainer[TaskPublication]
    next_cursor: int
    has_more: bool
    def __init__(self, updates: _Optional[_Iterable[_Union[TaskPublication, _Mapping]]] = ..., next_cursor: _Optional[int] = ..., has_more: _Optional[bool] = ...) -> None: ...

class GetTaskPublicationUpdatesResponse(_message.Message):
    __slots__ = ("page", "history_gap")
    PAGE_FIELD_NUMBER: _ClassVar[int]
    HISTORY_GAP_FIELD_NUMBER: _ClassVar[int]
    page: TaskPublicationUpdatePage
    history_gap: _operations_pb2.OperationHistoryGap
    def __init__(self, page: _Optional[_Union[TaskPublicationUpdatePage, _Mapping]] = ..., history_gap: _Optional[_Union[_operations_pb2.OperationHistoryGap, _Mapping]] = ...) -> None: ...

class CancelTaskPublicationRequest(_message.Message):
    __slots__ = ("operation", "reason")
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    reason: str
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., reason: _Optional[str] = ...) -> None: ...

class CancelTaskPublicationResponse(_message.Message):
    __slots__ = ("publication",)
    PUBLICATION_FIELD_NUMBER: _ClassVar[int]
    publication: TaskPublication
    def __init__(self, publication: _Optional[_Union[TaskPublication, _Mapping]] = ...) -> None: ...
