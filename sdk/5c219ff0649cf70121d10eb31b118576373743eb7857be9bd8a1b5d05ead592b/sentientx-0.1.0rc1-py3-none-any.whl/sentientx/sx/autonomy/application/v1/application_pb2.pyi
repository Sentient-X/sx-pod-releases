from buf.validate import validate_pb2 as _validate_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from sentientx.sx.experience.catalog.v1 import applications_pb2 as _applications_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ReviseApplicationRequest(_message.Message):
    __slots__ = ("base_application_ref", "candidate", "inputs")
    BASE_APPLICATION_REF_FIELD_NUMBER: _ClassVar[int]
    CANDIDATE_FIELD_NUMBER: _ClassVar[int]
    INPUTS_FIELD_NUMBER: _ClassVar[int]
    base_application_ref: str
    candidate: _applications_pb2.RobotApplicationDocument
    inputs: _containers.RepeatedCompositeFieldContainer[ApplicationInput]
    def __init__(self, base_application_ref: _Optional[str] = ..., candidate: _Optional[_Union[_applications_pb2.RobotApplicationDocument, _Mapping]] = ..., inputs: _Optional[_Iterable[_Union[ApplicationInput, _Mapping]]] = ...) -> None: ...

class ApplicationInput(_message.Message):
    __slots__ = ("content", "data")
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    content: _common_pb2.ContentRef
    data: bytes
    def __init__(self, content: _Optional[_Union[_common_pb2.ContentRef, _Mapping]] = ..., data: _Optional[bytes] = ...) -> None: ...

class ReviseApplicationResponse(_message.Message):
    __slots__ = ("application_ref",)
    APPLICATION_REF_FIELD_NUMBER: _ClassVar[int]
    application_ref: str
    def __init__(self, application_ref: _Optional[str] = ...) -> None: ...
