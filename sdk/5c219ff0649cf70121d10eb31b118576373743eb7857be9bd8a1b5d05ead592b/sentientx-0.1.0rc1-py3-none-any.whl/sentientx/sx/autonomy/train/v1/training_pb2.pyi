import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from sentientx.sx.operations.v1 import operations_pb2 as _operations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TrainingJobStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TRAINING_JOB_STATUS_UNSPECIFIED: _ClassVar[TrainingJobStatus]
    TRAINING_JOB_STATUS_QUEUED: _ClassVar[TrainingJobStatus]
    TRAINING_JOB_STATUS_RUNNING: _ClassVar[TrainingJobStatus]
    TRAINING_JOB_STATUS_SUCCEEDED: _ClassVar[TrainingJobStatus]
    TRAINING_JOB_STATUS_FAILED: _ClassVar[TrainingJobStatus]
    TRAINING_JOB_STATUS_CANCELLED: _ClassVar[TrainingJobStatus]

class TrainingJobEventKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TRAINING_JOB_EVENT_KIND_UNSPECIFIED: _ClassVar[TrainingJobEventKind]
    TRAINING_JOB_EVENT_KIND_JOB_QUEUED: _ClassVar[TrainingJobEventKind]
    TRAINING_JOB_EVENT_KIND_JOB_STARTED: _ClassVar[TrainingJobEventKind]
    TRAINING_JOB_EVENT_KIND_CANCELLATION_REQUESTED: _ClassVar[TrainingJobEventKind]
    TRAINING_JOB_EVENT_KIND_PUBLICATION_STARTED: _ClassVar[TrainingJobEventKind]
    TRAINING_JOB_EVENT_KIND_JOB_SUCCEEDED: _ClassVar[TrainingJobEventKind]
    TRAINING_JOB_EVENT_KIND_JOB_FAILED: _ClassVar[TrainingJobEventKind]
    TRAINING_JOB_EVENT_KIND_JOB_CANCELLED: _ClassVar[TrainingJobEventKind]
    TRAINING_JOB_EVENT_KIND_CHECKPOINT_CREATED: _ClassVar[TrainingJobEventKind]

class RecipePreset(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    RECIPE_PRESET_UNSPECIFIED: _ClassVar[RecipePreset]
    RECIPE_PRESET_PI0_BC: _ClassVar[RecipePreset]
    RECIPE_PRESET_PI05_BC: _ClassVar[RecipePreset]

class ModelPrecision(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    MODEL_PRECISION_UNSPECIFIED: _ClassVar[ModelPrecision]
    MODEL_PRECISION_BFLOAT16: _ClassVar[ModelPrecision]
    MODEL_PRECISION_FLOAT32: _ClassVar[ModelPrecision]

class Accelerator(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ACCELERATOR_UNSPECIFIED: _ClassVar[Accelerator]
    ACCELERATOR_T4: _ClassVar[Accelerator]
    ACCELERATOR_L4: _ClassVar[Accelerator]
    ACCELERATOR_A10: _ClassVar[Accelerator]
    ACCELERATOR_L40S: _ClassVar[Accelerator]
    ACCELERATOR_A100: _ClassVar[Accelerator]
    ACCELERATOR_A100_40GB: _ClassVar[Accelerator]
    ACCELERATOR_A100_80GB: _ClassVar[Accelerator]
    ACCELERATOR_RTX_PRO_6000: _ClassVar[Accelerator]
    ACCELERATOR_H100: _ClassVar[Accelerator]
    ACCELERATOR_H100_STRICT: _ClassVar[Accelerator]
    ACCELERATOR_H200: _ClassVar[Accelerator]
    ACCELERATOR_B200: _ClassVar[Accelerator]
    ACCELERATOR_B200_PLUS: _ClassVar[Accelerator]
    ACCELERATOR_B300: _ClassVar[Accelerator]

class ExecutionArchitecture(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EXECUTION_ARCHITECTURE_UNSPECIFIED: _ClassVar[ExecutionArchitecture]
    EXECUTION_ARCHITECTURE_AMD64: _ClassVar[ExecutionArchitecture]
TRAINING_JOB_STATUS_UNSPECIFIED: TrainingJobStatus
TRAINING_JOB_STATUS_QUEUED: TrainingJobStatus
TRAINING_JOB_STATUS_RUNNING: TrainingJobStatus
TRAINING_JOB_STATUS_SUCCEEDED: TrainingJobStatus
TRAINING_JOB_STATUS_FAILED: TrainingJobStatus
TRAINING_JOB_STATUS_CANCELLED: TrainingJobStatus
TRAINING_JOB_EVENT_KIND_UNSPECIFIED: TrainingJobEventKind
TRAINING_JOB_EVENT_KIND_JOB_QUEUED: TrainingJobEventKind
TRAINING_JOB_EVENT_KIND_JOB_STARTED: TrainingJobEventKind
TRAINING_JOB_EVENT_KIND_CANCELLATION_REQUESTED: TrainingJobEventKind
TRAINING_JOB_EVENT_KIND_PUBLICATION_STARTED: TrainingJobEventKind
TRAINING_JOB_EVENT_KIND_JOB_SUCCEEDED: TrainingJobEventKind
TRAINING_JOB_EVENT_KIND_JOB_FAILED: TrainingJobEventKind
TRAINING_JOB_EVENT_KIND_JOB_CANCELLED: TrainingJobEventKind
TRAINING_JOB_EVENT_KIND_CHECKPOINT_CREATED: TrainingJobEventKind
RECIPE_PRESET_UNSPECIFIED: RecipePreset
RECIPE_PRESET_PI0_BC: RecipePreset
RECIPE_PRESET_PI05_BC: RecipePreset
MODEL_PRECISION_UNSPECIFIED: ModelPrecision
MODEL_PRECISION_BFLOAT16: ModelPrecision
MODEL_PRECISION_FLOAT32: ModelPrecision
ACCELERATOR_UNSPECIFIED: Accelerator
ACCELERATOR_T4: Accelerator
ACCELERATOR_L4: Accelerator
ACCELERATOR_A10: Accelerator
ACCELERATOR_L40S: Accelerator
ACCELERATOR_A100: Accelerator
ACCELERATOR_A100_40GB: Accelerator
ACCELERATOR_A100_80GB: Accelerator
ACCELERATOR_RTX_PRO_6000: Accelerator
ACCELERATOR_H100: Accelerator
ACCELERATOR_H100_STRICT: Accelerator
ACCELERATOR_H200: Accelerator
ACCELERATOR_B200: Accelerator
ACCELERATOR_B200_PLUS: Accelerator
ACCELERATOR_B300: Accelerator
EXECUTION_ARCHITECTURE_UNSPECIFIED: ExecutionArchitecture
EXECUTION_ARCHITECTURE_AMD64: ExecutionArchitecture

class FromScratch(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class InitialWeights(_message.Message):
    __slots__ = ("governed", "from_scratch")
    GOVERNED_FIELD_NUMBER: _ClassVar[int]
    FROM_SCRATCH_FIELD_NUMBER: _ClassVar[int]
    governed: _common_pb2.ContentRef
    from_scratch: FromScratch
    def __init__(self, governed: _Optional[_Union[_common_pb2.ContentRef, _Mapping]] = ..., from_scratch: _Optional[_Union[FromScratch, _Mapping]] = ...) -> None: ...

class WholeTaskPrompt(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class StepPrompt(_message.Message):
    __slots__ = ("task_id",)
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    def __init__(self, task_id: _Optional[str] = ...) -> None: ...

class TaskPrompt(_message.Message):
    __slots__ = ("whole_task", "step")
    WHOLE_TASK_FIELD_NUMBER: _ClassVar[int]
    STEP_FIELD_NUMBER: _ClassVar[int]
    whole_task: WholeTaskPrompt
    step: StepPrompt
    def __init__(self, whole_task: _Optional[_Union[WholeTaskPrompt, _Mapping]] = ..., step: _Optional[_Union[StepPrompt, _Mapping]] = ...) -> None: ...

class AdvantageConditioning(_message.Message):
    __slots__ = ("value_checkpoint", "positive_fraction", "failure_cost", "max_task_steps")
    VALUE_CHECKPOINT_FIELD_NUMBER: _ClassVar[int]
    POSITIVE_FRACTION_FIELD_NUMBER: _ClassVar[int]
    FAILURE_COST_FIELD_NUMBER: _ClassVar[int]
    MAX_TASK_STEPS_FIELD_NUMBER: _ClassVar[int]
    value_checkpoint: _common_pb2.ContentRef
    positive_fraction: float
    failure_cost: float
    max_task_steps: int
    def __init__(self, value_checkpoint: _Optional[_Union[_common_pb2.ContentRef, _Mapping]] = ..., positive_fraction: _Optional[float] = ..., failure_cost: _Optional[float] = ..., max_task_steps: _Optional[int] = ...) -> None: ...

class BCRecipe(_message.Message):
    __slots__ = ("action_horizon", "paligemma_variant", "action_expert_variant", "dtype", "action_dim", "pi05", "discrete_state_input", "initial_weights", "image_resolution", "freeze_vision_encoder", "train_expert_only", "gradient_checkpointing", "tokenizer_name", "max_token_len", "lr", "beta1", "beta2", "eps", "weight_decay", "grad_clip_norm", "warmup_steps", "decay_steps", "decay_lr", "steps", "log_every", "checkpoint_every", "state_max_age_s", "camera_max_age_s", "precompute", "precompute_batch_size", "precompute_prefix_embeddings", "history_frames", "prompt", "history_stride", "context_metadata", "metadata_drop_all", "metadata_drop_component", "speed_bin_size", "subgoal_fraction", "subgoal_end_fraction", "subgoal_max_ahead", "advantage", "schema_version")
    ACTION_HORIZON_FIELD_NUMBER: _ClassVar[int]
    PALIGEMMA_VARIANT_FIELD_NUMBER: _ClassVar[int]
    ACTION_EXPERT_VARIANT_FIELD_NUMBER: _ClassVar[int]
    DTYPE_FIELD_NUMBER: _ClassVar[int]
    ACTION_DIM_FIELD_NUMBER: _ClassVar[int]
    PI05_FIELD_NUMBER: _ClassVar[int]
    DISCRETE_STATE_INPUT_FIELD_NUMBER: _ClassVar[int]
    INITIAL_WEIGHTS_FIELD_NUMBER: _ClassVar[int]
    IMAGE_RESOLUTION_FIELD_NUMBER: _ClassVar[int]
    FREEZE_VISION_ENCODER_FIELD_NUMBER: _ClassVar[int]
    TRAIN_EXPERT_ONLY_FIELD_NUMBER: _ClassVar[int]
    GRADIENT_CHECKPOINTING_FIELD_NUMBER: _ClassVar[int]
    TOKENIZER_NAME_FIELD_NUMBER: _ClassVar[int]
    MAX_TOKEN_LEN_FIELD_NUMBER: _ClassVar[int]
    LR_FIELD_NUMBER: _ClassVar[int]
    BETA1_FIELD_NUMBER: _ClassVar[int]
    BETA2_FIELD_NUMBER: _ClassVar[int]
    EPS_FIELD_NUMBER: _ClassVar[int]
    WEIGHT_DECAY_FIELD_NUMBER: _ClassVar[int]
    GRAD_CLIP_NORM_FIELD_NUMBER: _ClassVar[int]
    WARMUP_STEPS_FIELD_NUMBER: _ClassVar[int]
    DECAY_STEPS_FIELD_NUMBER: _ClassVar[int]
    DECAY_LR_FIELD_NUMBER: _ClassVar[int]
    STEPS_FIELD_NUMBER: _ClassVar[int]
    LOG_EVERY_FIELD_NUMBER: _ClassVar[int]
    CHECKPOINT_EVERY_FIELD_NUMBER: _ClassVar[int]
    STATE_MAX_AGE_S_FIELD_NUMBER: _ClassVar[int]
    CAMERA_MAX_AGE_S_FIELD_NUMBER: _ClassVar[int]
    PRECOMPUTE_FIELD_NUMBER: _ClassVar[int]
    PRECOMPUTE_BATCH_SIZE_FIELD_NUMBER: _ClassVar[int]
    PRECOMPUTE_PREFIX_EMBEDDINGS_FIELD_NUMBER: _ClassVar[int]
    HISTORY_FRAMES_FIELD_NUMBER: _ClassVar[int]
    PROMPT_FIELD_NUMBER: _ClassVar[int]
    HISTORY_STRIDE_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_METADATA_FIELD_NUMBER: _ClassVar[int]
    METADATA_DROP_ALL_FIELD_NUMBER: _ClassVar[int]
    METADATA_DROP_COMPONENT_FIELD_NUMBER: _ClassVar[int]
    SPEED_BIN_SIZE_FIELD_NUMBER: _ClassVar[int]
    SUBGOAL_FRACTION_FIELD_NUMBER: _ClassVar[int]
    SUBGOAL_END_FRACTION_FIELD_NUMBER: _ClassVar[int]
    SUBGOAL_MAX_AHEAD_FIELD_NUMBER: _ClassVar[int]
    ADVANTAGE_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_VERSION_FIELD_NUMBER: _ClassVar[int]
    action_horizon: int
    paligemma_variant: str
    action_expert_variant: str
    dtype: ModelPrecision
    action_dim: int
    pi05: bool
    discrete_state_input: bool
    initial_weights: InitialWeights
    image_resolution: int
    freeze_vision_encoder: bool
    train_expert_only: bool
    gradient_checkpointing: bool
    tokenizer_name: str
    max_token_len: int
    lr: float
    beta1: float
    beta2: float
    eps: float
    weight_decay: float
    grad_clip_norm: float
    warmup_steps: int
    decay_steps: int
    decay_lr: float
    steps: int
    log_every: int
    checkpoint_every: int
    state_max_age_s: float
    camera_max_age_s: float
    precompute: bool
    precompute_batch_size: int
    precompute_prefix_embeddings: bool
    history_frames: int
    prompt: TaskPrompt
    history_stride: int
    context_metadata: bool
    metadata_drop_all: float
    metadata_drop_component: float
    speed_bin_size: int
    subgoal_fraction: float
    subgoal_end_fraction: float
    subgoal_max_ahead: int
    advantage: AdvantageConditioning
    schema_version: int
    def __init__(self, action_horizon: _Optional[int] = ..., paligemma_variant: _Optional[str] = ..., action_expert_variant: _Optional[str] = ..., dtype: _Optional[_Union[ModelPrecision, str]] = ..., action_dim: _Optional[int] = ..., pi05: _Optional[bool] = ..., discrete_state_input: _Optional[bool] = ..., initial_weights: _Optional[_Union[InitialWeights, _Mapping]] = ..., image_resolution: _Optional[int] = ..., freeze_vision_encoder: _Optional[bool] = ..., train_expert_only: _Optional[bool] = ..., gradient_checkpointing: _Optional[bool] = ..., tokenizer_name: _Optional[str] = ..., max_token_len: _Optional[int] = ..., lr: _Optional[float] = ..., beta1: _Optional[float] = ..., beta2: _Optional[float] = ..., eps: _Optional[float] = ..., weight_decay: _Optional[float] = ..., grad_clip_norm: _Optional[float] = ..., warmup_steps: _Optional[int] = ..., decay_steps: _Optional[int] = ..., decay_lr: _Optional[float] = ..., steps: _Optional[int] = ..., log_every: _Optional[int] = ..., checkpoint_every: _Optional[int] = ..., state_max_age_s: _Optional[float] = ..., camera_max_age_s: _Optional[float] = ..., precompute: _Optional[bool] = ..., precompute_batch_size: _Optional[int] = ..., precompute_prefix_embeddings: _Optional[bool] = ..., history_frames: _Optional[int] = ..., prompt: _Optional[_Union[TaskPrompt, _Mapping]] = ..., history_stride: _Optional[int] = ..., context_metadata: _Optional[bool] = ..., metadata_drop_all: _Optional[float] = ..., metadata_drop_component: _Optional[float] = ..., speed_bin_size: _Optional[int] = ..., subgoal_fraction: _Optional[float] = ..., subgoal_end_fraction: _Optional[float] = ..., subgoal_max_ahead: _Optional[int] = ..., advantage: _Optional[_Union[AdvantageConditioning, _Mapping]] = ..., schema_version: _Optional[int] = ...) -> None: ...

class TrainingExecution(_message.Message):
    __slots__ = ("architecture", "accelerator", "accelerator_count", "minimum_vram_mib", "runtime_abi", "cpus", "memory_gib", "batch_size", "seed")
    ARCHITECTURE_FIELD_NUMBER: _ClassVar[int]
    ACCELERATOR_FIELD_NUMBER: _ClassVar[int]
    ACCELERATOR_COUNT_FIELD_NUMBER: _ClassVar[int]
    MINIMUM_VRAM_MIB_FIELD_NUMBER: _ClassVar[int]
    RUNTIME_ABI_FIELD_NUMBER: _ClassVar[int]
    CPUS_FIELD_NUMBER: _ClassVar[int]
    MEMORY_GIB_FIELD_NUMBER: _ClassVar[int]
    BATCH_SIZE_FIELD_NUMBER: _ClassVar[int]
    SEED_FIELD_NUMBER: _ClassVar[int]
    architecture: ExecutionArchitecture
    accelerator: Accelerator
    accelerator_count: int
    minimum_vram_mib: int
    runtime_abi: str
    cpus: int
    memory_gib: int
    batch_size: int
    seed: int
    def __init__(self, architecture: _Optional[_Union[ExecutionArchitecture, str]] = ..., accelerator: _Optional[_Union[Accelerator, str]] = ..., accelerator_count: _Optional[int] = ..., minimum_vram_mib: _Optional[int] = ..., runtime_abi: _Optional[str] = ..., cpus: _Optional[int] = ..., memory_gib: _Optional[int] = ..., batch_size: _Optional[int] = ..., seed: _Optional[int] = ...) -> None: ...

class CorpusSnapshotRef(_message.Message):
    __slots__ = ("name", "sha256")
    NAME_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    name: str
    sha256: str
    def __init__(self, name: _Optional[str] = ..., sha256: _Optional[str] = ...) -> None: ...

class TrainingDomain(_message.Message):
    __slots__ = ("name", "embodiment_name", "embodiment_id", "action_interface_id", "member_count")
    NAME_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_NAME_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ACTION_INTERFACE_ID_FIELD_NUMBER: _ClassVar[int]
    MEMBER_COUNT_FIELD_NUMBER: _ClassVar[int]
    name: str
    embodiment_name: str
    embodiment_id: str
    action_interface_id: str
    member_count: int
    def __init__(self, name: _Optional[str] = ..., embodiment_name: _Optional[str] = ..., embodiment_id: _Optional[str] = ..., action_interface_id: _Optional[str] = ..., member_count: _Optional[int] = ...) -> None: ...

class TrainingJobFailure(_message.Message):
    __slots__ = ("code", "message", "retryable")
    CODE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    RETRYABLE_FIELD_NUMBER: _ClassVar[int]
    code: str
    message: str
    retryable: bool
    def __init__(self, code: _Optional[str] = ..., message: _Optional[str] = ..., retryable: _Optional[bool] = ...) -> None: ...

class TrainingJob(_message.Message):
    __slots__ = ("id", "status", "recipe", "execution", "waddle_run_id", "corpus_name", "corpus_sha256", "domains", "created_at", "updated_at", "failure")
    ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    RECIPE_FIELD_NUMBER: _ClassVar[int]
    EXECUTION_FIELD_NUMBER: _ClassVar[int]
    WADDLE_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    CORPUS_NAME_FIELD_NUMBER: _ClassVar[int]
    CORPUS_SHA256_FIELD_NUMBER: _ClassVar[int]
    DOMAINS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    id: str
    status: TrainingJobStatus
    recipe: BCRecipe
    execution: TrainingExecution
    waddle_run_id: str
    corpus_name: str
    corpus_sha256: str
    domains: _containers.RepeatedCompositeFieldContainer[TrainingDomain]
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    failure: TrainingJobFailure
    def __init__(self, id: _Optional[str] = ..., status: _Optional[_Union[TrainingJobStatus, str]] = ..., recipe: _Optional[_Union[BCRecipe, _Mapping]] = ..., execution: _Optional[_Union[TrainingExecution, _Mapping]] = ..., waddle_run_id: _Optional[str] = ..., corpus_name: _Optional[str] = ..., corpus_sha256: _Optional[str] = ..., domains: _Optional[_Iterable[_Union[TrainingDomain, _Mapping]]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., failure: _Optional[_Union[TrainingJobFailure, _Mapping]] = ...) -> None: ...

class TrainingJobEvent(_message.Message):
    __slots__ = ("id", "job_id", "kind", "created_at", "message")
    ID_FIELD_NUMBER: _ClassVar[int]
    JOB_ID_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    id: str
    job_id: str
    kind: TrainingJobEventKind
    created_at: _timestamp_pb2.Timestamp
    message: str
    def __init__(self, id: _Optional[str] = ..., job_id: _Optional[str] = ..., kind: _Optional[_Union[TrainingJobEventKind, str]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., message: _Optional[str] = ...) -> None: ...

class TrainingCheckpoint(_message.Message):
    __slots__ = ("checkpoint", "job_id", "artifact_uri", "step", "created_at")
    CHECKPOINT_FIELD_NUMBER: _ClassVar[int]
    JOB_ID_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_URI_FIELD_NUMBER: _ClassVar[int]
    STEP_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    checkpoint: _common_pb2.ContentRef
    job_id: str
    artifact_uri: str
    step: int
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, checkpoint: _Optional[_Union[_common_pb2.ContentRef, _Mapping]] = ..., job_id: _Optional[str] = ..., artifact_uri: _Optional[str] = ..., step: _Optional[int] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class TrainingProgress(_message.Message):
    __slots__ = ("completed_steps", "total_steps", "latest_checkpoint")
    COMPLETED_STEPS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_STEPS_FIELD_NUMBER: _ClassVar[int]
    LATEST_CHECKPOINT_FIELD_NUMBER: _ClassVar[int]
    completed_steps: int
    total_steps: int
    latest_checkpoint: str
    def __init__(self, completed_steps: _Optional[int] = ..., total_steps: _Optional[int] = ..., latest_checkpoint: _Optional[str] = ...) -> None: ...

class TrainingOperation(_message.Message):
    __slots__ = ("metadata", "lifecycle", "progress")
    METADATA_FIELD_NUMBER: _ClassVar[int]
    LIFECYCLE_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_FIELD_NUMBER: _ClassVar[int]
    metadata: _operations_pb2.OperationMetadata
    lifecycle: _operations_pb2.OperationLifecycle
    progress: TrainingProgress
    def __init__(self, metadata: _Optional[_Union[_operations_pb2.OperationMetadata, _Mapping]] = ..., lifecycle: _Optional[_Union[_operations_pb2.OperationLifecycle, _Mapping]] = ..., progress: _Optional[_Union[TrainingProgress, _Mapping]] = ...) -> None: ...

class VlaPolicy(_message.Message):
    __slots__ = ("artifact", "checkpoint")
    ARTIFACT_FIELD_NUMBER: _ClassVar[int]
    CHECKPOINT_FIELD_NUMBER: _ClassVar[int]
    artifact: _common_pb2.ContentRef
    checkpoint: _common_pb2.ContentRef
    def __init__(self, artifact: _Optional[_Union[_common_pb2.ContentRef, _Mapping]] = ..., checkpoint: _Optional[_Union[_common_pb2.ContentRef, _Mapping]] = ...) -> None: ...

class TrainingResult(_message.Message):
    __slots__ = ("vla",)
    VLA_FIELD_NUMBER: _ClassVar[int]
    vla: VlaPolicy
    def __init__(self, vla: _Optional[_Union[VlaPolicy, _Mapping]] = ...) -> None: ...

class TrainingOperationResult(_message.Message):
    __slots__ = ("training",)
    TRAINING_FIELD_NUMBER: _ClassVar[int]
    training: TrainingResult
    def __init__(self, training: _Optional[_Union[TrainingResult, _Mapping]] = ...) -> None: ...

class CreateTrainingJobRequest(_message.Message):
    __slots__ = ("data", "recipe", "execution", "timeout")
    DATA_FIELD_NUMBER: _ClassVar[int]
    RECIPE_FIELD_NUMBER: _ClassVar[int]
    EXECUTION_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    data: CorpusSnapshotRef
    recipe: RecipePreset
    execution: TrainingExecution
    timeout: _duration_pb2.Duration
    def __init__(self, data: _Optional[_Union[CorpusSnapshotRef, _Mapping]] = ..., recipe: _Optional[_Union[RecipePreset, str]] = ..., execution: _Optional[_Union[TrainingExecution, _Mapping]] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class CreateTrainingJobResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: TrainingOperation
    def __init__(self, operation: _Optional[_Union[TrainingOperation, _Mapping]] = ...) -> None: ...

class CreateCustomTrainingJobRequest(_message.Message):
    __slots__ = ("data", "recipe", "execution", "timeout")
    DATA_FIELD_NUMBER: _ClassVar[int]
    RECIPE_FIELD_NUMBER: _ClassVar[int]
    EXECUTION_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    data: CorpusSnapshotRef
    recipe: BCRecipe
    execution: TrainingExecution
    timeout: _duration_pb2.Duration
    def __init__(self, data: _Optional[_Union[CorpusSnapshotRef, _Mapping]] = ..., recipe: _Optional[_Union[BCRecipe, _Mapping]] = ..., execution: _Optional[_Union[TrainingExecution, _Mapping]] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class CreateCustomTrainingJobResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: TrainingOperation
    def __init__(self, operation: _Optional[_Union[TrainingOperation, _Mapping]] = ...) -> None: ...

class ListTrainingJobsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListTrainingJobsResponse(_message.Message):
    __slots__ = ("jobs",)
    JOBS_FIELD_NUMBER: _ClassVar[int]
    jobs: _containers.RepeatedCompositeFieldContainer[TrainingJob]
    def __init__(self, jobs: _Optional[_Iterable[_Union[TrainingJob, _Mapping]]] = ...) -> None: ...

class GetTrainingJobRequest(_message.Message):
    __slots__ = ("job_id",)
    JOB_ID_FIELD_NUMBER: _ClassVar[int]
    job_id: str
    def __init__(self, job_id: _Optional[str] = ...) -> None: ...

class GetTrainingJobResponse(_message.Message):
    __slots__ = ("job",)
    JOB_FIELD_NUMBER: _ClassVar[int]
    job: TrainingJob
    def __init__(self, job: _Optional[_Union[TrainingJob, _Mapping]] = ...) -> None: ...

class ListTrainingJobEventsRequest(_message.Message):
    __slots__ = ("job_id",)
    JOB_ID_FIELD_NUMBER: _ClassVar[int]
    job_id: str
    def __init__(self, job_id: _Optional[str] = ...) -> None: ...

class ListTrainingJobEventsResponse(_message.Message):
    __slots__ = ("events",)
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    events: _containers.RepeatedCompositeFieldContainer[TrainingJobEvent]
    def __init__(self, events: _Optional[_Iterable[_Union[TrainingJobEvent, _Mapping]]] = ...) -> None: ...

class ListTrainingJobCheckpointsRequest(_message.Message):
    __slots__ = ("job_id",)
    JOB_ID_FIELD_NUMBER: _ClassVar[int]
    job_id: str
    def __init__(self, job_id: _Optional[str] = ...) -> None: ...

class ListTrainingJobCheckpointsResponse(_message.Message):
    __slots__ = ("checkpoints",)
    CHECKPOINTS_FIELD_NUMBER: _ClassVar[int]
    checkpoints: _containers.RepeatedCompositeFieldContainer[TrainingCheckpoint]
    def __init__(self, checkpoints: _Optional[_Iterable[_Union[TrainingCheckpoint, _Mapping]]] = ...) -> None: ...

class GetTrainingOperationRequest(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class GetTrainingOperationResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: TrainingOperation
    def __init__(self, operation: _Optional[_Union[TrainingOperation, _Mapping]] = ...) -> None: ...

class GetTrainingOperationUpdatesRequest(_message.Message):
    __slots__ = ("operation", "after_cursor", "limit", "wait_timeout")
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    AFTER_CURSOR_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    WAIT_TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    after_cursor: int
    limit: int
    wait_timeout: _duration_pb2.Duration
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., after_cursor: _Optional[int] = ..., limit: _Optional[int] = ..., wait_timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class TrainingOperationUpdatePage(_message.Message):
    __slots__ = ("updates", "next_cursor", "has_more")
    UPDATES_FIELD_NUMBER: _ClassVar[int]
    NEXT_CURSOR_FIELD_NUMBER: _ClassVar[int]
    HAS_MORE_FIELD_NUMBER: _ClassVar[int]
    updates: _containers.RepeatedCompositeFieldContainer[TrainingOperation]
    next_cursor: int
    has_more: bool
    def __init__(self, updates: _Optional[_Iterable[_Union[TrainingOperation, _Mapping]]] = ..., next_cursor: _Optional[int] = ..., has_more: _Optional[bool] = ...) -> None: ...

class GetTrainingOperationUpdatesResponse(_message.Message):
    __slots__ = ("page", "history_gap")
    PAGE_FIELD_NUMBER: _ClassVar[int]
    HISTORY_GAP_FIELD_NUMBER: _ClassVar[int]
    page: TrainingOperationUpdatePage
    history_gap: _operations_pb2.OperationHistoryGap
    def __init__(self, page: _Optional[_Union[TrainingOperationUpdatePage, _Mapping]] = ..., history_gap: _Optional[_Union[_operations_pb2.OperationHistoryGap, _Mapping]] = ...) -> None: ...

class GetTrainingOperationResultRequest(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class GetTrainingOperationResultResponse(_message.Message):
    __slots__ = ("result",)
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: TrainingOperationResult
    def __init__(self, result: _Optional[_Union[TrainingOperationResult, _Mapping]] = ...) -> None: ...

class CancelTrainingOperationRequest(_message.Message):
    __slots__ = ("operation", "reason")
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    reason: str
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., reason: _Optional[str] = ...) -> None: ...

class CancelTrainingOperationResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: TrainingOperation
    def __init__(self, operation: _Optional[_Union[TrainingOperation, _Mapping]] = ...) -> None: ...
