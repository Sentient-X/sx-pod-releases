import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from sentientx.sx.operations.v1 import operations_pb2 as _operations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CampaignExecutionState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CAMPAIGN_EXECUTION_STATE_UNSPECIFIED: _ClassVar[CampaignExecutionState]
    CAMPAIGN_EXECUTION_STATE_RUNNING: _ClassVar[CampaignExecutionState]
    CAMPAIGN_EXECUTION_STATE_COMPLETED: _ClassVar[CampaignExecutionState]
    CAMPAIGN_EXECUTION_STATE_FAILED: _ClassVar[CampaignExecutionState]
    CAMPAIGN_EXECUTION_STATE_CANCELLED: _ClassVar[CampaignExecutionState]
    CAMPAIGN_EXECUTION_STATE_TERMINATED: _ClassVar[CampaignExecutionState]
    CAMPAIGN_EXECUTION_STATE_CONTINUED_AS_NEW: _ClassVar[CampaignExecutionState]
    CAMPAIGN_EXECUTION_STATE_TIMED_OUT: _ClassVar[CampaignExecutionState]

class CampaignOutcome(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CAMPAIGN_OUTCOME_UNSPECIFIED: _ClassVar[CampaignOutcome]
    CAMPAIGN_OUTCOME_GATE_MET: _ClassVar[CampaignOutcome]
    CAMPAIGN_OUTCOME_BUDGET_EXHAUSTED: _ClassVar[CampaignOutcome]
    CAMPAIGN_OUTCOME_STOPPED: _ClassVar[CampaignOutcome]
    CAMPAIGN_OUTCOME_TIMED_OUT: _ClassVar[CampaignOutcome]
    CAMPAIGN_OUTCOME_FAILED: _ClassVar[CampaignOutcome]

class RoundVerdict(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ROUND_VERDICT_UNSPECIFIED: _ClassVar[RoundVerdict]
    ROUND_VERDICT_GATE_MET: _ClassVar[RoundVerdict]
    ROUND_VERDICT_CONTINUE: _ClassVar[RoundVerdict]
    ROUND_VERDICT_STEP_FAILED: _ClassVar[RoundVerdict]

class Settlement(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SETTLEMENT_UNSPECIFIED: _ClassVar[Settlement]
    SETTLEMENT_EMPTY: _ClassVar[Settlement]
    SETTLEMENT_SELECTED: _ClassVar[Settlement]
    SETTLEMENT_DISCARDED: _ClassVar[Settlement]

class GenerationSource(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    GENERATION_SOURCE_UNSPECIFIED: _ClassVar[GenerationSource]
    GENERATION_SOURCE_SCRIPTED: _ClassVar[GenerationSource]
    GENERATION_SOURCE_APPLICATION: _ClassVar[GenerationSource]
    GENERATION_SOURCE_MIMICGEN: _ClassVar[GenerationSource]
    GENERATION_SOURCE_AGENTIC: _ClassVar[GenerationSource]

class FailureDoor(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    FAILURE_DOOR_UNSPECIFIED: _ClassVar[FailureDoor]
    FAILURE_DOOR_TRAIN: _ClassVar[FailureDoor]
    FAILURE_DOOR_AUTONOMY: _ClassVar[FailureDoor]
    FAILURE_DOOR_WORLDS: _ClassVar[FailureDoor]
    FAILURE_DOOR_EXPERIENCE: _ClassVar[FailureDoor]
    FAILURE_DOOR_CATALOG: _ClassVar[FailureDoor]
    FAILURE_DOOR_WADDLE: _ClassVar[FailureDoor]
    FAILURE_DOOR_FLEET_RESEARCH: _ClassVar[FailureDoor]
CAMPAIGN_EXECUTION_STATE_UNSPECIFIED: CampaignExecutionState
CAMPAIGN_EXECUTION_STATE_RUNNING: CampaignExecutionState
CAMPAIGN_EXECUTION_STATE_COMPLETED: CampaignExecutionState
CAMPAIGN_EXECUTION_STATE_FAILED: CampaignExecutionState
CAMPAIGN_EXECUTION_STATE_CANCELLED: CampaignExecutionState
CAMPAIGN_EXECUTION_STATE_TERMINATED: CampaignExecutionState
CAMPAIGN_EXECUTION_STATE_CONTINUED_AS_NEW: CampaignExecutionState
CAMPAIGN_EXECUTION_STATE_TIMED_OUT: CampaignExecutionState
CAMPAIGN_OUTCOME_UNSPECIFIED: CampaignOutcome
CAMPAIGN_OUTCOME_GATE_MET: CampaignOutcome
CAMPAIGN_OUTCOME_BUDGET_EXHAUSTED: CampaignOutcome
CAMPAIGN_OUTCOME_STOPPED: CampaignOutcome
CAMPAIGN_OUTCOME_TIMED_OUT: CampaignOutcome
CAMPAIGN_OUTCOME_FAILED: CampaignOutcome
ROUND_VERDICT_UNSPECIFIED: RoundVerdict
ROUND_VERDICT_GATE_MET: RoundVerdict
ROUND_VERDICT_CONTINUE: RoundVerdict
ROUND_VERDICT_STEP_FAILED: RoundVerdict
SETTLEMENT_UNSPECIFIED: Settlement
SETTLEMENT_EMPTY: Settlement
SETTLEMENT_SELECTED: Settlement
SETTLEMENT_DISCARDED: Settlement
GENERATION_SOURCE_UNSPECIFIED: GenerationSource
GENERATION_SOURCE_SCRIPTED: GenerationSource
GENERATION_SOURCE_APPLICATION: GenerationSource
GENERATION_SOURCE_MIMICGEN: GenerationSource
GENERATION_SOURCE_AGENTIC: GenerationSource
FAILURE_DOOR_UNSPECIFIED: FailureDoor
FAILURE_DOOR_TRAIN: FailureDoor
FAILURE_DOOR_AUTONOMY: FailureDoor
FAILURE_DOOR_WORLDS: FailureDoor
FAILURE_DOOR_EXPERIENCE: FailureDoor
FAILURE_DOOR_CATALOG: FailureDoor
FAILURE_DOOR_WADDLE: FailureDoor
FAILURE_DOOR_FLEET_RESEARCH: FailureDoor

class CampaignGate(_message.Message):
    __slots__ = ("threshold", "trials")
    THRESHOLD_FIELD_NUMBER: _ClassVar[int]
    TRIALS_FIELD_NUMBER: _ClassVar[int]
    threshold: float
    trials: int
    def __init__(self, threshold: _Optional[float] = ..., trials: _Optional[int] = ...) -> None: ...

class CampaignGoal(_message.Message):
    __slots__ = ("task", "base_application_ref", "gate", "max_rounds", "timeout", "predecessor_campaign_id")
    TASK_FIELD_NUMBER: _ClassVar[int]
    BASE_APPLICATION_REF_FIELD_NUMBER: _ClassVar[int]
    GATE_FIELD_NUMBER: _ClassVar[int]
    MAX_ROUNDS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    PREDECESSOR_CAMPAIGN_ID_FIELD_NUMBER: _ClassVar[int]
    task: _common_pb2.TaskContractRef
    base_application_ref: str
    gate: CampaignGate
    max_rounds: int
    timeout: _duration_pb2.Duration
    predecessor_campaign_id: str
    def __init__(self, task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., base_application_ref: _Optional[str] = ..., gate: _Optional[_Union[CampaignGate, _Mapping]] = ..., max_rounds: _Optional[int] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ..., predecessor_campaign_id: _Optional[str] = ...) -> None: ...

class EvidenceMetric(_message.Message):
    __slots__ = ("name", "value")
    NAME_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    name: str
    value: float
    def __init__(self, name: _Optional[str] = ..., value: _Optional[float] = ...) -> None: ...

class GateEvidence(_message.Message):
    __slots__ = ("run_id", "task", "passed", "score", "threshold", "trials", "metrics")
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_FIELD_NUMBER: _ClassVar[int]
    PASSED_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    THRESHOLD_FIELD_NUMBER: _ClassVar[int]
    TRIALS_FIELD_NUMBER: _ClassVar[int]
    METRICS_FIELD_NUMBER: _ClassVar[int]
    run_id: str
    task: _common_pb2.TaskContractRef
    passed: bool
    score: float
    threshold: float
    trials: int
    metrics: _containers.RepeatedCompositeFieldContainer[EvidenceMetric]
    def __init__(self, run_id: _Optional[str] = ..., task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., passed: _Optional[bool] = ..., score: _Optional[float] = ..., threshold: _Optional[float] = ..., trials: _Optional[int] = ..., metrics: _Optional[_Iterable[_Union[EvidenceMetric, _Mapping]]] = ...) -> None: ...

class GenerationSummary(_message.Message):
    __slots__ = ("generation_id", "source", "dataset", "kept", "attempts")
    GENERATION_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    DATASET_FIELD_NUMBER: _ClassVar[int]
    KEPT_FIELD_NUMBER: _ClassVar[int]
    ATTEMPTS_FIELD_NUMBER: _ClassVar[int]
    generation_id: str
    source: GenerationSource
    dataset: str
    kept: int
    attempts: int
    def __init__(self, generation_id: _Optional[str] = ..., source: _Optional[_Union[GenerationSource, str]] = ..., dataset: _Optional[str] = ..., kept: _Optional[int] = ..., attempts: _Optional[int] = ...) -> None: ...

class CampaignAction(_message.Message):
    __slots__ = ("effect_id", "tool_name", "result_sha256", "operation_ref")
    EFFECT_ID_FIELD_NUMBER: _ClassVar[int]
    TOOL_NAME_FIELD_NUMBER: _ClassVar[int]
    RESULT_SHA256_FIELD_NUMBER: _ClassVar[int]
    OPERATION_REF_FIELD_NUMBER: _ClassVar[int]
    effect_id: str
    tool_name: str
    result_sha256: str
    operation_ref: str
    def __init__(self, effect_id: _Optional[str] = ..., tool_name: _Optional[str] = ..., result_sha256: _Optional[str] = ..., operation_ref: _Optional[str] = ...) -> None: ...

class RoundHypothesis(_message.Message):
    __slots__ = ("hypothesis", "rationale", "expected_outcome", "falsification_criteria")
    HYPOTHESIS_FIELD_NUMBER: _ClassVar[int]
    RATIONALE_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_OUTCOME_FIELD_NUMBER: _ClassVar[int]
    FALSIFICATION_CRITERIA_FIELD_NUMBER: _ClassVar[int]
    hypothesis: str
    rationale: str
    expected_outcome: str
    falsification_criteria: str
    def __init__(self, hypothesis: _Optional[str] = ..., rationale: _Optional[str] = ..., expected_outcome: _Optional[str] = ..., falsification_criteria: _Optional[str] = ...) -> None: ...

class CampaignRound(_message.Message):
    __slots__ = ("index", "verdict", "hypothesis", "actions", "evidence", "train_waddle_run_id", "waddle_trial_run_id", "generations", "step_failure", "proposal_artifacts", "proposal_log", "settlement", "proposal_branch", "selected_commit")
    INDEX_FIELD_NUMBER: _ClassVar[int]
    VERDICT_FIELD_NUMBER: _ClassVar[int]
    HYPOTHESIS_FIELD_NUMBER: _ClassVar[int]
    ACTIONS_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_FIELD_NUMBER: _ClassVar[int]
    TRAIN_WADDLE_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    WADDLE_TRIAL_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    GENERATIONS_FIELD_NUMBER: _ClassVar[int]
    STEP_FAILURE_FIELD_NUMBER: _ClassVar[int]
    PROPOSAL_ARTIFACTS_FIELD_NUMBER: _ClassVar[int]
    PROPOSAL_LOG_FIELD_NUMBER: _ClassVar[int]
    SETTLEMENT_FIELD_NUMBER: _ClassVar[int]
    PROPOSAL_BRANCH_FIELD_NUMBER: _ClassVar[int]
    SELECTED_COMMIT_FIELD_NUMBER: _ClassVar[int]
    index: int
    verdict: RoundVerdict
    hypothesis: RoundHypothesis
    actions: _containers.RepeatedCompositeFieldContainer[CampaignAction]
    evidence: GateEvidence
    train_waddle_run_id: str
    waddle_trial_run_id: str
    generations: _containers.RepeatedCompositeFieldContainer[GenerationSummary]
    step_failure: str
    proposal_artifacts: _containers.RepeatedCompositeFieldContainer[_common_pb2.ContentRef]
    proposal_log: _common_pb2.ContentRef
    settlement: Settlement
    proposal_branch: str
    selected_commit: str
    def __init__(self, index: _Optional[int] = ..., verdict: _Optional[_Union[RoundVerdict, str]] = ..., hypothesis: _Optional[_Union[RoundHypothesis, _Mapping]] = ..., actions: _Optional[_Iterable[_Union[CampaignAction, _Mapping]]] = ..., evidence: _Optional[_Union[GateEvidence, _Mapping]] = ..., train_waddle_run_id: _Optional[str] = ..., waddle_trial_run_id: _Optional[str] = ..., generations: _Optional[_Iterable[_Union[GenerationSummary, _Mapping]]] = ..., step_failure: _Optional[str] = ..., proposal_artifacts: _Optional[_Iterable[_Union[_common_pb2.ContentRef, _Mapping]]] = ..., proposal_log: _Optional[_Union[_common_pb2.ContentRef, _Mapping]] = ..., settlement: _Optional[_Union[Settlement, str]] = ..., proposal_branch: _Optional[str] = ..., selected_commit: _Optional[str] = ...) -> None: ...

class CampaignFailure(_message.Message):
    __slots__ = ("code", "message", "door")
    CODE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    DOOR_FIELD_NUMBER: _ClassVar[int]
    code: str
    message: str
    door: FailureDoor
    def __init__(self, code: _Optional[str] = ..., message: _Optional[str] = ..., door: _Optional[_Union[FailureDoor, str]] = ...) -> None: ...

class CampaignStop(_message.Message):
    __slots__ = ("requested_by", "reason")
    REQUESTED_BY_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    requested_by: str
    reason: str
    def __init__(self, requested_by: _Optional[str] = ..., reason: _Optional[str] = ...) -> None: ...

class Campaign(_message.Message):
    __slots__ = ("campaign_id", "execution", "terminal", "phase", "goal", "rounds", "outcome", "failure", "stop")
    CAMPAIGN_ID_FIELD_NUMBER: _ClassVar[int]
    EXECUTION_FIELD_NUMBER: _ClassVar[int]
    TERMINAL_FIELD_NUMBER: _ClassVar[int]
    PHASE_FIELD_NUMBER: _ClassVar[int]
    GOAL_FIELD_NUMBER: _ClassVar[int]
    ROUNDS_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    STOP_FIELD_NUMBER: _ClassVar[int]
    campaign_id: str
    execution: CampaignExecutionState
    terminal: bool
    phase: str
    goal: CampaignGoal
    rounds: _containers.RepeatedCompositeFieldContainer[CampaignRound]
    outcome: CampaignOutcome
    failure: CampaignFailure
    stop: CampaignStop
    def __init__(self, campaign_id: _Optional[str] = ..., execution: _Optional[_Union[CampaignExecutionState, str]] = ..., terminal: _Optional[bool] = ..., phase: _Optional[str] = ..., goal: _Optional[_Union[CampaignGoal, _Mapping]] = ..., rounds: _Optional[_Iterable[_Union[CampaignRound, _Mapping]]] = ..., outcome: _Optional[_Union[CampaignOutcome, str]] = ..., failure: _Optional[_Union[CampaignFailure, _Mapping]] = ..., stop: _Optional[_Union[CampaignStop, _Mapping]] = ...) -> None: ...

class CampaignSummary(_message.Message):
    __slots__ = ("campaign_id", "execution", "terminal", "started_at", "closed_at")
    CAMPAIGN_ID_FIELD_NUMBER: _ClassVar[int]
    EXECUTION_FIELD_NUMBER: _ClassVar[int]
    TERMINAL_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    CLOSED_AT_FIELD_NUMBER: _ClassVar[int]
    campaign_id: str
    execution: CampaignExecutionState
    terminal: bool
    started_at: _timestamp_pb2.Timestamp
    closed_at: _timestamp_pb2.Timestamp
    def __init__(self, campaign_id: _Optional[str] = ..., execution: _Optional[_Union[CampaignExecutionState, str]] = ..., terminal: _Optional[bool] = ..., started_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., closed_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ImprovementProgress(_message.Message):
    __slots__ = ("phase", "rounds_spent")
    PHASE_FIELD_NUMBER: _ClassVar[int]
    ROUNDS_SPENT_FIELD_NUMBER: _ClassVar[int]
    phase: str
    rounds_spent: int
    def __init__(self, phase: _Optional[str] = ..., rounds_spent: _Optional[int] = ...) -> None: ...

class ImprovementOperation(_message.Message):
    __slots__ = ("metadata", "lifecycle", "progress")
    METADATA_FIELD_NUMBER: _ClassVar[int]
    LIFECYCLE_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_FIELD_NUMBER: _ClassVar[int]
    metadata: _operations_pb2.OperationMetadata
    lifecycle: _operations_pb2.OperationLifecycle
    progress: ImprovementProgress
    def __init__(self, metadata: _Optional[_Union[_operations_pb2.OperationMetadata, _Mapping]] = ..., lifecycle: _Optional[_Union[_operations_pb2.OperationLifecycle, _Mapping]] = ..., progress: _Optional[_Union[ImprovementProgress, _Mapping]] = ...) -> None: ...

class ImprovementRound(_message.Message):
    __slots__ = ("index", "hypothesis", "evidence_refs")
    INDEX_FIELD_NUMBER: _ClassVar[int]
    HYPOTHESIS_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_REFS_FIELD_NUMBER: _ClassVar[int]
    index: int
    hypothesis: str
    evidence_refs: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, index: _Optional[int] = ..., hypothesis: _Optional[str] = ..., evidence_refs: _Optional[_Iterable[str]] = ...) -> None: ...

class Improved(_message.Message):
    __slots__ = ("evaluation", "rounds")
    EVALUATION_FIELD_NUMBER: _ClassVar[int]
    ROUNDS_FIELD_NUMBER: _ClassVar[int]
    evaluation: str
    rounds: _containers.RepeatedCompositeFieldContainer[ImprovementRound]
    def __init__(self, evaluation: _Optional[str] = ..., rounds: _Optional[_Iterable[_Union[ImprovementRound, _Mapping]]] = ...) -> None: ...

class ImprovementExhausted(_message.Message):
    __slots__ = ("rounds", "reason")
    ROUNDS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    rounds: _containers.RepeatedCompositeFieldContainer[ImprovementRound]
    reason: str
    def __init__(self, rounds: _Optional[_Iterable[_Union[ImprovementRound, _Mapping]]] = ..., reason: _Optional[str] = ...) -> None: ...

class ImprovementStopped(_message.Message):
    __slots__ = ("rounds", "reason")
    ROUNDS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    rounds: _containers.RepeatedCompositeFieldContainer[ImprovementRound]
    reason: str
    def __init__(self, rounds: _Optional[_Iterable[_Union[ImprovementRound, _Mapping]]] = ..., reason: _Optional[str] = ...) -> None: ...

class ImprovementOperationResult(_message.Message):
    __slots__ = ("improved", "exhausted", "stopped")
    IMPROVED_FIELD_NUMBER: _ClassVar[int]
    EXHAUSTED_FIELD_NUMBER: _ClassVar[int]
    STOPPED_FIELD_NUMBER: _ClassVar[int]
    improved: Improved
    exhausted: ImprovementExhausted
    stopped: ImprovementStopped
    def __init__(self, improved: _Optional[_Union[Improved, _Mapping]] = ..., exhausted: _Optional[_Union[ImprovementExhausted, _Mapping]] = ..., stopped: _Optional[_Union[ImprovementStopped, _Mapping]] = ...) -> None: ...

class StartCampaignRequest(_message.Message):
    __slots__ = ("task", "base_application_ref", "max_rounds", "timeout")
    TASK_FIELD_NUMBER: _ClassVar[int]
    BASE_APPLICATION_REF_FIELD_NUMBER: _ClassVar[int]
    MAX_ROUNDS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    task: _common_pb2.TaskContractRef
    base_application_ref: str
    max_rounds: int
    timeout: _duration_pb2.Duration
    def __init__(self, task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., base_application_ref: _Optional[str] = ..., max_rounds: _Optional[int] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class StartCampaignResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: ImprovementOperation
    def __init__(self, operation: _Optional[_Union[ImprovementOperation, _Mapping]] = ...) -> None: ...

class StartSuccessorCampaignRequest(_message.Message):
    __slots__ = ("predecessor_campaign_id", "max_rounds", "timeout")
    PREDECESSOR_CAMPAIGN_ID_FIELD_NUMBER: _ClassVar[int]
    MAX_ROUNDS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    predecessor_campaign_id: str
    max_rounds: int
    timeout: _duration_pb2.Duration
    def __init__(self, predecessor_campaign_id: _Optional[str] = ..., max_rounds: _Optional[int] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class StartSuccessorCampaignResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: ImprovementOperation
    def __init__(self, operation: _Optional[_Union[ImprovementOperation, _Mapping]] = ...) -> None: ...

class ListCampaignsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListCampaignsResponse(_message.Message):
    __slots__ = ("campaigns",)
    CAMPAIGNS_FIELD_NUMBER: _ClassVar[int]
    campaigns: _containers.RepeatedCompositeFieldContainer[CampaignSummary]
    def __init__(self, campaigns: _Optional[_Iterable[_Union[CampaignSummary, _Mapping]]] = ...) -> None: ...

class GetCampaignRequest(_message.Message):
    __slots__ = ("campaign_id",)
    CAMPAIGN_ID_FIELD_NUMBER: _ClassVar[int]
    campaign_id: str
    def __init__(self, campaign_id: _Optional[str] = ...) -> None: ...

class GetCampaignResponse(_message.Message):
    __slots__ = ("campaign",)
    CAMPAIGN_FIELD_NUMBER: _ClassVar[int]
    campaign: Campaign
    def __init__(self, campaign: _Optional[_Union[Campaign, _Mapping]] = ...) -> None: ...

class StopCampaignRequest(_message.Message):
    __slots__ = ("campaign_id", "reason")
    CAMPAIGN_ID_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    campaign_id: str
    reason: str
    def __init__(self, campaign_id: _Optional[str] = ..., reason: _Optional[str] = ...) -> None: ...

class StopCampaignResponse(_message.Message):
    __slots__ = ("campaign_id", "stop", "trace_id")
    CAMPAIGN_ID_FIELD_NUMBER: _ClassVar[int]
    STOP_FIELD_NUMBER: _ClassVar[int]
    TRACE_ID_FIELD_NUMBER: _ClassVar[int]
    campaign_id: str
    stop: CampaignStop
    trace_id: str
    def __init__(self, campaign_id: _Optional[str] = ..., stop: _Optional[_Union[CampaignStop, _Mapping]] = ..., trace_id: _Optional[str] = ...) -> None: ...

class GetImprovementOperationRequest(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class GetImprovementOperationResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: ImprovementOperation
    def __init__(self, operation: _Optional[_Union[ImprovementOperation, _Mapping]] = ...) -> None: ...

class GetImprovementOperationUpdatesRequest(_message.Message):
    __slots__ = ("operation", "after_cursor", "wait_timeout")
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    AFTER_CURSOR_FIELD_NUMBER: _ClassVar[int]
    WAIT_TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    after_cursor: int
    wait_timeout: _duration_pb2.Duration
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., after_cursor: _Optional[int] = ..., wait_timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class ImprovementOperationUpdatePage(_message.Message):
    __slots__ = ("updates", "next_cursor")
    UPDATES_FIELD_NUMBER: _ClassVar[int]
    NEXT_CURSOR_FIELD_NUMBER: _ClassVar[int]
    updates: _containers.RepeatedCompositeFieldContainer[ImprovementOperation]
    next_cursor: int
    def __init__(self, updates: _Optional[_Iterable[_Union[ImprovementOperation, _Mapping]]] = ..., next_cursor: _Optional[int] = ...) -> None: ...

class GetImprovementOperationUpdatesResponse(_message.Message):
    __slots__ = ("page",)
    PAGE_FIELD_NUMBER: _ClassVar[int]
    page: ImprovementOperationUpdatePage
    def __init__(self, page: _Optional[_Union[ImprovementOperationUpdatePage, _Mapping]] = ...) -> None: ...

class GetImprovementOperationResultRequest(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class GetImprovementOperationResultResponse(_message.Message):
    __slots__ = ("result",)
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: ImprovementOperationResult
    def __init__(self, result: _Optional[_Union[ImprovementOperationResult, _Mapping]] = ...) -> None: ...

class CancelImprovementOperationRequest(_message.Message):
    __slots__ = ("operation", "reason")
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    reason: str
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., reason: _Optional[str] = ...) -> None: ...

class CancelImprovementOperationResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: ImprovementOperation
    def __init__(self, operation: _Optional[_Union[ImprovementOperation, _Mapping]] = ...) -> None: ...
