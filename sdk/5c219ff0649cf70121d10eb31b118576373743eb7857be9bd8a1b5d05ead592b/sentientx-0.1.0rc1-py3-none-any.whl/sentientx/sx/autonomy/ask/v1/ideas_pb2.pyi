import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class IdeaSelector(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    IDEA_SELECTOR_UNSPECIFIED: _ClassVar[IdeaSelector]
    IDEA_SELECTOR_EMBODIMENT: _ClassVar[IdeaSelector]
    IDEA_SELECTOR_TASK: _ClassVar[IdeaSelector]
    IDEA_SELECTOR_DATASET: _ClassVar[IdeaSelector]
    IDEA_SELECTOR_RECIPE: _ClassVar[IdeaSelector]
    IDEA_SELECTOR_SCENE: _ClassVar[IdeaSelector]
IDEA_SELECTOR_UNSPECIFIED: IdeaSelector
IDEA_SELECTOR_EMBODIMENT: IdeaSelector
IDEA_SELECTOR_TASK: IdeaSelector
IDEA_SELECTOR_DATASET: IdeaSelector
IDEA_SELECTOR_RECIPE: IdeaSelector
IDEA_SELECTOR_SCENE: IdeaSelector

class IdeaSection(_message.Message):
    __slots__ = ("key", "label", "text", "references", "selector", "choices", "inputs")
    KEY_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    REFERENCES_FIELD_NUMBER: _ClassVar[int]
    SELECTOR_FIELD_NUMBER: _ClassVar[int]
    CHOICES_FIELD_NUMBER: _ClassVar[int]
    INPUTS_FIELD_NUMBER: _ClassVar[int]
    key: str
    label: str
    text: str
    references: _containers.RepeatedCompositeFieldContainer[_common_pb2.ResourceRef]
    selector: IdeaSelector
    choices: _containers.RepeatedCompositeFieldContainer[IdeaChoice]
    inputs: _containers.RepeatedCompositeFieldContainer[IdeaInput]
    def __init__(self, key: _Optional[str] = ..., label: _Optional[str] = ..., text: _Optional[str] = ..., references: _Optional[_Iterable[_Union[_common_pb2.ResourceRef, _Mapping]]] = ..., selector: _Optional[_Union[IdeaSelector, str]] = ..., choices: _Optional[_Iterable[_Union[IdeaChoice, _Mapping]]] = ..., inputs: _Optional[_Iterable[_Union[IdeaInput, _Mapping]]] = ...) -> None: ...

class IdeaInput(_message.Message):
    __slots__ = ("key", "label", "text", "enabled", "selection")
    KEY_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    ENABLED_FIELD_NUMBER: _ClassVar[int]
    SELECTION_FIELD_NUMBER: _ClassVar[int]
    key: str
    label: str
    text: str
    enabled: bool
    selection: IdeaInputSelection
    def __init__(self, key: _Optional[str] = ..., label: _Optional[str] = ..., text: _Optional[str] = ..., enabled: _Optional[bool] = ..., selection: _Optional[_Union[IdeaInputSelection, _Mapping]] = ...) -> None: ...

class IdeaInputSelection(_message.Message):
    __slots__ = ("options", "selected", "multiple")
    OPTIONS_FIELD_NUMBER: _ClassVar[int]
    SELECTED_FIELD_NUMBER: _ClassVar[int]
    MULTIPLE_FIELD_NUMBER: _ClassVar[int]
    options: _containers.RepeatedScalarFieldContainer[str]
    selected: _containers.RepeatedScalarFieldContainer[str]
    multiple: bool
    def __init__(self, options: _Optional[_Iterable[str]] = ..., selected: _Optional[_Iterable[str]] = ..., multiple: _Optional[bool] = ...) -> None: ...

class IdeaChoice(_message.Message):
    __slots__ = ("label", "text", "references")
    LABEL_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    REFERENCES_FIELD_NUMBER: _ClassVar[int]
    label: str
    text: str
    references: _containers.RepeatedCompositeFieldContainer[_common_pb2.ResourceRef]
    def __init__(self, label: _Optional[str] = ..., text: _Optional[str] = ..., references: _Optional[_Iterable[_Union[_common_pb2.ResourceRef, _Mapping]]] = ...) -> None: ...

class IdeaStep(_message.Message):
    __slots__ = ("title", "detail")
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DETAIL_FIELD_NUMBER: _ClassVar[int]
    title: str
    detail: str
    def __init__(self, title: _Optional[str] = ..., detail: _Optional[str] = ...) -> None: ...

class IdeaNextStep(_message.Message):
    __slots__ = ("label", "prompt")
    LABEL_FIELD_NUMBER: _ClassVar[int]
    PROMPT_FIELD_NUMBER: _ClassVar[int]
    label: str
    prompt: str
    def __init__(self, label: _Optional[str] = ..., prompt: _Optional[str] = ...) -> None: ...

class IdeaContent(_message.Message):
    __slots__ = ("title", "summary", "sections", "scenario", "next_step", "focus_section")
    TITLE_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    SECTIONS_FIELD_NUMBER: _ClassVar[int]
    SCENARIO_FIELD_NUMBER: _ClassVar[int]
    NEXT_STEP_FIELD_NUMBER: _ClassVar[int]
    FOCUS_SECTION_FIELD_NUMBER: _ClassVar[int]
    title: str
    summary: str
    sections: _containers.RepeatedCompositeFieldContainer[IdeaSection]
    scenario: _containers.RepeatedCompositeFieldContainer[IdeaStep]
    next_step: IdeaNextStep
    focus_section: str
    def __init__(self, title: _Optional[str] = ..., summary: _Optional[str] = ..., sections: _Optional[_Iterable[_Union[IdeaSection, _Mapping]]] = ..., scenario: _Optional[_Iterable[_Union[IdeaStep, _Mapping]]] = ..., next_step: _Optional[_Union[IdeaNextStep, _Mapping]] = ..., focus_section: _Optional[str] = ...) -> None: ...

class Idea(_message.Message):
    __slots__ = ("id", "parent_id", "content", "kept", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    PARENT_ID_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    KEPT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    parent_id: str
    content: IdeaContent
    kept: bool
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., parent_id: _Optional[str] = ..., content: _Optional[_Union[IdeaContent, _Mapping]] = ..., kept: _Optional[bool] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ListIdeasRequest(_message.Message):
    __slots__ = ("limit", "before", "kept_only")
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    BEFORE_FIELD_NUMBER: _ClassVar[int]
    KEPT_ONLY_FIELD_NUMBER: _ClassVar[int]
    limit: int
    before: str
    kept_only: bool
    def __init__(self, limit: _Optional[int] = ..., before: _Optional[str] = ..., kept_only: _Optional[bool] = ...) -> None: ...

class ListIdeasResponse(_message.Message):
    __slots__ = ("ideas", "next_before")
    IDEAS_FIELD_NUMBER: _ClassVar[int]
    NEXT_BEFORE_FIELD_NUMBER: _ClassVar[int]
    ideas: _containers.RepeatedCompositeFieldContainer[Idea]
    next_before: str
    def __init__(self, ideas: _Optional[_Iterable[_Union[Idea, _Mapping]]] = ..., next_before: _Optional[str] = ...) -> None: ...

class GetIdeaRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class GetIdeaResponse(_message.Message):
    __slots__ = ("idea",)
    IDEA_FIELD_NUMBER: _ClassVar[int]
    idea: Idea
    def __init__(self, idea: _Optional[_Union[Idea, _Mapping]] = ...) -> None: ...

class CreateIdeaRequest(_message.Message):
    __slots__ = ("parent_id", "content")
    PARENT_ID_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    parent_id: str
    content: IdeaContent
    def __init__(self, parent_id: _Optional[str] = ..., content: _Optional[_Union[IdeaContent, _Mapping]] = ...) -> None: ...

class CreateIdeaResponse(_message.Message):
    __slots__ = ("idea",)
    IDEA_FIELD_NUMBER: _ClassVar[int]
    idea: Idea
    def __init__(self, idea: _Optional[_Union[Idea, _Mapping]] = ...) -> None: ...

class KeepIdeaRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class KeepIdeaResponse(_message.Message):
    __slots__ = ("idea",)
    IDEA_FIELD_NUMBER: _ClassVar[int]
    idea: Idea
    def __init__(self, idea: _Optional[_Union[Idea, _Mapping]] = ...) -> None: ...
