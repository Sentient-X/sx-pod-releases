import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from sentientx.sx.autonomy.ask.v1 import ideas_pb2 as _ideas_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from sentientx.sx.conversations.v1 import conversations_pb2 as _conversations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ConversationMode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONVERSATION_MODE_UNSPECIFIED: _ClassVar[ConversationMode]
    CONVERSATION_MODE_PROJECT: _ClassVar[ConversationMode]
    CONVERSATION_MODE_AUTO_IMPROVE: _ClassVar[ConversationMode]
    CONVERSATION_MODE_PLAN: _ClassVar[ConversationMode]
    CONVERSATION_MODE_ROBOT: _ClassVar[ConversationMode]
    CONVERSATION_MODE_OBJECT: _ClassVar[ConversationMode]
    CONVERSATION_MODE_ENVIRONMENT: _ClassVar[ConversationMode]
    CONVERSATION_MODE_SIMULATE: _ClassVar[ConversationMode]
    CONVERSATION_MODE_TRAIN: _ClassVar[ConversationMode]
    CONVERSATION_MODE_DATA: _ClassVar[ConversationMode]

class ConversationPhase(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONVERSATION_PHASE_UNSPECIFIED: _ClassVar[ConversationPhase]
    CONVERSATION_PHASE_READY: _ClassVar[ConversationPhase]
    CONVERSATION_PHASE_ARCHIVED: _ClassVar[ConversationPhase]
CONVERSATION_MODE_UNSPECIFIED: ConversationMode
CONVERSATION_MODE_PROJECT: ConversationMode
CONVERSATION_MODE_AUTO_IMPROVE: ConversationMode
CONVERSATION_MODE_PLAN: ConversationMode
CONVERSATION_MODE_ROBOT: ConversationMode
CONVERSATION_MODE_OBJECT: ConversationMode
CONVERSATION_MODE_ENVIRONMENT: ConversationMode
CONVERSATION_MODE_SIMULATE: ConversationMode
CONVERSATION_MODE_TRAIN: ConversationMode
CONVERSATION_MODE_DATA: ConversationMode
CONVERSATION_PHASE_UNSPECIFIED: ConversationPhase
CONVERSATION_PHASE_READY: ConversationPhase
CONVERSATION_PHASE_ARCHIVED: ConversationPhase

class ProjectAskSkill(_message.Message):
    __slots__ = ("name", "description")
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    name: str
    description: str
    def __init__(self, name: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class AttachmentLimits(_message.Message):
    __slots__ = ("max_files", "max_file_bytes", "max_turn_bytes")
    MAX_FILES_FIELD_NUMBER: _ClassVar[int]
    MAX_FILE_BYTES_FIELD_NUMBER: _ClassVar[int]
    MAX_TURN_BYTES_FIELD_NUMBER: _ClassVar[int]
    max_files: int
    max_file_bytes: int
    max_turn_bytes: int
    def __init__(self, max_files: _Optional[int] = ..., max_file_bytes: _Optional[int] = ..., max_turn_bytes: _Optional[int] = ...) -> None: ...

class AgentContext(_message.Message):
    __slots__ = ("name", "mission", "conversation_modes", "attachment_limits", "skills")
    NAME_FIELD_NUMBER: _ClassVar[int]
    MISSION_FIELD_NUMBER: _ClassVar[int]
    CONVERSATION_MODES_FIELD_NUMBER: _ClassVar[int]
    ATTACHMENT_LIMITS_FIELD_NUMBER: _ClassVar[int]
    SKILLS_FIELD_NUMBER: _ClassVar[int]
    name: str
    mission: str
    conversation_modes: _containers.RepeatedScalarFieldContainer[ConversationMode]
    attachment_limits: AttachmentLimits
    skills: _containers.RepeatedCompositeFieldContainer[ProjectAskSkill]
    def __init__(self, name: _Optional[str] = ..., mission: _Optional[str] = ..., conversation_modes: _Optional[_Iterable[_Union[ConversationMode, str]]] = ..., attachment_limits: _Optional[_Union[AttachmentLimits, _Mapping]] = ..., skills: _Optional[_Iterable[_Union[ProjectAskSkill, _Mapping]]] = ...) -> None: ...

class Conversation(_message.Message):
    __slots__ = ("conversation_id", "title", "phase", "created_at", "updated_at")
    CONVERSATION_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    PHASE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    conversation_id: str
    title: str
    phase: ConversationPhase
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    def __init__(self, conversation_id: _Optional[str] = ..., title: _Optional[str] = ..., phase: _Optional[_Union[ConversationPhase, str]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ProjectAttachment(_message.Message):
    __slots__ = ("content", "filename", "media_type", "byte_size")
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    BYTE_SIZE_FIELD_NUMBER: _ClassVar[int]
    content: _common_pb2.ContentRef
    filename: str
    media_type: str
    byte_size: int
    def __init__(self, content: _Optional[_Union[_common_pb2.ContentRef, _Mapping]] = ..., filename: _Optional[str] = ..., media_type: _Optional[str] = ..., byte_size: _Optional[int] = ...) -> None: ...

class ProjectAsk(_message.Message):
    __slots__ = ("text", "attachments", "skills", "mode", "idea_id")
    TEXT_FIELD_NUMBER: _ClassVar[int]
    ATTACHMENTS_FIELD_NUMBER: _ClassVar[int]
    SKILLS_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    IDEA_ID_FIELD_NUMBER: _ClassVar[int]
    text: str
    attachments: _containers.RepeatedCompositeFieldContainer[ProjectAttachment]
    skills: _containers.RepeatedScalarFieldContainer[str]
    mode: ConversationMode
    idea_id: str
    def __init__(self, text: _Optional[str] = ..., attachments: _Optional[_Iterable[_Union[ProjectAttachment, _Mapping]]] = ..., skills: _Optional[_Iterable[str]] = ..., mode: _Optional[_Union[ConversationMode, str]] = ..., idea_id: _Optional[str] = ...) -> None: ...

class TurnOwnerContext(_message.Message):
    __slots__ = ("idea_id", "turn_id", "message_id", "mode", "attachments", "skills")
    IDEA_ID_FIELD_NUMBER: _ClassVar[int]
    TURN_ID_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_ID_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    ATTACHMENTS_FIELD_NUMBER: _ClassVar[int]
    SKILLS_FIELD_NUMBER: _ClassVar[int]
    idea_id: str
    turn_id: str
    message_id: str
    mode: ConversationMode
    attachments: _containers.RepeatedCompositeFieldContainer[ProjectAttachment]
    skills: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, idea_id: _Optional[str] = ..., turn_id: _Optional[str] = ..., message_id: _Optional[str] = ..., mode: _Optional[_Union[ConversationMode, str]] = ..., attachments: _Optional[_Iterable[_Union[ProjectAttachment, _Mapping]]] = ..., skills: _Optional[_Iterable[str]] = ...) -> None: ...

class TurnContextPage(_message.Message):
    __slots__ = ("contexts", "next_before")
    CONTEXTS_FIELD_NUMBER: _ClassVar[int]
    NEXT_BEFORE_FIELD_NUMBER: _ClassVar[int]
    contexts: _containers.RepeatedCompositeFieldContainer[TurnOwnerContext]
    next_before: int
    def __init__(self, contexts: _Optional[_Iterable[_Union[TurnOwnerContext, _Mapping]]] = ..., next_before: _Optional[int] = ...) -> None: ...

class GetAgentContextRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetAgentContextResponse(_message.Message):
    __slots__ = ("context",)
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    context: AgentContext
    def __init__(self, context: _Optional[_Union[AgentContext, _Mapping]] = ...) -> None: ...

class ListConversationsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListConversationsResponse(_message.Message):
    __slots__ = ("conversations",)
    CONVERSATIONS_FIELD_NUMBER: _ClassVar[int]
    conversations: _containers.RepeatedCompositeFieldContainer[Conversation]
    def __init__(self, conversations: _Optional[_Iterable[_Union[Conversation, _Mapping]]] = ...) -> None: ...

class GetConversationRequest(_message.Message):
    __slots__ = ("conversation_id",)
    CONVERSATION_ID_FIELD_NUMBER: _ClassVar[int]
    conversation_id: str
    def __init__(self, conversation_id: _Optional[str] = ...) -> None: ...

class GetConversationResponse(_message.Message):
    __slots__ = ("conversation",)
    CONVERSATION_FIELD_NUMBER: _ClassVar[int]
    conversation: Conversation
    def __init__(self, conversation: _Optional[_Union[Conversation, _Mapping]] = ...) -> None: ...

class StartConversationRequest(_message.Message):
    __slots__ = ("ask",)
    ASK_FIELD_NUMBER: _ClassVar[int]
    ask: ProjectAsk
    def __init__(self, ask: _Optional[_Union[ProjectAsk, _Mapping]] = ...) -> None: ...

class StartConversationResponse(_message.Message):
    __slots__ = ("conversation", "admission")
    CONVERSATION_FIELD_NUMBER: _ClassVar[int]
    ADMISSION_FIELD_NUMBER: _ClassVar[int]
    conversation: Conversation
    admission: _conversations_pb2.TurnAdmission
    def __init__(self, conversation: _Optional[_Union[Conversation, _Mapping]] = ..., admission: _Optional[_Union[_conversations_pb2.TurnAdmission, _Mapping]] = ...) -> None: ...

class SendMessageRequest(_message.Message):
    __slots__ = ("conversation_id", "ask")
    CONVERSATION_ID_FIELD_NUMBER: _ClassVar[int]
    ASK_FIELD_NUMBER: _ClassVar[int]
    conversation_id: str
    ask: ProjectAsk
    def __init__(self, conversation_id: _Optional[str] = ..., ask: _Optional[_Union[ProjectAsk, _Mapping]] = ...) -> None: ...

class SendMessageResponse(_message.Message):
    __slots__ = ("admission",)
    ADMISSION_FIELD_NUMBER: _ClassVar[int]
    admission: _conversations_pb2.TurnAdmission
    def __init__(self, admission: _Optional[_Union[_conversations_pb2.TurnAdmission, _Mapping]] = ...) -> None: ...

class ListMessagesRequest(_message.Message):
    __slots__ = ("conversation_id", "before", "limit")
    CONVERSATION_ID_FIELD_NUMBER: _ClassVar[int]
    BEFORE_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    conversation_id: str
    before: int
    limit: int
    def __init__(self, conversation_id: _Optional[str] = ..., before: _Optional[int] = ..., limit: _Optional[int] = ...) -> None: ...

class ListMessagesResponse(_message.Message):
    __slots__ = ("page",)
    PAGE_FIELD_NUMBER: _ClassVar[int]
    page: _conversations_pb2.MessagePage
    def __init__(self, page: _Optional[_Union[_conversations_pb2.MessagePage, _Mapping]] = ...) -> None: ...

class ListTurnContextsRequest(_message.Message):
    __slots__ = ("conversation_id", "before", "limit")
    CONVERSATION_ID_FIELD_NUMBER: _ClassVar[int]
    BEFORE_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    conversation_id: str
    before: int
    limit: int
    def __init__(self, conversation_id: _Optional[str] = ..., before: _Optional[int] = ..., limit: _Optional[int] = ...) -> None: ...

class ListTurnContextsResponse(_message.Message):
    __slots__ = ("page",)
    PAGE_FIELD_NUMBER: _ClassVar[int]
    page: TurnContextPage
    def __init__(self, page: _Optional[_Union[TurnContextPage, _Mapping]] = ...) -> None: ...

class ListEventsRequest(_message.Message):
    __slots__ = ("conversation_id", "after", "limit", "wait_timeout")
    CONVERSATION_ID_FIELD_NUMBER: _ClassVar[int]
    AFTER_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    WAIT_TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    conversation_id: str
    after: int
    limit: int
    wait_timeout: _duration_pb2.Duration
    def __init__(self, conversation_id: _Optional[str] = ..., after: _Optional[int] = ..., limit: _Optional[int] = ..., wait_timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class ListEventsResponse(_message.Message):
    __slots__ = ("page",)
    PAGE_FIELD_NUMBER: _ClassVar[int]
    page: _conversations_pb2.EventPage
    def __init__(self, page: _Optional[_Union[_conversations_pb2.EventPage, _Mapping]] = ...) -> None: ...

class RespondToApprovalRequest(_message.Message):
    __slots__ = ("conversation_id", "response")
    CONVERSATION_ID_FIELD_NUMBER: _ClassVar[int]
    RESPONSE_FIELD_NUMBER: _ClassVar[int]
    conversation_id: str
    response: _conversations_pb2.ApprovalResponse
    def __init__(self, conversation_id: _Optional[str] = ..., response: _Optional[_Union[_conversations_pb2.ApprovalResponse, _Mapping]] = ...) -> None: ...

class RespondToApprovalResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CancelTurnRequest(_message.Message):
    __slots__ = ("conversation_id", "turn_id", "reason")
    CONVERSATION_ID_FIELD_NUMBER: _ClassVar[int]
    TURN_ID_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    conversation_id: str
    turn_id: str
    reason: str
    def __init__(self, conversation_id: _Optional[str] = ..., turn_id: _Optional[str] = ..., reason: _Optional[str] = ...) -> None: ...

class CancelTurnResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ArchiveConversationRequest(_message.Message):
    __slots__ = ("conversation_id",)
    CONVERSATION_ID_FIELD_NUMBER: _ClassVar[int]
    conversation_id: str
    def __init__(self, conversation_id: _Optional[str] = ...) -> None: ...

class ArchiveConversationResponse(_message.Message):
    __slots__ = ("conversation",)
    CONVERSATION_FIELD_NUMBER: _ClassVar[int]
    conversation: Conversation
    def __init__(self, conversation: _Optional[_Union[Conversation, _Mapping]] = ...) -> None: ...
