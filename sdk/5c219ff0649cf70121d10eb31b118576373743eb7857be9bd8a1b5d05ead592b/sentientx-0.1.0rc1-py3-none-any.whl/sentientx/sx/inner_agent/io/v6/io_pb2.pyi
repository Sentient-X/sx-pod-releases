import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ImageMimeType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    IMAGE_MIME_TYPE_UNSPECIFIED: _ClassVar[ImageMimeType]
    IMAGE_MIME_TYPE_JPEG: _ClassVar[ImageMimeType]
    IMAGE_MIME_TYPE_PNG: _ClassVar[ImageMimeType]
    IMAGE_MIME_TYPE_WEBP: _ClassVar[ImageMimeType]

class NotSatisfiedReason(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    NOT_SATISFIED_REASON_UNSPECIFIED: _ClassVar[NotSatisfiedReason]
    NOT_SATISFIED_REASON_NO_GRASP: _ClassVar[NotSatisfiedReason]
    NOT_SATISFIED_REASON_UNREACHABLE: _ClassVar[NotSatisfiedReason]
    NOT_SATISFIED_REASON_TARGET_LOST: _ClassVar[NotSatisfiedReason]
    NOT_SATISFIED_REASON_GRASP_EMPTY: _ClassVar[NotSatisfiedReason]
    NOT_SATISFIED_REASON_GRASP_UNCERTAIN: _ClassVar[NotSatisfiedReason]
    NOT_SATISFIED_REASON_PLAN_DIVERGED: _ClassVar[NotSatisfiedReason]
    NOT_SATISFIED_REASON_HOLD_BUDGET_EXHAUSTED: _ClassVar[NotSatisfiedReason]

class PlacementMode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PLACEMENT_MODE_UNSPECIFIED: _ClassVar[PlacementMode]
    PLACEMENT_MODE_ON_SURFACE: _ClassVar[PlacementMode]
    PLACEMENT_MODE_IN_CONTAINER: _ClassVar[PlacementMode]

class DecisionKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DECISION_KIND_UNSPECIFIED: _ClassVar[DecisionKind]
    DECISION_KIND_VLA: _ClassVar[DecisionKind]
    DECISION_KIND_PICK: _ClassVar[DecisionKind]
    DECISION_KIND_PLACE: _ClassVar[DecisionKind]

class GoalPhase(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    GOAL_PHASE_UNSPECIFIED: _ClassVar[GoalPhase]
    GOAL_PHASE_UNSET: _ClassVar[GoalPhase]
    GOAL_PHASE_ACTIVE: _ClassVar[GoalPhase]
    GOAL_PHASE_COMPLETED: _ClassVar[GoalPhase]

class SessionPhase(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SESSION_PHASE_UNSPECIFIED: _ClassVar[SessionPhase]
    SESSION_PHASE_READY: _ClassVar[SessionPhase]
    SESSION_PHASE_RUNNING: _ClassVar[SessionPhase]
    SESSION_PHASE_RECONCILING: _ClassVar[SessionPhase]
    SESSION_PHASE_STOPPED: _ClassVar[SessionPhase]

class ExternalEffectKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EXTERNAL_EFFECT_KIND_UNSPECIFIED: _ClassVar[ExternalEffectKind]
    EXTERNAL_EFFECT_KIND_MCP: _ClassVar[ExternalEffectKind]
    EXTERNAL_EFFECT_KIND_SUBGOAL: _ClassVar[ExternalEffectKind]
    EXTERNAL_EFFECT_KIND_STOP: _ClassVar[ExternalEffectKind]

class ExternalEffectState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EXTERNAL_EFFECT_STATE_UNSPECIFIED: _ClassVar[ExternalEffectState]
    EXTERNAL_EFFECT_STATE_PREPARED: _ClassVar[ExternalEffectState]
    EXTERNAL_EFFECT_STATE_RESOLVED: _ClassVar[ExternalEffectState]
    EXTERNAL_EFFECT_STATE_INDETERMINATE: _ClassVar[ExternalEffectState]
    EXTERNAL_EFFECT_STATE_ABANDONED: _ClassVar[ExternalEffectState]

class InputReceiptDisposition(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    INPUT_RECEIPT_DISPOSITION_UNSPECIFIED: _ClassVar[InputReceiptDisposition]
    INPUT_RECEIPT_DISPOSITION_ACCEPTED: _ClassVar[InputReceiptDisposition]
    INPUT_RECEIPT_DISPOSITION_DUPLICATE: _ClassVar[InputReceiptDisposition]
IMAGE_MIME_TYPE_UNSPECIFIED: ImageMimeType
IMAGE_MIME_TYPE_JPEG: ImageMimeType
IMAGE_MIME_TYPE_PNG: ImageMimeType
IMAGE_MIME_TYPE_WEBP: ImageMimeType
NOT_SATISFIED_REASON_UNSPECIFIED: NotSatisfiedReason
NOT_SATISFIED_REASON_NO_GRASP: NotSatisfiedReason
NOT_SATISFIED_REASON_UNREACHABLE: NotSatisfiedReason
NOT_SATISFIED_REASON_TARGET_LOST: NotSatisfiedReason
NOT_SATISFIED_REASON_GRASP_EMPTY: NotSatisfiedReason
NOT_SATISFIED_REASON_GRASP_UNCERTAIN: NotSatisfiedReason
NOT_SATISFIED_REASON_PLAN_DIVERGED: NotSatisfiedReason
NOT_SATISFIED_REASON_HOLD_BUDGET_EXHAUSTED: NotSatisfiedReason
PLACEMENT_MODE_UNSPECIFIED: PlacementMode
PLACEMENT_MODE_ON_SURFACE: PlacementMode
PLACEMENT_MODE_IN_CONTAINER: PlacementMode
DECISION_KIND_UNSPECIFIED: DecisionKind
DECISION_KIND_VLA: DecisionKind
DECISION_KIND_PICK: DecisionKind
DECISION_KIND_PLACE: DecisionKind
GOAL_PHASE_UNSPECIFIED: GoalPhase
GOAL_PHASE_UNSET: GoalPhase
GOAL_PHASE_ACTIVE: GoalPhase
GOAL_PHASE_COMPLETED: GoalPhase
SESSION_PHASE_UNSPECIFIED: SessionPhase
SESSION_PHASE_READY: SessionPhase
SESSION_PHASE_RUNNING: SessionPhase
SESSION_PHASE_RECONCILING: SessionPhase
SESSION_PHASE_STOPPED: SessionPhase
EXTERNAL_EFFECT_KIND_UNSPECIFIED: ExternalEffectKind
EXTERNAL_EFFECT_KIND_MCP: ExternalEffectKind
EXTERNAL_EFFECT_KIND_SUBGOAL: ExternalEffectKind
EXTERNAL_EFFECT_KIND_STOP: ExternalEffectKind
EXTERNAL_EFFECT_STATE_UNSPECIFIED: ExternalEffectState
EXTERNAL_EFFECT_STATE_PREPARED: ExternalEffectState
EXTERNAL_EFFECT_STATE_RESOLVED: ExternalEffectState
EXTERNAL_EFFECT_STATE_INDETERMINATE: ExternalEffectState
EXTERNAL_EFFECT_STATE_ABANDONED: ExternalEffectState
INPUT_RECEIPT_DISPOSITION_UNSPECIFIED: InputReceiptDisposition
INPUT_RECEIPT_DISPOSITION_ACCEPTED: InputReceiptDisposition
INPUT_RECEIPT_DISPOSITION_DUPLICATE: InputReceiptDisposition

class EffectIdentity(_message.Message):
    __slots__ = ("effect_id", "request_digest")
    EFFECT_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_DIGEST_FIELD_NUMBER: _ClassVar[int]
    effect_id: str
    request_digest: str
    def __init__(self, effect_id: _Optional[str] = ..., request_digest: _Optional[str] = ...) -> None: ...

class DecisionIdentity(_message.Message):
    __slots__ = ("environment_generation", "effect", "goal_id", "goal_revision", "decision_id")
    ENVIRONMENT_GENERATION_FIELD_NUMBER: _ClassVar[int]
    EFFECT_FIELD_NUMBER: _ClassVar[int]
    GOAL_ID_FIELD_NUMBER: _ClassVar[int]
    GOAL_REVISION_FIELD_NUMBER: _ClassVar[int]
    DECISION_ID_FIELD_NUMBER: _ClassVar[int]
    environment_generation: int
    effect: EffectIdentity
    goal_id: str
    goal_revision: int
    decision_id: str
    def __init__(self, environment_generation: _Optional[int] = ..., effect: _Optional[_Union[EffectIdentity, _Mapping]] = ..., goal_id: _Optional[str] = ..., goal_revision: _Optional[int] = ..., decision_id: _Optional[str] = ...) -> None: ...

class OpenEnvironmentGeneration(_message.Message):
    __slots__ = ("generation", "reason")
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    generation: int
    reason: str
    def __init__(self, generation: _Optional[int] = ..., reason: _Optional[str] = ...) -> None: ...

class AdvanceIdleEnvironmentGeneration(_message.Message):
    __slots__ = ("previous_generation", "generation", "reason")
    PREVIOUS_GENERATION_FIELD_NUMBER: _ClassVar[int]
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    previous_generation: int
    generation: int
    reason: str
    def __init__(self, previous_generation: _Optional[int] = ..., generation: _Optional[int] = ..., reason: _Optional[str] = ...) -> None: ...

class AdvanceAndAbandonEnvironmentGeneration(_message.Message):
    __slots__ = ("previous_generation", "generation", "effect", "reason")
    PREVIOUS_GENERATION_FIELD_NUMBER: _ClassVar[int]
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    EFFECT_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    previous_generation: int
    generation: int
    effect: EffectIdentity
    reason: str
    def __init__(self, previous_generation: _Optional[int] = ..., generation: _Optional[int] = ..., effect: _Optional[_Union[EffectIdentity, _Mapping]] = ..., reason: _Optional[str] = ...) -> None: ...

class EnvironmentGenerationTransition(_message.Message):
    __slots__ = ("open", "advance_idle", "advance_and_abandon")
    OPEN_FIELD_NUMBER: _ClassVar[int]
    ADVANCE_IDLE_FIELD_NUMBER: _ClassVar[int]
    ADVANCE_AND_ABANDON_FIELD_NUMBER: _ClassVar[int]
    open: OpenEnvironmentGeneration
    advance_idle: AdvanceIdleEnvironmentGeneration
    advance_and_abandon: AdvanceAndAbandonEnvironmentGeneration
    def __init__(self, open: _Optional[_Union[OpenEnvironmentGeneration, _Mapping]] = ..., advance_idle: _Optional[_Union[AdvanceIdleEnvironmentGeneration, _Mapping]] = ..., advance_and_abandon: _Optional[_Union[AdvanceAndAbandonEnvironmentGeneration, _Mapping]] = ...) -> None: ...

class BootstrapObservationCause(_message.Message):
    __slots__ = ("environment_generation",)
    ENVIRONMENT_GENERATION_FIELD_NUMBER: _ClassVar[int]
    environment_generation: int
    def __init__(self, environment_generation: _Optional[int] = ...) -> None: ...

class DecisionObservationCause(_message.Message):
    __slots__ = ("decision",)
    DECISION_FIELD_NUMBER: _ClassVar[int]
    decision: DecisionIdentity
    def __init__(self, decision: _Optional[_Union[DecisionIdentity, _Mapping]] = ...) -> None: ...

class ObservationCause(_message.Message):
    __slots__ = ("bootstrap", "decision")
    BOOTSTRAP_FIELD_NUMBER: _ClassVar[int]
    DECISION_FIELD_NUMBER: _ClassVar[int]
    bootstrap: BootstrapObservationCause
    decision: DecisionObservationCause
    def __init__(self, bootstrap: _Optional[_Union[BootstrapObservationCause, _Mapping]] = ..., decision: _Optional[_Union[DecisionObservationCause, _Mapping]] = ...) -> None: ...

class ObservationImage(_message.Message):
    __slots__ = ("camera", "captured_at", "calibration_id", "mime_type", "data", "sha256")
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    CAPTURED_AT_FIELD_NUMBER: _ClassVar[int]
    CALIBRATION_ID_FIELD_NUMBER: _ClassVar[int]
    MIME_TYPE_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    camera: str
    captured_at: str
    calibration_id: str
    mime_type: ImageMimeType
    data: str
    sha256: str
    def __init__(self, camera: _Optional[str] = ..., captured_at: _Optional[str] = ..., calibration_id: _Optional[str] = ..., mime_type: _Optional[_Union[ImageMimeType, str]] = ..., data: _Optional[str] = ..., sha256: _Optional[str] = ...) -> None: ...

class PublishedInstance(_message.Message):
    __slots__ = ("instance", "label", "score")
    INSTANCE_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    instance: str
    label: str
    score: float
    def __init__(self, instance: _Optional[str] = ..., label: _Optional[str] = ..., score: _Optional[float] = ...) -> None: ...

class PublishedScene(_message.Message):
    __slots__ = ("observation_sequence", "instances")
    OBSERVATION_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    INSTANCES_FIELD_NUMBER: _ClassVar[int]
    observation_sequence: int
    instances: _containers.RepeatedCompositeFieldContainer[PublishedInstance]
    def __init__(self, observation_sequence: _Optional[int] = ..., instances: _Optional[_Iterable[_Union[PublishedInstance, _Mapping]]] = ...) -> None: ...

class RunningDecision(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SatisfiedDecision(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class NotSatisfiedDecision(_message.Message):
    __slots__ = ("reason",)
    REASON_FIELD_NUMBER: _ClassVar[int]
    reason: NotSatisfiedReason
    def __init__(self, reason: _Optional[_Union[NotSatisfiedReason, str]] = ...) -> None: ...

class DecisionReceipt(_message.Message):
    __slots__ = ("decision_id", "running", "satisfied", "not_satisfied", "detail")
    DECISION_ID_FIELD_NUMBER: _ClassVar[int]
    RUNNING_FIELD_NUMBER: _ClassVar[int]
    SATISFIED_FIELD_NUMBER: _ClassVar[int]
    NOT_SATISFIED_FIELD_NUMBER: _ClassVar[int]
    DETAIL_FIELD_NUMBER: _ClassVar[int]
    decision_id: str
    running: RunningDecision
    satisfied: SatisfiedDecision
    not_satisfied: NotSatisfiedDecision
    detail: str
    def __init__(self, decision_id: _Optional[str] = ..., running: _Optional[_Union[RunningDecision, _Mapping]] = ..., satisfied: _Optional[_Union[SatisfiedDecision, _Mapping]] = ..., not_satisfied: _Optional[_Union[NotSatisfiedDecision, _Mapping]] = ..., detail: _Optional[str] = ...) -> None: ...

class AlarmFact(_message.Message):
    __slots__ = ("monitor", "score", "threshold")
    MONITOR_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    THRESHOLD_FIELD_NUMBER: _ClassVar[int]
    monitor: str
    score: float
    threshold: float
    def __init__(self, monitor: _Optional[str] = ..., score: _Optional[float] = ..., threshold: _Optional[float] = ...) -> None: ...

class ReflexPreemption(_message.Message):
    __slots__ = ("reflex", "hazard", "decision_id", "chunks")
    REFLEX_FIELD_NUMBER: _ClassVar[int]
    HAZARD_FIELD_NUMBER: _ClassVar[int]
    DECISION_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNKS_FIELD_NUMBER: _ClassVar[int]
    reflex: str
    hazard: str
    decision_id: str
    chunks: int
    def __init__(self, reflex: _Optional[str] = ..., hazard: _Optional[str] = ..., decision_id: _Optional[str] = ..., chunks: _Optional[int] = ...) -> None: ...

class ReflexPreemptions(_message.Message):
    __slots__ = ("items",)
    ITEMS_FIELD_NUMBER: _ClassVar[int]
    items: _containers.RepeatedCompositeFieldContainer[ReflexPreemption]
    def __init__(self, items: _Optional[_Iterable[_Union[ReflexPreemption, _Mapping]]] = ...) -> None: ...

class ReservedObservationFacts(_message.Message):
    __slots__ = ("scene", "receipt", "alarm", "reflexes")
    SCENE_FIELD_NUMBER: _ClassVar[int]
    RECEIPT_FIELD_NUMBER: _ClassVar[int]
    ALARM_FIELD_NUMBER: _ClassVar[int]
    REFLEXES_FIELD_NUMBER: _ClassVar[int]
    scene: PublishedScene
    receipt: DecisionReceipt
    alarm: AlarmFact
    reflexes: ReflexPreemptions
    def __init__(self, scene: _Optional[_Union[PublishedScene, _Mapping]] = ..., receipt: _Optional[_Union[DecisionReceipt, _Mapping]] = ..., alarm: _Optional[_Union[AlarmFact, _Mapping]] = ..., reflexes: _Optional[_Union[ReflexPreemptions, _Mapping]] = ...) -> None: ...

class ReplanInterval(_message.Message):
    __slots__ = ("chunks", "wall_ms")
    CHUNKS_FIELD_NUMBER: _ClassVar[int]
    WALL_MS_FIELD_NUMBER: _ClassVar[int]
    chunks: int
    wall_ms: int
    def __init__(self, chunks: _Optional[int] = ..., wall_ms: _Optional[int] = ...) -> None: ...

class TargetRef(_message.Message):
    __slots__ = ("observation_sequence", "instance")
    OBSERVATION_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    INSTANCE_FIELD_NUMBER: _ClassVar[int]
    observation_sequence: int
    instance: str
    def __init__(self, observation_sequence: _Optional[int] = ..., instance: _Optional[str] = ...) -> None: ...

class VlaCommand(_message.Message):
    __slots__ = ("decision_id", "instruction")
    DECISION_ID_FIELD_NUMBER: _ClassVar[int]
    INSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    decision_id: str
    instruction: str
    def __init__(self, decision_id: _Optional[str] = ..., instruction: _Optional[str] = ...) -> None: ...

class PickCommand(_message.Message):
    __slots__ = ("decision_id", "target")
    DECISION_ID_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    decision_id: str
    target: TargetRef
    def __init__(self, decision_id: _Optional[str] = ..., target: _Optional[_Union[TargetRef, _Mapping]] = ...) -> None: ...

class PlaceCommand(_message.Message):
    __slots__ = ("decision_id", "target", "mode")
    DECISION_ID_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    decision_id: str
    target: TargetRef
    mode: PlacementMode
    def __init__(self, decision_id: _Optional[str] = ..., target: _Optional[_Union[TargetRef, _Mapping]] = ..., mode: _Optional[_Union[PlacementMode, str]] = ...) -> None: ...

class SubgoalCommand(_message.Message):
    __slots__ = ("vla", "pick", "place")
    VLA_FIELD_NUMBER: _ClassVar[int]
    PICK_FIELD_NUMBER: _ClassVar[int]
    PLACE_FIELD_NUMBER: _ClassVar[int]
    vla: VlaCommand
    pick: PickCommand
    place: PlaceCommand
    def __init__(self, vla: _Optional[_Union[VlaCommand, _Mapping]] = ..., pick: _Optional[_Union[PickCommand, _Mapping]] = ..., place: _Optional[_Union[PlaceCommand, _Mapping]] = ...) -> None: ...

class SubgoalDecision(_message.Message):
    __slots__ = ("decision", "command")
    DECISION_FIELD_NUMBER: _ClassVar[int]
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    decision: DecisionIdentity
    command: SubgoalCommand
    def __init__(self, decision: _Optional[_Union[DecisionIdentity, _Mapping]] = ..., command: _Optional[_Union[SubgoalCommand, _Mapping]] = ...) -> None: ...

class StopCommand(_message.Message):
    __slots__ = ("decision_id", "reason")
    DECISION_ID_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    decision_id: str
    reason: str
    def __init__(self, decision_id: _Optional[str] = ..., reason: _Optional[str] = ...) -> None: ...

class StopRequest(_message.Message):
    __slots__ = ("decision", "reason")
    DECISION_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    decision: DecisionIdentity
    reason: str
    def __init__(self, decision: _Optional[_Union[DecisionIdentity, _Mapping]] = ..., reason: _Optional[str] = ...) -> None: ...

class PendingEffect(_message.Message):
    __slots__ = ("effect", "kind", "goal_id", "goal_revision", "call_identity", "state")
    EFFECT_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    GOAL_ID_FIELD_NUMBER: _ClassVar[int]
    GOAL_REVISION_FIELD_NUMBER: _ClassVar[int]
    CALL_IDENTITY_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    effect: EffectIdentity
    kind: ExternalEffectKind
    goal_id: str
    goal_revision: int
    call_identity: str
    state: ExternalEffectState
    def __init__(self, effect: _Optional[_Union[EffectIdentity, _Mapping]] = ..., kind: _Optional[_Union[ExternalEffectKind, str]] = ..., goal_id: _Optional[str] = ..., goal_revision: _Optional[int] = ..., call_identity: _Optional[str] = ..., state: _Optional[_Union[ExternalEffectState, str]] = ...) -> None: ...

class HealthyRecovery(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class RetryScheduledRecovery(_message.Message):
    __slots__ = ("retry_at", "attempt", "reason")
    RETRY_AT_FIELD_NUMBER: _ClassVar[int]
    ATTEMPT_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    retry_at: _timestamp_pb2.Timestamp
    attempt: int
    reason: str
    def __init__(self, retry_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., attempt: _Optional[int] = ..., reason: _Optional[str] = ...) -> None: ...

class RetryingRecovery(_message.Message):
    __slots__ = ("attempt",)
    ATTEMPT_FIELD_NUMBER: _ClassVar[int]
    attempt: int
    def __init__(self, attempt: _Optional[int] = ...) -> None: ...

class RecoveryState(_message.Message):
    __slots__ = ("healthy", "retry_scheduled", "retrying")
    HEALTHY_FIELD_NUMBER: _ClassVar[int]
    RETRY_SCHEDULED_FIELD_NUMBER: _ClassVar[int]
    RETRYING_FIELD_NUMBER: _ClassVar[int]
    healthy: HealthyRecovery
    retry_scheduled: RetryScheduledRecovery
    retrying: RetryingRecovery
    def __init__(self, healthy: _Optional[_Union[HealthyRecovery, _Mapping]] = ..., retry_scheduled: _Optional[_Union[RetryScheduledRecovery, _Mapping]] = ..., retrying: _Optional[_Union[RetryingRecovery, _Mapping]] = ...) -> None: ...

class InputReceipt(_message.Message):
    __slots__ = ("schema", "input_id", "request_digest", "disposition")
    SCHEMA_FIELD_NUMBER: _ClassVar[int]
    INPUT_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_DIGEST_FIELD_NUMBER: _ClassVar[int]
    DISPOSITION_FIELD_NUMBER: _ClassVar[int]
    schema: str
    input_id: str
    request_digest: str
    disposition: InputReceiptDisposition
    def __init__(self, schema: _Optional[str] = ..., input_id: _Optional[str] = ..., request_digest: _Optional[str] = ..., disposition: _Optional[_Union[InputReceiptDisposition, str]] = ...) -> None: ...

class RuntimeStatus(_message.Message):
    __slots__ = ("schema", "session_id", "phase", "goal", "recovery", "environment_generation", "pending_effect", "last_sequence", "admitted_decisions")
    SCHEMA_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    PHASE_FIELD_NUMBER: _ClassVar[int]
    GOAL_FIELD_NUMBER: _ClassVar[int]
    RECOVERY_FIELD_NUMBER: _ClassVar[int]
    ENVIRONMENT_GENERATION_FIELD_NUMBER: _ClassVar[int]
    PENDING_EFFECT_FIELD_NUMBER: _ClassVar[int]
    LAST_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    ADMITTED_DECISIONS_FIELD_NUMBER: _ClassVar[int]
    schema: str
    session_id: str
    phase: SessionPhase
    goal: GoalPhase
    recovery: RecoveryState
    environment_generation: int
    pending_effect: PendingEffect
    last_sequence: int
    admitted_decisions: _containers.RepeatedScalarFieldContainer[DecisionKind]
    def __init__(self, schema: _Optional[str] = ..., session_id: _Optional[str] = ..., phase: _Optional[_Union[SessionPhase, str]] = ..., goal: _Optional[_Union[GoalPhase, str]] = ..., recovery: _Optional[_Union[RecoveryState, _Mapping]] = ..., environment_generation: _Optional[int] = ..., pending_effect: _Optional[_Union[PendingEffect, _Mapping]] = ..., last_sequence: _Optional[int] = ..., admitted_decisions: _Optional[_Iterable[_Union[DecisionKind, str]]] = ...) -> None: ...
