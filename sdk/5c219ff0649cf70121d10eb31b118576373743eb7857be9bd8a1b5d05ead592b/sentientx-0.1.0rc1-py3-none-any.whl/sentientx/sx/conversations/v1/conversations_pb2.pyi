import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ConversationRole(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONVERSATION_ROLE_UNSPECIFIED: _ClassVar[ConversationRole]
    CONVERSATION_ROLE_USER: _ClassVar[ConversationRole]
    CONVERSATION_ROLE_ASSISTANT: _ClassVar[ConversationRole]

class ApprovalDecision(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    APPROVAL_DECISION_UNSPECIFIED: _ClassVar[ApprovalDecision]
    APPROVAL_DECISION_APPROVED: _ClassVar[ApprovalDecision]
    APPROVAL_DECISION_REJECTED: _ClassVar[ApprovalDecision]

class ActiveTurnState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ACTIVE_TURN_STATE_UNSPECIFIED: _ClassVar[ActiveTurnState]
    ACTIVE_TURN_STATE_ACCEPTED: _ClassVar[ActiveTurnState]
    ACTIVE_TURN_STATE_RUNNING: _ClassVar[ActiveTurnState]
    ACTIVE_TURN_STATE_WAITING_FOR_APPROVAL: _ClassVar[ActiveTurnState]
    ACTIVE_TURN_STATE_RECONCILING: _ClassVar[ActiveTurnState]
CONVERSATION_ROLE_UNSPECIFIED: ConversationRole
CONVERSATION_ROLE_USER: ConversationRole
CONVERSATION_ROLE_ASSISTANT: ConversationRole
APPROVAL_DECISION_UNSPECIFIED: ApprovalDecision
APPROVAL_DECISION_APPROVED: ApprovalDecision
APPROVAL_DECISION_REJECTED: ApprovalDecision
ACTIVE_TURN_STATE_UNSPECIFIED: ActiveTurnState
ACTIVE_TURN_STATE_ACCEPTED: ActiveTurnState
ACTIVE_TURN_STATE_RUNNING: ActiveTurnState
ACTIVE_TURN_STATE_WAITING_FOR_APPROVAL: ActiveTurnState
ACTIVE_TURN_STATE_RECONCILING: ActiveTurnState

class ConversationFailure(_message.Message):
    __slots__ = ("code", "message", "retryable")
    CODE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    RETRYABLE_FIELD_NUMBER: _ClassVar[int]
    code: str
    message: str
    retryable: bool
    def __init__(self, code: _Optional[str] = ..., message: _Optional[str] = ..., retryable: _Optional[bool] = ...) -> None: ...

class TextPart(_message.Message):
    __slots__ = ("part_id", "revision", "text")
    PART_ID_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    part_id: str
    revision: int
    text: str
    def __init__(self, part_id: _Optional[str] = ..., revision: _Optional[int] = ..., text: _Optional[str] = ...) -> None: ...

class ToolCallPart(_message.Message):
    __slots__ = ("part_id", "revision", "call_id", "effect_id", "tool_name", "canonical_arguments")
    PART_ID_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    CALL_ID_FIELD_NUMBER: _ClassVar[int]
    EFFECT_ID_FIELD_NUMBER: _ClassVar[int]
    TOOL_NAME_FIELD_NUMBER: _ClassVar[int]
    CANONICAL_ARGUMENTS_FIELD_NUMBER: _ClassVar[int]
    part_id: str
    revision: int
    call_id: str
    effect_id: str
    tool_name: str
    canonical_arguments: str
    def __init__(self, part_id: _Optional[str] = ..., revision: _Optional[int] = ..., call_id: _Optional[str] = ..., effect_id: _Optional[str] = ..., tool_name: _Optional[str] = ..., canonical_arguments: _Optional[str] = ...) -> None: ...

class ToolResultPart(_message.Message):
    __slots__ = ("part_id", "revision", "call_id", "effect_id", "canonical_result")
    PART_ID_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    CALL_ID_FIELD_NUMBER: _ClassVar[int]
    EFFECT_ID_FIELD_NUMBER: _ClassVar[int]
    CANONICAL_RESULT_FIELD_NUMBER: _ClassVar[int]
    part_id: str
    revision: int
    call_id: str
    effect_id: str
    canonical_result: str
    def __init__(self, part_id: _Optional[str] = ..., revision: _Optional[int] = ..., call_id: _Optional[str] = ..., effect_id: _Optional[str] = ..., canonical_result: _Optional[str] = ...) -> None: ...

class ToolFailurePart(_message.Message):
    __slots__ = ("part_id", "revision", "call_id", "effect_id", "failure")
    PART_ID_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    CALL_ID_FIELD_NUMBER: _ClassVar[int]
    EFFECT_ID_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    part_id: str
    revision: int
    call_id: str
    effect_id: str
    failure: ConversationFailure
    def __init__(self, part_id: _Optional[str] = ..., revision: _Optional[int] = ..., call_id: _Optional[str] = ..., effect_id: _Optional[str] = ..., failure: _Optional[_Union[ConversationFailure, _Mapping]] = ...) -> None: ...

class ApprovalRequestPart(_message.Message):
    __slots__ = ("part_id", "revision", "approval_id", "call_id", "effect_id", "tool_name", "canonical_arguments", "request_sha256", "expires_at")
    PART_ID_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    APPROVAL_ID_FIELD_NUMBER: _ClassVar[int]
    CALL_ID_FIELD_NUMBER: _ClassVar[int]
    EFFECT_ID_FIELD_NUMBER: _ClassVar[int]
    TOOL_NAME_FIELD_NUMBER: _ClassVar[int]
    CANONICAL_ARGUMENTS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_SHA256_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    part_id: str
    revision: int
    approval_id: str
    call_id: str
    effect_id: str
    tool_name: str
    canonical_arguments: str
    request_sha256: str
    expires_at: _timestamp_pb2.Timestamp
    def __init__(self, part_id: _Optional[str] = ..., revision: _Optional[int] = ..., approval_id: _Optional[str] = ..., call_id: _Optional[str] = ..., effect_id: _Optional[str] = ..., tool_name: _Optional[str] = ..., canonical_arguments: _Optional[str] = ..., request_sha256: _Optional[str] = ..., expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ApprovalResponsePart(_message.Message):
    __slots__ = ("part_id", "revision", "approval_id", "request_sha256", "decision", "resolved_at")
    PART_ID_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    APPROVAL_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_SHA256_FIELD_NUMBER: _ClassVar[int]
    DECISION_FIELD_NUMBER: _ClassVar[int]
    RESOLVED_AT_FIELD_NUMBER: _ClassVar[int]
    part_id: str
    revision: int
    approval_id: str
    request_sha256: str
    decision: ApprovalDecision
    resolved_at: _timestamp_pb2.Timestamp
    def __init__(self, part_id: _Optional[str] = ..., revision: _Optional[int] = ..., approval_id: _Optional[str] = ..., request_sha256: _Optional[str] = ..., decision: _Optional[_Union[ApprovalDecision, str]] = ..., resolved_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class OperationPart(_message.Message):
    __slots__ = ("part_id", "revision", "operation")
    PART_ID_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    part_id: str
    revision: int
    operation: str
    def __init__(self, part_id: _Optional[str] = ..., revision: _Optional[int] = ..., operation: _Optional[str] = ...) -> None: ...

class ArtifactPart(_message.Message):
    __slots__ = ("part_id", "revision", "artifact")
    PART_ID_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_FIELD_NUMBER: _ClassVar[int]
    part_id: str
    revision: int
    artifact: _common_pb2.ContentRef
    def __init__(self, part_id: _Optional[str] = ..., revision: _Optional[int] = ..., artifact: _Optional[_Union[_common_pb2.ContentRef, _Mapping]] = ...) -> None: ...

class AuthoredPart(_message.Message):
    __slots__ = ("text", "tool_call", "tool_result", "tool_failure", "approval_request", "approval_response")
    TEXT_FIELD_NUMBER: _ClassVar[int]
    TOOL_CALL_FIELD_NUMBER: _ClassVar[int]
    TOOL_RESULT_FIELD_NUMBER: _ClassVar[int]
    TOOL_FAILURE_FIELD_NUMBER: _ClassVar[int]
    APPROVAL_REQUEST_FIELD_NUMBER: _ClassVar[int]
    APPROVAL_RESPONSE_FIELD_NUMBER: _ClassVar[int]
    text: TextPart
    tool_call: ToolCallPart
    tool_result: ToolResultPart
    tool_failure: ToolFailurePart
    approval_request: ApprovalRequestPart
    approval_response: ApprovalResponsePart
    def __init__(self, text: _Optional[_Union[TextPart, _Mapping]] = ..., tool_call: _Optional[_Union[ToolCallPart, _Mapping]] = ..., tool_result: _Optional[_Union[ToolResultPart, _Mapping]] = ..., tool_failure: _Optional[_Union[ToolFailurePart, _Mapping]] = ..., approval_request: _Optional[_Union[ApprovalRequestPart, _Mapping]] = ..., approval_response: _Optional[_Union[ApprovalResponsePart, _Mapping]] = ...) -> None: ...

class MessagePart(_message.Message):
    __slots__ = ("text", "tool_call", "tool_result", "tool_failure", "approval_request", "approval_response", "operation", "artifact")
    TEXT_FIELD_NUMBER: _ClassVar[int]
    TOOL_CALL_FIELD_NUMBER: _ClassVar[int]
    TOOL_RESULT_FIELD_NUMBER: _ClassVar[int]
    TOOL_FAILURE_FIELD_NUMBER: _ClassVar[int]
    APPROVAL_REQUEST_FIELD_NUMBER: _ClassVar[int]
    APPROVAL_RESPONSE_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_FIELD_NUMBER: _ClassVar[int]
    text: TextPart
    tool_call: ToolCallPart
    tool_result: ToolResultPart
    tool_failure: ToolFailurePart
    approval_request: ApprovalRequestPart
    approval_response: ApprovalResponsePart
    operation: OperationPart
    artifact: ArtifactPart
    def __init__(self, text: _Optional[_Union[TextPart, _Mapping]] = ..., tool_call: _Optional[_Union[ToolCallPart, _Mapping]] = ..., tool_result: _Optional[_Union[ToolResultPart, _Mapping]] = ..., tool_failure: _Optional[_Union[ToolFailurePart, _Mapping]] = ..., approval_request: _Optional[_Union[ApprovalRequestPart, _Mapping]] = ..., approval_response: _Optional[_Union[ApprovalResponsePart, _Mapping]] = ..., operation: _Optional[_Union[OperationPart, _Mapping]] = ..., artifact: _Optional[_Union[ArtifactPart, _Mapping]] = ...) -> None: ...

class ConversationMessage(_message.Message):
    __slots__ = ("message_id", "turn_id", "role", "created_at", "parts")
    MESSAGE_ID_FIELD_NUMBER: _ClassVar[int]
    TURN_ID_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    PARTS_FIELD_NUMBER: _ClassVar[int]
    message_id: str
    turn_id: str
    role: ConversationRole
    created_at: _timestamp_pb2.Timestamp
    parts: _containers.RepeatedCompositeFieldContainer[MessagePart]
    def __init__(self, message_id: _Optional[str] = ..., turn_id: _Optional[str] = ..., role: _Optional[_Union[ConversationRole, str]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., parts: _Optional[_Iterable[_Union[MessagePart, _Mapping]]] = ...) -> None: ...

class TurnAccepted(_message.Message):
    __slots__ = ("message_id", "request_sha256")
    MESSAGE_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_SHA256_FIELD_NUMBER: _ClassVar[int]
    message_id: str
    request_sha256: str
    def __init__(self, message_id: _Optional[str] = ..., request_sha256: _Optional[str] = ...) -> None: ...

class TurnRunning(_message.Message):
    __slots__ = ("resume_key",)
    RESUME_KEY_FIELD_NUMBER: _ClassVar[int]
    resume_key: str
    def __init__(self, resume_key: _Optional[str] = ...) -> None: ...

class TurnWaitingForApproval(_message.Message):
    __slots__ = ("approval_id",)
    APPROVAL_ID_FIELD_NUMBER: _ClassVar[int]
    approval_id: str
    def __init__(self, approval_id: _Optional[str] = ...) -> None: ...

class TurnReconciling(_message.Message):
    __slots__ = ("call_id",)
    CALL_ID_FIELD_NUMBER: _ClassVar[int]
    call_id: str
    def __init__(self, call_id: _Optional[str] = ...) -> None: ...

class TurnCancelRequested(_message.Message):
    __slots__ = ("reason",)
    REASON_FIELD_NUMBER: _ClassVar[int]
    reason: str
    def __init__(self, reason: _Optional[str] = ...) -> None: ...

class PartUpserted(_message.Message):
    __slots__ = ("message_id", "part")
    MESSAGE_ID_FIELD_NUMBER: _ClassVar[int]
    PART_FIELD_NUMBER: _ClassVar[int]
    message_id: str
    part: AuthoredPart
    def __init__(self, message_id: _Optional[str] = ..., part: _Optional[_Union[AuthoredPart, _Mapping]] = ...) -> None: ...

class OperationAttached(_message.Message):
    __slots__ = ("message_id", "part")
    MESSAGE_ID_FIELD_NUMBER: _ClassVar[int]
    PART_FIELD_NUMBER: _ClassVar[int]
    message_id: str
    part: OperationPart
    def __init__(self, message_id: _Optional[str] = ..., part: _Optional[_Union[OperationPart, _Mapping]] = ...) -> None: ...

class ArtifactAttached(_message.Message):
    __slots__ = ("message_id", "part")
    MESSAGE_ID_FIELD_NUMBER: _ClassVar[int]
    PART_FIELD_NUMBER: _ClassVar[int]
    message_id: str
    part: ArtifactPart
    def __init__(self, message_id: _Optional[str] = ..., part: _Optional[_Union[ArtifactPart, _Mapping]] = ...) -> None: ...

class TurnSucceeded(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class TurnFailed(_message.Message):
    __slots__ = ("failure",)
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    failure: ConversationFailure
    def __init__(self, failure: _Optional[_Union[ConversationFailure, _Mapping]] = ...) -> None: ...

class TurnCancelled(_message.Message):
    __slots__ = ("reason",)
    REASON_FIELD_NUMBER: _ClassVar[int]
    reason: str
    def __init__(self, reason: _Optional[str] = ...) -> None: ...

class TurnEventPayload(_message.Message):
    __slots__ = ("turn_accepted", "turn_running", "turn_waiting_for_approval", "turn_reconciling", "turn_cancel_requested", "part_upserted", "operation_attached", "artifact_attached", "turn_succeeded", "turn_failed", "turn_cancelled")
    TURN_ACCEPTED_FIELD_NUMBER: _ClassVar[int]
    TURN_RUNNING_FIELD_NUMBER: _ClassVar[int]
    TURN_WAITING_FOR_APPROVAL_FIELD_NUMBER: _ClassVar[int]
    TURN_RECONCILING_FIELD_NUMBER: _ClassVar[int]
    TURN_CANCEL_REQUESTED_FIELD_NUMBER: _ClassVar[int]
    PART_UPSERTED_FIELD_NUMBER: _ClassVar[int]
    OPERATION_ATTACHED_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_ATTACHED_FIELD_NUMBER: _ClassVar[int]
    TURN_SUCCEEDED_FIELD_NUMBER: _ClassVar[int]
    TURN_FAILED_FIELD_NUMBER: _ClassVar[int]
    TURN_CANCELLED_FIELD_NUMBER: _ClassVar[int]
    turn_accepted: TurnAccepted
    turn_running: TurnRunning
    turn_waiting_for_approval: TurnWaitingForApproval
    turn_reconciling: TurnReconciling
    turn_cancel_requested: TurnCancelRequested
    part_upserted: PartUpserted
    operation_attached: OperationAttached
    artifact_attached: ArtifactAttached
    turn_succeeded: TurnSucceeded
    turn_failed: TurnFailed
    turn_cancelled: TurnCancelled
    def __init__(self, turn_accepted: _Optional[_Union[TurnAccepted, _Mapping]] = ..., turn_running: _Optional[_Union[TurnRunning, _Mapping]] = ..., turn_waiting_for_approval: _Optional[_Union[TurnWaitingForApproval, _Mapping]] = ..., turn_reconciling: _Optional[_Union[TurnReconciling, _Mapping]] = ..., turn_cancel_requested: _Optional[_Union[TurnCancelRequested, _Mapping]] = ..., part_upserted: _Optional[_Union[PartUpserted, _Mapping]] = ..., operation_attached: _Optional[_Union[OperationAttached, _Mapping]] = ..., artifact_attached: _Optional[_Union[ArtifactAttached, _Mapping]] = ..., turn_succeeded: _Optional[_Union[TurnSucceeded, _Mapping]] = ..., turn_failed: _Optional[_Union[TurnFailed, _Mapping]] = ..., turn_cancelled: _Optional[_Union[TurnCancelled, _Mapping]] = ...) -> None: ...

class TurnEvent(_message.Message):
    __slots__ = ("conversation_id", "turn_id", "cursor", "occurred_at", "trace_id", "payload")
    CONVERSATION_ID_FIELD_NUMBER: _ClassVar[int]
    TURN_ID_FIELD_NUMBER: _ClassVar[int]
    CURSOR_FIELD_NUMBER: _ClassVar[int]
    OCCURRED_AT_FIELD_NUMBER: _ClassVar[int]
    TRACE_ID_FIELD_NUMBER: _ClassVar[int]
    PAYLOAD_FIELD_NUMBER: _ClassVar[int]
    conversation_id: str
    turn_id: str
    cursor: int
    occurred_at: _timestamp_pb2.Timestamp
    trace_id: str
    payload: TurnEventPayload
    def __init__(self, conversation_id: _Optional[str] = ..., turn_id: _Optional[str] = ..., cursor: _Optional[int] = ..., occurred_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., trace_id: _Optional[str] = ..., payload: _Optional[_Union[TurnEventPayload, _Mapping]] = ...) -> None: ...

class ActiveTurnSnapshot(_message.Message):
    __slots__ = ("turn_id", "state", "cancel_requested", "pending_approval_id")
    TURN_ID_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    CANCEL_REQUESTED_FIELD_NUMBER: _ClassVar[int]
    PENDING_APPROVAL_ID_FIELD_NUMBER: _ClassVar[int]
    turn_id: str
    state: ActiveTurnState
    cancel_requested: bool
    pending_approval_id: str
    def __init__(self, turn_id: _Optional[str] = ..., state: _Optional[_Union[ActiveTurnState, str]] = ..., cancel_requested: _Optional[bool] = ..., pending_approval_id: _Optional[str] = ...) -> None: ...

class EventBatch(_message.Message):
    __slots__ = ("events", "latest_cursor")
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    LATEST_CURSOR_FIELD_NUMBER: _ClassVar[int]
    events: _containers.RepeatedCompositeFieldContainer[TurnEvent]
    latest_cursor: int
    def __init__(self, events: _Optional[_Iterable[_Union[TurnEvent, _Mapping]]] = ..., latest_cursor: _Optional[int] = ...) -> None: ...

class EventHistoryGap(_message.Message):
    __slots__ = ("latest_cursor", "snapshot", "active_turn")
    LATEST_CURSOR_FIELD_NUMBER: _ClassVar[int]
    SNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_TURN_FIELD_NUMBER: _ClassVar[int]
    latest_cursor: int
    snapshot: _containers.RepeatedCompositeFieldContainer[ConversationMessage]
    active_turn: ActiveTurnSnapshot
    def __init__(self, latest_cursor: _Optional[int] = ..., snapshot: _Optional[_Iterable[_Union[ConversationMessage, _Mapping]]] = ..., active_turn: _Optional[_Union[ActiveTurnSnapshot, _Mapping]] = ...) -> None: ...

class EventPage(_message.Message):
    __slots__ = ("batch", "history_gap")
    BATCH_FIELD_NUMBER: _ClassVar[int]
    HISTORY_GAP_FIELD_NUMBER: _ClassVar[int]
    batch: EventBatch
    history_gap: EventHistoryGap
    def __init__(self, batch: _Optional[_Union[EventBatch, _Mapping]] = ..., history_gap: _Optional[_Union[EventHistoryGap, _Mapping]] = ...) -> None: ...

class MessagePage(_message.Message):
    __slots__ = ("messages", "next_before")
    MESSAGES_FIELD_NUMBER: _ClassVar[int]
    NEXT_BEFORE_FIELD_NUMBER: _ClassVar[int]
    messages: _containers.RepeatedCompositeFieldContainer[ConversationMessage]
    next_before: int
    def __init__(self, messages: _Optional[_Iterable[_Union[ConversationMessage, _Mapping]]] = ..., next_before: _Optional[int] = ...) -> None: ...

class TurnAdmission(_message.Message):
    __slots__ = ("conversation_id", "turn_id", "message_id", "request_sha256", "cursor", "replayed")
    CONVERSATION_ID_FIELD_NUMBER: _ClassVar[int]
    TURN_ID_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_SHA256_FIELD_NUMBER: _ClassVar[int]
    CURSOR_FIELD_NUMBER: _ClassVar[int]
    REPLAYED_FIELD_NUMBER: _ClassVar[int]
    conversation_id: str
    turn_id: str
    message_id: str
    request_sha256: str
    cursor: int
    replayed: bool
    def __init__(self, conversation_id: _Optional[str] = ..., turn_id: _Optional[str] = ..., message_id: _Optional[str] = ..., request_sha256: _Optional[str] = ..., cursor: _Optional[int] = ..., replayed: _Optional[bool] = ...) -> None: ...

class ApprovalResponse(_message.Message):
    __slots__ = ("approval_id", "request_sha256", "decision")
    APPROVAL_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_SHA256_FIELD_NUMBER: _ClassVar[int]
    DECISION_FIELD_NUMBER: _ClassVar[int]
    approval_id: str
    request_sha256: str
    decision: ApprovalDecision
    def __init__(self, approval_id: _Optional[str] = ..., request_sha256: _Optional[str] = ..., decision: _Optional[_Union[ApprovalDecision, str]] = ...) -> None: ...
