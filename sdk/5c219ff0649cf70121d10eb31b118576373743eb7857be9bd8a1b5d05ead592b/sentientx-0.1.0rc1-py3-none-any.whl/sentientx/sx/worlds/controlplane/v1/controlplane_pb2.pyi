import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from sentientx.sx.api.v1 import options_pb2 as _options_pb2
from sentientx.sx.common.v1 import assets_pb2 as _assets_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from sentientx.sx.common.v1 import outcomes_pb2 as _outcomes_pb2
from sentientx.sx.common.v1 import stations_pb2 as _stations_pb2
from sentientx.sx.operations.v1 import operations_pb2 as _operations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Simulator(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SIMULATOR_UNSPECIFIED: _ClassVar[Simulator]
    SIMULATOR_MUJOCO: _ClassVar[Simulator]
    SIMULATOR_ISAAC_LAB_NEWTON: _ClassVar[Simulator]

class PolicyArtifactKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    POLICY_ARTIFACT_KIND_UNSPECIFIED: _ClassVar[PolicyArtifactKind]
    POLICY_ARTIFACT_KIND_CODE_POLICY: _ClassVar[PolicyArtifactKind]
    POLICY_ARTIFACT_KIND_POLICY_GRAPH: _ClassVar[PolicyArtifactKind]

class ScriptedDecisionKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SCRIPTED_DECISION_KIND_UNSPECIFIED: _ClassVar[ScriptedDecisionKind]
    SCRIPTED_DECISION_KIND_PICK: _ClassVar[ScriptedDecisionKind]
    SCRIPTED_DECISION_KIND_PLACE: _ClassVar[ScriptedDecisionKind]
    SCRIPTED_DECISION_KIND_TRANSFER: _ClassVar[ScriptedDecisionKind]
    SCRIPTED_DECISION_KIND_VLA: _ClassVar[ScriptedDecisionKind]

class SeedSelection(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SEED_SELECTION_UNSPECIFIED: _ClassVar[SeedSelection]
    SEED_SELECTION_RANDOM: _ClassVar[SeedSelection]
    SEED_SELECTION_NEAREST_NEIGHBOR_OBJECT: _ClassVar[SeedSelection]
    SEED_SELECTION_NEAREST_NEIGHBOR_ROBOT_DISTANCE: _ClassVar[SeedSelection]

class EnvironmentAuthoringQuality(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ENVIRONMENT_AUTHORING_QUALITY_UNSPECIFIED: _ClassVar[EnvironmentAuthoringQuality]
    ENVIRONMENT_AUTHORING_QUALITY_DEFAULT: _ClassVar[EnvironmentAuthoringQuality]
    ENVIRONMENT_AUTHORING_QUALITY_HIGH: _ClassVar[EnvironmentAuthoringQuality]

class ObjectAuthoringQuality(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    OBJECT_AUTHORING_QUALITY_UNSPECIFIED: _ClassVar[ObjectAuthoringQuality]
    OBJECT_AUTHORING_QUALITY_DEFAULT: _ClassVar[ObjectAuthoringQuality]
    OBJECT_AUTHORING_QUALITY_HIGH: _ClassVar[ObjectAuthoringQuality]

class TaskBindingOutcome(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TASK_BINDING_OUTCOME_UNSPECIFIED: _ClassVar[TaskBindingOutcome]
    TASK_BINDING_OUTCOME_BOUND: _ClassVar[TaskBindingOutcome]
    TASK_BINDING_OUTCOME_SHORTFALL: _ClassVar[TaskBindingOutcome]
    TASK_BINDING_OUTCOME_UNSUPPORTED: _ClassVar[TaskBindingOutcome]
    TASK_BINDING_OUTCOME_UNAVAILABLE: _ClassVar[TaskBindingOutcome]

class EnvironmentSource(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ENVIRONMENT_SOURCE_UNSPECIFIED: _ClassVar[EnvironmentSource]
    ENVIRONMENT_SOURCE_XGRIDS_SCAN: _ClassVar[EnvironmentSource]
    ENVIRONMENT_SOURCE_MARBLE_GENERATION: _ClassVar[EnvironmentSource]
    ENVIRONMENT_SOURCE_TRELLIS_RECONSTRUCTION: _ClassVar[EnvironmentSource]
    ENVIRONMENT_SOURCE_SCENESMITH_GENERATION: _ClassVar[EnvironmentSource]
    ENVIRONMENT_SOURCE_MOLMOSPACES_GENERATION: _ClassVar[EnvironmentSource]
    ENVIRONMENT_SOURCE_LITEREALITY_GENERATION: _ClassVar[EnvironmentSource]
    ENVIRONMENT_SOURCE_ARTICRAFT_GENERATION: _ClassVar[EnvironmentSource]

class ObjectAssetSource(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    OBJECT_ASSET_SOURCE_UNSPECIFIED: _ClassVar[ObjectAssetSource]
    OBJECT_ASSET_SOURCE_TRELLIS_2: _ClassVar[ObjectAssetSource]
    OBJECT_ASSET_SOURCE_ARTICRAFT: _ClassVar[ObjectAssetSource]
    OBJECT_ASSET_SOURCE_ARTICULATED_AUTHORING: _ClassVar[ObjectAssetSource]

class SceneJointKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SCENE_JOINT_KIND_UNSPECIFIED: _ClassVar[SceneJointKind]
    SCENE_JOINT_KIND_HINGE: _ClassVar[SceneJointKind]
    SCENE_JOINT_KIND_SLIDE: _ClassVar[SceneJointKind]

class GenerationRejectionReason(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    GENERATION_REJECTION_REASON_UNSPECIFIED: _ClassVar[GenerationRejectionReason]
    GENERATION_REJECTION_REASON_ESCAPED: _ClassVar[GenerationRejectionReason]
    GENERATION_REJECTION_REASON_UNSETTLED: _ClassVar[GenerationRejectionReason]
    GENERATION_REJECTION_REASON_TILTED: _ClassVar[GenerationRejectionReason]
    GENERATION_REJECTION_REASON_CRITIC_REJECTED: _ClassVar[GenerationRejectionReason]
    GENERATION_REJECTION_REASON_UNPROJECTABLE: _ClassVar[GenerationRejectionReason]
    GENERATION_REJECTION_REASON_MALFORMED_PROPOSAL: _ClassVar[GenerationRejectionReason]

class MujocoIntegrator(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    MUJOCO_INTEGRATOR_UNSPECIFIED: _ClassVar[MujocoIntegrator]
    MUJOCO_INTEGRATOR_EULER: _ClassVar[MujocoIntegrator]
    MUJOCO_INTEGRATOR_RK4: _ClassVar[MujocoIntegrator]
    MUJOCO_INTEGRATOR_IMPLICIT: _ClassVar[MujocoIntegrator]
    MUJOCO_INTEGRATOR_IMPLICIT_FAST: _ClassVar[MujocoIntegrator]

class MujocoSolver(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    MUJOCO_SOLVER_UNSPECIFIED: _ClassVar[MujocoSolver]
    MUJOCO_SOLVER_PGS: _ClassVar[MujocoSolver]
    MUJOCO_SOLVER_CG: _ClassVar[MujocoSolver]
    MUJOCO_SOLVER_NEWTON: _ClassVar[MujocoSolver]

class RenderBackend(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    RENDER_BACKEND_UNSPECIFIED: _ClassVar[RenderBackend]
    RENDER_BACKEND_EGL: _ClassVar[RenderBackend]
    RENDER_BACKEND_OSMESA: _ClassVar[RenderBackend]
    RENDER_BACKEND_GLFW: _ClassVar[RenderBackend]
    RENDER_BACKEND_VULKAN: _ClassVar[RenderBackend]
    RENDER_BACKEND_CUDA: _ClassVar[RenderBackend]
    RENDER_BACKEND_CGL: _ClassVar[RenderBackend]

class SimulationJobFamily(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SIMULATION_JOB_FAMILY_UNSPECIFIED: _ClassVar[SimulationJobFamily]
    SIMULATION_JOB_FAMILY_SESSION: _ClassVar[SimulationJobFamily]
    SIMULATION_JOB_FAMILY_EVALUATION: _ClassVar[SimulationJobFamily]
    SIMULATION_JOB_FAMILY_GENERATION: _ClassVar[SimulationJobFamily]

class SimulationResourceBand(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SIMULATION_RESOURCE_BAND_UNSPECIFIED: _ClassVar[SimulationResourceBand]
    SIMULATION_RESOURCE_BAND_CPU: _ClassVar[SimulationResourceBand]
    SIMULATION_RESOURCE_BAND_GPU: _ClassVar[SimulationResourceBand]

class WorldSessionState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    WORLD_SESSION_STATE_UNSPECIFIED: _ClassVar[WorldSessionState]
    WORLD_SESSION_STATE_STARTING: _ClassVar[WorldSessionState]
    WORLD_SESSION_STATE_READY: _ClassVar[WorldSessionState]
    WORLD_SESSION_STATE_CLOSING: _ClassVar[WorldSessionState]
    WORLD_SESSION_STATE_CLOSED: _ClassVar[WorldSessionState]
    WORLD_SESSION_STATE_EXPIRED: _ClassVar[WorldSessionState]
    WORLD_SESSION_STATE_SAFETY_STOPPED: _ClassVar[WorldSessionState]
    WORLD_SESSION_STATE_FAILED: _ClassVar[WorldSessionState]

class SessionVerificationStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SESSION_VERIFICATION_STATUS_UNSPECIFIED: _ClassVar[SessionVerificationStatus]
    SESSION_VERIFICATION_STATUS_SATISFIED: _ClassVar[SessionVerificationStatus]
    SESSION_VERIFICATION_STATUS_NOT_SATISFIED: _ClassVar[SessionVerificationStatus]
    SESSION_VERIFICATION_STATUS_UNKNOWN: _ClassVar[SessionVerificationStatus]
SIMULATOR_UNSPECIFIED: Simulator
SIMULATOR_MUJOCO: Simulator
SIMULATOR_ISAAC_LAB_NEWTON: Simulator
POLICY_ARTIFACT_KIND_UNSPECIFIED: PolicyArtifactKind
POLICY_ARTIFACT_KIND_CODE_POLICY: PolicyArtifactKind
POLICY_ARTIFACT_KIND_POLICY_GRAPH: PolicyArtifactKind
SCRIPTED_DECISION_KIND_UNSPECIFIED: ScriptedDecisionKind
SCRIPTED_DECISION_KIND_PICK: ScriptedDecisionKind
SCRIPTED_DECISION_KIND_PLACE: ScriptedDecisionKind
SCRIPTED_DECISION_KIND_TRANSFER: ScriptedDecisionKind
SCRIPTED_DECISION_KIND_VLA: ScriptedDecisionKind
SEED_SELECTION_UNSPECIFIED: SeedSelection
SEED_SELECTION_RANDOM: SeedSelection
SEED_SELECTION_NEAREST_NEIGHBOR_OBJECT: SeedSelection
SEED_SELECTION_NEAREST_NEIGHBOR_ROBOT_DISTANCE: SeedSelection
ENVIRONMENT_AUTHORING_QUALITY_UNSPECIFIED: EnvironmentAuthoringQuality
ENVIRONMENT_AUTHORING_QUALITY_DEFAULT: EnvironmentAuthoringQuality
ENVIRONMENT_AUTHORING_QUALITY_HIGH: EnvironmentAuthoringQuality
OBJECT_AUTHORING_QUALITY_UNSPECIFIED: ObjectAuthoringQuality
OBJECT_AUTHORING_QUALITY_DEFAULT: ObjectAuthoringQuality
OBJECT_AUTHORING_QUALITY_HIGH: ObjectAuthoringQuality
TASK_BINDING_OUTCOME_UNSPECIFIED: TaskBindingOutcome
TASK_BINDING_OUTCOME_BOUND: TaskBindingOutcome
TASK_BINDING_OUTCOME_SHORTFALL: TaskBindingOutcome
TASK_BINDING_OUTCOME_UNSUPPORTED: TaskBindingOutcome
TASK_BINDING_OUTCOME_UNAVAILABLE: TaskBindingOutcome
ENVIRONMENT_SOURCE_UNSPECIFIED: EnvironmentSource
ENVIRONMENT_SOURCE_XGRIDS_SCAN: EnvironmentSource
ENVIRONMENT_SOURCE_MARBLE_GENERATION: EnvironmentSource
ENVIRONMENT_SOURCE_TRELLIS_RECONSTRUCTION: EnvironmentSource
ENVIRONMENT_SOURCE_SCENESMITH_GENERATION: EnvironmentSource
ENVIRONMENT_SOURCE_MOLMOSPACES_GENERATION: EnvironmentSource
ENVIRONMENT_SOURCE_LITEREALITY_GENERATION: EnvironmentSource
ENVIRONMENT_SOURCE_ARTICRAFT_GENERATION: EnvironmentSource
OBJECT_ASSET_SOURCE_UNSPECIFIED: ObjectAssetSource
OBJECT_ASSET_SOURCE_TRELLIS_2: ObjectAssetSource
OBJECT_ASSET_SOURCE_ARTICRAFT: ObjectAssetSource
OBJECT_ASSET_SOURCE_ARTICULATED_AUTHORING: ObjectAssetSource
SCENE_JOINT_KIND_UNSPECIFIED: SceneJointKind
SCENE_JOINT_KIND_HINGE: SceneJointKind
SCENE_JOINT_KIND_SLIDE: SceneJointKind
GENERATION_REJECTION_REASON_UNSPECIFIED: GenerationRejectionReason
GENERATION_REJECTION_REASON_ESCAPED: GenerationRejectionReason
GENERATION_REJECTION_REASON_UNSETTLED: GenerationRejectionReason
GENERATION_REJECTION_REASON_TILTED: GenerationRejectionReason
GENERATION_REJECTION_REASON_CRITIC_REJECTED: GenerationRejectionReason
GENERATION_REJECTION_REASON_UNPROJECTABLE: GenerationRejectionReason
GENERATION_REJECTION_REASON_MALFORMED_PROPOSAL: GenerationRejectionReason
MUJOCO_INTEGRATOR_UNSPECIFIED: MujocoIntegrator
MUJOCO_INTEGRATOR_EULER: MujocoIntegrator
MUJOCO_INTEGRATOR_RK4: MujocoIntegrator
MUJOCO_INTEGRATOR_IMPLICIT: MujocoIntegrator
MUJOCO_INTEGRATOR_IMPLICIT_FAST: MujocoIntegrator
MUJOCO_SOLVER_UNSPECIFIED: MujocoSolver
MUJOCO_SOLVER_PGS: MujocoSolver
MUJOCO_SOLVER_CG: MujocoSolver
MUJOCO_SOLVER_NEWTON: MujocoSolver
RENDER_BACKEND_UNSPECIFIED: RenderBackend
RENDER_BACKEND_EGL: RenderBackend
RENDER_BACKEND_OSMESA: RenderBackend
RENDER_BACKEND_GLFW: RenderBackend
RENDER_BACKEND_VULKAN: RenderBackend
RENDER_BACKEND_CUDA: RenderBackend
RENDER_BACKEND_CGL: RenderBackend
SIMULATION_JOB_FAMILY_UNSPECIFIED: SimulationJobFamily
SIMULATION_JOB_FAMILY_SESSION: SimulationJobFamily
SIMULATION_JOB_FAMILY_EVALUATION: SimulationJobFamily
SIMULATION_JOB_FAMILY_GENERATION: SimulationJobFamily
SIMULATION_RESOURCE_BAND_UNSPECIFIED: SimulationResourceBand
SIMULATION_RESOURCE_BAND_CPU: SimulationResourceBand
SIMULATION_RESOURCE_BAND_GPU: SimulationResourceBand
WORLD_SESSION_STATE_UNSPECIFIED: WorldSessionState
WORLD_SESSION_STATE_STARTING: WorldSessionState
WORLD_SESSION_STATE_READY: WorldSessionState
WORLD_SESSION_STATE_CLOSING: WorldSessionState
WORLD_SESSION_STATE_CLOSED: WorldSessionState
WORLD_SESSION_STATE_EXPIRED: WorldSessionState
WORLD_SESSION_STATE_SAFETY_STOPPED: WorldSessionState
WORLD_SESSION_STATE_FAILED: WorldSessionState
SESSION_VERIFICATION_STATUS_UNSPECIFIED: SessionVerificationStatus
SESSION_VERIFICATION_STATUS_SATISFIED: SessionVerificationStatus
SESSION_VERIFICATION_STATUS_NOT_SATISFIED: SessionVerificationStatus
SESSION_VERIFICATION_STATUS_UNKNOWN: SessionVerificationStatus

class AssetClosure(_message.Message):
    __slots__ = ("root", "members")
    ROOT_FIELD_NUMBER: _ClassVar[int]
    MEMBERS_FIELD_NUMBER: _ClassVar[int]
    root: _assets_pb2.AssetRef
    members: _containers.RepeatedCompositeFieldContainer[_assets_pb2.AssetRef]
    def __init__(self, root: _Optional[_Union[_assets_pb2.AssetRef, _Mapping]] = ..., members: _Optional[_Iterable[_Union[_assets_pb2.AssetRef, _Mapping]]] = ...) -> None: ...

class PolicyArtifactSubject(_message.Message):
    __slots__ = ("kind", "artifact")
    KIND_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_FIELD_NUMBER: _ClassVar[int]
    kind: PolicyArtifactKind
    artifact: _common_pb2.ContentRef
    def __init__(self, kind: _Optional[_Union[PolicyArtifactKind, str]] = ..., artifact: _Optional[_Union[_common_pb2.ContentRef, _Mapping]] = ...) -> None: ...

class ZeroActionSubject(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class EvaluationSubject(_message.Message):
    __slots__ = ("artifact", "zero_action")
    ARTIFACT_FIELD_NUMBER: _ClassVar[int]
    ZERO_ACTION_FIELD_NUMBER: _ClassVar[int]
    artifact: PolicyArtifactSubject
    zero_action: ZeroActionSubject
    def __init__(self, artifact: _Optional[_Union[PolicyArtifactSubject, _Mapping]] = ..., zero_action: _Optional[_Union[ZeroActionSubject, _Mapping]] = ...) -> None: ...

class StartApplicationEvaluationRequest(_message.Message):
    __slots__ = ("task", "application_ref", "seed", "timeout")
    TASK_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_REF_FIELD_NUMBER: _ClassVar[int]
    SEED_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    task: _common_pb2.TaskContractRef
    application_ref: str
    seed: int
    timeout: _duration_pb2.Duration
    def __init__(self, task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., application_ref: _Optional[str] = ..., seed: _Optional[int] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class StartApplicationEvaluationResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: WorldsOperation
    def __init__(self, operation: _Optional[_Union[WorldsOperation, _Mapping]] = ...) -> None: ...

class StartSubjectEvaluationRequest(_message.Message):
    __slots__ = ("task", "subject", "seed", "timeout")
    TASK_FIELD_NUMBER: _ClassVar[int]
    SUBJECT_FIELD_NUMBER: _ClassVar[int]
    SEED_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    task: _common_pb2.TaskContractRef
    subject: EvaluationSubject
    seed: int
    timeout: _duration_pb2.Duration
    def __init__(self, task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., subject: _Optional[_Union[EvaluationSubject, _Mapping]] = ..., seed: _Optional[int] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class StartSubjectEvaluationResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: WorldsOperation
    def __init__(self, operation: _Optional[_Union[WorldsOperation, _Mapping]] = ...) -> None: ...

class ReplanInterval(_message.Message):
    __slots__ = ("chunks", "wall_ms")
    CHUNKS_FIELD_NUMBER: _ClassVar[int]
    WALL_MS_FIELD_NUMBER: _ClassVar[int]
    chunks: int
    wall_ms: int
    def __init__(self, chunks: _Optional[int] = ..., wall_ms: _Optional[int] = ...) -> None: ...

class ScriptedStep(_message.Message):
    __slots__ = ("kind", "object_name", "target_name", "instruction")
    KIND_FIELD_NUMBER: _ClassVar[int]
    OBJECT_NAME_FIELD_NUMBER: _ClassVar[int]
    TARGET_NAME_FIELD_NUMBER: _ClassVar[int]
    INSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    kind: ScriptedDecisionKind
    object_name: str
    target_name: str
    instruction: str
    def __init__(self, kind: _Optional[_Union[ScriptedDecisionKind, str]] = ..., object_name: _Optional[str] = ..., target_name: _Optional[str] = ..., instruction: _Optional[str] = ...) -> None: ...

class ScriptedSource(_message.Message):
    __slots__ = ("steps", "replan_interval", "retry_budget")
    STEPS_FIELD_NUMBER: _ClassVar[int]
    REPLAN_INTERVAL_FIELD_NUMBER: _ClassVar[int]
    RETRY_BUDGET_FIELD_NUMBER: _ClassVar[int]
    steps: _containers.RepeatedCompositeFieldContainer[ScriptedStep]
    replan_interval: ReplanInterval
    retry_budget: int
    def __init__(self, steps: _Optional[_Iterable[_Union[ScriptedStep, _Mapping]]] = ..., replan_interval: _Optional[_Union[ReplanInterval, _Mapping]] = ..., retry_budget: _Optional[int] = ...) -> None: ...

class ScriptedGenerationSource(_message.Message):
    __slots__ = ("script",)
    SCRIPT_FIELD_NUMBER: _ClassVar[int]
    script: ScriptedSource
    def __init__(self, script: _Optional[_Union[ScriptedSource, _Mapping]] = ...) -> None: ...

class ApplicationGenerationSource(_message.Message):
    __slots__ = ("application_ref", "replan_horizon")
    APPLICATION_REF_FIELD_NUMBER: _ClassVar[int]
    REPLAN_HORIZON_FIELD_NUMBER: _ClassVar[int]
    application_ref: str
    replan_horizon: int
    def __init__(self, application_ref: _Optional[str] = ..., replan_horizon: _Optional[int] = ...) -> None: ...

class MimicGenSource(_message.Message):
    __slots__ = ("seed_segments", "position_jitter_m", "rotation_jitter_rad", "selection")
    SEED_SEGMENTS_FIELD_NUMBER: _ClassVar[int]
    POSITION_JITTER_M_FIELD_NUMBER: _ClassVar[int]
    ROTATION_JITTER_RAD_FIELD_NUMBER: _ClassVar[int]
    SELECTION_FIELD_NUMBER: _ClassVar[int]
    seed_segments: _containers.RepeatedCompositeFieldContainer[CatalogSegmentRef]
    position_jitter_m: float
    rotation_jitter_rad: float
    selection: SeedSelection
    def __init__(self, seed_segments: _Optional[_Iterable[_Union[CatalogSegmentRef, _Mapping]]] = ..., position_jitter_m: _Optional[float] = ..., rotation_jitter_rad: _Optional[float] = ..., selection: _Optional[_Union[SeedSelection, str]] = ...) -> None: ...

class AgenticSceneSource(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GenerationSource(_message.Message):
    __slots__ = ("scripted", "application", "mimicgen", "agentic")
    SCRIPTED_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_FIELD_NUMBER: _ClassVar[int]
    MIMICGEN_FIELD_NUMBER: _ClassVar[int]
    AGENTIC_FIELD_NUMBER: _ClassVar[int]
    scripted: ScriptedGenerationSource
    application: ApplicationGenerationSource
    mimicgen: MimicGenSource
    agentic: AgenticSceneSource
    def __init__(self, scripted: _Optional[_Union[ScriptedGenerationSource, _Mapping]] = ..., application: _Optional[_Union[ApplicationGenerationSource, _Mapping]] = ..., mimicgen: _Optional[_Union[MimicGenSource, _Mapping]] = ..., agentic: _Optional[_Union[AgenticSceneSource, _Mapping]] = ...) -> None: ...

class StartGenerationRequest(_message.Message):
    __slots__ = ("task", "simulator", "source", "count", "seed", "dataset", "world", "timeout")
    TASK_FIELD_NUMBER: _ClassVar[int]
    SIMULATOR_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    COUNT_FIELD_NUMBER: _ClassVar[int]
    SEED_FIELD_NUMBER: _ClassVar[int]
    DATASET_FIELD_NUMBER: _ClassVar[int]
    WORLD_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    task: _common_pb2.TaskContractRef
    simulator: Simulator
    source: GenerationSource
    count: int
    seed: int
    dataset: str
    world: str
    timeout: _duration_pb2.Duration
    def __init__(self, task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., simulator: _Optional[_Union[Simulator, str]] = ..., source: _Optional[_Union[GenerationSource, _Mapping]] = ..., count: _Optional[int] = ..., seed: _Optional[int] = ..., dataset: _Optional[str] = ..., world: _Optional[str] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class StartGenerationResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: WorldsOperation
    def __init__(self, operation: _Optional[_Union[WorldsOperation, _Mapping]] = ...) -> None: ...

class StartEnvironmentAuthoringRequest(_message.Message):
    __slots__ = ("pano_id", "name", "description", "prompt", "quality", "seed", "tags", "timeout")
    PANO_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    PROMPT_FIELD_NUMBER: _ClassVar[int]
    QUALITY_FIELD_NUMBER: _ClassVar[int]
    SEED_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    pano_id: str
    name: str
    description: str
    prompt: str
    quality: EnvironmentAuthoringQuality
    seed: int
    tags: _containers.RepeatedScalarFieldContainer[str]
    timeout: _duration_pb2.Duration
    def __init__(self, pano_id: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., prompt: _Optional[str] = ..., quality: _Optional[_Union[EnvironmentAuthoringQuality, str]] = ..., seed: _Optional[int] = ..., tags: _Optional[_Iterable[str]] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class StartEnvironmentAuthoringResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: WorldsOperation
    def __init__(self, operation: _Optional[_Union[WorldsOperation, _Mapping]] = ...) -> None: ...

class StartObjectAuthoringRequest(_message.Message):
    __slots__ = ("image_id", "name", "description", "category", "longest_dimension_m", "mass_kg", "quality", "seed", "tags", "timeout")
    IMAGE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    LONGEST_DIMENSION_M_FIELD_NUMBER: _ClassVar[int]
    MASS_KG_FIELD_NUMBER: _ClassVar[int]
    QUALITY_FIELD_NUMBER: _ClassVar[int]
    SEED_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    image_id: str
    name: str
    description: str
    category: str
    longest_dimension_m: float
    mass_kg: float
    quality: ObjectAuthoringQuality
    seed: int
    tags: _containers.RepeatedScalarFieldContainer[str]
    timeout: _duration_pb2.Duration
    def __init__(self, image_id: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., category: _Optional[str] = ..., longest_dimension_m: _Optional[float] = ..., mass_kg: _Optional[float] = ..., quality: _Optional[_Union[ObjectAuthoringQuality, str]] = ..., seed: _Optional[int] = ..., tags: _Optional[_Iterable[str]] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class StartObjectAuthoringResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: WorldsOperation
    def __init__(self, operation: _Optional[_Union[WorldsOperation, _Mapping]] = ...) -> None: ...

class StartArticulatedObjectAuthoringRequest(_message.Message):
    __slots__ = ("prompt", "name", "description", "category", "tags", "timeout")
    PROMPT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    prompt: str
    name: str
    description: str
    category: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    timeout: _duration_pb2.Duration
    def __init__(self, prompt: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., category: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class StartArticulatedObjectAuthoringResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: WorldsOperation
    def __init__(self, operation: _Optional[_Union[WorldsOperation, _Mapping]] = ...) -> None: ...

class StartRobotPartAuthoringRequest(_message.Message):
    __slots__ = ("part_id", "geometry_brief", "timeout")
    PART_ID_FIELD_NUMBER: _ClassVar[int]
    GEOMETRY_BRIEF_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    part_id: str
    geometry_brief: str
    timeout: _duration_pb2.Duration
    def __init__(self, part_id: _Optional[str] = ..., geometry_brief: _Optional[str] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class StartRobotPartAuthoringResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: WorldsOperation
    def __init__(self, operation: _Optional[_Union[WorldsOperation, _Mapping]] = ...) -> None: ...

class StartScanSeedRequest(_message.Message):
    __slots__ = ("scan_id", "timeout")
    SCAN_ID_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    scan_id: str
    timeout: _duration_pb2.Duration
    def __init__(self, scan_id: _Optional[str] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class StartScanSeedResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: WorldsOperation
    def __init__(self, operation: _Optional[_Union[WorldsOperation, _Mapping]] = ...) -> None: ...

class StartScanPublishRequest(_message.Message):
    __slots__ = ("scan_id", "name", "description", "tags", "timeout")
    SCAN_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    scan_id: str
    name: str
    description: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    timeout: _duration_pb2.Duration
    def __init__(self, scan_id: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class StartScanPublishResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: WorldsOperation
    def __init__(self, operation: _Optional[_Union[WorldsOperation, _Mapping]] = ...) -> None: ...

class TaskBindingObject(_message.Message):
    __slots__ = ("object_id", "object_head")
    OBJECT_ID_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HEAD_FIELD_NUMBER: _ClassVar[int]
    object_id: str
    object_head: str
    def __init__(self, object_id: _Optional[str] = ..., object_head: _Optional[str] = ...) -> None: ...

class PreviewTaskBindingRequest(_message.Message):
    __slots__ = ("canonical_json", "scene_ref", "objects")
    CANONICAL_JSON_FIELD_NUMBER: _ClassVar[int]
    SCENE_REF_FIELD_NUMBER: _ClassVar[int]
    OBJECTS_FIELD_NUMBER: _ClassVar[int]
    canonical_json: str
    scene_ref: str
    objects: _containers.RepeatedCompositeFieldContainer[TaskBindingObject]
    def __init__(self, canonical_json: _Optional[str] = ..., scene_ref: _Optional[str] = ..., objects: _Optional[_Iterable[_Union[TaskBindingObject, _Mapping]]] = ...) -> None: ...

class PreviewTaskBindingResponse(_message.Message):
    __slots__ = ("outcome", "summary", "missing_bindings", "recovery", "source_refs")
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    MISSING_BINDINGS_FIELD_NUMBER: _ClassVar[int]
    RECOVERY_FIELD_NUMBER: _ClassVar[int]
    SOURCE_REFS_FIELD_NUMBER: _ClassVar[int]
    outcome: TaskBindingOutcome
    summary: str
    missing_bindings: _containers.RepeatedScalarFieldContainer[str]
    recovery: _containers.RepeatedScalarFieldContainer[str]
    source_refs: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, outcome: _Optional[_Union[TaskBindingOutcome, str]] = ..., summary: _Optional[str] = ..., missing_bindings: _Optional[_Iterable[str]] = ..., recovery: _Optional[_Iterable[str]] = ..., source_refs: _Optional[_Iterable[str]] = ...) -> None: ...

class EvaluationProgress(_message.Message):
    __slots__ = ("completed_cases", "total_cases", "current_case")
    COMPLETED_CASES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_CASES_FIELD_NUMBER: _ClassVar[int]
    CURRENT_CASE_FIELD_NUMBER: _ClassVar[int]
    completed_cases: int
    total_cases: int
    current_case: str
    def __init__(self, completed_cases: _Optional[int] = ..., total_cases: _Optional[int] = ..., current_case: _Optional[str] = ...) -> None: ...

class GenerationProgress(_message.Message):
    __slots__ = ("completed_attempts", "total_attempts", "registered_episodes")
    COMPLETED_ATTEMPTS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ATTEMPTS_FIELD_NUMBER: _ClassVar[int]
    REGISTERED_EPISODES_FIELD_NUMBER: _ClassVar[int]
    completed_attempts: int
    total_attempts: int
    registered_episodes: int
    def __init__(self, completed_attempts: _Optional[int] = ..., total_attempts: _Optional[int] = ..., registered_episodes: _Optional[int] = ...) -> None: ...

class AuthoringProgress(_message.Message):
    __slots__ = ("stage", "completed_stages", "total_stages", "note")
    STAGE_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_STAGES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_STAGES_FIELD_NUMBER: _ClassVar[int]
    NOTE_FIELD_NUMBER: _ClassVar[int]
    stage: str
    completed_stages: int
    total_stages: int
    note: str
    def __init__(self, stage: _Optional[str] = ..., completed_stages: _Optional[int] = ..., total_stages: _Optional[int] = ..., note: _Optional[str] = ...) -> None: ...

class WorldsOperation(_message.Message):
    __slots__ = ("metadata", "lifecycle", "evaluation_progress", "generation_progress", "authoring_progress")
    METADATA_FIELD_NUMBER: _ClassVar[int]
    LIFECYCLE_FIELD_NUMBER: _ClassVar[int]
    EVALUATION_PROGRESS_FIELD_NUMBER: _ClassVar[int]
    GENERATION_PROGRESS_FIELD_NUMBER: _ClassVar[int]
    AUTHORING_PROGRESS_FIELD_NUMBER: _ClassVar[int]
    metadata: _operations_pb2.OperationMetadata
    lifecycle: _operations_pb2.OperationLifecycle
    evaluation_progress: EvaluationProgress
    generation_progress: GenerationProgress
    authoring_progress: AuthoringProgress
    def __init__(self, metadata: _Optional[_Union[_operations_pb2.OperationMetadata, _Mapping]] = ..., lifecycle: _Optional[_Union[_operations_pb2.OperationLifecycle, _Mapping]] = ..., evaluation_progress: _Optional[_Union[EvaluationProgress, _Mapping]] = ..., generation_progress: _Optional[_Union[GenerationProgress, _Mapping]] = ..., authoring_progress: _Optional[_Union[AuthoringProgress, _Mapping]] = ...) -> None: ...

class GetWorldsOperationRequest(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class GetWorldsOperationResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: WorldsOperation
    def __init__(self, operation: _Optional[_Union[WorldsOperation, _Mapping]] = ...) -> None: ...

class GetWorldsOperationUpdatesRequest(_message.Message):
    __slots__ = ("operation", "after_cursor", "limit", "wait_timeout")
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    AFTER_CURSOR_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    WAIT_TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    after_cursor: int
    limit: int
    wait_timeout: _duration_pb2.Duration
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., after_cursor: _Optional[int] = ..., limit: _Optional[int] = ..., wait_timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class WorldsOperationUpdatePage(_message.Message):
    __slots__ = ("updates", "next_cursor", "has_more")
    UPDATES_FIELD_NUMBER: _ClassVar[int]
    NEXT_CURSOR_FIELD_NUMBER: _ClassVar[int]
    HAS_MORE_FIELD_NUMBER: _ClassVar[int]
    updates: _containers.RepeatedCompositeFieldContainer[WorldsOperation]
    next_cursor: int
    has_more: bool
    def __init__(self, updates: _Optional[_Iterable[_Union[WorldsOperation, _Mapping]]] = ..., next_cursor: _Optional[int] = ..., has_more: _Optional[bool] = ...) -> None: ...

class GetWorldsOperationUpdatesResponse(_message.Message):
    __slots__ = ("page", "history_gap")
    PAGE_FIELD_NUMBER: _ClassVar[int]
    HISTORY_GAP_FIELD_NUMBER: _ClassVar[int]
    page: WorldsOperationUpdatePage
    history_gap: _operations_pb2.OperationHistoryGap
    def __init__(self, page: _Optional[_Union[WorldsOperationUpdatePage, _Mapping]] = ..., history_gap: _Optional[_Union[_operations_pb2.OperationHistoryGap, _Mapping]] = ...) -> None: ...

class WorldsOperationResult(_message.Message):
    __slots__ = ("environment", "object_asset", "scan_seed", "generation", "evaluation", "robot_part_candidate")
    ENVIRONMENT_FIELD_NUMBER: _ClassVar[int]
    OBJECT_ASSET_FIELD_NUMBER: _ClassVar[int]
    SCAN_SEED_FIELD_NUMBER: _ClassVar[int]
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    EVALUATION_FIELD_NUMBER: _ClassVar[int]
    ROBOT_PART_CANDIDATE_FIELD_NUMBER: _ClassVar[int]
    environment: EnvironmentBundle
    object_asset: ObjectAssetBundle
    scan_seed: ScanSeed
    generation: Generation
    evaluation: WorldEvaluation
    robot_part_candidate: RobotPartCandidate
    def __init__(self, environment: _Optional[_Union[EnvironmentBundle, _Mapping]] = ..., object_asset: _Optional[_Union[ObjectAssetBundle, _Mapping]] = ..., scan_seed: _Optional[_Union[ScanSeed, _Mapping]] = ..., generation: _Optional[_Union[Generation, _Mapping]] = ..., evaluation: _Optional[_Union[WorldEvaluation, _Mapping]] = ..., robot_part_candidate: _Optional[_Union[RobotPartCandidate, _Mapping]] = ...) -> None: ...

class GetWorldsOperationResultRequest(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ...) -> None: ...

class GetWorldsOperationResultResponse(_message.Message):
    __slots__ = ("result", "operation", "resource")
    RESULT_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    RESOURCE_FIELD_NUMBER: _ClassVar[int]
    result: WorldsOperationResult
    operation: _common_pb2.OperationRef
    resource: _common_pb2.ResourceRef
    def __init__(self, result: _Optional[_Union[WorldsOperationResult, _Mapping]] = ..., operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., resource: _Optional[_Union[_common_pb2.ResourceRef, _Mapping]] = ...) -> None: ...

class CancelWorldsOperationRequest(_message.Message):
    __slots__ = ("operation", "reason")
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    operation: _common_pb2.OperationRef
    reason: str
    def __init__(self, operation: _Optional[_Union[_common_pb2.OperationRef, _Mapping]] = ..., reason: _Optional[str] = ...) -> None: ...

class CancelWorldsOperationResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: WorldsOperation
    def __init__(self, operation: _Optional[_Union[WorldsOperation, _Mapping]] = ...) -> None: ...

class EnvironmentPlacement(_message.Message):
    __slots__ = ("quaternion_wxyz", "scale", "translation_xyz")
    QUATERNION_WXYZ_FIELD_NUMBER: _ClassVar[int]
    SCALE_FIELD_NUMBER: _ClassVar[int]
    TRANSLATION_XYZ_FIELD_NUMBER: _ClassVar[int]
    quaternion_wxyz: _containers.RepeatedScalarFieldContainer[float]
    scale: float
    translation_xyz: _containers.RepeatedScalarFieldContainer[float]
    def __init__(self, quaternion_wxyz: _Optional[_Iterable[float]] = ..., scale: _Optional[float] = ..., translation_xyz: _Optional[_Iterable[float]] = ...) -> None: ...

class EnvironmentFacts(_message.Message):
    __slots__ = ("source", "source_ref", "placement", "name", "description", "license_id", "tags", "source_uri")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    SOURCE_REF_FIELD_NUMBER: _ClassVar[int]
    PLACEMENT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    LICENSE_ID_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    SOURCE_URI_FIELD_NUMBER: _ClassVar[int]
    source: EnvironmentSource
    source_ref: str
    placement: EnvironmentPlacement
    name: str
    description: str
    license_id: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    source_uri: str
    def __init__(self, source: _Optional[_Union[EnvironmentSource, str]] = ..., source_ref: _Optional[str] = ..., placement: _Optional[_Union[EnvironmentPlacement, _Mapping]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., license_id: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., source_uri: _Optional[str] = ...) -> None: ...

class EnvironmentSettlement(_message.Message):
    __slots__ = ("mjcf_sha256", "geoms", "meshes", "steps", "engine")
    MJCF_SHA256_FIELD_NUMBER: _ClassVar[int]
    GEOMS_FIELD_NUMBER: _ClassVar[int]
    MESHES_FIELD_NUMBER: _ClassVar[int]
    STEPS_FIELD_NUMBER: _ClassVar[int]
    ENGINE_FIELD_NUMBER: _ClassVar[int]
    mjcf_sha256: str
    geoms: int
    meshes: int
    steps: int
    engine: str
    def __init__(self, mjcf_sha256: _Optional[str] = ..., geoms: _Optional[int] = ..., meshes: _Optional[int] = ..., steps: _Optional[int] = ..., engine: _Optional[str] = ...) -> None: ...

class EnvironmentBundle(_message.Message):
    __slots__ = ("environment_id", "assets", "facts", "settlement")
    ENVIRONMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ASSETS_FIELD_NUMBER: _ClassVar[int]
    FACTS_FIELD_NUMBER: _ClassVar[int]
    SETTLEMENT_FIELD_NUMBER: _ClassVar[int]
    environment_id: str
    assets: AssetClosure
    facts: EnvironmentFacts
    settlement: EnvironmentSettlement
    def __init__(self, environment_id: _Optional[str] = ..., assets: _Optional[_Union[AssetClosure, _Mapping]] = ..., facts: _Optional[_Union[EnvironmentFacts, _Mapping]] = ..., settlement: _Optional[_Union[EnvironmentSettlement, _Mapping]] = ...) -> None: ...

class ObjectBounds(_message.Message):
    __slots__ = ("center_xyz", "half_extents_xyz")
    CENTER_XYZ_FIELD_NUMBER: _ClassVar[int]
    HALF_EXTENTS_XYZ_FIELD_NUMBER: _ClassVar[int]
    center_xyz: _containers.RepeatedScalarFieldContainer[float]
    half_extents_xyz: _containers.RepeatedScalarFieldContainer[float]
    def __init__(self, center_xyz: _Optional[_Iterable[float]] = ..., half_extents_xyz: _Optional[_Iterable[float]] = ...) -> None: ...

class SceneArticulation(_message.Message):
    __slots__ = ("name", "joint", "kind", "lower", "upper", "home")
    NAME_FIELD_NUMBER: _ClassVar[int]
    JOINT_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    LOWER_FIELD_NUMBER: _ClassVar[int]
    UPPER_FIELD_NUMBER: _ClassVar[int]
    HOME_FIELD_NUMBER: _ClassVar[int]
    name: str
    joint: str
    kind: SceneJointKind
    lower: float
    upper: float
    home: float
    def __init__(self, name: _Optional[str] = ..., joint: _Optional[str] = ..., kind: _Optional[_Union[SceneJointKind, str]] = ..., lower: _Optional[float] = ..., upper: _Optional[float] = ..., home: _Optional[float] = ...) -> None: ...

class ObjectAssetFacts(_message.Message):
    __slots__ = ("source", "source_ref", "producer_model", "name", "description", "category", "license_id", "longest_dimension_m", "mass_kg", "bounds", "tags", "articulation")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    SOURCE_REF_FIELD_NUMBER: _ClassVar[int]
    PRODUCER_MODEL_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    LICENSE_ID_FIELD_NUMBER: _ClassVar[int]
    LONGEST_DIMENSION_M_FIELD_NUMBER: _ClassVar[int]
    MASS_KG_FIELD_NUMBER: _ClassVar[int]
    BOUNDS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    ARTICULATION_FIELD_NUMBER: _ClassVar[int]
    source: ObjectAssetSource
    source_ref: str
    producer_model: str
    name: str
    description: str
    category: str
    license_id: str
    longest_dimension_m: float
    mass_kg: float
    bounds: ObjectBounds
    tags: _containers.RepeatedScalarFieldContainer[str]
    articulation: _containers.RepeatedCompositeFieldContainer[SceneArticulation]
    def __init__(self, source: _Optional[_Union[ObjectAssetSource, str]] = ..., source_ref: _Optional[str] = ..., producer_model: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., category: _Optional[str] = ..., license_id: _Optional[str] = ..., longest_dimension_m: _Optional[float] = ..., mass_kg: _Optional[float] = ..., bounds: _Optional[_Union[ObjectBounds, _Mapping]] = ..., tags: _Optional[_Iterable[str]] = ..., articulation: _Optional[_Iterable[_Union[SceneArticulation, _Mapping]]] = ...) -> None: ...

class ObjectAssetSettlement(_message.Message):
    __slots__ = ("mjcf_sha256", "geoms", "collision_geoms", "meshes", "joints", "steps", "engine")
    MJCF_SHA256_FIELD_NUMBER: _ClassVar[int]
    GEOMS_FIELD_NUMBER: _ClassVar[int]
    COLLISION_GEOMS_FIELD_NUMBER: _ClassVar[int]
    MESHES_FIELD_NUMBER: _ClassVar[int]
    JOINTS_FIELD_NUMBER: _ClassVar[int]
    STEPS_FIELD_NUMBER: _ClassVar[int]
    ENGINE_FIELD_NUMBER: _ClassVar[int]
    mjcf_sha256: str
    geoms: int
    collision_geoms: int
    meshes: int
    joints: int
    steps: int
    engine: str
    def __init__(self, mjcf_sha256: _Optional[str] = ..., geoms: _Optional[int] = ..., collision_geoms: _Optional[int] = ..., meshes: _Optional[int] = ..., joints: _Optional[int] = ..., steps: _Optional[int] = ..., engine: _Optional[str] = ...) -> None: ...

class ObjectAssetBundle(_message.Message):
    __slots__ = ("object_asset_id", "assets", "facts", "settlement")
    OBJECT_ASSET_ID_FIELD_NUMBER: _ClassVar[int]
    ASSETS_FIELD_NUMBER: _ClassVar[int]
    FACTS_FIELD_NUMBER: _ClassVar[int]
    SETTLEMENT_FIELD_NUMBER: _ClassVar[int]
    object_asset_id: str
    assets: AssetClosure
    facts: ObjectAssetFacts
    settlement: ObjectAssetSettlement
    def __init__(self, object_asset_id: _Optional[str] = ..., assets: _Optional[_Union[AssetClosure, _Mapping]] = ..., facts: _Optional[_Union[ObjectAssetFacts, _Mapping]] = ..., settlement: _Optional[_Union[ObjectAssetSettlement, _Mapping]] = ...) -> None: ...

class SplatReport(_message.Message):
    __slots__ = ("psnr", "gaussians", "iterations")
    PSNR_FIELD_NUMBER: _ClassVar[int]
    GAUSSIANS_FIELD_NUMBER: _ClassVar[int]
    ITERATIONS_FIELD_NUMBER: _ClassVar[int]
    psnr: float
    gaussians: int
    iterations: int
    def __init__(self, psnr: _Optional[float] = ..., gaussians: _Optional[int] = ..., iterations: _Optional[int] = ...) -> None: ...

class ScanSeed(_message.Message):
    __slots__ = ("scan_id", "run_id", "objects", "stages", "splat")
    SCAN_ID_FIELD_NUMBER: _ClassVar[int]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    OBJECTS_FIELD_NUMBER: _ClassVar[int]
    STAGES_FIELD_NUMBER: _ClassVar[int]
    SPLAT_FIELD_NUMBER: _ClassVar[int]
    scan_id: str
    run_id: str
    objects: int
    stages: _containers.RepeatedScalarFieldContainer[str]
    splat: SplatReport
    def __init__(self, scan_id: _Optional[str] = ..., run_id: _Optional[str] = ..., objects: _Optional[int] = ..., stages: _Optional[_Iterable[str]] = ..., splat: _Optional[_Union[SplatReport, _Mapping]] = ...) -> None: ...

class Metric(_message.Message):
    __slots__ = ("name", "value")
    NAME_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    name: str
    value: float
    def __init__(self, name: _Optional[str] = ..., value: _Optional[float] = ...) -> None: ...

class MetricSet(_message.Message):
    __slots__ = ("metrics",)
    METRICS_FIELD_NUMBER: _ClassVar[int]
    metrics: _containers.RepeatedCompositeFieldContainer[Metric]
    def __init__(self, metrics: _Optional[_Iterable[_Union[Metric, _Mapping]]] = ...) -> None: ...

class EpisodeExecutionSummary(_message.Message):
    __slots__ = ("episode_id", "world_id", "actions", "duration_s", "end")
    EPISODE_ID_FIELD_NUMBER: _ClassVar[int]
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    ACTIONS_FIELD_NUMBER: _ClassVar[int]
    DURATION_S_FIELD_NUMBER: _ClassVar[int]
    END_FIELD_NUMBER: _ClassVar[int]
    episode_id: str
    world_id: str
    actions: int
    duration_s: float
    end: _outcomes_pb2.EpisodeEnd
    def __init__(self, episode_id: _Optional[str] = ..., world_id: _Optional[str] = ..., actions: _Optional[int] = ..., duration_s: _Optional[float] = ..., end: _Optional[_Union[_outcomes_pb2.EpisodeEnd, _Mapping]] = ...) -> None: ...

class CatalogSegmentRef(_message.Message):
    __slots__ = ("dataset_id", "segment_id", "base_sha256")
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_ID_FIELD_NUMBER: _ClassVar[int]
    BASE_SHA256_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    segment_id: str
    base_sha256: str
    def __init__(self, dataset_id: _Optional[str] = ..., segment_id: _Optional[str] = ..., base_sha256: _Optional[str] = ...) -> None: ...

class GenerationAttempt(_message.Message):
    __slots__ = ("index", "segment", "summary", "measurements")
    INDEX_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    MEASUREMENTS_FIELD_NUMBER: _ClassVar[int]
    index: int
    segment: CatalogSegmentRef
    summary: EpisodeExecutionSummary
    measurements: MetricSet
    def __init__(self, index: _Optional[int] = ..., segment: _Optional[_Union[CatalogSegmentRef, _Mapping]] = ..., summary: _Optional[_Union[EpisodeExecutionSummary, _Mapping]] = ..., measurements: _Optional[_Union[MetricSet, _Mapping]] = ...) -> None: ...

class GenerationRejection(_message.Message):
    __slots__ = ("index", "reason", "detail")
    INDEX_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    DETAIL_FIELD_NUMBER: _ClassVar[int]
    index: int
    reason: GenerationRejectionReason
    detail: str
    def __init__(self, index: _Optional[int] = ..., reason: _Optional[_Union[GenerationRejectionReason, str]] = ..., detail: _Optional[str] = ...) -> None: ...

class MujocoEngineConfig(_message.Message):
    __slots__ = ("runtime_version", "timestep_s", "control_substeps", "integrator", "solver", "iterations", "line_search_iterations", "tolerance", "render_backend", "render_width", "render_height", "render_samples")
    RUNTIME_VERSION_FIELD_NUMBER: _ClassVar[int]
    TIMESTEP_S_FIELD_NUMBER: _ClassVar[int]
    CONTROL_SUBSTEPS_FIELD_NUMBER: _ClassVar[int]
    INTEGRATOR_FIELD_NUMBER: _ClassVar[int]
    SOLVER_FIELD_NUMBER: _ClassVar[int]
    ITERATIONS_FIELD_NUMBER: _ClassVar[int]
    LINE_SEARCH_ITERATIONS_FIELD_NUMBER: _ClassVar[int]
    TOLERANCE_FIELD_NUMBER: _ClassVar[int]
    RENDER_BACKEND_FIELD_NUMBER: _ClassVar[int]
    RENDER_WIDTH_FIELD_NUMBER: _ClassVar[int]
    RENDER_HEIGHT_FIELD_NUMBER: _ClassVar[int]
    RENDER_SAMPLES_FIELD_NUMBER: _ClassVar[int]
    runtime_version: str
    timestep_s: float
    control_substeps: int
    integrator: MujocoIntegrator
    solver: MujocoSolver
    iterations: int
    line_search_iterations: int
    tolerance: float
    render_backend: RenderBackend
    render_width: int
    render_height: int
    render_samples: int
    def __init__(self, runtime_version: _Optional[str] = ..., timestep_s: _Optional[float] = ..., control_substeps: _Optional[int] = ..., integrator: _Optional[_Union[MujocoIntegrator, str]] = ..., solver: _Optional[_Union[MujocoSolver, str]] = ..., iterations: _Optional[int] = ..., line_search_iterations: _Optional[int] = ..., tolerance: _Optional[float] = ..., render_backend: _Optional[_Union[RenderBackend, str]] = ..., render_width: _Optional[int] = ..., render_height: _Optional[int] = ..., render_samples: _Optional[int] = ...) -> None: ...

class EngineConfig(_message.Message):
    __slots__ = ("mujoco",)
    MUJOCO_FIELD_NUMBER: _ClassVar[int]
    mujoco: MujocoEngineConfig
    def __init__(self, mujoco: _Optional[_Union[MujocoEngineConfig, _Mapping]] = ...) -> None: ...

class ExecutionVenue(_message.Message):
    __slots__ = ("worker", "operating_system", "architecture", "accelerator", "driver", "cuda", "memory_bytes", "station_target")
    WORKER_FIELD_NUMBER: _ClassVar[int]
    OPERATING_SYSTEM_FIELD_NUMBER: _ClassVar[int]
    ARCHITECTURE_FIELD_NUMBER: _ClassVar[int]
    ACCELERATOR_FIELD_NUMBER: _ClassVar[int]
    DRIVER_FIELD_NUMBER: _ClassVar[int]
    CUDA_FIELD_NUMBER: _ClassVar[int]
    MEMORY_BYTES_FIELD_NUMBER: _ClassVar[int]
    STATION_TARGET_FIELD_NUMBER: _ClassVar[int]
    worker: str
    operating_system: str
    architecture: str
    accelerator: str
    driver: str
    cuda: str
    memory_bytes: int
    station_target: _stations_pb2.StationTarget
    def __init__(self, worker: _Optional[str] = ..., operating_system: _Optional[str] = ..., architecture: _Optional[str] = ..., accelerator: _Optional[str] = ..., driver: _Optional[str] = ..., cuda: _Optional[str] = ..., memory_bytes: _Optional[int] = ..., station_target: _Optional[_Union[_stations_pb2.StationTarget, _Mapping]] = ...) -> None: ...

class PythonRuntime(_message.Message):
    __slots__ = ("name", "python", "lock_sha256")
    NAME_FIELD_NUMBER: _ClassVar[int]
    PYTHON_FIELD_NUMBER: _ClassVar[int]
    LOCK_SHA256_FIELD_NUMBER: _ClassVar[int]
    name: str
    python: str
    lock_sha256: str
    def __init__(self, name: _Optional[str] = ..., python: _Optional[str] = ..., lock_sha256: _Optional[str] = ...) -> None: ...

class BoundImage(_message.Message):
    __slots__ = ("name", "digest")
    NAME_FIELD_NUMBER: _ClassVar[int]
    DIGEST_FIELD_NUMBER: _ClassVar[int]
    name: str
    digest: str
    def __init__(self, name: _Optional[str] = ..., digest: _Optional[str] = ...) -> None: ...

class GenerationRuntime(_message.Message):
    __slots__ = ("python", "image")
    PYTHON_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    python: PythonRuntime
    image: BoundImage
    def __init__(self, python: _Optional[_Union[PythonRuntime, _Mapping]] = ..., image: _Optional[_Union[BoundImage, _Mapping]] = ...) -> None: ...

class Generation(_message.Message):
    __slots__ = ("world_id", "source", "base_seed", "requested_count", "destination_dataset", "attempts", "runtime", "engine_config", "venue", "rejections", "generation_id")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    BASE_SEED_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_COUNT_FIELD_NUMBER: _ClassVar[int]
    DESTINATION_DATASET_FIELD_NUMBER: _ClassVar[int]
    ATTEMPTS_FIELD_NUMBER: _ClassVar[int]
    RUNTIME_FIELD_NUMBER: _ClassVar[int]
    ENGINE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    VENUE_FIELD_NUMBER: _ClassVar[int]
    REJECTIONS_FIELD_NUMBER: _ClassVar[int]
    GENERATION_ID_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    source: GenerationSource
    base_seed: int
    requested_count: int
    destination_dataset: str
    attempts: _containers.RepeatedCompositeFieldContainer[GenerationAttempt]
    runtime: GenerationRuntime
    engine_config: EngineConfig
    venue: ExecutionVenue
    rejections: _containers.RepeatedCompositeFieldContainer[GenerationRejection]
    generation_id: str
    def __init__(self, world_id: _Optional[str] = ..., source: _Optional[_Union[GenerationSource, _Mapping]] = ..., base_seed: _Optional[int] = ..., requested_count: _Optional[int] = ..., destination_dataset: _Optional[str] = ..., attempts: _Optional[_Iterable[_Union[GenerationAttempt, _Mapping]]] = ..., runtime: _Optional[_Union[GenerationRuntime, _Mapping]] = ..., engine_config: _Optional[_Union[EngineConfig, _Mapping]] = ..., venue: _Optional[_Union[ExecutionVenue, _Mapping]] = ..., rejections: _Optional[_Iterable[_Union[GenerationRejection, _Mapping]]] = ..., generation_id: _Optional[str] = ...) -> None: ...

class EvaluationVerdict(_message.Message):
    __slots__ = ("passed", "score", "threshold", "metrics")
    PASSED_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    THRESHOLD_FIELD_NUMBER: _ClassVar[int]
    METRICS_FIELD_NUMBER: _ClassVar[int]
    passed: bool
    score: float
    threshold: float
    metrics: MetricSet
    def __init__(self, passed: _Optional[bool] = ..., score: _Optional[float] = ..., threshold: _Optional[float] = ..., metrics: _Optional[_Union[MetricSet, _Mapping]] = ...) -> None: ...

class EvaluationCase(_message.Message):
    __slots__ = ("task_id", "stratum", "trial", "seed", "success", "reason", "steps", "evidence_segment", "refusal")
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    STRATUM_FIELD_NUMBER: _ClassVar[int]
    TRIAL_FIELD_NUMBER: _ClassVar[int]
    SEED_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    STEPS_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_SEGMENT_FIELD_NUMBER: _ClassVar[int]
    REFUSAL_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    stratum: str
    trial: int
    seed: int
    success: bool
    reason: _outcomes_pb2.TerminationReason
    steps: int
    evidence_segment: str
    refusal: str
    def __init__(self, task_id: _Optional[str] = ..., stratum: _Optional[str] = ..., trial: _Optional[int] = ..., seed: _Optional[int] = ..., success: _Optional[bool] = ..., reason: _Optional[_Union[_outcomes_pb2.TerminationReason, str]] = ..., steps: _Optional[int] = ..., evidence_segment: _Optional[str] = ..., refusal: _Optional[str] = ...) -> None: ...

class DoorLocalEvidence(_message.Message):
    __slots__ = ("evaluation_id",)
    EVALUATION_ID_FIELD_NUMBER: _ClassVar[int]
    evaluation_id: str
    def __init__(self, evaluation_id: _Optional[str] = ...) -> None: ...

class EvaluationEvidence(_message.Message):
    __slots__ = ("canonical_run", "door_local")
    CANONICAL_RUN_FIELD_NUMBER: _ClassVar[int]
    DOOR_LOCAL_FIELD_NUMBER: _ClassVar[int]
    canonical_run: _common_pb2.ContentRef
    door_local: DoorLocalEvidence
    def __init__(self, canonical_run: _Optional[_Union[_common_pb2.ContentRef, _Mapping]] = ..., door_local: _Optional[_Union[DoorLocalEvidence, _Mapping]] = ...) -> None: ...

class EvaluatedSubject(_message.Message):
    __slots__ = ("application_ref", "artifact", "zero_action")
    APPLICATION_REF_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_FIELD_NUMBER: _ClassVar[int]
    ZERO_ACTION_FIELD_NUMBER: _ClassVar[int]
    application_ref: str
    artifact: PolicyArtifactSubject
    zero_action: ZeroActionSubject
    def __init__(self, application_ref: _Optional[str] = ..., artifact: _Optional[_Union[PolicyArtifactSubject, _Mapping]] = ..., zero_action: _Optional[_Union[ZeroActionSubject, _Mapping]] = ...) -> None: ...

class WorldEvaluation(_message.Message):
    __slots__ = ("task", "subject", "verdict", "evidence", "cases", "evidence_segments")
    TASK_FIELD_NUMBER: _ClassVar[int]
    SUBJECT_FIELD_NUMBER: _ClassVar[int]
    VERDICT_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_FIELD_NUMBER: _ClassVar[int]
    CASES_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_SEGMENTS_FIELD_NUMBER: _ClassVar[int]
    task: _common_pb2.TaskContractRef
    subject: EvaluatedSubject
    verdict: EvaluationVerdict
    evidence: EvaluationEvidence
    cases: _containers.RepeatedCompositeFieldContainer[EvaluationCase]
    evidence_segments: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., subject: _Optional[_Union[EvaluatedSubject, _Mapping]] = ..., verdict: _Optional[_Union[EvaluationVerdict, _Mapping]] = ..., evidence: _Optional[_Union[EvaluationEvidence, _Mapping]] = ..., cases: _Optional[_Iterable[_Union[EvaluationCase, _Mapping]]] = ..., evidence_segments: _Optional[_Iterable[str]] = ...) -> None: ...

class GetEvaluationRequest(_message.Message):
    __slots__ = ("evaluation_id",)
    EVALUATION_ID_FIELD_NUMBER: _ClassVar[int]
    evaluation_id: str
    def __init__(self, evaluation_id: _Optional[str] = ...) -> None: ...

class GetEvaluationResponse(_message.Message):
    __slots__ = ("evaluation", "evaluation_id")
    EVALUATION_FIELD_NUMBER: _ClassVar[int]
    EVALUATION_ID_FIELD_NUMBER: _ClassVar[int]
    evaluation: WorldEvaluation
    evaluation_id: str
    def __init__(self, evaluation: _Optional[_Union[WorldEvaluation, _Mapping]] = ..., evaluation_id: _Optional[str] = ...) -> None: ...

class GetEnvironmentAuthoringRequest(_message.Message):
    __slots__ = ("authoring_id",)
    AUTHORING_ID_FIELD_NUMBER: _ClassVar[int]
    authoring_id: str
    def __init__(self, authoring_id: _Optional[str] = ...) -> None: ...

class GetEnvironmentAuthoringResponse(_message.Message):
    __slots__ = ("environment",)
    ENVIRONMENT_FIELD_NUMBER: _ClassVar[int]
    environment: EnvironmentBundle
    def __init__(self, environment: _Optional[_Union[EnvironmentBundle, _Mapping]] = ...) -> None: ...

class GetObjectAuthoringRequest(_message.Message):
    __slots__ = ("authoring_id",)
    AUTHORING_ID_FIELD_NUMBER: _ClassVar[int]
    authoring_id: str
    def __init__(self, authoring_id: _Optional[str] = ...) -> None: ...

class GetObjectAuthoringResponse(_message.Message):
    __slots__ = ("object_asset",)
    OBJECT_ASSET_FIELD_NUMBER: _ClassVar[int]
    object_asset: ObjectAssetBundle
    def __init__(self, object_asset: _Optional[_Union[ObjectAssetBundle, _Mapping]] = ...) -> None: ...

class RobotPartCandidate(_message.Message):
    __slots__ = ("candidate_id", "canonical_json")
    CANDIDATE_ID_FIELD_NUMBER: _ClassVar[int]
    CANONICAL_JSON_FIELD_NUMBER: _ClassVar[int]
    candidate_id: str
    canonical_json: bytes
    def __init__(self, candidate_id: _Optional[str] = ..., canonical_json: _Optional[bytes] = ...) -> None: ...

class GetRobotPartAuthoringRequest(_message.Message):
    __slots__ = ("authoring_id",)
    AUTHORING_ID_FIELD_NUMBER: _ClassVar[int]
    authoring_id: str
    def __init__(self, authoring_id: _Optional[str] = ...) -> None: ...

class GetRobotPartAuthoringResponse(_message.Message):
    __slots__ = ("candidate",)
    CANDIDATE_FIELD_NUMBER: _ClassVar[int]
    candidate: RobotPartCandidate
    def __init__(self, candidate: _Optional[_Union[RobotPartCandidate, _Mapping]] = ...) -> None: ...

class GetGenerationRequest(_message.Message):
    __slots__ = ("generation_id",)
    GENERATION_ID_FIELD_NUMBER: _ClassVar[int]
    generation_id: str
    def __init__(self, generation_id: _Optional[str] = ...) -> None: ...

class GetGenerationResponse(_message.Message):
    __slots__ = ("generation", "canonical_json")
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    CANONICAL_JSON_FIELD_NUMBER: _ClassVar[int]
    generation: Generation
    canonical_json: str
    def __init__(self, generation: _Optional[_Union[Generation, _Mapping]] = ..., canonical_json: _Optional[str] = ...) -> None: ...

class ListEnvironmentsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListEnvironmentsResponse(_message.Message):
    __slots__ = ("environments",)
    ENVIRONMENTS_FIELD_NUMBER: _ClassVar[int]
    environments: _containers.RepeatedCompositeFieldContainer[EnvironmentBundle]
    def __init__(self, environments: _Optional[_Iterable[_Union[EnvironmentBundle, _Mapping]]] = ...) -> None: ...

class SceneDocument(_message.Message):
    __slots__ = ("canonical_json",)
    CANONICAL_JSON_FIELD_NUMBER: _ClassVar[int]
    canonical_json: str
    def __init__(self, canonical_json: _Optional[str] = ...) -> None: ...

class ListScenesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListScenesResponse(_message.Message):
    __slots__ = ("scenes", "request")
    SCENES_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    scenes: _containers.RepeatedCompositeFieldContainer[SceneDocument]
    request: ListScenesRequest
    def __init__(self, scenes: _Optional[_Iterable[_Union[SceneDocument, _Mapping]]] = ..., request: _Optional[_Union[ListScenesRequest, _Mapping]] = ...) -> None: ...

class ListObjectAssetsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListObjectAssetsResponse(_message.Message):
    __slots__ = ("object_assets",)
    OBJECT_ASSETS_FIELD_NUMBER: _ClassVar[int]
    object_assets: _containers.RepeatedCompositeFieldContainer[ObjectAssetBundle]
    def __init__(self, object_assets: _Optional[_Iterable[_Union[ObjectAssetBundle, _Mapping]]] = ...) -> None: ...

class ListSimulationRunsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListSimulationRunsResponse(_message.Message):
    __slots__ = ("runs",)
    RUNS_FIELD_NUMBER: _ClassVar[int]
    runs: _containers.RepeatedCompositeFieldContainer[WorldsOperation]
    def __init__(self, runs: _Optional[_Iterable[_Union[WorldsOperation, _Mapping]]] = ...) -> None: ...

class SimulatorCapability(_message.Message):
    __slots__ = ("simulator", "job", "resource_band", "available", "reason")
    SIMULATOR_FIELD_NUMBER: _ClassVar[int]
    JOB_FIELD_NUMBER: _ClassVar[int]
    RESOURCE_BAND_FIELD_NUMBER: _ClassVar[int]
    AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    simulator: Simulator
    job: SimulationJobFamily
    resource_band: SimulationResourceBand
    available: bool
    reason: str
    def __init__(self, simulator: _Optional[_Union[Simulator, str]] = ..., job: _Optional[_Union[SimulationJobFamily, str]] = ..., resource_band: _Optional[_Union[SimulationResourceBand, str]] = ..., available: _Optional[bool] = ..., reason: _Optional[str] = ...) -> None: ...

class ListSimulatorsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListSimulatorsResponse(_message.Message):
    __slots__ = ("simulators",)
    SIMULATORS_FIELD_NUMBER: _ClassVar[int]
    simulators: _containers.RepeatedCompositeFieldContainer[SimulatorCapability]
    def __init__(self, simulators: _Optional[_Iterable[_Union[SimulatorCapability, _Mapping]]] = ...) -> None: ...

class WorldSessionClose(_message.Message):
    __slots__ = ("success", "steps", "episode_segment", "reason")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    STEPS_FIELD_NUMBER: _ClassVar[int]
    EPISODE_SEGMENT_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    success: bool
    steps: int
    episode_segment: str
    reason: str
    def __init__(self, success: _Optional[bool] = ..., steps: _Optional[int] = ..., episode_segment: _Optional[str] = ..., reason: _Optional[str] = ...) -> None: ...

class WorldSessionFailure(_message.Message):
    __slots__ = ("code", "message", "retryable")
    CODE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    RETRYABLE_FIELD_NUMBER: _ClassVar[int]
    code: str
    message: str
    retryable: bool
    def __init__(self, code: _Optional[str] = ..., message: _Optional[str] = ..., retryable: _Optional[bool] = ...) -> None: ...

class WorldSession(_message.Message):
    __slots__ = ("session_id", "task", "simulator", "engine_config_id", "allocation_ref", "operation_ref", "state", "expires_at", "observation_sequence", "tools", "evidence_refs", "usage_ref", "close", "failure")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_FIELD_NUMBER: _ClassVar[int]
    SIMULATOR_FIELD_NUMBER: _ClassVar[int]
    ENGINE_CONFIG_ID_FIELD_NUMBER: _ClassVar[int]
    ALLOCATION_REF_FIELD_NUMBER: _ClassVar[int]
    OPERATION_REF_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    OBSERVATION_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    TOOLS_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_REFS_FIELD_NUMBER: _ClassVar[int]
    USAGE_REF_FIELD_NUMBER: _ClassVar[int]
    CLOSE_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    task: _common_pb2.TaskContractRef
    simulator: Simulator
    engine_config_id: str
    allocation_ref: str
    operation_ref: str
    state: WorldSessionState
    expires_at: _timestamp_pb2.Timestamp
    observation_sequence: int
    tools: _containers.RepeatedScalarFieldContainer[str]
    evidence_refs: _containers.RepeatedScalarFieldContainer[str]
    usage_ref: str
    close: WorldSessionClose
    failure: WorldSessionFailure
    def __init__(self, session_id: _Optional[str] = ..., task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., simulator: _Optional[_Union[Simulator, str]] = ..., engine_config_id: _Optional[str] = ..., allocation_ref: _Optional[str] = ..., operation_ref: _Optional[str] = ..., state: _Optional[_Union[WorldSessionState, str]] = ..., expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., observation_sequence: _Optional[int] = ..., tools: _Optional[_Iterable[str]] = ..., evidence_refs: _Optional[_Iterable[str]] = ..., usage_ref: _Optional[str] = ..., close: _Optional[_Union[WorldSessionClose, _Mapping]] = ..., failure: _Optional[_Union[WorldSessionFailure, _Mapping]] = ...) -> None: ...

class OpenSessionRequest(_message.Message):
    __slots__ = ("task", "simulator", "seed", "ttl_seconds")
    TASK_FIELD_NUMBER: _ClassVar[int]
    SIMULATOR_FIELD_NUMBER: _ClassVar[int]
    SEED_FIELD_NUMBER: _ClassVar[int]
    TTL_SECONDS_FIELD_NUMBER: _ClassVar[int]
    task: _common_pb2.TaskContractRef
    simulator: Simulator
    seed: int
    ttl_seconds: int
    def __init__(self, task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., simulator: _Optional[_Union[Simulator, str]] = ..., seed: _Optional[int] = ..., ttl_seconds: _Optional[int] = ...) -> None: ...

class OpenSessionResponse(_message.Message):
    __slots__ = ("session",)
    SESSION_FIELD_NUMBER: _ClassVar[int]
    session: WorldSession
    def __init__(self, session: _Optional[_Union[WorldSession, _Mapping]] = ...) -> None: ...

class ListSessionsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListSessionsResponse(_message.Message):
    __slots__ = ("sessions",)
    SESSIONS_FIELD_NUMBER: _ClassVar[int]
    sessions: _containers.RepeatedCompositeFieldContainer[WorldSession]
    def __init__(self, sessions: _Optional[_Iterable[_Union[WorldSession, _Mapping]]] = ...) -> None: ...

class GetSessionRequest(_message.Message):
    __slots__ = ("session_id",)
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    def __init__(self, session_id: _Optional[str] = ...) -> None: ...

class GetSessionResponse(_message.Message):
    __slots__ = ("session",)
    SESSION_FIELD_NUMBER: _ClassVar[int]
    session: WorldSession
    def __init__(self, session: _Optional[_Union[WorldSession, _Mapping]] = ...) -> None: ...

class StepSessionRequest(_message.Message):
    __slots__ = ("session_id", "step_id", "expected_observation_sequence", "tool", "arguments")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    STEP_ID_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_OBSERVATION_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    TOOL_FIELD_NUMBER: _ClassVar[int]
    ARGUMENTS_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    step_id: str
    expected_observation_sequence: int
    tool: str
    arguments: _struct_pb2.Struct
    def __init__(self, session_id: _Optional[str] = ..., step_id: _Optional[str] = ..., expected_observation_sequence: _Optional[int] = ..., tool: _Optional[str] = ..., arguments: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class SessionJsonResult(_message.Message):
    __slots__ = ("value",)
    VALUE_FIELD_NUMBER: _ClassVar[int]
    value: _struct_pb2.Value
    def __init__(self, value: _Optional[_Union[_struct_pb2.Value, _Mapping]] = ...) -> None: ...

class SessionImageResult(_message.Message):
    __slots__ = ("dtype", "shape", "png")
    DTYPE_FIELD_NUMBER: _ClassVar[int]
    SHAPE_FIELD_NUMBER: _ClassVar[int]
    PNG_FIELD_NUMBER: _ClassVar[int]
    dtype: str
    shape: _containers.RepeatedScalarFieldContainer[int]
    png: bytes
    def __init__(self, dtype: _Optional[str] = ..., shape: _Optional[_Iterable[int]] = ..., png: _Optional[bytes] = ...) -> None: ...

class SessionStepResult(_message.Message):
    __slots__ = ("json", "image")
    JSON_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    json: SessionJsonResult
    image: SessionImageResult
    def __init__(self, json: _Optional[_Union[SessionJsonResult, _Mapping]] = ..., image: _Optional[_Union[SessionImageResult, _Mapping]] = ...) -> None: ...

class StepSessionResponse(_message.Message):
    __slots__ = ("step_id", "previous_observation_sequence", "observation_sequence", "replayed", "result", "request")
    STEP_ID_FIELD_NUMBER: _ClassVar[int]
    PREVIOUS_OBSERVATION_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    OBSERVATION_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    REPLAYED_FIELD_NUMBER: _ClassVar[int]
    RESULT_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    step_id: str
    previous_observation_sequence: int
    observation_sequence: int
    replayed: bool
    result: SessionStepResult
    request: StepSessionRequest
    def __init__(self, step_id: _Optional[str] = ..., previous_observation_sequence: _Optional[int] = ..., observation_sequence: _Optional[int] = ..., replayed: _Optional[bool] = ..., result: _Optional[_Union[SessionStepResult, _Mapping]] = ..., request: _Optional[_Union[StepSessionRequest, _Mapping]] = ...) -> None: ...

class SessionEffectIdentity(_message.Message):
    __slots__ = ("effect_id", "request_sha256")
    EFFECT_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_SHA256_FIELD_NUMBER: _ClassVar[int]
    effect_id: str
    request_sha256: str
    def __init__(self, effect_id: _Optional[str] = ..., request_sha256: _Optional[str] = ...) -> None: ...

class SessionDecisionIdentity(_message.Message):
    __slots__ = ("environment_generation", "effect", "goal_id", "goal_revision", "decision_id")
    ENVIRONMENT_GENERATION_FIELD_NUMBER: _ClassVar[int]
    EFFECT_FIELD_NUMBER: _ClassVar[int]
    GOAL_ID_FIELD_NUMBER: _ClassVar[int]
    GOAL_REVISION_FIELD_NUMBER: _ClassVar[int]
    DECISION_ID_FIELD_NUMBER: _ClassVar[int]
    environment_generation: int
    effect: SessionEffectIdentity
    goal_id: str
    goal_revision: int
    decision_id: str
    def __init__(self, environment_generation: _Optional[int] = ..., effect: _Optional[_Union[SessionEffectIdentity, _Mapping]] = ..., goal_id: _Optional[str] = ..., goal_revision: _Optional[int] = ..., decision_id: _Optional[str] = ...) -> None: ...

class VerifySessionRequest(_message.Message):
    __slots__ = ("session_id", "decision")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    DECISION_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    decision: SessionDecisionIdentity
    def __init__(self, session_id: _Optional[str] = ..., decision: _Optional[_Union[SessionDecisionIdentity, _Mapping]] = ...) -> None: ...

class SessionVerifier(_message.Message):
    __slots__ = ("name", "version")
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    name: str
    version: str
    def __init__(self, name: _Optional[str] = ..., version: _Optional[str] = ...) -> None: ...

class SessionVerificationEvidence(_message.Message):
    __slots__ = ("session_id", "task", "state")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    task: _common_pb2.TaskContractRef
    state: WorldSessionState
    def __init__(self, session_id: _Optional[str] = ..., task: _Optional[_Union[_common_pb2.TaskContractRef, _Mapping]] = ..., state: _Optional[_Union[WorldSessionState, str]] = ...) -> None: ...

class VerifySessionResponse(_message.Message):
    __slots__ = ("schema", "decision", "status", "summary", "observation_sequence", "verifier", "evidence")
    SCHEMA_FIELD_NUMBER: _ClassVar[int]
    DECISION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    OBSERVATION_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    VERIFIER_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_FIELD_NUMBER: _ClassVar[int]
    schema: str
    decision: SessionDecisionIdentity
    status: SessionVerificationStatus
    summary: str
    observation_sequence: int
    verifier: SessionVerifier
    evidence: SessionVerificationEvidence
    def __init__(self, schema: _Optional[str] = ..., decision: _Optional[_Union[SessionDecisionIdentity, _Mapping]] = ..., status: _Optional[_Union[SessionVerificationStatus, str]] = ..., summary: _Optional[str] = ..., observation_sequence: _Optional[int] = ..., verifier: _Optional[_Union[SessionVerifier, _Mapping]] = ..., evidence: _Optional[_Union[SessionVerificationEvidence, _Mapping]] = ...) -> None: ...

class CloseSessionRequest(_message.Message):
    __slots__ = ("session_id",)
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    def __init__(self, session_id: _Optional[str] = ...) -> None: ...

class CloseSessionResponse(_message.Message):
    __slots__ = ("session",)
    SESSION_FIELD_NUMBER: _ClassVar[int]
    session: WorldSession
    def __init__(self, session: _Optional[_Union[WorldSession, _Mapping]] = ...) -> None: ...
