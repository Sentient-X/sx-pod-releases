from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CpuArchitecture(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CPU_ARCHITECTURE_UNSPECIFIED: _ClassVar[CpuArchitecture]
    CPU_ARCHITECTURE_X86_64: _ClassVar[CpuArchitecture]
    CPU_ARCHITECTURE_AARCH64: _ClassVar[CpuArchitecture]

class Accelerator(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ACCELERATOR_UNSPECIFIED: _ClassVar[Accelerator]
    ACCELERATOR_RTX_5090: _ClassVar[Accelerator]
    ACCELERATOR_DGX_SPARK_GB10: _ClassVar[Accelerator]
    ACCELERATOR_JETSON_THOR_T5000: _ClassVar[Accelerator]
    ACCELERATOR_ROCKCHIP_RK3588_NPU: _ClassVar[Accelerator]
CPU_ARCHITECTURE_UNSPECIFIED: CpuArchitecture
CPU_ARCHITECTURE_X86_64: CpuArchitecture
CPU_ARCHITECTURE_AARCH64: CpuArchitecture
ACCELERATOR_UNSPECIFIED: Accelerator
ACCELERATOR_RTX_5090: Accelerator
ACCELERATOR_DGX_SPARK_GB10: Accelerator
ACCELERATOR_JETSON_THOR_T5000: Accelerator
ACCELERATOR_ROCKCHIP_RK3588_NPU: Accelerator

class StationTarget(_message.Message):
    __slots__ = ("cpu", "accelerator", "minimum_memory_mib", "runtime_abi", "power_mode")
    CPU_FIELD_NUMBER: _ClassVar[int]
    ACCELERATOR_FIELD_NUMBER: _ClassVar[int]
    MINIMUM_MEMORY_MIB_FIELD_NUMBER: _ClassVar[int]
    RUNTIME_ABI_FIELD_NUMBER: _ClassVar[int]
    POWER_MODE_FIELD_NUMBER: _ClassVar[int]
    cpu: CpuArchitecture
    accelerator: Accelerator
    minimum_memory_mib: int
    runtime_abi: str
    power_mode: str
    def __init__(self, cpu: _Optional[_Union[CpuArchitecture, str]] = ..., accelerator: _Optional[_Union[Accelerator, str]] = ..., minimum_memory_mib: _Optional[int] = ..., runtime_abi: _Optional[str] = ..., power_mode: _Optional[str] = ...) -> None: ...
