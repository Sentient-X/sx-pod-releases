from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class AssetFormat(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ASSET_FORMAT_UNSPECIFIED: _ClassVar[AssetFormat]
    ASSET_FORMAT_URDF: _ClassVar[AssetFormat]
    ASSET_FORMAT_SRDF: _ClassVar[AssetFormat]
    ASSET_FORMAT_MJCF: _ClassVar[AssetFormat]
    ASSET_FORMAT_USD: _ClassVar[AssetFormat]
    ASSET_FORMAT_USDA: _ClassVar[AssetFormat]
    ASSET_FORMAT_USDC: _ClassVar[AssetFormat]
    ASSET_FORMAT_USDZ: _ClassVar[AssetFormat]
    ASSET_FORMAT_MESH: _ClassVar[AssetFormat]
    ASSET_FORMAT_SPLAT: _ClassVar[AssetFormat]
    ASSET_FORMAT_CALIBRATION: _ClassVar[AssetFormat]
    ASSET_FORMAT_OTHER: _ClassVar[AssetFormat]
    ASSET_FORMAT_SDF: _ClassVar[AssetFormat]
    ASSET_FORMAT_STEP: _ClassVar[AssetFormat]

class AssetRole(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ASSET_ROLE_UNSPECIFIED: _ClassVar[AssetRole]
    ASSET_ROLE_DESCRIPTION: _ClassVar[AssetRole]
    ASSET_ROLE_GEOMETRY: _ClassVar[AssetRole]
    ASSET_ROLE_COLLISION: _ClassVar[AssetRole]
    ASSET_ROLE_CALIBRATION: _ClassVar[AssetRole]
    ASSET_ROLE_TEXTURE: _ClassVar[AssetRole]
    ASSET_ROLE_LICENSE: _ClassVar[AssetRole]
    ASSET_ROLE_OTHER: _ClassVar[AssetRole]
ASSET_FORMAT_UNSPECIFIED: AssetFormat
ASSET_FORMAT_URDF: AssetFormat
ASSET_FORMAT_SRDF: AssetFormat
ASSET_FORMAT_MJCF: AssetFormat
ASSET_FORMAT_USD: AssetFormat
ASSET_FORMAT_USDA: AssetFormat
ASSET_FORMAT_USDC: AssetFormat
ASSET_FORMAT_USDZ: AssetFormat
ASSET_FORMAT_MESH: AssetFormat
ASSET_FORMAT_SPLAT: AssetFormat
ASSET_FORMAT_CALIBRATION: AssetFormat
ASSET_FORMAT_OTHER: AssetFormat
ASSET_FORMAT_SDF: AssetFormat
ASSET_FORMAT_STEP: AssetFormat
ASSET_ROLE_UNSPECIFIED: AssetRole
ASSET_ROLE_DESCRIPTION: AssetRole
ASSET_ROLE_GEOMETRY: AssetRole
ASSET_ROLE_COLLISION: AssetRole
ASSET_ROLE_CALIBRATION: AssetRole
ASSET_ROLE_TEXTURE: AssetRole
ASSET_ROLE_LICENSE: AssetRole
ASSET_ROLE_OTHER: AssetRole

class ContentBlob(_message.Message):
    __slots__ = ("sha256", "size_bytes")
    SHA256_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    sha256: str
    size_bytes: int
    def __init__(self, sha256: _Optional[str] = ..., size_bytes: _Optional[int] = ...) -> None: ...

class AssetRef(_message.Message):
    __slots__ = ("location", "content", "format", "role", "media_type", "logical_path")
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    FORMAT_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_PATH_FIELD_NUMBER: _ClassVar[int]
    location: str
    content: ContentBlob
    format: AssetFormat
    role: AssetRole
    media_type: str
    logical_path: str
    def __init__(self, location: _Optional[str] = ..., content: _Optional[_Union[ContentBlob, _Mapping]] = ..., format: _Optional[_Union[AssetFormat, str]] = ..., role: _Optional[_Union[AssetRole, str]] = ..., media_type: _Optional[str] = ..., logical_path: _Optional[str] = ...) -> None: ...

class AssetProvenance(_message.Message):
    __slots__ = ("repository", "revision", "path", "license_id", "generator")
    REPOSITORY_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    LICENSE_ID_FIELD_NUMBER: _ClassVar[int]
    GENERATOR_FIELD_NUMBER: _ClassVar[int]
    repository: str
    revision: str
    path: str
    license_id: str
    generator: str
    def __init__(self, repository: _Optional[str] = ..., revision: _Optional[str] = ..., path: _Optional[str] = ..., license_id: _Optional[str] = ..., generator: _Optional[str] = ...) -> None: ...

class ProvenancedAsset(_message.Message):
    __slots__ = ("asset", "provenance")
    ASSET_FIELD_NUMBER: _ClassVar[int]
    PROVENANCE_FIELD_NUMBER: _ClassVar[int]
    asset: AssetRef
    provenance: AssetProvenance
    def __init__(self, asset: _Optional[_Union[AssetRef, _Mapping]] = ..., provenance: _Optional[_Union[AssetProvenance, _Mapping]] = ...) -> None: ...
