from buf.validate import validate_pb2 as _validate_pb2
from sentientx.sx.common.v1 import capabilities_pb2 as _capabilities_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TaskGoalRelation(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TASK_GOAL_RELATION_UNSPECIFIED: _ClassVar[TaskGoalRelation]
    TASK_GOAL_RELATION_GEOMETRY: _ClassVar[TaskGoalRelation]
    TASK_GOAL_RELATION_ATTACHMENT: _ClassVar[TaskGoalRelation]
    TASK_GOAL_RELATION_TOPOLOGY: _ClassVar[TaskGoalRelation]
    TASK_GOAL_RELATION_MATERIAL_STATE: _ClassVar[TaskGoalRelation]
    TASK_GOAL_RELATION_INFORMATION: _ClassVar[TaskGoalRelation]
    TASK_GOAL_RELATION_HUMAN_BODY: _ClassVar[TaskGoalRelation]
    TASK_GOAL_RELATION_HUMAN_MIND: _ClassVar[TaskGoalRelation]

class TaskCounterparty(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TASK_COUNTERPARTY_UNSPECIFIED: _ClassVar[TaskCounterparty]
    TASK_COUNTERPARTY_NONE: _ClassVar[TaskCounterparty]
    TASK_COUNTERPARTY_SYSTEM: _ClassVar[TaskCounterparty]
    TASK_COUNTERPARTY_HUMAN_BODY: _ClassVar[TaskCounterparty]
    TASK_COUNTERPARTY_HUMAN_MIND: _ClassVar[TaskCounterparty]

class TaskHorizon(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TASK_HORIZON_UNSPECIFIED: _ClassVar[TaskHorizon]
    TASK_HORIZON_SHORT: _ClassVar[TaskHorizon]
    TASK_HORIZON_MEDIUM: _ClassVar[TaskHorizon]
    TASK_HORIZON_LONG: _ClassVar[TaskHorizon]

class OperatorTier(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    OPERATOR_TIER_UNSPECIFIED: _ClassVar[OperatorTier]
    OPERATOR_TIER_ANY: _ClassVar[OperatorTier]
    OPERATOR_TIER_TRAINED: _ClassVar[OperatorTier]
    OPERATOR_TIER_EXPERT: _ClassVar[OperatorTier]

class ReasoningKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    REASONING_KIND_UNSPECIFIED: _ClassVar[ReasoningKind]
    REASONING_KIND_NONE: _ClassVar[ReasoningKind]
    REASONING_KIND_SPATIAL: _ClassVar[ReasoningKind]
    REASONING_KIND_SEQUENTIAL: _ClassVar[ReasoningKind]
    REASONING_KIND_PUZZLE: _ClassVar[ReasoningKind]

class ComplexityAxis(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    COMPLEXITY_AXIS_UNSPECIFIED: _ClassVar[ComplexityAxis]
    COMPLEXITY_AXIS_GEOM: _ClassVar[ComplexityAxis]
    COMPLEXITY_AXIS_FORCE: _ClassVar[ComplexityAxis]
    COMPLEXITY_AXIS_CONTACT: _ClassVar[ComplexityAxis]
    COMPLEXITY_AXIS_OBS: _ClassVar[ComplexityAxis]
    COMPLEXITY_AXIS_DEFORM: _ClassVar[ComplexityAxis]
    COMPLEXITY_AXIS_DYN: _ClassVar[ComplexityAxis]

class EvidenceRelation(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EVIDENCE_RELATION_UNSPECIFIED: _ClassVar[EvidenceRelation]
    EVIDENCE_RELATION_EXACT: _ClassVar[EvidenceRelation]
    EVIDENCE_RELATION_FRAGMENT: _ClassVar[EvidenceRelation]
    EVIDENCE_RELATION_ANALOG: _ClassVar[EvidenceRelation]

class EvidenceOrigin(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EVIDENCE_ORIGIN_UNSPECIFIED: _ClassVar[EvidenceOrigin]
    EVIDENCE_ORIGIN_EXISTING: _ClassVar[EvidenceOrigin]
    EVIDENCE_ORIGIN_FACTORY_ADDED: _ClassVar[EvidenceOrigin]

class TaskObjectRole(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TASK_OBJECT_ROLE_UNSPECIFIED: _ClassVar[TaskObjectRole]
    TASK_OBJECT_ROLE_FOCUS: _ClassVar[TaskObjectRole]
    TASK_OBJECT_ROLE_FIXTURE: _ClassVar[TaskObjectRole]
    TASK_OBJECT_ROLE_TOOL: _ClassVar[TaskObjectRole]
    TASK_OBJECT_ROLE_CONTAINER: _ClassVar[TaskObjectRole]

class TaskObjectMix(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TASK_OBJECT_MIX_UNSPECIFIED: _ClassVar[TaskObjectMix]
    TASK_OBJECT_MIX_IDENTICAL: _ClassVar[TaskObjectMix]
    TASK_OBJECT_MIX_VARIED: _ClassVar[TaskObjectMix]

class DiversificationScheme(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DIVERSIFICATION_SCHEME_UNSPECIFIED: _ClassVar[DiversificationScheme]
    DIVERSIFICATION_SCHEME_COVERAGE_DESIGN: _ClassVar[DiversificationScheme]
    DIVERSIFICATION_SCHEME_FULL_FACTORIAL: _ClassVar[DiversificationScheme]
    DIVERSIFICATION_SCHEME_SCRIPTED: _ClassVar[DiversificationScheme]

class AdaptationKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ADAPTATION_KIND_UNSPECIFIED: _ClassVar[AdaptationKind]
    ADAPTATION_KIND_NONE: _ClassVar[AdaptationKind]
    ADAPTATION_KIND_FAILURE_SEEKING: _ClassVar[AdaptationKind]

class FillState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    FILL_STATE_UNSPECIFIED: _ClassVar[FillState]
    FILL_STATE_EMPTY: _ClassVar[FillState]
    FILL_STATE_QUARTER: _ClassVar[FillState]
    FILL_STATE_HALF: _ClassVar[FillState]
    FILL_STATE_THREE_QUARTER: _ClassVar[FillState]
    FILL_STATE_FULL: _ClassVar[FillState]

class DemonstrationPace(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DEMONSTRATION_PACE_UNSPECIFIED: _ClassVar[DemonstrationPace]
    DEMONSTRATION_PACE_SLOW: _ClassVar[DemonstrationPace]
    DEMONSTRATION_PACE_NORMAL: _ClassVar[DemonstrationPace]
    DEMONSTRATION_PACE_FAST: _ClassVar[DemonstrationPace]

class PerturbationKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PERTURBATION_KIND_UNSPECIFIED: _ClassVar[PerturbationKind]
    PERTURBATION_KIND_NONE: _ClassVar[PerturbationKind]
    PERTURBATION_KIND_STATIC_REPOSITION: _ClassVar[PerturbationKind]
    PERTURBATION_KIND_DYNAMIC_NUDGE: _ClassVar[PerturbationKind]
    PERTURBATION_KIND_MOVING_TARGET: _ClassVar[PerturbationKind]

class ObjectCondition(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    OBJECT_CONDITION_UNSPECIFIED: _ClassVar[ObjectCondition]
    OBJECT_CONDITION_NEW: _ClassVar[ObjectCondition]
    OBJECT_CONDITION_GOOD: _ClassVar[ObjectCondition]
    OBJECT_CONDITION_WORN: _ClassVar[ObjectCondition]
    OBJECT_CONDITION_DAMAGED: _ClassVar[ObjectCondition]

class FailureConditionKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    FAILURE_CONDITION_KIND_UNSPECIFIED: _ClassVar[FailureConditionKind]
    FAILURE_CONDITION_KIND_DAMAGE: _ClassVar[FailureConditionKind]
    FAILURE_CONDITION_KIND_DROP: _ClassVar[FailureConditionKind]
    FAILURE_CONDITION_KIND_PROCESS_CONSTRAINT: _ClassVar[FailureConditionKind]
    FAILURE_CONDITION_KIND_ATTEMPT_LIMIT: _ClassVar[FailureConditionKind]
    FAILURE_CONDITION_KIND_SIDE_EFFECT: _ClassVar[FailureConditionKind]
    FAILURE_CONDITION_KIND_OUTCOME_TOLERANCE: _ClassVar[FailureConditionKind]
TASK_GOAL_RELATION_UNSPECIFIED: TaskGoalRelation
TASK_GOAL_RELATION_GEOMETRY: TaskGoalRelation
TASK_GOAL_RELATION_ATTACHMENT: TaskGoalRelation
TASK_GOAL_RELATION_TOPOLOGY: TaskGoalRelation
TASK_GOAL_RELATION_MATERIAL_STATE: TaskGoalRelation
TASK_GOAL_RELATION_INFORMATION: TaskGoalRelation
TASK_GOAL_RELATION_HUMAN_BODY: TaskGoalRelation
TASK_GOAL_RELATION_HUMAN_MIND: TaskGoalRelation
TASK_COUNTERPARTY_UNSPECIFIED: TaskCounterparty
TASK_COUNTERPARTY_NONE: TaskCounterparty
TASK_COUNTERPARTY_SYSTEM: TaskCounterparty
TASK_COUNTERPARTY_HUMAN_BODY: TaskCounterparty
TASK_COUNTERPARTY_HUMAN_MIND: TaskCounterparty
TASK_HORIZON_UNSPECIFIED: TaskHorizon
TASK_HORIZON_SHORT: TaskHorizon
TASK_HORIZON_MEDIUM: TaskHorizon
TASK_HORIZON_LONG: TaskHorizon
OPERATOR_TIER_UNSPECIFIED: OperatorTier
OPERATOR_TIER_ANY: OperatorTier
OPERATOR_TIER_TRAINED: OperatorTier
OPERATOR_TIER_EXPERT: OperatorTier
REASONING_KIND_UNSPECIFIED: ReasoningKind
REASONING_KIND_NONE: ReasoningKind
REASONING_KIND_SPATIAL: ReasoningKind
REASONING_KIND_SEQUENTIAL: ReasoningKind
REASONING_KIND_PUZZLE: ReasoningKind
COMPLEXITY_AXIS_UNSPECIFIED: ComplexityAxis
COMPLEXITY_AXIS_GEOM: ComplexityAxis
COMPLEXITY_AXIS_FORCE: ComplexityAxis
COMPLEXITY_AXIS_CONTACT: ComplexityAxis
COMPLEXITY_AXIS_OBS: ComplexityAxis
COMPLEXITY_AXIS_DEFORM: ComplexityAxis
COMPLEXITY_AXIS_DYN: ComplexityAxis
EVIDENCE_RELATION_UNSPECIFIED: EvidenceRelation
EVIDENCE_RELATION_EXACT: EvidenceRelation
EVIDENCE_RELATION_FRAGMENT: EvidenceRelation
EVIDENCE_RELATION_ANALOG: EvidenceRelation
EVIDENCE_ORIGIN_UNSPECIFIED: EvidenceOrigin
EVIDENCE_ORIGIN_EXISTING: EvidenceOrigin
EVIDENCE_ORIGIN_FACTORY_ADDED: EvidenceOrigin
TASK_OBJECT_ROLE_UNSPECIFIED: TaskObjectRole
TASK_OBJECT_ROLE_FOCUS: TaskObjectRole
TASK_OBJECT_ROLE_FIXTURE: TaskObjectRole
TASK_OBJECT_ROLE_TOOL: TaskObjectRole
TASK_OBJECT_ROLE_CONTAINER: TaskObjectRole
TASK_OBJECT_MIX_UNSPECIFIED: TaskObjectMix
TASK_OBJECT_MIX_IDENTICAL: TaskObjectMix
TASK_OBJECT_MIX_VARIED: TaskObjectMix
DIVERSIFICATION_SCHEME_UNSPECIFIED: DiversificationScheme
DIVERSIFICATION_SCHEME_COVERAGE_DESIGN: DiversificationScheme
DIVERSIFICATION_SCHEME_FULL_FACTORIAL: DiversificationScheme
DIVERSIFICATION_SCHEME_SCRIPTED: DiversificationScheme
ADAPTATION_KIND_UNSPECIFIED: AdaptationKind
ADAPTATION_KIND_NONE: AdaptationKind
ADAPTATION_KIND_FAILURE_SEEKING: AdaptationKind
FILL_STATE_UNSPECIFIED: FillState
FILL_STATE_EMPTY: FillState
FILL_STATE_QUARTER: FillState
FILL_STATE_HALF: FillState
FILL_STATE_THREE_QUARTER: FillState
FILL_STATE_FULL: FillState
DEMONSTRATION_PACE_UNSPECIFIED: DemonstrationPace
DEMONSTRATION_PACE_SLOW: DemonstrationPace
DEMONSTRATION_PACE_NORMAL: DemonstrationPace
DEMONSTRATION_PACE_FAST: DemonstrationPace
PERTURBATION_KIND_UNSPECIFIED: PerturbationKind
PERTURBATION_KIND_NONE: PerturbationKind
PERTURBATION_KIND_STATIC_REPOSITION: PerturbationKind
PERTURBATION_KIND_DYNAMIC_NUDGE: PerturbationKind
PERTURBATION_KIND_MOVING_TARGET: PerturbationKind
OBJECT_CONDITION_UNSPECIFIED: ObjectCondition
OBJECT_CONDITION_NEW: ObjectCondition
OBJECT_CONDITION_GOOD: ObjectCondition
OBJECT_CONDITION_WORN: ObjectCondition
OBJECT_CONDITION_DAMAGED: ObjectCondition
FAILURE_CONDITION_KIND_UNSPECIFIED: FailureConditionKind
FAILURE_CONDITION_KIND_DAMAGE: FailureConditionKind
FAILURE_CONDITION_KIND_DROP: FailureConditionKind
FAILURE_CONDITION_KIND_PROCESS_CONSTRAINT: FailureConditionKind
FAILURE_CONDITION_KIND_ATTEMPT_LIMIT: FailureConditionKind
FAILURE_CONDITION_KIND_SIDE_EFFECT: FailureConditionKind
FAILURE_CONDITION_KIND_OUTCOME_TOLERANCE: FailureConditionKind

class PlanarDistanceTo(_message.Message):
    __slots__ = ("reference",)
    REFERENCE_FIELD_NUMBER: _ClassVar[int]
    reference: str
    def __init__(self, reference: _Optional[str] = ...) -> None: ...

class VerticalDistanceTo(_message.Message):
    __slots__ = ("reference",)
    REFERENCE_FIELD_NUMBER: _ClassVar[int]
    reference: str
    def __init__(self, reference: _Optional[str] = ...) -> None: ...

class OrientationErrorTo(_message.Message):
    __slots__ = ("reference",)
    REFERENCE_FIELD_NUMBER: _ClassVar[int]
    reference: str
    def __init__(self, reference: _Optional[str] = ...) -> None: ...

class UprightOrientationError(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class FractionTransferredTo(_message.Message):
    __slots__ = ("reference",)
    REFERENCE_FIELD_NUMBER: _ClassVar[int]
    reference: str
    def __init__(self, reference: _Optional[str] = ...) -> None: ...

class CountWithin(_message.Message):
    __slots__ = ("reference",)
    REFERENCE_FIELD_NUMBER: _ClassVar[int]
    reference: str
    def __init__(self, reference: _Optional[str] = ...) -> None: ...

class JointFractionAtLeast(_message.Message):
    __slots__ = ("articulation", "fraction")
    ARTICULATION_FIELD_NUMBER: _ClassVar[int]
    FRACTION_FIELD_NUMBER: _ClassVar[int]
    articulation: str
    fraction: float
    def __init__(self, articulation: _Optional[str] = ..., fraction: _Optional[float] = ...) -> None: ...

class BinaryStateIs(_message.Message):
    __slots__ = ("articulation", "on")
    ARTICULATION_FIELD_NUMBER: _ClassVar[int]
    ON_FIELD_NUMBER: _ClassVar[int]
    articulation: str
    on: bool
    def __init__(self, articulation: _Optional[str] = ..., on: _Optional[bool] = ...) -> None: ...

class JointAngleOutside(_message.Message):
    __slots__ = ("articulation", "lower_rad", "upper_rad")
    ARTICULATION_FIELD_NUMBER: _ClassVar[int]
    LOWER_RAD_FIELD_NUMBER: _ClassVar[int]
    UPPER_RAD_FIELD_NUMBER: _ClassVar[int]
    articulation: str
    lower_rad: float
    upper_rad: float
    def __init__(self, articulation: _Optional[str] = ..., lower_rad: _Optional[float] = ..., upper_rad: _Optional[float] = ...) -> None: ...

class ContactWith(_message.Message):
    __slots__ = ("surface",)
    SURFACE_FIELD_NUMBER: _ClassVar[int]
    surface: str
    def __init__(self, surface: _Optional[str] = ...) -> None: ...

class TaskMeasure(_message.Message):
    __slots__ = ("planar_distance_to", "vertical_distance_to", "orientation_error_to", "upright_orientation_error", "fraction_transferred_to", "count_within", "joint_fraction_at_least", "binary_state_is", "joint_angle_outside", "contact_with")
    PLANAR_DISTANCE_TO_FIELD_NUMBER: _ClassVar[int]
    VERTICAL_DISTANCE_TO_FIELD_NUMBER: _ClassVar[int]
    ORIENTATION_ERROR_TO_FIELD_NUMBER: _ClassVar[int]
    UPRIGHT_ORIENTATION_ERROR_FIELD_NUMBER: _ClassVar[int]
    FRACTION_TRANSFERRED_TO_FIELD_NUMBER: _ClassVar[int]
    COUNT_WITHIN_FIELD_NUMBER: _ClassVar[int]
    JOINT_FRACTION_AT_LEAST_FIELD_NUMBER: _ClassVar[int]
    BINARY_STATE_IS_FIELD_NUMBER: _ClassVar[int]
    JOINT_ANGLE_OUTSIDE_FIELD_NUMBER: _ClassVar[int]
    CONTACT_WITH_FIELD_NUMBER: _ClassVar[int]
    planar_distance_to: PlanarDistanceTo
    vertical_distance_to: VerticalDistanceTo
    orientation_error_to: OrientationErrorTo
    upright_orientation_error: UprightOrientationError
    fraction_transferred_to: FractionTransferredTo
    count_within: CountWithin
    joint_fraction_at_least: JointFractionAtLeast
    binary_state_is: BinaryStateIs
    joint_angle_outside: JointAngleOutside
    contact_with: ContactWith
    def __init__(self, planar_distance_to: _Optional[_Union[PlanarDistanceTo, _Mapping]] = ..., vertical_distance_to: _Optional[_Union[VerticalDistanceTo, _Mapping]] = ..., orientation_error_to: _Optional[_Union[OrientationErrorTo, _Mapping]] = ..., upright_orientation_error: _Optional[_Union[UprightOrientationError, _Mapping]] = ..., fraction_transferred_to: _Optional[_Union[FractionTransferredTo, _Mapping]] = ..., count_within: _Optional[_Union[CountWithin, _Mapping]] = ..., joint_fraction_at_least: _Optional[_Union[JointFractionAtLeast, _Mapping]] = ..., binary_state_is: _Optional[_Union[BinaryStateIs, _Mapping]] = ..., joint_angle_outside: _Optional[_Union[JointAngleOutside, _Mapping]] = ..., contact_with: _Optional[_Union[ContactWith, _Mapping]] = ...) -> None: ...

class AtMost(_message.Message):
    __slots__ = ("value",)
    VALUE_FIELD_NUMBER: _ClassVar[int]
    value: float
    def __init__(self, value: _Optional[float] = ...) -> None: ...

class AtLeast(_message.Message):
    __slots__ = ("value",)
    VALUE_FIELD_NUMBER: _ClassVar[int]
    value: float
    def __init__(self, value: _Optional[float] = ...) -> None: ...

class Exactly(_message.Message):
    __slots__ = ("value",)
    VALUE_FIELD_NUMBER: _ClassVar[int]
    value: float
    def __init__(self, value: _Optional[float] = ...) -> None: ...

class Within(_message.Message):
    __slots__ = ("value", "tolerance")
    VALUE_FIELD_NUMBER: _ClassVar[int]
    TOLERANCE_FIELD_NUMBER: _ClassVar[int]
    value: float
    tolerance: float
    def __init__(self, value: _Optional[float] = ..., tolerance: _Optional[float] = ...) -> None: ...

class TaskComparison(_message.Message):
    __slots__ = ("at_most", "at_least", "exactly", "within")
    AT_MOST_FIELD_NUMBER: _ClassVar[int]
    AT_LEAST_FIELD_NUMBER: _ClassVar[int]
    EXACTLY_FIELD_NUMBER: _ClassVar[int]
    WITHIN_FIELD_NUMBER: _ClassVar[int]
    at_most: AtMost
    at_least: AtLeast
    exactly: Exactly
    within: Within
    def __init__(self, at_most: _Optional[_Union[AtMost, _Mapping]] = ..., at_least: _Optional[_Union[AtLeast, _Mapping]] = ..., exactly: _Optional[_Union[Exactly, _Mapping]] = ..., within: _Optional[_Union[Within, _Mapping]] = ...) -> None: ...

class GoalPredicate(_message.Message):
    __slots__ = ("entity", "measure", "comparison")
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    MEASURE_FIELD_NUMBER: _ClassVar[int]
    COMPARISON_FIELD_NUMBER: _ClassVar[int]
    entity: str
    measure: TaskMeasure
    comparison: TaskComparison
    def __init__(self, entity: _Optional[str] = ..., measure: _Optional[_Union[TaskMeasure, _Mapping]] = ..., comparison: _Optional[_Union[TaskComparison, _Mapping]] = ...) -> None: ...

class TaskGoal(_message.Message):
    __slots__ = ("relation", "counterparty", "predicates")
    RELATION_FIELD_NUMBER: _ClassVar[int]
    COUNTERPARTY_FIELD_NUMBER: _ClassVar[int]
    PREDICATES_FIELD_NUMBER: _ClassVar[int]
    relation: TaskGoalRelation
    counterparty: TaskCounterparty
    predicates: _containers.RepeatedCompositeFieldContainer[GoalPredicate]
    def __init__(self, relation: _Optional[_Union[TaskGoalRelation, str]] = ..., counterparty: _Optional[_Union[TaskCounterparty, str]] = ..., predicates: _Optional[_Iterable[_Union[GoalPredicate, _Mapping]]] = ...) -> None: ...

class TaskStep(_message.Message):
    __slots__ = ("skill", "object", "target", "when", "until", "note", "reversible")
    SKILL_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    WHEN_FIELD_NUMBER: _ClassVar[int]
    UNTIL_FIELD_NUMBER: _ClassVar[int]
    NOTE_FIELD_NUMBER: _ClassVar[int]
    REVERSIBLE_FIELD_NUMBER: _ClassVar[int]
    skill: str
    object: str
    target: str
    when: str
    until: str
    note: str
    reversible: bool
    def __init__(self, skill: _Optional[str] = ..., object: _Optional[str] = ..., target: _Optional[str] = ..., when: _Optional[str] = ..., until: _Optional[str] = ..., note: _Optional[str] = ..., reversible: _Optional[bool] = ...) -> None: ...

class TaskpediaCodeRef(_message.Message):
    __slots__ = ("code", "relation", "origin")
    CODE_FIELD_NUMBER: _ClassVar[int]
    RELATION_FIELD_NUMBER: _ClassVar[int]
    ORIGIN_FIELD_NUMBER: _ClassVar[int]
    code: str
    relation: EvidenceRelation
    origin: EvidenceOrigin
    def __init__(self, code: _Optional[str] = ..., relation: _Optional[_Union[EvidenceRelation, str]] = ..., origin: _Optional[_Union[EvidenceOrigin, str]] = ...) -> None: ...

class CountInterval(_message.Message):
    __slots__ = ("minimum", "maximum")
    MINIMUM_FIELD_NUMBER: _ClassVar[int]
    MAXIMUM_FIELD_NUMBER: _ClassVar[int]
    minimum: int
    maximum: int
    def __init__(self, minimum: _Optional[int] = ..., maximum: _Optional[int] = ...) -> None: ...

class TaskObject(_message.Message):
    __slots__ = ("role", "head", "count", "mix", "options")
    ROLE_FIELD_NUMBER: _ClassVar[int]
    HEAD_FIELD_NUMBER: _ClassVar[int]
    COUNT_FIELD_NUMBER: _ClassVar[int]
    MIX_FIELD_NUMBER: _ClassVar[int]
    OPTIONS_FIELD_NUMBER: _ClassVar[int]
    role: TaskObjectRole
    head: str
    count: CountInterval
    mix: TaskObjectMix
    options: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, role: _Optional[_Union[TaskObjectRole, str]] = ..., head: _Optional[str] = ..., count: _Optional[_Union[CountInterval, _Mapping]] = ..., mix: _Optional[_Union[TaskObjectMix, str]] = ..., options: _Optional[_Iterable[str]] = ...) -> None: ...

class TaskEnvironment(_message.Message):
    __slots__ = ("stations", "lighting", "surfaces")
    STATIONS_FIELD_NUMBER: _ClassVar[int]
    LIGHTING_FIELD_NUMBER: _ClassVar[int]
    SURFACES_FIELD_NUMBER: _ClassVar[int]
    stations: _containers.RepeatedScalarFieldContainer[str]
    lighting: _containers.RepeatedScalarFieldContainer[str]
    surfaces: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, stations: _Optional[_Iterable[str]] = ..., lighting: _Optional[_Iterable[str]] = ..., surfaces: _Optional[_Iterable[str]] = ...) -> None: ...

class DistractorPlan(_message.Message):
    __slots__ = ("easy", "medium", "hard")
    EASY_FIELD_NUMBER: _ClassVar[int]
    MEDIUM_FIELD_NUMBER: _ClassVar[int]
    HARD_FIELD_NUMBER: _ClassVar[int]
    easy: str
    medium: str
    hard: str
    def __init__(self, easy: _Optional[str] = ..., medium: _Optional[str] = ..., hard: _Optional[str] = ...) -> None: ...

class InitialPosePlan(_message.Message):
    __slots__ = ("object_bins", "robot_bins")
    OBJECT_BINS_FIELD_NUMBER: _ClassVar[int]
    ROBOT_BINS_FIELD_NUMBER: _ClassVar[int]
    object_bins: _containers.RepeatedScalarFieldContainer[str]
    robot_bins: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, object_bins: _Optional[_Iterable[str]] = ..., robot_bins: _Optional[_Iterable[str]] = ...) -> None: ...

class ObjectDiversification(_message.Message):
    __slots__ = ("role", "instances", "justification")
    ROLE_FIELD_NUMBER: _ClassVar[int]
    INSTANCES_FIELD_NUMBER: _ClassVar[int]
    JUSTIFICATION_FIELD_NUMBER: _ClassVar[int]
    role: TaskObjectRole
    instances: _containers.RepeatedScalarFieldContainer[str]
    justification: str
    def __init__(self, role: _Optional[_Union[TaskObjectRole, str]] = ..., instances: _Optional[_Iterable[str]] = ..., justification: _Optional[str] = ...) -> None: ...

class DiversificationPlan(_message.Message):
    __slots__ = ("scheme", "budget", "adapt", "object_scheme")
    SCHEME_FIELD_NUMBER: _ClassVar[int]
    BUDGET_FIELD_NUMBER: _ClassVar[int]
    ADAPT_FIELD_NUMBER: _ClassVar[int]
    OBJECT_SCHEME_FIELD_NUMBER: _ClassVar[int]
    scheme: DiversificationScheme
    budget: int
    adapt: AdaptationKind
    object_scheme: ObjectDiversification
    def __init__(self, scheme: _Optional[_Union[DiversificationScheme, str]] = ..., budget: _Optional[int] = ..., adapt: _Optional[_Union[AdaptationKind, str]] = ..., object_scheme: _Optional[_Union[ObjectDiversification, _Mapping]] = ...) -> None: ...

class VariationPlan(_message.Message):
    __slots__ = ("fill_states", "media", "pace", "perturbations", "conditions", "recovery_share", "cameras")
    FILL_STATES_FIELD_NUMBER: _ClassVar[int]
    MEDIA_FIELD_NUMBER: _ClassVar[int]
    PACE_FIELD_NUMBER: _ClassVar[int]
    PERTURBATIONS_FIELD_NUMBER: _ClassVar[int]
    CONDITIONS_FIELD_NUMBER: _ClassVar[int]
    RECOVERY_SHARE_FIELD_NUMBER: _ClassVar[int]
    CAMERAS_FIELD_NUMBER: _ClassVar[int]
    fill_states: _containers.RepeatedScalarFieldContainer[FillState]
    media: _containers.RepeatedScalarFieldContainer[str]
    pace: _containers.RepeatedScalarFieldContainer[DemonstrationPace]
    perturbations: _containers.RepeatedScalarFieldContainer[PerturbationKind]
    conditions: _containers.RepeatedScalarFieldContainer[ObjectCondition]
    recovery_share: float
    cameras: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, fill_states: _Optional[_Iterable[_Union[FillState, str]]] = ..., media: _Optional[_Iterable[str]] = ..., pace: _Optional[_Iterable[_Union[DemonstrationPace, str]]] = ..., perturbations: _Optional[_Iterable[_Union[PerturbationKind, str]]] = ..., conditions: _Optional[_Iterable[_Union[ObjectCondition, str]]] = ..., recovery_share: _Optional[float] = ..., cameras: _Optional[_Iterable[str]] = ...) -> None: ...

class CapturePlan(_message.Message):
    __slots__ = ("episodes_per_scenario_max", "episode_minutes_est")
    EPISODES_PER_SCENARIO_MAX_FIELD_NUMBER: _ClassVar[int]
    EPISODE_MINUTES_EST_FIELD_NUMBER: _ClassVar[int]
    episodes_per_scenario_max: int
    episode_minutes_est: float
    def __init__(self, episodes_per_scenario_max: _Optional[int] = ..., episode_minutes_est: _Optional[float] = ...) -> None: ...

class EvaluationSuiteRef(_message.Message):
    __slots__ = ("suite_id", "sha256")
    SUITE_ID_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    suite_id: str
    sha256: str
    def __init__(self, suite_id: _Optional[str] = ..., sha256: _Optional[str] = ...) -> None: ...

class NativeEvaluationCriteria(_message.Message):
    __slots__ = ("threshold", "trials")
    THRESHOLD_FIELD_NUMBER: _ClassVar[int]
    TRIALS_FIELD_NUMBER: _ClassVar[int]
    threshold: float
    trials: int
    def __init__(self, threshold: _Optional[float] = ..., trials: _Optional[int] = ...) -> None: ...

class SuiteEvaluationCriteria(_message.Message):
    __slots__ = ("threshold", "trials", "suite")
    THRESHOLD_FIELD_NUMBER: _ClassVar[int]
    TRIALS_FIELD_NUMBER: _ClassVar[int]
    SUITE_FIELD_NUMBER: _ClassVar[int]
    threshold: float
    trials: int
    suite: EvaluationSuiteRef
    def __init__(self, threshold: _Optional[float] = ..., trials: _Optional[int] = ..., suite: _Optional[_Union[EvaluationSuiteRef, _Mapping]] = ...) -> None: ...

class TaskEvaluationCriteria(_message.Message):
    __slots__ = ("native", "suite")
    NATIVE_FIELD_NUMBER: _ClassVar[int]
    SUITE_FIELD_NUMBER: _ClassVar[int]
    native: NativeEvaluationCriteria
    suite: SuiteEvaluationCriteria
    def __init__(self, native: _Optional[_Union[NativeEvaluationCriteria, _Mapping]] = ..., suite: _Optional[_Union[SuiteEvaluationCriteria, _Mapping]] = ...) -> None: ...

class FailureCondition(_message.Message):
    __slots__ = ("kind", "detail", "limit")
    KIND_FIELD_NUMBER: _ClassVar[int]
    DETAIL_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    kind: FailureConditionKind
    detail: str
    limit: int
    def __init__(self, kind: _Optional[_Union[FailureConditionKind, str]] = ..., detail: _Optional[str] = ..., limit: _Optional[int] = ...) -> None: ...

class TaskContract(_message.Message):
    __slots__ = ("schema_version", "family", "task")
    SCHEMA_VERSION_FIELD_NUMBER: _ClassVar[int]
    FAMILY_FIELD_NUMBER: _ClassVar[int]
    TASK_FIELD_NUMBER: _ClassVar[int]
    schema_version: str
    family: str
    task: TaskTemplate
    def __init__(self, schema_version: _Optional[str] = ..., family: _Optional[str] = ..., task: _Optional[_Union[TaskTemplate, _Mapping]] = ...) -> None: ...

class TaskTemplate(_message.Message):
    __slots__ = ("id", "name", "horizon", "reasoning", "rigs", "operator", "embodiment", "steps", "taskpedia_codes", "objects", "environment", "distractors", "initial_poses", "diversification", "success", "goal", "complexity", "variation", "capture", "evaluation", "failure_conditions", "safety")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    HORIZON_FIELD_NUMBER: _ClassVar[int]
    REASONING_FIELD_NUMBER: _ClassVar[int]
    RIGS_FIELD_NUMBER: _ClassVar[int]
    OPERATOR_FIELD_NUMBER: _ClassVar[int]
    EMBODIMENT_FIELD_NUMBER: _ClassVar[int]
    STEPS_FIELD_NUMBER: _ClassVar[int]
    TASKPEDIA_CODES_FIELD_NUMBER: _ClassVar[int]
    OBJECTS_FIELD_NUMBER: _ClassVar[int]
    ENVIRONMENT_FIELD_NUMBER: _ClassVar[int]
    DISTRACTORS_FIELD_NUMBER: _ClassVar[int]
    INITIAL_POSES_FIELD_NUMBER: _ClassVar[int]
    DIVERSIFICATION_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    GOAL_FIELD_NUMBER: _ClassVar[int]
    COMPLEXITY_FIELD_NUMBER: _ClassVar[int]
    VARIATION_FIELD_NUMBER: _ClassVar[int]
    CAPTURE_FIELD_NUMBER: _ClassVar[int]
    EVALUATION_FIELD_NUMBER: _ClassVar[int]
    FAILURE_CONDITIONS_FIELD_NUMBER: _ClassVar[int]
    SAFETY_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    horizon: TaskHorizon
    reasoning: ReasoningKind
    rigs: _containers.RepeatedScalarFieldContainer[str]
    operator: OperatorTier
    embodiment: _capabilities_pb2.TaskCapabilityRequirements
    steps: _containers.RepeatedCompositeFieldContainer[TaskStep]
    taskpedia_codes: _containers.RepeatedCompositeFieldContainer[TaskpediaCodeRef]
    objects: _containers.RepeatedCompositeFieldContainer[TaskObject]
    environment: TaskEnvironment
    distractors: DistractorPlan
    initial_poses: InitialPosePlan
    diversification: DiversificationPlan
    success: str
    goal: TaskGoal
    complexity: _containers.RepeatedScalarFieldContainer[ComplexityAxis]
    variation: VariationPlan
    capture: CapturePlan
    evaluation: TaskEvaluationCriteria
    failure_conditions: _containers.RepeatedCompositeFieldContainer[FailureCondition]
    safety: str
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., horizon: _Optional[_Union[TaskHorizon, str]] = ..., reasoning: _Optional[_Union[ReasoningKind, str]] = ..., rigs: _Optional[_Iterable[str]] = ..., operator: _Optional[_Union[OperatorTier, str]] = ..., embodiment: _Optional[_Union[_capabilities_pb2.TaskCapabilityRequirements, _Mapping]] = ..., steps: _Optional[_Iterable[_Union[TaskStep, _Mapping]]] = ..., taskpedia_codes: _Optional[_Iterable[_Union[TaskpediaCodeRef, _Mapping]]] = ..., objects: _Optional[_Iterable[_Union[TaskObject, _Mapping]]] = ..., environment: _Optional[_Union[TaskEnvironment, _Mapping]] = ..., distractors: _Optional[_Union[DistractorPlan, _Mapping]] = ..., initial_poses: _Optional[_Union[InitialPosePlan, _Mapping]] = ..., diversification: _Optional[_Union[DiversificationPlan, _Mapping]] = ..., success: _Optional[str] = ..., goal: _Optional[_Union[TaskGoal, _Mapping]] = ..., complexity: _Optional[_Iterable[_Union[ComplexityAxis, str]]] = ..., variation: _Optional[_Union[VariationPlan, _Mapping]] = ..., capture: _Optional[_Union[CapturePlan, _Mapping]] = ..., evaluation: _Optional[_Union[TaskEvaluationCriteria, _Mapping]] = ..., failure_conditions: _Optional[_Iterable[_Union[FailureCondition, _Mapping]]] = ..., safety: _Optional[str] = ...) -> None: ...
