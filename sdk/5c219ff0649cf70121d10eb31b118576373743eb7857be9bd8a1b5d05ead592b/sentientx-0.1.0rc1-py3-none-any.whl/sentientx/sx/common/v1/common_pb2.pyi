import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PlatformPillar(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PLATFORM_PILLAR_UNSPECIFIED: _ClassVar[PlatformPillar]
    PLATFORM_PILLAR_EXPERIENCE: _ClassVar[PlatformPillar]
    PLATFORM_PILLAR_WORLDS: _ClassVar[PlatformPillar]
    PLATFORM_PILLAR_AUTONOMY: _ClassVar[PlatformPillar]
    PLATFORM_PILLAR_FLEET: _ClassVar[PlatformPillar]

class OperationKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    OPERATION_KIND_UNSPECIFIED: _ClassVar[OperationKind]
    OPERATION_KIND_EPISODE_INGEST: _ClassVar[OperationKind]
    OPERATION_KIND_REGISTRATION: _ClassVar[OperationKind]
    OPERATION_KIND_BATCH_REGISTRATION: _ClassVar[OperationKind]
    OPERATION_KIND_ASSET_REGISTRATION: _ClassVar[OperationKind]
    OPERATION_KIND_CAPTURE_REGISTRATION: _ClassVar[OperationKind]
    OPERATION_KIND_POLICY_REGISTRATION: _ClassVar[OperationKind]
    OPERATION_KIND_TRAINING_CHECKPOINT_REGISTRATION: _ClassVar[OperationKind]
    OPERATION_KIND_EXPORT_CREDENTIAL_VALIDATION: _ClassVar[OperationKind]
    OPERATION_KIND_INGEST_CONVERSION: _ClassVar[OperationKind]
    OPERATION_KIND_PIPELINE_RUN: _ClassVar[OperationKind]
    OPERATION_KIND_EXPORT: _ClassVar[OperationKind]
    OPERATION_KIND_RETENTION: _ClassVar[OperationKind]
    OPERATION_KIND_COMPACTION: _ClassVar[OperationKind]
    OPERATION_KIND_REINDEX: _ClassVar[OperationKind]
    OPERATION_KIND_CAPTURE: _ClassVar[OperationKind]
    OPERATION_KIND_EVALUATION: _ClassVar[OperationKind]
    OPERATION_KIND_GENERATION: _ClassVar[OperationKind]
    OPERATION_KIND_SESSION: _ClassVar[OperationKind]
    OPERATION_KIND_AUTHORING: _ClassVar[OperationKind]
    OPERATION_KIND_TRAINING: _ClassVar[OperationKind]
    OPERATION_KIND_PROGRAM: _ClassVar[OperationKind]
    OPERATION_KIND_IMPROVEMENT: _ClassVar[OperationKind]
    OPERATION_KIND_DEPLOYMENT: _ClassVar[OperationKind]
    OPERATION_KIND_ROLLBACK: _ClassVar[OperationKind]
    OPERATION_KIND_RESEARCH: _ClassVar[OperationKind]
    OPERATION_KIND_WORKLOAD: _ClassVar[OperationKind]
PLATFORM_PILLAR_UNSPECIFIED: PlatformPillar
PLATFORM_PILLAR_EXPERIENCE: PlatformPillar
PLATFORM_PILLAR_WORLDS: PlatformPillar
PLATFORM_PILLAR_AUTONOMY: PlatformPillar
PLATFORM_PILLAR_FLEET: PlatformPillar
OPERATION_KIND_UNSPECIFIED: OperationKind
OPERATION_KIND_EPISODE_INGEST: OperationKind
OPERATION_KIND_REGISTRATION: OperationKind
OPERATION_KIND_BATCH_REGISTRATION: OperationKind
OPERATION_KIND_ASSET_REGISTRATION: OperationKind
OPERATION_KIND_CAPTURE_REGISTRATION: OperationKind
OPERATION_KIND_POLICY_REGISTRATION: OperationKind
OPERATION_KIND_TRAINING_CHECKPOINT_REGISTRATION: OperationKind
OPERATION_KIND_EXPORT_CREDENTIAL_VALIDATION: OperationKind
OPERATION_KIND_INGEST_CONVERSION: OperationKind
OPERATION_KIND_PIPELINE_RUN: OperationKind
OPERATION_KIND_EXPORT: OperationKind
OPERATION_KIND_RETENTION: OperationKind
OPERATION_KIND_COMPACTION: OperationKind
OPERATION_KIND_REINDEX: OperationKind
OPERATION_KIND_CAPTURE: OperationKind
OPERATION_KIND_EVALUATION: OperationKind
OPERATION_KIND_GENERATION: OperationKind
OPERATION_KIND_SESSION: OperationKind
OPERATION_KIND_AUTHORING: OperationKind
OPERATION_KIND_TRAINING: OperationKind
OPERATION_KIND_PROGRAM: OperationKind
OPERATION_KIND_IMPROVEMENT: OperationKind
OPERATION_KIND_DEPLOYMENT: OperationKind
OPERATION_KIND_ROLLBACK: OperationKind
OPERATION_KIND_RESEARCH: OperationKind
OPERATION_KIND_WORKLOAD: OperationKind

class ProjectRef(_message.Message):
    __slots__ = ("organization_id", "project_id")
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    project_id: str
    def __init__(self, organization_id: _Optional[str] = ..., project_id: _Optional[str] = ...) -> None: ...

class ContentRef(_message.Message):
    __slots__ = ("artifact_id", "sha256")
    ARTIFACT_ID_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    artifact_id: str
    sha256: str
    def __init__(self, artifact_id: _Optional[str] = ..., sha256: _Optional[str] = ...) -> None: ...

class TaskContractRef(_message.Message):
    __slots__ = ("task_id", "schema_version", "sha256")
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_VERSION_FIELD_NUMBER: _ClassVar[int]
    SHA256_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    schema_version: str
    sha256: str
    def __init__(self, task_id: _Optional[str] = ..., schema_version: _Optional[str] = ..., sha256: _Optional[str] = ...) -> None: ...

class OperationRef(_message.Message):
    __slots__ = ("pillar", "kind", "operation_id")
    PILLAR_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    OPERATION_ID_FIELD_NUMBER: _ClassVar[int]
    pillar: PlatformPillar
    kind: OperationKind
    operation_id: str
    def __init__(self, pillar: _Optional[_Union[PlatformPillar, str]] = ..., kind: _Optional[_Union[OperationKind, str]] = ..., operation_id: _Optional[str] = ...) -> None: ...

class ResourceRef(_message.Message):
    __slots__ = ("owner", "kind", "id")
    OWNER_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    owner: str
    kind: str
    id: str
    def __init__(self, owner: _Optional[str] = ..., kind: _Optional[str] = ..., id: _Optional[str] = ...) -> None: ...

class RefusalDetail(_message.Message):
    __slots__ = ("code", "retryable", "resource", "trace_id", "retry_after")
    CODE_FIELD_NUMBER: _ClassVar[int]
    RETRYABLE_FIELD_NUMBER: _ClassVar[int]
    RESOURCE_FIELD_NUMBER: _ClassVar[int]
    TRACE_ID_FIELD_NUMBER: _ClassVar[int]
    RETRY_AFTER_FIELD_NUMBER: _ClassVar[int]
    code: str
    retryable: bool
    resource: ResourceRef
    trace_id: str
    retry_after: _duration_pb2.Duration
    def __init__(self, code: _Optional[str] = ..., retryable: _Optional[bool] = ..., resource: _Optional[_Union[ResourceRef, _Mapping]] = ..., trace_id: _Optional[str] = ..., retry_after: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...
