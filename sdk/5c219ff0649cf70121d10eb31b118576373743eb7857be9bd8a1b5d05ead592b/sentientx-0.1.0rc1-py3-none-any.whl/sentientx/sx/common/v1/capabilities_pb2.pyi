from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Capability(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CAPABILITY_UNSPECIFIED: _ClassVar[Capability]
    CAPABILITY_SPATIAL_MOTION_SE3: _ClassVar[Capability]
    CAPABILITY_PLANAR_MOTION_SE2: _ClassVar[Capability]
    CAPABILITY_GRASP: _ClassVar[Capability]
    CAPABILITY_GRASP_PARALLEL: _ClassVar[Capability]
    CAPABILITY_GRASP_DEXTEROUS: _ClassVar[Capability]
    CAPABILITY_LOCOMOTION_PLANAR: _ClassVar[Capability]
    CAPABILITY_LOCOMOTION_LEGGED: _ClassVar[Capability]
    CAPABILITY_SENSING_RGB: _ClassVar[Capability]
    CAPABILITY_SENSING_DEPTH: _ClassVar[Capability]
    CAPABILITY_SENSING_LIDAR: _ClassVar[Capability]
    CAPABILITY_SENSING_TACTILE: _ClassVar[Capability]
    CAPABILITY_SENSING_FORCE_TORQUE: _ClassVar[Capability]
CAPABILITY_UNSPECIFIED: Capability
CAPABILITY_SPATIAL_MOTION_SE3: Capability
CAPABILITY_PLANAR_MOTION_SE2: Capability
CAPABILITY_GRASP: Capability
CAPABILITY_GRASP_PARALLEL: Capability
CAPABILITY_GRASP_DEXTEROUS: Capability
CAPABILITY_LOCOMOTION_PLANAR: Capability
CAPABILITY_LOCOMOTION_LEGGED: Capability
CAPABILITY_SENSING_RGB: Capability
CAPABILITY_SENSING_DEPTH: Capability
CAPABILITY_SENSING_LIDAR: Capability
CAPABILITY_SENSING_TACTILE: Capability
CAPABILITY_SENSING_FORCE_TORQUE: Capability

class TaskRoleRequirement(_message.Message):
    __slots__ = ("role_id", "capabilities")
    ROLE_ID_FIELD_NUMBER: _ClassVar[int]
    CAPABILITIES_FIELD_NUMBER: _ClassVar[int]
    role_id: str
    capabilities: _containers.RepeatedScalarFieldContainer[Capability]
    def __init__(self, role_id: _Optional[str] = ..., capabilities: _Optional[_Iterable[_Union[Capability, str]]] = ...) -> None: ...

class TaskCapabilityRequirements(_message.Message):
    __slots__ = ("roles",)
    ROLES_FIELD_NUMBER: _ClassVar[int]
    roles: _containers.RepeatedCompositeFieldContainer[TaskRoleRequirement]
    def __init__(self, roles: _Optional[_Iterable[_Union[TaskRoleRequirement, _Mapping]]] = ...) -> None: ...

class TaskRoleBinding(_message.Message):
    __slots__ = ("role_id", "component_id")
    ROLE_ID_FIELD_NUMBER: _ClassVar[int]
    COMPONENT_ID_FIELD_NUMBER: _ClassVar[int]
    role_id: str
    component_id: str
    def __init__(self, role_id: _Optional[str] = ..., component_id: _Optional[str] = ...) -> None: ...
