from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TerminationReason(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TERMINATION_REASON_UNSPECIFIED: _ClassVar[TerminationReason]
    TERMINATION_REASON_SUCCESS: _ClassVar[TerminationReason]
    TERMINATION_REASON_FAILURE: _ClassVar[TerminationReason]
    TERMINATION_REASON_SAFETY_VIOLATION: _ClassVar[TerminationReason]
    TERMINATION_REASON_MAX_STEPS: _ClassVar[TerminationReason]
    TERMINATION_REASON_STOPPED: _ClassVar[TerminationReason]
    TERMINATION_REASON_POLICY_FAILURE: _ClassVar[TerminationReason]

class TaskVerdict(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TASK_VERDICT_UNSPECIFIED: _ClassVar[TaskVerdict]
    TASK_VERDICT_SATISFIED: _ClassVar[TaskVerdict]
    TASK_VERDICT_NOT_SATISFIED: _ClassVar[TaskVerdict]
    TASK_VERDICT_UNKNOWN: _ClassVar[TaskVerdict]
TERMINATION_REASON_UNSPECIFIED: TerminationReason
TERMINATION_REASON_SUCCESS: TerminationReason
TERMINATION_REASON_FAILURE: TerminationReason
TERMINATION_REASON_SAFETY_VIOLATION: TerminationReason
TERMINATION_REASON_MAX_STEPS: TerminationReason
TERMINATION_REASON_STOPPED: TerminationReason
TERMINATION_REASON_POLICY_FAILURE: TerminationReason
TASK_VERDICT_UNSPECIFIED: TaskVerdict
TASK_VERDICT_SATISFIED: TaskVerdict
TASK_VERDICT_NOT_SATISFIED: TaskVerdict
TASK_VERDICT_UNKNOWN: TaskVerdict

class TerminatedEpisode(_message.Message):
    __slots__ = ("reason", "verdict")
    REASON_FIELD_NUMBER: _ClassVar[int]
    VERDICT_FIELD_NUMBER: _ClassVar[int]
    reason: TerminationReason
    verdict: TaskVerdict
    def __init__(self, reason: _Optional[_Union[TerminationReason, str]] = ..., verdict: _Optional[_Union[TaskVerdict, str]] = ...) -> None: ...

class TruncatedEpisode(_message.Message):
    __slots__ = ("reason", "verdict")
    REASON_FIELD_NUMBER: _ClassVar[int]
    VERDICT_FIELD_NUMBER: _ClassVar[int]
    reason: TerminationReason
    verdict: TaskVerdict
    def __init__(self, reason: _Optional[_Union[TerminationReason, str]] = ..., verdict: _Optional[_Union[TaskVerdict, str]] = ...) -> None: ...

class EpisodeEnd(_message.Message):
    __slots__ = ("terminated", "truncated")
    TERMINATED_FIELD_NUMBER: _ClassVar[int]
    TRUNCATED_FIELD_NUMBER: _ClassVar[int]
    terminated: TerminatedEpisode
    truncated: TruncatedEpisode
    def __init__(self, terminated: _Optional[_Union[TerminatedEpisode, _Mapping]] = ..., truncated: _Optional[_Union[TruncatedEpisode, _Mapping]] = ...) -> None: ...
