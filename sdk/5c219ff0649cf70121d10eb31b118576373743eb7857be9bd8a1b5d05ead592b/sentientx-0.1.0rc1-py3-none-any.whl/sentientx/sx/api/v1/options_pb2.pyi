from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import descriptor_pb2 as _descriptor_pb2
from sentientx.sx.common.v1 import common_pb2 as _common_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PublicProjection(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PUBLIC_PROJECTION_UNSPECIFIED: _ClassVar[PublicProjection]
    PUBLIC_PROJECTION_COMMON: _ClassVar[PublicProjection]
    PUBLIC_PROJECTION_ADVANCED: _ClassVar[PublicProjection]
PUBLIC_PROJECTION_UNSPECIFIED: PublicProjection
PUBLIC_PROJECTION_COMMON: PublicProjection
PUBLIC_PROJECTION_ADVANCED: PublicProjection
METHOD_POLICY_FIELD_NUMBER: _ClassVar[int]
method_policy: _descriptor.FieldDescriptor

class MethodPolicy(_message.Message):
    __slots__ = ("surface", "projection", "rate_class", "operation_kind")
    SURFACE_FIELD_NUMBER: _ClassVar[int]
    PROJECTION_FIELD_NUMBER: _ClassVar[int]
    RATE_CLASS_FIELD_NUMBER: _ClassVar[int]
    OPERATION_KIND_FIELD_NUMBER: _ClassVar[int]
    surface: str
    projection: PublicProjection
    rate_class: str
    operation_kind: _common_pb2.OperationKind
    def __init__(self, surface: _Optional[str] = ..., projection: _Optional[_Union[PublicProjection, str]] = ..., rate_class: _Optional[str] = ..., operation_kind: _Optional[_Union[_common_pb2.OperationKind, str]] = ...) -> None: ...
