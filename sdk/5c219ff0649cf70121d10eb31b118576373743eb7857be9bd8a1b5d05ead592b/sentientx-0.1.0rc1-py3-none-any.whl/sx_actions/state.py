"""The canonical meaning and ordering of an observation state vector."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import cast

from sx_contracts import Capability, ComponentId, decode
from sx_contracts.identity import JsonValue, content_id
from sx_contracts.identity import canonical_json as canonical_document
from sx_contracts.wire import HexDigest
from sx_embodiments import (
    Bounds,
    ChannelKind,
    CoordinateBounds,
    CoordinateUnit,
    Embodiment,
    EmbodimentId,
    Unbounded,
)

from .contract import (
    ActionChannelKind,
    ActionCoordinateId,
    RotationRepresentation,
    native_coordinate_id,
)

STATE_INTERFACE_SCHEMA_VERSION = 2


class StateInterfaceError(ValueError):
    """A state interface does not describe a readable body-state vector."""


class StateInterfaceId(HexDigest):
    """The lowercase SHA-256 of one complete state-interface document."""

    error = StateInterfaceError
    noun = "state interface id"


@dataclass(frozen=True, slots=True)
class JointCoordinate:
    component_id: ComponentId
    coordinate_id: ActionCoordinateId
    kind: ActionChannelKind
    unit: CoordinateUnit
    bounds: CoordinateBounds

    def __post_init__(self) -> None:
        if self.kind not in {
            ActionChannelKind.ARM_JOINT,
            ActionChannelKind.BODY_JOINT,
            ActionChannelKind.BASE,
        }:
            raise StateInterfaceError("joint coordinates need an arm, body, or base kind")

    @property
    def width(self) -> int:
        return 1


@dataclass(frozen=True, slots=True)
class Translation3:
    component_id: ComponentId
    frame: str

    def __post_init__(self) -> None:
        if not self.frame.strip():
            raise StateInterfaceError("translation state needs a non-empty frame")

    @property
    def width(self) -> int:
        return 3


@dataclass(frozen=True, slots=True)
class Rotation:
    component_id: ComponentId
    frame: str
    representation: RotationRepresentation

    def __post_init__(self) -> None:
        if not self.frame.strip():
            raise StateInterfaceError("rotation state needs a non-empty frame")

    @property
    def width(self) -> int:
        return self.representation.width


@dataclass(frozen=True, slots=True)
class GripperDrive:
    component_id: ComponentId
    coordinate_id: ActionCoordinateId
    unit: CoordinateUnit
    bounds: CoordinateBounds

    @property
    def width(self) -> int:
        return 1


@dataclass(frozen=True, slots=True)
class GripperAperture:
    component_id: ComponentId

    @property
    def width(self) -> int:
        return 1


StateField = JointCoordinate | Translation3 | Rotation | GripperDrive | GripperAperture


@dataclass(frozen=True, slots=True)
class StateInterface:
    """An ordered, typed state vector for one exact embodiment revision."""

    embodiment_id: EmbodimentId
    fields: tuple[StateField, ...]
    schema_version: int = STATE_INTERFACE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != STATE_INTERFACE_SCHEMA_VERSION:
            raise StateInterfaceError(f"unsupported state interface version: {self.schema_version}")
        if not self.fields:
            raise StateInterfaceError("a state interface needs at least one field")
        identities = tuple(_field_identity(field) for field in self.fields)
        if len(identities) != len(set(identities)):
            raise StateInterfaceError("state interface fields must be unique")

    @property
    def width(self) -> int:
        return sum(field.width for field in self.fields)

    @property
    def id(self) -> StateInterfaceId:
        return content_id(StateInterfaceId, _content_dict(self))

    def indices(self, kind: ActionChannelKind) -> tuple[int, ...]:
        positions: list[int] = []
        offset = 0
        for field in self.fields:
            if _field_kind(field) is kind:
                positions.extend(range(offset, offset + field.width))
            offset += field.width
        return tuple(positions)

    def field_span(self, field: StateField) -> range:
        offset = 0
        for candidate in self.fields:
            stop = offset + candidate.width
            if candidate is field:
                return range(offset, stop)
            offset = stop
        raise StateInterfaceError("state field does not belong to this interface")

    def field_at(self, position: int) -> StateField:
        """Return the semantic field owning one dense-vector position."""

        if isinstance(position, bool) or position < 0 or position >= self.width:
            raise StateInterfaceError(f"state position {position!r} is outside this interface")
        offset = 0
        for field in self.fields:
            if position < offset + field.width:
                return field
            offset += field.width
        raise StateInterfaceError(f"state position {position!r} is outside this interface")

    def unit_at(self, position: int) -> CoordinateUnit:
        """The physical unit of one dense-vector position, derived from its field."""

        field = self.field_at(position)
        if isinstance(field, (JointCoordinate, GripperDrive)):
            return field.unit
        if isinstance(field, Translation3):
            return CoordinateUnit.METER
        if isinstance(field, Rotation):
            return (
                CoordinateUnit.UNITLESS
                if field.representation is RotationRepresentation.QUATERNION_WXYZ
                else CoordinateUnit.RADIAN
            )
        return CoordinateUnit.METER


def _field_identity(field: StateField) -> tuple[object, ...]:
    if isinstance(field, (JointCoordinate, GripperDrive)):
        return type(field), field.component_id, field.coordinate_id
    if isinstance(field, (Translation3, Rotation)):
        return type(field), field.component_id, field.frame
    return type(field), field.component_id


def _field_kind(field: StateField) -> ActionChannelKind:
    if isinstance(field, JointCoordinate):
        return field.kind
    if isinstance(field, Translation3):
        return ActionChannelKind.EEF_TRANSLATION
    if isinstance(field, Rotation):
        return ActionChannelKind.EEF_ROTATION
    return ActionChannelKind.GRIPPER


def _bounds_dict(bounds: CoordinateBounds) -> dict[str, JsonValue]:
    if isinstance(bounds, Bounds):
        return {"kind": "bounded", "lower": bounds.lower, "upper": bounds.upper}
    return {"kind": "unbounded"}


def _field_dict(field: StateField) -> dict[str, JsonValue]:
    if isinstance(field, JointCoordinate):
        return {
            "kind": "joint_coordinate",
            "component_id": str(field.component_id),
            "coordinate_id": str(field.coordinate_id),
            "coordinate_kind": field.kind.value,
            "unit": field.unit.value,
            "bounds": _bounds_dict(field.bounds),
        }
    if isinstance(field, Translation3):
        return {
            "kind": "translation3",
            "component_id": str(field.component_id),
            "frame": field.frame,
        }
    if isinstance(field, Rotation):
        return {
            "kind": "rotation",
            "component_id": str(field.component_id),
            "frame": field.frame,
            "representation": field.representation.value,
        }
    if isinstance(field, GripperDrive):
        return {
            "kind": "gripper_drive",
            "component_id": str(field.component_id),
            "coordinate_id": str(field.coordinate_id),
            "unit": field.unit.value,
            "bounds": _bounds_dict(field.bounds),
        }
    return {"kind": "gripper_aperture", "component_id": str(field.component_id)}


def _content_dict(interface: StateInterface) -> dict[str, JsonValue]:
    return {
        "schema_version": interface.schema_version,
        "embodiment_id": str(interface.embodiment_id),
        "fields": [_field_dict(field) for field in interface.fields],
    }


def canonical_json(interface: StateInterface) -> str:
    return canonical_document(_content_dict(interface))


def state_interface_to_dict(interface: StateInterface) -> dict[str, object]:
    return {"id": str(interface.id), **_content_dict(interface)}


def state_interface_from_dict(document: Mapping[str, object]) -> StateInterface:
    _exact_keys(document, {"id", "schema_version", "embodiment_id", "fields"}, "state interface")
    version = document["schema_version"]
    if isinstance(version, bool) or version != STATE_INTERFACE_SCHEMA_VERSION:
        raise StateInterfaceError(f"unsupported state interface version: {version!r}")
    raw_fields = document["fields"]
    if not isinstance(raw_fields, list):
        raise StateInterfaceError("state interface fields must be a list")
    interface = StateInterface(
        EmbodimentId(_string(document, "embodiment_id", "state interface")),
        tuple(
            _parse_field(item, offset) for offset, item in enumerate(cast(list[object], raw_fields))
        ),
    )
    try:
        expected_id = StateInterfaceId(_string(document, "id", "state interface"))
    except ValueError as exc:
        raise StateInterfaceError(f"invalid state interface id: {exc}") from exc
    if interface.id != expected_id:
        raise StateInterfaceError("state interface id does not match its canonical content")
    return interface


def _parse_field(raw: object, offset: int) -> StateField:
    label = f"fields[{offset}]"
    if not isinstance(raw, Mapping):
        raise StateInterfaceError(f"{label} must be a mapping")
    entry = cast(Mapping[str, object], raw)
    kind = _string(entry, "kind", label)
    try:
        if kind == "joint_coordinate":
            _exact_keys(
                entry,
                {"kind", "component_id", "coordinate_id", "coordinate_kind", "unit", "bounds"},
                label,
            )
            return JointCoordinate(
                ComponentId(_string(entry, "component_id", label)),
                ActionCoordinateId(_string(entry, "coordinate_id", label)),
                ActionChannelKind(_string(entry, "coordinate_kind", label)),
                CoordinateUnit(_string(entry, "unit", label)),
                _parse_bounds(entry["bounds"], label),
            )
        if kind == "translation3":
            _exact_keys(entry, {"kind", "component_id", "frame"}, label)
            return Translation3(
                ComponentId(_string(entry, "component_id", label)),
                _string(entry, "frame", label),
            )
        if kind == "rotation":
            _exact_keys(entry, {"kind", "component_id", "frame", "representation"}, label)
            return Rotation(
                ComponentId(_string(entry, "component_id", label)),
                _string(entry, "frame", label),
                RotationRepresentation(_string(entry, "representation", label)),
            )
        if kind == "gripper_drive":
            _exact_keys(entry, {"kind", "component_id", "coordinate_id", "unit", "bounds"}, label)
            return GripperDrive(
                ComponentId(_string(entry, "component_id", label)),
                ActionCoordinateId(_string(entry, "coordinate_id", label)),
                CoordinateUnit(_string(entry, "unit", label)),
                _parse_bounds(entry["bounds"], label),
            )
        if kind == "gripper_aperture":
            _exact_keys(entry, {"kind", "component_id"}, label)
            return GripperAperture(ComponentId(_string(entry, "component_id", label)))
    except ValueError as exc:
        raise StateInterfaceError(f"unknown state-field vocabulary: {exc}") from exc
    raise StateInterfaceError(f"unknown state-field variant: {kind!r}")


def _parse_bounds(raw: object, label: str) -> CoordinateBounds:
    if not isinstance(raw, Mapping):
        raise StateInterfaceError(f"{label}.bounds must be a mapping")
    bounds = cast(Mapping[str, object], raw)
    kind = _string(bounds, "kind", f"{label}.bounds")
    if kind == "unbounded":
        _exact_keys(bounds, {"kind"}, f"{label}.bounds")
        return Unbounded()
    if kind == "bounded":
        _exact_keys(bounds, {"kind", "lower", "upper"}, f"{label}.bounds")
        return Bounds(
            decode.number(bounds, "lower", where=f"{label}.bounds", error=StateInterfaceError),
            decode.number(bounds, "upper", where=f"{label}.bounds", error=StateInterfaceError),
        )
    raise StateInterfaceError(f"unknown bounds variant: {kind!r}")


def joint_state(embodiment: Embodiment) -> StateInterface:
    """The embodiment's native state order, derived from its canonical layout."""

    fields: list[StateField] = []
    for coordinate in embodiment.state.coordinates:
        component_id = ComponentId(coordinate.instance)
        coordinate_id = native_coordinate_id(coordinate.joint_name)
        if coordinate.kind is ChannelKind.GRIPPER:
            fields.append(
                GripperDrive(component_id, coordinate_id, coordinate.unit, coordinate.axis.bounds)
            )
        else:
            fields.append(
                JointCoordinate(
                    component_id,
                    coordinate_id,
                    ActionChannelKind(coordinate.kind.value),
                    coordinate.unit,
                    coordinate.axis.bounds,
                )
            )
    return StateInterface(embodiment.id, tuple(fields))


def end_effector_state(
    embodiment: Embodiment,
    *,
    effector_id: ComponentId,
    frame: str,
    rotation: RotationRepresentation = RotationRepresentation.QUATERNION_WXYZ,
) -> StateInterface:
    """Tool-frame translation and rotation followed by that tool's jaw aperture."""

    components = {component.component_id: component for component in embodiment.components}
    component = components.get(effector_id)
    if component is None:
        raise StateInterfaceError(f"end-effector component {effector_id!r} is absent")
    if not all(
        capability in component.capabilities
        for capability in (Capability.SPATIAL_MOTION_SE3, Capability.GRASP)
    ):
        raise StateInterfaceError(
            f"end-effector component {effector_id!r} needs spatial motion and grasp capabilities"
        )
    return StateInterface(
        embodiment.id,
        (
            Translation3(effector_id, frame),
            Rotation(effector_id, frame, rotation),
            GripperAperture(effector_id),
        ),
    )


def _exact_keys(document: Mapping[str, object], expected: set[str], label: str) -> None:
    actual = set(document)
    if actual != expected:
        raise StateInterfaceError(
            f"{label} keys differ: missing={sorted(expected - actual)}, "
            f"unknown={sorted(actual - expected)}"
        )


def _string(document: Mapping[str, object], key: str, label: str) -> str:
    value = document.get(key)
    if not isinstance(value, str):
        raise StateInterfaceError(f"{label}.{key} must be a string")
    return value
