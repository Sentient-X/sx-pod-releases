"""The one canonical, content-addressed robot action interface."""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from typing import TYPE_CHECKING, NewType, cast

import numpy as np
from sx_contracts import Capability, ComponentId, decode
from sx_contracts.identity import JsonValue, content_id
from sx_contracts.identity import canonical_json as canonical_document
from sx_contracts.wire import HexDigest, WireString
from sx_embodiments import Bounds, ChannelKind, CoordinateUnit, Embodiment, EmbodimentId

from .shapes import ActionVector

if TYPE_CHECKING:
    from .values import Action

ACTION_INTERFACE_SCHEMA_VERSION = 6
ActionInterfaceName = NewType("ActionInterfaceName", str)

_MAX_EXACT_FLOAT_INTEGER = float(2**53)
"""Above this every float is an integer, so integrality stops proving exactness."""


class ActionInterfaceError(ValueError):
    """An action interface cannot be constructed or parsed exactly."""


class ActionEmbodimentMismatchError(ActionInterfaceError):
    """An action interface names structure absent from its exact embodiment."""


class ActionCoordinateId(WireString):
    """Coordinate identity local to one embodiment component."""

    def __new__(cls, value: str) -> ActionCoordinateId:
        if not value.strip() or any(char.isspace() for char in value) or "/" in value:
            raise ActionInterfaceError(
                f"action coordinate id must be non-empty, local, and contain no spaces: {value!r}"
            )
        return str.__new__(cls, value)


def native_coordinate_id(joint_name: str) -> ActionCoordinateId:
    """Project a vendor-qualified native joint name into its component-local identity."""

    return ActionCoordinateId(joint_name.rsplit("/", 1)[-1])


class ActionInterfaceId(HexDigest):
    """The lowercase SHA-256 of one complete action-interface document."""

    error = ActionInterfaceError
    noun = "action interface id"


class ActionSpace(StrEnum):
    """A derived presentation of the command groups, never stored in the contract."""

    JOINT = "joint"
    END_EFFECTOR = "end_effector"
    COMPOSITE = "composite"


class ActionMode(StrEnum):
    """A derived presentation of group reference semantics."""

    ABSOLUTE = "absolute"
    DELTA_FROM_TARGET = "delta_from_target"
    DELTA_FROM_POSITION = "delta_from_position"
    MIXED = "mixed"


class ActionNormalization(StrEnum):
    """What the numbers on the wire mean against the channels' declared bounds."""

    PHYSICAL = "physical"
    """Commands are the channels' own units, inside the channels' own bounds."""
    NEGATIVE_ONE_TO_ONE = "negative_one_to_one"
    """Commands are dimensionless ``[-1, 1]``; each channel's unit and bounds describe the
    physical command its controller denormalizes ``±1`` into. The legal wire values are
    :attr:`ActionInterface.command_box`, NEVER the channels' bounds — reading those as the
    wire attenuates every command by the controller's own output scale."""


class ActionSemanticType(StrEnum):
    """A derived presentation used by capability-sized consumers."""

    JOINT_POSITION_TARGET = "joint_position_target"
    JOINT_VELOCITY_TARGET = "joint_velocity_target"
    JOINT_TORQUE_TARGET = "joint_torque_target"
    END_EFFECTOR_POSE_TARGET = "end_effector_pose_target"
    END_EFFECTOR_DELTA_POSE = "end_effector_delta_pose"
    GRIPPER_POSITION_TARGET = "gripper_position_target"
    GRIPPER_DELTA_COMMAND = "gripper_delta_command"
    GRIPPER_VELOCITY_TARGET = "gripper_velocity_target"
    GRIPPER_FORCE_TARGET = "gripper_force_target"
    CONTROL_MODE = "control_mode"
    COMPOSITE_COMMAND = "composite_command"


class ActionChannelKind(StrEnum):
    ARM_JOINT = "arm_joint"
    BODY_JOINT = "body_joint"
    GRIPPER = "gripper"
    BASE = "base"
    EEF_TRANSLATION = "eef_translation"
    EEF_ROTATION = "eef_rotation"
    MODE = "mode"


class RotationRepresentation(StrEnum):
    EULER_XYZ = "euler_xyz"
    AXIS_ANGLE = "axis_angle"
    QUATERNION_WXYZ = "quaternion_wxyz"

    @property
    def width(self) -> int:
        return 4 if self is RotationRepresentation.QUATERNION_WXYZ else 3


class JointCommandKind(StrEnum):
    POSITION = "position"
    VELOCITY = "velocity"
    TORQUE = "torque"


class ReferenceMode(StrEnum):
    ABSOLUTE = "absolute"
    DELTA_FROM_TARGET = "delta_from_target"
    DELTA_FROM_POSITION = "delta_from_position"


class CartesianTargetKind(StrEnum):
    ABSOLUTE_POSE = "absolute_pose"
    DELTA_FROM_TARGET = "delta_from_target"
    DELTA_FROM_POSITION = "delta_from_position"


class GripperCommandKind(StrEnum):
    POSITION = "position"
    DELTA_POSITION = "delta_position"
    VELOCITY = "velocity"
    FORCE = "force"


@dataclass(frozen=True, slots=True)
class CommandCoordinate:
    """One bounded command coordinate; tuple position is its vector position."""

    component_id: ComponentId
    coordinate_id: ActionCoordinateId
    kind: ActionChannelKind
    unit: CoordinateUnit
    bounds: Bounds

    def __post_init__(self) -> None:
        if not str(self.component_id).strip() or not str(self.coordinate_id).strip():
            raise ActionInterfaceError(
                "command coordinate component and coordinate must not be empty"
            )

    @property
    def lower(self) -> float:
        return self.bounds.lower

    @property
    def upper(self) -> float:
        return self.bounds.upper


def _coordinates(
    coordinates: tuple[CommandCoordinate, ...],
    *,
    label: str,
    allowed: frozenset[ActionChannelKind],
) -> None:
    if not coordinates:
        raise ActionInterfaceError(f"{label} needs at least one coordinate")
    if any(coordinate.kind not in allowed for coordinate in coordinates):
        kinds = sorted(
            {coordinate.kind.value for coordinate in coordinates} - {k.value for k in allowed}
        )
        raise ActionInterfaceError(f"{label} contains unsupported coordinate kinds: {kinds}")
    names = tuple((coordinate.component_id, coordinate.coordinate_id) for coordinate in coordinates)
    if len(names) != len(set(names)):
        raise ActionInterfaceError(f"{label} component-coordinate pairs must be unique")


@dataclass(frozen=True, slots=True)
class JointCommands:
    command_kind: JointCommandKind
    reference_mode: ReferenceMode
    coordinates: tuple[CommandCoordinate, ...]

    def __post_init__(self) -> None:
        _coordinates(
            self.coordinates,
            label="joint commands",
            allowed=frozenset(
                {
                    ActionChannelKind.ARM_JOINT,
                    ActionChannelKind.BODY_JOINT,
                    ActionChannelKind.BASE,
                }
            ),
        )
        if (
            self.command_kind is not JointCommandKind.POSITION
            and self.reference_mode is not ReferenceMode.ABSOLUTE
        ):
            raise ActionInterfaceError(
                "velocity and torque commands must use absolute reference mode"
            )


@dataclass(frozen=True, slots=True)
class CartesianCommands:
    target_kind: CartesianTargetKind
    frame: str
    rotation: RotationRepresentation
    coordinates: tuple[CommandCoordinate, ...]

    def __post_init__(self) -> None:
        if not self.frame.strip():
            raise ActionInterfaceError("Cartesian commands need a non-empty frame")
        _coordinates(
            self.coordinates,
            label="Cartesian commands",
            allowed=frozenset({ActionChannelKind.EEF_TRANSLATION, ActionChannelKind.EEF_ROTATION}),
        )
        components = {coordinate.component_id for coordinate in self.coordinates}
        if len(components) != 1:
            raise ActionInterfaceError("one Cartesian command group must address one component")
        translation = tuple(
            coordinate
            for coordinate in self.coordinates
            if coordinate.kind is ActionChannelKind.EEF_TRANSLATION
        )
        rotation = tuple(
            coordinate
            for coordinate in self.coordinates
            if coordinate.kind is ActionChannelKind.EEF_ROTATION
        )
        if len(translation) != 3 or len(rotation) != self.rotation.width:
            raise ActionInterfaceError(
                "Cartesian commands need 3 translation and "
                f"{self.rotation.width} rotation coordinates"
            )
        if self.coordinates != translation + rotation:
            raise ActionInterfaceError(
                "Cartesian coordinates must be translation followed by rotation"
            )

    @property
    def component_id(self) -> ComponentId:
        return self.coordinates[0].component_id


@dataclass(frozen=True, slots=True)
class GripperCommands:
    command_kind: GripperCommandKind
    coordinates: tuple[CommandCoordinate, ...]

    def __post_init__(self) -> None:
        _coordinates(
            self.coordinates,
            label="gripper commands",
            allowed=frozenset({ActionChannelKind.GRIPPER}),
        )


@dataclass(frozen=True, slots=True)
class ControlModeCommands:
    coordinates: tuple[CommandCoordinate, ...]

    def __post_init__(self) -> None:
        _coordinates(
            self.coordinates,
            label="control-mode commands",
            allowed=frozenset({ActionChannelKind.MODE}),
        )


CommandGroup = JointCommands | CartesianCommands | GripperCommands | ControlModeCommands


@dataclass(frozen=True, slots=True, eq=False)
class CommandBox:
    """The values one interface accepts on its wire, in channel order.

    The ONE definition, because the box is not always the channels' bounds: a
    :attr:`ActionNormalization.PHYSICAL` interface commands in the channels' own units,
    so the box *is* those bounds, while a
    :attr:`ActionNormalization.NEGATIVE_ONE_TO_ONE` interface commands a dimensionless
    ``[-1, 1]`` that its controller denormalizes into them. Every consumer that
    saturates, samples, or bands a command asks the interface for this instead of
    rebuilding it from ``channels``, which is how a normalized wire gets read as a
    physical one.
    """

    lower: ActionVector
    upper: ActionVector

    def saturate(self, values: ActionVector) -> ActionVector:
        """Clip a proposal into the box — the command the controller applies anyway.

        A policy emits a *proposal*, not a promise: a regression head routinely predicts
        outside the range it was fit on, and the controller clips before it scales.
        Saturating here keeps recorded equal to executed instead of refusing the episode.
        """

        return np.clip(np.asarray(values, dtype=np.float64), self.lower, self.upper)


@dataclass(frozen=True, slots=True)
class ActionInterface:
    """One complete controller vector, grouped by truthful command semantics."""

    embodiment_id: EmbodimentId
    normalization: ActionNormalization
    control_hz: float
    groups: tuple[CommandGroup, ...]
    schema_version: int = ACTION_INTERFACE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != ACTION_INTERFACE_SCHEMA_VERSION:
            raise ActionInterfaceError(
                f"unsupported action interface version: {self.schema_version}"
            )
        if not math.isfinite(self.control_hz) or self.control_hz <= 0.0:
            raise ActionInterfaceError("action interface control_hz must be positive and finite")
        if not self.groups:
            raise ActionInterfaceError("action interface needs at least one command group")
        coordinates = tuple(
            (coordinate.component_id, coordinate.coordinate_id) for coordinate in self.channels
        )
        if len(coordinates) != len(set(coordinates)):
            raise ActionInterfaceError(
                "action interface component-coordinate pairs must be globally unique"
            )

    @property
    def id(self) -> ActionInterfaceId:
        return content_id(ActionInterfaceId, _semantic_dict(self))

    @property
    def channels(self) -> tuple[CommandCoordinate, ...]:
        """The ordered dense-vector projection derived from the command groups."""

        return tuple(coordinate for group in self.groups for coordinate in group.coordinates)

    @property
    def width(self) -> int:
        return len(self.channels)

    @property
    def control_period_ns(self) -> int:
        """The exact integer-nanosecond period for uniformly timed controller artifacts.

        Exactness is decided on the quotient itself rather than a tolerance: a float
        period is integral or it is not, and above ``2**53`` every float is integral, so
        the question stops being meaningful and the rate is refused instead of believed.
        A rate small enough to overflow the division (``1e-300`` Hz) lands on ``inf``,
        which is not integral, so it refuses here rather than raising ``OverflowError``
        past every caller that catches this module's own error type.
        """
        period = 1_000_000_000.0 / self.control_hz
        if not period.is_integer() or not 0.0 < period <= _MAX_EXACT_FLOAT_INTEGER:
            raise ActionInterfaceError(
                f"control rate {self.control_hz:g} Hz has no integral nanosecond period"
            )
        return int(period)

    @property
    def command_box(self) -> CommandBox:
        """The legal values on this wire — exactly what :meth:`action` enforces."""

        if self.normalization is ActionNormalization.NEGATIVE_ONE_TO_ONE:
            return CommandBox(np.full(self.width, -1.0), np.full(self.width, 1.0))
        return CommandBox(
            np.asarray([coordinate.lower for coordinate in self.channels], dtype=np.float64),
            np.asarray([coordinate.upper for coordinate in self.channels], dtype=np.float64),
        )

    @property
    def cartesian_groups(self) -> tuple[CartesianCommands, ...]:
        return tuple(group for group in self.groups if isinstance(group, CartesianCommands))

    @property
    def space(self) -> ActionSpace:
        non_gripper = tuple(
            group for group in self.groups if not isinstance(group, GripperCommands)
        )
        if non_gripper and all(isinstance(group, JointCommands) for group in non_gripper):
            return ActionSpace.JOINT
        if len(non_gripper) == 1 and isinstance(non_gripper[0], CartesianCommands):
            return ActionSpace.END_EFFECTOR
        return ActionSpace.COMPOSITE

    @property
    def semantic_type(self) -> ActionSemanticType:
        primary = tuple(group for group in self.groups if not isinstance(group, GripperCommands))
        if len(primary) == 1:
            return _group_semantic_type(primary[0])
        if not primary and len(self.groups) == 1:
            return _group_semantic_type(self.groups[0])
        return ActionSemanticType.COMPOSITE_COMMAND

    @property
    def mode(self) -> ActionMode:
        primary = tuple(group for group in self.groups if not isinstance(group, GripperCommands))
        selected = primary if primary else self.groups
        modes = {_group_mode(group) for group in selected}
        return next(iter(modes)) if len(modes) == 1 else ActionMode.MIXED

    @property
    def command_frame(self) -> str:
        return self.cartesian_groups[0].frame if len(self.cartesian_groups) == 1 else ""

    @property
    def rotation(self) -> RotationRepresentation | None:
        return self.cartesian_groups[0].rotation if len(self.cartesian_groups) == 1 else None

    def positions(self, kind: ActionChannelKind) -> tuple[int, ...]:
        return tuple(
            index for index, coordinate in enumerate(self.channels) if coordinate.kind is kind
        )

    def group_span(self, group: CommandGroup) -> range:
        offset = 0
        for candidate in self.groups:
            stop = offset + len(candidate.coordinates)
            if candidate is group:
                return range(offset, stop)
            offset = stop
        raise ActionInterfaceError("command group does not belong to this interface")

    def action(self, values: ActionVector) -> Action:
        """Validate the complete vector before producing an immutable bound action."""

        from .values import Action

        return Action(self, values)

    def validate_values(self, values: ActionVector) -> ActionVector:
        # The declared type is a promise, not a fact: `Action` is the boundary untyped
        # policy code reaches, so the array-ness is checked rather than assumed. Without
        # this, a list reaches `.ndim` and raises an `AttributeError` no caller catches.
        if not isinstance(cast(object, values), np.ndarray):
            raise ActionInterfaceError("action values must be a numpy array")
        if values.ndim != 1 or values.shape != (self.width,):
            raise ActionInterfaceError(
                f"action values must have shape ({self.width},), got {values.shape}"
            )
        if not np.issubdtype(values.dtype, np.floating):
            raise ActionInterfaceError("action values must have a floating-point dtype")
        if not bool(np.isfinite(values).all()):
            raise ActionInterfaceError("action values must be finite")
        checked = np.array(values, copy=True)
        box = self.command_box
        lower, upper = box.lower, box.upper
        # Float32 round-trips can land a few ulps outside a decimal endpoint. The tolerance is
        # numerical representation, not a semantic safety margin; larger violations still fail.
        invalid = np.flatnonzero((checked < lower - 1e-6) | (checked > upper + 1e-6))
        if invalid.size:
            index = int(invalid[0])
            coordinate = self.channels[index]
            raise ActionInterfaceError(
                f"action {coordinate.component_id}/{coordinate.coordinate_id} value "
                f"{float(checked[index]):g} is outside [{lower[index]:g}, {upper[index]:g}]"
            )
        checked.setflags(write=False)
        return checked


def _group_semantic_type(group: CommandGroup) -> ActionSemanticType:
    if isinstance(group, JointCommands):
        return {
            JointCommandKind.POSITION: ActionSemanticType.JOINT_POSITION_TARGET,
            JointCommandKind.VELOCITY: ActionSemanticType.JOINT_VELOCITY_TARGET,
            JointCommandKind.TORQUE: ActionSemanticType.JOINT_TORQUE_TARGET,
        }[group.command_kind]
    if isinstance(group, CartesianCommands):
        return (
            ActionSemanticType.END_EFFECTOR_POSE_TARGET
            if group.target_kind is CartesianTargetKind.ABSOLUTE_POSE
            else ActionSemanticType.END_EFFECTOR_DELTA_POSE
        )
    if isinstance(group, GripperCommands):
        return {
            GripperCommandKind.POSITION: ActionSemanticType.GRIPPER_POSITION_TARGET,
            GripperCommandKind.DELTA_POSITION: ActionSemanticType.GRIPPER_DELTA_COMMAND,
            GripperCommandKind.VELOCITY: ActionSemanticType.GRIPPER_VELOCITY_TARGET,
            GripperCommandKind.FORCE: ActionSemanticType.GRIPPER_FORCE_TARGET,
        }[group.command_kind]
    return ActionSemanticType.CONTROL_MODE


def _group_mode(group: CommandGroup) -> ActionMode:
    if isinstance(group, JointCommands):
        return ActionMode(group.reference_mode.value)
    if isinstance(group, CartesianCommands):
        if group.target_kind is CartesianTargetKind.ABSOLUTE_POSE:
            return ActionMode.ABSOLUTE
        return ActionMode(group.target_kind.value)
    if (
        isinstance(group, GripperCommands)
        and group.command_kind is GripperCommandKind.DELTA_POSITION
    ):
        return ActionMode.DELTA_FROM_TARGET
    return ActionMode.ABSOLUTE


def validate_for_embodiment(interface: ActionInterface, embodiment: Embodiment) -> ActionInterface:
    """Prove that every command group is meaningful on the exact embodiment revision."""

    if interface.embodiment_id != embodiment.id:
        raise ActionEmbodimentMismatchError("action interface does not match the exact embodiment")
    native = {
        (coordinate.instance, native_coordinate_id(coordinate.joint_name)): coordinate
        for coordinate in embodiment.state.coordinates
    }
    components = {component.component_id: component for component in embodiment.components}
    for group in interface.groups:
        for coordinate in group.coordinates:
            component = components.get(coordinate.component_id)
            if component is None:
                raise ActionEmbodimentMismatchError(
                    f"action coordinate {coordinate.component_id}/{coordinate.coordinate_id} "
                    "names an absent component"
                )
            if isinstance(group, JointCommands):
                declared = native.get((coordinate.component_id, coordinate.coordinate_id))
                if declared is None:
                    if (
                        group.command_kind is JointCommandKind.POSITION
                        and group.reference_mode is ReferenceMode.ABSOLUTE
                    ):
                        raise ActionEmbodimentMismatchError(
                            f"action coordinate {coordinate.component_id}/"
                            f"{coordinate.coordinate_id} is absent from the embodiment state space"
                        )
                    if (
                        coordinate.kind is ActionChannelKind.BASE
                        and Capability.PLANAR_MOTION_SE2 not in component.capabilities
                    ):
                        raise ActionEmbodimentMismatchError(
                            f"base component {coordinate.component_id!r} lacks planar motion"
                        )
                    continue
                if coordinate.kind.value != declared.kind.value:
                    raise ActionEmbodimentMismatchError(
                        f"action coordinate {coordinate.component_id}/{coordinate.coordinate_id} "
                        f"has kind {coordinate.kind.value!r}, expected {declared.kind.value!r}"
                    )
            elif isinstance(group, CartesianCommands):
                if Capability.SPATIAL_MOTION_SE3 not in component.capabilities:
                    raise ActionEmbodimentMismatchError(
                        f"Cartesian component {coordinate.component_id!r} lacks spatial motion"
                    )
            elif isinstance(group, GripperCommands):
                if Capability.GRASP not in component.capabilities:
                    raise ActionEmbodimentMismatchError(
                        f"gripper component {coordinate.component_id!r} lacks grasp capability"
                    )
                declared = native.get((coordinate.component_id, coordinate.coordinate_id))
                if declared is not None and declared.kind is not ChannelKind.GRIPPER:
                    raise ActionEmbodimentMismatchError(
                        f"gripper coordinate {coordinate.component_id}/{coordinate.coordinate_id} "
                        "is not a gripper state coordinate"
                    )
    return interface


def _coordinate_dict(coordinate: CommandCoordinate) -> dict[str, JsonValue]:
    return {
        "component_id": str(coordinate.component_id),
        "coordinate_id": str(coordinate.coordinate_id),
        "kind": coordinate.kind.value,
        "unit": coordinate.unit.value,
        "bounds": {"lower": coordinate.lower, "upper": coordinate.upper},
    }


def _group_dict(group: CommandGroup) -> dict[str, JsonValue]:
    coordinates: list[JsonValue] = [
        _coordinate_dict(coordinate) for coordinate in group.coordinates
    ]
    if isinstance(group, JointCommands):
        return {
            "kind": "joint",
            "command_kind": group.command_kind.value,
            "reference_mode": group.reference_mode.value,
            "coordinates": coordinates,
        }
    if isinstance(group, CartesianCommands):
        return {
            "kind": "cartesian",
            "target_kind": group.target_kind.value,
            "frame": group.frame,
            "rotation": group.rotation.value,
            "coordinates": coordinates,
        }
    if isinstance(group, GripperCommands):
        return {
            "kind": "gripper",
            "command_kind": group.command_kind.value,
            "coordinates": coordinates,
        }
    return {"kind": "control_mode", "coordinates": coordinates}


def _semantic_dict(interface: ActionInterface) -> dict[str, JsonValue]:
    groups: list[JsonValue] = [_group_dict(group) for group in interface.groups]
    return {
        "schema_version": interface.schema_version,
        "embodiment_id": str(interface.embodiment_id),
        "normalization": interface.normalization.value,
        "control_hz": interface.control_hz,
        "groups": groups,
    }


def canonical_json(interface: ActionInterface) -> str:
    return canonical_document(_semantic_dict(interface))


def action_interface_to_dict(interface: ActionInterface) -> dict[str, object]:
    return {"id": str(interface.id), **_semantic_dict(interface)}


def action_interface_from_dict(document: Mapping[str, object]) -> ActionInterface:
    _exact_keys(
        document,
        {"id", "schema_version", "embodiment_id", "normalization", "control_hz", "groups"},
        "action interface",
    )
    version = document["schema_version"]
    if isinstance(version, bool) or version != ACTION_INTERFACE_SCHEMA_VERSION:
        raise ActionInterfaceError(f"unsupported action interface version: {version!r}")
    try:
        embodiment = EmbodimentId(_string(document, "embodiment_id", "action interface"))
        normalization = ActionNormalization(_string(document, "normalization", "action interface"))
    except ValueError as exc:
        raise ActionInterfaceError(f"unknown action-interface vocabulary: {exc}") from exc
    raw_groups = document["groups"]
    if not isinstance(raw_groups, list):
        raise ActionInterfaceError("action interface groups must be a list")
    interface = ActionInterface(
        embodiment_id=embodiment,
        normalization=normalization,
        control_hz=decode.number(
            document, "control_hz", where="action interface", error=ActionInterfaceError
        ),
        groups=tuple(
            _parse_group(item, offset) for offset, item in enumerate(cast(list[object], raw_groups))
        ),
    )
    try:
        expected_id = ActionInterfaceId(_string(document, "id", "action interface"))
    except ValueError as exc:
        raise ActionInterfaceError(f"invalid action interface id: {exc}") from exc
    if interface.id != expected_id:
        raise ActionInterfaceError("action interface id does not match its canonical content")
    return interface


def _parse_group(raw: object, offset: int) -> CommandGroup:
    if not isinstance(raw, Mapping):
        raise ActionInterfaceError(f"groups[{offset}] must be a mapping")
    entry = cast(Mapping[str, object], raw)
    kind = _string(entry, "kind", f"groups[{offset}]")
    label = f"groups[{offset}]"
    try:
        if kind == "joint":
            _exact_keys(entry, {"kind", "command_kind", "reference_mode", "coordinates"}, label)
            return JointCommands(
                JointCommandKind(_string(entry, "command_kind", label)),
                ReferenceMode(_string(entry, "reference_mode", label)),
                _parse_coordinates(entry["coordinates"], label),
            )
        if kind == "cartesian":
            _exact_keys(entry, {"kind", "target_kind", "frame", "rotation", "coordinates"}, label)
            return CartesianCommands(
                CartesianTargetKind(_string(entry, "target_kind", label)),
                _string(entry, "frame", label),
                RotationRepresentation(_string(entry, "rotation", label)),
                _parse_coordinates(entry["coordinates"], label),
            )
        if kind == "gripper":
            _exact_keys(entry, {"kind", "command_kind", "coordinates"}, label)
            return GripperCommands(
                GripperCommandKind(_string(entry, "command_kind", label)),
                _parse_coordinates(entry["coordinates"], label),
            )
        if kind == "control_mode":
            _exact_keys(entry, {"kind", "coordinates"}, label)
            return ControlModeCommands(_parse_coordinates(entry["coordinates"], label))
    except ValueError as exc:
        raise ActionInterfaceError(f"unknown command-group vocabulary: {exc}") from exc
    raise ActionInterfaceError(f"unknown command-group variant: {kind!r}")


def _parse_coordinates(raw: object, label: str) -> tuple[CommandCoordinate, ...]:
    if not isinstance(raw, list):
        raise ActionInterfaceError(f"{label}.coordinates must be a list")
    coordinates: list[CommandCoordinate] = []
    for offset, item in enumerate(cast(list[object], raw)):
        coordinate_label = f"{label}.coordinates[{offset}]"
        if not isinstance(item, Mapping):
            raise ActionInterfaceError(f"{coordinate_label} must be a mapping")
        entry = cast(Mapping[str, object], item)
        _exact_keys(
            entry,
            {"component_id", "coordinate_id", "kind", "unit", "bounds"},
            coordinate_label,
        )
        raw_bounds = entry["bounds"]
        if not isinstance(raw_bounds, Mapping):
            raise ActionInterfaceError(f"{coordinate_label}.bounds must be a mapping")
        bounds = cast(Mapping[str, object], raw_bounds)
        _exact_keys(bounds, {"lower", "upper"}, f"{coordinate_label}.bounds")
        try:
            kind = ActionChannelKind(_string(entry, "kind", coordinate_label))
            unit = CoordinateUnit(_string(entry, "unit", coordinate_label))
        except ValueError as exc:
            raise ActionInterfaceError(f"unknown command-coordinate vocabulary: {exc}") from exc
        coordinates.append(
            CommandCoordinate(
                ComponentId(_string(entry, "component_id", coordinate_label)),
                ActionCoordinateId(_string(entry, "coordinate_id", coordinate_label)),
                kind,
                unit,
                Bounds(
                    decode.number(
                        bounds,
                        "lower",
                        where=f"{coordinate_label}.bounds",
                        error=ActionInterfaceError,
                    ),
                    decode.number(
                        bounds,
                        "upper",
                        where=f"{coordinate_label}.bounds",
                        error=ActionInterfaceError,
                    ),
                ),
            )
        )
    return tuple(coordinates)


def _exact_keys(document: Mapping[str, object], expected: set[str], label: str) -> None:
    actual = set(document)
    if actual != expected:
        raise ActionInterfaceError(
            f"{label} keys differ: missing={sorted(expected - actual)}, "
            f"unknown={sorted(actual - expected)}"
        )


def _string(document: Mapping[str, object], key: str, label: str) -> str:
    value = document.get(key)
    if not isinstance(value, str):
        raise ActionInterfaceError(f"{label}.{key} must be a string")
    return value
