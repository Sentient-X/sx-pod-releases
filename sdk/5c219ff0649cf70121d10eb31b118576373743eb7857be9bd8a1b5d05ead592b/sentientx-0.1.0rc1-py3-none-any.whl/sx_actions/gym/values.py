"""The small values exchanged by robot environments and policies."""

from collections.abc import Mapping
from dataclasses import dataclass

from sx_actions.shapes import Float32StateVector, RgbObservation

type Image = RgbObservation
"""An ``(H, W, 3)`` uint8 RGB camera frame."""

type Proprioception = Float32StateVector
"""One observation's embodiment-native state vector."""


@dataclass(frozen=True, slots=True, eq=False)
class Observation[CameraT: str]:
    """One named-camera and proprioceptive observation."""

    proprioception: Proprioception
    images: Mapping[CameraT, Image]

    def camera(self, camera: CameraT) -> Image:
        return self.images[camera]


@dataclass(frozen=True, slots=True)
class BinaryReward:
    """The verified binary task reward."""

    success: bool

    def as_float(self) -> float:
        return 1.0 if self.success else 0.0


@dataclass(frozen=True, slots=True)
class Safe:
    """The proposed action is inside every bound safety constraint."""


@dataclass(frozen=True, slots=True)
class Violation:
    """The proposed action violates one identified hard constraint."""

    constraint_id: str

    def __post_init__(self) -> None:
        if not self.constraint_id.strip():
            raise ValueError("safety constraint identity must be non-empty")


type SafetyVerdict = Safe | Violation
