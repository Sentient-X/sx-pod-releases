"""The immutable Gym API surface shared by the platform's RL consumers.

The four frozen ``Protocol``s (``SafetyConstraint``/``Verifier``/``ResetRoutine`` composing into
``RolloutEnv``) plus the ``StepResult`` record, generic over task identity (``TaskT``) and camera
key (``CameraT``) so execution owners share one definition instead of re-declaring it. Worlds
owns simulated conformers; Fleet owns physical research-pod conformers; auto-perfect consumes
both through MCP. Extracted from ``auto_perfect.en`` with the method set verbatim;
auto-perfect's current real/sim conformers are transitional migration sources.

The values and Protocols live together: observations and rewards are runtime Gym facts, not
episode-storage records.  NumPy is the neutral array boundary; no simulator or ML framework
enters this package.

It lives beneath the action vocabulary it constrains -- every Protocol here is generic over
``ActionT: Action`` -- but stays its own import path: ``sx_actions`` proper is the wire-contract
half (content-addressed interfaces that persist and travel), while this is the in-process
runtime half (structural Protocols an executing service satisfies). Nothing here is flattened
into ``sx_actions.__all__``; the distinction has to stay visible at the call site.
"""

from sx_actions.gym.api import (
    ResetRoutine,
    RolloutEnv,
    SafetyConstraint,
    StepResult,
    Verifier,
)
from sx_actions.gym.values import (
    BinaryReward,
    Image,
    Observation,
    Proprioception,
    Safe,
    SafetyVerdict,
    Violation,
)

__all__ = [
    "BinaryReward",
    "Image",
    "Observation",
    "Proprioception",
    "ResetRoutine",
    "RolloutEnv",
    "Safe",
    "SafetyConstraint",
    "SafetyVerdict",
    "StepResult",
    "Verifier",
    "Violation",
]
