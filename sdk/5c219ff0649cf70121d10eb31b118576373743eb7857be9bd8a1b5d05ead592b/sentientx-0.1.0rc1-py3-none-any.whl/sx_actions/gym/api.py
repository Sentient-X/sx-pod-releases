"""The immutable Gym API surface, shared by the platform's RL consumers.

These ``Protocol``s are the boundary ENPIRE calls *immutable Gym APIs* (the EN/R contract): a
small, total, well-typed surface that hides every implementation detail behind it. The three EN
pieces -- :class:`SafetyConstraint`, :class:`Verifier`, :class:`ResetRoutine` -- compose into a
:class:`RolloutEnv`, which the executing Worlds or Fleet service exposes to its policy runner.
Agent clients such as auto-perfect receive an MCP resource, not this in-process object.

Execution owners meet at this surface, so it is defined once here and each conformer binds its
own identity types. Worlds owns simulated conformers and Fleet owns physical research-pod
conformers; auto-perfect calls both through MCP. Enpire's present real/sim conformers are
pre-cutover migration sources.

* ``TaskT`` -- the exact task this env evaluates. Left unbounded: task identity is a
  conformer's vocabulary.
* ``CameraT`` -- the conformer's camera-key set.
* ``ActionT`` -- the exact interface-bound :class:`sx_actions.Action` subtype the conformer
  consumes. There is one action value and no controller-specific split representation.

The runtime observation/reward/verdict records live beside these Protocols in
``sx_actions.gym`` and executed action values come from ``sx_actions`` itself; episode
persistence is a separate executing-service boundary. A conformer specializes each Protocol
into a concrete, ``isinstance``-able one by binding every parameter (see ``auto_perfect.en.api``);
the method set is verbatim, so the frozen surface is preserved -- generalizing where it is
*defined* is not relaxing what a consumer *exposes*.
"""

from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Protocol, runtime_checkable

from sx_contracts import Ended, EpisodeEnd, StepProgress

from sx_actions import Action
from sx_actions.gym.values import BinaryReward, Observation, SafetyVerdict


def _empty_info() -> Mapping[str, object]:
    """Typed default factory for :attr:`StepResult.info` (an empty, read-only mapping)."""
    return MappingProxyType({})


@dataclass(frozen=True, slots=True, eq=False)
class StepResult[CameraT: str]:
    """One observation/reward transition and its closed episode progress."""

    observation: Observation[CameraT]
    reward: BinaryReward
    progress: StepProgress
    info: Mapping[str, object] = field(default_factory=_empty_info)

    def __post_init__(self) -> None:
        object.__setattr__(self, "info", MappingProxyType(dict(self.info)))

    @property
    def done(self) -> bool:
        """Whether the episode has ended for any reason (terminated or truncated)."""
        return isinstance(self.progress, Ended)

    @property
    def end(self) -> EpisodeEnd | None:
        """The terminal facts, or ``None`` while the episode continues."""

        return self.progress.end if isinstance(self.progress, Ended) else None

    def gymnasium_flags(self) -> tuple[bool, bool]:
        """Project terminality only at a Gymnasium adapter boundary."""

        end = self.end
        return (
            bool(end is not None and end.terminated),
            bool(end is not None and end.truncated),
        )


@runtime_checkable
class SafetyConstraint[CameraT: str, ActionT: Action](Protocol):
    """A hard safety constraint on configuration space / kinematic behavior (ENPIRE Sec. 2.1).

    Constraints are sufficient for task completion while bounding the robot to a safe operational
    limit. A violation triggers immediate task failure and an automated reset.

    **The terminal veto, deliberately.** This is the environment owner's answer to "the robot
    must not be here", and ending the episode is the only answer that is always available to it:
    the owner knows the safe set but not what the policy was trying to do, so it cannot withdraw
    on the policy's behalf. It is not the only reflex the stack has, and it must not become one —
    a layer whose sole response is to kill the episode cannot express *withdraw and keep going*,
    which is what a biological flexion reflex actually does.

    The recoverable layer sits beneath it, inside the policy: ``sx_runtime.Reflex`` is consulted
    every step before the chunk is streamed and may **preempt** the decision in force — commanding
    a withdrawal while the hazard persists and handing control back to the same decision when it
    clears, without ending anything. The two compose in one direction: a reflex that cannot
    resolve its hazard within its declared authority fails closed, and this constraint (in Worlds)
    or the pod's ``safe_stop`` (in Fleet) is what catches it. Neither replaces the other.
    """

    @property
    def name(self) -> str:
        """Stable identifier carried by :class:`~sx_actions.gym.Violation` on a breach."""
        ...

    def check(self, observation: Observation[CameraT], action: ActionT) -> SafetyVerdict:
        """Return whether executing ``action`` from ``observation`` stays within the safe set."""
        ...


@runtime_checkable
class Verifier[CameraT: str, ActionT: Action](Protocol):
    """Automated verification: synthesize a binary reward from sensor inputs (ENPIRE Sec. 2.1).

    The reward must ground in perception, never oracle state, and stay within the harness's
    inference-latency budget (e.g. by ONNX-compiling the perception stack).
    """

    def verify(self, observation: Observation[CameraT], action: ActionT) -> BinaryReward:
        """Return the binary reward for the current step."""
        ...


@runtime_checkable
class ResetRoutine[CameraT: str](Protocol):
    """Automated reset: restore the scene to the onset of the task's most challenging phase.

    A long-horizon function composed from perception/planning skills (segmentation, 6-DoF pose
    tracking, collision-free planning, grasp synthesis). Returns the first observation of the
    freshly reset episode.
    """

    def reset(self) -> Observation[CameraT]:
        """Restore the environment and return the initial observation."""
        ...


@runtime_checkable
class RolloutEnv[TaskT, CameraT: str, ActionT: Action](Protocol):
    """The Rollout (R) module: EN modules + visual-proprioception obs -> controller + reward.

    This is the frozen Gym API that policy-improvement agents consume; its method set does not
    grow once the EN module is finalized.
    """

    @property
    def task(self) -> TaskT:
        """The task this environment evaluates."""
        ...

    def reset(self) -> Observation[CameraT]:
        """Run the automated reset and return the initial observation of a new episode."""
        ...

    def get_observation(self) -> Observation[CameraT]:
        """Return the current visual-proprioception observation without stepping."""
        ...

    def get_reward(self, observation: Observation[CameraT], action: ActionT) -> BinaryReward:
        """Return the binary reward from automated verification for ``(observation, action)``."""
        ...

    def step(self, action: ActionT) -> StepResult[CameraT]:
        """Command ``action`` to the controller and return the resulting typed step outcome."""
        ...
