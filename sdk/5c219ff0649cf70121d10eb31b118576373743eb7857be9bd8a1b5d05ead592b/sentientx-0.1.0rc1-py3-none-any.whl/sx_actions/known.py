"""General action constructors plus exact external-controller values."""

import math
from typing import Final

from sx_contracts import ComponentId
from sx_embodiments import Bounds, ChannelKind, CoordinateUnit, Embodiment, embodiments

from .contract import (
    ActionChannelKind,
    ActionCoordinateId,
    ActionInterface,
    ActionInterfaceError,
    ActionNormalization,
    CartesianCommands,
    CartesianTargetKind,
    CommandCoordinate,
    CommandGroup,
    GripperCommandKind,
    GripperCommands,
    JointCommandKind,
    JointCommands,
    ReferenceMode,
    RotationRepresentation,
    native_coordinate_id,
    validate_for_embodiment,
)


def joint_position(embodiment: Embodiment, *, control_hz: float | None = None) -> ActionInterface:
    """The complete bounded native body as position targets."""

    rate = embodiment.policy_hz if control_hz is None else control_hz
    if rate is None:
        raise ActionInterfaceError("control_hz is required when the embodiment has no nominal rate")
    joints, grippers = _native_position_coordinates(embodiment, excluded=frozenset())
    groups: list[CommandGroup] = []
    if joints:
        groups.append(
            JointCommands(JointCommandKind.POSITION, ReferenceMode.ABSOLUTE, tuple(joints))
        )
    if grippers:
        groups.append(GripperCommands(GripperCommandKind.POSITION, tuple(grippers)))
    return ActionInterface(
        embodiment_id=embodiment.id,
        normalization=ActionNormalization.PHYSICAL,
        control_hz=rate,
        groups=tuple(groups),
    )


def rby1_whole_body(
    *,
    control_hz: float,
    base_linear_speed_limit_mps: float,
    base_yaw_speed_limit_rad_s: float,
) -> ActionInterface:
    """RBY1 body-frame base velocity plus bounded native joint-position targets.

    The base coordinates are semantic controller inputs rather than invented position state:
    forward and left velocity in the robot body frame, then yaw rate. The remaining coordinates
    derive from the exact registered RBY1 state layout.
    """
    if (
        not math.isfinite(base_linear_speed_limit_mps)
        or not math.isfinite(base_yaw_speed_limit_rad_s)
        or base_linear_speed_limit_mps <= 0.0
        or base_yaw_speed_limit_rad_s <= 0.0
    ):
        raise ActionInterfaceError("RBY1 base speed limits must be positive and finite")
    embodiment = embodiments["rby1"]
    base = ComponentId("base")
    joints, grippers = _native_position_coordinates(embodiment, excluded=frozenset({base}))
    interface = ActionInterface(
        embodiment_id=embodiment.id,
        normalization=ActionNormalization.PHYSICAL,
        control_hz=control_hz,
        groups=(
            JointCommands(
                JointCommandKind.VELOCITY,
                ReferenceMode.ABSOLUTE,
                (
                    _coordinate(
                        base,
                        "forward",
                        ActionChannelKind.BASE,
                        CoordinateUnit.METERS_PER_SECOND,
                        -base_linear_speed_limit_mps,
                        base_linear_speed_limit_mps,
                    ),
                    _coordinate(
                        base,
                        "left",
                        ActionChannelKind.BASE,
                        CoordinateUnit.METERS_PER_SECOND,
                        -base_linear_speed_limit_mps,
                        base_linear_speed_limit_mps,
                    ),
                    _coordinate(
                        base,
                        "yaw",
                        ActionChannelKind.BASE,
                        CoordinateUnit.RADIANS_PER_SECOND,
                        -base_yaw_speed_limit_rad_s,
                        base_yaw_speed_limit_rad_s,
                    ),
                ),
            ),
            JointCommands(JointCommandKind.POSITION, ReferenceMode.ABSOLUTE, joints),
            GripperCommands(GripperCommandKind.POSITION, grippers),
        ),
    )
    return validate_for_embodiment(interface, embodiment)


def _native_position_coordinates(
    embodiment: Embodiment, *, excluded: frozenset[ComponentId]
) -> tuple[tuple[CommandCoordinate, ...], tuple[CommandCoordinate, ...]]:
    joints: list[CommandCoordinate] = []
    grippers: list[CommandCoordinate] = []
    for coordinate in embodiment.state.coordinates:
        component = ComponentId(coordinate.instance)
        if component in excluded:
            continue
        bounds = coordinate.axis.bounds
        if not isinstance(bounds, Bounds):
            raise ActionInterfaceError(
                "native position bounds are not declared for: "
                f"{coordinate.instance}/{coordinate.joint_name}"
            )
        command = CommandCoordinate(
            component,
            native_coordinate_id(coordinate.joint_name),
            ActionChannelKind(coordinate.kind.value),
            coordinate.unit,
            bounds,
        )
        (grippers if coordinate.kind is ChannelKind.GRIPPER else joints).append(command)
    return tuple(joints), tuple(grippers)


def _coordinate(
    component_id: ComponentId,
    coordinate_id: str,
    kind: ActionChannelKind,
    unit: CoordinateUnit,
    lower: float,
    upper: float,
) -> CommandCoordinate:
    return CommandCoordinate(
        component_id,
        ActionCoordinateId(coordinate_id),
        kind,
        unit,
        Bounds(lower, upper),
    )


def _libero_franka() -> ActionInterface:
    """LIBERO's robosuite 1.4.1 OSC_POSE input over a fixed-base Franka."""

    embodiment = embodiments["franka"]
    effector = ComponentId("gripper")
    cartesian = CartesianCommands(
        target_kind=CartesianTargetKind.DELTA_FROM_POSITION,
        frame="robot0_base",
        rotation=RotationRepresentation.AXIS_ANGLE,
        coordinates=(
            _coordinate(
                effector,
                "delta_x",
                ActionChannelKind.EEF_TRANSLATION,
                CoordinateUnit.METER,
                -0.05,
                0.05,
            ),
            _coordinate(
                effector,
                "delta_y",
                ActionChannelKind.EEF_TRANSLATION,
                CoordinateUnit.METER,
                -0.05,
                0.05,
            ),
            _coordinate(
                effector,
                "delta_z",
                ActionChannelKind.EEF_TRANSLATION,
                CoordinateUnit.METER,
                -0.05,
                0.05,
            ),
            _coordinate(
                effector,
                "delta_rx",
                ActionChannelKind.EEF_ROTATION,
                CoordinateUnit.RADIAN,
                -0.5,
                0.5,
            ),
            _coordinate(
                effector,
                "delta_ry",
                ActionChannelKind.EEF_ROTATION,
                CoordinateUnit.RADIAN,
                -0.5,
                0.5,
            ),
            _coordinate(
                effector,
                "delta_rz",
                ActionChannelKind.EEF_ROTATION,
                CoordinateUnit.RADIAN,
                -0.5,
                0.5,
            ),
        ),
    )
    gripper = GripperCommands(
        GripperCommandKind.POSITION,
        (
            _coordinate(
                effector,
                "aperture",
                ActionChannelKind.GRIPPER,
                CoordinateUnit.METER,
                0.0,
                0.08,
            ),
        ),
    )
    return ActionInterface(
        embodiment_id=embodiment.id,
        normalization=ActionNormalization.NEGATIVE_ONE_TO_ONE,
        control_hz=20.0,
        groups=(cartesian, gripper),
    )


LIBERO_FRANKA: Final = _libero_franka()


def cartesian_pose_target(
    *,
    embodiment: Embodiment,
    effector_id: ComponentId,
    control_hz: float,
    command_frame: str,
    translation_lower: tuple[float, float, float],
    translation_upper: tuple[float, float, float],
    gripper_lower: float,
    gripper_upper: float,
) -> ActionInterface:
    """Absolute xyz + quaternion-wxyz + gripper-aperture target contract."""

    translation = tuple(
        _coordinate(
            effector_id,
            axis,
            ActionChannelKind.EEF_TRANSLATION,
            CoordinateUnit.METER,
            translation_lower[index],
            translation_upper[index],
        )
        for index, axis in enumerate(("x", "y", "z"))
    )
    rotation = tuple(
        _coordinate(
            effector_id,
            f"q{axis}",
            ActionChannelKind.EEF_ROTATION,
            CoordinateUnit.UNITLESS,
            -1.0,
            1.0,
        )
        for axis in ("w", "x", "y", "z")
    )
    aperture = _coordinate(
        effector_id,
        "aperture",
        ActionChannelKind.GRIPPER,
        CoordinateUnit.METER,
        gripper_lower,
        gripper_upper,
    )
    return ActionInterface(
        embodiment_id=embodiment.id,
        normalization=ActionNormalization.PHYSICAL,
        control_hz=control_hz,
        groups=(
            CartesianCommands(
                CartesianTargetKind.ABSOLUTE_POSE,
                command_frame,
                RotationRepresentation.QUATERNION_WXYZ,
                translation + rotation,
            ),
            GripperCommands(GripperCommandKind.POSITION, (aperture,)),
        ),
    )
