"""Immutable action values bound to their exact controller interface."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from .shapes import ActionVector

if TYPE_CHECKING:
    from .contract import ActionInterface


class ActionValueError(ValueError):
    """An action is not valid for its bound interface."""


@dataclass(frozen=True, slots=True, eq=False)
class Action:
    """One already-validated action and the exact semantics of every value."""

    interface: ActionInterface
    values: ActionVector

    def __post_init__(self) -> None:
        try:
            checked = self.interface.validate_values(self.values)
        except ValueError as exc:
            raise ActionValueError(str(exc)) from exc
        object.__setattr__(self, "values", checked)
