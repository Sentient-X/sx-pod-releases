"""Portable array shapes owned by the action and observation contracts."""

import numpy as np
from jaxtyping import Float, Float32, UInt8
from numpy.typing import NDArray

type ActionVector = Float[NDArray[np.floating], "action"]
"""One controller action in its declared coordinate order."""

type ActionHorizon = Float[NDArray[np.floating], "horizon action"]
"""A time-major sequence of controller actions."""

type StateVector = Float[NDArray[np.floating], "state"]
"""One embodiment state in its declared coordinate order."""

type Float32StateVector = Float32[NDArray[np.float32], "state"]
"""A normalized float32 state at a model boundary."""

type RgbObservation = UInt8[NDArray[np.uint8], "height width 3"]
"""One RGB observation frame."""
