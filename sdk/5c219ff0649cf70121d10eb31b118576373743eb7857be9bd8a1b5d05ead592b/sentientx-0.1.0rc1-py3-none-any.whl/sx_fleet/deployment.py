"""Application admission, atomic rollout waves, and expiring task leases."""

import math
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import StrEnum
from typing import NewType

from sx_actions import ActionInterfaceId
from sx_autonomy import (
    ApplicationQualification,
    CapabilityApproval,
    CapabilityApprovalRef,
)
from sx_contracts import (
    DeploymentGroupRef,
    RobotApplication,
    RobotApplicationRef,
    StationApplicationRelease,
    StationTarget,
    TaskFamilyRef,
)
from sx_embodiments import EmbodimentId

from sx_fleet.qualification import RuntimeCriteria
from sx_fleet.supervision import SupervisionPolicyRef

StationId = NewType("StationId", str)
ApplicationDeploymentRef = NewType("ApplicationDeploymentRef", str)
RolloutRef = NewType("RolloutRef", str)
TaskLeaseRef = NewType("TaskLeaseRef", str)
_RESERVED_LABEL_PREFIXES = ("sx.", "sentientx.", "system.")


class DeploymentRejectedError(ValueError):
    """An application, rollout, acknowledgement, or lease failed closed."""


class DeploymentState(StrEnum):
    ROLLING_OUT = "rolling_out"
    ACTIVE = "active"
    SAFE_STOPPED = "safe_stopped"
    FAILED = "failed"
    RETIRED = "retired"


class DeploymentStage(StrEnum):
    CANARY = "canary"
    PRODUCTION = "production"


@dataclass(frozen=True, slots=True)
class ExecutionLimits:
    maximum_action_horizon: int
    maximum_linear_velocity: float
    maximum_angular_velocity: float

    def __post_init__(self) -> None:
        if isinstance(self.maximum_action_horizon, bool) or self.maximum_action_horizon < 1:
            raise DeploymentRejectedError("maximum action horizon must be positive")
        if any(
            not math.isfinite(value) or value <= 0
            for value in (self.maximum_linear_velocity, self.maximum_angular_velocity)
        ):
            raise DeploymentRejectedError("execution velocity limits must be positive")


@dataclass(frozen=True, slots=True)
class CanaryCriteria:
    required_consecutive_successful_trials: int
    maximum_failed_attempts: int
    minimum_supervision_coverage: float

    def __post_init__(self) -> None:
        if (
            isinstance(self.required_consecutive_successful_trials, bool)
            or self.required_consecutive_successful_trials < 1
        ):
            raise DeploymentRejectedError("canary success streak must be positive")
        if isinstance(self.maximum_failed_attempts, bool) or self.maximum_failed_attempts < 0:
            raise DeploymentRejectedError("canary failed-attempt allowance must be non-negative")
        if (
            not math.isfinite(self.minimum_supervision_coverage)
            or not 0 <= self.minimum_supervision_coverage <= 1
        ):
            raise DeploymentRejectedError("canary supervision coverage must be within [0, 1]")


@dataclass(frozen=True, slots=True)
class StationLabels:
    values: tuple[tuple[str, str], ...]

    def __post_init__(self) -> None:
        if not self.values:
            raise DeploymentRejectedError("station labels must not be empty")
        keys = tuple(key for key, _ in self.values)
        if keys != tuple(sorted(keys)) or len(set(keys)) != len(keys):
            raise DeploymentRejectedError("station labels need unique sorted keys")
        for key, value in self.values:
            if not key.strip() or not value.strip():
                raise DeploymentRejectedError("station labels must be non-empty strings")
            if key.startswith(_RESERVED_LABEL_PREFIXES):
                raise DeploymentRejectedError(f"station label key {key!r} is reserved")

    @classmethod
    def canonical(cls, values: dict[str, str]) -> "StationLabels":
        return cls(tuple(sorted(values.items())))

    def matches(self, selector: "StationLabels") -> bool:
        labels = dict(self.values)
        return all(labels.get(key) == value for key, value in selector.values)


@dataclass(frozen=True, slots=True)
class StationInventory:
    station_id: StationId
    target: StationTarget
    labels: StationLabels
    online: bool


@dataclass(frozen=True, slots=True)
class DeploymentGroup:
    deployment_group_ref: DeploymentGroupRef
    stage: DeploymentStage
    station_target: StationTarget
    embodiment_id: EmbodimentId
    action_interface_ids: tuple[ActionInterfaceId, ...]
    supervision_policy_ref: SupervisionPolicyRef
    execution_limits: ExecutionLimits
    selector: StationLabels
    wave_size: int
    qualification_station: StationId
    runtime_criteria: RuntimeCriteria
    canary_criteria: CanaryCriteria | None

    def __post_init__(self) -> None:
        if not self.action_interface_ids or len(set(self.action_interface_ids)) != len(
            self.action_interface_ids
        ):
            raise DeploymentRejectedError("deployment group needs unique action interfaces")
        if not str(self.supervision_policy_ref).startswith("supervision-policy:"):
            raise DeploymentRejectedError("deployment group needs an exact supervision policy ref")
        if isinstance(self.wave_size, bool) or self.wave_size < 1:
            raise DeploymentRejectedError("rollout wave size must be positive")
        if self.stage is DeploymentStage.CANARY and self.canary_criteria is None:
            raise DeploymentRejectedError("canary groups need canary criteria")
        if self.stage is DeploymentStage.PRODUCTION and self.canary_criteria is not None:
            raise DeploymentRejectedError("production groups cannot carry canary criteria")


def matching_stations(
    group: DeploymentGroup, inventory: tuple[StationInventory, ...], *, require_match: bool
) -> tuple[StationInventory, ...]:
    matching = tuple(
        sorted(
            (station for station in inventory if station.labels.matches(group.selector)),
            key=lambda station: str(station.station_id),
        )
    )
    incompatible = tuple(
        station.station_id for station in matching if station.target != group.station_target
    )
    if incompatible:
        raise DeploymentRejectedError(
            f"selector matched incompatible station targets: {', '.join(map(str, incompatible))}"
        )
    if require_match and not matching:
        raise DeploymentRejectedError("deployment selector currently matches no station")
    return matching


def validate_group_inventory(
    group: DeploymentGroup, inventory: tuple[StationInventory, ...]
) -> None:
    stations = {station.station_id: station for station in inventory}
    station = stations.get(group.qualification_station)
    if station is None or not station.labels.matches(group.selector):
        raise DeploymentRejectedError("qualification station is missing or does not match")
    if station.target != group.station_target:
        raise DeploymentRejectedError("qualification station target differs")
    matching_stations(group, inventory, require_match=True)


@dataclass(frozen=True, slots=True)
class RolloutWave:
    index: int
    stations: tuple[StationId, ...]


def next_rollout_wave(
    group: DeploymentGroup,
    inventory: tuple[StationInventory, ...],
    persisted: tuple[RolloutWave, ...],
) -> RolloutWave | None:
    selected = {station for wave in persisted for station in wave.stations}
    remaining = tuple(
        station.station_id
        for station in matching_stations(group, inventory, require_match=not persisted)
        if station.station_id not in selected
    )
    return None if not remaining else RolloutWave(len(persisted), remaining[: group.wave_size])


@dataclass(frozen=True, slots=True)
class ApplicationAcknowledgement:
    station: StationId
    application: RobotApplicationRef
    station_release: StationApplicationRelease
    station_target: StationTarget
    workloads_healthy: bool


def require_exact_acknowledgement(
    acknowledgement: ApplicationAcknowledgement,
    *,
    station: StationId,
    application: RobotApplication,
    station_release: StationApplicationRelease,
) -> None:
    if (
        acknowledgement.station != station
        or acknowledgement.application != application.ref
        or acknowledgement.station_release != station_release
        or acknowledgement.station_target != application.target
    ):
        raise DeploymentRejectedError("station acknowledgement differs from its assignment")
    if not acknowledgement.workloads_healthy:
        raise DeploymentRejectedError("station acknowledged unhealthy application workloads")


@dataclass(frozen=True, slots=True)
class ApplicationDeployment:
    deployment_ref: ApplicationDeploymentRef
    group_ref: DeploymentGroupRef
    application: RobotApplicationRef
    approvals: tuple[CapabilityApprovalRef, ...]
    supervision_policy_ref: SupervisionPolicyRef
    rollout_ref: RolloutRef
    state: DeploymentState
    waves: tuple[RolloutWave, ...]

    def __post_init__(self) -> None:
        if not self.approvals or len(set(self.approvals)) != len(self.approvals):
            raise DeploymentRejectedError(
                "an application deployment needs unique enabled capability approvals"
            )


def admit_application(
    *,
    application: RobotApplication,
    qualification: ApplicationQualification,
    approvals: tuple[CapabilityApproval, ...],
    group: DeploymentGroup,
    matching_canary_exists: bool,
) -> None:
    """Admit the graph once, while preserving exact evidence per enabled task."""

    if qualification.application != application or not qualification.passed:
        raise DeploymentRejectedError(
            "application qualification does not pass for the submitted application"
        )
    if application.target != group.station_target:
        raise DeploymentRejectedError("application target does not match the deployment group")
    if not approvals:
        raise DeploymentRejectedError("deployment needs at least one capability approval")
    task_refs = tuple(approval.task for approval in approvals)
    if len(set(task_refs)) != len(task_refs):
        raise DeploymentRejectedError("deployment repeats a capability approval task")
    approved_families: set[TaskFamilyRef] = set()
    for approval in approvals:
        if approval.application != application or approval.qualification != qualification:
            raise DeploymentRejectedError(
                "capability approval targets another application or qualification"
            )
        if (
            approval.embodiment_id != group.embodiment_id
            or approval.action_interface_id not in group.action_interface_ids
        ):
            raise DeploymentRejectedError(
                "capability approval robot contract is not admitted by the group"
            )
        approved_families.add(TaskFamilyRef(str(approval.world.task.family)))
    if approved_families != set(application.capabilities):
        raise DeploymentRejectedError(
            "every declared application task family must have passing capability evidence"
        )
    if group.stage is DeploymentStage.PRODUCTION and not matching_canary_exists:
        raise DeploymentRejectedError("no exact passing canary qualification exists")


@dataclass(frozen=True, slots=True)
class TaskLease:
    """One expiring authorization for one enabled task on one active deployment."""

    lease_ref: TaskLeaseRef
    deployment: ApplicationDeploymentRef
    approval: CapabilityApprovalRef
    sequence: int
    issued_at: datetime
    expires_at: datetime

    def __post_init__(self) -> None:
        if isinstance(self.sequence, bool) or self.sequence < 1:
            raise DeploymentRejectedError("task lease sequence must be positive")
        if self.issued_at.tzinfo is None or self.expires_at.tzinfo is None:
            raise DeploymentRejectedError("task lease timestamps must be timezone-aware")
        if self.expires_at <= self.issued_at:
            raise DeploymentRejectedError("task lease expiry must follow issuance")

    def active_at(self, now: datetime) -> bool:
        if now.tzinfo is None:
            raise DeploymentRejectedError("task lease check time must be timezone-aware")
        return self.issued_at <= now < self.expires_at


def issue_task_lease(
    deployment: ApplicationDeployment,
    approval: CapabilityApprovalRef,
    *,
    sequence: int,
    issued_at: datetime,
    duration: timedelta,
) -> TaskLease:
    if deployment.state is not DeploymentState.ACTIVE:
        raise DeploymentRejectedError("task leases require an active application deployment")
    if approval not in deployment.approvals:
        raise DeploymentRejectedError("task lease approval is not enabled on the deployment")
    if duration <= timedelta(0):
        raise DeploymentRejectedError("task lease duration must be positive")
    return TaskLease(
        TaskLeaseRef(f"task-lease:{deployment.deployment_ref}:{sequence}"),
        deployment.deployment_ref,
        approval,
        sequence,
        issued_at,
        issued_at + duration,
    )
