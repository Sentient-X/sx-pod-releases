"""Automatic canary evidence that alone unlocks a matching production group."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import NewType, cast

from sx_autonomy import CapabilityApprovalRef
from sx_contracts import (
    ActionSource,
    RobotApplicationRef,
    Sha256Digest,
    StationTarget,
    TaskContractRef,
    TaskId,
    TaskSchemaVersion,
    TaskVerdict,
    decode,
    station_target_from_dict,
)
from sx_contracts.identity import CanonicalDocument, content_digest

from sx_fleet.deployment import ApplicationDeploymentRef, CanaryCriteria, StationId
from sx_fleet.qualification import RuntimeCriteria, runtime_criteria_from_dict
from sx_fleet.supervision import SupervisionPolicyRef

CanaryQualificationRef = NewType("CanaryQualificationRef", str)


class CanaryQualificationError(ValueError):
    """Canary trials are incomplete, mismatched, or do not satisfy their criteria."""


@dataclass(frozen=True, slots=True)
class CanaryTrial:
    episode_ref: str
    deployment: ApplicationDeploymentRef
    application: RobotApplicationRef
    approval: CapabilityApprovalRef
    supervision_policy: SupervisionPolicyRef
    task: TaskContractRef
    action_source: ActionSource
    station: StationId
    healthy: bool
    supervision_coverage: float
    verdict: TaskVerdict

    def __post_init__(self) -> None:
        if any(
            not value.strip()
            for value in (
                self.episode_ref,
                str(self.deployment),
                str(self.application),
                str(self.approval),
                str(self.supervision_policy),
                str(self.station),
            )
        ):
            raise CanaryQualificationError("canary trial identities must not be empty")
        if (
            not math.isfinite(self.supervision_coverage)
            or not 0.0 <= self.supervision_coverage <= 1.0
        ):
            raise CanaryQualificationError("supervision coverage must be within [0, 1]")


@dataclass(frozen=True, slots=True)
class CanaryQualification:
    application: RobotApplicationRef
    approval: CapabilityApprovalRef
    target: StationTarget
    runtime_criteria: RuntimeCriteria
    supervision_policy: SupervisionPolicyRef
    criteria: CanaryCriteria
    trials: tuple[CanaryTrial, ...]

    def __post_init__(self) -> None:
        if not self.trials:
            raise CanaryQualificationError("canary qualification needs executed trials")
        if any(
            trial.application != self.application
            or trial.approval != self.approval
            or trial.supervision_policy != self.supervision_policy
            for trial in self.trials
        ):
            raise CanaryQualificationError("canary trials disagree with qualification identity")
        deployments = {trial.deployment for trial in self.trials}
        if len(deployments) != 1:
            raise CanaryQualificationError(
                "canary trials must run under one acknowledged application deployment"
            )
        failures = 0
        streak = 0
        for trial in self.trials:
            passed = (
                trial.healthy
                and trial.verdict is TaskVerdict.SATISFIED
                and trial.supervision_coverage >= self.criteria.minimum_supervision_coverage
            )
            if passed:
                streak += 1
            else:
                failures += 1
                streak = 0
            if failures > self.criteria.maximum_failed_attempts:
                raise CanaryQualificationError("canary exceeded its failed-attempt allowance")
        if streak < self.criteria.required_consecutive_successful_trials:
            raise CanaryQualificationError("canary evidence lacks the required success streak")

    @property
    def ref(self) -> CanaryQualificationRef:
        digest = content_digest(cast("CanonicalDocument", canary_qualification_to_dict(self)))
        return CanaryQualificationRef(f"canary-qualification:{digest}")


def canary_qualification_to_dict(value: CanaryQualification) -> dict[str, object]:
    from sx_contracts import station_target_to_dict

    from sx_fleet.qualification import runtime_criteria_to_dict

    return {
        "schema": "sx.canary-qualification/v2",
        "application": str(value.application),
        "approval": str(value.approval),
        "target": station_target_to_dict(value.target),
        "runtime_criteria": runtime_criteria_to_dict(value.runtime_criteria),
        "supervision_policy": str(value.supervision_policy),
        "criteria": {
            "required_consecutive_successful_trials": (
                value.criteria.required_consecutive_successful_trials
            ),
            "maximum_failed_attempts": value.criteria.maximum_failed_attempts,
            "minimum_supervision_coverage": value.criteria.minimum_supervision_coverage,
        },
        "trials": [
            {
                "episode_ref": trial.episode_ref,
                "deployment": str(trial.deployment),
                "application": str(trial.application),
                "approval": str(trial.approval),
                "supervision_policy": str(trial.supervision_policy),
                "task": {
                    "task_id": str(trial.task.task_id),
                    "schema_version": str(trial.task.schema_version),
                    "sha256": str(trial.task.sha256),
                },
                "action_source": trial.action_source.value,
                "station": str(trial.station),
                "healthy": trial.healthy,
                "supervision_coverage": trial.supervision_coverage,
                "verdict": trial.verdict.value,
            }
            for trial in value.trials
        ],
    }


def canary_qualification_from_dict(value: object) -> CanaryQualification:
    document = _object(
        value,
        "canary qualification",
        {
            "schema",
            "application",
            "approval",
            "target",
            "runtime_criteria",
            "supervision_policy",
            "criteria",
            "trials",
        },
    )
    if document["schema"] != "sx.canary-qualification/v2":
        raise CanaryQualificationError("unsupported canary-qualification schema")
    criteria = _object(
        document["criteria"],
        "canary criteria",
        {
            "required_consecutive_successful_trials",
            "maximum_failed_attempts",
            "minimum_supervision_coverage",
        },
    )
    trials: list[CanaryTrial] = []
    for raw in decode.sequence(document, "trials"):
        item = _object(
            raw,
            "canary trial",
            {
                "episode_ref",
                "deployment",
                "application",
                "approval",
                "supervision_policy",
                "task",
                "action_source",
                "station",
                "healthy",
                "supervision_coverage",
                "verdict",
            },
        )
        task = _object(item["task"], "canary task", {"task_id", "schema_version", "sha256"})
        try:
            source = ActionSource(decode.text(item, "action_source"))
            verdict = TaskVerdict(decode.text(item, "verdict"))
        except ValueError as error:
            raise CanaryQualificationError(f"malformed canary trial: {error}") from error
        trials.append(
            CanaryTrial(
                decode.text(item, "episode_ref"),
                ApplicationDeploymentRef(decode.text(item, "deployment")),
                RobotApplicationRef(decode.text(item, "application")),
                CapabilityApprovalRef(decode.text(item, "approval")),
                SupervisionPolicyRef(decode.text(item, "supervision_policy")),
                TaskContractRef(
                    TaskId(decode.text(task, "task_id")),
                    TaskSchemaVersion(decode.text(task, "schema_version")),
                    Sha256Digest(decode.text(task, "sha256")),
                ),
                source,
                StationId(decode.text(item, "station")),
                decode.boolean(item, "healthy"),
                decode.number(item, "supervision_coverage"),
                verdict,
            )
        )
    return CanaryQualification(
        RobotApplicationRef(decode.text(document, "application")),
        CapabilityApprovalRef(decode.text(document, "approval")),
        station_target_from_dict(document["target"]),
        runtime_criteria_from_dict(document["runtime_criteria"]),
        SupervisionPolicyRef(decode.text(document, "supervision_policy")),
        CanaryCriteria(
            decode.integer(criteria, "required_consecutive_successful_trials"),
            decode.integer(criteria, "maximum_failed_attempts"),
            decode.number(criteria, "minimum_supervision_coverage"),
        ),
        tuple(trials),
    )


def _object(value: object, where: str, fields: set[str]) -> decode.Document:
    document = decode.document(value, where=where, error=CanaryQualificationError)
    if set(document) != fields:
        raise CanaryQualificationError(f"{where} has unknown or missing fields")
    return document
