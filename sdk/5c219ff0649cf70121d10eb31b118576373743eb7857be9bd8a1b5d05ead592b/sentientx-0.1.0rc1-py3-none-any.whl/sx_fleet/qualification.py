"""Deployment-group thresholds for evaluating whole-application qualifications."""

import math
from dataclasses import dataclass

from sx_contracts import decode


class QualificationCriteriaError(ValueError):
    """A deployment group's qualification thresholds are malformed."""


@dataclass(frozen=True, slots=True)
class RuntimeCriteria:
    """Minimum evidence required from an ``ApplicationQualification``.

    The name describes the measured facts, not a separately promotable runtime
    qualification. The sole qualification identity belongs to the complete robot
    application in ``sx_autonomy.ApplicationQualification``.
    """

    clean_process_starts: int
    warmup_samples_per_start: int
    measured_samples_per_start: int
    sustained_duration_s: float
    latency_deadline_ms: float
    maximum_quality_regression: float

    def __post_init__(self) -> None:
        counts = (
            self.clean_process_starts,
            self.warmup_samples_per_start,
            self.measured_samples_per_start,
        )
        if any(isinstance(value, bool) or value < 1 for value in counts):
            raise QualificationCriteriaError("sample counts must be positive integers")
        if not math.isfinite(self.sustained_duration_s) or self.sustained_duration_s <= 0:
            raise QualificationCriteriaError("sustained duration must be positive")
        if not math.isfinite(self.latency_deadline_ms) or self.latency_deadline_ms <= 0:
            raise QualificationCriteriaError("latency deadline must be positive")
        if (
            not math.isfinite(self.maximum_quality_regression)
            or not 0 <= self.maximum_quality_regression <= 1
        ):
            raise QualificationCriteriaError("maximum quality regression must be within [0, 1]")


def runtime_criteria_to_dict(value: RuntimeCriteria) -> dict[str, object]:
    return {
        "clean_process_starts": value.clean_process_starts,
        "warmup_samples_per_start": value.warmup_samples_per_start,
        "measured_samples_per_start": value.measured_samples_per_start,
        "sustained_duration_s": value.sustained_duration_s,
        "latency_deadline_ms": value.latency_deadline_ms,
        "maximum_quality_regression": value.maximum_quality_regression,
    }


def runtime_criteria_from_dict(value: object) -> RuntimeCriteria:
    document = decode.document(
        value, where="application qualification criteria", error=QualificationCriteriaError
    )
    expected = {
        "clean_process_starts",
        "warmup_samples_per_start",
        "measured_samples_per_start",
        "sustained_duration_s",
        "latency_deadline_ms",
        "maximum_quality_regression",
    }
    if set(document) != expected:
        raise QualificationCriteriaError(
            "application qualification criteria have unknown or missing fields"
        )
    return RuntimeCriteria(
        decode.integer(document, "clean_process_starts"),
        decode.integer(document, "warmup_samples_per_start"),
        decode.integer(document, "measured_samples_per_start"),
        decode.number(document, "sustained_duration_s"),
        decode.number(document, "latency_deadline_ms"),
        decode.number(document, "maximum_quality_regression"),
    )
