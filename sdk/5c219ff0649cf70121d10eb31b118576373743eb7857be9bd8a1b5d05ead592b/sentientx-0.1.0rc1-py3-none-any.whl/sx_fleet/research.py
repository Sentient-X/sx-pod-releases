"""Hosted research-run contracts shared by Fleet, stations, the CLI, and MCP.

Fleet resolves an application deployment and capability once.  The station participates in the
durable run state machine through ordered events; it never polls as an independently
configured pod daemon.  Runtime locations, device paths, credentials, and container topology
are deliberately absent from every value in this module.
"""

from __future__ import annotations

from datetime import datetime
from typing import Annotated, Literal, NewType, cast
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, ValidateAs, model_validator
from sx_contracts import (
    CatalogRegistrationState,
    ContentRef,
    DeploymentGroupRef,
    ResearchRunState,
    TaskVerdict,
)

from sx_fleet.commissioning import CatalogDatasetNameWire, ResearchPodId
from sx_fleet.control import ControlRequest, HumanTaskVerdictReceipt
from sx_fleet.deployment import ApplicationDeploymentRef, StationId, TaskLease, TaskLeaseRef
from sx_fleet.physical import ResetExecutorKind, RewardEvidence
from sx_fleet.supervision import SupervisionPolicyRef

ResearchRunId = NewType("ResearchRunId", str)
ResearchRunIdWire = Annotated[ResearchRunId, ValidateAs(str, ResearchRunId)]
ResearchPodIdWire = Annotated[ResearchPodId, ValidateAs(str, ResearchPodId)]
StationIdWire = Annotated[StationId, ValidateAs(str, StationId)]
ApplicationDeploymentRefWire = Annotated[
    ApplicationDeploymentRef, ValidateAs(str, ApplicationDeploymentRef)
]
TaskLeaseRefWire = Annotated[TaskLeaseRef, ValidateAs(str, TaskLeaseRef)]
SupervisionPolicyRefWire = Annotated[SupervisionPolicyRef, ValidateAs(str, SupervisionPolicyRef)]


class ResearchError(ValueError):
    """A hosted research request, transition, or evidence commitment is invalid."""


class IllegalRunTransitionError(ResearchError):
    def __init__(self, current: ResearchRunState, target: ResearchRunState) -> None:
        self.current = current
        self.target = target
        super().__init__(f"research run cannot move from {current.value} to {target.value}")


TERMINAL_RUN_STATES = frozenset(
    {
        ResearchRunState.SUCCEEDED,
        ResearchRunState.FAILED,
        ResearchRunState.CANCELLED,
    }
)

LEGAL_RUN_TRANSITIONS: dict[ResearchRunState, frozenset[ResearchRunState]] = {
    ResearchRunState.ADMITTED: frozenset(
        {
            ResearchRunState.PREPARING,
            ResearchRunState.FAILED,
            ResearchRunState.CANCELLED,
        }
    ),
    ResearchRunState.PREPARING: frozenset(
        {
            ResearchRunState.RUNNING,
            ResearchRunState.WAITING_FOR_CONTROL,
            ResearchRunState.FAILED,
            ResearchRunState.CANCELLED,
        }
    ),
    ResearchRunState.RUNNING: frozenset(
        {
            ResearchRunState.WAITING_FOR_CONTROL,
            ResearchRunState.RESETTING,
            ResearchRunState.FINALIZING,
            ResearchRunState.FAILED,
            ResearchRunState.CANCELLED,
        }
    ),
    ResearchRunState.WAITING_FOR_CONTROL: frozenset(
        {
            ResearchRunState.WAITING_FOR_CONTROL,
            ResearchRunState.RUNNING,
            ResearchRunState.RESETTING,
            ResearchRunState.FINALIZING,
            ResearchRunState.FAILED,
            ResearchRunState.CANCELLED,
        }
    ),
    ResearchRunState.RESETTING: frozenset(
        {
            ResearchRunState.RUNNING,
            ResearchRunState.WAITING_FOR_CONTROL,
            ResearchRunState.FINALIZING,
            ResearchRunState.FAILED,
            ResearchRunState.CANCELLED,
            ResearchRunState.RESETTING,
        }
    ),
    ResearchRunState.FINALIZING: frozenset(
        {
            ResearchRunState.SUCCEEDED,
            ResearchRunState.FAILED,
            ResearchRunState.CANCELLED,
            ResearchRunState.FINALIZING,
        }
    ),
    ResearchRunState.SUCCEEDED: frozenset(),
    ResearchRunState.FAILED: frozenset(),
    ResearchRunState.CANCELLED: frozenset(),
}


def require_transition(current: ResearchRunState, target: ResearchRunState) -> None:
    if target not in LEGAL_RUN_TRANSITIONS[current]:
        raise IllegalRunTransitionError(current, target)


class _Model(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class RunBudget(_Model):
    max_episodes: int = Field(ge=1)
    max_duration_s: float = Field(gt=0.0)


class ResearchRunIn(_Model):
    """The entire routine researcher input: deployment, capability, and finite limits."""

    deployment: ApplicationDeploymentRefWire
    approval: str = Field(pattern=r"^capability-approval:[a-f0-9]{64}$")
    budget: RunBudget


class ResolvedService(_Model):
    """A release-local service identity; the station alone resolves its transport."""

    workload: str = Field(pattern=r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")
    endpoint: str = Field(pattern=r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")
    protocol: Literal["http", "websocket"]


class ApplicationProof(_Model):
    """The exact applied identities that must prove healthy before station arming."""

    deployment: ApplicationDeploymentRefWire
    application: str = Field(pattern=r"^application:[a-f0-9]{64}$")
    approval: str = Field(pattern=r"^capability-approval:[a-f0-9]{64}$")
    task_lease: TaskLease
    supervision_policy: SupervisionPolicyRefWire
    calibrations: tuple[ContentRef, ...]


class AdmissionCheck(_Model):
    name: str = Field(min_length=1)
    ready: bool
    detail: str = Field(min_length=1)


class RunAdmission(_Model):
    """Fleet's actionable, fail-closed admission result."""

    admitted: bool
    checks: tuple[AdmissionCheck, ...] = Field(min_length=1)

    @model_validator(mode="after")
    def truthful(self) -> RunAdmission:
        if self.admitted != all(check.ready for check in self.checks):
            raise ValueError("run admission is true exactly when every check is ready")
        if len({check.name for check in self.checks}) != len(self.checks):
            raise ValueError("run admission check names must be unique")
        return self


class CatalogCommit(_Model):
    """An immutable Catalog fact and the exact receipt Fleet retains for it."""

    content: ContentRef
    registration_id: UUID
    state: CatalogRegistrationState
    receipt: str = Field(min_length=1)


class EpisodeCommit(_Model):
    """One closed episode: raw MCAP capture plus canonical episode segment."""

    episode: str = Field(min_length=1)
    index: int = Field(ge=0)
    outcome: TaskVerdict
    raw_capture: CatalogCommit
    canonical_episode: CatalogCommit

    @model_validator(mode="after")
    def terminal_outcome(self) -> EpisodeCommit:
        if self.outcome is TaskVerdict.UNKNOWN:
            raise ValueError("a closed episode needs a final autonomous or human verdict")
        return self

    @property
    def ready(self) -> bool:
        return (
            self.raw_capture.state is CatalogRegistrationState.READY
            and self.canonical_episode.state is CatalogRegistrationState.READY
        )


class StationRunAssignment(_Model):
    """The immutable hosted assignment a selected station prepares."""

    run_id: ResearchRunIdWire
    station_id: StationIdWire
    pod_id: ResearchPodIdWire
    pod_revision: int = Field(ge=1)
    dataset: CatalogDatasetNameWire
    application: ApplicationProof
    services: tuple[ResolvedService, ...]
    budget: RunBudget

    @model_validator(mode="after")
    def unique_services(self) -> StationRunAssignment:
        endpoint_names = tuple(service.endpoint for service in self.services)
        if len(set(endpoint_names)) != len(endpoint_names):
            raise ValueError("run assignment repeats an application endpoint")
        return self


class StationRunEvent(_Model):
    """One idempotent station-to-Fleet workflow event."""

    run_id: ResearchRunIdWire
    sequence: int = Field(ge=1)
    state: ResearchRunState
    observed_at: datetime
    reason: str | None = Field(default=None, min_length=1)
    control_request: ControlRequest | None = None
    human_verdict: HumanTaskVerdictReceipt | None = None
    reset_executor: ResetExecutorKind | None = None
    reset_evidence: RewardEvidence | None = None
    reset_verdict: TaskVerdict | None = None
    episode: EpisodeCommit | None = None

    @model_validator(mode="after")
    def coherent_event(self) -> StationRunEvent:
        if self.observed_at.tzinfo is None:
            raise ValueError("station run event time must be timezone-aware")
        if self.human_verdict is not None and self.control_request is None:
            raise ValueError("human verdict event must carry its control request")
        if (
            len(
                {
                    self.reset_executor is None,
                    self.reset_evidence is None,
                    self.reset_verdict is None,
                }
            )
            != 1
        ):
            raise ValueError("reset executor, verifier evidence, and verdict must travel together")
        if self.reset_verdict is TaskVerdict.NOT_SATISFIED:
            raise ValueError("reset verification is satisfied or unknown, never task failure")
        if (
            self.state is ResearchRunState.RUNNING
            and self.reset_verdict is not None
            and self.reset_verdict is not TaskVerdict.SATISFIED
        ):
            raise ValueError("autonomy resumes only after a satisfied reset verification")
        if self.episode is not None and self.state not in {
            ResearchRunState.RESETTING,
            ResearchRunState.FINALIZING,
        }:
            raise ValueError("a closed episode enters resetting or finalizing")
        return self


class ResearchRun(_Model):
    """Fleet's authoritative hosted workflow record."""

    run_id: ResearchRunIdWire
    project_id: UUID
    operation_id: str = Field(pattern=r"^fleet-op:[a-f0-9]{32}$")
    idempotency_key: str = Field(min_length=1)
    trace_id: str = Field(min_length=1)
    deployment_group: Annotated[DeploymentGroupRef, ValidateAs(str, DeploymentGroupRef)]
    station_id: StationIdWire
    pod_id: ResearchPodIdWire
    pod_revision: int = Field(ge=1)
    dataset: CatalogDatasetNameWire
    application: ApplicationProof
    services: tuple[ResolvedService, ...]
    budget: RunBudget
    state: ResearchRunState
    last_sequence: int = Field(ge=0)
    episodes: tuple[EpisodeCommit, ...]
    active_control_request: ControlRequest | None
    created_at: datetime
    updated_at: datetime
    reason: str | None = Field(default=None, min_length=1)

    @model_validator(mode="after")
    def coherent_run(self) -> ResearchRun:
        if self.created_at.tzinfo is None or self.updated_at.tzinfo is None:
            raise ValueError("research run times must be timezone-aware")
        if self.updated_at < self.created_at:
            raise ValueError("research run update cannot precede creation")
        if len(self.episodes) > self.budget.max_episodes:
            raise ValueError("research run exceeds its episode budget")
        indexes = tuple(episode.index for episode in self.episodes)
        if indexes != tuple(range(len(indexes))):
            raise ValueError("research episode indexes must be contiguous")
        if self.state is ResearchRunState.SUCCEEDED:
            if not self.episodes:
                raise ValueError("research run cannot succeed without a closed episode")
            if not all(episode.ready for episode in self.episodes):
                raise ValueError("research run cannot succeed before every Catalog commit is ready")
        if (self.state is ResearchRunState.WAITING_FOR_CONTROL) != (
            self.active_control_request is not None
        ):
            raise ValueError("waiting-for-control state must name exactly one control request")
        return self

    @property
    def terminal(self) -> bool:
        return self.state in TERMINAL_RUN_STATES


class ResearchRunOut(_Model):
    run: ResearchRun


class StationRunEventOut(_Model):
    applied: bool
    run: ResearchRun


def research_run_from_dict(value: object) -> ResearchRun:
    """Validate an untrusted wire value as the one canonical research-run model."""

    return ResearchRun.model_validate(value)


def research_run_to_dict(value: ResearchRun) -> dict[str, object]:
    """Serialize the canonical research-run model without a parallel wire schema."""

    return cast("dict[str, object]", value.model_dump(mode="json"))
