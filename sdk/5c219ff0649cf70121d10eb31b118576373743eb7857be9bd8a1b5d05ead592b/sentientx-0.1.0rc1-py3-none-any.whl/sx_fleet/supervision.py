"""Immutable supervision policies and the endpoint protocol every component speaks."""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import StrEnum
from typing import NewType, cast

from sx_contracts import ArtifactId, ContentRef, Sha256Digest, decode
from sx_contracts.identity import CanonicalDocument, JsonValue, content_digest

from sx_fleet.control import ControlQueue

SupervisionPolicyRef = NewType("SupervisionPolicyRef", str)
SupervisionComponentId = NewType("SupervisionComponentId", str)

SUPERVISION_POLICY_SCHEMA = "sx.supervision-policy/v2"
SUPERVISION_ENDPOINT_SCHEMA = "sx.supervision-endpoint/v1"


class SupervisionPolicyError(ValueError):
    """A policy or endpoint message cannot be enforced exactly as written."""


class ComponentPlacement(StrEnum):
    STATION = "station"
    SERVICE = "service"


class UnavailableBehavior(StrEnum):
    CONTINUE = "continue"
    STOP = "stop"


class ControllerKind(StrEnum):
    SO101_LEADER = "so101_leader"


class HumanControlParticipantKind(StrEnum):
    LOCAL_LEADER = "local_leader"
    REMOTE_TELEOPERATOR = "remote_teleoperator"


@dataclass(frozen=True, slots=True)
class ControllerSelector:
    """Fleet-owned selector for a commissioned controller, never a device path."""

    kind: ControllerKind
    labels: tuple[tuple[str, str], ...] = ()

    def __post_init__(self) -> None:
        keys = tuple(key for key, _ in self.labels)
        if keys != tuple(sorted(keys)) or len(set(keys)) != len(keys):
            raise SupervisionPolicyError("controller selector labels need unique sorted keys")
        if any(not key.strip() or not value.strip() for key, value in self.labels):
            raise SupervisionPolicyError("controller selector labels must be non-empty")


@dataclass(frozen=True, slots=True)
class LocalLeader:
    selector: ControllerSelector
    queue: ControlQueue
    deadline_s: float

    @property
    def kind(self) -> HumanControlParticipantKind:
        return HumanControlParticipantKind.LOCAL_LEADER

    def __post_init__(self) -> None:
        _route_deadline(self.deadline_s)


@dataclass(frozen=True, slots=True)
class RemoteTeleoperator:
    queue: ControlQueue
    deadline_s: float

    @property
    def kind(self) -> HumanControlParticipantKind:
        return HumanControlParticipantKind.REMOTE_TELEOPERATOR

    def __post_init__(self) -> None:
        _route_deadline(self.deadline_s)


type HumanControlParticipant = LocalLeader | RemoteTeleoperator


def _route_deadline(value: float) -> None:
    if not math.isfinite(value) or value <= 0.0:
        raise SupervisionPolicyError("human control route deadlines must be positive")


@dataclass(frozen=True, slots=True)
class HumanControlRoute:
    """The exact ordered participants Fleet advances through for human control."""

    participants: tuple[HumanControlParticipant, ...]

    def __post_init__(self) -> None:
        if not self.participants:
            raise SupervisionPolicyError("human control route needs at least one participant")
        kinds = tuple(participant.kind for participant in self.participants)
        if len(set(kinds)) != len(kinds):
            raise SupervisionPolicyError("human control route cannot repeat a participant kind")

    @classmethod
    def local_then_remote(
        cls,
        *,
        local_queue: ControlQueue,
        remote_queue: ControlQueue,
        local_deadline_s: float,
        remote_deadline_s: float,
    ) -> HumanControlRoute:
        return cls(
            (
                LocalLeader(
                    ControllerSelector(ControllerKind.SO101_LEADER),
                    local_queue,
                    local_deadline_s,
                ),
                RemoteTeleoperator(remote_queue, remote_deadline_s),
            )
        )


@dataclass(frozen=True, slots=True)
class ActionBoundsMonitor:
    lower: tuple[float, ...]
    upper: tuple[float, ...]

    def __post_init__(self) -> None:
        if not self.lower or len(self.lower) != len(self.upper):
            raise SupervisionPolicyError("action bounds need equal non-empty vectors")
        if any(
            not math.isfinite(low) or not math.isfinite(high) or low > high
            for low, high in zip(self.lower, self.upper, strict=True)
        ):
            raise SupervisionPolicyError("action bounds must be finite and ordered")


@dataclass(frozen=True, slots=True)
class RewardTrendMonitor:
    window: int
    minimum_slope: float

    def __post_init__(self) -> None:
        if self.window < 2 or not math.isfinite(self.minimum_slope):
            raise SupervisionPolicyError("reward trend needs a finite slope and window >= 2")


@dataclass(frozen=True, slots=True)
class ValueFloorMonitor:
    minimum_value: float

    def __post_init__(self) -> None:
        if not math.isfinite(self.minimum_value):
            raise SupervisionPolicyError("value floor must be finite")


@dataclass(frozen=True, slots=True)
class ModelMonitor:
    """A release-owned model workload and the exact model artifact it serves.

    ``workload`` is resolved from the station workload release or hosted service
    deployment.  Network addresses and credentials are runtime facts and therefore never
    enter the immutable supervision policy or an operator runbook.
    """

    workload: str
    model: ContentRef

    def __post_init__(self) -> None:
        if not self.workload.strip():
            raise SupervisionPolicyError("model monitor needs a workload component")


@dataclass(frozen=True, slots=True)
class HarnessMonitor:
    workload: str
    protocol: str

    def __post_init__(self) -> None:
        if not self.workload.strip() or not self.protocol.strip():
            raise SupervisionPolicyError("harness monitor needs a workload and protocol")


type MonitorMethod = (
    ActionBoundsMonitor | RewardTrendMonitor | ValueFloorMonitor | ModelMonitor | HarnessMonitor
)


@dataclass(frozen=True, slots=True)
class AutomatedResponder:
    workload: str

    def __post_init__(self) -> None:
        if not self.workload.strip():
            raise SupervisionPolicyError("automated responder needs a workload")


type ResponderMethod = AutomatedResponder


@dataclass(frozen=True, slots=True)
class Monitor:
    component_id: SupervisionComponentId
    placement: ComponentPlacement
    timeout_ms: int
    on_unavailable: UnavailableBehavior
    method: MonitorMethod

    def __post_init__(self) -> None:
        _component_laws(self.component_id, self.timeout_ms)


@dataclass(frozen=True, slots=True)
class Responder:
    component_id: SupervisionComponentId
    placement: ComponentPlacement
    timeout_ms: int
    on_unavailable: UnavailableBehavior
    method: ResponderMethod

    def __post_init__(self) -> None:
        _component_laws(self.component_id, self.timeout_ms)


def _component_laws(component_id: SupervisionComponentId, timeout_ms: int) -> None:
    if not str(component_id).strip() or any(character.isspace() for character in component_id):
        raise SupervisionPolicyError("component id must be non-empty and unbroken")
    if isinstance(timeout_ms, bool) or timeout_ms < 1:
        raise SupervisionPolicyError("component timeout must be positive")


@dataclass(frozen=True, slots=True)
class SupervisionPolicy:
    """Concurrent frame monitors followed by deterministic ordered responders."""

    monitors: tuple[Monitor, ...]
    responders: tuple[Responder, ...]
    human_control: HumanControlRoute

    def __post_init__(self) -> None:
        if not self.monitors:
            raise SupervisionPolicyError("a supervision policy needs at least one monitor")
        identities = tuple(
            component.component_id for component in (*self.monitors, *self.responders)
        )
        if len(set(identities)) != len(identities):
            raise SupervisionPolicyError("supervision component ids must be unique")

    @property
    def ref(self) -> SupervisionPolicyRef:
        digest = content_digest(cast("CanonicalDocument", supervision_policy_to_dict(self)))
        return SupervisionPolicyRef(f"supervision-policy:{digest}")


def supervision_policy_to_dict(policy: SupervisionPolicy) -> dict[str, object]:
    return {
        "schema": SUPERVISION_POLICY_SCHEMA,
        "monitors": [_monitor_to_dict(component) for component in policy.monitors],
        "responders": [_responder_to_dict(component) for component in policy.responders],
        "human_control": {
            "route": [
                _human_control_participant_to_dict(participant)
                for participant in policy.human_control.participants
            ]
        },
    }


def _monitor_to_dict(component: Monitor) -> dict[str, object]:
    method = component.method
    if isinstance(method, ActionBoundsMonitor):
        config: dict[str, object] = {
            "method": "action_bounds",
            "lower": list(method.lower),
            "upper": list(method.upper),
        }
    elif isinstance(method, RewardTrendMonitor):
        config = {
            "method": "reward_trend",
            "window": method.window,
            "minimum_slope": method.minimum_slope,
        }
    elif isinstance(method, ValueFloorMonitor):
        config = {"method": "value_floor", "minimum_value": method.minimum_value}
    elif isinstance(method, ModelMonitor):
        config = {
            "method": "model",
            "workload": method.workload,
            "model": _content_to_dict(method.model),
        }
    else:
        config = {
            "method": "harness",
            "workload": method.workload,
            "protocol": method.protocol,
        }
    return _component_to_dict(component, config)


def _responder_to_dict(component: Responder) -> dict[str, object]:
    method = component.method
    config: dict[str, object] = {"method": "automated", "workload": method.workload}
    return _component_to_dict(component, config)


def _human_control_participant_to_dict(
    participant: HumanControlParticipant,
) -> dict[str, object]:
    if isinstance(participant, LocalLeader):
        return {
            "kind": participant.kind.value,
            "selector": {
                "kind": participant.selector.kind.value,
                "labels": [list(item) for item in participant.selector.labels],
            },
            "queue": participant.queue.value,
            "deadline_s": participant.deadline_s,
        }
    return {
        "kind": participant.kind.value,
        "queue": participant.queue.value,
        "deadline_s": participant.deadline_s,
    }


def _component_to_dict(
    component: Monitor | Responder, method: dict[str, object]
) -> dict[str, object]:
    return {
        "component_id": str(component.component_id),
        "placement": component.placement.value,
        "timeout_ms": component.timeout_ms,
        "on_unavailable": component.on_unavailable.value,
        "config": method,
    }


def supervision_policy_from_dict(value: object) -> SupervisionPolicy:
    document = decode.exactly(
        value,
        {"schema", "monitors", "responders", "human_control"},
        where="supervision policy",
        error=SupervisionPolicyError,
    )
    if document["schema"] != SUPERVISION_POLICY_SCHEMA:
        raise SupervisionPolicyError(
            f"unsupported supervision policy schema {document['schema']!r}"
        )
    return SupervisionPolicy(
        monitors=tuple(_monitor_from_dict(item) for item in decode.sequence(document, "monitors")),
        responders=tuple(
            _responder_from_dict(item) for item in decode.sequence(document, "responders")
        ),
        human_control=_human_control_route_from_dict(document["human_control"]),
    )


def _monitor_from_dict(value: object) -> Monitor:
    component, config = _parse_component(value, "monitor")
    method = decode.text(config, "method")
    if method == "action_bounds":
        config = decode.exactly(config, {"method", "lower", "upper"})
        implementation: MonitorMethod = ActionBoundsMonitor(
            decode.numbers(config, "lower"),
            decode.numbers(config, "upper"),
        )
    elif method == "reward_trend":
        config = decode.exactly(config, {"method", "window", "minimum_slope"})
        implementation = RewardTrendMonitor(
            decode.integer(config, "window"),
            decode.number(config, "minimum_slope"),
        )
    elif method == "value_floor":
        config = decode.exactly(config, {"method", "minimum_value"})
        implementation = ValueFloorMonitor(decode.number(config, "minimum_value"))
    elif method == "model":
        config = decode.exactly(config, {"method", "workload", "model"})
        implementation = ModelMonitor(
            decode.text(config, "workload"),
            _content_from_dict(config["model"], "model monitor artifact"),
        )
    elif method == "harness":
        config = decode.exactly(config, {"method", "workload", "protocol"})
        implementation = HarnessMonitor(
            decode.text(config, "workload"), decode.text(config, "protocol")
        )
    else:
        raise SupervisionPolicyError(f"unknown monitor method {method!r}")
    return Monitor(
        component.component_id,
        component.placement,
        component.timeout_ms,
        component.on_unavailable,
        implementation,
    )


def _responder_from_dict(value: object) -> Responder:
    component, config = _parse_component(value, "responder")
    method = decode.text(config, "method")
    if method == "automated":
        config = decode.exactly(config, {"method", "workload"})
        implementation = AutomatedResponder(decode.text(config, "workload"))
    else:
        raise SupervisionPolicyError(f"unknown responder method {method!r}")
    return Responder(
        component.component_id,
        component.placement,
        component.timeout_ms,
        component.on_unavailable,
        implementation,
    )


def _human_control_route_from_dict(value: object) -> HumanControlRoute:
    document = decode.exactly(
        value, {"route"}, where="human control route", error=SupervisionPolicyError
    )
    return HumanControlRoute(
        tuple(
            _human_control_participant_from_dict(item)
            for item in decode.sequence(document, "route")
        )
    )


def _human_control_participant_from_dict(value: object) -> HumanControlParticipant:
    document = decode.document(
        value, where="human control participant", error=SupervisionPolicyError
    )
    kind = decode.text(document, "kind")
    if kind == HumanControlParticipantKind.LOCAL_LEADER.value:
        exact = decode.exactly(
            document,
            {"kind", "selector", "queue", "deadline_s"},
            where="local leader route participant",
            error=SupervisionPolicyError,
        )
        selector = decode.exactly(
            exact["selector"],
            {"kind", "labels"},
            where="controller selector",
            error=SupervisionPolicyError,
        )
        labels: list[tuple[str, str]] = []
        for value in decode.sequence(selector, "labels"):
            pair = decode.sequence({"pair": value}, "pair", error=SupervisionPolicyError)
            if len(pair) != 2 or not all(isinstance(item, str) for item in pair):
                raise SupervisionPolicyError("controller selector label must be a text pair")
            labels.append((str(pair[0]), str(pair[1])))
        return LocalLeader(
            ControllerSelector(ControllerKind(decode.text(selector, "kind")), tuple(labels)),
            ControlQueue(decode.text(exact, "queue")),
            decode.number(exact, "deadline_s"),
        )
    if kind == HumanControlParticipantKind.REMOTE_TELEOPERATOR.value:
        exact = decode.exactly(
            document,
            {"kind", "queue", "deadline_s"},
            where="remote teleoperator route participant",
            error=SupervisionPolicyError,
        )
        return RemoteTeleoperator(
            ControlQueue(decode.text(exact, "queue")),
            decode.number(exact, "deadline_s"),
        )
    raise SupervisionPolicyError(f"unknown human control participant {kind!r}")


@dataclass(frozen=True, slots=True)
class _Component:
    component_id: SupervisionComponentId
    placement: ComponentPlacement
    timeout_ms: int
    on_unavailable: UnavailableBehavior


def _parse_component(value: object, kind: str) -> tuple[_Component, decode.Document]:
    document = decode.exactly(
        value,
        {"component_id", "placement", "timeout_ms", "on_unavailable", "config"},
        where=f"supervision {kind}",
        error=SupervisionPolicyError,
    )
    try:
        common = _Component(
            SupervisionComponentId(decode.text(document, "component_id")),
            ComponentPlacement(decode.text(document, "placement")),
            decode.integer(document, "timeout_ms"),
            UnavailableBehavior(decode.text(document, "on_unavailable")),
        )
    except ValueError as error:
        raise SupervisionPolicyError(f"malformed supervision {kind}: {error}") from error
    config = decode.document(
        document["config"], where=f"supervision {kind} config", error=SupervisionPolicyError
    )
    return common, config


def _content_to_dict(value: ContentRef) -> dict[str, str]:
    return {"artifact_id": str(value.artifact_id), "sha256": str(value.sha256)}


def _content_from_dict(value: object, label: str) -> ContentRef:
    document = decode.exactly(
        value,
        {"artifact_id", "sha256"},
        where=label,
        error=SupervisionPolicyError,
    )
    return ContentRef(
        ArtifactId(decode.text(document, "artifact_id")),
        Sha256Digest(decode.text(document, "sha256")),
    )


@dataclass(frozen=True, slots=True)
class SupervisionEndpointRequest:
    policy: SupervisionPolicyRef
    deployment: str
    station: str
    episode: str
    step: int
    observation: JsonValue
    proposal: JsonValue
    deadline: float

    def __post_init__(self) -> None:
        if any(
            not value.strip()
            for value in (str(self.policy), self.deployment, self.station, self.episode)
        ):
            raise SupervisionPolicyError("supervision request identities must not be empty")
        if self.step < 0 or not math.isfinite(self.deadline):
            raise SupervisionPolicyError("supervision request step/deadline is invalid")


@dataclass(frozen=True, slots=True)
class ResponseIdentity:
    policy: SupervisionPolicyRef
    episode: str
    step: int
    issued_at: float
    valid_until: float

    def __post_init__(self) -> None:
        if not str(self.policy).strip() or not self.episode.strip() or self.step < 0:
            raise SupervisionPolicyError("supervision response identity is incomplete")
        if (
            not math.isfinite(self.issued_at)
            or not math.isfinite(self.valid_until)
            or self.valid_until < self.issued_at
        ):
            raise SupervisionPolicyError("supervision response validity is malformed")


@dataclass(frozen=True, slots=True)
class Clear:
    identity: ResponseIdentity


@dataclass(frozen=True, slots=True)
class Alert:
    identity: ResponseIdentity
    reason: str


@dataclass(frozen=True, slots=True)
class Stop:
    identity: ResponseIdentity
    reason: str


@dataclass(frozen=True, slots=True)
class Override:
    identity: ResponseIdentity
    action: tuple[float, ...]

    def __post_init__(self) -> None:
        if not self.action or any(not math.isfinite(value) for value in self.action):
            raise SupervisionPolicyError("override action must be a finite non-empty vector")


@dataclass(frozen=True, slots=True)
class TakeoverRequest:
    identity: ResponseIdentity
    reason: str


type SupervisionEndpointResponse = Clear | Alert | Stop | Override | TakeoverRequest


def require_current_response(
    request: SupervisionEndpointRequest,
    response: SupervisionEndpointResponse,
    *,
    now: float,
) -> SupervisionEndpointResponse:
    """Reject stale or mismatched responses before any responder may affect a station."""

    identity = response.identity
    if (
        identity.policy != request.policy
        or identity.episode != request.episode
        or identity.step != request.step
    ):
        raise SupervisionPolicyError("supervision response identity does not match its request")
    if now > request.deadline or now > identity.valid_until or now < identity.issued_at:
        raise SupervisionPolicyError("supervision response is outside its validity interval")
    return response


def endpoint_request_to_dict(value: SupervisionEndpointRequest) -> dict[str, object]:
    return {
        "schema": SUPERVISION_ENDPOINT_SCHEMA,
        "policy": str(value.policy),
        "deployment": value.deployment,
        "station": value.station,
        "episode": value.episode,
        "step": value.step,
        "observation": value.observation,
        "proposal": value.proposal,
        "deadline": value.deadline,
    }


def endpoint_request_from_dict(value: object) -> SupervisionEndpointRequest:
    document = decode.exactly(
        value,
        {
            "schema",
            "policy",
            "deployment",
            "station",
            "episode",
            "step",
            "observation",
            "proposal",
            "deadline",
        },
        where="supervision endpoint request",
        error=SupervisionPolicyError,
    )
    if document["schema"] != SUPERVISION_ENDPOINT_SCHEMA:
        raise SupervisionPolicyError("unsupported supervision endpoint schema")
    return SupervisionEndpointRequest(
        SupervisionPolicyRef(decode.text(document, "policy")),
        decode.text(document, "deployment"),
        decode.text(document, "station"),
        decode.text(document, "episode"),
        decode.integer(document, "step"),
        cast("JsonValue", document["observation"]),
        cast("JsonValue", document["proposal"]),
        decode.number(document, "deadline"),
    )


def endpoint_response_to_dict(value: SupervisionEndpointResponse) -> dict[str, object]:
    identity = value.identity
    document: dict[str, object] = {
        "schema": SUPERVISION_ENDPOINT_SCHEMA,
        "policy": str(identity.policy),
        "episode": identity.episode,
        "step": identity.step,
        "issued_at": identity.issued_at,
        "valid_until": identity.valid_until,
    }
    if isinstance(value, Clear):
        document["action"] = "clear"
    elif isinstance(value, Alert | Stop | TakeoverRequest):
        document["action"] = (
            "alert"
            if isinstance(value, Alert)
            else "stop"
            if isinstance(value, Stop)
            else "takeover_request"
        )
        document["reason"] = value.reason
    else:
        document["action"] = "override"
        document["override"] = list(value.action)
    return document


def endpoint_response_from_dict(value: object) -> SupervisionEndpointResponse:
    document = decode.document(
        value, where="supervision endpoint response", error=SupervisionPolicyError
    )
    action = decode.text(document, "action")
    common = {
        "schema",
        "policy",
        "episode",
        "step",
        "issued_at",
        "valid_until",
        "action",
    }
    extra: set[str] = (
        set() if action == "clear" else {"override"} if action == "override" else {"reason"}
    )
    if set(document) != common | extra or document["schema"] != SUPERVISION_ENDPOINT_SCHEMA:
        raise SupervisionPolicyError("supervision endpoint response has unknown fields")
    identity = ResponseIdentity(
        SupervisionPolicyRef(decode.text(document, "policy")),
        decode.text(document, "episode"),
        decode.integer(document, "step"),
        decode.number(document, "issued_at"),
        decode.number(document, "valid_until"),
    )
    if action == "clear":
        return Clear(identity)
    if action == "alert":
        return Alert(identity, decode.text(document, "reason"))
    if action == "stop":
        return Stop(identity, decode.text(document, "reason"))
    if action == "takeover_request":
        return TakeoverRequest(identity, decode.text(document, "reason"))
    if action == "override":
        return Override(identity, decode.numbers(document, "override"))
    raise SupervisionPolicyError(f"unknown supervision response action {action!r}")
