"""Fleet control requests, purpose-scoped leases, and authenticated human verdicts."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import NewType
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, model_validator
from sx_contracts import TaskVerdict

ControlRequestId = NewType("ControlRequestId", str)


class ControlContractError(ValueError):
    """A control request, lease, or human receipt is internally inconsistent."""


class ControlQueue(StrEnum):
    SENTIENT = "sentient"
    CUSTOMER = "customer"
    THIRD_PARTY = "third_party"


class ControlPurpose(StrEnum):
    SUPERVISION_ESCALATION = "supervision_escalation"
    TERMINAL_VERIFICATION = "terminal_verification"
    RESET = "reset"


class ControlCause(StrEnum):
    SUPERVISOR_STOP = "supervisor_stop"
    ROBOMETER_UNKNOWN = "robometer_unknown"
    RESET_REQUIRED = "reset_required"
    RESET_VERIFICATION_UNKNOWN = "reset_verification_unknown"


class ControlModality(StrEnum):
    LOCAL_LEADER = "local_leader"
    REMOTE_TELEOPERATOR = "remote_teleoperator"
    HANDS = "hands"
    AUTOMATED_RESET = "automated_reset"


class ControlRequestState(StrEnum):
    PENDING = "pending"
    OFFERED = "offered"
    LEASED = "leased"
    AWAITING_VERDICT = "awaiting_verdict"
    COMPLETED = "completed"
    EXPIRED = "expired"
    CANCELLED = "cancelled"


class _Model(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ObservationActionSpan(_Model):
    """The causal episode slice a verdict or reset decision is allowed to cover."""

    first_observation: str = Field(min_length=1)
    last_observation: str = Field(min_length=1)
    action_receipts: tuple[str, ...]

    @model_validator(mode="after")
    def receipt_identities(self) -> ObservationActionSpan:
        if len(set(self.action_receipts)) != len(self.action_receipts) or any(
            not receipt.strip() for receipt in self.action_receipts
        ):
            raise ValueError("observation/action span receipt identities must be unique")
        return self


class ControlRequest(_Model):
    """One durable, routed request for exclusive human or reset participation."""

    request_id: str = Field(pattern=r"^control-request:[a-f0-9]{32}$")
    purpose: ControlPurpose
    cause: ControlCause
    run_id: str = Field(min_length=1)
    episode_id: str = Field(min_length=1)
    station_id: str = Field(min_length=1)
    route: tuple[ControlModality, ...] = Field(min_length=1)
    route_index: int = Field(ge=0)
    selected_modality: ControlModality | None
    deadline: datetime
    lease_id: UUID | None
    evidence_span: ObservationActionSpan | None
    state: ControlRequestState

    @model_validator(mode="after")
    def coherent_state(self) -> ControlRequest:
        if self.deadline.tzinfo is None:
            raise ValueError("control request deadline must be timezone-aware")
        if len(set(self.route)) != len(self.route):
            raise ValueError("control request route cannot repeat a modality")
        reset_modalities = {ControlModality.HANDS, ControlModality.AUTOMATED_RESET}
        if self.purpose is not ControlPurpose.RESET and reset_modalities.intersection(self.route):
            raise ValueError("task control routes cannot contain reset-only modalities")
        if self.purpose is ControlPurpose.RESET and self.cause not in {
            ControlCause.RESET_REQUIRED,
            ControlCause.RESET_VERIFICATION_UNKNOWN,
        }:
            raise ValueError("reset control request needs a reset cause")
        if self.purpose is ControlPurpose.TERMINAL_VERIFICATION and (
            self.cause is not ControlCause.ROBOMETER_UNKNOWN
        ):
            raise ValueError("terminal verification is caused by unknown Robometer evidence")
        if self.route_index >= len(self.route):
            raise ValueError("control request route index is outside the route")
        expected = self.route[self.route_index]
        selected = self.selected_modality
        if self.state is ControlRequestState.PENDING:
            if selected is not None or self.lease_id is not None:
                raise ValueError("pending control request cannot select or lease a participant")
        elif selected is None or selected is not expected:
            raise ValueError("active control request must select its current route participant")
        if (
            self.state
            in {
                ControlRequestState.LEASED,
                ControlRequestState.AWAITING_VERDICT,
            }
            and self.lease_id is None
        ):
            raise ValueError("leased control request needs its lease identity")
        if (
            self.state
            in {
                ControlRequestState.OFFERED,
                ControlRequestState.EXPIRED,
                ControlRequestState.CANCELLED,
            }
            and self.lease_id is not None
        ):
            raise ValueError("unleased control request cannot carry a lease identity")
        return self


class ControlLease(_Model):
    """Exclusive station authority scoped to one request, purpose, and episode."""

    station: str = Field(min_length=1)
    control_request: str = Field(pattern=r"^control-request:[a-f0-9]{32}$")
    purpose: ControlPurpose
    episode: str = Field(min_length=1)
    lease_id: UUID
    session_id: UUID
    generation: int = Field(ge=1, le=2**32 - 1)
    controller_identity: str = Field(min_length=1)
    participant_identity: str = Field(min_length=1)
    modality: ControlModality
    expires_at_us: int = Field(ge=0, le=2**64 - 1)

    @model_validator(mode="after")
    def purpose_scoped_modality(self) -> ControlLease:
        if (
            self.modality in {ControlModality.HANDS, ControlModality.AUTOMATED_RESET}
            and self.purpose is not ControlPurpose.RESET
        ):
            raise ValueError("reset-only modality cannot receive task-control authority")
        return self

    def active_at(self, at_us: int) -> bool:
        return at_us < self.expires_at_us


class HumanTaskVerdictReceipt(_Model):
    """The only human fact that may settle a takeover episode."""

    verdict: TaskVerdict
    control_request: str = Field(pattern=r"^control-request:[a-f0-9]{32}$")
    control_lease: UUID
    controller_identity: str = Field(min_length=1)
    episode: str = Field(min_length=1)
    observation_action_span: ObservationActionSpan
    issued_at: datetime
    note: str | None = Field(default=None, min_length=1)

    @model_validator(mode="after")
    def final_verdict(self) -> HumanTaskVerdictReceipt:
        if self.verdict is TaskVerdict.UNKNOWN:
            raise ValueError("a human task verdict must be satisfied or not_satisfied")
        if self.issued_at.tzinfo is None:
            raise ValueError("human verdict receipt time must be timezone-aware")
        return self
