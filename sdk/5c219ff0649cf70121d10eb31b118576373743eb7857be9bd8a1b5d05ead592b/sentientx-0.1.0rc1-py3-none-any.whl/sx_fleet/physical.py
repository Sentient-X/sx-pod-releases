"""Exact physical-task conformance, reward evidence, and reset routing.

Fleet binds these values to a deployment group.  A station receives the resulting
content-addressed conformer with its run assignment; researchers never reconstruct it
from URLs, serial numbers, task text, or environment variables.

The reward model is deliberately not an authority.  It emits :class:`RewardEvidence`.
Only :func:`reward_verdict` applies the task's pinned thresholds, and an unhealthy or
ambiguous result is always ``UNKNOWN`` so the supervision route can hand control to a
human under Fleet's existing control lease.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import StrEnum
from typing import NewType, cast

from sx_contracts import (
    ArtifactId,
    ContentRef,
    RobotApplication,
    Sha256Digest,
    TaskContractRef,
    TaskId,
    TaskSchemaVersion,
    TaskVerdict,
    decode,
    robot_application_from_dict,
    robot_application_to_dict,
)
from sx_contracts.identity import CanonicalDocument, content_digest

from sx_fleet.control import ControlQueue

PHYSICAL_TASK_CONFORMER_SCHEMA = "sx.physical-task-conformer/v2"
REWARD_EVIDENCE_SCHEMA = "sx.reward-evidence/v1"

PhysicalTaskConformerRef = NewType("PhysicalTaskConformerRef", str)


class PhysicalTaskConformerError(ValueError):
    """A physical task cannot be verified or reset exactly as declared."""


class RewardHealth(StrEnum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNAVAILABLE = "unavailable"


class EpisodeRouteKind(StrEnum):
    HANDOFF = "handoff"
    CLOSE_AND_RESET = "close_and_reset"


class ResetExecutorKind(StrEnum):
    AUTOMATED = "automated"
    TELEOPERATOR = "teleoperator"
    LOCAL_RESEARCHER = "local_researcher"


class LocalResetMethod(StrEnum):
    HANDS = "hands"
    LOCAL_CONTROLLER = "local_controller"


@dataclass(frozen=True, slots=True)
class RobometerVerdictPolicy:
    """Pinned terminal thresholds for interpreting Robometer evidence.

    Values between the two bounds are intentionally inconclusive.  A verdict is only
    possible on a completed episode with enough causal samples from a healthy model.
    """

    satisfied_at_or_above: float
    not_satisfied_at_or_below: float
    minimum_samples: int = 2

    def __post_init__(self) -> None:
        if (
            not math.isfinite(self.satisfied_at_or_above)
            or not math.isfinite(self.not_satisfied_at_or_below)
            or not 0.0 <= self.not_satisfied_at_or_below < self.satisfied_at_or_above <= 1.0
        ):
            raise PhysicalTaskConformerError(
                "reward verdict thresholds must be ordered inside [0, 1]"
            )
        if isinstance(self.minimum_samples, bool) or self.minimum_samples < 1:
            raise PhysicalTaskConformerError("reward verdict minimum_samples must be positive")


@dataclass(frozen=True, slots=True)
class TaskVerifier:
    """The supervision component and calibration allowed to judge this task."""

    component_id: str
    calibration: ContentRef
    verdict: RobometerVerdictPolicy

    def __post_init__(self) -> None:
        if not self.component_id.strip() or any(
            character.isspace() for character in self.component_id
        ):
            raise PhysicalTaskConformerError(
                "task verifier component_id must be non-empty and unbroken"
            )


@dataclass(frozen=True, slots=True)
class AutomatedReset:
    """An exact reset application with its own governed control boundary."""

    application: RobotApplication

    @property
    def kind(self) -> ResetExecutorKind:
        return ResetExecutorKind.AUTOMATED


@dataclass(frozen=True, slots=True)
class TeleoperatorReset:
    queue: ControlQueue

    @property
    def kind(self) -> ResetExecutorKind:
        return ResetExecutorKind.TELEOPERATOR


@dataclass(frozen=True, slots=True)
class LocalResearcherReset:
    """A researcher physically present at the pod performs the authored reset."""

    methods: frozenset[LocalResetMethod]

    def __post_init__(self) -> None:
        if not self.methods:
            raise PhysicalTaskConformerError(
                "local researcher reset needs hands, local_controller, or both"
            )

    @property
    def kind(self) -> ResetExecutorKind:
        return ResetExecutorKind.LOCAL_RESEARCHER


type ResetExecutor = AutomatedReset | TeleoperatorReset | LocalResearcherReset


@dataclass(frozen=True, slots=True)
class ResetPolicy:
    """Ordered reset executors followed by one exact scene verifier."""

    route: tuple[ResetExecutor, ...]
    scene_verifier: ContentRef
    verdict: RobometerVerdictPolicy
    deadline_s: float

    def __post_init__(self) -> None:
        if not self.route:
            raise PhysicalTaskConformerError("reset policy needs at least one executor")
        kinds = tuple(executor.kind for executor in self.route)
        if len(set(kinds)) != len(kinds):
            raise PhysicalTaskConformerError("reset route cannot repeat an executor kind")
        if not math.isfinite(self.deadline_s) or self.deadline_s <= 0.0:
            raise PhysicalTaskConformerError("reset deadline_s must be positive")

    @classmethod
    def local_researcher(
        cls,
        *,
        scene_verifier: ContentRef,
        verdict: RobometerVerdictPolicy,
        deadline_s: float,
    ) -> ResetPolicy:
        """The default local-researcher then remote-teleoperator reset route."""

        return cls(
            (
                LocalResearcherReset(frozenset({LocalResetMethod.HANDS})),
                TeleoperatorReset(ControlQueue.SENTIENT),
            ),
            scene_verifier,
            verdict,
            deadline_s,
        )

    def select(self, available: frozenset[ResetExecutorKind]) -> ResetExecutor:
        """Select the first configured and currently available executor, or fail closed."""

        for executor in self.route:
            if executor.kind in available:
                return executor
        raise PhysicalTaskConformerError("no configured reset executor is currently available")


@dataclass(frozen=True, slots=True)
class PhysicalTaskConformer:
    """Everything physical execution adds to an existing governed task contract."""

    task: TaskContractRef
    verifier: TaskVerifier
    safety_profile: ContentRef
    reset: ResetPolicy

    @property
    def ref(self) -> PhysicalTaskConformerRef:
        digest = content_digest(cast("CanonicalDocument", physical_task_conformer_to_dict(self)))
        return PhysicalTaskConformerRef(f"physical-task-conformer:{digest}")


@dataclass(frozen=True, slots=True)
class RewardEvidence:
    """Causal, model-identified evidence from one terminal reward-model evaluation."""

    model: ContentRef
    episode_id: str
    observation_ids: tuple[str, ...]
    progress: tuple[float, ...]
    success: tuple[float, ...]
    episode_complete: bool
    health: RewardHealth
    started_at_us: int
    completed_at_us: int
    detail: str | None = None

    def __post_init__(self) -> None:
        if not self.episode_id.strip():
            raise PhysicalTaskConformerError("reward evidence episode_id must not be empty")
        if (
            not self.observation_ids
            or len(self.observation_ids) != len(self.progress)
            or len(self.progress) != len(self.success)
        ):
            raise PhysicalTaskConformerError(
                "reward evidence ids, progress, and success must be non-empty and parallel"
            )
        if len(set(self.observation_ids)) != len(self.observation_ids) or any(
            not identity.strip() for identity in self.observation_ids
        ):
            raise PhysicalTaskConformerError(
                "reward evidence observation_ids must be unique non-empty strings"
            )
        if any(
            not math.isfinite(value) or not 0.0 <= value <= 1.0
            for value in (*self.progress, *self.success)
        ):
            raise PhysicalTaskConformerError("reward evidence scores must be within [0, 1]")
        if (
            isinstance(self.started_at_us, bool)
            or isinstance(self.completed_at_us, bool)
            or self.started_at_us < 0
            or self.completed_at_us < self.started_at_us
        ):
            raise PhysicalTaskConformerError("reward evidence timing is invalid")
        if self.detail is not None and not self.detail.strip():
            raise PhysicalTaskConformerError("reward evidence detail must be null or non-empty")


@dataclass(frozen=True, slots=True)
class HandoffEpisode:
    """Autonomy yields while the existing episode stays open under a human lease."""

    verdict: TaskVerdict

    @property
    def kind(self) -> EpisodeRouteKind:
        return EpisodeRouteKind.HANDOFF


@dataclass(frozen=True, slots=True)
class CloseEpisodeAndReset:
    """Close the episode with this verdict, then enter its configured reset phase."""

    verdict: TaskVerdict
    reset: ResetPolicy

    @property
    def kind(self) -> EpisodeRouteKind:
        return EpisodeRouteKind.CLOSE_AND_RESET


type EpisodeRoute = HandoffEpisode | CloseEpisodeAndReset


def reward_verdict(evidence: RewardEvidence, policy: RobometerVerdictPolicy) -> TaskVerdict:
    """Interpret terminal evidence; ambiguity and model trouble always route to humans."""

    if (
        not evidence.episode_complete
        or evidence.health is not RewardHealth.HEALTHY
        or len(evidence.success) < policy.minimum_samples
    ):
        return TaskVerdict.UNKNOWN
    success = evidence.success[-1]
    if success >= policy.satisfied_at_or_above:
        return TaskVerdict.SATISFIED
    if success <= policy.not_satisfied_at_or_below:
        return TaskVerdict.NOT_SATISFIED
    return TaskVerdict.UNKNOWN


def route_reward_evidence(
    evidence: RewardEvidence, conformer: PhysicalTaskConformer
) -> EpisodeRoute:
    """Apply the configured "clear verdict or human" rule without an implicit fallback.

    ``UNKNOWN`` always yields the current episode to a human.  A clear satisfied or
    not-satisfied verdict is final and closes for reset before another autonomous episode
    can begin.
    """

    verdict = reward_verdict(evidence, conformer.verifier.verdict)
    if verdict is TaskVerdict.UNKNOWN:
        return HandoffEpisode(verdict)
    return CloseEpisodeAndReset(verdict, conformer.reset)


def physical_task_conformer_to_dict(value: PhysicalTaskConformer) -> dict[str, object]:
    return {
        "schema": PHYSICAL_TASK_CONFORMER_SCHEMA,
        "task": _task_to_dict(value.task),
        "verifier": {
            "component_id": value.verifier.component_id,
            "calibration": _content_to_dict(value.verifier.calibration),
            "verdict": {
                "satisfied_at_or_above": value.verifier.verdict.satisfied_at_or_above,
                "not_satisfied_at_or_below": value.verifier.verdict.not_satisfied_at_or_below,
                "minimum_samples": value.verifier.verdict.minimum_samples,
            },
        },
        "safety_profile": _content_to_dict(value.safety_profile),
        "reset": {
            "route": [_reset_executor_to_dict(executor) for executor in value.reset.route],
            "scene_verifier": _content_to_dict(value.reset.scene_verifier),
            "verdict": {
                "satisfied_at_or_above": value.reset.verdict.satisfied_at_or_above,
                "not_satisfied_at_or_below": value.reset.verdict.not_satisfied_at_or_below,
                "minimum_samples": value.reset.verdict.minimum_samples,
            },
            "deadline_s": value.reset.deadline_s,
        },
    }


def physical_task_conformer_from_dict(value: object) -> PhysicalTaskConformer:
    document = decode.exactly(
        value,
        {"schema", "task", "verifier", "safety_profile", "reset"},
        where="physical task conformer",
        error=PhysicalTaskConformerError,
    )
    if document["schema"] != PHYSICAL_TASK_CONFORMER_SCHEMA:
        raise PhysicalTaskConformerError(
            f"unsupported physical-task conformer schema {document['schema']!r}"
        )
    verifier = decode.exactly(
        document["verifier"],
        {"component_id", "calibration", "verdict"},
        where="task verifier",
        error=PhysicalTaskConformerError,
    )
    verdict = decode.exactly(
        verifier["verdict"],
        {"satisfied_at_or_above", "not_satisfied_at_or_below", "minimum_samples"},
        where="reward verdict policy",
        error=PhysicalTaskConformerError,
    )
    reset = decode.exactly(
        document["reset"],
        {"route", "scene_verifier", "verdict", "deadline_s"},
        where="reset policy",
        error=PhysicalTaskConformerError,
    )
    reset_verdict = decode.exactly(
        reset["verdict"],
        {"satisfied_at_or_above", "not_satisfied_at_or_below", "minimum_samples"},
        where="reset verdict policy",
        error=PhysicalTaskConformerError,
    )
    try:
        return PhysicalTaskConformer(
            task=_task_from_dict(document["task"]),
            verifier=TaskVerifier(
                decode.text(verifier, "component_id"),
                _content_from_dict(verifier["calibration"], "task verifier calibration"),
                RobometerVerdictPolicy(
                    decode.number(verdict, "satisfied_at_or_above"),
                    decode.number(verdict, "not_satisfied_at_or_below"),
                    decode.integer(verdict, "minimum_samples"),
                ),
            ),
            safety_profile=_content_from_dict(document["safety_profile"], "safety profile"),
            reset=ResetPolicy(
                tuple(_reset_executor_from_dict(item) for item in decode.sequence(reset, "route")),
                _content_from_dict(reset["scene_verifier"], "reset scene verifier"),
                RobometerVerdictPolicy(
                    decode.number(reset_verdict, "satisfied_at_or_above"),
                    decode.number(reset_verdict, "not_satisfied_at_or_below"),
                    decode.integer(reset_verdict, "minimum_samples"),
                ),
                decode.number(reset, "deadline_s"),
            ),
        )
    except ValueError as error:
        if isinstance(error, PhysicalTaskConformerError):
            raise
        raise PhysicalTaskConformerError(str(error)) from error


def reward_evidence_to_dict(value: RewardEvidence) -> dict[str, object]:
    return {
        "schema": REWARD_EVIDENCE_SCHEMA,
        "model": _content_to_dict(value.model),
        "episode_id": value.episode_id,
        "observation_ids": list(value.observation_ids),
        "progress": list(value.progress),
        "success": list(value.success),
        "episode_complete": value.episode_complete,
        "health": value.health.value,
        "started_at_us": value.started_at_us,
        "completed_at_us": value.completed_at_us,
        "detail": value.detail,
    }


def reward_evidence_from_dict(value: object) -> RewardEvidence:
    document = decode.exactly(
        value,
        {
            "schema",
            "model",
            "episode_id",
            "observation_ids",
            "progress",
            "success",
            "episode_complete",
            "health",
            "started_at_us",
            "completed_at_us",
            "detail",
        },
        where="reward evidence",
        error=PhysicalTaskConformerError,
    )
    if document["schema"] != REWARD_EVIDENCE_SCHEMA:
        raise PhysicalTaskConformerError(
            f"unsupported reward-evidence schema {document['schema']!r}"
        )
    detail = document["detail"]
    if detail is not None and not isinstance(detail, str):
        raise PhysicalTaskConformerError("reward evidence detail must be text or null")
    complete = document["episode_complete"]
    if not isinstance(complete, bool):
        raise PhysicalTaskConformerError("reward evidence episode_complete must be boolean")
    try:
        return RewardEvidence(
            _content_from_dict(document["model"], "reward model"),
            decode.text(document, "episode_id"),
            tuple(decode.texts(document, "observation_ids")),
            tuple(decode.numbers(document, "progress")),
            tuple(decode.numbers(document, "success")),
            complete,
            RewardHealth(decode.text(document, "health")),
            decode.integer(document, "started_at_us"),
            decode.integer(document, "completed_at_us"),
            detail,
        )
    except ValueError as error:
        if isinstance(error, PhysicalTaskConformerError):
            raise
        raise PhysicalTaskConformerError(str(error)) from error


def _reset_executor_to_dict(value: ResetExecutor) -> dict[str, object]:
    if isinstance(value, AutomatedReset):
        return {
            "kind": value.kind.value,
            "application": robot_application_to_dict(value.application),
        }
    if isinstance(value, TeleoperatorReset):
        return {"kind": value.kind.value, "queue": value.queue.value}
    return {
        "kind": value.kind.value,
        "methods": sorted(method.value for method in value.methods),
    }


def _reset_executor_from_dict(value: object) -> ResetExecutor:
    document = decode.document(value, where="reset executor", error=PhysicalTaskConformerError)
    kind = decode.text(document, "kind")
    if kind == ResetExecutorKind.AUTOMATED.value and set(document) == {
        "kind",
        "application",
    }:
        return AutomatedReset(robot_application_from_dict(document["application"]))
    if kind == ResetExecutorKind.TELEOPERATOR.value and set(document) == {"kind", "queue"}:
        return TeleoperatorReset(ControlQueue(decode.text(document, "queue")))
    if kind == ResetExecutorKind.LOCAL_RESEARCHER.value and set(document) == {
        "kind",
        "methods",
    }:
        return LocalResearcherReset(
            frozenset(LocalResetMethod(method) for method in decode.texts(document, "methods"))
        )
    raise PhysicalTaskConformerError(f"unknown or malformed reset executor {kind!r}")


def _content_to_dict(value: ContentRef) -> dict[str, str]:
    return {"artifact_id": str(value.artifact_id), "sha256": str(value.sha256)}


def _content_from_dict(value: object, label: str) -> ContentRef:
    document = decode.exactly(
        value,
        {"artifact_id", "sha256"},
        where=label,
        error=PhysicalTaskConformerError,
    )
    return ContentRef(
        ArtifactId(decode.text(document, "artifact_id")),
        Sha256Digest(decode.text(document, "sha256")),
    )


def _task_to_dict(value: TaskContractRef) -> dict[str, str]:
    return {
        "task_id": str(value.task_id),
        "schema_version": str(value.schema_version),
        "sha256": str(value.sha256),
    }


def _task_from_dict(value: object) -> TaskContractRef:
    document = decode.exactly(
        value,
        {"task_id", "schema_version", "sha256"},
        where="physical task",
        error=PhysicalTaskConformerError,
    )
    return TaskContractRef(
        TaskId(decode.text(document, "task_id")),
        TaskSchemaVersion(decode.text(document, "schema_version")),
        Sha256Digest(decode.text(document, "sha256")),
    )
