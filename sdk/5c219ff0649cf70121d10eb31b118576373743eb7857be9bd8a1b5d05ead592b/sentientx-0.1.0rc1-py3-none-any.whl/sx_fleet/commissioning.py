"""Fleet-owned station, research-pod, and controller resources.

These are the normal forms used by commissioning and admission.  A station reports
device identities; a pod revision binds those identities to task-facing roles; a
controller identifies one enrolled human-input capability.  None of the three carries
runtime URLs, USB paths, container topology, release policy, or deployment-group facts.
"""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Annotated, NewType
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, ValidateAs, model_validator
from sx_contracts import ContentRef, RobotApplicationRef, StationTarget

from sx_fleet.deployment import StationId, TaskLeaseRef
from sx_fleet.supervision import ControllerKind

DeviceId = NewType("DeviceId", str)
ResearchPodId = NewType("ResearchPodId", str)
ControllerId = NewType("ControllerId", str)
CatalogDatasetName = NewType("CatalogDatasetName", str)

DeviceIdWire = Annotated[
    DeviceId,
    ValidateAs(str, DeviceId),
    Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$"),
]
StationIdWire = Annotated[
    StationId,
    ValidateAs(str, StationId),
    Field(min_length=1, max_length=512),
]

#: What one station may report, and therefore what any projection of it must carry.
#: The numbers are the contract: a station admitted above them could be stored and
#: never answered, so the bound belongs where the value is built, not only on the
#: wire that happens to be reading it today.
MAX_STATION_LABELS = 256
MAX_STATION_DEVICES = 256
ResearchPodIdWire = Annotated[ResearchPodId, ValidateAs(str, ResearchPodId)]
ControllerIdWire = Annotated[
    ControllerId,
    ValidateAs(str, ControllerId),
    Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$"),
]
CatalogDatasetNameWire = Annotated[
    CatalogDatasetName,
    ValidateAs(str, CatalogDatasetName),
    Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9._/-]{0,255}$"),
]


class CommissioningError(ValueError):
    """A station resource or commissioning revision is internally inconsistent."""


class DeviceKind(StrEnum):
    """What the station's own discovery observed, named as the device it is.

    A station discovers a *bus adapter*, not a robot product: the USB facts that
    identify an SO-101's serial adapter identify every Feetech-bus body's adapter
    equally, because they are the same part. Naming the adapter is what makes a
    customer-assembled body commissionable on the same station — qualification is
    per actuator model (`sx_embodiments.ActuatorModel`, enforced where the bus
    driver resolves), amortized across every body that binds it, which is the
    economics of the motor restriction.
    """

    FEETECH_BUS = "feetech_bus"
    REALSENSE = "realsense"
    OAK_D = "oak_d"


class DeviceHealth(StrEnum):
    READY = "ready"
    DEGRADED = "degraded"
    UNAVAILABLE = "unavailable"


class DeviceCapability(StrEnum):
    """A station-proved hardware operation, not mere USB visibility."""

    ACTUATOR_CONTROL = "actuator_control"
    SAFE_STOP = "safe_stop"
    VIDEO_STREAM = "video_stream"
    HUMAN_INPUT = "human_input"


class StationReadiness(StrEnum):
    READY = "ready"
    DEGRADED = "degraded"
    OFFLINE = "offline"
    SAFE_STOPPED = "safe_stopped"


class ResearchPodRole(StrEnum):
    FOLLOWER = "follower"
    EXO_CAMERA = "exo_camera"
    WRIST_CAMERA = "wrist_camera"
    LOCAL_LEADER = "local_leader"


class ControllerHealth(StrEnum):
    READY = "ready"
    OFFLINE = "offline"
    IN_USE = "in_use"


class _Model(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class DiscoveredDevice(_Model):
    """One stable hardware identity from the station's own discovery pass."""

    device_id: DeviceIdWire
    kind: DeviceKind
    health: DeviceHealth
    capabilities: tuple[DeviceCapability, ...]
    observed_at: datetime

    @model_validator(mode="after")
    def valid_identity(self) -> DiscoveredDevice:
        if not str(self.device_id).strip() or any(
            character.isspace() for character in str(self.device_id)
        ):
            raise ValueError("device identity must be non-empty and unbroken")
        if self.observed_at.tzinfo is None:
            raise ValueError("device observation time must be timezone-aware")
        if self.capabilities != tuple(sorted(set(self.capabilities), key=str)):
            raise ValueError("device capabilities need unique canonical ordering")
        return self


class StationLabel(_Model):
    key: str = Field(min_length=1)
    value: str = Field(min_length=1)


class EvidenceCapacity(_Model):
    """Station-local immutable-evidence reserve, reported in bytes."""

    total: int = Field(gt=0)
    available: int = Field(ge=0)
    uncommitted: int = Field(ge=0)
    reserve: int = Field(ge=0)

    @model_validator(mode="after")
    def bounded(self) -> EvidenceCapacity:
        if self.available > self.total or self.uncommitted > self.total:
            raise ValueError("station evidence counters cannot exceed total capacity")
        if self.reserve > self.total:
            raise ValueError("station evidence reserve cannot exceed total capacity")
        return self

    @property
    def can_start_episode(self) -> bool:
        return self.available >= self.reserve


class Station(_Model):
    """An enrolled station and its latest authenticated, discovered facts."""

    station_id: StationIdWire
    project_id: UUID
    target: StationTarget
    labels: tuple[StationLabel, ...] = Field(max_length=MAX_STATION_LABELS)
    inventory_revision: int = Field(ge=1)
    inventory_observed_at: datetime
    devices: tuple[DiscoveredDevice, ...] = Field(max_length=MAX_STATION_DEVICES)
    health: StationReadiness
    active_application: Annotated[RobotApplicationRef, ValidateAs(str, RobotApplicationRef)] | None
    active_task_lease: (
        Annotated[TaskLeaseRef, ValidateAs(str, TaskLeaseRef), Field(min_length=1)] | None
    )
    evidence: EvidenceCapacity

    @model_validator(mode="after")
    def coherent_inventory(self) -> Station:
        if self.inventory_observed_at.tzinfo is None:
            raise ValueError("station inventory time must be timezone-aware")
        identities = tuple(device.device_id for device in self.devices)
        if len(set(identities)) != len(identities):
            raise ValueError("station inventory device identities must be unique")
        if any(device.observed_at > self.inventory_observed_at for device in self.devices):
            raise ValueError("device observation cannot be newer than its inventory")
        label_keys = tuple(label.key for label in self.labels)
        if label_keys != tuple(sorted(label_keys)) or len(set(label_keys)) != len(label_keys):
            raise ValueError("station labels need unique sorted keys")
        if any(not label.key.strip() or not label.value.strip() for label in self.labels):
            raise ValueError("station labels must be non-empty")
        return self

    def device(self, identity: DeviceId) -> DiscoveredDevice:
        matches = tuple(device for device in self.devices if device.device_id == identity)
        if len(matches) != 1:
            raise CommissioningError(
                f"station {self.station_id!s} has no unique device {identity!s}"
            )
        return matches[0]


class DeviceRoleBinding(_Model):
    role: ResearchPodRole
    device_id: DeviceIdWire


class CalibrationBinding(_Model):
    role: ResearchPodRole
    artifact: ContentRef


class ResearchPod(_Model):
    """One immutable commissioning revision for a physical research embodiment."""

    pod_id: ResearchPodIdWire
    project_id: UUID
    revision: int = Field(ge=1)
    station_id: StationIdWire
    bindings: tuple[DeviceRoleBinding, ...] = Field(min_length=3)
    calibrations: tuple[CalibrationBinding, ...] = Field(min_length=1)
    dataset: CatalogDatasetNameWire
    committed_at: datetime

    @model_validator(mode="after")
    def complete_binding(self) -> ResearchPod:
        if self.committed_at.tzinfo is None:
            raise ValueError("pod commit time must be timezone-aware")
        roles = tuple(binding.role for binding in self.bindings)
        devices = tuple(binding.device_id for binding in self.bindings)
        if len(set(roles)) != len(roles):
            raise ValueError("research pod roles must be unique")
        if len(set(devices)) != len(devices):
            raise ValueError("one station device cannot fill two research pod roles")
        required = {
            ResearchPodRole.FOLLOWER,
            ResearchPodRole.EXO_CAMERA,
            ResearchPodRole.WRIST_CAMERA,
        }
        if not required.issubset(roles):
            raise ValueError("research pod needs follower, exo camera, and wrist camera roles")
        calibration_roles = tuple(binding.role for binding in self.calibrations)
        if len(set(calibration_roles)) != len(calibration_roles):
            raise ValueError("research pod calibration roles must be unique")
        if not set(calibration_roles).issubset(roles):
            raise ValueError("research pod calibration names an unbound role")
        if not required.issubset(calibration_roles):
            raise ValueError(
                "research pod needs follower, exo camera, and wrist camera calibrations"
            )
        if not str(self.dataset).strip():
            raise ValueError("research pod dataset must be non-empty")
        return self

    def binding(self, role: ResearchPodRole) -> DeviceRoleBinding:
        matches = tuple(binding for binding in self.bindings if binding.role is role)
        if len(matches) != 1:
            raise CommissioningError(f"research pod has no unique {role.value} binding")
        return matches[0]

    def validate_inventory(self, station: Station) -> None:
        """Prove this revision still names healthy, operational devices on its station."""

        if station.project_id != self.project_id or station.station_id != self.station_id:
            raise CommissioningError("research pod and station identity disagree")
        expected_kinds = {
            ResearchPodRole.FOLLOWER: DeviceKind.FEETECH_BUS,
            ResearchPodRole.EXO_CAMERA: DeviceKind.REALSENSE,
            ResearchPodRole.WRIST_CAMERA: DeviceKind.OAK_D,
            ResearchPodRole.LOCAL_LEADER: DeviceKind.FEETECH_BUS,
        }
        required_capabilities = {
            ResearchPodRole.FOLLOWER: {
                DeviceCapability.ACTUATOR_CONTROL,
                DeviceCapability.SAFE_STOP,
            },
            ResearchPodRole.EXO_CAMERA: {DeviceCapability.VIDEO_STREAM},
            ResearchPodRole.WRIST_CAMERA: {DeviceCapability.VIDEO_STREAM},
            ResearchPodRole.LOCAL_LEADER: {DeviceCapability.HUMAN_INPUT},
        }
        for binding in self.bindings:
            device = station.device(binding.device_id)
            if device.kind is not expected_kinds[binding.role]:
                raise CommissioningError(f"{binding.role.value} is bound to {device.kind.value}")
            if device.health is not DeviceHealth.READY:
                raise CommissioningError(f"{binding.role.value} device is {device.health.value}")
            missing = required_capabilities[binding.role].difference(device.capabilities)
            if missing:
                names = ", ".join(sorted(capability.value for capability in missing))
                raise CommissioningError(f"{binding.role.value} device has not proved {names}")


class StationController(_Model):
    """A leader arm on a Feetech bus, discovered and owned by the same station runtime.

    ``ControllerKind.SO101_LEADER`` is the wire spelling deployment-group selectors
    already carry; the device it binds is the bus adapter, so any Feetech-bus leader
    commissions here.
    """

    kind: ControllerKind = ControllerKind.SO101_LEADER
    controller_id: ControllerIdWire
    project_id: UUID
    station_id: StationIdWire
    device_id: DeviceIdWire
    health: ControllerHealth


class BridgedController(_Model):
    """A leader arm on another enrolled controller-bridge host."""

    kind: ControllerKind = ControllerKind.SO101_LEADER
    controller_id: ControllerIdWire
    project_id: UUID
    bridge_subject: str = Field(pattern=r"^controller:[a-zA-Z0-9._-]+$")
    health: ControllerHealth


type Controller = StationController | BridgedController


class CommissioningReadiness(_Model):
    """The actionable result of Fleet's complete pre-commit readiness gate."""

    ready: bool
    checks: tuple[str, ...]
    failures: tuple[str, ...]

    @model_validator(mode="after")
    def truthful(self) -> CommissioningReadiness:
        if not self.checks:
            raise ValueError("commissioning readiness needs at least one performed check")
        if self.ready == bool(self.failures):
            raise ValueError("readiness must be true exactly when no failures remain")
        if any(not value.strip() for value in (*self.checks, *self.failures)):
            raise ValueError("readiness checks and failures must be non-empty text")
        return self


class StationInventoryReport(_Model):
    """Authenticated station facts; Fleet supplies project identity from the credential."""

    target: StationTarget
    inventory_revision: int = Field(ge=1)
    inventory_observed_at: datetime
    devices: tuple[DiscoveredDevice, ...]
    health: StationReadiness
    active_application: Annotated[RobotApplicationRef, ValidateAs(str, RobotApplicationRef)] | None
    active_task_lease: Annotated[TaskLeaseRef, ValidateAs(str, TaskLeaseRef)] | None
    evidence: EvidenceCapacity


class ResearchPodCommit(_Model):
    """User-selected role bindings; Fleet owns project, revision, and commit time."""

    pod_id: ResearchPodIdWire
    station_id: StationIdWire
    bindings: tuple[DeviceRoleBinding, ...] = Field(min_length=3)
    calibrations: tuple[CalibrationBinding, ...] = Field(min_length=1)
    dataset: CatalogDatasetNameWire


class StationControllerCommit(_Model):
    controller_id: ControllerIdWire
    station_id: StationIdWire
    device_id: DeviceIdWire


class BridgedControllerReport(_Model):
    controller_id: ControllerIdWire
    health: ControllerHealth
