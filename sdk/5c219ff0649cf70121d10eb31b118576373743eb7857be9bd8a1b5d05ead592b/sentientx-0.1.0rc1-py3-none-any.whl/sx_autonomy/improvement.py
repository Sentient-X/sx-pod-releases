"""The one structural goal for governed Autonomy improvement campaigns."""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from datetime import timedelta
from typing import Literal

from sx_contracts import (
    DeploymentGroupRef,
    OperationContractError,
    TaskContractRef,
    decode,
)
from sx_worlds import WorldId, WorldRunId


class ImprovementGoalError(ValueError):
    """An improvement goal is incomplete or admits an unsafe budget."""


@dataclass(frozen=True, slots=True)
class TaskBrief:
    name: str
    objective: str

    def __post_init__(self) -> None:
        if not self.name.strip() or not self.objective.strip():
            raise ImprovementGoalError("a task brief requires a name and objective")


@dataclass(frozen=True, slots=True)
class SimulationTarget:
    world: WorldId


@dataclass(frozen=True, slots=True)
class PhysicalTarget:
    group: DeploymentGroupRef

    def __post_init__(self) -> None:
        if not str(self.group).strip():
            raise ImprovementGoalError("a physical target requires a deployment group")


type ImprovementTarget = SimulationTarget | PhysicalTarget


@dataclass(frozen=True, slots=True)
class CampaignBudget:
    max_hypotheses: int
    active_duration: timedelta
    max_parallelism: int

    def __post_init__(self) -> None:
        if (
            self.max_hypotheses < 1
            or self.active_duration <= timedelta(0)
            or self.max_parallelism < 1
            or self.max_parallelism > self.max_hypotheses
        ):
            raise ImprovementGoalError("campaign budget must be positive and internally bounded")


@dataclass(frozen=True, slots=True)
class ImprovementGoal:
    task: TaskBrief | TaskContractRef
    target: ImprovementTarget
    budget: CampaignBudget

    @property
    def identity(self) -> str:
        """Content identity over the task, execution target, and campaign budget."""

        document = asdict(self)
        budget = document["budget"]
        if not isinstance(budget, dict):  # pragma: no cover - dataclass construction law
            raise ImprovementGoalError("campaign budget did not serialize as a record")
        budget["active_duration"] = self.budget.active_duration.total_seconds()
        payload = json.dumps(document, sort_keys=True, separators=(",", ":"), default=str)
        return f"improvement:{hashlib.sha256(payload.encode()).hexdigest()}"


@dataclass(frozen=True, slots=True)
class ImprovementRound:
    index: int
    hypothesis: str
    evidence_refs: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class Improved:
    """The campaign produced a passing registered evaluation."""

    evaluation: WorldRunId
    rounds: tuple[ImprovementRound, ...]
    kind: Literal["improved"] = field(default="improved", init=False)


@dataclass(frozen=True, slots=True)
class ImprovementExhausted:
    rounds: tuple[ImprovementRound, ...]
    reason: str
    kind: Literal["exhausted"] = field(default="exhausted", init=False)


@dataclass(frozen=True, slots=True)
class ImprovementStopped:
    rounds: tuple[ImprovementRound, ...]
    reason: str
    kind: Literal["stopped"] = field(default="stopped", init=False)


type ImprovementResult = Improved | ImprovementExhausted | ImprovementStopped


@dataclass(frozen=True, slots=True)
class ImprovementProgress:
    """What a running campaign is spending, as its owner reports it.

    ``phase`` is the durable workflow's own live line ("round 2: awaiting training
    tj-1"), so it exists only once the workflow has stated one. An accepted campaign
    therefore has *no* progress at all rather than a zero this value invented — the
    absence lives on the receipt, and every value of this type is a live campaign.
    """

    phase: str
    rounds_spent: int

    def __post_init__(self) -> None:
        if not self.phase.strip():
            raise OperationContractError("improvement progress phase must not be empty")
        if self.rounds_spent < 0:
            raise OperationContractError("improvement progress cannot spend negative rounds")


def improvement_progress_from_dict(value: object) -> ImprovementProgress:
    """Read one improvement progress ledger, or refuse it typed."""

    document = decode.exactly(
        value,
        {"phase", "rounds_spent"},
        where="improvement progress",
        error=OperationContractError,
    )
    return ImprovementProgress(
        phase=decode.text(document, "phase"),
        rounds_spent=decode.integer(document, "rounds_spent"),
    )


def improvement_progress_to_dict(progress: ImprovementProgress) -> dict[str, object]:
    """Write one improvement progress ledger into a receipt's progress mapping."""

    return {"phase": progress.phase, "rounds_spent": progress.rounds_spent}
