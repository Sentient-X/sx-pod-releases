"""What supervision a release demands, as enforceable facts rather than prose."""

import math
from dataclasses import dataclass
from enum import StrEnum
from typing import Final

from sx_contracts import SupervisionLayer


class SupervisionPlanRejectedError(ValueError):
    """A supervision plan states something no fleet can honor as written."""


class Placement(StrEnum):
    """Where a component runs, as a deployment fact — never a vendor or venue name.

    `EDGE` is the robot host itself: deterministic, model-free screening that no
    network can delay. `SERVER` is anything reached over the internet, which this
    platform treats as unreliable for low latency — a server rung supervises
    asynchronously and proves itself alive by heartbeat, it is never waited on.
    """

    EDGE = "edge"
    SERVER = "server"


EDGE_CAPABLE_LAYERS: Final = frozenset({SupervisionLayer.L0_HEURISTIC, SupervisionLayer.L1_REWARD})
"""The rungs whose methods can be model-free, and so can run on the robot host.

L2 dispatches a coding agent and L3 summons a human; both are network effects by
definition and cannot be mirrored locally.
"""


@dataclass(frozen=True, slots=True)
class RungRequirement:
    """What one ladder rung must do for this deployment, and where it must run."""

    layer: SupervisionLayer
    required: bool
    """A required rung's loss stops the robot; an advisory rung's loss is a flag."""
    placement: Placement


@dataclass(frozen=True, slots=True)
class SupervisionRequirements:
    """The supervision a release demands, as enforceable facts rather than prose.

    Every field is read by an enforcement path: `rungs` decides what the ladder must
    configure and what the robot screens locally, `availability_timeout_s` is the
    lease a required server rung must renew by heartbeat, and
    `escalation_deadline_s` is how long an unanswered escalation may stand before
    both sides safe-stop.
    """

    rungs: tuple[RungRequirement, ...]
    availability_timeout_s: float = 60.0
    escalation_deadline_s: float = 60.0

    def __post_init__(self) -> None:
        if not self.rungs:
            raise SupervisionPlanRejectedError("a supervision plan needs at least one rung")
        layers = [rung.layer for rung in self.rungs]
        if len(set(layers)) != len(layers):
            raise SupervisionPlanRejectedError("each supervision layer appears at most once")
        if not any(rung.required for rung in self.rungs):
            raise SupervisionPlanRejectedError(
                "a supervision plan needs at least one required rung; all-advisory "
                "supervision is unsupervised motion"
            )
        for rung in self.rungs:
            if rung.placement is Placement.EDGE and rung.layer not in EDGE_CAPABLE_LAYERS:
                raise SupervisionPlanRejectedError(
                    f"{rung.layer.name} cannot run at the edge; only "
                    f"{'/'.join(sorted(layer.name for layer in EDGE_CAPABLE_LAYERS))} "
                    "are model-free"
                )
        # Finite as well as positive: an infinite lease is a rung that can never be
        # observed to have died, which reads as supervision without being it.
        for name, seconds in (
            ("availability_timeout_s", self.availability_timeout_s),
            ("escalation_deadline_s", self.escalation_deadline_s),
        ):
            if not math.isfinite(seconds) or seconds <= 0.0:
                raise SupervisionPlanRejectedError(f"{name} must be positive and finite")

    @property
    def needs_live_server(self) -> bool:
        """Whether losing the server's heartbeat must stop the robot."""
        return any(rung.required and rung.placement is Placement.SERVER for rung in self.rungs)
