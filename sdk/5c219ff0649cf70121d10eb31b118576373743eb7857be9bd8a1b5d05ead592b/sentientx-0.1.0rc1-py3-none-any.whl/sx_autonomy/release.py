"""One exact task approval for one qualified robot application."""

from dataclasses import dataclass
from enum import StrEnum
from typing import NewType

from sx_actions import ActionInterface, ActionInterfaceId
from sx_contracts import (
    RobotApplication,
    Sha256Digest,
    TaskContractRef,
    TaskFamilyRef,
    TaskRoleAssignments,
    contract_ref,
)
from sx_contracts.identity import CanonicalDocument, content_id
from sx_embodiments import EmbodimentId
from sx_worlds import World, WorldEvaluation

from sx_autonomy.performance import ApplicationQualification
from sx_autonomy.supervision import SupervisionRequirements

CapabilityApprovalRef = NewType("CapabilityApprovalRef", str)

CAPABILITY_APPROVAL_SCHEMA = "sx.capability-approval/v1"


class CapabilityApprovalError(ValueError):
    """The application, qualification, task gate, or supervision facts disagree."""


class EvidenceAttestation(StrEnum):
    CATALOG = "catalog"


@dataclass(frozen=True, slots=True)
class CapabilityApproval:
    """Autonomy proof for one exact task, with no copied evidence facts."""

    evaluation: WorldEvaluation
    qualification: ApplicationQualification
    supervision: SupervisionRequirements

    def __post_init__(self) -> None:
        subject = self.evaluation.run.subject
        if not isinstance(subject, RobotApplication):
            raise CapabilityApprovalError(
                "a capability approval needs an evaluated robot application"
            )
        if not self.evaluation.passed:
            raise CapabilityApprovalError("Worlds evaluation did not pass its task gate")
        if self.qualification.application != subject:
            raise CapabilityApprovalError("qualification targets another application")
        if not self.qualification.passed:
            raise CapabilityApprovalError("application qualification did not pass")
        family = TaskFamilyRef(str(self.evaluation.run.world.task.family))
        if family not in subject.capabilities:
            raise CapabilityApprovalError(
                "the evaluated task family is not declared by the application"
            )

    @property
    def ref(self) -> CapabilityApprovalRef:
        return CapabilityApprovalRef(
            f"capability-approval:{content_id(Sha256Digest, _approval_payload(self))}"
        )

    @property
    def application(self) -> RobotApplication:
        subject = self.evaluation.run.subject
        if not isinstance(subject, RobotApplication):  # pragma: no cover - constructor law
            raise CapabilityApprovalError("approval subject is not an application")
        return subject

    @property
    def world(self) -> World:
        return self.evaluation.run.world

    @property
    def task(self) -> TaskContractRef:
        return contract_ref(self.world.task)

    @property
    def embodiment_id(self) -> EmbodimentId:
        return self.world.scene.embodiment.id

    @property
    def role_assignments(self) -> TaskRoleAssignments:
        return self.world.role_assignments

    @property
    def action_interface(self) -> ActionInterface:
        return self.world.action_interface

    @property
    def action_interface_id(self) -> ActionInterfaceId:
        return self.world.action_interface.id


def capability_approval_digest(approval: CapabilityApproval) -> Sha256Digest:
    return content_id(Sha256Digest, _approval_payload(approval))


def _approval_payload(approval: CapabilityApproval) -> CanonicalDocument:
    return {
        "schema": CAPABILITY_APPROVAL_SCHEMA,
        "evaluation": {
            "run_id": str(approval.evaluation.run.id),
            "score": approval.evaluation.score,
            "threshold": approval.evaluation.threshold,
            "metrics": approval.evaluation.metrics.to_dict(),
        },
        "qualification": str(approval.qualification.ref),
        "supervision": {
            "rungs": [
                {
                    "layer": rung.layer.value,
                    "required": rung.required,
                    "placement": rung.placement.value,
                }
                for rung in approval.supervision.rungs
            ],
            "availability_timeout_s": approval.supervision.availability_timeout_s,
            "escalation_deadline_s": approval.supervision.escalation_deadline_s,
        },
    }
