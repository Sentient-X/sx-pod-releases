"""Whole-application qualification on one exact station target."""

import math
from dataclasses import dataclass
from typing import NewType

from sx_contracts import ContentRef, RobotApplication, StationTarget, WorkloadName
from sx_contracts.identity import CanonicalDocument, content_digest

ApplicationQualificationRef = NewType("ApplicationQualificationRef", str)
APPLICATION_QUALIFICATION_SCHEMA = "sx.application-qualification/v1"

MIN_CLEAN_STARTS = 3
MIN_SUSTAINED_DURATION_S = 1_800.0


class ApplicationQualificationError(ValueError):
    """Qualification evidence is incomplete or contradicts the application."""


@dataclass(frozen=True, slots=True)
class LatencyDistribution:
    """Client-visible latency through the robot-control boundary."""

    p50_ms: float
    p95_ms: float
    p99_ms: float
    deadline_ms: float

    def __post_init__(self) -> None:
        values = (self.p50_ms, self.p95_ms, self.p99_ms, self.deadline_ms)
        if any(not math.isfinite(value) or value <= 0.0 for value in values):
            raise ApplicationQualificationError(
                "latencies and deadline must be positive and finite"
            )
        if not self.p50_ms <= self.p95_ms <= self.p99_ms:
            raise ApplicationQualificationError(
                "latency percentiles must be ordered p50 <= p95 <= p99"
            )

    @property
    def passed(self) -> bool:
        return self.p99_ms <= self.deadline_ms


@dataclass(frozen=True, slots=True)
class WorkloadObservation:
    workload: WorkloadName
    clean_starts: int
    maximum_startup_ms: float
    peak_cpu_millis: int
    peak_memory_mib: int
    peak_pids: int
    healthy: bool
    stable: bool

    def __post_init__(self) -> None:
        if isinstance(self.clean_starts, bool) or self.clean_starts < MIN_CLEAN_STARTS:
            raise ApplicationQualificationError(
                f"each workload needs at least {MIN_CLEAN_STARTS} clean starts"
            )
        if not math.isfinite(self.maximum_startup_ms) or self.maximum_startup_ms <= 0.0:
            raise ApplicationQualificationError("workload startup duration must be positive")
        peaks = (self.peak_cpu_millis, self.peak_memory_mib, self.peak_pids)
        if any(isinstance(value, bool) or value < 1 for value in peaks):
            raise ApplicationQualificationError("workload resource peaks must be positive")


@dataclass(frozen=True, slots=True)
class SafeDegradation:
    internet_loss_safe: bool
    stale_remote_decisions_rejected: bool
    local_fallback: WorkloadName | None = None


@dataclass(frozen=True, slots=True)
class ApplicationQualification:
    """Fleet-owned proof that the complete graph runs on its exact target."""

    application: RobotApplication
    observed_target: StationTarget
    workloads: tuple[WorkloadObservation, ...]
    healthy_connections: tuple[tuple[WorkloadName, str], ...]
    sustained_duration_s: float
    latency: LatencyDistribution
    degradation: SafeDegradation
    robot_control_handshake: bool
    images_verified: bool
    artifacts_verified: bool
    evidence: ContentRef

    def __post_init__(self) -> None:
        if self.observed_target != self.application.target:
            raise ApplicationQualificationError(
                "qualification target differs from the application target"
            )
        expected_workloads = {workload.name: workload for workload in self.application.workloads}
        observed_names = tuple(observation.workload for observation in self.workloads)
        if len(set(observed_names)) != len(observed_names) or set(observed_names) != set(
            expected_workloads
        ):
            raise ApplicationQualificationError(
                "qualification must observe every application workload exactly once"
            )
        for observation in self.workloads:
            budget = expected_workloads[observation.workload].resources
            if (
                observation.peak_cpu_millis > budget.cpu_millis
                or observation.peak_memory_mib > budget.memory_mib
                or observation.peak_pids > budget.pids
            ):
                raise ApplicationQualificationError(
                    f"workload {observation.workload} exceeded its resource budget"
                )
        expected_connections = {
            (workload.name, str(connection.name))
            for workload in self.application.workloads
            for connection in workload.connects
        }
        if set(self.healthy_connections) != expected_connections or len(
            self.healthy_connections
        ) != len(expected_connections):
            raise ApplicationQualificationError(
                "qualification must health-check every declared connection exactly once"
            )
        if (
            not math.isfinite(self.sustained_duration_s)
            or self.sustained_duration_s < MIN_SUSTAINED_DURATION_S
        ):
            raise ApplicationQualificationError(
                f"qualification needs at least {MIN_SUSTAINED_DURATION_S:g} sustained seconds"
            )
        fallback = self.degradation.local_fallback
        if fallback is not None and fallback not in expected_workloads:
            raise ApplicationQualificationError(
                "safe-degradation fallback names an unknown workload"
            )

    @property
    def passed(self) -> bool:
        return (
            self.latency.passed
            and all(item.healthy and item.stable for item in self.workloads)
            and self.degradation.internet_loss_safe
            and self.degradation.stale_remote_decisions_rejected
            and self.robot_control_handshake
            and self.images_verified
            and self.artifacts_verified
        )

    @property
    def ref(self) -> ApplicationQualificationRef:
        return ApplicationQualificationRef(
            f"application-qualification:{content_digest(_qualification_payload(self))}"
        )


def _qualification_payload(value: ApplicationQualification) -> CanonicalDocument:
    return {
        "schema": APPLICATION_QUALIFICATION_SCHEMA,
        "application": str(value.application.ref),
        "observed_target": str(value.observed_target.ref),
        "workloads": [
            {
                "workload": str(item.workload),
                "clean_starts": item.clean_starts,
                "maximum_startup_ms": item.maximum_startup_ms,
                "peak_cpu_millis": item.peak_cpu_millis,
                "peak_memory_mib": item.peak_memory_mib,
                "peak_pids": item.peak_pids,
                "healthy": item.healthy,
                "stable": item.stable,
            }
            for item in value.workloads
        ],
        "healthy_connections": [list(item) for item in value.healthy_connections],
        "sustained_duration_s": value.sustained_duration_s,
        "latency": {
            "p50_ms": value.latency.p50_ms,
            "p95_ms": value.latency.p95_ms,
            "p99_ms": value.latency.p99_ms,
            "deadline_ms": value.latency.deadline_ms,
        },
        "degradation": {
            "internet_loss_safe": value.degradation.internet_loss_safe,
            "stale_remote_decisions_rejected": value.degradation.stale_remote_decisions_rejected,
            "local_fallback": (
                None
                if value.degradation.local_fallback is None
                else str(value.degradation.local_fallback)
            ),
        },
        "robot_control_handshake": value.robot_control_handshake,
        "images_verified": value.images_verified,
        "artifacts_verified": value.artifacts_verified,
        "evidence": {
            "artifact_id": str(value.evidence.artifact_id),
            "sha256": str(value.evidence.sha256),
        },
    }
