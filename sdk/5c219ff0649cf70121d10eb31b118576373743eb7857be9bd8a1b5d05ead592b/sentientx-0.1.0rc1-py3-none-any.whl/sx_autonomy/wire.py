"""Canonical qualification and capability-approval documents."""

from collections.abc import Mapping
from typing import cast

from sx_contracts import (
    ArtifactId,
    ContentRef,
    Sha256Digest,
    SupervisionLayer,
    WorkloadName,
    decode,
    robot_application_from_dict,
    robot_application_to_dict,
    station_target_from_dict,
    station_target_to_dict,
)
from sx_worlds import world_evaluation_from_dict, world_evaluation_to_dict

from sx_autonomy.performance import (
    APPLICATION_QUALIFICATION_SCHEMA,
    ApplicationQualification,
    ApplicationQualificationError,
    LatencyDistribution,
    SafeDegradation,
    WorkloadObservation,
)
from sx_autonomy.release import (
    CAPABILITY_APPROVAL_SCHEMA,
    CapabilityApproval,
    CapabilityApprovalError,
)
from sx_autonomy.supervision import Placement, RungRequirement, SupervisionRequirements


class CapabilityApprovalWireError(ValueError):
    """An approval or qualification document is not its exact closed wire shape."""


def capability_approval_to_dict(approval: CapabilityApproval) -> dict[str, object]:
    return {
        "schema": CAPABILITY_APPROVAL_SCHEMA,
        "evaluation": world_evaluation_to_dict(approval.evaluation),
        "qualification": application_qualification_to_dict(approval.qualification),
        "supervision": supervision_requirements_to_dict(approval.supervision),
    }


def capability_approval_from_dict(value: object) -> CapabilityApproval:
    document = decode.exactly(
        value,
        {"schema", "evaluation", "qualification", "supervision"},
        where="capability approval",
        error=CapabilityApprovalWireError,
    )
    if document["schema"] != CAPABILITY_APPROVAL_SCHEMA:
        raise CapabilityApprovalWireError(
            f"unsupported capability-approval schema: {document['schema']!r}"
        )
    try:
        return CapabilityApproval(
            world_evaluation_from_dict(document["evaluation"]),
            application_qualification_from_dict(document["qualification"]),
            supervision_requirements_from_dict(document["supervision"]),
        )
    except (CapabilityApprovalError, ApplicationQualificationError):
        raise
    except ValueError as error:
        raise CapabilityApprovalWireError(f"malformed capability approval: {error}") from error


def application_qualification_to_dict(
    qualification: ApplicationQualification,
) -> dict[str, object]:
    return {
        "schema": APPLICATION_QUALIFICATION_SCHEMA,
        "application": robot_application_to_dict(qualification.application),
        "observed_target": station_target_to_dict(qualification.observed_target),
        "workloads": [
            {
                "workload": str(item.workload),
                "clean_starts": item.clean_starts,
                "maximum_startup_ms": item.maximum_startup_ms,
                "peak_cpu_millis": item.peak_cpu_millis,
                "peak_memory_mib": item.peak_memory_mib,
                "peak_pids": item.peak_pids,
                "healthy": item.healthy,
                "stable": item.stable,
            }
            for item in qualification.workloads
        ],
        "healthy_connections": [list(item) for item in qualification.healthy_connections],
        "sustained_duration_s": qualification.sustained_duration_s,
        "latency": {
            "p50_ms": qualification.latency.p50_ms,
            "p95_ms": qualification.latency.p95_ms,
            "p99_ms": qualification.latency.p99_ms,
            "deadline_ms": qualification.latency.deadline_ms,
        },
        "degradation": {
            "internet_loss_safe": qualification.degradation.internet_loss_safe,
            "stale_remote_decisions_rejected": (
                qualification.degradation.stale_remote_decisions_rejected
            ),
            "local_fallback": (
                None
                if qualification.degradation.local_fallback is None
                else str(qualification.degradation.local_fallback)
            ),
        },
        "robot_control_handshake": qualification.robot_control_handshake,
        "images_verified": qualification.images_verified,
        "artifacts_verified": qualification.artifacts_verified,
        "evidence": {
            "artifact_id": str(qualification.evidence.artifact_id),
            "sha256": str(qualification.evidence.sha256),
        },
    }


def application_qualification_from_dict(value: object) -> ApplicationQualification:
    document = decode.exactly(
        value,
        {
            "schema",
            "application",
            "observed_target",
            "workloads",
            "healthy_connections",
            "sustained_duration_s",
            "latency",
            "degradation",
            "robot_control_handshake",
            "images_verified",
            "artifacts_verified",
            "evidence",
        },
        where="application qualification",
        error=CapabilityApprovalWireError,
    )
    if document["schema"] != APPLICATION_QUALIFICATION_SCHEMA:
        raise CapabilityApprovalWireError(
            f"unsupported application-qualification schema: {document['schema']!r}"
        )
    latency = decode.exactly(
        document["latency"],
        {"p50_ms", "p95_ms", "p99_ms", "deadline_ms"},
        where="qualification latency",
        error=CapabilityApprovalWireError,
    )
    degradation = decode.exactly(
        document["degradation"],
        {"internet_loss_safe", "stale_remote_decisions_rejected", "local_fallback"},
        where="qualification degradation",
        error=CapabilityApprovalWireError,
    )
    evidence = decode.exactly(
        document["evidence"],
        {"artifact_id", "sha256"},
        where="qualification evidence",
        error=CapabilityApprovalWireError,
    )
    fallback = degradation["local_fallback"]
    if fallback is not None and not isinstance(fallback, str):
        raise CapabilityApprovalWireError(
            "qualification degradation local_fallback must be text or null"
        )
    return ApplicationQualification(
        robot_application_from_dict(document["application"]),
        station_target_from_dict(document["observed_target"]),
        tuple(_workload_observation(item) for item in decode.sequence(document, "workloads")),
        tuple(_connection(item) for item in decode.sequence(document, "healthy_connections")),
        decode.number(document, "sustained_duration_s"),
        LatencyDistribution(
            decode.number(latency, "p50_ms"),
            decode.number(latency, "p95_ms"),
            decode.number(latency, "p99_ms"),
            decode.number(latency, "deadline_ms"),
        ),
        SafeDegradation(
            decode.boolean(degradation, "internet_loss_safe"),
            decode.boolean(degradation, "stale_remote_decisions_rejected"),
            None if fallback is None else WorkloadName(fallback),
        ),
        decode.boolean(document, "robot_control_handshake"),
        decode.boolean(document, "images_verified"),
        decode.boolean(document, "artifacts_verified"),
        ContentRef(
            ArtifactId(_text(evidence, "artifact_id")),
            Sha256Digest(_text(evidence, "sha256")),
        ),
    )


def _workload_observation(value: object) -> WorkloadObservation:
    document = decode.exactly(
        value,
        {
            "workload",
            "clean_starts",
            "maximum_startup_ms",
            "peak_cpu_millis",
            "peak_memory_mib",
            "peak_pids",
            "healthy",
            "stable",
        },
        where="workload observation",
        error=CapabilityApprovalWireError,
    )
    return WorkloadObservation(
        WorkloadName(_text(document, "workload")),
        decode.integer(document, "clean_starts"),
        decode.number(document, "maximum_startup_ms"),
        decode.integer(document, "peak_cpu_millis"),
        decode.integer(document, "peak_memory_mib"),
        decode.integer(document, "peak_pids"),
        decode.boolean(document, "healthy"),
        decode.boolean(document, "stable"),
    )


def _connection(value: object) -> tuple[WorkloadName, str]:
    if not isinstance(value, (list, tuple)):
        raise CapabilityApprovalWireError(
            "healthy connection must be a [workload, connection] pair"
        )
    items = cast("list[object] | tuple[object, ...]", value)
    if len(items) != 2:
        raise CapabilityApprovalWireError(
            "healthy connection must be a [workload, connection] pair"
        )
    if not all(isinstance(item, str) and item.strip() for item in items):
        raise CapabilityApprovalWireError("healthy connection pair values must be text")
    return WorkloadName(cast(str, items[0])), cast(str, items[1])


def supervision_requirements_to_dict(plan: SupervisionRequirements) -> dict[str, object]:
    return {
        "rungs": [
            {
                "layer": rung.layer.value,
                "required": rung.required,
                "placement": rung.placement.value,
            }
            for rung in plan.rungs
        ],
        "availability_timeout_s": plan.availability_timeout_s,
        "escalation_deadline_s": plan.escalation_deadline_s,
    }


def supervision_requirements_from_dict(value: object) -> SupervisionRequirements:
    document = decode.exactly(
        value,
        {"rungs", "availability_timeout_s", "escalation_deadline_s"},
        where="supervision requirements",
        error=CapabilityApprovalWireError,
    )
    return SupervisionRequirements(
        tuple(_rung(item) for item in decode.sequence(document, "rungs")),
        decode.number(document, "availability_timeout_s"),
        decode.number(document, "escalation_deadline_s"),
    )


def _rung(value: object) -> RungRequirement:
    document = decode.exactly(
        value,
        {"layer", "required", "placement"},
        where="supervision rung",
        error=CapabilityApprovalWireError,
    )
    return RungRequirement(
        SupervisionLayer(decode.integer(document, "layer")),
        decode.boolean(document, "required"),
        Placement(_text(document, "placement")),
    )


def _text(document: Mapping[str, object], name: str) -> str:
    value = decode.text(document, name)
    if not value.strip():
        raise CapabilityApprovalWireError(f"{name} must not be empty")
    return value
