"""Grading the agent: what seating a decision-maker bought, and what it cost.

An application task gate scores the complete graph. When a task owner also needs to isolate
the contribution of one decision-making workload, paired agent-gain evidence records that
ordinary task metric without changing the shared application or approval shape.

:class:`AgentGain` is the missing half, measured the way every ablation in this stack is
measured (``tools/measure_split_gain.py``): one suite, one policy document, two arms behind
the ordinary Worlds gate, differing in exactly one thing — the seated ``DecisionSource``.
Scores are per stratum with Wilson intervals and never pooled, and the nominal stratum is the
**guard**: orchestration must not cost anything on the easy case, so a gain that cannot show
its nominal stratum is not constructible here.

Deliberately not application qualification. Qualification grades serving of the complete graph;
this optional measurement grades one experimental decision source and belongs in a task gate.

The scalar is not the whole signal. :class:`DecisionCredit` joins the runtime's
``sx.decision-spans/v1`` document to the episode's own outcome, so the answer is not "the
agent is worth +3 points" but *which subgoal was in force when the episode failed* — the
decision-level signal an agent would actually be optimised against, the same shape as the
VLA's training data one level up.
"""

import math
from collections import Counter
from dataclasses import dataclass

from sx_contracts import TerminationReason
from sx_contracts.decisions import DecisionId, DecisionSpan, DecisionState
from sx_worlds import (
    NOMINAL,
    InstructionReplanSource,
    StratumId,
    SuiteManifest,
    WorldCase,
    wilson_interval,
)


class AgentEvidenceError(ValueError):
    """Agent evidence is incomplete, unpaired, or contradicts its own measurement."""


@dataclass(frozen=True, slots=True)
class ArmScore:
    """One arm's outcome in one stratum: the two counts every rate and interval derives from.

    Rates and intervals are views, never stored beside the counts they come from — a record
    cannot claim a rate its trials contradict.
    """

    trials: int
    successes: int

    def __post_init__(self) -> None:
        if isinstance(self.trials, bool) or isinstance(self.successes, bool):
            raise AgentEvidenceError("arm counts must be integers")
        if self.trials < 1:
            raise AgentEvidenceError("an arm scores at least one trial in every stratum")
        if not 0 <= self.successes <= self.trials:
            raise AgentEvidenceError("arm successes must lie within [0, trials]")

    @property
    def rate(self) -> float:
        return self.successes / self.trials

    @property
    def wilson(self) -> tuple[float, float]:
        """The suite's uncertainty law, applied to this arm — the same interval the gate uses."""
        return wilson_interval(self.successes, self.trials)


def score_arm(cases: tuple[WorldCase, ...], stratum: StratumId) -> ArmScore:
    """One arm's score in one stratum, read off the cases the gate actually produced.

    The one derivation of an arm's counts, shared by every ablation in ``tools/`` so two
    measurements can never disagree about what "the nominal rate" means.
    """
    ran = tuple(case for case in cases if str(case.stratum) == str(stratum))
    if not ran:
        raise AgentEvidenceError(f"no episode ran in stratum {stratum!r}")
    return ArmScore(trials=len(ran), successes=sum(case.accepted for case in ran))


@dataclass(frozen=True, slots=True)
class StratumGain:
    """What the agent was worth in one stratum, as the two arms that produced it."""

    stratum: StratumId
    agent: ArmScore
    reference: ArmScore

    def __post_init__(self) -> None:
        if not str(self.stratum).strip():
            raise AgentEvidenceError("a stratum gain names its stratum")
        if self.agent.trials != self.reference.trials:
            raise AgentEvidenceError(
                "the arms must run the same number of trials in a stratum; "
                f"got {self.agent.trials} against {self.reference.trials}"
            )

    @property
    def gain(self) -> float:
        """``success(agent) - success(reference)`` — never pooled across strata."""
        return self.agent.rate - self.reference.rate


@dataclass(frozen=True, slots=True)
class CadenceCost:
    """What deciding cost, stated beside what it bought.

    An agent worth +3 points that spends 600 s per episode is not obviously better, so a
    release states both. Wall time is measured on both arms over the same suite, because the
    only honest unit of "what the agent cost" is what the same episodes cost without it.
    """

    episodes: int
    decisions: int
    agent_wall_ms: float
    reference_wall_ms: float

    def __post_init__(self) -> None:
        if isinstance(self.episodes, bool) or isinstance(self.decisions, bool):
            raise AgentEvidenceError("cadence counts must be integers")
        if self.episodes < 1:
            raise AgentEvidenceError("cadence cost is measured over at least one episode")
        if self.decisions < 0:
            raise AgentEvidenceError("an agent cannot take a negative number of decisions")
        for wall in (self.agent_wall_ms, self.reference_wall_ms):
            if not math.isfinite(wall) or wall <= 0.0:
                raise AgentEvidenceError("measured wall times must be positive and finite")

    @property
    def decisions_per_episode(self) -> float:
        return self.decisions / self.episodes

    @property
    def overhead_ms_per_episode(self) -> float:
        """What an episode cost extra for having an agent in it — the price of the gain."""
        return (self.agent_wall_ms - self.reference_wall_ms) / self.episodes


@dataclass(frozen=True, slots=True)
class NoAgentGain:
    """The measured case where a task gate has no agent-gain dimension.

    This value is useful to analysis code that wants an explicit closed alternative. It is
    not part of capability approval: task gates carry only the metrics that task requires.
    """


@dataclass(frozen=True, slots=True)
class AgentGain:
    """One optional task-gate measurement of orchestration benefit and cost.

    Applications and capability approvals do not have an agent-shaped field. A Worlds gate
    may publish this measurement when the exact task needs it, regardless of how the
    application implements planning or control.
    """

    suite: SuiteManifest
    reference: InstructionReplanSource
    """The seat the agent was measured against, as Worlds already stores it on the run.

    Only the lease is stated here. The arm's instruction is the World task's own, read off
    the task the suite names — a gain that restated the objective could be measured against
    a different task than the one it is scored on.
    """

    strata: tuple[StratumGain, ...]
    cost: CadenceCost

    def __post_init__(self) -> None:
        if not self.strata:
            raise AgentEvidenceError("a gain is measured in at least one stratum")
        names = [str(entry.stratum) for entry in self.strata]
        if len(set(names)) != len(names):
            raise AgentEvidenceError("a gain scores each stratum once")
        if str(NOMINAL) not in names:
            raise AgentEvidenceError(
                "the nominal stratum is the guard: a gain that never measured the easy case "
                "cannot show that orchestration cost nothing on it"
            )

    @property
    def nominal(self) -> StratumGain:
        """The guard stratum — the one orchestration must not cost anything on."""
        return next(entry for entry in self.strata if str(entry.stratum) == str(NOMINAL))

    @property
    def regressed(self) -> bool:
        """Whether seating the agent cost success on the easy case."""
        return self.nominal.gain < 0.0


# -- per-decision credit -----------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class DecisionCredit:
    """One decision's share of one episode's outcome.

    The join the scalar gain cannot make: the runtime's span says which decision was issued,
    when it moved, and how it ended; the environment owner's episode says whether the task
    was achieved. Together they say *which subgoal was in force when the episode failed*.
    """

    episode_id: str
    stratum: StratumId
    outcome: TerminationReason
    decision_id: DecisionId
    ordinal: int
    in_force_at_end: bool
    status: DecisionState
    reason: str
    motion_chunks: int
    hold_chunks: int
    preempted_chunks: int

    def __post_init__(self) -> None:
        if not self.episode_id.strip():
            raise AgentEvidenceError("a decision credit names the episode it ran in")
        if self.ordinal < 0:
            raise AgentEvidenceError("a decision's ordinal within its episode is non-negative")

    @property
    def blamed(self) -> bool:
        """Whether this decision held control when its episode ended in failure."""
        return self.in_force_at_end and self.outcome is not TerminationReason.SUCCESS


def credit_episode(case: WorldCase, spans: tuple[DecisionSpan, ...]) -> tuple[DecisionCredit, ...]:
    """Join one episode's spans to its outcome, in the order the decisions were issued.

    The last span is the decision in force when the episode ended: a span closes when its
    successor takes over or when its episode ends, so the final one held control at the
    verdict. An episode with no spans yields nothing — that is a lawful absence (an agent
    that never decided), not missing data.
    """
    return tuple(
        DecisionCredit(
            episode_id=case.summary.episode_id,
            stratum=case.stratum,
            outcome=case.summary.end.reason,
            decision_id=span.anchor.decision_id,
            ordinal=ordinal,
            in_force_at_end=ordinal == len(spans) - 1,
            status=span.status,
            reason=span.reason,
            motion_chunks=span.motion_chunks,
            hold_chunks=span.hold_chunks,
            preempted_chunks=span.preempted_chunks,
        )
        for ordinal, span in enumerate(spans)
    )


def blame_tally(credits: tuple[DecisionCredit, ...]) -> tuple[tuple[DecisionId, int], ...]:
    """Which decisions held control at failure, most-blamed first.

    The optimisation target: a subgoal that is in force at the end of many failed episodes is
    where the agent is wrong, and no scalar gain can point at it.
    """
    tally = Counter(credit.decision_id for credit in credits if credit.blamed)
    return tuple(sorted(tally.items(), key=lambda item: (-item[1], str(item[0]))))
