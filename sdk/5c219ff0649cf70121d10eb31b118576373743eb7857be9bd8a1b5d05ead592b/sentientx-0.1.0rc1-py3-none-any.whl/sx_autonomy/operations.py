"""Canonical Autonomy operation results and live progress values."""

from dataclasses import dataclass

from sx_contracts import (
    OperationContractError,
    decode,
)


@dataclass(frozen=True, slots=True)
class TrainingProgress:
    completed_steps: int
    total_steps: int
    latest_checkpoint: str | None = None

    def __post_init__(self) -> None:
        if not 0 <= self.completed_steps <= self.total_steps:
            raise OperationContractError(
                "training progress must stay within the admitted step count"
            )


def training_progress_from_dict(value: object) -> TrainingProgress:
    """Read one training progress ledger, or refuse it typed."""

    document = decode.exactly(
        value,
        {"completed_steps", "total_steps", "latest_checkpoint"},
        where="training progress",
        error=OperationContractError,
    )
    return TrainingProgress(
        completed_steps=decode.integer(document, "completed_steps"),
        total_steps=decode.integer(document, "total_steps"),
        latest_checkpoint=decode.optional_text(document, "latest_checkpoint"),
    )
