"""Complete, portable PI0 behavior-cloning recipes."""

import math
from collections.abc import Mapping
from dataclasses import dataclass, field, fields, replace
from enum import StrEnum
from typing import Literal, cast

from sx_contracts import ArtifactId, ContentRef, Sha256Digest, decode

RECIPE_SCHEMA_VERSION = 2


class BCRecipeError(ValueError):
    """A PI0 recipe omits or contradicts a scientifically relevant setting."""


type ModelPrecision = Literal["bfloat16", "float32"]


class RecipePreset(StrEnum):
    """Stable public names whose implementations are pinned in this package version."""

    PI0_BC_V2 = "pi0-bc"
    PI05_BC_V2 = "pi05-bc"


@dataclass(frozen=True, slots=True)
class FromScratch:
    """Explicitly initialize a trainable component rather than resolve governed weights."""


type InitialWeights = ContentRef | FromScratch


@dataclass(frozen=True, slots=True)
class WholeTaskPrompt:
    """Condition every training window on the complete task instruction."""


@dataclass(frozen=True, slots=True)
class StepPrompt:
    task_id: str

    def __post_init__(self) -> None:
        if not self.task_id.strip():
            raise BCRecipeError("step-conditioned training requires a governed task id")


type TaskPrompt = WholeTaskPrompt | StepPrompt


@dataclass(frozen=True, slots=True)
class BCRecipe:
    """Every result-changing fact of one PI0 flow-matching training program."""

    action_horizon: int
    paligemma_variant: str
    action_expert_variant: str
    dtype: ModelPrecision
    action_dim: int
    pi05: bool
    discrete_state_input: bool
    initial_weights: InitialWeights
    image_resolution: int
    freeze_vision_encoder: bool
    train_expert_only: bool
    gradient_checkpointing: bool
    tokenizer_name: str
    max_token_len: int
    lr: float
    beta1: float
    beta2: float
    eps: float
    weight_decay: float
    grad_clip_norm: float
    warmup_steps: int
    decay_steps: int
    decay_lr: float
    steps: int
    log_every: int
    checkpoint_every: int
    state_max_age_s: float
    camera_max_age_s: float
    precompute: bool = False
    precompute_batch_size: int = 64
    precompute_prefix_embeddings: bool = False
    history_frames: int = 1
    prompt: TaskPrompt = field(default_factory=WholeTaskPrompt)
    history_stride: int = 1
    context_metadata: bool = False
    metadata_drop_all: float = 0.15
    metadata_drop_component: float = 0.05
    speed_bin_size: int = 500
    subgoal_fraction: float = 0.0
    subgoal_end_fraction: float = 0.25
    subgoal_max_ahead: int = 0
    advantage_value_checkpoint: ContentRef | None = None
    advantage_positive_fraction: float = 0.3
    advantage_failure_cost: float = 0.0
    advantage_max_task_steps: int = 0
    schema_version: int = RECIPE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != RECIPE_SCHEMA_VERSION:
            raise BCRecipeError(f"unsupported PI0 BC recipe schema {self.schema_version!r}")
        positive_integers = {
            "action_horizon": self.action_horizon,
            "action_dim": self.action_dim,
            "image_resolution": self.image_resolution,
            "max_token_len": self.max_token_len,
            "steps": self.steps,
            "log_every": self.log_every,
            "precompute_batch_size": self.precompute_batch_size,
            "history_frames": self.history_frames,
            "history_stride": self.history_stride,
            "speed_bin_size": self.speed_bin_size,
        }
        if any(isinstance(value, bool) or value < 1 for value in positive_integers.values()):
            raise BCRecipeError("recipe counts and dimensions must be positive integers")
        if self.checkpoint_every < 0 or self.warmup_steps < 0:
            raise BCRecipeError("checkpoint and warmup steps must be non-negative")
        if self.decay_steps < self.warmup_steps:
            raise BCRecipeError("decay_steps must be at least warmup_steps")
        if any(
            not math.isfinite(value) or value <= 0.0
            for value in (self.lr, self.eps, self.grad_clip_norm, self.decay_lr)
        ):
            raise BCRecipeError("learning-rate, epsilon, and clipping values must be positive")
        if not math.isfinite(self.weight_decay) or self.weight_decay < 0.0:
            raise BCRecipeError("weight_decay must be finite and non-negative")
        probabilities = (
            ("beta1", self.beta1),
            ("beta2", self.beta2),
            ("metadata_drop_all", self.metadata_drop_all),
            ("metadata_drop_component", self.metadata_drop_component),
            ("subgoal_fraction", self.subgoal_fraction),
            ("subgoal_end_fraction", self.subgoal_end_fraction),
        )
        for name, value in probabilities:
            if not math.isfinite(value) or not 0.0 <= value <= 1.0:
                raise BCRecipeError(f"{name} must be within [0, 1]")
        if any(
            not math.isfinite(value) or value < 0.0
            for value in (self.state_max_age_s, self.camera_max_age_s)
        ):
            raise BCRecipeError("modality staleness limits must be finite and non-negative")
        if not self.paligemma_variant or not self.action_expert_variant or not self.tokenizer_name:
            raise BCRecipeError("model variants and tokenizer must be explicit")
        if self.precompute_prefix_embeddings and (
            not self.precompute or not self.train_expert_only
        ):
            raise BCRecipeError("prefix precomputation requires expert-only precomputation")
        if (self.context_metadata or self.subgoal_fraction > 0.0) and self.precompute:
            raise BCRecipeError("context conditioning cannot use a precomputed prompt cache")
        if self.subgoal_fraction > 0.0 and self.subgoal_max_ahead < 1:
            raise BCRecipeError("subgoal training requires subgoal_max_ahead")
        if self.subgoal_fraction > 0.0 and self.history_frames > 1:
            raise BCRecipeError("subgoal conditioning does not compose with video memory")
        if self.advantage_value_checkpoint is not None:
            if not self.context_metadata:
                raise BCRecipeError("advantage conditioning requires scalar context metadata")
            if self.history_frames > 1:
                raise BCRecipeError("advantage conditioning does not compose with video memory")
            if self.advantage_failure_cost <= 0.0:
                raise BCRecipeError("advantage_failure_cost must be positive")
            if self.advantage_max_task_steps < 1:
                raise BCRecipeError("advantage_max_task_steps must be positive")
            if not 0.0 < self.advantage_positive_fraction < 1.0:
                raise BCRecipeError("advantage_positive_fraction must be within (0, 1)")

    @property
    def name(self) -> str:
        return "pi0_bc"

    def to_dict(self) -> dict[str, object]:
        document = {item.name: _recipe_value(getattr(self, item.name)) for item in fields(self)}
        return document

    @classmethod
    def from_dict(cls, document: Mapping[str, object]) -> "BCRecipe":
        expected = {item.name for item in fields(cls)}
        if set(document) != expected:
            raise BCRecipeError(
                f"recipe keys differ: missing={sorted(expected - set(document))}, "
                f"extra={sorted(set(document) - expected)}"
            )
        values = dict(document)
        try:
            dtype = values["dtype"]
            if dtype not in {"bfloat16", "float32"}:
                raise BCRecipeError("unsupported model precision")
            values["dtype"] = cast("ModelPrecision", dtype)
            values["initial_weights"] = _initial_weights(values["initial_weights"])
            values["prompt"] = _prompt(values["prompt"])
            checkpoint = values["advantage_value_checkpoint"]
            values["advantage_value_checkpoint"] = (
                None if checkpoint is None else _content_ref(checkpoint)
            )
            return cls(**values)  # pyright: ignore[reportArgumentType]
        except (KeyError, TypeError, ValueError) as error:
            if isinstance(error, BCRecipeError):
                raise
            raise BCRecipeError("recipe fields are malformed") from error


def _recipe_value(value: object) -> object:
    if isinstance(value, ContentRef):
        return {
            "artifact_id": str(value.artifact_id),
            "sha256": str(value.sha256),
        }
    if isinstance(value, FromScratch):
        return {"kind": "from_scratch"}
    if isinstance(value, WholeTaskPrompt):
        return {"kind": "whole_task"}
    if isinstance(value, StepPrompt):
        return {"kind": "step", "task_id": value.task_id}
    return value


def _record(value: object, label: str) -> decode.Document:
    return decode.document(value, where=label, error=BCRecipeError)


def _content_ref(value: object) -> ContentRef:
    document = decode.exactly(
        value, {"artifact_id", "sha256"}, where="content reference", error=BCRecipeError
    )
    return ContentRef(
        ArtifactId(decode.text(document, "artifact_id")),
        Sha256Digest(decode.text(document, "sha256")),
    )


def _initial_weights(value: object) -> InitialWeights:
    document = _record(value, "initial weights")
    if document == {"kind": "from_scratch"}:
        return FromScratch()
    return _content_ref(value)


def _prompt(value: object) -> TaskPrompt:
    document = _record(value, "task prompt")
    if document == {"kind": "whole_task"}:
        return WholeTaskPrompt()
    if set(document) == {"kind", "task_id"} and document["kind"] == "step":
        task_id = document["task_id"]
        if isinstance(task_id, str):
            return StepPrompt(task_id)
    raise BCRecipeError("task prompt fields are malformed")


PI0_BC = BCRecipe(
    action_horizon=8,
    paligemma_variant="gemma_2b",
    action_expert_variant="gemma_300m",
    dtype="bfloat16",
    action_dim=32,
    pi05=False,
    discrete_state_input=False,
    initial_weights=FromScratch(),
    image_resolution=224,
    freeze_vision_encoder=True,
    train_expert_only=True,
    gradient_checkpointing=True,
    tokenizer_name="google/paligemma-3b-pt-224",
    max_token_len=256,
    lr=2.5e-5,
    beta1=0.9,
    beta2=0.95,
    eps=1e-8,
    weight_decay=0.01,
    grad_clip_norm=1.0,
    warmup_steps=1_000,
    decay_steps=30_000,
    decay_lr=2.5e-6,
    steps=30_000,
    log_every=10,
    checkpoint_every=5_000,
    state_max_age_s=0.1,
    camera_max_age_s=0.2,
    precompute_batch_size=16,
)

PI05_BC = replace(
    PI0_BC,
    action_horizon=10,
    pi05=True,
    freeze_vision_encoder=False,
    train_expert_only=False,
    lr=5e-5,
    warmup_steps=10_000,
    decay_steps=1_000_000,
    decay_lr=5e-5,
)


def recipe_for_preset(preset: RecipePreset) -> BCRecipe:
    """Resolve a public preset without accepting caller-supplied science fields."""

    return {
        RecipePreset.PI0_BC_V2: PI0_BC,
        RecipePreset.PI05_BC_V2: PI05_BC,
    }[preset]
