"""The scan-seed report: what the machine half of a scan-to-scene run produced.

A LiteReality scan runs as two operations. The seed half (ingest → reconstruct →
splat → seed) is deterministic GPU work; the publish half (author → publish) is
the agent spend that ends in a governed :class:`~sx_worlds.environment.EnvironmentBundle`.
This record is the seed half's typed result on the operation wire: enough for a
caller to decide whether the scene is worth the publish spend, nothing that
duplicates the governed evidence inside the run directory.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import cast

from sx_contracts import decode

SCAN_SEED_SCHEMA = "sx.scan-seed/v1"


class ScanSeedContractError(ValueError):
    """A scan-seed document is malformed or incomplete."""


@dataclass(frozen=True, slots=True)
class SplatReport:
    """Held-out quality of the trained gaussian splat, from the splat stage's metrics."""

    psnr: float
    gaussians: int
    iterations: int

    def __post_init__(self) -> None:
        if not math.isfinite(self.psnr):
            raise ScanSeedContractError("splat psnr must be finite")
        if self.gaussians < 1 or self.iterations < 1:
            raise ScanSeedContractError("splat gaussians and iterations must be positive")


@dataclass(frozen=True, slots=True)
class ScanSeed:
    """One seeded scene package, bound to the durable run the publish half resumes."""

    scan_id: str
    run_id: str
    objects: int
    stages: tuple[str, ...]
    splat: SplatReport

    def __post_init__(self) -> None:
        if not self.scan_id.strip() or not self.run_id.strip():
            raise ScanSeedContractError("scan seed needs its scan and run identities")
        if self.objects < 0:
            raise ScanSeedContractError("scan seed object count must be non-negative")
        if not self.stages or any(not stage.strip() for stage in self.stages):
            raise ScanSeedContractError("scan seed stages must be non-empty names")
        if len(set(self.stages)) != len(self.stages):
            raise ScanSeedContractError("scan seed stages must be unique")
        if "seed" not in self.stages:
            raise ScanSeedContractError("a scan seed report must include the seed stage")


def scan_seed_to_dict(seed: ScanSeed) -> dict[str, object]:
    """The exact canonical ``sx.scan-seed/v1`` wire document."""

    return {
        "schema": SCAN_SEED_SCHEMA,
        "scan_id": seed.scan_id,
        "run_id": seed.run_id,
        "objects": seed.objects,
        "stages": list(seed.stages),
        "splat": {
            "psnr": seed.splat.psnr,
            "gaussians": seed.splat.gaussians,
            "iterations": seed.splat.iterations,
        },
    }


def scan_seed_from_dict(value: object) -> ScanSeed:
    """Parse an exact scan-seed document, refusing unknown or missing fields."""

    try:
        document = _object(value, "scan seed")
        _exact(
            document,
            {"schema", "scan_id", "run_id", "objects", "stages", "splat"},
            "scan seed",
        )
        if document["schema"] != SCAN_SEED_SCHEMA:
            raise ScanSeedContractError(f"unsupported scan-seed schema {document['schema']!r}")
        splat = _object(document["splat"], "scan seed splat")
        _exact(splat, {"psnr", "gaussians", "iterations"}, "scan seed splat")
        return ScanSeed(
            scan_id=decode.text(document, "scan_id"),
            run_id=decode.text(document, "run_id"),
            objects=_count(document, "objects"),
            stages=decode.texts(document, "stages"),
            splat=SplatReport(
                psnr=decode.number(splat, "psnr"),
                gaussians=_count(splat, "gaussians"),
                iterations=_count(splat, "iterations"),
            ),
        )
    except ScanSeedContractError:
        raise
    except (KeyError, TypeError, ValueError) as error:
        raise ScanSeedContractError(f"malformed scan-seed document: {error}") from error


def _object(value: object, where: str) -> dict[str, object]:
    if not isinstance(value, dict):
        raise ScanSeedContractError(f"{where} must be an object with text keys")
    raw = cast("dict[object, object]", value)
    if any(not isinstance(key, str) for key in raw):
        raise ScanSeedContractError(f"{where} must be an object with text keys")
    return cast("dict[str, object]", value)


def _exact(document: dict[str, object], fields: set[str], where: str) -> None:
    actual = set(document)
    if actual != fields:
        raise ScanSeedContractError(
            f"{where} fields differ: missing={sorted(fields - actual)}, "
            f"unexpected={sorted(actual - fields)}"
        )


def _count(document: dict[str, object], key: str) -> int:
    value = document[key]
    if isinstance(value, bool) or not isinstance(value, int):
        raise ScanSeedContractError(f"scan seed {key} must be an integer")
    return value
