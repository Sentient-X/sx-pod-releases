"""One canonical measured WorldRun and its pure derived WorldEvaluation."""

from __future__ import annotations

import hashlib
import math
import re
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Literal, NewType, cast

from sx_contracts import (
    ArtifactId,
    CatalogSegmentRef,
    ContentRef,
    EpisodeEnd,
    MetricSet,
    RobotApplication,
    Runtime,
    Sha256Digest,
    StationTarget,
    SuiteEvaluationCriteria,
    TaskVerdict,
    catalog_segment_from_dict,
    catalog_segment_to_dict,
    decode,
    episode_end_from_dict,
    episode_end_to_dict,
    parse_runtime,
    robot_application_from_dict,
    robot_application_to_dict,
    runtime_wire,
    station_target_from_dict,
    station_target_to_dict,
)
from sx_contracts.decisions import ReplanInterval, parse_replan_interval
from sx_contracts.identity import CanonicalDocument, canonical_json, content_id

from sx_worlds.engine_config import (
    EngineConfig,
    GenesisEngineConfig,
    LiberoEngineConfig,
    MjxEngineConfig,
    RoboCasaEngineConfig,
    SimplerEnvEngineConfig,
    engine_config_from_dict,
    engine_config_to_dict,
)
from sx_worlds.world import World, WorldId, world_from_dict, world_to_dict

WORLD_RUN_SCHEMA = "sx.world-run/v3"
WORLD_EVALUATION_SCHEMA = "sx.world-evaluation/v3"
MAX_WORLD_RUN_CASES = 4096
MAX_WORLD_RUN_BYTES = 4 * 1024 * 1024

WorldRunId = NewType("WorldRunId", str)
BenchmarkId = NewType("BenchmarkId", str)
BenchmarkTaskId = NewType("BenchmarkTaskId", str)
StratumId = NewType("StratumId", str)
NOMINAL = StratumId("nominal")

_SHA256 = re.compile(r"[a-f0-9]{64}")


type EvidencePart = Literal["evidence", "generation"]
"""What an evidence rejection names: run/suite evidence itself, or the generation
ledger that quotes the same execution facts."""


class WorldEvidenceError(ValueError):
    """Evaluation evidence is incomplete, contradictory, oversized, or malformed.

    ``part`` is the typed name of what failed — the folded former GenerationError
    leaf lives here as a value, not as a class.
    """

    def __init__(self, message: str, part: EvidencePart = "evidence") -> None:
        super().__init__(message)
        self.part = part


class PolicyArtifactKind(StrEnum):
    CODE_POLICY = "code_policy"
    POLICY_GRAPH = "policy_graph"


@dataclass(frozen=True, slots=True)
class PolicyArtifactRef:
    """The lawful product of an authored artifact family and exact content."""

    kind: PolicyArtifactKind
    artifact: ContentRef


type EvaluationSubject = RobotApplication | PolicyArtifactRef


class BenchmarkKind(StrEnum):
    NATIVE_WORLD = "native_world"
    LOCKED_BENCHMARK = "locked_benchmark"
    REAL_PROTOCOL = "real_protocol"


@dataclass(frozen=True, slots=True)
class BenchmarkRef:
    benchmark_id: BenchmarkId
    kind: BenchmarkKind
    revision: str
    assets_sha256: Sha256Digest

    def __post_init__(self) -> None:
        if not str(self.benchmark_id).strip() or not self.revision.strip():
            raise WorldEvidenceError("benchmark identity fields must not be empty")


@dataclass(frozen=True, slots=True)
class AllTasks:
    """Run every task governed by the benchmark entry."""


@dataclass(frozen=True, slots=True)
class SelectedTasks:
    tasks: tuple[BenchmarkTaskId, ...]

    def __post_init__(self) -> None:
        names = tuple(str(item) for item in self.tasks)
        if not names or any(not name.strip() for name in names) or len(set(names)) != len(names):
            raise WorldEvidenceError("selected suite tasks must be non-empty and unique")


type TaskSelection = AllTasks | SelectedTasks


@dataclass(frozen=True, slots=True)
class Nominal:
    """Run only the World reset distribution's nominal stratum."""


@dataclass(frozen=True, slots=True)
class DeclaredStrata:
    strata: tuple[StratumId, ...]

    def __post_init__(self) -> None:
        names = tuple(str(item) for item in self.strata)
        if not names or any(not name.strip() for name in names) or len(set(names)) != len(names):
            raise WorldEvidenceError("declared suite strata must be non-empty and unique")


type StrataSelection = Nominal | DeclaredStrata


@dataclass(frozen=True, slots=True)
class SuiteEntry:
    benchmark: BenchmarkRef
    trials_per_task: int
    seed: int
    task_selection: TaskSelection = AllTasks()
    strata_selection: StrataSelection = Nominal()
    action_horizon: int = 1

    def __post_init__(self) -> None:
        if isinstance(self.trials_per_task, bool) or self.trials_per_task < 1:
            raise WorldEvidenceError("suite trials_per_task must be a positive integer")
        if isinstance(self.seed, bool) or self.seed < 0:
            raise WorldEvidenceError("suite seed must be a non-negative integer")
        if isinstance(self.action_horizon, bool) or self.action_horizon < 1:
            raise WorldEvidenceError("suite action_horizon must be a positive integer")

    @property
    def covered_strata(self) -> tuple[StratumId, ...]:
        if isinstance(self.strata_selection, Nominal):
            return (NOMINAL,)
        return self.strata_selection.strata

    def selects(self, task_id: str) -> bool:
        return isinstance(self.task_selection, AllTasks) or BenchmarkTaskId(task_id) in (
            self.task_selection.tasks
        )


@dataclass(frozen=True, slots=True)
class SuiteManifest:
    suite_id: str
    entries: tuple[SuiteEntry, ...]

    def __post_init__(self) -> None:
        if not self.suite_id.strip() or not self.entries:
            raise WorldEvidenceError("suite needs a non-empty id and at least one entry")
        if len(set(self.entries)) != len(self.entries):
            raise WorldEvidenceError("suite must not repeat an identical entry")


def suite_digest(manifest: SuiteManifest) -> str:
    # The document is an open projection; `canonical_json` re-validates the JSON
    # shape at runtime before any byte is hashed.
    document = cast("CanonicalDocument", _suite_document(manifest))
    return hashlib.sha256(canonical_json(document).encode()).hexdigest()


class DecisionPlacement(StrEnum):
    OWNER_PROCESS = "owner_process"
    LOCKED_WORKER = "locked_worker"


@dataclass(frozen=True, slots=True)
class ApplicationControlSource:
    """Exercise the application's declared robot-control boundary."""


@dataclass(frozen=True, slots=True)
class InstructionReplanSource:
    replan_horizon: int

    def __post_init__(self) -> None:
        if isinstance(self.replan_horizon, bool) or self.replan_horizon < 1:
            raise WorldEvidenceError("instruction replan horizon must be positive")


@dataclass(frozen=True, slots=True)
class TaskContractSource:
    replan_interval: ReplanInterval
    retry_budget: int
    placement: DecisionPlacement

    def __post_init__(self) -> None:
        if isinstance(self.retry_budget, bool) or self.retry_budget < 0:
            raise WorldEvidenceError("task-contract retry budget must be non-negative")


class ScriptedDecisionKind(StrEnum):
    PICK = "pick"
    PLACE = "place"
    TRANSFER = "transfer"
    VLA = "vla"


@dataclass(frozen=True, slots=True)
class ScriptedStep:
    kind: ScriptedDecisionKind
    object_name: str | None = None
    target_name: str | None = None
    instruction: str | None = None

    def __post_init__(self) -> None:
        values = (self.object_name, self.target_name, self.instruction)
        if any(value is not None and not value.strip() for value in values):
            raise WorldEvidenceError("scripted step text must be non-empty when present")
        if self.kind is ScriptedDecisionKind.PICK:
            valid = self.object_name is not None and self.target_name is self.instruction is None
        elif self.kind in {ScriptedDecisionKind.PLACE, ScriptedDecisionKind.TRANSFER}:
            valid = (
                self.object_name is not None
                and self.target_name is not None
                and self.instruction is None
            )
        else:
            valid = self.instruction is not None and self.object_name is self.target_name is None
        if not valid:
            raise WorldEvidenceError(f"scripted {self.kind.value} step has contradictory fields")


@dataclass(frozen=True, slots=True)
class ScriptedSource:
    steps: tuple[ScriptedStep, ...]
    replan_interval: ReplanInterval
    retry_budget: int

    def __post_init__(self) -> None:
        if not self.steps:
            raise WorldEvidenceError("scripted source needs at least one typed step")
        if isinstance(self.retry_budget, bool) or self.retry_budget < 0:
            raise WorldEvidenceError("scripted retry budget must be non-negative")


type DecisionSourceConfig = (
    ApplicationControlSource | InstructionReplanSource | TaskContractSource | ScriptedSource
)


@dataclass(frozen=True, slots=True)
class ExecutionVenue:
    """Observed placement facts; never part of World identity or caller selection."""

    worker: str
    operating_system: str
    architecture: str
    accelerator: str | None
    driver: str | None
    cuda: str | None
    memory_bytes: int | None
    station_target: StationTarget | None = None

    def __post_init__(self) -> None:
        for label, value in (
            ("worker", self.worker),
            ("operating system", self.operating_system),
            ("architecture", self.architecture),
        ):
            if not value.strip():
                raise WorldEvidenceError(f"venue {label} must not be empty")
        for label, value in (
            ("accelerator", self.accelerator),
            ("driver", self.driver),
            ("CUDA", self.cuda),
        ):
            if value is not None and not value.strip():
                raise WorldEvidenceError(f"venue {label} must be non-empty when present")
        if self.memory_bytes is not None and (
            isinstance(self.memory_bytes, bool) or self.memory_bytes <= 0
        ):
            raise WorldEvidenceError("venue memory must be positive when present")
        accelerator_facts = (self.driver, self.cuda, self.memory_bytes)
        if self.accelerator is None and any(value is not None for value in accelerator_facts):
            raise WorldEvidenceError("accelerator-specific venue facts need an accelerator")


class RunArtifactKind(StrEnum):
    RERUN_RECORDING = "rerun_recording"
    DECISION_SPANS = "decision_spans"
    LOG = "log"
    RENDER = "render"


@dataclass(frozen=True, slots=True)
class RunArtifact:
    kind: RunArtifactKind
    content: ContentRef
    media_type: str

    def __post_init__(self) -> None:
        if not self.media_type.strip():
            raise WorldEvidenceError("run artifact media_type must not be empty")


@dataclass(frozen=True, slots=True)
class EpisodeExecutionSummary:
    """Checked quotation of the Catalog-registered episode execution summary."""

    episode_id: str
    world_id: WorldId
    actions: int
    duration_s: float
    end: EpisodeEnd

    def __post_init__(self) -> None:
        if not self.episode_id.strip() or not str(self.world_id).strip():
            raise WorldEvidenceError("episode summary identities must not be empty")
        if isinstance(self.actions, bool) or self.actions < 0:
            raise WorldEvidenceError("episode summary actions must be non-negative")
        if (
            isinstance(self.duration_s, bool)
            or not math.isfinite(self.duration_s)
            or self.duration_s < 0.0
        ):
            raise WorldEvidenceError("episode summary duration must be finite and non-negative")


@dataclass(frozen=True, slots=True)
class WorldCase:
    index: int
    seed: int
    stratum: StratumId
    segment: CatalogSegmentRef
    summary: EpisodeExecutionSummary
    measurements: MetricSet = field(default_factory=MetricSet)

    def __post_init__(self) -> None:
        if isinstance(self.index, bool) or self.index < 0:
            raise WorldEvidenceError("World case index must be non-negative")
        if isinstance(self.seed, bool) or self.seed < 0:
            raise WorldEvidenceError("World case seed must be non-negative")
        if not str(self.stratum).strip():
            raise WorldEvidenceError("World case stratum must not be empty")

    @property
    def accepted(self) -> bool:
        return self.summary.end.verdict is TaskVerdict.SATISFIED


@dataclass(frozen=True, slots=True)
class WorldRun:
    """The sole independently stored measured evaluation record."""

    world: World
    suite: SuiteManifest
    entry_index: int
    subject: EvaluationSubject
    cases: tuple[WorldCase, ...]
    runtime: Runtime
    engine_config: EngineConfig
    venue: ExecutionVenue
    decision_source: DecisionSourceConfig
    artifacts: tuple[RunArtifact, ...]

    def __post_init__(self) -> None:
        if (
            isinstance(self.entry_index, bool)
            or self.entry_index < 0
            or self.entry_index >= len(self.suite.entries)
        ):
            raise WorldEvidenceError("WorldRun entry_index is outside its suite")
        entry = self.entry
        if not entry.selects(self.world.task_id):
            raise WorldEvidenceError("suite entry does not select the embedded World task")
        if entry.benchmark.kind is BenchmarkKind.REAL_PROTOCOL:
            raise WorldEvidenceError("physical protocol evidence is not a simulated WorldRun")
        _validate_conformer(entry, self.world, self.engine_config)
        _validate_decision_source(self.subject, self.decision_source)
        if not self.cases or len(self.cases) > MAX_WORLD_RUN_CASES:
            raise WorldEvidenceError(f"WorldRun cases must be within [1, {MAX_WORLD_RUN_CASES}]")
        indices = tuple(case.index for case in self.cases)
        if indices != tuple(range(len(self.cases))):
            raise WorldEvidenceError("WorldRun case indices must be contiguous and ordered")
        segments = tuple(case.segment for case in self.cases)
        episodes = tuple(case.summary.episode_id for case in self.cases)
        plans = tuple((case.seed, case.stratum) for case in self.cases)
        if len(set(segments)) != len(segments) or len(set(episodes)) != len(episodes):
            raise WorldEvidenceError("WorldRun cases must have unique segments and episode ids")
        if len(set(plans)) != len(plans):
            raise WorldEvidenceError("WorldRun cases repeat a seed/stratum plan")
        if any(case.summary.world_id != self.world.id for case in self.cases):
            raise WorldEvidenceError("WorldRun episode summary quotes another World")
        expected = {str(stratum): entry.trials_per_task for stratum in entry.covered_strata}
        actual = dict.fromkeys(expected, 0)
        for case in self.cases:
            name = str(case.stratum)
            if name not in actual:
                raise WorldEvidenceError(f"WorldRun case uses undeclared stratum {name!r}")
            actual[name] += 1
        if actual != expected:
            raise WorldEvidenceError(
                f"WorldRun suite coverage differs: expected={expected}, actual={actual}"
            )
        identities = tuple((artifact.kind, artifact.content) for artifact in self.artifacts)
        if len(set(identities)) != len(identities):
            raise WorldEvidenceError("WorldRun repeats an artifact identity")
        size = len(canonical_json(cast("CanonicalDocument", _world_run_document(self))).encode())
        if size > MAX_WORLD_RUN_BYTES:
            raise WorldEvidenceError(
                f"WorldRun canonical bytes exceed {MAX_WORLD_RUN_BYTES}: {size}"
            )

    @property
    def entry(self) -> SuiteEntry:
        return self.suite.entries[self.entry_index]

    @property
    def id(self) -> WorldRunId:
        # The document nests open `to_dict` projections; `canonical_json` re-validates
        # the JSON shape at runtime before any byte is hashed.
        return content_id(WorldRunId, cast("CanonicalDocument", _world_run_document(self)))

    @property
    def pairing_projection(self) -> str:
        document = _world_run_document(self)
        document.pop("decision_source")
        document.pop("runtime")
        document.pop("venue")
        # Results differ across arms; pairing proves the identical admitted case plan.
        document["cases"] = [
            {"index": case.index, "seed": case.seed, "stratum": str(case.stratum)}
            for case in self.cases
        ]
        document.pop("artifacts")
        return canonical_json(cast("CanonicalDocument", document))


def _validate_conformer(entry: SuiteEntry, world: World, config: EngineConfig) -> None:
    locked = isinstance(
        config,
        (LiberoEngineConfig, RoboCasaEngineConfig, SimplerEnvEngineConfig),
    )
    if locked != (entry.benchmark.kind is BenchmarkKind.LOCKED_BENCHMARK):
        raise WorldEvidenceError("locked benchmark configuration and suite kind disagree")
    layers = world.scene.layers
    if layers and not isinstance(config, GenesisEngineConfig):
        raise WorldEvidenceError("scene layers require the Genesis conformer")
    if isinstance(config, MjxEngineConfig) and layers:
        raise WorldEvidenceError("MJX does not conform to layered Scene execution")


def _validate_decision_source(subject: EvaluationSubject, source: DecisionSourceConfig) -> None:
    if isinstance(subject, RobotApplication) != isinstance(source, ApplicationControlSource):
        raise WorldEvidenceError(
            "an application run must use its robot-control boundary, and authored artifacts "
            "must use an authored decision source"
        )


@dataclass(frozen=True, slots=True)
class WorldEvaluation:
    """A pure judgment; every score, metric, interval, and verdict derives from one run."""

    run: WorldRun

    def __post_init__(self) -> None:
        criteria = self.run.world.task.task.evaluation
        if criteria is None:
            raise WorldEvidenceError("World task has no applicable evaluation criteria")
        entry = self.run.entry
        if criteria.trials != entry.trials_per_task:
            raise WorldEvidenceError("task criteria trial count disagrees with the suite entry")
        if isinstance(criteria, SuiteEvaluationCriteria):
            if criteria.suite.suite_id != self.run.suite.suite_id:
                raise WorldEvidenceError("task criteria names another registered suite")
            if criteria.suite.sha256 != suite_digest(self.run.suite):
                raise WorldEvidenceError(
                    "task criteria suite digest disagrees with the embedded suite"
                )
        elif entry.benchmark.kind is not BenchmarkKind.NATIVE_WORLD:
            raise WorldEvidenceError("native task criteria require a native World suite entry")

    @property
    def threshold(self) -> float:
        criteria = self.run.world.task.task.evaluation
        if criteria is None:  # pragma: no cover - established by construction
            raise WorldEvidenceError("World task has no evaluation criteria")
        return criteria.threshold

    @property
    def score(self) -> float:
        return min(score for _, score in self.stratum_scores)

    @property
    def passed(self) -> bool:
        return self.score >= self.threshold

    @property
    def stratum_scores(self) -> tuple[tuple[StratumId, float], ...]:
        return tuple(
            (
                stratum,
                _rate(tuple(case for case in self.run.cases if case.stratum == stratum)),
            )
            for stratum in self.run.entry.covered_strata
        )

    @property
    def uncertainty(self) -> tuple[float, float]:
        worst = min(self.stratum_scores, key=lambda item: item[1])[0]
        cases = tuple(case for case in self.run.cases if case.stratum == worst)
        return wilson_interval(sum(case.accepted for case in cases), len(cases))

    @property
    def metrics(self) -> MetricSet:
        low, high = self.uncertainty
        pairs: list[tuple[str, float]] = [
            ("episodes", float(len(self.run.cases))),
            ("pooled_success_rate", _rate(self.run.cases)),
            ("success_rate", self.score),
            ("wilson_high", high),
            ("wilson_low", low),
        ]
        pairs.extend((f"stratum.{stratum}", score) for stratum, score in self.stratum_scores)
        measurement_names = sorted(
            {str(metric.name) for case in self.run.cases for metric in case.measurements}
        )
        for name in measurement_names:
            values = tuple(
                metric.value
                for case in self.run.cases
                for metric in case.measurements
                if str(metric.name) == name
            )
            if len(values) != len(self.run.cases):
                raise WorldEvidenceError(
                    f"evaluation measurement {name!r} is missing from some cases"
                )
            pairs.append((f"measurement.{name}.mean", sum(values) / len(values)))
        return MetricSet.from_pairs(pairs)


def _rate(cases: tuple[WorldCase, ...]) -> float:
    if not cases:
        raise WorldEvidenceError("cannot score an empty World case collection")
    return sum(case.accepted for case in cases) / len(cases)


def wilson_interval(successes: int, trials: int, *, z: float = 1.96) -> tuple[float, float]:
    if trials < 1 or not 0 <= successes <= trials:
        raise WorldEvidenceError("Wilson inputs require 0 <= successes <= positive trials")
    if not math.isfinite(z) or z <= 0.0:
        raise WorldEvidenceError("Wilson z must be positive and finite")
    rate = successes / trials
    denominator = 1.0 + z * z / trials
    center = (rate + z * z / (2 * trials)) / denominator
    margin = (z / denominator) * math.sqrt(
        rate * (1.0 - rate) / trials + z * z / (4 * trials * trials)
    )
    return max(0.0, center - margin), min(1.0, center + margin)


def world_run_to_dict(run: WorldRun) -> dict[str, object]:
    return {"schema": WORLD_RUN_SCHEMA, "world_run_id": str(run.id), **_world_run_document(run)}


def world_run_from_dict(value: object) -> WorldRun:
    try:
        document = _object(value, "WorldRun")
        fields = {
            "schema",
            "world_run_id",
            "world",
            "suite",
            "entry_index",
            "subject",
            "cases",
            "runtime",
            "engine_config",
            "venue",
            "decision_source",
            "artifacts",
        }
        _exact(document, fields, "WorldRun")
        if document["schema"] != WORLD_RUN_SCHEMA:
            raise WorldEvidenceError(f"unsupported WorldRun schema {document['schema']!r}")
        run = WorldRun(
            world_from_dict(document["world"]),
            _parse_suite(document["suite"]),
            decode.integer(document, "entry_index"),
            _parse_subject(document["subject"]),
            tuple(_parse_case(item) for item in decode.sequence(document, "cases")),
            parse_runtime(document["runtime"]),
            engine_config_from_dict(document["engine_config"]),
            execution_venue_from_dict(document["venue"]),
            decision_source_from_dict(document["decision_source"]),
            tuple(_parse_artifact(item) for item in decode.sequence(document, "artifacts")),
        )
        if document["world_run_id"] != str(run.id):
            raise WorldEvidenceError("world_run_id disagrees with canonical WorldRun content")
        return run
    except WorldEvidenceError:
        raise
    except (KeyError, TypeError, ValueError) as error:
        raise WorldEvidenceError(f"malformed WorldRun document: {error}") from error


def world_evaluation_to_dict(value: WorldEvaluation) -> dict[str, object]:
    return {"schema": WORLD_EVALUATION_SCHEMA, "run": world_run_to_dict(value.run)}


def world_evaluation_from_dict(value: object) -> WorldEvaluation:
    document = _object(value, "WorldEvaluation")
    _exact(document, {"schema", "run"}, "WorldEvaluation")
    if document["schema"] != WORLD_EVALUATION_SCHEMA:
        raise WorldEvidenceError(f"unsupported WorldEvaluation schema {document['schema']!r}")
    return WorldEvaluation(world_run_from_dict(document["run"]))


def _world_run_document(run: WorldRun) -> dict[str, object]:
    return {
        "world": world_to_dict(run.world),
        "suite": _suite_document(run.suite),
        "entry_index": run.entry_index,
        "subject": _subject_document(run.subject),
        "cases": [_case_document(case) for case in run.cases],
        "runtime": runtime_wire(run.runtime),
        "engine_config": engine_config_to_dict(run.engine_config),
        "venue": execution_venue_to_dict(run.venue),
        "decision_source": decision_source_to_dict(run.decision_source),
        "artifacts": [_artifact_document(item) for item in run.artifacts],
    }


def suite_to_dict(value: SuiteManifest) -> dict[str, object]:
    """The suite's canonical document — the same one a WorldRun embeds."""
    return _suite_document(value)


def suite_from_dict(value: object) -> SuiteManifest:
    """Parse a suite document, failing closed on an unknown or missing field."""
    return _parse_suite(value)


def _suite_document(value: SuiteManifest) -> dict[str, object]:
    return {
        "suite_id": value.suite_id,
        "entries": [_entry_document(item) for item in value.entries],
    }


def _entry_document(value: SuiteEntry) -> dict[str, object]:
    tasks = (
        {"kind": "all"}
        if isinstance(value.task_selection, AllTasks)
        else {"kind": "selected", "tasks": [str(item) for item in value.task_selection.tasks]}
    )
    strata = (
        {"kind": "nominal"}
        if isinstance(value.strata_selection, Nominal)
        else {
            "kind": "declared",
            "strata": [str(item) for item in value.strata_selection.strata],
        }
    )
    return {
        "benchmark": {
            "benchmark_id": str(value.benchmark.benchmark_id),
            "kind": value.benchmark.kind.value,
            "revision": value.benchmark.revision,
            "assets_sha256": str(value.benchmark.assets_sha256),
        },
        "trials_per_task": value.trials_per_task,
        "seed": value.seed,
        "task_selection": tasks,
        "strata_selection": strata,
        "action_horizon": value.action_horizon,
    }


def _parse_suite(value: object) -> SuiteManifest:
    document = _object(value, "suite")
    _exact(document, {"suite_id", "entries"}, "suite")
    return SuiteManifest(
        decode.text(document, "suite_id"),
        tuple(_parse_entry(item) for item in decode.sequence(document, "entries")),
    )


def _parse_entry(value: object) -> SuiteEntry:
    document = _object(value, "suite entry")
    _exact(
        document,
        {
            "benchmark",
            "trials_per_task",
            "seed",
            "task_selection",
            "strata_selection",
            "action_horizon",
        },
        "suite entry",
    )
    benchmark = _object(document["benchmark"], "suite benchmark")
    _exact(
        benchmark,
        {"benchmark_id", "kind", "revision", "assets_sha256"},
        "suite benchmark",
    )
    return SuiteEntry(
        BenchmarkRef(
            BenchmarkId(decode.text(benchmark, "benchmark_id")),
            BenchmarkKind(decode.text(benchmark, "kind")),
            decode.text(benchmark, "revision"),
            Sha256Digest(decode.text(benchmark, "assets_sha256")),
        ),
        decode.integer(document, "trials_per_task"),
        decode.integer(document, "seed"),
        _parse_task_selection(document["task_selection"]),
        _parse_strata_selection(document["strata_selection"]),
        decode.integer(document, "action_horizon"),
    )


def _parse_task_selection(value: object) -> TaskSelection:
    document = _object(value, "task selection")
    if document == {"kind": "all"}:
        return AllTasks()
    _exact(document, {"kind", "tasks"}, "selected tasks")
    if document["kind"] != "selected":
        raise WorldEvidenceError(f"unknown task selection kind {document['kind']!r}")
    return SelectedTasks(tuple(BenchmarkTaskId(item) for item in decode.texts(document, "tasks")))


def _parse_strata_selection(value: object) -> StrataSelection:
    document = _object(value, "strata selection")
    if document == {"kind": "nominal"}:
        return Nominal()
    _exact(document, {"kind", "strata"}, "declared strata")
    if document["kind"] != "declared":
        raise WorldEvidenceError(f"unknown strata selection kind {document['kind']!r}")
    return DeclaredStrata(tuple(StratumId(item) for item in decode.texts(document, "strata")))


def _subject_document(value: EvaluationSubject) -> dict[str, object]:
    if isinstance(value, RobotApplication):
        return {"kind": "application", "application": robot_application_to_dict(value)}
    return {
        "kind": "authored",
        "artifact_kind": value.kind.value,
        "artifact": _content_document(value.artifact),
    }


def _parse_subject(value: object) -> EvaluationSubject:
    document = _object(value, "evaluation subject")
    kind = document.get("kind")
    if kind == "application":
        _exact(document, {"kind", "application"}, "application subject")
        return robot_application_from_dict(document["application"])
    if kind == "authored":
        _exact(document, {"kind", "artifact_kind", "artifact"}, "authored subject")
        return PolicyArtifactRef(
            PolicyArtifactKind(decode.text(document, "artifact_kind")),
            _parse_content(document["artifact"]),
        )
    raise WorldEvidenceError(f"unknown evaluation subject kind {kind!r}")


def _case_document(value: WorldCase) -> dict[str, object]:
    return {
        "index": value.index,
        "seed": value.seed,
        "stratum": str(value.stratum),
        "segment": catalog_segment_to_dict(value.segment),
        "summary": {
            "episode_id": value.summary.episode_id,
            "world_id": str(value.summary.world_id),
            "actions": value.summary.actions,
            "duration_s": value.summary.duration_s,
            "end": episode_end_to_dict(value.summary.end),
        },
        "measurements": value.measurements.to_dict(),
    }


def _parse_case(value: object) -> WorldCase:
    document = _object(value, "World case")
    _exact(
        document,
        {"index", "seed", "stratum", "segment", "summary", "measurements"},
        "World case",
    )
    summary = _object(document["summary"], "episode summary")
    _exact(
        summary,
        {"episode_id", "world_id", "actions", "duration_s", "end"},
        "episode summary",
    )
    measurements = _object(document["measurements"], "case measurements")
    return WorldCase(
        decode.integer(document, "index"),
        decode.integer(document, "seed"),
        StratumId(decode.text(document, "stratum")),
        catalog_segment_from_dict(document["segment"]),
        EpisodeExecutionSummary(
            decode.text(summary, "episode_id"),
            WorldId(decode.text(summary, "world_id")),
            decode.integer(summary, "actions"),
            decode.number(summary, "duration_s"),
            episode_end_from_dict(summary["end"]),
        ),
        MetricSet.from_pairs(
            (
                name,
                _scalar(raw, f"measurement {name}"),
            )
            for name, raw in measurements.items()
        ),
    )


def decision_source_to_dict(value: DecisionSourceConfig) -> dict[str, object]:
    if isinstance(value, ApplicationControlSource):
        return {"kind": "application_control"}
    if isinstance(value, InstructionReplanSource):
        return {"kind": "instruction_replan", "replan_horizon": value.replan_horizon}
    if isinstance(value, TaskContractSource):
        return {
            "kind": "task_contract",
            "replan_interval": value.replan_interval.to_wire(),
            "retry_budget": value.retry_budget,
            "placement": value.placement.value,
        }
    return {
        "kind": "scripted",
        "steps": [_script_step_document(step) for step in value.steps],
        "replan_interval": value.replan_interval.to_wire(),
        "retry_budget": value.retry_budget,
    }


def decision_source_from_dict(value: object) -> DecisionSourceConfig:
    document = _object(value, "decision source")
    kind = document.get("kind")
    if kind == "application_control":
        _exact(document, {"kind"}, "application-control source")
        return ApplicationControlSource()
    if kind == "instruction_replan":
        _exact(document, {"kind", "replan_horizon"}, "instruction-replan source")
        return InstructionReplanSource(decode.integer(document, "replan_horizon"))
    if kind == "task_contract":
        _exact(
            document,
            {"kind", "replan_interval", "retry_budget", "placement"},
            "task-contract source",
        )
        return TaskContractSource(
            parse_replan_interval(document["replan_interval"]),
            decode.integer(document, "retry_budget"),
            DecisionPlacement(decode.text(document, "placement")),
        )
    if kind == "scripted":
        _exact(
            document,
            {"kind", "steps", "replan_interval", "retry_budget"},
            "scripted source",
        )
        return ScriptedSource(
            tuple(_parse_script_step(item) for item in decode.sequence(document, "steps")),
            parse_replan_interval(document["replan_interval"]),
            decode.integer(document, "retry_budget"),
        )
    raise WorldEvidenceError(f"unknown decision source kind {kind!r}")


def _script_step_document(value: ScriptedStep) -> dict[str, object]:
    return {
        "kind": value.kind.value,
        "object_name": value.object_name,
        "target_name": value.target_name,
        "instruction": value.instruction,
    }


def _parse_script_step(value: object) -> ScriptedStep:
    document = _object(value, "scripted step")
    _exact(
        document,
        {"kind", "object_name", "target_name", "instruction"},
        "scripted step",
    )
    return ScriptedStep(
        ScriptedDecisionKind(decode.text(document, "kind")),
        decode.optional_text(document, "object_name"),
        decode.optional_text(document, "target_name"),
        decode.optional_text(document, "instruction"),
    )


def execution_venue_to_dict(value: ExecutionVenue) -> dict[str, object]:
    return {
        "worker": value.worker,
        "operating_system": value.operating_system,
        "architecture": value.architecture,
        "accelerator": value.accelerator,
        "driver": value.driver,
        "cuda": value.cuda,
        "memory_bytes": value.memory_bytes,
        "station_target": (
            None if value.station_target is None else station_target_to_dict(value.station_target)
        ),
    }


def execution_venue_from_dict(value: object) -> ExecutionVenue:
    document = _object(value, "execution venue")
    _exact(
        document,
        {
            "worker",
            "operating_system",
            "architecture",
            "accelerator",
            "driver",
            "cuda",
            "memory_bytes",
            "station_target",
        },
        "execution venue",
    )
    memory = document["memory_bytes"]
    target = document["station_target"]
    return ExecutionVenue(
        decode.text(document, "worker"),
        decode.text(document, "operating_system"),
        decode.text(document, "architecture"),
        decode.optional_text(document, "accelerator"),
        decode.optional_text(document, "driver"),
        decode.optional_text(document, "cuda"),
        None if memory is None else decode.integer(document, "memory_bytes"),
        None if target is None else station_target_from_dict(target),
    )


def _artifact_document(value: RunArtifact) -> dict[str, object]:
    return {
        "kind": value.kind.value,
        "content": _content_document(value.content),
        "media_type": value.media_type,
    }


def _parse_artifact(value: object) -> RunArtifact:
    document = _object(value, "run artifact")
    _exact(document, {"kind", "content", "media_type"}, "run artifact")
    return RunArtifact(
        RunArtifactKind(decode.text(document, "kind")),
        _parse_content(document["content"]),
        decode.text(document, "media_type"),
    )


def _content_document(value: ContentRef) -> dict[str, str]:
    return {"artifact_id": str(value.artifact_id), "sha256": str(value.sha256)}


def _parse_content(value: object) -> ContentRef:
    document = _object(value, "content reference")
    _exact(document, {"artifact_id", "sha256"}, "content reference")
    return ContentRef(
        ArtifactId(decode.text(document, "artifact_id")),
        Sha256Digest(decode.text(document, "sha256")),
    )


def _object(value: object, label: str) -> decode.Document:
    return decode.document(value, where=label, error=WorldEvidenceError)


def _exact(value: decode.Document, fields: set[str], label: str) -> None:
    if set(value) != fields:
        raise WorldEvidenceError(
            f"{label} fields differ: missing={sorted(fields - set(value))}, "
            f"unknown={sorted(set(value) - fields)}"
        )


def _scalar(value: object, label: str) -> float:
    """One number out of an array or a metric mapping — the kit reads fields, not values."""
    if isinstance(value, bool) or not isinstance(value, int | float) or not math.isfinite(value):
        raise WorldEvidenceError(f"{label} must be finite numeric data")
    return float(value)
