"""Canonical ledger of every attempted generated episode."""

from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass, field
from enum import StrEnum
from typing import NewType, cast

from sx_contracts import (
    CatalogSegmentRef,
    MetricSet,
    RobotApplication,
    Runtime,
    TaskVerdict,
    catalog_segment_from_dict,
    catalog_segment_to_dict,
    decode,
    episode_end_from_dict,
    episode_end_to_dict,
    parse_runtime,
    robot_application_from_dict,
    robot_application_to_dict,
    runtime_wire,
)
from sx_contracts.identity import CanonicalDocument, canonical_json, content_id

from sx_worlds.engine_config import (
    EngineConfig,
    Simulator,
    engine_config_from_dict,
    engine_config_to_dict,
    simulator_for_engine_config,
)
from sx_worlds.evaluation import (
    EpisodeExecutionSummary,
    ExecutionVenue,
    ScriptedSource,
    WorldEvidenceError,
    decision_source_from_dict,
    decision_source_to_dict,
    execution_venue_from_dict,
    execution_venue_to_dict,
)
from sx_worlds.world import WorldId

GENERATION_SCHEMA = "sx.generation/v4"
# v4 projects the exact engine configuration onto the canonical public simulator
# identity and verifies that redundant wire fact while parsing. v3 predates it.
GENERATION_SEED_LAW = "sx.generation-seed/v1"
MAX_GENERATION_ATTEMPTS = 100_000
MAX_GENERATION_BYTES = 16 * 1024 * 1024

GenerationId = NewType("GenerationId", str)


@dataclass(frozen=True, slots=True)
class ScriptedGenerationSource:
    script: ScriptedSource


@dataclass(frozen=True, slots=True)
class ApplicationGenerationSource:
    application: RobotApplication
    replan_horizon: int

    def __post_init__(self) -> None:
        if isinstance(self.replan_horizon, bool) or self.replan_horizon < 1:
            raise WorldEvidenceError(
                "application generation replan horizon must be positive", "generation"
            )


class SeedSelection(StrEnum):
    """How a diversification picks which pooled demo a subtask replays (MimicGen's strategies).

    A closed vocabulary because it is a wire value: the door parses it, the runner matches on
    it, and the executed generation records it. The strategies' tuning constants (position and
    rotation weights, the top-k width) are not on the wire — they are the ported defaults, and
    a knob nothing sets would be a surface with no consumer.
    """

    RANDOM = "random"
    """Uniform over the pool — the only strategy a subtask with no reference object supports."""
    NEAREST_NEIGHBOR_OBJECT = "nearest_neighbor_object"
    """The demo that saw this subtask's object closest to where the new scene puts it."""
    NEAREST_NEIGHBOR_ROBOT_DISTANCE = "nearest_neighbor_robot_distance"
    """The demo whose retargeted segment starts closest to where the arm already is."""


@dataclass(frozen=True, slots=True)
class MimicGenSource:
    """Replay a **pool** of registered seed episodes across randomized scenes.

    The pool is the mechanism, not a convenience: MimicGen selects a source segment per subtask,
    so one demo is the degenerate case of the surface rather than its shape. Every listed
    segment must be a registered episode of the same task.
    """

    seed_segments: tuple[CatalogSegmentRef, ...]
    position_jitter_m: float
    rotation_jitter_rad: float
    selection: SeedSelection = SeedSelection.RANDOM

    def __post_init__(self) -> None:
        for value, label in (
            (self.position_jitter_m, "MimicGen position jitter"),
            (self.rotation_jitter_rad, "MimicGen rotation jitter"),
        ):
            if isinstance(value, bool) or not math.isfinite(value) or value < 0.0:
                raise WorldEvidenceError(f"{label} must be finite and non-negative", "generation")
        if self.position_jitter_m == 0.0 and self.rotation_jitter_rad == 0.0:
            raise WorldEvidenceError(
                "MimicGen source must declare a non-zero transformation", "generation"
            )
        if not self.seed_segments:
            raise WorldEvidenceError(
                "MimicGen source must name at least one seed segment", "generation"
            )
        if len({(ref.dataset_id, ref.segment_id) for ref in self.seed_segments}) != len(
            self.seed_segments
        ):
            raise WorldEvidenceError(
                "MimicGen seed pool repeats a segment; a pool of duplicates is one demo",
                "generation",
            )


@dataclass(frozen=True, slots=True)
class AgenticSceneSource:
    """Propose task scenes through the pinned VLM designer + critic, then roll them.

    The designer and critic prompts are the task's registered content-addressed assets
    (each pinned to a model); this source is the *kind* discriminator that tells the door
    to run them. It carries no per-request knobs — scene diversity comes from the VLM,
    and how many scenes to propose is the request's ``count``.
    """


type GenerationSource = (
    ScriptedGenerationSource | ApplicationGenerationSource | MimicGenSource | AgenticSceneSource
)


def generation_source_to_dict(value: GenerationSource) -> dict[str, object]:
    return _source_document(value)


def generation_source_from_dict(value: object) -> GenerationSource:
    return _parse_source(value)


@dataclass(frozen=True, slots=True)
class GenerationAttempt:
    """One executed attempt; seed and disposition derive, while evidence is quoted exactly."""

    index: int
    segment: CatalogSegmentRef
    summary: EpisodeExecutionSummary
    measurements: MetricSet = field(default_factory=MetricSet)

    def __post_init__(self) -> None:
        if isinstance(self.index, bool) or self.index < 0:
            raise WorldEvidenceError("generation attempt index must be non-negative", "generation")

    @property
    def accepted(self) -> bool:
        return self.summary.end.verdict is TaskVerdict.SATISFIED


class GenerationRejectionReason(StrEnum):
    """Why one requested attempt produced no episode — the one wire taxonomy.

    A superset of the feasibility verdict's rejection causes
    (``escaped``/``unsettled``/``tilted``) plus the agentic proposer's own: a designer's
    unparseable output, a critic's refusal, and a proposal no projection could seat.
    ``settled`` is absent because it is an *acceptance*, not a rejection — acceptances
    register as attempts, never here.
    """

    ESCAPED = "escaped"
    """A proposed object left its support during settling."""
    UNSETTLED = "unsettled"
    """A proposed object was still moving when the settle budget ran out."""
    TILTED = "tilted"
    """A proposed object came to rest rotated away from the orientation it was placed at."""
    CRITIC_REJECTED = "critic_rejected"
    """The VLM critic refused the designer's proposal; ``detail`` carries its reason."""
    UNPROJECTABLE = "unprojectable"
    """The proposal could not be projected onto the task's resettable layout."""
    MALFORMED_PROPOSAL = "malformed_proposal"
    """The designer returned a document the proposer could not parse."""


@dataclass(frozen=True, slots=True)
class GenerationRejection:
    """One attempt that produced no episode: which ordinal, why, and the human reason.

    ``index`` is the attempt ordinal (the same input ``Generation.seed_for`` reads), so a
    rejection correlates with the seed it refused and the ledger's partition is exact.
    ``detail`` is free text a critic or a projection supplies; feasibility rejections
    leave it empty because the enum already says what happened.
    """

    index: int
    reason: GenerationRejectionReason
    detail: str = ""

    def __post_init__(self) -> None:
        if isinstance(self.index, bool) or self.index < 0:
            raise WorldEvidenceError(
                "generation rejection index must be non-negative", "generation"
            )


@dataclass(frozen=True, slots=True)
class Generation:
    """The durable terminal result for one fully published generation operation."""

    world_id: WorldId
    source: GenerationSource
    base_seed: int
    requested_count: int
    destination_dataset: str
    attempts: tuple[GenerationAttempt, ...]
    runtime: Runtime
    engine_config: EngineConfig
    venue: ExecutionVenue
    rejections: tuple[GenerationRejection, ...] = ()

    def __post_init__(self) -> None:
        if not str(self.world_id).strip() or not self.destination_dataset.strip():
            raise WorldEvidenceError(
                "generation World and destination must not be empty", "generation"
            )
        if isinstance(self.base_seed, bool) or self.base_seed < 0:
            raise WorldEvidenceError("generation base_seed must be non-negative", "generation")
        if (
            isinstance(self.requested_count, bool)
            or not 1 <= self.requested_count <= MAX_GENERATION_ATTEMPTS
        ):
            raise WorldEvidenceError(
                f"generation requested_count must be within [1, {MAX_GENERATION_ATTEMPTS}]",
                "generation",
            )
        # Every requested attempt is either a registered attempt or a typed rejection,
        # never a silent drop — so a caller reads the accept rate straight off the ledger
        # and a replay recovers the exact seed of anything that did not roll.
        attempt_indices = tuple(item.index for item in self.attempts)
        rejection_indices = tuple(item.index for item in self.rejections)
        if len(self.attempts) + len(self.rejections) != self.requested_count:
            raise WorldEvidenceError(
                "a generation must account for every requested attempt as a registered "
                "attempt or a rejection",
                "generation",
            )
        if len(set(attempt_indices)) != len(attempt_indices):
            raise WorldEvidenceError("generation attempt indices must be unique", "generation")
        if len(set(rejection_indices)) != len(rejection_indices):
            raise WorldEvidenceError("generation rejection indices must be unique", "generation")
        if set(attempt_indices) & set(rejection_indices):
            raise WorldEvidenceError(
                "generation attempt and rejection indices must not overlap", "generation"
            )
        if set(attempt_indices) | set(rejection_indices) != set(range(self.requested_count)):
            raise WorldEvidenceError(
                "a generation must account for every requested attempt as a registered "
                "attempt or a rejection",
                "generation",
            )
        segments = tuple(item.segment for item in self.attempts)
        episodes = tuple(item.summary.episode_id for item in self.attempts)
        if len(set(segments)) != len(segments) or len(set(episodes)) != len(episodes):
            raise WorldEvidenceError(
                "generation attempts need unique segments and episode ids", "generation"
            )
        if any(item.summary.world_id != self.world_id for item in self.attempts):
            raise WorldEvidenceError("generation attempt quotes another World", "generation")
        size = len(canonical_json(cast("CanonicalDocument", _generation_document(self))).encode())
        if size > MAX_GENERATION_BYTES:
            raise WorldEvidenceError(
                f"Generation canonical bytes exceed {MAX_GENERATION_BYTES}: {size}", "generation"
            )

    @property
    def simulator(self) -> Simulator:
        return simulator_for_engine_config(self.engine_config)

    @property
    def id(self) -> GenerationId:
        # The document nests open `to_dict` projections; `canonical_json` re-validates
        # the JSON shape at runtime before any byte is hashed.
        return content_id(GenerationId, cast("CanonicalDocument", _generation_document(self)))

    @property
    def accepted_attempts(self) -> tuple[GenerationAttempt, ...]:
        return tuple(item for item in self.attempts if item.accepted)

    @property
    def rejected_attempts(self) -> tuple[GenerationAttempt, ...]:
        return tuple(item for item in self.attempts if not item.accepted)

    @property
    def accepted_count(self) -> int:
        return len(self.accepted_attempts)

    @property
    def rejected_count(self) -> int:
        return len(self.rejected_attempts)

    def seed_for(self, index: int) -> int:
        if isinstance(index, bool) or not 0 <= index < self.requested_count:
            raise WorldEvidenceError("generation attempt index is outside the ledger", "generation")
        return generation_seed(self.base_seed, index)


def generation_seed(base_seed: int, index: int) -> int:
    """The versioned, cross-process seed law for attempt ``index``."""

    if isinstance(base_seed, bool) or isinstance(index, bool) or base_seed < 0 or index < 0:
        raise WorldEvidenceError(
            "generation seed inputs must be non-negative integers", "generation"
        )
    payload = f"{GENERATION_SEED_LAW}:{base_seed}:{index}".encode()
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")


def generation_to_dict(value: Generation) -> dict[str, object]:
    return {
        "schema": GENERATION_SCHEMA,
        "generation_id": str(value.id),
        **_generation_document(value),
    }


def generation_from_dict(value: object) -> Generation:
    try:
        document = _object(value, "Generation")
        _exact(
            document,
            {
                "schema",
                "generation_id",
                "world_id",
                "source",
                "base_seed",
                "requested_count",
                "destination_dataset",
                "attempts",
                "rejections",
                "runtime",
                "simulator",
                "engine_config",
                "venue",
            },
            "Generation",
        )
        if document["schema"] != GENERATION_SCHEMA:
            raise WorldEvidenceError(
                f"unsupported Generation schema {document['schema']!r}", "generation"
            )
        simulator = Simulator(decode.text(document, "simulator"))
        generation = Generation(
            WorldId(decode.text(document, "world_id")),
            _parse_source(document["source"]),
            decode.integer(document, "base_seed"),
            decode.integer(document, "requested_count"),
            decode.text(document, "destination_dataset"),
            tuple(_parse_attempt(item) for item in decode.sequence(document, "attempts")),
            parse_runtime(document["runtime"]),
            engine_config_from_dict(document["engine_config"]),
            execution_venue_from_dict(document["venue"]),
            tuple(_parse_rejection(item) for item in decode.sequence(document, "rejections")),
        )
        if generation.simulator is not simulator:
            raise WorldEvidenceError(
                "generation simulator disagrees with its exact engine config", "generation"
            )
        if document["generation_id"] != str(generation.id):
            raise WorldEvidenceError(
                "generation_id disagrees with canonical Generation content", "generation"
            )
        return generation
    except WorldEvidenceError as error:
        if error.part == "generation":
            raise
        # A sub-document (venue, scripted source) failed: wrap it with generation context,
        # exactly as the former GenerationError boundary did.
        raise WorldEvidenceError(f"malformed Generation document: {error}", "generation") from error
    except (KeyError, TypeError, ValueError) as error:
        raise WorldEvidenceError(f"malformed Generation document: {error}", "generation") from error


def _generation_document(value: Generation) -> dict[str, object]:
    return {
        "world_id": str(value.world_id),
        "source": _source_document(value.source),
        "base_seed": value.base_seed,
        "requested_count": value.requested_count,
        "destination_dataset": value.destination_dataset,
        "attempts": [_attempt_document(item) for item in value.attempts],
        "rejections": [_rejection_document(item) for item in value.rejections],
        "runtime": runtime_wire(value.runtime),
        "simulator": value.simulator.value,
        "engine_config": engine_config_to_dict(value.engine_config),
        "venue": execution_venue_to_dict(value.venue),
    }


def _source_document(value: GenerationSource) -> dict[str, object]:
    if isinstance(value, ScriptedGenerationSource):
        return {"kind": "scripted", "script": decision_source_to_dict(value.script)}
    if isinstance(value, ApplicationGenerationSource):
        return {
            "kind": "application",
            "application": robot_application_to_dict(value.application),
            "replan_horizon": value.replan_horizon,
        }
    if isinstance(value, MimicGenSource):
        return {
            "kind": "mimicgen",
            "seed_segments": [catalog_segment_to_dict(ref) for ref in value.seed_segments],
            "position_jitter_m": value.position_jitter_m,
            "rotation_jitter_rad": value.rotation_jitter_rad,
            "selection": value.selection.value,
        }
    return {"kind": "agentic"}


def _parse_source(value: object) -> GenerationSource:
    document = _object(value, "generation source")
    kind = document.get("kind")
    if kind == "scripted":
        _exact(document, {"kind", "script"}, "scripted generation source")
        source = decision_source_from_dict(document["script"])
        if not isinstance(source, ScriptedSource):
            raise WorldEvidenceError(
                "scripted generation source needs a ScriptedSource", "generation"
            )
        return ScriptedGenerationSource(source)
    if kind == "application":
        _exact(
            document,
            {"kind", "application", "replan_horizon"},
            "application generation source",
        )
        return ApplicationGenerationSource(
            robot_application_from_dict(document["application"]),
            decode.integer(document, "replan_horizon"),
        )
    if kind == "mimicgen":
        _exact(
            document,
            {"kind", "seed_segments", "position_jitter_m", "rotation_jitter_rad", "selection"},
            "MimicGen source",
        )
        segments = document["seed_segments"]
        if not isinstance(segments, list):
            raise WorldEvidenceError("MimicGen seed_segments must be a list", "generation")
        listed = cast(list[object], segments)
        return MimicGenSource(
            tuple(catalog_segment_from_dict(item) for item in listed),
            decode.number(document, "position_jitter_m"),
            decode.number(document, "rotation_jitter_rad"),
            _seed_selection(document["selection"]),
        )
    if kind == "agentic":
        _exact(document, {"kind"}, "agentic scene source")
        return AgenticSceneSource()
    raise WorldEvidenceError(f"unknown generation source kind {kind!r}", "generation")


def _attempt_document(value: GenerationAttempt) -> dict[str, object]:
    return {
        "index": value.index,
        "segment": catalog_segment_to_dict(value.segment),
        "summary": {
            "episode_id": value.summary.episode_id,
            "world_id": str(value.summary.world_id),
            "actions": value.summary.actions,
            "duration_s": value.summary.duration_s,
            "end": episode_end_to_dict(value.summary.end),
        },
        "measurements": value.measurements.to_dict(),
    }


def _parse_attempt(value: object) -> GenerationAttempt:
    document = _object(value, "generation attempt")
    _exact(
        document,
        {"index", "segment", "summary", "measurements"},
        "generation attempt",
    )
    summary = _object(document["summary"], "generation episode summary")
    _exact(
        summary,
        {"episode_id", "world_id", "actions", "duration_s", "end"},
        "generation episode summary",
    )
    measurements = _object(document["measurements"], "generation measurements")
    return GenerationAttempt(
        decode.integer(document, "index"),
        catalog_segment_from_dict(document["segment"]),
        EpisodeExecutionSummary(
            decode.text(summary, "episode_id"),
            WorldId(decode.text(summary, "world_id")),
            decode.integer(summary, "actions"),
            decode.number(summary, "duration_s"),
            episode_end_from_dict(summary["end"]),
        ),
        MetricSet.from_pairs(
            (name, _scalar(raw, f"generation measurement {name}"))
            for name, raw in measurements.items()
        ),
    )


def _rejection_document(value: GenerationRejection) -> dict[str, object]:
    return {"index": value.index, "reason": value.reason.value, "detail": value.detail}


def _parse_rejection(value: object) -> GenerationRejection:
    document = _object(value, "generation rejection")
    _exact(document, {"index", "reason", "detail"}, "generation rejection")
    reason = decode.text(document, "reason")
    try:
        parsed = GenerationRejectionReason(reason)
    except ValueError:
        raise WorldEvidenceError(
            f"unknown generation rejection reason {reason!r}", "generation"
        ) from None
    return GenerationRejection(
        decode.integer(document, "index"), parsed, decode.text(document, "detail")
    )


def _object(value: object, label: str) -> decode.Document:
    return decode.document(value, where=label, error=WorldEvidenceError)


def _seed_selection(value: object) -> SeedSelection:
    """Parse the seed-selection strategy, failing closed on an unknown name."""
    try:
        return SeedSelection(value)
    except ValueError as err:
        raise WorldEvidenceError(
            f"unknown MimicGen seed selection {value!r}; known: "
            f"{', '.join(item.value for item in SeedSelection)}",
            "generation",
        ) from err


def _exact(value: decode.Document, fields: set[str], label: str) -> None:
    if set(value) != fields:
        raise WorldEvidenceError(
            f"{label} fields differ: missing={sorted(fields - set(value))}, "
            f"unknown={sorted(set(value) - fields)}",
            "generation",
        )


def _scalar(value: object, label: str) -> float:
    """One number out of an array or a metric mapping — the kit reads fields, not values."""
    if isinstance(value, bool) or not isinstance(value, int | float) or not math.isfinite(value):
        raise WorldEvidenceError(f"{label} must be finite numeric data", "generation")
    return float(value)
