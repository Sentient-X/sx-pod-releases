"""Worlds-owned seed and generation provenance records.

Two unifications live here:

* **A seed is a demo trajectory with provenance — origin doesn't matter.** :class:`SeedTrajectory`
  is a time series of end-effector poses + gripper widths, exactly the embodiment-agnostic
  shape a UMI recording has and exactly what MimicGen's diversifier consumes. Whether it came
  from a real UMI capture or was synthesized in sim by a planner/RL expert is recorded in
  :class:`SeedOrigin`, not in a separate type or a separate pipeline.
* **Generated episodes stay distinguishable.** Every generated episode carries a
  :class:`GenerationProvenance` whose :attr:`~GenerationProvenance.action_source` is
  :attr:`ActionSource.SIM_AUGMENTED` — the shared wire label that keeps augmented data from
  ever being mixed indistinguishably with real captures.

Episodes are not re-exported here.  Producers use :mod:`sx_episodes`, runtime observations use
:mod:`sx_actions.gym`, and executed actions use :mod:`sx_actions` directly so every concept has
one name and one import path.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from enum import StrEnum

import numpy as np
from numpy.typing import NDArray
from sx_contracts import ActionSource, EpisodeId

from sx_worlds.engine_config import EngineConfigId

__all__ = [
    "GenerationProvenance",
    "SeedOrigin",
    "SeedTrajectory",
]


def _empty_str_map() -> dict[str, str]:
    """Typed default factory for the randomization descriptor (an empty string map)."""
    return {}


class SeedOrigin(StrEnum):
    """Where a seed trajectory came from — recorded, but invisible to the diversifier.

    The whole point of the platform's seed/seedless unification: MimicGen replays a
    :class:`SeedTrajectory` identically regardless of this value. It exists so generated data
    can be traced back to its true provenance (a real capture vs. a synthesized expert).
    """

    REAL_UMI = "real_umi"
    """A real Universal Manipulation Interface recording (retargeted onto a sim arm)."""
    SIM_PLANNER = "sim_planner"
    """Synthesized in sim by a motion planner solving the task's waypoints (M5)."""
    SIM_RL_EXPERT = "sim_rl_expert"
    """Distilled from rollouts of an RL expert trained in sim (M5)."""
    SIM_SCRIPTED = "sim_scripted"
    """A hand-written scripted routine executed in sim (bootstrap seeds, e.g. M1)."""
    SIM_TELEOP = "sim_teleop"
    """A human teleoperating a simulated robot — what an upstream robomimic/MimicGen source
    dataset actually contains (:mod:`sim_envs.io.robomimic`). Distinct from ``REAL_UMI``
    (a human, but a real robot) and from ``SIM_SCRIPTED`` (sim, but no human)."""


@dataclass(frozen=True, slots=True, eq=False)
class SeedTrajectory:
    """An embodiment-agnostic demonstration: SE(3) end-effector poses + gripper over time.

    This is the single intake shape for both platform doors (real UMI seeds and seedless
    synthesized seeds). Poses are in the world/scene frame; the diversifier re-expresses the
    relevant segments in object frames itself (see :mod:`sx_geometry`).

    Arrays are treated as read-only (``eq=False`` because element-wise ``==`` on arrays would
    break ``__eq__``). ``ee_quaternions`` are ``(w, x, y, z)``.
    """

    ee_positions: NDArray[np.float64]
    """``(T, 3)`` end-effector positions."""
    ee_quaternions: NDArray[np.float64]
    """``(T, 4)`` end-effector orientations, ``(w, x, y, z)``."""
    gripper_widths: NDArray[np.float64]
    """``(T,)`` gripper opening widths in meters."""
    timestamps: NDArray[np.float64]
    """``(T,)`` monotonically increasing timestamps in seconds."""
    origin: SeedOrigin
    """Where this seed came from (traceability only — not read by generation)."""
    seed_id: str
    """Stable identifier for this seed (e.g. the source UMI episode id, or a synth run id)."""

    def __post_init__(self) -> None:
        t = self.ee_positions.shape[0]
        shapes = {
            "ee_positions": (self.ee_positions.shape, (t, 3)),
            "ee_quaternions": (self.ee_quaternions.shape, (t, 4)),
            "gripper_widths": (self.gripper_widths.shape, (t,)),
            "timestamps": (self.timestamps.shape, (t,)),
        }
        for name, (got, want) in shapes.items():
            if got != want:
                raise ValueError(f"SeedTrajectory.{name}: expected {want}, got {got}")

    @property
    def num_steps(self) -> int:
        """Number of samples ``T`` in the trajectory."""
        return int(self.ee_positions.shape[0])


@dataclass(frozen=True, slots=True)
class GenerationProvenance:
    """Lineage stamped onto every generated episode — the distinguishability guarantee.

    Carried in the episode manifest and mirrored into the ``.rrd`` metadata entity. The coarse
    routing bit (:attr:`action_source`, always :attr:`ActionSource.SIM_AUGMENTED`) is what
    crosses the shared contract; the rest stays Worlds-local until a second consumer needs
    to *read* lineage (then it promotes into ``sx-episodes`` as an additive field).
    """

    generator: str
    """The generation mechanism, e.g. ``"mimicgen"``."""
    generator_version: str
    """Version/commit of the generator, so a dataset is reproducible."""
    engine_config_id: EngineConfigId
    """Content identity of the exact engine configuration that produced the rollout."""
    physics_seed: int
    """RNG seed driving randomization + physics for this episode."""
    seed_origin: SeedOrigin
    """Origin of the seed this episode was derived from."""
    seed_episode_id: EpisodeId | None = None
    """The seed's episode id, or ``None`` for a seedless (synthesized-seed) episode."""
    randomization: Mapping[str, str] = field(default_factory=_empty_str_map)
    """Free-form descriptor of the randomization applied (scene id, object set, DR ranges)."""
    action_source: ActionSource = ActionSource.SIM_AUGMENTED
    """The shared wire label. Fixed to SIM_AUGMENTED — this is generated data, by definition."""

    def __post_init__(self) -> None:
        if len(str(self.engine_config_id)) != 64:
            raise ValueError("GenerationProvenance.engine_config_id must be a sha256 digest")
        if self.action_source is not ActionSource.SIM_AUGMENTED:
            raise ValueError(
                "GenerationProvenance.action_source must be ActionSource.SIM_AUGMENTED "
                f"(generated data stays distinguishable); got {self.action_source!r}"
            )
