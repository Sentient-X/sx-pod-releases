"""Calibrated camera facts returned by rendering-capable conformers."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray

from sx_worlds.scene import SceneContractError


@dataclass(frozen=True, slots=True, eq=False)
class CameraParameters:
    """One engine camera expressed in the shared OpenCV pinhole convention."""

    name: str
    width: int
    height: int
    image_from_camera: NDArray[np.float64]
    parent_frame: str
    parent_from_camera: NDArray[np.float64]

    def __post_init__(self) -> None:
        if not self.name or self.width <= 0 or self.height <= 0:
            raise SceneContractError("camera name and positive resolution are mandatory", "camera")
        if self.image_from_camera.shape != (3, 3):
            raise SceneContractError("camera intrinsic matrix must be 3x3", "camera")
        if self.parent_from_camera.shape != (4, 4):
            raise SceneContractError("camera extrinsic matrix must be 4x4", "camera")
