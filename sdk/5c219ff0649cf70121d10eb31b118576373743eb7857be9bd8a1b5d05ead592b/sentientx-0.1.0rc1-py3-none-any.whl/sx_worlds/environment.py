"""Canonical captured or generated places before an embodiment is placed."""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import StrEnum
from typing import cast
from urllib.parse import urlparse

import numpy as np
from numpy.typing import NDArray
from sx_contracts import Sha256Digest, decode
from sx_contracts.assets import AssetFormat, AssetRole
from sx_contracts.identity import CanonicalDocument, content_id
from sx_contracts.wire import HexDigest

from sx_worlds.scene import AssetClosure, asset_closure_from_dict, asset_closure_to_dict

ENVIRONMENT_SCHEMA = "sx.environment/v1"


class EnvironmentContractError(ValueError):
    """A governed environment document is malformed or incomplete."""


class EnvironmentId(HexDigest):
    """Content identity of one environment document."""

    error = EnvironmentContractError
    noun = "environment id"


class EnvironmentSource(StrEnum):
    """The producer whose immutable output became the environment."""

    XGRIDS_SCAN = "xgrids_scan"
    MARBLE_GENERATION = "marble_generation"
    TRELLIS_RECONSTRUCTION = "trellis_reconstruction"
    SCENESMITH_GENERATION = "scenesmith_generation"
    MOLMOSPACES_GENERATION = "molmospaces_generation"
    LITEREALITY_GENERATION = "litereality_generation"


class UpAxis(StrEnum):
    """Vertical axis in the producer's coordinate system."""

    Y = "y"
    Z = "z"


@dataclass(frozen=True, slots=True)
class EnvironmentFacts:
    """Declarations that the environment's asset formats do not carry reliably."""

    source: EnvironmentSource
    source_ref: str
    placement: EnvironmentPlacement
    name: str
    description: str
    license_id: str
    tags: tuple[str, ...] = ()
    source_uri: str | None = None

    def __post_init__(self) -> None:
        if not self.source_ref.strip():
            raise EnvironmentContractError("environment source_ref must not be empty")
        if not isinstance(  # pyright: ignore[reportUnnecessaryIsInstance]
            self.placement, EnvironmentPlacement
        ):
            raise EnvironmentContractError("environment placement must be explicit")
        if not self.name.strip() or len(self.name) > 64:
            raise EnvironmentContractError("environment name must contain 1 to 64 characters")
        if not self.description.strip():
            raise EnvironmentContractError("environment description must not be empty")
        if not self.license_id.strip():
            raise EnvironmentContractError("environment license_id must not be empty")
        if self.source_uri is not None:
            parsed = urlparse(self.source_uri)
            if parsed.scheme not in {"http", "https"} or not parsed.netloc:
                raise EnvironmentContractError("environment source_uri must be an HTTP(S) URL")
        if any(not tag.strip() for tag in self.tags) or len(set(self.tags)) != len(self.tags):
            raise EnvironmentContractError("environment tags must be non-empty and unique")


@dataclass(frozen=True, slots=True)
class EnvironmentPlacement:
    """Producer coordinates to composed-world metres."""

    quaternion_wxyz: tuple[float, float, float, float]
    scale: float
    translation_xyz: tuple[float, float, float] = (0.0, 0.0, 0.0)

    def __post_init__(self) -> None:
        if len(self.quaternion_wxyz) != 4 or not all(
            math.isfinite(value) for value in self.quaternion_wxyz
        ):
            raise EnvironmentContractError("environment quaternion must have four finite values")
        norm = math.sqrt(sum(value * value for value in self.quaternion_wxyz))
        if not math.isclose(norm, 1.0, rel_tol=1e-6, abs_tol=1e-6):
            raise EnvironmentContractError("environment quaternion must be normalized")
        if not math.isfinite(self.scale) or self.scale <= 0:
            raise EnvironmentContractError("environment placement scale must be positive")
        if len(self.translation_xyz) != 3 or not all(
            math.isfinite(value) for value in self.translation_xyz
        ):
            raise EnvironmentContractError("environment translation must have three finite values")

    @property
    def rotates(self) -> bool:
        return self.quaternion_wxyz != (1.0, 0.0, 0.0, 0.0)

    @property
    def rotation(self) -> NDArray[np.float64]:
        w, x, y, z = self.quaternion_wxyz
        return np.array(
            [
                [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
                [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
                [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
            ],
            dtype=np.float64,
        )

    def place(self, positions: NDArray[np.float32] | NDArray[np.float64]) -> NDArray[np.float64]:
        translated = np.asarray(self.translation_xyz, dtype=np.float64)
        return (np.asarray(positions, dtype=np.float64) @ self.rotation.T) * self.scale + translated


@dataclass(frozen=True, slots=True)
class EnvironmentSettlement:
    """Content-bound report from compiling and stepping the canonical MJCF root.

    ``meshes`` may be zero: a scan-derived room shell settles as analytic box and
    plane geoms while its visual truth rides in the bundle's mandatory mesh and
    splat members, so a mesh-free MJCF root is an honest physics document, not a
    missing one.
    """

    mjcf_sha256: Sha256Digest
    geoms: int
    meshes: int
    steps: int
    engine: str = "mujoco"

    def __post_init__(self) -> None:
        try:
            object.__setattr__(self, "mjcf_sha256", Sha256Digest(str(self.mjcf_sha256)))
        except ValueError as error:
            raise EnvironmentContractError(
                "settlement MJCF digest must be lowercase sha256"
            ) from error
        if self.engine != "mujoco":
            raise EnvironmentContractError("environment settlement engine must be mujoco")
        if self.geoms < 1 or self.steps < 1:
            raise EnvironmentContractError("environment settlement counts must be positive")
        if self.meshes < 0:
            raise EnvironmentContractError("environment settlement mesh count must be non-negative")


def environment_placement(facts: EnvironmentFacts) -> EnvironmentPlacement:
    """Derive the one transform used by mesh, splat, and simulation shell."""
    return facts.placement


@dataclass(frozen=True, slots=True)
class EnvironmentBundle:
    """A governed place: settled MJCF plus visual, physical, source, and license bytes."""

    assets: AssetClosure
    facts: EnvironmentFacts
    settlement: EnvironmentSettlement

    def __post_init__(self) -> None:
        if (
            self.assets.root.format is not AssetFormat.MJCF
            or self.assets.root.role is not AssetRole.DESCRIPTION
        ):
            raise EnvironmentContractError("environment root must be its MJCF description")
        if self.settlement.mjcf_sha256 != self.assets.root.sha256:
            raise EnvironmentContractError("settlement digest must bind the canonical MJCF root")
        members = self.assets.members
        if not any(
            asset.format is AssetFormat.MESH and asset.role is AssetRole.GEOMETRY
            for asset in members
        ):
            raise EnvironmentContractError("environment needs a geometry mesh")
        if not any(asset.format is AssetFormat.SPLAT for asset in members):
            raise EnvironmentContractError("environment needs a gaussian-splat inspection asset")
        if not any(asset.role is AssetRole.LICENSE for asset in members):
            raise EnvironmentContractError("environment needs a license asset")
        if not any(
            asset.logical_path is not None
            and asset.logical_path.parts
            and asset.logical_path.parts[0] == "source"
            for asset in members
        ):
            raise EnvironmentContractError(
                "environment needs source evidence under the source/ asset path"
            )

    @property
    def id(self) -> EnvironmentId:
        return content_id(EnvironmentId, cast("CanonicalDocument", _environment_document(self)))


def environment_to_dict(environment: EnvironmentBundle) -> dict[str, object]:
    """The exact canonical ``sx.environment/v1`` wire document."""

    return {
        "schema": ENVIRONMENT_SCHEMA,
        "environment_id": str(environment.id),
        **_environment_document(environment),
    }


def environment_from_dict(value: object) -> EnvironmentBundle:
    """Parse an exact environment document and verify its quoted content identity."""

    try:
        document = _object(value, "environment")
        _exact(
            document,
            {"schema", "environment_id", "assets", "facts", "settlement"},
            "environment",
        )
        if document["schema"] != ENVIRONMENT_SCHEMA:
            raise EnvironmentContractError(f"unsupported environment schema {document['schema']!r}")
        facts = _object(document["facts"], "environment.facts")
        _exact(
            facts,
            {
                "source",
                "source_ref",
                "placement",
                "name",
                "description",
                "license_id",
                "tags",
                "source_uri",
            },
            "environment.facts",
        )
        placement = _object(facts["placement"], "environment.facts.placement")
        _exact(
            placement,
            {"quaternion_wxyz", "scale", "translation_xyz"},
            "environment.facts.placement",
        )
        settlement = _object(document["settlement"], "environment.settlement")
        _exact(
            settlement,
            {"engine", "mjcf_sha256", "geoms", "meshes", "steps"},
            "environment.settlement",
        )
        environment = EnvironmentBundle(
            assets=asset_closure_from_dict(document["assets"], where="environment.assets"),
            facts=EnvironmentFacts(
                source=EnvironmentSource(decode.text(facts, "source")),
                source_ref=decode.text(facts, "source_ref"),
                placement=EnvironmentPlacement(
                    quaternion_wxyz=cast(
                        "tuple[float, float, float, float]",
                        _fixed_numbers(placement, "quaternion_wxyz", 4),
                    ),
                    scale=decode.number(placement, "scale"),
                    translation_xyz=cast(
                        "tuple[float, float, float]",
                        _fixed_numbers(placement, "translation_xyz", 3),
                    ),
                ),
                name=decode.text(facts, "name"),
                description=decode.text(facts, "description"),
                license_id=decode.text(facts, "license_id"),
                tags=decode.texts(facts, "tags"),
                source_uri=_optional_text(facts, "source_uri"),
            ),
            settlement=EnvironmentSettlement(
                engine=decode.text(settlement, "engine"),
                mjcf_sha256=Sha256Digest(decode.text(settlement, "mjcf_sha256")),
                geoms=_positive_int(settlement, "geoms", "environment.settlement"),
                meshes=_count(settlement, "meshes", "environment.settlement"),
                steps=_positive_int(settlement, "steps", "environment.settlement"),
            ),
        )
        if document["environment_id"] != str(environment.id):
            raise EnvironmentContractError(
                "environment_id disagrees with the canonical environment document"
            )
        return environment
    except EnvironmentContractError:
        raise
    except (KeyError, TypeError, ValueError) as error:
        raise EnvironmentContractError(f"malformed environment document: {error}") from error


def _environment_document(environment: EnvironmentBundle) -> dict[str, object]:
    facts = environment.facts
    return {
        "assets": asset_closure_to_dict(environment.assets),
        "facts": {
            "source": facts.source.value,
            "source_ref": facts.source_ref,
            "placement": {
                "quaternion_wxyz": list(facts.placement.quaternion_wxyz),
                "scale": facts.placement.scale,
                "translation_xyz": list(facts.placement.translation_xyz),
            },
            "name": facts.name,
            "description": facts.description,
            "license_id": facts.license_id,
            "tags": list(facts.tags),
            "source_uri": facts.source_uri,
        },
        "settlement": {
            "engine": environment.settlement.engine,
            "mjcf_sha256": environment.settlement.mjcf_sha256,
            "geoms": environment.settlement.geoms,
            "meshes": environment.settlement.meshes,
            "steps": environment.settlement.steps,
        },
    }


def _object(value: object, where: str) -> dict[str, object]:
    if not isinstance(value, dict):
        raise EnvironmentContractError(f"{where} must be an object with text keys")
    raw = cast("dict[object, object]", value)
    if any(not isinstance(key, str) for key in raw):
        raise EnvironmentContractError(f"{where} must be an object with text keys")
    return cast("dict[str, object]", value)


def _exact(document: dict[str, object], fields: set[str], where: str) -> None:
    actual = set(document)
    if actual != fields:
        raise EnvironmentContractError(
            f"{where} fields differ: missing={sorted(fields - actual)}, "
            f"unexpected={sorted(actual - fields)}"
        )


def _optional_text(document: dict[str, object], key: str) -> str | None:
    value = document[key]
    if value is None:
        return None
    if not isinstance(value, str):
        raise EnvironmentContractError(f"environment.facts.{key} must be text or null")
    return value


def _fixed_numbers(document: dict[str, object], key: str, length: int) -> tuple[float, ...]:
    value = document[key]
    if not isinstance(value, list):
        raise EnvironmentContractError(
            f"environment.facts.placement.{key} must contain {length} numbers"
        )
    items = cast("list[object]", value)
    if len(items) != length:
        raise EnvironmentContractError(
            f"environment.facts.placement.{key} must contain {length} numbers"
        )
    numbers: list[float] = []
    for item in items:
        if isinstance(item, bool) or not isinstance(item, int | float):
            raise EnvironmentContractError(
                f"environment.facts.placement.{key} must contain numbers"
            )
        numbers.append(float(item))
    return tuple(numbers)


def _positive_int(document: dict[str, object], key: str, where: str) -> int:
    value = document[key]
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise EnvironmentContractError(f"{where}.{key} must be a positive integer")
    return value


def _count(document: dict[str, object], key: str, where: str) -> int:
    value = document[key]
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise EnvironmentContractError(f"{where}.{key} must be a non-negative integer")
    return value
