"""Canonical bounded interactive World session resource."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Literal

from sx_contracts import TaskContractRef
from sx_contracts.identity import FrozenJsonValue

from sx_worlds.engine_config import EngineConfigId, Simulator


class WorldSessionState(StrEnum):
    STARTING = "starting"
    READY = "ready"
    CLOSING = "closing"
    CLOSED = "closed"
    EXPIRED = "expired"
    SAFETY_STOPPED = "safety_stopped"
    FAILED = "failed"


@dataclass(frozen=True, slots=True)
class WorldSessionFailure:
    code: str
    message: str
    retryable: bool

    def __post_init__(self) -> None:
        if not self.code.strip() or not self.message.strip():
            raise ValueError("a session failure needs a code and message")


@dataclass(frozen=True, slots=True)
class WorldSessionClose:
    success: bool
    steps: int
    episode_segment: str | None
    reason: str | None

    def __post_init__(self) -> None:
        if self.steps < 0 or (self.episode_segment is None) == (self.reason is None):
            raise ValueError("a session close needs a valid receipt or an explicit absence reason")


@dataclass(frozen=True, slots=True)
class SessionJsonResult:
    """One immutable JSON-valued session tool result."""

    value: FrozenJsonValue
    kind: Literal["json"] = field(default="json", init=False)


@dataclass(frozen=True, slots=True)
class SessionImageResult:
    """One PNG observation with its original tensor shape and dtype."""

    dtype: str
    shape: tuple[int, ...]
    png: bytes
    kind: Literal["image"] = field(default="image", init=False)

    def __post_init__(self) -> None:
        if not self.dtype.strip() or not 2 <= len(self.shape) <= 8 or not self.png:
            raise ValueError("a session image needs a dtype, bounded shape, and PNG bytes")


type SessionStepResult = SessionJsonResult | SessionImageResult


@dataclass(frozen=True, slots=True)
class SessionStepReceipt:
    """The exact sequence-fenced receipt for one idempotent session tool call."""

    step_id: str
    previous_observation_sequence: int
    observation_sequence: int
    replayed: bool
    result: SessionStepResult

    def __post_init__(self) -> None:
        sequences = (self.previous_observation_sequence, self.observation_sequence)
        if not self.step_id.strip() or any(
            isinstance(value, bool) or value < 0 for value in sequences
        ):
            raise ValueError("a session step receipt needs an identity and non-negative fences")


@dataclass(frozen=True, slots=True)
class WorldSession:
    session_id: str
    task: TaskContractRef
    simulator: Simulator
    engine_config_id: EngineConfigId
    allocation_ref: str
    operation_ref: str
    state: WorldSessionState
    expires_at: datetime
    observation_sequence: int
    tools: tuple[str, ...]
    evidence_refs: tuple[str, ...] = ()
    usage_ref: str | None = None
    close: WorldSessionClose | None = None
    failure: WorldSessionFailure | None = None

    def __post_init__(self) -> None:
        identities = (
            self.session_id,
            str(self.engine_config_id),
            self.allocation_ref,
            self.operation_ref,
            *self.evidence_refs,
        )
        if any(not value.strip() for value in identities) or self.expires_at.tzinfo is None:
            raise ValueError("a World session needs complete identity and a timezone-aware expiry")
        if isinstance(self.observation_sequence, bool) or self.observation_sequence < 0:
            raise ValueError("a World session observation sequence must be non-negative")
        closed = self.state in {
            WorldSessionState.CLOSED,
            WorldSessionState.EXPIRED,
            WorldSessionState.SAFETY_STOPPED,
        }
        if closed != (self.close is not None):
            raise ValueError("only a closed World session carries a close receipt")
        if (self.state is WorldSessionState.FAILED) != (self.failure is not None):
            raise ValueError("only a failed World session carries a failure")
