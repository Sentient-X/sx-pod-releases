"""Public result contract for governed Worlds robot-part authoring.

The coding harness and local files do not belong here.  This value is the exact,
content-addressed review material returned by the Worlds operation and later submitted
unchanged to Experience part admission.
"""

from __future__ import annotations

import hashlib
from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from pathlib import PurePosixPath
from types import MappingProxyType
from typing import cast

from sx_contracts import ContentBlob, Sha256Digest
from sx_contracts.assets import (
    AssetFormat,
    AssetProvenance,
    AssetRef,
    AssetRole,
    ProvenancedAsset,
)
from sx_contracts.identity import CanonicalDocument, content_digest
from sx_embodiments import admit_part, part_from_dict, part_to_dict

TEXT_TO_CAD_REVISION = "02ecd59dd1deecc10695b957218487d35cb8c903"
ROBOT_PART_PROFILE = "worlds.robot-part/v1"
ROBOT_PART_SCHEMA = "sx.robot-part-candidate/v1"


class RobotPartContractError(ValueError):
    """A robot-part authoring result is incomplete or internally inconsistent."""


class CheckState(StrEnum):
    PASSED = "passed"
    UNAVAILABLE = "unavailable"


class RobotPartSourceKind(StrEnum):
    """Which byte is the editable CAD authority for this exact candidate."""

    GENERATED_PYTHON = "generated_python"
    IMPORTED_STEP = "imported_step"


@dataclass(frozen=True, slots=True)
class RobotPartCheck:
    name: str
    state: CheckState
    detail: str

    def __post_init__(self) -> None:
        if not self.name.strip() or not self.detail.strip():
            raise RobotPartContractError("robot-part checks need a name and detail")


@dataclass(frozen=True, slots=True)
class RobotPartValidation:
    checks: tuple[RobotPartCheck, ...]

    def __post_init__(self) -> None:
        names = tuple(check.name for check in self.checks)
        if not names or len(set(names)) != len(names):
            raise RobotPartContractError("robot-part checks must be non-empty and uniquely named")
        required = {"source", "step", "geometry", "urdf", "visual"}
        passed = {check.name for check in self.checks if check.state is CheckState.PASSED}
        missing = sorted(required - passed)
        if missing:
            raise RobotPartContractError(
                f"robot-part validation did not pass required checks: {', '.join(missing)}"
            )


@dataclass(frozen=True, slots=True)
class RobotPartSource:
    kind: RobotPartSourceKind
    path: PurePosixPath
    sha256: Sha256Digest
    provenance: AssetProvenance

    def __post_init__(self) -> None:
        expected = ".step.py" if self.kind is RobotPartSourceKind.GENERATED_PYTHON else ".step"
        if not str(self.path).endswith(expected):
            raise RobotPartContractError(f"{self.kind.value} CAD source must end in {expected!r}")


@dataclass(frozen=True, slots=True)
class RobotPartAssets:
    root: ProvenancedAsset
    members: tuple[ProvenancedAsset, ...]

    def __post_init__(self) -> None:
        if self.root.format is not AssetFormat.URDF or self.root.role is not AssetRole.DESCRIPTION:
            raise RobotPartContractError("robot-part root must be its URDF description")
        assets = (self.root, *self.members)
        if any(asset.logical_path is None for asset in assets):
            raise RobotPartContractError("every robot-part asset needs a logical path")
        if any(asset.uri != f"catalog://assets/{asset.sha256}" for asset in assets):
            raise RobotPartContractError(
                "every robot-part asset location must be derived from its content hash"
            )
        paths = tuple(cast(PurePosixPath, asset.logical_path) for asset in assets)
        if len(paths) != len(set(paths)):
            raise RobotPartContractError("robot-part asset paths must be unique")
        if tuple(sorted(paths[1:], key=str)) != paths[1:]:
            raise RobotPartContractError("robot-part asset members must be path ordered")

    @property
    def all(self) -> tuple[ProvenancedAsset, ...]:
        return (self.root, *self.members)


@dataclass(frozen=True, slots=True)
class RobotPartCandidate:
    """The exact governed bytes Experience may submit to ``part.admit``."""

    part: Mapping[str, object]
    urdf_xml: str
    assets: RobotPartAssets
    validation: RobotPartValidation
    source: RobotPartSource
    pack: str
    geometry_brief_sha256: Sha256Digest
    model: str
    skill_revision: str = TEXT_TO_CAD_REVISION
    profile: str = ROBOT_PART_PROFILE

    def __post_init__(self) -> None:
        if not self.urdf_xml.strip() or not self.pack.strip() or not self.model.strip():
            raise RobotPartContractError("robot-part candidate text fields must not be blank")
        canonical = part_to_dict(part_from_dict(self.part))
        object.__setattr__(self, "part", MappingProxyType(canonical))
        source_asset = next(
            (asset for asset in self.assets.all if asset.logical_path == self.source.path), None
        )
        if (
            source_asset is None
            or source_asset.sha256 != self.source.sha256
            or source_asset.provenance != self.source.provenance
        ):
            raise RobotPartContractError("candidate CAD source is not its governed exact byte")
        if self.assets.root.sha256 != hashlib.sha256(self.urdf_xml.encode()).hexdigest():
            raise RobotPartContractError("candidate URDF text disagrees with its root asset")
        mesh_paths = frozenset(
            str(asset.logical_path)
            for asset in self.assets.all
            if asset.format is AssetFormat.MESH and asset.logical_path is not None
        )
        admit_part(canonical, urdf=self.urdf_xml.encode(), mesh_paths=mesh_paths)

    @property
    def id(self) -> Sha256Digest:
        return content_digest(cast("CanonicalDocument", _candidate_document(self)))


def robot_part_candidate_to_dict(candidate: RobotPartCandidate) -> dict[str, object]:
    return {
        "schema": ROBOT_PART_SCHEMA,
        "candidate_id": str(candidate.id),
        **_candidate_document(candidate),
    }


def robot_part_candidate_from_dict(value: object) -> RobotPartCandidate:
    document = _object(value, "robot-part candidate")
    expected = {
        "schema",
        "candidate_id",
        "part",
        "urdf_xml",
        "assets",
        "validation",
        "source",
        "pack",
        "geometry_brief_sha256",
        "model",
        "skill_revision",
        "profile",
    }
    if set(document) != expected or document["schema"] != ROBOT_PART_SCHEMA:
        raise RobotPartContractError("robot-part candidate has an unsupported shape")
    part = _object(document["part"], "robot-part candidate part")
    candidate = RobotPartCandidate(
        part=part,
        urdf_xml=_text(document, "urdf_xml"),
        assets=_assets_from_dict(document["assets"]),
        validation=_validation_from_dict(document["validation"]),
        source=_source_from_dict(document["source"]),
        pack=_text(document, "pack"),
        geometry_brief_sha256=Sha256Digest(_text(document, "geometry_brief_sha256")),
        model=_text(document, "model"),
        skill_revision=_text(document, "skill_revision"),
        profile=_text(document, "profile"),
    )
    if _text(document, "candidate_id") != candidate.id:
        raise RobotPartContractError("robot-part candidate identity does not match its content")
    return candidate


def _candidate_document(candidate: RobotPartCandidate) -> dict[str, object]:
    return {
        "part": dict(candidate.part),
        "urdf_xml": candidate.urdf_xml,
        "assets": _assets_to_dict(candidate.assets),
        "validation": _validation_to_dict(candidate.validation),
        "source": _source_to_dict(candidate.source),
        "pack": candidate.pack,
        "geometry_brief_sha256": str(candidate.geometry_brief_sha256),
        "model": candidate.model,
        "skill_revision": candidate.skill_revision,
        "profile": candidate.profile,
    }


def _asset_to_dict(asset: AssetRef) -> dict[str, object]:
    return {
        "location": asset.location,
        "sha256": asset.sha256,
        "byte_size": asset.byte_size,
        "format": asset.format.value,
        "role": asset.role.value,
        "media_type": asset.media_type,
        "logical_path": str(asset.logical_path) if asset.logical_path is not None else None,
    }


def _asset_from_dict(value: object) -> AssetRef:
    row = _object(value, "robot-part asset")
    expected = {
        "location",
        "sha256",
        "byte_size",
        "format",
        "role",
        "media_type",
        "logical_path",
    }
    if set(row) != expected:
        raise RobotPartContractError("robot-part asset has an unsupported shape")
    media_type = row["media_type"]
    if media_type is not None and not isinstance(media_type, str):
        raise RobotPartContractError("robot-part asset media_type must be text or null")
    return AssetRef(
        location=_text(row, "location"),
        content=ContentBlob(Sha256Digest(_text(row, "sha256")), _integer(row, "byte_size")),
        format=AssetFormat(_text(row, "format")),
        role=AssetRole(_text(row, "role")),
        media_type=media_type,
        logical_path=PurePosixPath(_text(row, "logical_path")),
    )


def _assets_to_dict(assets: RobotPartAssets) -> dict[str, object]:
    return {
        "root": _provenanced_asset_to_dict(assets.root),
        "members": [_provenanced_asset_to_dict(asset) for asset in assets.members],
    }


def _assets_from_dict(value: object) -> RobotPartAssets:
    row = _object(value, "robot-part assets")
    if set(row) != {"root", "members"}:
        raise RobotPartContractError("robot-part assets have an unsupported shape")
    members = row["members"]
    if not isinstance(members, list):
        raise RobotPartContractError("robot-part asset members must be an array")
    return RobotPartAssets(
        _provenanced_asset_from_dict(row["root"]),
        tuple(_provenanced_asset_from_dict(item) for item in cast("list[object]", members)),
    )


def _provenanced_asset_to_dict(value: ProvenancedAsset) -> dict[str, object]:
    provenance = value.provenance
    return {
        "asset": _asset_to_dict(value.asset),
        "provenance": {
            "repository": provenance.repository,
            "revision": provenance.revision,
            "path": provenance.path,
            "license_id": provenance.license_id,
            "generator": provenance.generator,
        },
    }


def _provenanced_asset_from_dict(value: object) -> ProvenancedAsset:
    row = _object(value, "provenanced robot-part asset")
    if set(row) != {"asset", "provenance"}:
        raise RobotPartContractError("provenanced robot-part asset has an unsupported shape")
    origin = _object(row["provenance"], "robot-part asset provenance")
    if set(origin) != {"repository", "revision", "path", "license_id", "generator"}:
        raise RobotPartContractError("robot-part asset provenance has an unsupported shape")
    generator = origin["generator"]
    if generator is not None and not isinstance(generator, str):
        raise RobotPartContractError("robot-part asset provenance generator must be text or null")
    return ProvenancedAsset(
        _asset_from_dict(row["asset"]),
        AssetProvenance(
            repository=_text(origin, "repository"),
            revision=_text(origin, "revision"),
            path=_text(origin, "path"),
            license_id=_text(origin, "license_id"),
            generator=generator,
        ),
    )


def _validation_to_dict(validation: RobotPartValidation) -> dict[str, object]:
    return {
        "checks": [
            {"name": check.name, "state": check.state.value, "detail": check.detail}
            for check in validation.checks
        ]
    }


def _validation_from_dict(value: object) -> RobotPartValidation:
    row = _object(value, "robot-part validation")
    if set(row) != {"checks"} or not isinstance(row["checks"], list):
        raise RobotPartContractError("robot-part validation must contain only a checks array")
    checks: list[RobotPartCheck] = []
    for value in cast("list[object]", row["checks"]):
        check = _object(value, "robot-part validation check")
        if set(check) != {"name", "state", "detail"}:
            raise RobotPartContractError("robot-part validation check has an unsupported shape")
        checks.append(
            RobotPartCheck(
                _text(check, "name"),
                CheckState(_text(check, "state")),
                _text(check, "detail"),
            )
        )
    return RobotPartValidation(tuple(checks))


def _source_to_dict(source: RobotPartSource) -> dict[str, object]:
    provenance = source.provenance
    return {
        "kind": source.kind.value,
        "path": str(source.path),
        "sha256": str(source.sha256),
        "provenance": {
            "repository": provenance.repository,
            "revision": provenance.revision,
            "path": provenance.path,
            "license_id": provenance.license_id,
            "generator": provenance.generator,
        },
    }


def _source_from_dict(value: object) -> RobotPartSource:
    row = _object(value, "robot-part CAD source")
    if set(row) != {"kind", "path", "sha256", "provenance"}:
        raise RobotPartContractError("robot-part CAD source has an unsupported shape")
    origin = _object(row["provenance"], "robot-part CAD source provenance")
    if set(origin) != {"repository", "revision", "path", "license_id", "generator"}:
        raise RobotPartContractError("robot-part provenance has an unsupported shape")
    generator = origin["generator"]
    if generator is not None and not isinstance(generator, str):
        raise RobotPartContractError("robot-part provenance generator must be text or null")
    return RobotPartSource(
        RobotPartSourceKind(_text(row, "kind")),
        PurePosixPath(_text(row, "path")),
        Sha256Digest(_text(row, "sha256")),
        AssetProvenance(
            repository=_text(origin, "repository"),
            revision=_text(origin, "revision"),
            path=_text(origin, "path"),
            license_id=_text(origin, "license_id"),
            generator=generator,
        ),
    )


def _object(value: object, noun: str) -> dict[str, object]:
    if not isinstance(value, dict):
        raise RobotPartContractError(f"{noun} must be an object")
    mapping = cast("Mapping[object, object]", value)
    if any(not isinstance(key, str) for key in mapping):
        raise RobotPartContractError(f"{noun} keys must be text")
    return cast("dict[str, object]", mapping)


def _text(document: Mapping[str, object], key: str) -> str:
    value = document.get(key)
    if not isinstance(value, str) or not value:
        raise RobotPartContractError(f"robot-part {key} must be non-empty text")
    return value


def _integer(document: Mapping[str, object], key: str) -> int:
    value = document.get(key)
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise RobotPartContractError(f"robot-part {key} must be a positive integer")
    return value
