"""Digest-verified ephemeral local bytes for one canonical Scene."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Protocol, cast, runtime_checkable

from sx_contracts.assets import AssetRef

from sx_worlds.scene import Scene, SceneContractError


@runtime_checkable
class SceneAssetReader(Protocol):
    """The single content-byte capability required by Scene materialization."""

    def read(self, asset: AssetRef) -> bytes:
        """Return the exact bytes named by ``asset`` or fail."""
        ...


@dataclass(frozen=True, slots=True)
class MaterializedAsset:
    asset: AssetRef
    path: Path

    def __post_init__(self) -> None:
        if not self.path.is_absolute() or not self.path.is_file():
            raise SceneContractError(
                "a materialized asset must be an absolute file", "materialization"
            )
        _verify(self.asset, self.path.read_bytes())


@dataclass(frozen=True, slots=True)
class MaterializedScene:
    """One Scene plus a verified local path for every member; never a wire value."""

    scene: Scene
    directory: Path
    assets: tuple[MaterializedAsset, ...]

    def __post_init__(self) -> None:
        root = self.directory.resolve(strict=True)
        if not root.is_dir():
            raise SceneContractError("materialization root must be a directory", "materialization")
        object.__setattr__(self, "directory", root)
        expected = self.scene.assets.assets
        actual = tuple(item.asset for item in self.assets)
        if actual != expected:
            raise SceneContractError(
                "materialized assets must exactly preserve the Scene closure order",
                "materialization",
            )
        for item in self.assets:
            logical = cast(PurePosixPath, item.asset.logical_path)
            path = item.path.resolve(strict=True)
            if not path.is_relative_to(root):
                raise SceneContractError("materialized asset escaped its root", "materialization")
            if path.relative_to(root).as_posix() != str(logical):
                raise SceneContractError(
                    "materialized path disagrees with the asset logical path", "materialization"
                )

    @property
    def root_file(self) -> Path:
        return self.assets[0].path

    def path_for(self, logical_path: str | PurePosixPath) -> Path:
        logical = PurePosixPath(logical_path)
        matches = tuple(item.path for item in self.assets if item.asset.logical_path == logical)
        if len(matches) != 1:
            raise KeyError(f"Scene has no unique asset at {str(logical)!r}")
        return matches[0]

    def __getstate__(self) -> object:
        raise TypeError("MaterializedScene is ephemeral and cannot be serialized")


def materialize_scene(
    scene: Scene,
    reader: SceneAssetReader,
    directory: Path,
) -> MaterializedScene:
    """Verify the complete closure before returning any engine-loadable path."""

    root = directory.resolve()
    root.mkdir(parents=True, exist_ok=True)
    staged: list[tuple[AssetRef, Path, bytes]] = []
    for asset in scene.assets.assets:
        payload = reader.read(asset)
        _verify(asset, payload)
        logical = cast(PurePosixPath, asset.logical_path)
        destination = (root / Path(*logical.parts)).resolve()
        if not destination.is_relative_to(root):
            raise SceneContractError(
                "asset logical path escaped the materialization root", "materialization"
            )
        staged.append((asset, destination, payload))

    # No engine-visible value is returned until every byte in the closure has verified.
    for asset, destination, payload in staged:
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            _verify(asset, destination.read_bytes())
            continue
        temporary = destination.with_name(f".{destination.name}.{asset.sha256}.tmp")
        temporary.write_bytes(payload)
        temporary.replace(destination)

    return MaterializedScene(
        scene,
        root,
        tuple(MaterializedAsset(asset, path) for asset, path, _ in staged),
    )


def _verify(asset: AssetRef, payload: bytes) -> None:
    if len(payload) != asset.byte_size:
        raise SceneContractError(
            f"asset {asset.sha256} size mismatch: expected {asset.byte_size}, got {len(payload)}",
            "materialization",
        )
    actual = hashlib.sha256(payload).hexdigest()
    if actual != asset.sha256:
        raise SceneContractError(
            f"asset digest mismatch: expected {asset.sha256}, got {actual}", "materialization"
        )
