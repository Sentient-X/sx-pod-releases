"""Durable progress facts emitted by Worlds operation owners.

The owner writes one of these into the receipt's ``progress`` mapping; the mapping
stays the shared untyped carrier — live detail under ``running``, never a lifecycle
state. Two of the three are round-trip values: the evaluation and generation lanes
write theirs whole, so each carries the codec that reads it back, and the SDK decodes
those two families. :class:`AuthoringProgress` is deliberately not one of them — the
authoring lane merges its stage note into a larger door-local document (provider,
expected duration, unit counts), and until the door writes the value whole there is
nothing here to parse back.
"""

from dataclasses import dataclass

from sx_contracts import OperationContractError, decode


@dataclass(frozen=True, slots=True)
class EvaluationProgress:
    completed_cases: int
    total_cases: int
    current_case: str | None = None

    def __post_init__(self) -> None:
        if not 0 <= self.completed_cases <= self.total_cases:
            raise OperationContractError(
                "evaluation progress must stay within its admitted case count"
            )


def evaluation_progress_from_dict(value: object) -> EvaluationProgress:
    """Read one evaluation progress ledger, or refuse it typed."""

    document = decode.exactly(
        value,
        {"completed_cases", "total_cases", "current_case"},
        where="evaluation progress",
        error=OperationContractError,
    )
    return EvaluationProgress(
        completed_cases=decode.integer(document, "completed_cases"),
        total_cases=decode.integer(document, "total_cases"),
        current_case=decode.optional_text(document, "current_case"),
    )


@dataclass(frozen=True, slots=True)
class GenerationProgress:
    completed_attempts: int
    total_attempts: int
    registered_episodes: int

    def __post_init__(self) -> None:
        if not 0 <= self.registered_episodes <= self.completed_attempts <= self.total_attempts:
            raise OperationContractError("generation progress counts are inconsistent")


def generation_progress_from_dict(value: object) -> GenerationProgress:
    """Read one generation progress ledger, or refuse it typed."""

    document = decode.exactly(
        value,
        {"completed_attempts", "total_attempts", "registered_episodes"},
        where="generation progress",
        error=OperationContractError,
    )
    return GenerationProgress(
        completed_attempts=decode.integer(document, "completed_attempts"),
        total_attempts=decode.integer(document, "total_attempts"),
        registered_episodes=decode.integer(document, "registered_episodes"),
    )


@dataclass(frozen=True, slots=True)
class AuthoringProgress:
    """Where one authoring operation stands, at stage granularity.

    ``stage`` names the producer's current stage (a workspace design run's
    phase, a scan pipeline's stage); ``note`` carries the producer's one-line
    fact for that beat (turn counts, costs, the stage's own summary). Rows are
    append-only and monotonic by ``completed_stages``.
    """

    stage: str
    completed_stages: int
    total_stages: int
    note: str = ""

    def __post_init__(self) -> None:
        if not self.stage.strip():
            raise ValueError("authoring progress stage must not be empty")
        if not 0 <= self.completed_stages <= self.total_stages:
            raise ValueError("authoring progress must stay within its declared stage count")
