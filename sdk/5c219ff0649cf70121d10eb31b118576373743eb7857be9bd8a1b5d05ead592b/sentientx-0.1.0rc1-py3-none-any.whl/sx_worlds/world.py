"""The complete immutable task, scene, control, reset, goal, and safety binding."""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from typing import Literal, NewType, Protocol, cast, overload, runtime_checkable

import numpy as np
from sx_actions import (
    ActionInterface,
    CartesianCommands,
    ControlModeCommands,
    GripperCommands,
    action_interface_from_dict,
    action_interface_to_dict,
    validate_for_embodiment,
)
from sx_contracts import (
    BINARY_STATE_THRESHOLD,
    AtLeast,
    AtMost,
    BinaryStateIs,
    ComponentId,
    ContactWith,
    CountWithin,
    Exactly,
    FractionTransferredTo,
    GoalPredicate,
    JointAngleOutside,
    JointFractionAtLeast,
    OrientationErrorTo,
    PlanarDistanceTo,
    TaskContract,
    TaskRoleAssignments,
    TaskRoleBinding,
    TaskRoleId,
    UprightOrientationError,
    VerticalDistanceTo,
    Within,
    decode,
    task_role_assignments_wire,
    validate_assignments,
)
from sx_contracts import (
    canonical_json as task_canonical_json,
)
from sx_contracts import (
    from_canonical_json as task_from_canonical_json,
)
from sx_contracts.identity import CanonicalDocument, canonical_json, content_id
from sx_embodiments import ChannelKind
from sx_geometry import Pose, quat_angle, quat_to_mat

from sx_worlds.scene import Scene, SceneFrameKind, scene_from_dict, scene_to_dict

WORLD_SCHEMA = "sx.world/v1"
WorldId = NewType("WorldId", str)


type WorldPart = Literal["world", "grounding", "engine_config"]
"""What a world-domain rejection names: the contract itself, the grounding of a
declared support region, or the pinned engine configuration."""


class WorldContractError(ValueError):
    """A World is incomplete, ambiguous, or cannot be executed as declared.

    ``part`` is the typed name of what failed — the folded former leaf errors
    (grounding, engine config) live here as values, not as classes.
    """

    def __init__(self, message: str, part: WorldPart = "world") -> None:
        super().__init__(message)
        self.part = part


def _finite(value: float, label: str) -> float:
    if isinstance(value, bool) or not math.isfinite(value):
        raise WorldContractError(f"{label} must be finite numeric data")
    return float(value)


@dataclass(frozen=True, slots=True)
class AxisInterval:
    """One closed interval sampled by a reset distribution."""

    lower: float
    upper: float

    def __post_init__(self) -> None:
        lower = _finite(self.lower, "axis interval lower")
        upper = _finite(self.upper, "axis interval upper")
        if lower > upper:
            raise WorldContractError("axis interval requires lower <= upper")
        object.__setattr__(self, "lower", lower)
        object.__setattr__(self, "upper", upper)

    def at(self, unit: float) -> float:
        return self.lower + (self.upper - self.lower) * unit


def _quaternion(value: tuple[float, float, float, float], label: str) -> tuple[float, ...]:
    items = tuple(_finite(item, label) for item in value)
    norm = math.sqrt(sum(item * item for item in items))
    if norm < 1e-12:
        raise WorldContractError(f"{label} must be non-zero")
    normalized = tuple(item / norm for item in items)
    first = next((item for item in normalized if abs(item) > 1e-15), 1.0)
    return tuple(-item for item in normalized) if first < 0.0 else normalized


@dataclass(frozen=True, slots=True)
class PlacementDistribution:
    """The complete reset law for one resettable scene object."""

    object_name: str
    x: AxisInterval
    y: AxisInterval
    z: AxisInterval
    quaternion_wxyz: tuple[float, float, float, float]

    def __post_init__(self) -> None:
        if not self.object_name.strip():
            raise WorldContractError("placement distribution object must not be empty")
        object.__setattr__(
            self,
            "quaternion_wxyz",
            cast(
                "tuple[float, float, float, float]",
                _quaternion(self.quaternion_wxyz, "reset quaternion"),
            ),
        )


@dataclass(frozen=True, slots=True)
class NominalReset:
    name: str = "nominal"

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise WorldContractError("reset stratum name must not be empty")


@dataclass(frozen=True, slots=True)
class PlanarDisplacement:
    name: str
    radius_m: float

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise WorldContractError("reset stratum name must not be empty")
        radius = _finite(self.radius_m, "reset displacement radius")
        if radius <= 0.0:
            raise WorldContractError("reset displacement radius must be positive")
        object.__setattr__(self, "radius_m", radius)


type ResetStratum = NominalReset | PlanarDisplacement


@dataclass(frozen=True, slots=True)
class ObjectPlacement:
    object_name: str
    position: tuple[float, float, float]
    quaternion_wxyz: tuple[float, float, float, float]

    @property
    def pose(self) -> Pose:
        return Pose(np.asarray(self.position), np.asarray(self.quaternion_wxyz))


@dataclass(frozen=True, slots=True)
class ResetState:
    placements: tuple[ObjectPlacement, ...]
    seed: int
    stratum: str


@dataclass(frozen=True, slots=True)
class ResetDistribution:
    """A serializable reset law, pure from seed plus an explicitly declared stratum."""

    placements: tuple[PlacementDistribution, ...]
    strata: tuple[ResetStratum, ...] = (NominalReset(),)

    def __post_init__(self) -> None:
        names = tuple(item.object_name for item in self.placements)
        strata = tuple(item.name for item in self.strata)
        if not self.placements or len(names) != len(set(names)):
            raise WorldContractError("reset placements must be non-empty and object-unique")
        if not self.strata or len(strata) != len(set(strata)):
            raise WorldContractError("reset strata must be non-empty and name-unique")
        nominal = tuple(item for item in self.strata if isinstance(item, NominalReset))
        if len(nominal) != 1 or nominal[0].name != "nominal":
            raise WorldContractError("reset strata need exactly one stratum named 'nominal'")

    def sample(self, seed: int, stratum: str = "nominal") -> ResetState:
        if isinstance(seed, bool) or seed < 0:
            raise WorldContractError("reset seed must be a non-negative integer")
        selected = tuple(item for item in self.strata if item.name == stratum)
        if len(selected) != 1:
            raise WorldContractError(f"reset stratum {stratum!r} is not declared")
        sampled: list[ObjectPlacement] = []
        for index, law in enumerate(self.placements):
            position = (
                law.x.at(_unit(seed, stratum, index, "x")),
                law.y.at(_unit(seed, stratum, index, "y")),
                law.z.at(_unit(seed, stratum, index, "z")),
            )
            if isinstance(selected[0], PlanarDisplacement):
                angle = 2.0 * math.pi * _unit(seed, stratum, index, "angle")
                radius = selected[0].radius_m * math.sqrt(_unit(seed, stratum, index, "radius"))
                position = (
                    position[0] + radius * math.cos(angle),
                    position[1] + radius * math.sin(angle),
                    position[2],
                )
            sampled.append(ObjectPlacement(law.object_name, position, law.quaternion_wxyz))
        return ResetState(tuple(sampled), seed, stratum)


def _unit(seed: int, stratum: str, index: int, coordinate: str) -> float:
    digest = hashlib.sha256(f"{seed}:{stratum}:{index}:{coordinate}".encode()).digest()
    return int.from_bytes(digest[:8], "big") / 2**64


@dataclass(frozen=True, slots=True)
class ObjectAnchor:
    object_name: str

    def __post_init__(self) -> None:
        if not self.object_name.strip():
            raise WorldContractError("object anchor must not be empty")


@dataclass(frozen=True, slots=True)
class FrameAnchor:
    frame: str

    def __post_init__(self) -> None:
        if not self.frame.strip():
            raise WorldContractError("frame anchor must not be empty")


@dataclass(frozen=True, slots=True)
class FixedAnchor:
    position: tuple[float, float, float]
    quaternion_wxyz: tuple[float, float, float, float] = (1.0, 0.0, 0.0, 0.0)

    def __post_init__(self) -> None:
        if len(self.position) != 3:
            raise WorldContractError("fixed anchor position must have width three")
        object.__setattr__(
            self,
            "position",
            cast(
                "tuple[float, float, float]",
                tuple(_finite(v, "fixed anchor position") for v in self.position),
            ),
        )
        object.__setattr__(
            self,
            "quaternion_wxyz",
            cast(
                "tuple[float, float, float, float]",
                _quaternion(self.quaternion_wxyz, "fixed anchor quaternion"),
            ),
        )

    @property
    def pose(self) -> Pose:
        return Pose(np.asarray(self.position), np.asarray(self.quaternion_wxyz))


@dataclass(frozen=True, slots=True)
class ObjectSetAnchor:
    tag: str

    def __post_init__(self) -> None:
        if not self.tag.strip():
            raise WorldContractError("object-set anchor tag must not be empty")


type GoalAnchor = ObjectAnchor | FrameAnchor | FixedAnchor | ObjectSetAnchor


@dataclass(frozen=True, slots=True)
class GoalBinding:
    participant: str
    anchor: GoalAnchor

    def __post_init__(self) -> None:
        if not self.participant.strip():
            raise WorldContractError("goal participant must not be empty")


@dataclass(frozen=True, slots=True)
class NoAdditionalSafety:
    """The task contract declares no safety semantics beyond action validation."""


@dataclass(frozen=True, slots=True)
class WorkspaceLimit:
    component_id: str
    x: AxisInterval
    y: AxisInterval
    z: AxisInterval

    def __post_init__(self) -> None:
        if not self.component_id.strip():
            raise WorldContractError("workspace safety limit needs a component")


@dataclass(frozen=True, slots=True)
class CoordinateRateLimit:
    component_id: str
    coordinate_id: str
    maximum_per_second: float

    def __post_init__(self) -> None:
        if not self.component_id.strip() or not self.coordinate_id.strip():
            raise WorldContractError("coordinate safety limit needs component and coordinate")
        maximum = _finite(self.maximum_per_second, "coordinate safety rate")
        if maximum <= 0.0:
            raise WorldContractError("coordinate safety rate must be positive")
        object.__setattr__(self, "maximum_per_second", maximum)


@dataclass(frozen=True, slots=True)
class ForbiddenContact:
    object_name: str
    forbidden_tag: str

    def __post_init__(self) -> None:
        if not self.object_name.strip() or not self.forbidden_tag.strip():
            raise WorldContractError("forbidden contact needs an object and tag")


type SafetyRule = WorkspaceLimit | CoordinateRateLimit | ForbiddenContact


@dataclass(frozen=True, slots=True)
class BoundSafety:
    """An authored task safety intent compiled into executable closed rules."""

    intent: str
    rules: tuple[SafetyRule, ...]

    def __post_init__(self) -> None:
        if not self.intent.strip() or not self.rules:
            raise WorldContractError("bound safety requires intent and executable rules")


type SafetyBinding = NoAdditionalSafety | BoundSafety


@dataclass(frozen=True, slots=True)
class World:
    """The sole complete, content-addressed input to native World execution."""

    task: TaskContract
    scene: Scene
    action_interface: ActionInterface
    role_assignments: TaskRoleAssignments
    goal_bindings: tuple[GoalBinding, ...]
    reset_distribution: ResetDistribution
    safety: SafetyBinding
    max_steps: int

    def __post_init__(self) -> None:
        if isinstance(self.max_steps, bool):
            raise WorldContractError("World max_steps must be an integer")
        if self.max_steps <= 0:
            raise WorldContractError("World max_steps must be positive")
        try:
            validate_assignments(
                self.task.task.embodiment,
                self.scene.embodiment.capabilities,
                self.role_assignments,
            )
            validate_for_embodiment(self.action_interface, self.scene.embodiment)
        except ValueError as error:
            raise WorldContractError(f"World embodiment binding is invalid: {error}") from error
        _validate_action_binding(self)
        _validate_goal_binding(self)
        _validate_reset_binding(self)
        _validate_safety_binding(self)

    @property
    def id(self) -> WorldId:
        # The document nests open `to_dict` projections; `canonical_json` re-validates
        # the JSON shape at runtime before any byte is hashed.
        return content_id(WorldId, cast("CanonicalDocument", _world_document(self)))

    @property
    def task_id(self) -> str:
        return str(self.task.task.id)


def _validate_action_binding(world: World) -> None:
    scene_coordinates = {
        (binding.component_id, binding.coordinate_id) for binding in world.scene.control.coordinates
    }
    frame_by_name = {frame.name: frame for frame in world.scene.frames}
    for group in world.action_interface.groups:
        if isinstance(group, ControlModeCommands):
            raise WorldContractError("control-mode actions need an explicit engine binding")
        if isinstance(group, CartesianCommands):
            if group.frame not in frame_by_name:
                raise WorldContractError(
                    f"Cartesian command frame {group.frame!r} is absent from the Scene"
                )
            effectors = tuple(
                frame
                for frame in world.scene.frames
                if frame.kind is SceneFrameKind.END_EFFECTOR
                and frame.component_id == group.component_id
            )
            if len(effectors) != 1:
                raise WorldContractError(
                    f"Cartesian component {group.component_id!r} needs one end-effector frame"
                )
            continue
        if isinstance(group, GripperCommands):
            # An aperture command is command-space (its coordinate id need not be a state
            # coordinate); it grounds through the component's one gripper state coordinate,
            # whose scene binding totality already guarantees an MJCF realization.
            for coordinate in group.coordinates:
                grippers = tuple(
                    state
                    for state in world.scene.embodiment.state.coordinates
                    if state.instance == coordinate.component_id
                    and state.kind is ChannelKind.GRIPPER
                )
                if len(grippers) != 1:
                    raise WorldContractError(
                        f"gripper command component {coordinate.component_id!r} needs "
                        "exactly one gripper state coordinate"
                    )
            continue
        for coordinate in group.coordinates:
            key = (coordinate.component_id, str(coordinate.coordinate_id))
            if key not in scene_coordinates:
                raise WorldContractError(
                    f"action coordinate {key[0]}/{key[1]} has no Scene control binding"
                )


def _goal_participants(predicate: GoalPredicate) -> set[str]:
    participants = {predicate.entity}
    measure = predicate.measure
    if isinstance(
        measure,
        (
            PlanarDistanceTo,
            VerticalDistanceTo,
            OrientationErrorTo,
            FractionTransferredTo,
            CountWithin,
        ),
    ):
        participants.add(measure.reference)
    return participants


def _validate_goal_binding(world: World) -> None:
    expected = set[str]().union(
        *(_goal_participants(predicate) for predicate in world.task.task.goal.predicates)
    )
    names = tuple(binding.participant for binding in world.goal_bindings)
    if len(names) != len(set(names)) or set(names) != expected:
        raise WorldContractError(
            "World goal bindings must cover every typed goal participant exactly"
        )
    articulations = {item.name for item in world.scene.articulations}
    objects = {item.name: item for item in world.scene.objects}
    frames = {item.name for item in world.scene.frames}
    tags = set(world.scene.tags) | {tag for item in world.scene.objects for tag in item.tags}
    for predicate in world.task.task.goal.predicates:
        measure = predicate.measure
        if (
            isinstance(measure, (JointFractionAtLeast, BinaryStateIs, JointAngleOutside))
            and measure.articulation not in articulations
        ):
            raise WorldContractError(
                f"goal articulation {measure.articulation!r} is absent from the Scene"
            )
        # A contact surface resolves in the same namespace as `ForbiddenContact`:
        # a scene object by name, or a declared surface/body tag.
        if isinstance(measure, ContactWith) and measure.surface not in tags | set(objects):
            raise WorldContractError(
                f"goal contact surface {measure.surface!r} is absent from the Scene"
            )
    for binding in world.goal_bindings:
        anchor = binding.anchor
        if isinstance(anchor, ObjectAnchor) and anchor.object_name not in objects:
            raise WorldContractError(f"goal object {anchor.object_name!r} is absent from the Scene")
        if isinstance(anchor, FrameAnchor) and anchor.frame not in frames:
            raise WorldContractError(f"goal frame {anchor.frame!r} is absent from the Scene")
        if isinstance(anchor, ObjectSetAnchor) and anchor.tag not in tags:
            raise WorldContractError(f"goal object tag {anchor.tag!r} is absent from the Scene")


def _validate_reset_binding(world: World) -> None:
    resettable = {item.name for item in world.scene.objects if item.resettable}
    declared = {item.object_name for item in world.reset_distribution.placements}
    if declared != resettable:
        raise WorldContractError(
            f"World reset binding is not total: missing={sorted(resettable - declared)}, "
            f"extra={sorted(declared - resettable)}"
        )


def _validate_safety_binding(world: World) -> None:
    intent = world.task.task.safety
    if intent is None:
        if not isinstance(world.safety, NoAdditionalSafety):
            raise WorldContractError("a task without safety intent requires NoAdditionalSafety")
        return
    if not isinstance(world.safety, BoundSafety) or world.safety.intent != intent:
        raise WorldContractError("task safety intent needs an exact executable BoundSafety")
    components = {str(component.component_id) for component in world.scene.embodiment.components}
    objects = {item.name for item in world.scene.objects}
    tags = set(world.scene.tags) | {tag for item in world.scene.objects for tag in item.tags}
    coordinates = {
        (str(binding.component_id), binding.coordinate_id)
        for binding in world.scene.control.coordinates
    }
    for rule in world.safety.rules:
        if isinstance(rule, WorkspaceLimit) and rule.component_id not in components:
            raise WorldContractError("workspace safety rule names an absent component")
        if (
            isinstance(rule, CoordinateRateLimit)
            and (rule.component_id, rule.coordinate_id) not in coordinates
        ):
            raise WorldContractError("coordinate safety rule names an absent coordinate")
        if isinstance(rule, ForbiddenContact) and (
            rule.object_name not in objects or rule.forbidden_tag not in tags
        ):
            raise WorldContractError("contact safety rule names an absent object or tag")


@runtime_checkable
class RigidWorldState(Protocol):
    def object_pose(self, name: str) -> Pose: ...

    def frame_pose(self, name: str) -> Pose: ...


@runtime_checkable
class FluidWorldState(Protocol):
    def fraction_contained(self, medium: str, vessel: str) -> float: ...


@runtime_checkable
class CountWorldState(Protocol):
    def count_within(self, objects: tuple[str, ...], reference: Pose) -> int: ...


@runtime_checkable
class ArticulatedWorldState(Protocol):
    """A resolved state that can read the Scene's articulations.

    ``name`` is a ``SceneArticulation`` name. One Protocol carries both reads —
    not a sibling — because they are two projections of the same underlying
    fact: a state that can report a joint's normalized fraction necessarily
    read its raw position against the declared range, so splitting them would
    let a state claim half a capability it always has whole.
    """

    def joint_fraction(self, name: str) -> float:
        """The normalized fraction ``(position - lower) / (upper - lower)``."""
        ...

    def joint_angle(self, name: str) -> float:
        """The raw joint position in radians, unwrapped and unnormalized."""
        ...


@runtime_checkable
class ContactWorldState(Protocol):
    """A resolved state that can read physical contact between scene members.

    ``entity`` is a ``SceneObject`` name; ``surface`` is the touched member —
    an object name or a declared surface/body tag (the same namespace
    ``ForbiddenContact`` rules resolve against).
    """

    def in_contact(self, entity: str, surface: str) -> bool: ...


def verify_goal(world: World, state: RigidWorldState) -> bool:
    """Evaluate only the TaskContract goal and its exact typed World bindings."""

    bindings = {binding.participant: binding.anchor for binding in world.goal_bindings}
    return all(
        _verify_predicate(world, predicate, bindings, state)
        for predicate in world.task.task.goal.predicates
    )


def _verify_predicate(
    world: World,
    predicate: GoalPredicate,
    bindings: dict[str, GoalAnchor],
    state: RigidWorldState,
) -> bool:
    measure = predicate.measure
    entity = bindings[predicate.entity]
    if isinstance(measure, (JointFractionAtLeast, BinaryStateIs, JointAngleOutside)):
        if not isinstance(state, ArticulatedWorldState):
            raise WorldContractError("resolved World state cannot measure articulations")
        # Truth-valued measures: 1.0 when the named condition holds, else 0.0 — the
        # predicate's comparison grades that truth value (its [0, 1] codomain is a
        # `GoalPredicate` construction law).
        if isinstance(measure, JointAngleOutside):
            angle = state.joint_angle(measure.articulation)
            if not math.isfinite(angle):
                raise WorldContractError("articulation measurement returned a non-finite value")
            # The measure's pinned normalization (RoboCasa `get_knobs_state`): wrap the
            # raw angle into [0, 2*pi). Python's float `%` already returns a value with
            # the modulus's sign, so upstream's `if q < 0: q += 2*pi` step is subsumed.
            wrapped = angle % (2.0 * math.pi)
            value = 0.0 if measure.lower_rad <= wrapped <= measure.upper_rad else 1.0
        else:
            fraction = state.joint_fraction(measure.articulation)
            if not math.isfinite(fraction):
                raise WorldContractError("articulation measurement returned a non-finite value")
            if isinstance(measure, JointFractionAtLeast):
                value = 1.0 if fraction >= measure.fraction else 0.0
            else:
                value = 1.0 if (fraction >= BINARY_STATE_THRESHOLD) == measure.on else 0.0
    elif isinstance(measure, ContactWith):
        if not isinstance(state, ContactWorldState):
            raise WorldContractError("resolved World state cannot measure contact")
        if not isinstance(entity, ObjectAnchor):
            raise WorldContractError("contact goals require an object-bound entity")
        value = 1.0 if state.in_contact(entity.object_name, measure.surface) else 0.0
    elif isinstance(measure, FractionTransferredTo):
        if not isinstance(state, FluidWorldState):
            raise WorldContractError("resolved World state cannot measure fluid transfer")
        reference = bindings[measure.reference]
        if not isinstance(entity, ObjectAnchor) or not isinstance(reference, ObjectAnchor):
            raise WorldContractError("fluid goals require object-bound medium and vessel")
        value = state.fraction_contained(entity.object_name, reference.object_name)
    elif isinstance(measure, CountWithin):
        if not isinstance(state, CountWorldState):
            raise WorldContractError("resolved World state cannot measure object counts")
        if not isinstance(entity, ObjectSetAnchor):
            raise WorldContractError("count goals require an object-set entity binding")
        objects = tuple(item.name for item in world.scene.objects if entity.tag in item.tags)
        value = float(state.count_within(objects, _pose(bindings[measure.reference], state)))
    else:
        source = _pose(entity, state)
        if isinstance(measure, UprightOrientationError):
            local_z = quat_to_mat(source.quaternion)[:, 2]
            value = math.acos(float(np.clip(local_z[2], -1.0, 1.0)))
        else:
            target = _pose(bindings[measure.reference], state)
            if isinstance(measure, PlanarDistanceTo):
                value = float(np.linalg.norm(source.position[:2] - target.position[:2]))
            elif isinstance(measure, VerticalDistanceTo):
                # Signed: entity minus reference, as the deleted `compiled_success`
                # measured it. Published contracts bound engagement depth with negative
                # values (`ft-ia-peg-in-hole`: `at_most -0.02` — the pin at least 2 cm
                # past the rim), which a magnitude can never satisfy.
                value = float(source.position[2] - target.position[2])
            else:
                value = quat_angle(source.quaternion, target.quaternion)
    return _compare(value, predicate.comparison)


def _pose(anchor: GoalAnchor, state: RigidWorldState) -> Pose:
    if isinstance(anchor, ObjectAnchor):
        return state.object_pose(anchor.object_name)
    if isinstance(anchor, FrameAnchor):
        return state.frame_pose(anchor.frame)
    if isinstance(anchor, FixedAnchor):
        return anchor.pose
    raise WorldContractError("an object-set anchor has no singular pose")


def _compare(value: float, comparison: AtMost | AtLeast | Exactly | Within) -> bool:
    if not math.isfinite(value):
        raise WorldContractError("goal measurement returned a non-finite value")
    if isinstance(comparison, AtMost):
        return value <= comparison.value
    if isinstance(comparison, AtLeast):
        return value >= comparison.value
    if isinstance(comparison, Exactly):
        return value == comparison.value
    return abs(value - comparison.value) <= comparison.tolerance


def world_to_dict(world: World) -> dict[str, object]:
    return {"schema": WORLD_SCHEMA, "world_id": str(world.id), **_world_document(world)}


def world_from_dict(value: object) -> World:
    try:
        document = _object(value, "World")
        _exact(
            document,
            {
                "schema",
                "world_id",
                "task",
                "scene",
                "action_interface",
                "role_assignments",
                "goal_bindings",
                "reset_distribution",
                "safety",
                "max_steps",
            },
            "World",
        )
        if document["schema"] != WORLD_SCHEMA:
            raise WorldContractError(f"unsupported World schema {document['schema']!r}")
        world = World(
            # The wire value is untrusted; `canonical_json` re-validates the JSON shape.
            task=task_from_canonical_json(
                canonical_json(cast("CanonicalDocument", document["task"]))
            ),
            scene=scene_from_dict(document["scene"]),
            action_interface=action_interface_from_dict(
                _object(document["action_interface"], "World.action_interface")
            ),
            role_assignments=_parse_roles(document["role_assignments"]),
            goal_bindings=tuple(
                _parse_goal_binding(item) for item in decode.sequence(document, "goal_bindings")
            ),
            reset_distribution=_parse_reset(document["reset_distribution"]),
            safety=_parse_safety(document["safety"]),
            max_steps=decode.integer(document, "max_steps"),
        )
        if document["world_id"] != str(world.id):
            raise WorldContractError("world_id disagrees with the canonical World document")
        return world
    except WorldContractError:
        raise
    except (KeyError, TypeError, ValueError) as error:
        raise WorldContractError(f"malformed World document: {error}") from error


def _world_document(world: World) -> dict[str, object]:
    return {
        "task": cast("dict[str, object]", json.loads(task_canonical_json(world.task))),
        "scene": scene_to_dict(world.scene),
        "action_interface": action_interface_to_dict(world.action_interface),
        "role_assignments": list(task_role_assignments_wire(world.role_assignments)),
        "goal_bindings": [_goal_binding_document(item) for item in world.goal_bindings],
        "reset_distribution": _reset_document(world.reset_distribution),
        "safety": _safety_document(world.safety),
        "max_steps": world.max_steps,
    }


def _goal_binding_document(binding: GoalBinding) -> dict[str, object]:
    anchor = binding.anchor
    if isinstance(anchor, ObjectAnchor):
        payload: dict[str, object] = {"kind": "object", "object_name": anchor.object_name}
    elif isinstance(anchor, FrameAnchor):
        payload = {"kind": "frame", "frame": anchor.frame}
    elif isinstance(anchor, FixedAnchor):
        payload = {
            "kind": "fixed",
            "position": list(anchor.position),
            "quaternion_wxyz": list(anchor.quaternion_wxyz),
        }
    else:
        payload = {"kind": "object_set", "tag": anchor.tag}
    return {"participant": binding.participant, "anchor": payload}


def _parse_goal_binding(value: object) -> GoalBinding:
    document = _object(value, "World.goal_bindings[]")
    _exact(document, {"participant", "anchor"}, "World.goal_bindings[]")
    anchor = _object(document["anchor"], "World.goal_bindings[].anchor")
    kind = anchor.get("kind")
    if kind == "object":
        _exact(anchor, {"kind", "object_name"}, "object anchor")
        parsed: GoalAnchor = ObjectAnchor(decode.text(anchor, "object_name"))
    elif kind == "frame":
        _exact(anchor, {"kind", "frame"}, "frame anchor")
        parsed = FrameAnchor(decode.text(anchor, "frame"))
    elif kind == "fixed":
        _exact(anchor, {"kind", "position", "quaternion_wxyz"}, "fixed anchor")
        parsed = FixedAnchor(
            _float_tuple(anchor["position"], 3, "fixed anchor position"),
            _float_tuple(anchor["quaternion_wxyz"], 4, "fixed anchor quaternion"),
        )
    elif kind == "object_set":
        _exact(anchor, {"kind", "tag"}, "object-set anchor")
        parsed = ObjectSetAnchor(decode.text(anchor, "tag"))
    else:
        raise WorldContractError(f"unknown goal anchor kind {kind!r}")
    return GoalBinding(decode.text(document, "participant"), parsed)


def _reset_document(value: ResetDistribution) -> dict[str, object]:
    return {
        "placements": [
            {
                "object_name": item.object_name,
                "x": _interval_document(item.x),
                "y": _interval_document(item.y),
                "z": _interval_document(item.z),
                "quaternion_wxyz": list(item.quaternion_wxyz),
            }
            for item in value.placements
        ],
        "strata": [
            {"kind": "nominal", "name": item.name}
            if isinstance(item, NominalReset)
            else {"kind": "planar_displacement", "name": item.name, "radius_m": item.radius_m}
            for item in value.strata
        ],
    }


def _parse_reset(value: object) -> ResetDistribution:
    document = _object(value, "World.reset_distribution")
    _exact(document, {"placements", "strata"}, "World.reset_distribution")
    placements: list[PlacementDistribution] = []
    for item in decode.sequence(document, "placements"):
        placement = _object(item, "reset placement")
        _exact(
            placement,
            {"object_name", "x", "y", "z", "quaternion_wxyz"},
            "reset placement",
        )
        placements.append(
            PlacementDistribution(
                decode.text(placement, "object_name"),
                _parse_interval(placement["x"]),
                _parse_interval(placement["y"]),
                _parse_interval(placement["z"]),
                _float_tuple(placement["quaternion_wxyz"], 4, "reset quaternion"),
            )
        )
    strata: list[ResetStratum] = []
    for item in decode.sequence(document, "strata"):
        stratum = _object(item, "reset stratum")
        kind = stratum.get("kind")
        if kind == "nominal":
            _exact(stratum, {"kind", "name"}, "nominal reset stratum")
            strata.append(NominalReset(decode.text(stratum, "name")))
        elif kind == "planar_displacement":
            _exact(
                stratum,
                {"kind", "name", "radius_m"},
                "planar displacement stratum",
            )
            strata.append(
                PlanarDisplacement(
                    decode.text(stratum, "name"),
                    decode.number(stratum, "radius_m"),
                )
            )
        else:
            raise WorldContractError(f"unknown reset stratum kind {kind!r}")
    return ResetDistribution(tuple(placements), tuple(strata))


def _interval_document(value: AxisInterval) -> dict[str, float]:
    return {"lower": value.lower, "upper": value.upper}


def _parse_interval(value: object) -> AxisInterval:
    document = _object(value, "axis interval")
    _exact(document, {"lower", "upper"}, "axis interval")
    return AxisInterval(
        decode.number(document, "lower"),
        decode.number(document, "upper"),
    )


def _safety_document(value: SafetyBinding) -> dict[str, object]:
    if isinstance(value, NoAdditionalSafety):
        return {"kind": "no_additional_safety"}
    return {
        "kind": "bound_safety",
        "intent": value.intent,
        "rules": [_safety_rule_document(rule) for rule in value.rules],
    }


def _safety_rule_document(value: SafetyRule) -> dict[str, object]:
    if isinstance(value, WorkspaceLimit):
        return {
            "kind": "workspace_limit",
            "component_id": value.component_id,
            "x": _interval_document(value.x),
            "y": _interval_document(value.y),
            "z": _interval_document(value.z),
        }
    if isinstance(value, CoordinateRateLimit):
        return {
            "kind": "coordinate_rate_limit",
            "component_id": value.component_id,
            "coordinate_id": value.coordinate_id,
            "maximum_per_second": value.maximum_per_second,
        }
    return {
        "kind": "forbidden_contact",
        "object_name": value.object_name,
        "forbidden_tag": value.forbidden_tag,
    }


def _parse_safety(value: object) -> SafetyBinding:
    document = _object(value, "World.safety")
    kind = document.get("kind")
    if kind == "no_additional_safety":
        _exact(document, {"kind"}, "no-additional-safety binding")
        return NoAdditionalSafety()
    if kind != "bound_safety":
        raise WorldContractError(f"unknown safety binding kind {kind!r}")
    _exact(document, {"kind", "intent", "rules"}, "bound-safety binding")
    rules = tuple(_parse_safety_rule(item) for item in decode.sequence(document, "rules"))
    return BoundSafety(decode.text(document, "intent"), rules)


def _parse_safety_rule(value: object) -> SafetyRule:
    document = _object(value, "safety rule")
    kind = document.get("kind")
    if kind == "workspace_limit":
        _exact(document, {"kind", "component_id", "x", "y", "z"}, "workspace rule")
        return WorkspaceLimit(
            decode.text(document, "component_id"),
            _parse_interval(document["x"]),
            _parse_interval(document["y"]),
            _parse_interval(document["z"]),
        )
    if kind == "coordinate_rate_limit":
        _exact(
            document,
            {"kind", "component_id", "coordinate_id", "maximum_per_second"},
            "coordinate-rate rule",
        )
        return CoordinateRateLimit(
            decode.text(document, "component_id"),
            decode.text(document, "coordinate_id"),
            decode.number(document, "maximum_per_second"),
        )
    if kind == "forbidden_contact":
        _exact(document, {"kind", "object_name", "forbidden_tag"}, "contact rule")
        return ForbiddenContact(
            decode.text(document, "object_name"),
            decode.text(document, "forbidden_tag"),
        )
    raise WorldContractError(f"unknown safety rule kind {kind!r}")


def _parse_roles(value: object) -> TaskRoleAssignments:
    assignments: list[TaskRoleBinding] = []
    for item in _array(value, "World.role_assignments"):
        document = _object(item, "World.role_assignments[]")
        _exact(document, {"role_id", "component_id"}, "World.role_assignments[]")
        assignments.append(
            TaskRoleBinding(
                TaskRoleId(decode.text(document, "role_id")),
                ComponentId(decode.text(document, "component_id")),
            )
        )
    return TaskRoleAssignments(tuple(assignments))


def _object(value: object, label: str) -> decode.Document:
    return decode.document(value, where=label, error=WorldContractError)


def _array(value: object, label: str) -> list[object]:
    if not isinstance(value, list):
        raise WorldContractError(f"{label} must be an array")
    return cast("list[object]", value)


def _exact(value: decode.Document, fields: set[str], label: str) -> None:
    if set(value) != fields:
        raise WorldContractError(
            f"{label} fields differ: missing={sorted(fields - set(value))}, "
            f"unknown={sorted(set(value) - fields)}"
        )


@overload
def _float_tuple(value: object, width: Literal[3], label: str) -> tuple[float, float, float]: ...


@overload
def _float_tuple(
    value: object, width: Literal[4], label: str
) -> tuple[float, float, float, float]: ...


def _float_tuple(
    value: object, width: Literal[3, 4], label: str
) -> tuple[float, float, float] | tuple[float, float, float, float]:
    values = _array(value, label)
    if len(values) != width:
        raise WorldContractError(f"{label} must have width {width}")
    parsed = tuple(_scalar(item, label) for item in values)
    if width == 3:
        return cast("tuple[float, float, float]", parsed)
    return cast("tuple[float, float, float, float]", parsed)


def _scalar(value: object, label: str) -> float:
    """One number out of an array or a metric mapping — the kit reads fields, not values."""
    if isinstance(value, bool) or not isinstance(value, int | float) or not math.isfinite(value):
        raise WorldContractError(f"{label} must be finite numeric data")
    return float(value)
