"""Canonical composed scenes: content bytes, semantic objects, and typed MJCF bindings."""

from __future__ import annotations

import math
from dataclasses import dataclass, replace
from enum import StrEnum
from pathlib import PurePosixPath
from typing import Literal, cast

from sx_contracts import ComponentId, decode
from sx_contracts.assets import AssetFormat, AssetRef, AssetRole
from sx_contracts.content import ContentBlob, Sha256Digest
from sx_contracts.identity import CanonicalDocument, content_id
from sx_contracts.wire import HexDigest
from sx_embodiments import Embodiment

SCENE_SCHEMA = "sx.scene/v1"
type ScenePart = Literal["scene", "camera", "materialization"]
"""What a scene-domain rejection names: the document itself, a rendering camera's
calibrated parameters, or the digest-verified materialization of the asset closure."""


class SceneContractError(ValueError):
    """A canonical Scene is malformed, incomplete, or internally inconsistent.

    ``part`` is the typed name of what failed — the folded former leaf errors
    (camera parameters, materialization) live here as values, not as classes.
    """

    def __init__(self, message: str, part: ScenePart = "scene") -> None:
        super().__init__(message)
        self.part = part


class SceneId(HexDigest):
    """The content identity of one scene document.

    A `HexDigest` rather than a `NewType` because it is a digest and every door that
    publishes it should say so: a `NewType` carries no invariant into a schema, so the
    catalog restated the 64-hex pattern beside it instead.
    """

    error = SceneContractError
    noun = "scene id"


def canonical_scene_asset(asset: AssetRef, logical_path: str | PurePosixPath) -> AssetRef:
    """Project verified bytes into their one path-free Catalog scene reference."""

    path = PurePosixPath(logical_path)
    return replace(
        asset,
        location=f"catalog://assets/{asset.sha256}",
        logical_path=path,
    )


def _validate_scene_asset(asset: AssetRef, label: str) -> None:
    expected = f"catalog://assets/{asset.sha256}"
    if asset.location != expected:
        raise SceneContractError(
            f"{label} location must be the content-derived Catalog URI {expected!r}"
        )
    if asset.logical_path is None:
        raise SceneContractError(f"{label} needs a bundle-relative logical path")


@dataclass(frozen=True, slots=True)
class AssetClosure:
    """Exactly one root MJCF plus every byte member it references."""

    root: AssetRef
    members: tuple[AssetRef, ...] = ()

    def __post_init__(self) -> None:
        _validate_scene_asset(self.root, "asset closure root")
        if self.root.format is not AssetFormat.MJCF:
            raise SceneContractError("asset closure root must be MJCF")
        if self.root.role is not AssetRole.DESCRIPTION:
            raise SceneContractError("asset closure root must be a description asset")
        for member in self.members:
            _validate_scene_asset(member, "asset closure member")
            if member.format is AssetFormat.MJCF:
                raise SceneContractError("asset closure must contain exactly one MJCF asset")
        assets = (self.root, *self.members)
        paths = tuple(cast(PurePosixPath, asset.logical_path) for asset in assets)
        if len(set(paths)) != len(paths):
            raise SceneContractError("asset closure logical paths must be unique")
        identities = tuple((asset.sha256, asset.logical_path) for asset in assets)
        if len(set(identities)) != len(identities):
            raise SceneContractError("asset closure repeats a content/path member")
        member_paths = paths[1:]
        if tuple(sorted(member_paths, key=str)) != member_paths:
            raise SceneContractError("asset closure members must be logical-path ordered")

    @property
    def assets(self) -> tuple[AssetRef, ...]:
        return (self.root, *self.members)


class SceneCameraModality(StrEnum):
    RGB = "rgb"
    METRIC_DEPTH = "metric_depth"


class SceneFrameKind(StrEnum):
    WORLD = "world"
    OBJECT = "object"
    END_EFFECTOR = "end_effector"
    CAMERA = "camera"


@dataclass(frozen=True, slots=True)
class SceneFrame:
    """One semantic frame that World goals, actions, and cameras may name."""

    name: str
    kind: SceneFrameKind
    component_id: ComponentId | None = None

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise SceneContractError("scene frame name must not be empty")
        if self.kind is SceneFrameKind.END_EFFECTOR and self.component_id is None:
            raise SceneContractError("an end-effector frame must name its embodiment component")
        if self.kind is not SceneFrameKind.END_EFFECTOR and self.component_id is not None:
            raise SceneContractError("only an end-effector frame may name a component")


@dataclass(frozen=True, slots=True)
class SceneCamera:
    """A named calibrated-view source and the modalities it truthfully renders."""

    name: str
    frame: str
    modalities: tuple[SceneCameraModality, ...]

    def __post_init__(self) -> None:
        if not self.name.strip() or not self.frame.strip():
            raise SceneContractError("scene camera name and frame must not be empty")
        if not self.modalities or len(set(self.modalities)) != len(self.modalities):
            raise SceneContractError("scene camera modalities must be non-empty and unique")


@dataclass(frozen=True, slots=True)
class SceneObject:
    """One semantic object bound to one MJCF body and optional reset/grasp joint."""

    name: str
    body: str
    category: str
    free_joint: str | None = None
    mocap: bool = False
    graspable: bool = False
    tags: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.name.strip() or not self.body.strip() or not self.category.strip():
            raise SceneContractError("scene object name, body, and category must not be empty")
        if self.free_joint is not None and not self.free_joint.strip():
            raise SceneContractError("scene object free_joint must be non-empty when present")
        if self.free_joint is not None and self.mocap:
            raise SceneContractError("one scene object cannot be both free-jointed and mocap")
        if self.graspable and self.free_joint is None:
            raise SceneContractError("a graspable scene object needs its free joint binding")
        if any(not tag.strip() for tag in self.tags) or len(set(self.tags)) != len(self.tags):
            raise SceneContractError("scene object tags must be non-empty and unique")

    @property
    def resettable(self) -> bool:
        return self.free_joint is not None or self.mocap


class SceneJointKind(StrEnum):
    """The MJCF joint types an articulation can bind: a hinge or a slide."""

    HINGE = "hinge"
    SLIDE = "slide"


@dataclass(frozen=True, slots=True)
class SceneArticulation:
    """One named articulated degree of freedom bound to one MJCF joint.

    ``lower``/``upper`` are the joint range in MJCF units (radians for a hinge,
    metres for a slide) and ``home`` is the reset position inside that range. The
    normalized *joint fraction* an ``ArticulatedWorldState`` reports for this name
    is ``(position - lower) / (upper - lower)``; its raw *joint angle* is the
    unnormalized position itself.
    """

    name: str
    joint: str
    kind: SceneJointKind
    lower: float
    upper: float
    home: float = 0.0

    def __post_init__(self) -> None:
        if not self.name.strip() or not self.joint.strip():
            raise SceneContractError("scene articulation name and joint must not be empty")
        for label, value in (("lower", self.lower), ("upper", self.upper), ("home", self.home)):
            if not math.isfinite(value):
                raise SceneContractError(f"scene articulation {label} must be finite")
        if self.lower >= self.upper:
            raise SceneContractError("scene articulation range requires lower < upper")
        if not self.lower <= self.home <= self.upper:
            raise SceneContractError("scene articulation home must lie within its range")


@dataclass(frozen=True, slots=True)
class JointActuatorBinding:
    """One MJCF joint projection, including its coordinate direction and actuator."""

    joint: str
    actuator: str | None
    sign: float = 1.0

    def __post_init__(self) -> None:
        if not self.joint.strip():
            raise SceneContractError("joint binding needs a non-empty MJCF joint")
        if self.actuator is not None and not self.actuator.strip():
            raise SceneContractError("actuator binding must be non-empty when present")
        if not math.isfinite(self.sign) or self.sign == 0.0:
            raise SceneContractError("joint binding sign must be finite and non-zero")


@dataclass(frozen=True, slots=True)
class CoordinateControlBinding:
    """One canonical embodiment coordinate projected onto one or more MJCF joints."""

    component_id: ComponentId
    coordinate_id: str
    joints: tuple[JointActuatorBinding, ...]

    def __post_init__(self) -> None:
        if not self.coordinate_id.strip() or not self.joints:
            raise SceneContractError("coordinate binding needs an id and at least one joint")
        names = tuple(binding.joint for binding in self.joints)
        if len(set(names)) != len(names):
            raise SceneContractError("one coordinate binding repeats an MJCF joint")


@dataclass(frozen=True, slots=True)
class WorldFrameTarget:
    """The distinguished MJCF world frame."""


@dataclass(frozen=True, slots=True)
class BodyFrameTarget:
    body: str

    def __post_init__(self) -> None:
        if not self.body.strip():
            raise SceneContractError("body frame target must not be empty")


@dataclass(frozen=True, slots=True)
class SiteFrameTarget:
    site: str

    def __post_init__(self) -> None:
        if not self.site.strip():
            raise SceneContractError("site frame target must not be empty")


@dataclass(frozen=True, slots=True)
class CameraFrameTarget:
    camera: str

    def __post_init__(self) -> None:
        if not self.camera.strip():
            raise SceneContractError("camera frame target must not be empty")


type FrameTarget = WorldFrameTarget | BodyFrameTarget | SiteFrameTarget | CameraFrameTarget


@dataclass(frozen=True, slots=True)
class FrameControlBinding:
    frame: str
    target: FrameTarget

    def __post_init__(self) -> None:
        if not self.frame.strip():
            raise SceneContractError("frame control binding needs a non-empty frame")


@dataclass(frozen=True, slots=True)
class SceneControlBinding:
    """The total canonical-coordinate and semantic-frame projection into MJCF."""

    coordinates: tuple[CoordinateControlBinding, ...]
    frames: tuple[FrameControlBinding, ...]

    def __post_init__(self) -> None:
        coordinate_keys = tuple(
            (binding.component_id, binding.coordinate_id) for binding in self.coordinates
        )
        frame_keys = tuple(binding.frame for binding in self.frames)
        if len(set(coordinate_keys)) != len(coordinate_keys):
            raise SceneContractError("scene control binding repeats a canonical coordinate")
        if len(set(frame_keys)) != len(frame_keys):
            raise SceneContractError("scene control binding repeats a semantic frame")

    def coordinate(self, component_id: ComponentId, coordinate_id: str) -> CoordinateControlBinding:
        matches = tuple(
            binding
            for binding in self.coordinates
            if binding.component_id == component_id and binding.coordinate_id == coordinate_id
        )
        if len(matches) != 1:
            raise SceneContractError(
                f"coordinate {component_id}/{coordinate_id} has {len(matches)} bindings"
            )
        return matches[0]

    def frame(self, name: str) -> FrameControlBinding:
        matches = tuple(binding for binding in self.frames if binding.frame == name)
        if len(matches) != 1:
            raise SceneContractError(f"frame {name!r} has {len(matches)} bindings")
        return matches[0]


@dataclass(frozen=True, slots=True)
class LiquidVolume:
    name: str
    container_object: str
    volume_l: float
    density_kg_m3: float

    def __post_init__(self) -> None:
        if not self.name.strip() or not self.container_object.strip():
            raise SceneContractError("liquid layer name and container must not be empty")
        if not math.isfinite(self.volume_l) or self.volume_l <= 0.0:
            raise SceneContractError("liquid volume must be positive and finite")
        if not math.isfinite(self.density_kg_m3) or self.density_kg_m3 <= 0.0:
            raise SceneContractError("liquid density must be positive and finite")


@dataclass(frozen=True, slots=True)
class DeformableSurface:
    name: str
    object_name: str
    rest_asset: AssetRef

    def __post_init__(self) -> None:
        if not self.name.strip() or not self.object_name.strip():
            raise SceneContractError("deformable layer name and object must not be empty")
        _validate_scene_asset(self.rest_asset, "deformable rest asset")


@dataclass(frozen=True, slots=True)
class GaussianSplatLayer:
    asset: AssetRef
    frame: str

    def __post_init__(self) -> None:
        _validate_scene_asset(self.asset, "Gaussian splat asset")
        if self.asset.format is not AssetFormat.SPLAT:
            raise SceneContractError("Gaussian splat layer asset must use the splat format")
        if not self.frame.strip():
            raise SceneContractError("Gaussian splat layer needs a semantic frame")


type SceneLayer = LiquidVolume | DeformableSurface | GaussianSplatLayer


@dataclass(frozen=True, slots=True)
class Scene:
    """One immutable, path-free composed environment and its truthful MJCF projection."""

    assets: AssetClosure
    embodiment: Embodiment
    objects: tuple[SceneObject, ...]
    frames: tuple[SceneFrame, ...]
    cameras: tuple[SceneCamera, ...]
    tags: tuple[str, ...]
    control: SceneControlBinding
    layers: tuple[SceneLayer, ...] = ()
    articulations: tuple[SceneArticulation, ...] = ()

    def __post_init__(self) -> None:
        object_names = tuple(item.name for item in self.objects)
        object_bodies = tuple(item.body for item in self.objects)
        frame_names = tuple(item.name for item in self.frames)
        camera_names = tuple(item.name for item in self.cameras)
        for label, values in (
            ("object names", object_names),
            ("object bodies", object_bodies),
            ("frame names", frame_names),
            ("camera names", camera_names),
            ("articulation names", tuple(item.name for item in self.articulations)),
            ("articulation joints", tuple(item.joint for item in self.articulations)),
        ):
            if len(set(values)) != len(values):
                raise SceneContractError(f"scene repeats {label}")
        if any(not tag.strip() for tag in self.tags) or len(set(self.tags)) != len(self.tags):
            raise SceneContractError("scene tags must be non-empty and unique")
        expected_coordinates = {
            (coordinate.instance, coordinate.axis.name)
            for coordinate in self.embodiment.state.coordinates
        }
        actual_coordinates = {
            (binding.component_id, binding.coordinate_id) for binding in self.control.coordinates
        }
        if actual_coordinates != expected_coordinates:
            missing = sorted(f"{c}/{a}" for c, a in expected_coordinates - actual_coordinates)
            extra = sorted(f"{c}/{a}" for c, a in actual_coordinates - expected_coordinates)
            raise SceneContractError(
                f"scene coordinate binding is not total: missing={missing}, extra={extra}"
            )
        if {binding.frame for binding in self.control.frames} != set(frame_names):
            raise SceneContractError("scene frame bindings must cover every semantic frame exactly")
        frame_by_name = {frame.name: frame for frame in self.frames}
        binding_by_frame = {binding.frame: binding for binding in self.control.frames}
        for camera in self.cameras:
            frame = frame_by_name.get(camera.frame)
            if frame is None or frame.kind is not SceneFrameKind.CAMERA:
                raise SceneContractError(f"camera {camera.name!r} has no camera frame")
            target = binding_by_frame[camera.frame].target
            if not isinstance(target, CameraFrameTarget) or target.camera != camera.name:
                raise SceneContractError(
                    f"camera {camera.name!r} frame does not bind to that MJCF camera"
                )
        for layer in self.layers:
            if isinstance(layer, LiquidVolume) and layer.container_object not in object_names:
                raise SceneContractError("liquid layer container is not a scene object")
            if isinstance(layer, DeformableSurface):
                if layer.object_name not in object_names:
                    raise SceneContractError("deformable layer object is not a scene object")
                if layer.rest_asset not in self.assets.assets:
                    raise SceneContractError("deformable rest asset is outside the asset closure")
            if isinstance(layer, GaussianSplatLayer):
                if layer.frame not in frame_names:
                    raise SceneContractError("Gaussian splat layer frame is not a scene frame")
                if layer.asset not in self.assets.assets:
                    raise SceneContractError("Gaussian splat asset is outside the asset closure")

    @property
    def id(self) -> SceneId:
        # The document nests the embodiment's open `to_dict` projection; `canonical_json`
        # re-validates the JSON shape at runtime before any byte is hashed.
        return content_id(SceneId, cast("CanonicalDocument", _scene_document(self)))

    @property
    def native_control(self) -> tuple[CoordinateControlBinding, ...]:
        """Control bindings ordered by the embodiment's declared state coordinates.

        The one owned permutation from native state order to MJCF joints: an engine that
        reads or writes a native vector follows this view, never MuJoCo's own joint or
        actuator interleaving (identity for one arm; the law for many). Total by
        construction — Scene validation already proved the binding covers every
        coordinate exactly.
        """
        return tuple(
            self.control.coordinate(coordinate.instance, coordinate.axis.name)
            for coordinate in self.embodiment.state.coordinates
        )

    def object(self, name: str) -> SceneObject:
        matches = tuple(item for item in self.objects if item.name == name)
        if len(matches) != 1:
            raise KeyError(f"scene {self.id} has no unique object named {name!r}")
        return matches[0]

    def camera(self, name: str) -> SceneCamera:
        matches = tuple(item for item in self.cameras if item.name == name)
        if len(matches) != 1:
            raise KeyError(f"scene {self.id} has no unique camera named {name!r}")
        return matches[0]

    def articulation(self, name: str) -> SceneArticulation:
        matches = tuple(item for item in self.articulations if item.name == name)
        if len(matches) != 1:
            raise KeyError(f"scene {self.id} has no unique articulation named {name!r}")
        return matches[0]


def scene_to_dict(scene: Scene) -> dict[str, object]:
    """The exact canonical ``sx.scene/v1`` wire document."""

    return {"schema": SCENE_SCHEMA, "scene_id": str(scene.id), **_scene_document(scene)}


def scene_from_dict(value: object) -> Scene:
    """Parse one exact Scene document and verify its quoted content identity."""

    try:
        document = _object(value, "scene")
        fields = {
            "schema",
            "scene_id",
            "assets",
            "embodiment",
            "objects",
            "frames",
            "cameras",
            "tags",
            "control",
            "layers",
        }
        # "articulations" is present exactly when non-empty (see `_scene_document`), so a
        # pre-articulation document parses unchanged and keeps its quoted SceneId.
        if "articulations" in document:
            fields.add("articulations")
        _exact(document, fields, "scene")
        if document["schema"] != SCENE_SCHEMA:
            raise SceneContractError(f"unsupported scene schema {document['schema']!r}")
        articulations = tuple(
            articulation_from_dict(item)
            for item in (
                decode.sequence(document, "articulations") if "articulations" in document else ()
            )
        )
        if "articulations" in document and not articulations:
            raise SceneContractError("scene articulations, when present, must be non-empty")
        scene = Scene(
            assets=asset_closure_from_dict(document["assets"], where="scene.assets"),
            embodiment=Embodiment.from_dict(_object(document["embodiment"], "embodiment")),
            objects=tuple(_parse_object(item) for item in decode.sequence(document, "objects")),
            frames=tuple(_parse_frame(item) for item in decode.sequence(document, "frames")),
            cameras=tuple(_parse_camera(item) for item in decode.sequence(document, "cameras")),
            tags=decode.texts(document, "tags"),
            control=_parse_control(document["control"]),
            layers=tuple(_parse_layer(item) for item in decode.sequence(document, "layers")),
            articulations=articulations,
        )
        if document["scene_id"] != str(scene.id):
            raise SceneContractError("scene_id disagrees with the canonical scene document")
        return scene
    except SceneContractError:
        raise
    except (KeyError, TypeError, ValueError) as error:
        raise SceneContractError(f"malformed scene document: {error}") from error


def _scene_document(scene: Scene) -> dict[str, object]:
    document: dict[str, object] = {
        "assets": asset_closure_to_dict(scene.assets),
        "embodiment": scene.embodiment.to_dict(),
        "objects": [_object_document(item) for item in scene.objects],
        "frames": [_frame_document(item) for item in scene.frames],
        "cameras": [_camera_document(item) for item in scene.cameras],
        "tags": list(scene.tags),
        "control": _control_document(scene.control),
        "layers": [_layer_document(item) for item in scene.layers],
    }
    # The one canonical encoding of "no articulations" is the absent key: every scene
    # authored before the field existed keeps its exact document bytes and SceneId, and
    # only an articulated scene mints the new shape (which pre-articulation readers
    # refuse as an unknown field — the fail-closed direction the wire law requires).
    if scene.articulations:
        document["articulations"] = [articulation_to_dict(item) for item in scene.articulations]
    return document


def asset_ref_to_dict(asset: AssetRef) -> dict[str, object]:
    """Canonical wire projection for one logical member of a Worlds asset closure."""

    return {
        "uri": asset.location,
        "sha256": asset.sha256,
        "byte_size": asset.byte_size,
        "format": asset.format.value,
        "role": asset.role.value,
        "media_type": asset.media_type,
        "logical_path": str(cast(PurePosixPath, asset.logical_path)),
    }


def asset_ref_from_dict(value: object, *, where: str = "asset") -> AssetRef:
    """Parse one exact logical asset reference shared by Worlds resources."""

    item = _object(value, where)
    _exact(
        item,
        {"uri", "sha256", "byte_size", "format", "role", "media_type", "logical_path"},
        where,
    )
    media_type = item["media_type"]
    if media_type is not None and not isinstance(media_type, str):
        raise SceneContractError(f"{where}.media_type must be text or null")
    return AssetRef(
        location=decode.text(item, "uri"),
        content=ContentBlob(
            Sha256Digest(decode.text(item, "sha256")),
            decode.integer(item, "byte_size"),
        ),
        format=AssetFormat(decode.text(item, "format")),
        role=AssetRole(decode.text(item, "role")),
        media_type=media_type,
        logical_path=PurePosixPath(decode.text(item, "logical_path")),
    )


def asset_closure_to_dict(value: AssetClosure) -> dict[str, object]:
    """Canonical wire projection shared by scenes and environment bundles."""

    return {
        "root": asset_ref_to_dict(value.root),
        "members": [asset_ref_to_dict(member) for member in value.members],
    }


def asset_closure_from_dict(value: object, *, where: str = "assets") -> AssetClosure:
    """Parse the one asset-closure wire shape."""

    document = _object(value, where)
    _exact(document, {"root", "members"}, where)
    return AssetClosure(
        asset_ref_from_dict(document["root"], where=f"{where}.root"),
        tuple(
            asset_ref_from_dict(item, where=f"{where}.members[{index}]")
            for index, item in enumerate(decode.sequence(document, "members"))
        ),
    )


def _object_document(value: SceneObject) -> dict[str, object]:
    return {
        "name": value.name,
        "body": value.body,
        "category": value.category,
        "free_joint": value.free_joint,
        "mocap": value.mocap,
        "graspable": value.graspable,
        "tags": list(value.tags),
    }


def _parse_object(value: object) -> SceneObject:
    document = _object(value, "scene.objects[]")
    _exact(
        document,
        {"name", "body", "category", "free_joint", "mocap", "graspable", "tags"},
        "scene.objects[]",
    )
    free_joint = document["free_joint"]
    if free_joint is not None and not isinstance(free_joint, str):
        raise SceneContractError("scene object free_joint must be text or null")
    return SceneObject(
        decode.text(document, "name"),
        decode.text(document, "body"),
        decode.text(document, "category"),
        free_joint,
        decode.boolean(document, "mocap"),
        decode.boolean(document, "graspable"),
        decode.texts(document, "tags"),
    )


def articulation_to_dict(value: SceneArticulation) -> dict[str, object]:
    return {
        "name": value.name,
        "joint": value.joint,
        "kind": value.kind.value,
        "lower": value.lower,
        "upper": value.upper,
        "home": value.home,
    }


def articulation_from_dict(
    value: object, *, where: str = "scene.articulations[]"
) -> SceneArticulation:
    document = _object(value, where)
    _exact(document, {"name", "joint", "kind", "lower", "upper", "home"}, where)
    return SceneArticulation(
        decode.text(document, "name"),
        decode.text(document, "joint"),
        SceneJointKind(decode.text(document, "kind")),
        decode.number(document, "lower"),
        decode.number(document, "upper"),
        decode.number(document, "home"),
    )


def _frame_document(value: SceneFrame) -> dict[str, object]:
    return {
        "name": value.name,
        "kind": value.kind.value,
        "component_id": None if value.component_id is None else str(value.component_id),
    }


def _parse_frame(value: object) -> SceneFrame:
    document = _object(value, "scene.frames[]")
    _exact(document, {"name", "kind", "component_id"}, "scene.frames[]")
    component = document["component_id"]
    if component is not None and not isinstance(component, str):
        raise SceneContractError("scene frame component_id must be text or null")
    return SceneFrame(
        decode.text(document, "name"),
        SceneFrameKind(decode.text(document, "kind")),
        None if component is None else ComponentId(component),
    )


def _camera_document(value: SceneCamera) -> dict[str, object]:
    return {
        "name": value.name,
        "frame": value.frame,
        "modalities": [item.value for item in value.modalities],
    }


def _parse_camera(value: object) -> SceneCamera:
    document = _object(value, "scene.cameras[]")
    _exact(document, {"name", "frame", "modalities"}, "scene.cameras[]")
    return SceneCamera(
        decode.text(document, "name"),
        decode.text(document, "frame"),
        tuple(SceneCameraModality(item) for item in decode.texts(document, "modalities")),
    )


def _joint_document(value: JointActuatorBinding) -> dict[str, object]:
    return {"joint": value.joint, "actuator": value.actuator, "sign": value.sign}


def _parse_joint(value: object) -> JointActuatorBinding:
    document = _object(value, "scene.control.coordinates[].joints[]")
    _exact(document, {"joint", "actuator", "sign"}, "joint binding")
    actuator = document["actuator"]
    if actuator is not None and not isinstance(actuator, str):
        raise SceneContractError("joint binding actuator must be text or null")
    return JointActuatorBinding(
        decode.text(document, "joint"),
        actuator,
        decode.number(document, "sign"),
    )


def _target_document(value: FrameTarget) -> dict[str, object]:
    if isinstance(value, WorldFrameTarget):
        return {"kind": "world"}
    if isinstance(value, BodyFrameTarget):
        return {"kind": "body", "body": value.body}
    if isinstance(value, SiteFrameTarget):
        return {"kind": "site", "site": value.site}
    return {"kind": "camera", "camera": value.camera}


def _parse_target(value: object) -> FrameTarget:
    document = _object(value, "scene.control.frames[].target")
    kind = document.get("kind")
    if kind == "world":
        _exact(document, {"kind"}, "world frame target")
        return WorldFrameTarget()
    if kind == "body":
        _exact(document, {"kind", "body"}, "body frame target")
        return BodyFrameTarget(decode.text(document, "body"))
    if kind == "site":
        _exact(document, {"kind", "site"}, "site frame target")
        return SiteFrameTarget(decode.text(document, "site"))
    if kind == "camera":
        _exact(document, {"kind", "camera"}, "camera frame target")
        return CameraFrameTarget(decode.text(document, "camera"))
    raise SceneContractError(f"unknown frame target kind {kind!r}")


def _control_document(value: SceneControlBinding) -> dict[str, object]:
    return {
        "coordinates": [
            {
                "component_id": str(binding.component_id),
                "coordinate_id": binding.coordinate_id,
                "joints": [_joint_document(item) for item in binding.joints],
            }
            for binding in value.coordinates
        ],
        "frames": [
            {"frame": binding.frame, "target": _target_document(binding.target)}
            for binding in value.frames
        ],
    }


def _parse_control(value: object) -> SceneControlBinding:
    document = _object(value, "scene.control")
    _exact(document, {"coordinates", "frames"}, "scene.control")
    coordinates: list[CoordinateControlBinding] = []
    for item in decode.sequence(document, "coordinates"):
        binding = _object(item, "coordinate binding")
        _exact(binding, {"component_id", "coordinate_id", "joints"}, "coordinate binding")
        coordinates.append(
            CoordinateControlBinding(
                ComponentId(decode.text(binding, "component_id")),
                decode.text(binding, "coordinate_id"),
                tuple(_parse_joint(joint) for joint in decode.sequence(binding, "joints")),
            )
        )
    frames: list[FrameControlBinding] = []
    for item in decode.sequence(document, "frames"):
        binding = _object(item, "frame binding")
        _exact(binding, {"frame", "target"}, "frame binding")
        frames.append(
            FrameControlBinding(
                decode.text(binding, "frame"),
                _parse_target(binding["target"]),
            )
        )
    return SceneControlBinding(tuple(coordinates), tuple(frames))


def _layer_document(value: SceneLayer) -> dict[str, object]:
    if isinstance(value, LiquidVolume):
        return {
            "kind": "liquid_volume",
            "name": value.name,
            "container_object": value.container_object,
            "volume_l": value.volume_l,
            "density_kg_m3": value.density_kg_m3,
        }
    if isinstance(value, DeformableSurface):
        return {
            "kind": "deformable_surface",
            "name": value.name,
            "object_name": value.object_name,
            "rest_asset": asset_ref_to_dict(value.rest_asset),
        }
    return {
        "kind": "gaussian_splat",
        "asset": asset_ref_to_dict(value.asset),
        "frame": value.frame,
    }


def _parse_layer(value: object) -> SceneLayer:
    document = _object(value, "scene.layers[]")
    kind = document.get("kind")
    if kind == "liquid_volume":
        _exact(
            document,
            {"kind", "name", "container_object", "volume_l", "density_kg_m3"},
            "liquid layer",
        )
        return LiquidVolume(
            decode.text(document, "name"),
            decode.text(document, "container_object"),
            decode.number(document, "volume_l"),
            decode.number(document, "density_kg_m3"),
        )
    if kind == "deformable_surface":
        _exact(
            document,
            {"kind", "name", "object_name", "rest_asset"},
            "deformable layer",
        )
        return DeformableSurface(
            decode.text(document, "name"),
            decode.text(document, "object_name"),
            asset_ref_from_dict(document["rest_asset"], where="deformable rest asset"),
        )
    if kind == "gaussian_splat":
        _exact(document, {"kind", "asset", "frame"}, "Gaussian splat layer")
        return GaussianSplatLayer(
            asset_ref_from_dict(document["asset"], where="Gaussian splat asset"),
            decode.text(document, "frame"),
        )
    raise SceneContractError(f"unknown scene layer kind {kind!r}")


def _object(value: object, label: str) -> decode.Document:
    return decode.document(value, where=label, error=SceneContractError)


def _exact(value: decode.Document, fields: set[str], label: str) -> None:
    if set(value) != fields:
        raise SceneContractError(
            f"{label} fields differ: missing={sorted(fields - set(value))}, "
            f"unknown={sorted(set(value) - fields)}"
        )
