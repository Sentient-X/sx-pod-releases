"""Declarative articulated-object parts model: parts, materials, and joints as pure data.

Ported from ``https://github.com/Sentient-X/LiteReality-Agent@aa0046e131cf4a11efdef94089c7afcf55e6c44f``
(``.../image-to-articulated-glb/scripts/object_model.py``, Apache-2.0), adapted to the
sx house style: frozen slots dataclasses, a ``PartShape`` enum, joint kinds spoken in the
one shared vocabulary (:class:`sx_worlds.scene.SceneJointKind`), and typed
:class:`PartsContractError` refusals raised at construction instead of a severity-tagged
report dict. Metres and radians throughout, Z-up.

Two upstream behaviours are deliberately not ported:

- the front-facing check (centroid travel toward +Y under the joint) — it constrains
  upstream's Blender *build* frame (canonical front = -Y), not the declarative geometry,
  so it stays with the Blender compiler rather than this frame-agnostic model;
- ``build()`` — compilation is a consumer's job (Blender GLB upstream, native MJCF in
  ``sim_envs.real2sim.litereality.mjcf`` here).

Upstream's ``fixed`` joint kind is modelled as ``kind=None`` — the smallest truthful
shape: a fixed joint introduces no degree of freedom, it is an author's explicit weld
statement, so no enum member exists for it and ``SceneJointKind`` stays exactly the MJCF
hinge/slide vocabulary. Upstream's soft isolated-part QC survives as the
:meth:`ArticulatedObjectModel.isolated_parts` query rather than a non-fatal "violation".
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import StrEnum

from sx_worlds.scene import SceneJointKind

_AXIS_EPSILON = 1e-6
_LIMIT_EPSILON = 1e-6
_TOUCH_TOLERANCE = 1e-3


class PartsContractError(ValueError):
    """An articulated parts model is malformed; ``part`` names what failed."""

    def __init__(self, message: str, *, part: str = "model") -> None:
        super().__init__(message)
        self.part = part


class PartShape(StrEnum):
    """The closed geometry forms the native Worlds compiler accepts."""

    BOX = "box"
    CYLINDER = "cylinder"
    MESH = "mesh"


@dataclass(frozen=True, slots=True)
class PartMesh:
    """One complete, object-local triangle surface carried by the authored algebra.

    A WorkspaceJob normally derives these vertices and faces from a build123d solid.
    The dependency-free contract proves only structural integrity; Worlds independently
    proves watertight positive volume with trimesh before compiling the mesh to MJCF.
    """

    vertices: tuple[tuple[float, float, float], ...]
    faces: tuple[tuple[int, int, int], ...]

    def __post_init__(self) -> None:
        if len(self.vertices) < 4 or len(self.faces) < 4:
            raise PartsContractError("a part mesh needs at least four vertices and four faces")
        if any(
            len(vertex) != 3 or any(not math.isfinite(value) for value in vertex)
            for vertex in self.vertices
        ):
            raise PartsContractError("part mesh vertices must be finite XYZ triples")
        if any(
            len(face) != 3
            or any(isinstance(index, bool) for index in face)
            or len(set(face)) != 3
            or any(index < 0 or index >= len(self.vertices) for index in face)
            for face in self.faces
        ):
            raise PartsContractError("part mesh faces must be distinct in-range index triples")
        used = {index for face in self.faces for index in face}
        if used != set(range(len(self.vertices))):
            raise PartsContractError("every part mesh vertex must belong to a face")
        unoriented = [tuple(sorted(face)) for face in self.faces]
        if len(unoriented) != len(set(unoriented)):
            raise PartsContractError("part mesh repeats a triangle")


class ClosureKind(StrEnum):
    """The closed set of MuJoCo equality constraints the native compiler supports."""

    CONNECT = "connect"
    WELD = "weld"


@dataclass(frozen=True, slots=True)
class Material:
    """One named appearance: a plain PBR colour, or texture paths relative to a texture dir."""

    name: str
    color: tuple[float, float, float] = (0.8, 0.8, 0.8)  # linear rgb, 0-1
    roughness: float = 0.6
    metallic: float = 0.0
    diffuse: str | None = None
    rough: str | None = None
    normal: str | None = None

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise PartsContractError("material name must not be empty")
        for label, value in (("roughness", self.roughness), ("metallic", self.metallic)):
            if not math.isfinite(value) or not 0.0 <= value <= 1.0:
                raise PartsContractError(f"material {label} must lie in [0, 1]", part=self.name)
        if any(not math.isfinite(channel) or not 0.0 <= channel <= 1.0 for channel in self.color):
            raise PartsContractError("material color channels must lie in [0, 1]", part=self.name)
        for label, path in (
            ("diffuse", self.diffuse),
            ("rough", self.rough),
            ("normal", self.normal),
        ):
            if path is not None and not path.strip():
                raise PartsContractError(
                    f"material {label} path must be non-empty when present", part=self.name
                )


@dataclass(frozen=True, slots=True)
class Part:
    """One rigid body at a centre pose in the model frame (Z-up metres, radians)."""

    name: str
    shape: PartShape
    size: tuple[float, ...]  # box: (dx, dy, dz) · cylinder: (radius, depth) · mesh: ()
    at: tuple[float, float, float] = (0.0, 0.0, 0.0)
    material: str | None = None
    rot: tuple[float, float, float] = (0.0, 0.0, 0.0)  # euler radians, for tilted cylinders
    mesh: PartMesh | None = None

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise PartsContractError("part name must not be empty")
        expected = {PartShape.BOX: 3, PartShape.CYLINDER: 2, PartShape.MESH: 0}[self.shape]
        if len(self.size) != expected:
            raise PartsContractError(
                f"a {self.shape.value} part takes exactly {expected} size values,"
                f" got {len(self.size)}",
                part=self.name,
            )
        if any(not math.isfinite(value) or value <= 0.0 for value in self.size):
            raise PartsContractError("part size values must be positive metres", part=self.name)
        if any(not math.isfinite(value) for value in (*self.at, *self.rot)):
            raise PartsContractError("part pose must be finite", part=self.name)
        if self.material is not None and not self.material.strip():
            raise PartsContractError("part material must be non-empty when present", part=self.name)
        if (self.shape is PartShape.MESH) != (self.mesh is not None):
            raise PartsContractError(
                "only a mesh part carries mesh geometry, and it must carry one", part=self.name
            )


@dataclass(frozen=True, slots=True)
class Joint:
    """How one named part moves relative to the static rest of the model.

    ``kind=None`` is upstream's ``fixed``: an explicit weld with no degree of freedom,
    so a fixed joint must carry no travel claim (both limits zero). For a moving joint
    the limits are radians (hinge) or metres (slide); either limit may be the larger —
    a limit interval is a set, not an ordered pair.
    """

    part: str
    kind: SceneJointKind | None
    axis: tuple[float, float, float] = (0.0, 0.0, 1.0)
    origin: tuple[float, float, float] = (0.0, 0.0, 0.0)  # hinge point (hinge only)
    limit_min: float = 0.0
    limit_max: float = 0.0

    def __post_init__(self) -> None:
        if not self.part.strip():
            raise PartsContractError("joint part must not be empty")
        finite = (*self.axis, *self.origin, self.limit_min, self.limit_max)
        if any(not math.isfinite(value) for value in finite):
            raise PartsContractError("joint values must be finite", part=self.part)
        if self.kind is None:
            if self.limit_min != 0.0 or self.limit_max != 0.0:
                raise PartsContractError(
                    "a fixed joint carries no travel — its limits must both be zero",
                    part=self.part,
                )
            return
        if math.hypot(*self.axis) < _AXIS_EPSILON:
            raise PartsContractError("joint axis is zero-length", part=self.part)
        if abs(self.limit_max - self.limit_min) < _LIMIT_EPSILON:
            raise PartsContractError(
                f"degenerate limits (min={self.limit_min}, max={self.limit_max})"
                " — the joint cannot move",
                part=self.part,
            )


@dataclass(frozen=True, slots=True)
class Frame:
    """One named semantic frame fixed to a part (Z-up metres/radians)."""

    name: str
    part: str
    at: tuple[float, float, float] = (0.0, 0.0, 0.0)
    rot: tuple[float, float, float] = (0.0, 0.0, 0.0)

    def __post_init__(self) -> None:
        if not self.name.strip() or not self.part.strip():
            raise PartsContractError("frame name and part must not be empty", part=self.name)
        if any(not math.isfinite(value) for value in (*self.at, *self.rot)):
            raise PartsContractError("frame pose must be finite", part=self.name)


@dataclass(frozen=True, slots=True)
class BodyInertia:
    """Measured or designed rigid-body inertia bound to one part."""

    part: str
    mass_kg: float
    center_xyz: tuple[float, float, float]
    diagonal_kg_m2: tuple[float, float, float]

    def __post_init__(self) -> None:
        if not self.part.strip():
            raise PartsContractError("inertial part must not be empty")
        if not math.isfinite(self.mass_kg) or self.mass_kg <= 0:
            raise PartsContractError("inertial mass must be positive", part=self.part)
        if any(not math.isfinite(value) for value in self.center_xyz):
            raise PartsContractError("inertial center must be finite", part=self.part)
        diagonal = self.diagonal_kg_m2
        if any(not math.isfinite(value) or value <= 0 for value in diagonal):
            raise PartsContractError("diagonal inertia must be positive", part=self.part)
        if any(diagonal[index] > sum(diagonal) - diagonal[index] for index in range(3)):
            raise PartsContractError(
                "diagonal inertia violates the triangle inequalities", part=self.part
            )


@dataclass(frozen=True, slots=True)
class Closure:
    """One supported loop-closure constraint between named semantic frames."""

    name: str
    kind: ClosureKind
    first_frame: str
    second_frame: str

    def __post_init__(self) -> None:
        if any(not value.strip() for value in (self.name, self.first_frame, self.second_frame)):
            raise PartsContractError("closure names and frames must not be empty", part=self.name)
        if self.first_frame == self.second_frame:
            raise PartsContractError("closure frames must be distinct", part=self.name)


@dataclass(frozen=True, slots=True)
class ArticulatedObjectModel:
    """One articulated object as data: every cross-reference is proven at construction."""

    name: str
    parts: tuple[Part, ...]
    materials: tuple[Material, ...] = ()
    joints: tuple[Joint, ...] = ()
    frames: tuple[Frame, ...] = ()
    inertials: tuple[BodyInertia, ...] = ()
    closures: tuple[Closure, ...] = ()

    def __post_init__(self) -> None:
        self.validate()

    def validate(self) -> None:
        """Refuse a model whose references or joint graph cannot compile anywhere."""

        if not self.name.strip():
            raise PartsContractError("model name must not be empty")
        if not self.parts:
            raise PartsContractError("a parts model needs at least one part")
        part_names = tuple(part.name for part in self.parts)
        for label, values in (
            ("part", part_names),
            ("material", tuple(material.name for material in self.materials)),
            ("frame", tuple(frame.name for frame in self.frames)),
            ("inertial", tuple(inertial.part for inertial in self.inertials)),
            ("closure", tuple(closure.name for closure in self.closures)),
        ):
            duplicates = sorted({name for name in values if values.count(name) > 1})
            if duplicates:
                raise PartsContractError(f"two {label}s share a name", part=duplicates[0])
        material_names = {material.name for material in self.materials}
        for part in self.parts:
            if part.material is not None and part.material not in material_names:
                raise PartsContractError(
                    f"part references unknown material {part.material!r}", part=part.name
                )
        jointed: set[str] = set()
        for joint in self.joints:
            if joint.part not in part_names:
                raise PartsContractError(
                    "joint targets a part that does not exist", part=joint.part
                )
            if joint.part in jointed:
                raise PartsContractError(
                    "two joints move the same part — the joint graph must be a tree",
                    part=joint.part,
                )
            jointed.add(joint.part)
        frame_names = {frame.name for frame in self.frames}
        part_name_set = set(part_names)
        for frame in self.frames:
            if frame.part not in part_name_set:
                raise PartsContractError(
                    "frame references a part that does not exist", part=frame.name
                )
        for inertial in self.inertials:
            if inertial.part not in part_name_set:
                raise PartsContractError(
                    "inertial references a part that does not exist", part=inertial.part
                )
        for closure in self.closures:
            missing = {closure.first_frame, closure.second_frame} - frame_names
            if missing:
                raise PartsContractError(
                    f"closure references unknown frames {sorted(missing)}", part=closure.name
                )

    def isolated_parts(self) -> tuple[str, ...]:
        """Upstream's soft QC as a query: parts whose AABB touches no other part's (1 mm).

        Cylinder and mesh AABBs ignore ``rot`` — this is only the upstream-compatible
        soft isolation query. The native compiler derives authoritative rotated bounds.
        """

        if len(self.parts) < 2:
            return ()
        boxes = {part.name: _part_aabb(part) for part in self.parts}
        return tuple(
            name
            for name in (part.name for part in self.parts)
            if not any(other != name and _touches(boxes[name], boxes[other]) for other in boxes)
        )


type _Aabb = tuple[tuple[float, float, float], tuple[float, float, float]]


def _part_aabb(part: Part) -> _Aabb:
    center_x, center_y, center_z = part.at
    if part.shape is PartShape.CYLINDER:
        radius, depth = part.size
        half_x = half_y = radius
        half_z = depth / 2.0
    elif part.shape is PartShape.MESH:
        assert part.mesh is not None
        axes = tuple(zip(*part.mesh.vertices, strict=True))
        half_x, half_y, half_z = ((max(values) - min(values)) / 2.0 for values in axes)
        mesh_center = tuple((min(values) + max(values)) / 2.0 for values in axes)
        center_x += mesh_center[0]
        center_y += mesh_center[1]
        center_z += mesh_center[2]
    else:
        half_x, half_y, half_z = (value / 2.0 for value in part.size)
    return (
        (center_x - half_x, center_y - half_y, center_z - half_z),
        (center_x + half_x, center_y + half_y, center_z + half_z),
    )


def _touches(first: _Aabb, second: _Aabb) -> bool:
    return all(
        first[1][axis] >= second[0][axis] - _TOUCH_TOLERANCE
        and second[1][axis] >= first[0][axis] - _TOUCH_TOLERANCE
        for axis in range(3)
    )
