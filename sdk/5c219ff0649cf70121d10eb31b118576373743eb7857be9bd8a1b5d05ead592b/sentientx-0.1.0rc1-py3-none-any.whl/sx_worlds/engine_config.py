"""Closed, content-addressed execution configuration for admitted World conformers."""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from enum import StrEnum
from typing import NewType, cast

from sx_contracts import decode
from sx_contracts.identity import CanonicalDocument, content_id

from sx_worlds.world import WorldContractError

ENGINE_CONFIG_SCHEMA = "sx.engine-config/v1"
EngineConfigId = NewType("EngineConfigId", str)


class Simulator(StrEnum):
    """The complete public simulator vocabulary.

    Engine configurations remain exact, content-addressed execution facts.  This
    deliberately smaller identity is the only simulator choice exposed by Worlds
    requests; providers, physics libraries, and renderers are not product variants.
    """

    MUJOCO = "mujoco"
    ISAAC_LAB_NEWTON = "isaac_lab_newton"


class MujocoIntegrator(StrEnum):
    EULER = "euler"
    RK4 = "rk4"
    IMPLICIT = "implicit"
    IMPLICIT_FAST = "implicit_fast"


class MujocoSolver(StrEnum):
    PGS = "pgs"
    CG = "cg"
    NEWTON = "newton"


class RenderBackend(StrEnum):
    EGL = "egl"
    OSMESA = "osmesa"
    GLFW = "glfw"
    VULKAN = "vulkan"
    CUDA = "cuda"
    # macOS's own offscreen GL context — what MuJoCo uses there when MUJOCO_GL is unset.
    CGL = "cgl"


def _text(value: str, label: str) -> None:
    if not value.strip():
        raise WorldContractError(f"{label} must not be empty", "engine_config")


def _positive(value: float, label: str) -> None:
    if isinstance(value, bool) or not math.isfinite(value) or value <= 0.0:
        raise WorldContractError(f"{label} must be positive and finite", "engine_config")


def _positive_int(value: int, label: str) -> None:
    if isinstance(value, bool) or value <= 0:
        raise WorldContractError(f"{label} must be a positive integer", "engine_config")


def _resolution(width: int, height: int) -> None:
    _positive_int(width, "render width")
    _positive_int(height, "render height")


@dataclass(frozen=True, slots=True)
class MujocoEngineConfig:
    runtime_version: str
    timestep_s: float
    control_substeps: int
    integrator: MujocoIntegrator
    solver: MujocoSolver
    iterations: int
    line_search_iterations: int
    tolerance: float
    render_backend: RenderBackend
    render_width: int
    render_height: int
    render_samples: int

    def __post_init__(self) -> None:
        _text(self.runtime_version, "MuJoCo runtime version")
        _positive(self.timestep_s, "MuJoCo timestep")
        _positive_int(self.control_substeps, "MuJoCo control substeps")
        _positive_int(self.iterations, "MuJoCo solver iterations")
        _positive_int(self.line_search_iterations, "MuJoCo line-search iterations")
        _positive(self.tolerance, "MuJoCo tolerance")
        _resolution(self.render_width, self.render_height)
        _positive_int(self.render_samples, "MuJoCo render samples")


@dataclass(frozen=True, slots=True)
class MjxEngineConfig:
    mujoco_version: str
    mjx_version: str
    warp_version: str
    timestep_s: float
    control_substeps: int
    solver: MujocoSolver
    iterations: int
    line_search_iterations: int
    batch_size: int
    device: str
    render_backend: RenderBackend
    render_width: int
    render_height: int

    def __post_init__(self) -> None:
        for value, label in (
            (self.mujoco_version, "MuJoCo version"),
            (self.mjx_version, "MJX version"),
            (self.warp_version, "Warp version"),
            (self.device, "MJX device"),
        ):
            _text(value, label)
        _positive(self.timestep_s, "MJX timestep")
        _positive_int(self.control_substeps, "MJX control substeps")
        _positive_int(self.iterations, "MJX solver iterations")
        _positive_int(self.line_search_iterations, "MJX line-search iterations")
        _positive_int(self.batch_size, "MJX batch size")
        _resolution(self.render_width, self.render_height)


@dataclass(frozen=True, slots=True)
class ManiSkillEngineConfig:
    runtime_version: str
    environment_id: str
    physics_backend: str
    controller: str
    sim_hz: int
    control_hz: int
    num_envs: int
    device: str
    renderer: str
    render_width: int
    render_height: int

    def __post_init__(self) -> None:
        for value, label in (
            (self.runtime_version, "ManiSkill runtime version"),
            (self.environment_id, "ManiSkill environment id"),
            (self.physics_backend, "ManiSkill physics backend"),
            (self.controller, "ManiSkill controller"),
            (self.device, "ManiSkill device"),
            (self.renderer, "ManiSkill renderer"),
        ):
            _text(value, label)
        _positive_int(self.sim_hz, "ManiSkill simulation rate")
        _positive_int(self.control_hz, "ManiSkill control rate")
        if self.sim_hz % self.control_hz:
            raise WorldContractError(
                "ManiSkill simulation rate must divide by control rate", "engine_config"
            )
        _positive_int(self.num_envs, "ManiSkill environment count")
        _resolution(self.render_width, self.render_height)


@dataclass(frozen=True, slots=True)
class GenesisEngineConfig:
    runtime_version: str
    nyx_version: str
    backend: str
    precision: str
    sim_hz: int
    control_substeps: int
    rigid_solver: str
    rigid_iterations: int
    liquid_solver: str
    liquid_iterations: int
    deformable_solver: str
    deformable_iterations: int
    renderer: str
    render_width: int
    render_height: int
    device: str

    def __post_init__(self) -> None:
        if self.runtime_version != "1.3.1":
            raise WorldContractError("Genesis runtime must be pinned to 1.3.1", "engine_config")
        if self.nyx_version != "0.1.3":
            raise WorldContractError("Nyx runtime must be pinned to 0.1.3", "engine_config")
        for value, label in (
            (self.backend, "Genesis backend"),
            (self.precision, "Genesis precision"),
            (self.rigid_solver, "Genesis rigid solver"),
            (self.liquid_solver, "Genesis liquid solver"),
            (self.deformable_solver, "Genesis deformable solver"),
            (self.renderer, "Genesis renderer"),
            (self.device, "Genesis device"),
        ):
            _text(value, label)
        _positive_int(self.sim_hz, "Genesis simulation rate")
        _positive_int(self.control_substeps, "Genesis control substeps")
        _positive_int(self.rigid_iterations, "Genesis rigid iterations")
        _positive_int(self.liquid_iterations, "Genesis liquid iterations")
        _positive_int(self.deformable_iterations, "Genesis deformable iterations")
        _resolution(self.render_width, self.render_height)


class IsaacLabNewtonSolver(StrEnum):
    MJWARP = "mjwarp"
    KAMINO = "kamino"
    VBD = "vbd"


@dataclass(frozen=True, slots=True)
class IsaacLabNewtonEngineConfig:
    """Reproducible facts for one kit-less Isaac Lab/Newton execution."""

    isaac_lab_version: str
    newton_version: str
    warp_version: str
    torch_version: str
    cuda_version: str
    solver: IsaacLabNewtonSolver
    timestep_s: float
    control_substeps: int
    num_envs: int
    device: str
    renderer: str
    render_width: int
    render_height: int

    def __post_init__(self) -> None:
        for value, label in (
            (self.isaac_lab_version, "Isaac Lab version"),
            (self.newton_version, "Newton version"),
            (self.warp_version, "Warp version"),
            (self.torch_version, "PyTorch version"),
            (self.cuda_version, "CUDA version"),
            (self.device, "Isaac Lab device"),
            (self.renderer, "Isaac Lab renderer"),
        ):
            _text(value, label)
        _positive(self.timestep_s, "Isaac Lab timestep")
        _positive_int(self.control_substeps, "Isaac Lab control substeps")
        _positive_int(self.num_envs, "Isaac Lab environment count")
        _resolution(self.render_width, self.render_height)


@dataclass(frozen=True, slots=True)
class LiberoEngineConfig:
    runtime_version: str
    benchmark: str
    environment_id: str
    controller: str
    render_width: int
    render_height: int

    def __post_init__(self) -> None:
        _locked(self.runtime_version, self.benchmark, self.environment_id, self.controller)
        _resolution(self.render_width, self.render_height)


@dataclass(frozen=True, slots=True)
class RoboCasaEngineConfig:
    runtime_version: str
    benchmark: str
    environment_id: str
    controller: str
    render_width: int
    render_height: int

    def __post_init__(self) -> None:
        _locked(self.runtime_version, self.benchmark, self.environment_id, self.controller)
        _resolution(self.render_width, self.render_height)


@dataclass(frozen=True, slots=True)
class SimplerEnvEngineConfig:
    runtime_version: str
    benchmark: str
    environment_id: str
    controller: str
    render_width: int
    render_height: int

    def __post_init__(self) -> None:
        _locked(self.runtime_version, self.benchmark, self.environment_id, self.controller)
        _resolution(self.render_width, self.render_height)


def _locked(runtime: str, benchmark: str, environment: str, controller: str) -> None:
    for value, label in (
        (runtime, "locked runtime version"),
        (benchmark, "locked benchmark"),
        (environment, "locked environment id"),
        (controller, "locked controller"),
    ):
        _text(value, label)


type EngineConfig = (
    MujocoEngineConfig
    | MjxEngineConfig
    | ManiSkillEngineConfig
    | GenesisEngineConfig
    | IsaacLabNewtonEngineConfig
    | LiberoEngineConfig
    | RoboCasaEngineConfig
    | SimplerEnvEngineConfig
)


_KINDS: dict[str, type[EngineConfig]] = {
    "mujoco": MujocoEngineConfig,
    "mjx": MjxEngineConfig,
    "maniskill": ManiSkillEngineConfig,
    "genesis": GenesisEngineConfig,
    "isaac_lab_newton": IsaacLabNewtonEngineConfig,
    "libero": LiberoEngineConfig,
    "robocasa": RoboCasaEngineConfig,
    "simpler_env": SimplerEnvEngineConfig,
}


def engine_config_id(config: EngineConfig) -> EngineConfigId:
    # The document projects `asdict` output; `canonical_json` re-validates the JSON
    # shape at runtime before any byte is hashed.
    return content_id(EngineConfigId, cast("CanonicalDocument", _config_document(config)))


def engine_config_to_dict(config: EngineConfig) -> dict[str, object]:
    return {
        "schema": ENGINE_CONFIG_SCHEMA,
        "engine_config_id": str(engine_config_id(config)),
        **_config_document(config),
    }


def engine_config_from_dict(value: object) -> EngineConfig:
    document = decode.document(value, where="engine config", error=WorldContractError)
    kind = document.get("kind")
    if not isinstance(kind, str) or kind not in _KINDS:
        raise WorldContractError(f"unknown engine config variant {kind!r}", "engine_config")
    config_type = _KINDS[kind]
    fields = set(config_type.__dataclass_fields__)
    expected = {"schema", "engine_config_id", "kind", *fields}
    if set(document) != expected:
        raise WorldContractError(
            f"engine config fields differ: missing={sorted(expected - set(document))}, "
            f"unknown={sorted(set(document) - expected)}",
            "engine_config",
        )
    if document["schema"] != ENGINE_CONFIG_SCHEMA:
        raise WorldContractError(
            f"unsupported engine config schema {document['schema']!r}", "engine_config"
        )
    try:
        config = _parse_config(kind, document)
    except (TypeError, ValueError) as error:
        raise WorldContractError(
            f"malformed {kind} engine config: {error}", "engine_config"
        ) from error
    if document["engine_config_id"] != str(engine_config_id(config)):
        raise WorldContractError(
            "engine_config_id disagrees with canonical config content", "engine_config"
        )
    return config


def _parse_config(kind: str, value: decode.Document) -> EngineConfig:
    if kind == "mujoco":
        return MujocoEngineConfig(
            decode.text(value, "runtime_version"),
            decode.number(value, "timestep_s"),
            decode.integer(value, "control_substeps"),
            MujocoIntegrator(decode.text(value, "integrator")),
            MujocoSolver(decode.text(value, "solver")),
            decode.integer(value, "iterations"),
            decode.integer(value, "line_search_iterations"),
            decode.number(value, "tolerance"),
            RenderBackend(decode.text(value, "render_backend")),
            decode.integer(value, "render_width"),
            decode.integer(value, "render_height"),
            decode.integer(value, "render_samples"),
        )
    if kind == "mjx":
        return MjxEngineConfig(
            decode.text(value, "mujoco_version"),
            decode.text(value, "mjx_version"),
            decode.text(value, "warp_version"),
            decode.number(value, "timestep_s"),
            decode.integer(value, "control_substeps"),
            MujocoSolver(decode.text(value, "solver")),
            decode.integer(value, "iterations"),
            decode.integer(value, "line_search_iterations"),
            decode.integer(value, "batch_size"),
            decode.text(value, "device"),
            RenderBackend(decode.text(value, "render_backend")),
            decode.integer(value, "render_width"),
            decode.integer(value, "render_height"),
        )
    if kind == "maniskill":
        return ManiSkillEngineConfig(
            decode.text(value, "runtime_version"),
            decode.text(value, "environment_id"),
            decode.text(value, "physics_backend"),
            decode.text(value, "controller"),
            decode.integer(value, "sim_hz"),
            decode.integer(value, "control_hz"),
            decode.integer(value, "num_envs"),
            decode.text(value, "device"),
            decode.text(value, "renderer"),
            decode.integer(value, "render_width"),
            decode.integer(value, "render_height"),
        )
    if kind == "genesis":
        return GenesisEngineConfig(
            decode.text(value, "runtime_version"),
            decode.text(value, "nyx_version"),
            decode.text(value, "backend"),
            decode.text(value, "precision"),
            decode.integer(value, "sim_hz"),
            decode.integer(value, "control_substeps"),
            decode.text(value, "rigid_solver"),
            decode.integer(value, "rigid_iterations"),
            decode.text(value, "liquid_solver"),
            decode.integer(value, "liquid_iterations"),
            decode.text(value, "deformable_solver"),
            decode.integer(value, "deformable_iterations"),
            decode.text(value, "renderer"),
            decode.integer(value, "render_width"),
            decode.integer(value, "render_height"),
            decode.text(value, "device"),
        )
    if kind == "isaac_lab_newton":
        return IsaacLabNewtonEngineConfig(
            decode.text(value, "isaac_lab_version"),
            decode.text(value, "newton_version"),
            decode.text(value, "warp_version"),
            decode.text(value, "torch_version"),
            decode.text(value, "cuda_version"),
            IsaacLabNewtonSolver(decode.text(value, "solver")),
            decode.number(value, "timestep_s"),
            decode.integer(value, "control_substeps"),
            decode.integer(value, "num_envs"),
            decode.text(value, "device"),
            decode.text(value, "renderer"),
            decode.integer(value, "render_width"),
            decode.integer(value, "render_height"),
        )
    if kind == "libero":
        return LiberoEngineConfig(*_locked_fields(value))
    if kind == "robocasa":
        return RoboCasaEngineConfig(*_locked_fields(value))
    if kind == "simpler_env":
        return SimplerEnvEngineConfig(*_locked_fields(value))
    raise WorldContractError(f"unknown engine config variant {kind!r}", "engine_config")


def _locked_fields(value: decode.Document) -> tuple[str, str, str, str, int, int]:
    return (
        decode.text(value, "runtime_version"),
        decode.text(value, "benchmark"),
        decode.text(value, "environment_id"),
        decode.text(value, "controller"),
        decode.integer(value, "render_width"),
        decode.integer(value, "render_height"),
    )


def _config_document(config: EngineConfig) -> dict[str, object]:
    kind = next(name for name, config_type in _KINDS.items() if isinstance(config, config_type))
    values = asdict(config)
    return {"kind": kind, **{name: _wire(value) for name, value in values.items()}}


def simulator_for_engine_config(config: EngineConfig) -> Simulator:
    """Project one qualified exact engine configuration onto its public simulator."""

    if isinstance(
        config,
        (MujocoEngineConfig, MjxEngineConfig, LiberoEngineConfig, RoboCasaEngineConfig),
    ):
        return Simulator.MUJOCO
    if isinstance(config, IsaacLabNewtonEngineConfig):
        return Simulator.ISAAC_LAB_NEWTON
    raise WorldContractError(
        f"{type(config).__name__} is not a qualified public simulator configuration",
        "engine_config",
    )


def _wire(value: object) -> object:
    return value.value if isinstance(value, StrEnum) else value
