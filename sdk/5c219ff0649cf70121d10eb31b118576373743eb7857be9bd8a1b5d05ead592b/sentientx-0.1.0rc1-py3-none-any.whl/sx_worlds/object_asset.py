"""Canonical reusable simulation objects before they are placed in a scene."""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import StrEnum
from typing import cast

from sx_contracts import Sha256Digest, decode
from sx_contracts.assets import AssetFormat, AssetRole
from sx_contracts.identity import CanonicalDocument, content_id
from sx_contracts.wire import HexDigest

from sx_worlds.scene import (
    AssetClosure,
    SceneArticulation,
    articulation_from_dict,
    articulation_to_dict,
    asset_closure_from_dict,
    asset_closure_to_dict,
)

OBJECT_ASSET_SCHEMA = "sx.object-asset/v1"


class ObjectAssetContractError(ValueError):
    """A governed reusable object is malformed or incomplete."""


class ObjectAssetId(HexDigest):
    """Content identity of one reusable object document."""

    error = ObjectAssetContractError
    noun = "object asset id"


class ObjectAssetSource(StrEnum):
    """The producer whose immutable output became the object."""

    TRELLIS_2 = "trellis_2"
    ARTICULATED_AUTHORING = "articulated_authoring"


@dataclass(frozen=True, slots=True)
class ObjectBounds:
    """Axis-aligned physical bounds in the canonical MJCF frame, in metres."""

    center_xyz: tuple[float, float, float]
    half_extents_xyz: tuple[float, float, float]

    def __post_init__(self) -> None:
        if len(self.center_xyz) != 3 or not all(math.isfinite(value) for value in self.center_xyz):
            raise ObjectAssetContractError("object bounds center must have three finite values")
        if len(self.half_extents_xyz) != 3 or not all(
            math.isfinite(value) and value > 0 for value in self.half_extents_xyz
        ):
            raise ObjectAssetContractError("object bounds half extents must be positive and finite")


@dataclass(frozen=True, slots=True)
class ObjectAssetFacts:
    """Physical and semantic facts that generated geometry cannot declare reliably."""

    source: ObjectAssetSource
    source_ref: str
    producer_model: str
    name: str
    description: str
    category: str
    license_id: str
    longest_dimension_m: float
    mass_kg: float
    bounds: ObjectBounds
    tags: tuple[str, ...] = ()
    articulation: tuple[SceneArticulation, ...] = ()
    """One row per movable MJCF joint, ordered by joint name; empty means rigid."""

    def __post_init__(self) -> None:
        for label, value in (
            ("source_ref", self.source_ref),
            ("producer_model", self.producer_model),
            ("name", self.name),
            ("description", self.description),
            ("category", self.category),
            ("license_id", self.license_id),
        ):
            if not value.strip():
                raise ObjectAssetContractError(f"object {label} must not be empty")
        if len(self.name) > 64:
            raise ObjectAssetContractError("object name must contain at most 64 characters")
        if not math.isfinite(self.longest_dimension_m) or self.longest_dimension_m <= 0:
            raise ObjectAssetContractError("object longest dimension must be positive")
        if not math.isfinite(self.mass_kg) or self.mass_kg <= 0:
            raise ObjectAssetContractError("object mass must be positive")
        if any(not tag.strip() for tag in self.tags) or len(set(self.tags)) != len(self.tags):
            raise ObjectAssetContractError("object tags must be non-empty and unique")
        joints = [row.joint for row in self.articulation]
        if joints != sorted(joints) or len(set(joints)) != len(joints):
            raise ObjectAssetContractError(
                "object articulation rows must be unique and ordered by joint name"
            )


@dataclass(frozen=True, slots=True)
class ObjectAssetSettlement:
    """Content-bound report from compiling and stepping the reusable MJCF root.

    The settlement is the executed proof of the object's physical shape: the
    compiled model's geometry and joint counts, not the producer's claims. A
    purely primitive object legitimately has zero meshes; every object needs at
    least one contact-participating geom, or nothing can ever rest on or grasp
    it.
    """

    mjcf_sha256: Sha256Digest
    geoms: int
    collision_geoms: int
    meshes: int
    joints: int
    steps: int
    engine: str = "mujoco"

    def __post_init__(self) -> None:
        try:
            object.__setattr__(self, "mjcf_sha256", Sha256Digest(str(self.mjcf_sha256)))
        except ValueError as error:
            raise ObjectAssetContractError(
                "settlement MJCF digest must be lowercase sha256"
            ) from error
        if self.engine != "mujoco":
            raise ObjectAssetContractError("object settlement engine must be mujoco")
        if self.geoms < 1 or self.steps < 1:
            raise ObjectAssetContractError("object settlement counts must be positive")
        if self.collision_geoms < 1:
            raise ObjectAssetContractError(
                "object settlement needs at least one contact-participating geom"
            )
        if self.meshes < 0 or self.joints < 0:
            raise ObjectAssetContractError("object settlement counts must not be negative")


@dataclass(frozen=True, slots=True)
class ObjectAssetBundle:
    """A governed reusable object with visual, collision, source, and license bytes."""

    assets: AssetClosure
    facts: ObjectAssetFacts
    settlement: ObjectAssetSettlement

    def __post_init__(self) -> None:
        if (
            self.assets.root.format is not AssetFormat.MJCF
            or self.assets.root.role is not AssetRole.DESCRIPTION
        ):
            raise ObjectAssetContractError("object root must be its MJCF description")
        if self.settlement.mjcf_sha256 != self.assets.root.sha256:
            raise ObjectAssetContractError("settlement digest must bind the canonical MJCF root")
        # Geometry proof lives in the settlement (compiled geom/collision counts), not in
        # member shapes: a self-contained MJCF root carries its meshes inline and a
        # primitive-built object carries none, yet both compile, collide, and settle.
        if self.settlement.joints != len(self.facts.articulation):
            raise ObjectAssetContractError(
                "settlement joint count must equal the declared articulation rows"
            )
        members = self.assets.members
        if not any(asset.role is AssetRole.LICENSE for asset in members):
            raise ObjectAssetContractError("object needs a license asset")
        if not any(
            asset.logical_path is not None
            and asset.logical_path.parts
            and asset.logical_path.parts[0] == "source"
            for asset in members
        ):
            raise ObjectAssetContractError("object needs source evidence under source/")

    @property
    def id(self) -> ObjectAssetId:
        return content_id(ObjectAssetId, cast("CanonicalDocument", _object_asset_document(self)))


def object_asset_to_dict(asset: ObjectAssetBundle) -> dict[str, object]:
    """The exact canonical ``sx.object-asset/v1`` wire document."""

    return {
        "schema": OBJECT_ASSET_SCHEMA,
        "object_asset_id": str(asset.id),
        **_object_asset_document(asset),
    }


def object_asset_from_dict(value: object) -> ObjectAssetBundle:
    """Parse an exact object-asset document and verify its quoted identity."""

    try:
        document = _object(value, "object asset")
        _exact(
            document,
            {"schema", "object_asset_id", "assets", "facts", "settlement"},
            "object asset",
        )
        if document["schema"] != OBJECT_ASSET_SCHEMA:
            raise ObjectAssetContractError(
                f"unsupported object asset schema {document['schema']!r}"
            )
        facts = _object(document["facts"], "object asset facts")
        _exact(
            facts,
            {
                "source",
                "source_ref",
                "producer_model",
                "name",
                "description",
                "category",
                "license_id",
                "longest_dimension_m",
                "mass_kg",
                "bounds",
                "tags",
                "articulation",
            },
            "object asset facts",
        )
        bounds = _object(facts["bounds"], "object asset bounds")
        _exact(bounds, {"center_xyz", "half_extents_xyz"}, "object asset bounds")
        settlement = _object(document["settlement"], "object asset settlement")
        _exact(
            settlement,
            {"engine", "mjcf_sha256", "geoms", "collision_geoms", "meshes", "joints", "steps"},
            "object asset settlement",
        )
        asset = ObjectAssetBundle(
            assets=asset_closure_from_dict(document["assets"], where="object_asset.assets"),
            facts=ObjectAssetFacts(
                source=ObjectAssetSource(decode.text(facts, "source")),
                source_ref=decode.text(facts, "source_ref"),
                producer_model=decode.text(facts, "producer_model"),
                name=decode.text(facts, "name"),
                description=decode.text(facts, "description"),
                category=decode.text(facts, "category"),
                license_id=decode.text(facts, "license_id"),
                longest_dimension_m=decode.number(facts, "longest_dimension_m"),
                mass_kg=decode.number(facts, "mass_kg"),
                bounds=ObjectBounds(
                    center_xyz=cast(
                        "tuple[float, float, float]", _fixed_numbers(bounds, "center_xyz")
                    ),
                    half_extents_xyz=cast(
                        "tuple[float, float, float]", _fixed_numbers(bounds, "half_extents_xyz")
                    ),
                ),
                tags=decode.texts(facts, "tags"),
                articulation=tuple(
                    articulation_from_dict(item, where="object asset articulation[]")
                    for item in decode.sequence(facts, "articulation")
                ),
            ),
            settlement=ObjectAssetSettlement(
                engine=decode.text(settlement, "engine"),
                mjcf_sha256=Sha256Digest(decode.text(settlement, "mjcf_sha256")),
                geoms=_positive_int(settlement, "geoms"),
                collision_geoms=_positive_int(settlement, "collision_geoms"),
                meshes=_count(settlement, "meshes"),
                joints=_count(settlement, "joints"),
                steps=_positive_int(settlement, "steps"),
            ),
        )
        if document["object_asset_id"] != str(asset.id):
            raise ObjectAssetContractError(
                "object_asset_id disagrees with the canonical object asset document"
            )
        return asset
    except ObjectAssetContractError:
        raise
    except (KeyError, TypeError, ValueError) as error:
        raise ObjectAssetContractError(f"malformed object asset document: {error}") from error


def _object_asset_document(asset: ObjectAssetBundle) -> dict[str, object]:
    facts = asset.facts
    return {
        "assets": asset_closure_to_dict(asset.assets),
        "facts": {
            "source": facts.source.value,
            "source_ref": facts.source_ref,
            "producer_model": facts.producer_model,
            "name": facts.name,
            "description": facts.description,
            "category": facts.category,
            "license_id": facts.license_id,
            "longest_dimension_m": facts.longest_dimension_m,
            "mass_kg": facts.mass_kg,
            "bounds": {
                "center_xyz": list(facts.bounds.center_xyz),
                "half_extents_xyz": list(facts.bounds.half_extents_xyz),
            },
            "tags": list(facts.tags),
            "articulation": [articulation_to_dict(row) for row in facts.articulation],
        },
        "settlement": {
            "engine": asset.settlement.engine,
            "mjcf_sha256": asset.settlement.mjcf_sha256,
            "geoms": asset.settlement.geoms,
            "collision_geoms": asset.settlement.collision_geoms,
            "meshes": asset.settlement.meshes,
            "joints": asset.settlement.joints,
            "steps": asset.settlement.steps,
        },
    }


def _object(value: object, where: str) -> dict[str, object]:
    if not isinstance(value, dict):
        raise ObjectAssetContractError(f"{where} must be an object with text keys")
    raw = cast("dict[object, object]", value)
    if any(not isinstance(key, str) for key in raw):
        raise ObjectAssetContractError(f"{where} must be an object with text keys")
    return {cast("str", key): item for key, item in raw.items()}


def _exact(document: dict[str, object], fields: set[str], where: str) -> None:
    actual = set(document)
    if actual != fields:
        raise ObjectAssetContractError(
            f"{where} fields differ: missing={sorted(fields - actual)}, "
            f"unexpected={sorted(actual - fields)}"
        )


def _fixed_numbers(document: dict[str, object], key: str) -> tuple[float, ...]:
    value = document[key]
    if not isinstance(value, list):
        raise ObjectAssetContractError(f"object asset {key} must have three numbers")
    items = cast("list[object]", value)
    if len(items) != 3:
        raise ObjectAssetContractError(f"object asset {key} must have three numbers")
    numbers: list[float] = []
    for item in items:
        if isinstance(item, bool) or not isinstance(item, int | float):
            raise ObjectAssetContractError(f"object asset {key} must contain numbers")
        numbers.append(float(item))
    values = tuple(numbers)
    if not all(math.isfinite(item) for item in values):
        raise ObjectAssetContractError(f"object asset {key} must contain finite numbers")
    return values


def _positive_int(document: dict[str, object], key: str) -> int:
    value = document[key]
    if not isinstance(value, int) or isinstance(value, bool) or value < 1:
        raise ObjectAssetContractError(f"object asset settlement {key} must be positive")
    return value


def _count(document: dict[str, object], key: str) -> int:
    value = document[key]
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ObjectAssetContractError(f"object asset settlement {key} must not be negative")
    return value
