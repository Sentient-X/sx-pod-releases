"""Public simulation-service capability vocabulary."""

from dataclasses import dataclass
from enum import StrEnum

from sx_worlds.engine_config import Simulator


class SimulationJobFamily(StrEnum):
    SESSION = "session"
    EVALUATION = "evaluation"
    GENERATION = "generation"


class SimulationResourceBand(StrEnum):
    CPU = "cpu"
    GPU = "gpu"


@dataclass(frozen=True, slots=True)
class SimulatorCapability:
    """One qualified simulator/job/resource combination, without provider inventory."""

    simulator: Simulator
    job: SimulationJobFamily
    resource_band: SimulationResourceBand
    available: bool
    reason: str | None = None

    def __post_init__(self) -> None:
        if self.available == (self.reason is not None):
            raise ValueError("available simulation capability has no refusal reason")
        if self.reason is not None and not self.reason.strip():
            raise ValueError("unavailable simulation capability needs a refusal reason")
