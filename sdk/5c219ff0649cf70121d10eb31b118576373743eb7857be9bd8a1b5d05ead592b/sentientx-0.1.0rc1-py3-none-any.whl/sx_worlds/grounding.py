"""Supports and groundings — how bodies, objects, and regions meet a world.

The one abstraction under embodiment↔environment integration
(``docs/plans/archive/embodiment-grounding-2026-08.md``): a world exposes a small set of affordance
frames — **supports** (a tabletop, the floor, a shelf) — and everything in a scene
grounds onto them. A benchtop arm bolts *onto* the table; a mobile base stands on the
floor *facing* the table; a spawn region is a patch *on* the table. Robot placement is
not a special case: it is one more grounding, chosen by the placement solver in
sim-envs over these records. Declaring positions relative to supports (instead of
world-absolute constants) is what lets one task re-ground portably onto a digital
cousin whose work surface sits at a different height.

Records only, pure by budget (numpy + the sx-geometry ``Pose``): solving, IK
verification, and MJCF composition live with the engines.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import StrEnum

import numpy as np
from numpy.typing import NDArray
from sx_geometry import Pose

from sx_worlds.world import WorldContractError


class SupportKind(StrEnum):
    """What sort of affordance a support frame is — one side of the stance table."""

    TABLETOP = "tabletop"
    FLOOR = "floor"
    SHELF = "shelf"
    RAIL = "rail"
    WALL = "wall"


@dataclass(frozen=True, slots=True)
class PlanarPose:
    """A pose *on* a support: xy in the support frame plus yaw about its up-normal."""

    x: float
    y: float
    yaw: float = 0.0


@dataclass(frozen=True, slots=True)
class PlanarRect:
    """An axis-aligned rectangle in a support's frame, centred at ``(cx, cy)``."""

    cx: float
    cy: float
    half_x: float
    half_y: float

    def __post_init__(self) -> None:
        if self.half_x <= 0.0 or self.half_y <= 0.0:
            raise WorldContractError("a planar rect needs positive half extents", "grounding")

    def contains(self, x: float, y: float, *, margin: float = 0.0) -> bool:
        """Whether ``(x, y)`` lies inside this rect, shrunk by ``margin`` on every side."""
        return abs(x - self.cx) <= self.half_x - margin and abs(y - self.cy) <= self.half_y - margin

    def contains_rect(self, other: PlanarRect, *, margin: float = 0.0) -> bool:
        """Whether ``other`` lies entirely inside this rect (both in the same frame)."""
        return (
            abs(other.cx - self.cx) + other.half_x <= self.half_x - margin
            and abs(other.cy - self.cy) + other.half_y <= self.half_y - margin
        )


@dataclass(frozen=True, slots=True)
class Support:
    """A named affordance frame of a world: pose, usable extent, and kind.

    ``pose`` places the support frame in the world with **+z as the up-normal**;
    ``extent`` is the usable area in that frame. Built-in world shells declare their
    supports; real2sim cousins will detect them (with confidence) from reconstruction.
    """

    name: str
    kind: SupportKind
    pose: Pose
    extent: PlanarRect

    @property
    def surface_z(self) -> float:
        """The support surface height in world z (the up-normal is the support frame's +z)."""
        return float(self.pose.position[2])

    def world_point(self, x: float, y: float, z: float = 0.0) -> NDArray[np.float64]:
        """A support-frame point expressed in world coordinates."""
        return self.pose.transform_point(np.array([x, y, z], dtype=np.float64))

    def rest_position(self, x: float, y: float, half_height: float) -> NDArray[np.float64]:
        """World position of an object of the given half-height resting on the support.

        The object centre sits ``half_height`` above the surface along the support's
        up-normal — so an object's height is a fact of *which support it rests on*, not a
        world-absolute constant. A cousin whose table sits higher grounds the same object
        higher, with no per-scene arithmetic.
        """
        return self.world_point(x, y, half_height)

    def local_point(self, world: NDArray[np.float64]) -> NDArray[np.float64]:
        """A world point expressed in this support's frame (inverse of world_point)."""
        return self.pose.inverse().transform_point(np.asarray(world, dtype=np.float64))

    def world_pose(self, planar: PlanarPose) -> Pose:
        """A planar pose on this support as a full world :class:`Pose` (yaw about up)."""
        half = 0.5 * planar.yaw
        yaw_quat = np.array([math.cos(half), 0.0, 0.0, math.sin(half)])
        local = Pose(np.array([planar.x, planar.y, 0.0], dtype=np.float64), yaw_quat)
        return self.pose.compose(local)


@dataclass(frozen=True, slots=True)
class RegionOn:
    """A region grounded on a named support — the portable form of every task region.

    The name resolves within one world's support namespace; grounding onto a world that
    lacks the support (or has it at a different kind) is a typed refusal at resolution,
    never a silent absolute-coordinate fallback.
    """

    support: str
    rect: PlanarRect


def resolve_region(region: RegionOn, supports: tuple[Support, ...]) -> Support:
    """The support a region grounds on, refusing typed when the world lacks it."""
    for support in supports:
        if support.name == region.support:
            if not support.extent.contains_rect(region.rect):
                raise WorldContractError(
                    f"region on {region.support!r} leaves the support extent", "grounding"
                )
            return support
    known = ", ".join(sorted(s.name for s in supports)) or "none"
    raise WorldContractError(
        f"world has no support {region.support!r} (declared: {known})", "grounding"
    )
