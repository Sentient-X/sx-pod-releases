"""One canonical demo World, and the evidence values built over it.

Every repo that consumes Worlds evidence needs *a* complete `World` — the sim-envs,
catalog, Fleet, Autonomy and client suites to have any `WorldRun` or `WorldEvaluation`
at all. A `World` is a large value with real invariants
(the interface must validate against the body, the reset strata must cover what the suite
declares, the goal bindings must anchor every predicate participant), so six independently
authored "minimal" ones would be six chances to encode a world that could not actually run
— and they would drift apart the first time an invariant tightened.

So the demo world lives here, beside the type whose laws it must satisfy, and every
consumer parameterises it rather than rebuilding it. The task contract inside it is the
shared `sx_contracts.samples` demo contract — the same one the catalog dev seed publishes
— while the Worlds-only values (scene, resets, suite, run evidence) are authored here.
"""

from __future__ import annotations

from dataclasses import replace

from sx_actions import joint_position
from sx_contracts import (
    Accelerator,
    ApplicationName,
    ApplicationWorkload,
    ArtifactId,
    BoundImage,
    CatalogSegmentRef,
    ContentRef,
    CpuArchitecture,
    DeviceAccess,
    DeviceGrant,
    ImageDigest,
    ImageName,
    InterfaceKind,
    InterfaceName,
    LogicalDevice,
    MetricSet,
    NativeEvaluationCriteria,
    PowerMode,
    ProvidedInterface,
    PythonRuntime,
    ResourceBudget,
    RobotApplication,
    RuntimeAbi,
    SecurityProfile,
    Sha256Digest,
    StandardTaskRole,
    StationTarget,
    TaskContract,
    TaskFamilyRef,
    TaskRoleAssignments,
    TaskRoleBinding,
    TaskRoleId,
    TaskVerdict,
    Terminated,
    TerminationReason,
    WorkloadName,
    WorkloadPlacement,
)
from sx_contracts import samples as contract_samples
from sx_contracts.assets import AssetFormat, AssetRef, AssetRole
from sx_contracts.decisions import ReplanInterval
from sx_embodiments import embodiments

from sx_worlds.engine_config import (
    MujocoEngineConfig,
    MujocoIntegrator,
    MujocoSolver,
    RenderBackend,
)
from sx_worlds.evaluation import (
    ApplicationControlSource,
    BenchmarkId,
    BenchmarkKind,
    BenchmarkRef,
    BenchmarkTaskId,
    DecisionPlacement,
    DeclaredStrata,
    EpisodeExecutionSummary,
    EvaluationSubject,
    ExecutionVenue,
    RunArtifact,
    RunArtifactKind,
    SelectedTasks,
    StratumId,
    SuiteEntry,
    SuiteManifest,
    TaskContractSource,
    WorldCase,
    WorldEvaluation,
    WorldRun,
)
from sx_worlds.scene import (
    AssetClosure,
    BodyFrameTarget,
    CoordinateControlBinding,
    FrameControlBinding,
    JointActuatorBinding,
    Scene,
    SceneControlBinding,
    SceneFrame,
    SceneFrameKind,
    SceneObject,
    SiteFrameTarget,
    WorldFrameTarget,
    canonical_scene_asset,
)
from sx_worlds.world import (
    AxisInterval,
    GoalBinding,
    NoAdditionalSafety,
    NominalReset,
    ObjectAnchor,
    PlacementDistribution,
    PlanarDisplacement,
    ResetDistribution,
    World,
)

SAMPLE_EMBODIMENT = embodiments["piper"]
SAMPLE_MJCF = b'<mujoco model="world"/>'
NOMINAL_STRATUM = StratumId("nominal")
DISPLACED_STRATUM = StratumId("displaced")


def sample_application() -> RobotApplication:
    """One exact rule-based application for examples, dev seeds, and contract tests."""

    return RobotApplication(
        ApplicationName("worlds-sample-controller"),
        StationTarget(
            CpuArchitecture.X86_64,
            Accelerator.RTX_5090,
            32_768,
            RuntimeAbi("cuda-13.0+driver-580"),
            PowerMode("qualified-default"),
        ),
        (
            ApplicationWorkload(
                WorkloadName("controller"),
                BoundImage(ImageName("rule-controller"), ImageDigest("sha256:" + "9" * 64)),
                WorkloadPlacement.STATION,
                SecurityProfile.ROBOT_IO_CONFORMER,
                ResourceBudget(1_000, 1_024, 64),
                provides=(
                    ProvidedInterface(
                        InterfaceName("control"),
                        InterfaceKind.ROBOT_CONTROL,
                        "sx-serving/v10",
                    ),
                ),
                devices=(DeviceGrant(LogicalDevice("can:sample-arm"), DeviceAccess.CONTROL),),
            ),
        ),
        (TaskFamilyRef("world-samples"),),
    )


def sample_task(*, evaluation: NativeEvaluationCriteria | None = None) -> TaskContract:
    """The demo pick-and-place contract, gated so it can be promoted."""
    return contract_samples.sample_task(evaluation=evaluation)


def sample_scene() -> Scene:
    """A one-asset tabletop scene whose control binding covers the whole body."""
    root = canonical_scene_asset(
        AssetRef.from_bytes(
            SAMPLE_MJCF,
            uri="memory://world.xml",
            format=AssetFormat.MJCF,
            role=AssetRole.DESCRIPTION,
            media_type="application/xml",
        ),
        "world.xml",
    )
    coordinates = tuple(
        CoordinateControlBinding(
            coordinate.instance,
            coordinate.axis.name,
            (JointActuatorBinding(f"sim_{coordinate.axis.name}", f"act_{coordinate.axis.name}"),),
        )
        for coordinate in SAMPLE_EMBODIMENT.state.coordinates
    )
    return Scene(
        assets=AssetClosure(root),
        embodiment=SAMPLE_EMBODIMENT,
        objects=(
            SceneObject("box", "box", "container", "box_free", graspable=True),
            SceneObject("target", "target", "region"),
        ),
        frames=(
            SceneFrame("world", SceneFrameKind.WORLD),
            SceneFrame(
                "tool",
                SceneFrameKind.END_EFFECTOR,
                SAMPLE_EMBODIMENT.components[0].component_id,
            ),
            SceneFrame("target", SceneFrameKind.OBJECT),
        ),
        cameras=(),
        tags=("tabletop",),
        control=SceneControlBinding(
            coordinates,
            (
                FrameControlBinding("world", WorldFrameTarget()),
                FrameControlBinding("tool", SiteFrameTarget("tool_site")),
                FrameControlBinding("target", BodyFrameTarget("target")),
            ),
        ),
    )


def sample_world(*, threshold: float = 0.5, trials: int = 2) -> World:
    """One executable World, gated at ``threshold`` over ``trials`` trials per task."""
    return World(
        task=sample_task(evaluation=NativeEvaluationCriteria(threshold, trials)),
        scene=sample_scene(),
        action_interface=joint_position(SAMPLE_EMBODIMENT),
        role_assignments=TaskRoleAssignments(
            (
                TaskRoleBinding(
                    TaskRoleId(StandardTaskRole.MANIPULATION_PRIMARY.value),
                    SAMPLE_EMBODIMENT.components[0].component_id,
                ),
                TaskRoleBinding(
                    TaskRoleId(StandardTaskRole.MANIPULATION_SECONDARY.value),
                    SAMPLE_EMBODIMENT.components[1].component_id,
                ),
            )
        ),
        goal_bindings=(
            GoalBinding("box", ObjectAnchor("box")),
            GoalBinding("target", ObjectAnchor("target")),
        ),
        reset_distribution=ResetDistribution(
            (
                PlacementDistribution(
                    "box",
                    AxisInterval(0.3, 0.5),
                    AxisInterval(-0.1, 0.1),
                    AxisInterval(0.02, 0.02),
                    (1.0, 0.0, 0.0, 0.0),
                ),
            ),
            (NominalReset(), PlanarDisplacement(str(DISPLACED_STRATUM), 0.04)),
        ),
        safety=NoAdditionalSafety(),
        max_steps=200,
    )


def sample_suite(*, trials: int = 2, action_horizon: int = 7) -> SuiteManifest:
    """The native suite the demo world is gated by, covering both strata."""
    return SuiteManifest(
        "native-v1",
        (
            SuiteEntry(
                BenchmarkRef(
                    BenchmarkId("worlds-native"),
                    BenchmarkKind.NATIVE_WORLD,
                    "sim-envs@1",
                    Sha256Digest("a" * 64),
                ),
                trials,
                action_horizon,
                SelectedTasks((BenchmarkTaskId("pick-place"),)),
                DeclaredStrata((NOMINAL_STRATUM, DISPLACED_STRATUM)),
            ),
        ),
    )


def sample_case(world: World, index: int, stratum: StratumId, *, accepted: bool) -> WorldCase:
    """One measured trial, ended by the verdict its acceptance implies."""
    end = Terminated(
        TerminationReason.SUCCESS if accepted else TerminationReason.FAILURE,
        TaskVerdict.SATISFIED if accepted else TaskVerdict.NOT_SATISFIED,
    )
    return WorldCase(
        index,
        100 + index,
        stratum,
        CatalogSegmentRef(
            "worlds-evaluation", f"episode-{index}", Sha256Digest(f"{index + 1:064x}")
        ),
        EpisodeExecutionSummary(f"episode-{index}", world.id, 20 + index, 1.0, end),
        MetricSet.from_pairs((("clearance_m", 0.01 + index * 0.001),)),
    )


def sample_world_run(
    subject: EvaluationSubject,
    *,
    accepted: bool = True,
    threshold: float = 0.5,
    trials: int = 2,
) -> WorldRun:
    """A complete run of the demo world by ``subject``.

    ``accepted`` grades every trial the same way, which is what a caller wanting "evidence
    that passes" (or "evidence that does not") actually means; a caller wanting a mixed run
    builds its cases with :func:`sample_case`.
    """
    world = sample_world(threshold=threshold, trials=trials)
    cases = tuple(
        sample_case(world, index, stratum, accepted=accepted)
        for index, stratum in enumerate([NOMINAL_STRATUM] * trials + [DISPLACED_STRATUM] * trials)
    )
    return WorldRun(
        world,
        sample_suite(trials=trials),
        0,
        subject,
        cases,
        PythonRuntime("sim-envs", "3.12", Sha256Digest("b" * 64)),
        sample_engine_config(),
        ExecutionVenue("worker-1", "linux", "x86_64", None, None, None, None),
        (
            ApplicationControlSource()
            if isinstance(subject, RobotApplication)
            else TaskContractSource(ReplanInterval(1, 1000), 0, DecisionPlacement.OWNER_PROCESS)
        ),
        (
            RunArtifact(
                RunArtifactKind.RERUN_RECORDING,
                ContentRef(ArtifactId("rrd:run"), Sha256Digest("c" * 64)),
                "application/vnd.rerun.rrd",
            ),
        ),
    )


def sample_engine_config() -> MujocoEngineConfig:
    """The MuJoCo configuration the demo run was executed under."""
    return MujocoEngineConfig(
        "3.3.6",
        0.002,
        10,
        MujocoIntegrator.IMPLICIT_FAST,
        MujocoSolver.NEWTON,
        100,
        50,
        1e-8,
        RenderBackend.EGL,
        640,
        480,
        4,
    )


def sample_evaluation(
    subject: EvaluationSubject,
    *,
    accepted: bool = True,
    threshold: float = 0.5,
    trials: int = 2,
) -> WorldEvaluation:
    """The judgment over :func:`sample_world_run` — passing when ``accepted``."""
    return WorldEvaluation(
        sample_world_run(subject, accepted=accepted, threshold=threshold, trials=trials)
    )


def with_subject(run: WorldRun, subject: EvaluationSubject) -> WorldRun:
    """The same measured run, re-subjected — the paired-arm construction."""
    return replace(run, subject=subject)
