"""Hosted CLI authentication and the operating system credential boundary."""

from __future__ import annotations

import os
import socket
import time
import webbrowser
from collections.abc import Callable
from dataclasses import dataclass
from enum import StrEnum
from typing import Protocol
from urllib.parse import quote

import httpx
import keyring
from keyring.errors import KeyringError
from pydantic import BaseModel, ConfigDict, Field, ValidationError
from sx_service.registry import DoorId

from sx._transport import ConnectionProfile, Endpoints

_SERVICE = "sentientx CLI"


class AuthPath(StrEnum):
    """Non-project auth lifecycle paths this bootstrap speaks natively.

    The device grant, its token exchange, the credential introspection and the
    browser session are the SDK's own way in — they exist before a project or a
    generated client does, so they stay native HTTP and name their paths here.
    """

    DEVICE_AUTHORIZATIONS = "/api/auth/device/authorizations"
    DEVICE_TOKEN = "/api/auth/device/token"
    CURRENT_CREDENTIAL = "/api/auth/credentials/current"
    SESSION = "/api/auth/session"
    ACTIVATE = "/activate"


class CredentialError(RuntimeError):
    """A CLI credential could not be acquired, stored, or revoked safely."""


class CredentialStore(Protocol):
    def get(self, profile: ConnectionProfile) -> str | None: ...

    def set(self, profile: ConnectionProfile, api_key: str) -> None: ...

    def delete(self, profile: ConnectionProfile) -> bool: ...


class SystemCredentialStore:
    """Persist opaque keys in Keychain, Secret Service, or Credential Locker."""

    def get(self, profile: ConnectionProfile) -> str | None:
        try:
            return keyring.get_password(_SERVICE, profile.value)
        except KeyringError as error:
            raise CredentialError(
                f"operating-system credential store is unavailable: {error}"
            ) from error

    def set(self, profile: ConnectionProfile, api_key: str) -> None:
        try:
            keyring.set_password(_SERVICE, profile.value, api_key)
        except KeyringError as error:
            raise CredentialError(
                f"operating-system credential store refused the key: {error}"
            ) from error

    def delete(self, profile: ConnectionProfile) -> bool:
        try:
            if keyring.get_password(_SERVICE, profile.value) is None:
                return False
            keyring.delete_password(_SERVICE, profile.value)
            return True
        except KeyringError as error:
            raise CredentialError(
                f"operating-system credential store refused logout: {error}"
            ) from error


def api_key_for(
    profile: ConnectionProfile,
    explicit: str | None = None,
    *,
    store: CredentialStore | None = None,
) -> str | None:
    """Resolve one caller credential by explicit, process, then durable precedence."""

    if explicit is not None:
        return explicit
    environment_key = os.environ.get("SX_API_KEY")
    if environment_key:
        return environment_key
    return (store or SystemCredentialStore()).get(profile)


class _Model(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class _DeviceAuthorization(_Model):
    device_code: str
    user_code: str
    verification_uri: str
    verification_uri_complete: str
    expires_in: int = Field(gt=0, le=3600)
    interval: int = Field(ge=1, le=60)


class _DeviceToken(_Model):
    token_type: str
    access_token: str
    credential_id: str


class _SessionPrincipal(BaseModel):
    subject: str


class _Session(BaseModel):
    principal: _SessionPrincipal


@dataclass(frozen=True, slots=True)
class DeviceLogin:
    subject: str
    credential_id: str


def login(
    profile: ConnectionProfile,
    *,
    store: CredentialStore | None = None,
    transport: httpx.BaseTransport | None = None,
    open_browser: Callable[[str], object] = webbrowser.open,
    wait: Callable[[float], object] = time.sleep,
    on_authorization: Callable[[str, str], None] | None = None,
    launch_browser: bool = True,
) -> DeviceLogin:
    """Authorize this CLI in a browser and retain its one-time returned key."""

    selected_store = store or SystemCredentialStore()
    auth_url = Endpoints.resolve(profile).for_door(DoorId.AUTH).rstrip("/")
    try:
        with httpx.Client(timeout=30.0, transport=transport) as client:
            begun_response = client.post(
                f"{auth_url}{AuthPath.DEVICE_AUTHORIZATIONS}",
                json={"client_name": f"sx CLI on {socket.gethostname()}"},
            )
            if begun_response.is_error:
                raise CredentialError(
                    f"auth refused device login with HTTP {begun_response.status_code}"
                )
            begun = _DeviceAuthorization.model_validate(begun_response.json())
            # Derive the complete URI from the explicitly selected endpoint. This
            # preserves a real development profile without letting a server-supplied
            # host redirect the local browser.
            verification_uri = f"{auth_url}{AuthPath.ACTIVATE}?user_code={quote(begun.user_code)}"
            if on_authorization is not None:
                on_authorization(verification_uri, begun.user_code)
            if launch_browser:
                open_browser(verification_uri)
            deadline = time.monotonic() + begun.expires_in
            interval = float(begun.interval)
            while time.monotonic() < deadline:
                wait(interval)
                response = client.post(
                    f"{auth_url}{AuthPath.DEVICE_TOKEN}",
                    json={"device_code": begun.device_code},
                )
                if response.status_code == 202:
                    continue
                if response.status_code == 429:
                    interval = min(interval + 1.0, 60.0)
                    continue
                if response.status_code == 410:
                    raise CredentialError("device authorization expired; run `sx auth login` again")
                if response.is_error:
                    raise CredentialError(
                        f"auth refused device login with HTTP {response.status_code}"
                    )
                token = _DeviceToken.model_validate(response.json())
                if token.token_type.lower() != "bearer" or not token.access_token:
                    raise CredentialError("auth returned an invalid device credential")
                session = _session(client, auth_url, token.access_token)
                subject = session.principal.subject
                if not subject:
                    raise CredentialError("auth returned a credential without a user identity")
                selected_store.set(profile, token.access_token)
                return DeviceLogin(subject=subject, credential_id=token.credential_id)
    except (httpx.HTTPError, ValidationError, ValueError) as error:
        raise CredentialError(f"device login failed: {error}") from error
    raise CredentialError("device authorization expired; run `sx auth login` again")


def status(
    profile: ConnectionProfile,
    *,
    store: CredentialStore | None = None,
    transport: httpx.BaseTransport | None = None,
) -> str:
    api_key = api_key_for(profile, store=store)
    if api_key is None:
        raise CredentialError("not signed in; run `sx auth login`")
    auth_url = Endpoints.resolve(profile).for_door(DoorId.AUTH).rstrip("/")
    try:
        with httpx.Client(timeout=30.0, transport=transport) as client:
            session = _session(client, auth_url, api_key)
    except httpx.HTTPError as error:
        raise CredentialError(f"auth status failed: {error}") from error
    subject = session.principal.subject
    if not subject:
        raise CredentialError("auth returned a credential without a user identity")
    return subject


def logout(
    profile: ConnectionProfile,
    *,
    store: CredentialStore | None = None,
    transport: httpx.BaseTransport | None = None,
) -> bool:
    selected_store = store or SystemCredentialStore()
    # Logout owns only the durable interactive credential. An ambient SX_API_KEY belongs
    # to the invoking automation and must never cause `sx auth logout` to revoke a different
    # credential or delete an unrelated stored login.
    api_key = selected_store.get(profile)
    if api_key is None:
        return False
    auth_url = Endpoints.resolve(profile).for_door(DoorId.AUTH).rstrip("/")
    try:
        with httpx.Client(timeout=30.0, transport=transport) as client:
            response = client.delete(
                f"{auth_url}{AuthPath.CURRENT_CREDENTIAL}",
                headers={"Authorization": f"Bearer {api_key}"},
            )
            if response.status_code not in {204, 401}:
                raise CredentialError(
                    f"auth refused logout with HTTP {response.status_code}; credential retained"
                )
    except httpx.HTTPError as error:
        raise CredentialError(f"logout failed; credential retained: {error}") from error
    return selected_store.delete(profile)


def _session(client: httpx.Client, auth_url: str, api_key: str) -> _Session:
    response = client.get(
        f"{auth_url}{AuthPath.SESSION}",
        headers={"Authorization": f"Bearer {api_key}"},
    )
    if response.status_code == 401:
        raise CredentialError("stored credential is no longer valid; run `sx auth login`")
    if response.is_error:
        raise CredentialError(f"auth status failed with HTTP {response.status_code}")
    try:
        return _Session.model_validate(response.json())
    except ValidationError as error:
        raise CredentialError("auth returned an invalid session document") from error
