"""Install descriptor-native tools; semantic adapters register before this projection."""

from collections.abc import Awaitable, Callable
from functools import wraps
from typing import Any, ParamSpec, TypeVar

from google.protobuf.descriptor_pb2 import MethodOptions
from google.protobuf.message import Message
from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.tools import Tool
from mcp.server.fastmcp.utilities.func_metadata import ArgModelBase, FuncMetadata
from mcp.types import ToolAnnotations
from pydantic import ConfigDict, JsonValue, RootModel, create_model

from sx._descriptor_surface import PUBLIC_RPC_OPERATIONS, RpcOperation
from sx._encode import proto_document
from sx._projected_rpc import rpc_method
from sx._protobuf_schema import message_schema
from sx._rpc import validated


class _Arguments(ArgModelBase):
    model_config = ConfigDict(extra="forbid")


type Invoke = Callable[[RpcOperation, dict[str, Any]], Awaitable[dict[str, JsonValue]]]


def register_projections(server: FastMCP, invoke: Invoke) -> None:
    """Each unadapted common RPC gets its actual closed input and output contract."""
    manager = server._tool_manager  # pyright: ignore[reportPrivateUsage]
    for operation in PUBLIC_RPC_OPERATIONS.values():
        if operation.projection != "common" or manager.get_tool(operation.name) is not None:
            continue
        method = rpc_method(operation)
        fields: dict[str, Any] = {
            field.name: (JsonValue, None) for field in method.input_type.fields
        }
        arguments = create_model(
            method.input_type.name,
            __base__=_Arguments,
            **fields,
        )

        # A factory captures a descriptor, never a second per-method dispatch table.
        def bind(selected: RpcOperation) -> Callable[..., Awaitable[dict[str, JsonValue]]]:
            async def call(**values: Any) -> dict[str, JsonValue]:
                return await invoke(selected, values)

            return call

        manager._tools[operation.name] = Tool(  # pyright: ignore[reportPrivateUsage]
            name=operation.name,
            title=None,
            description=f"{operation.name}: {method.input_type.name} → {method.output_type.name}.",
            fn=bind(operation),
            is_async=True,
            context_kwarg="ctx",
            parameters=message_schema(method.input_type),
            fn_metadata=FuncMetadata(
                arg_model=arguments,
                output_schema=message_schema(method.output_type),
                output_model=RootModel[dict[str, JsonValue]],
            ),
            annotations=ToolAnnotations(
                readOnlyHint=method.GetOptions().idempotency_level == MethodOptions.NO_SIDE_EFFECTS
            ),
        )


_P = ParamSpec("_P")
_Response = TypeVar("_Response", bound=Message)


def protobuf_tool(
    server: FastMCP, operation: RpcOperation
) -> Callable[[Callable[_P, Awaitable[_Response]]], Callable[_P, Awaitable[_Response]]]:
    """Preserve a semantic input adapter and derive its generated response schema."""

    def register(
        function: Callable[_P, Awaitable[_Response]],
    ) -> Callable[_P, Awaitable[_Response]]:
        @wraps(function)
        async def project(*args: _P.args, **kwargs: _P.kwargs) -> dict[str, object]:
            result = await function(*args, **kwargs)
            return proto_document(validated(result, label=f"{operation.name} response"))

        server.add_tool(project, name=operation.name, structured_output=False)
        tool = server._tool_manager.get_tool(operation.name)  # pyright: ignore[reportPrivateUsage]
        if tool is None:
            raise RuntimeError(f"missing projected tool {operation.name}")
        tool.fn_metadata.output_schema = message_schema(rpc_method(operation).output_type)
        tool.fn_metadata.output_model = RootModel[dict[str, JsonValue]]
        return function

    return register
