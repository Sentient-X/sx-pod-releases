"""Descriptor-derived public RPC surface; no HTTP-shaped compatibility rows.

A method is public exactly when its `method_policy` declares a `surface`. A
policy that declares only a `rate_class` prices an internal method's work and
projects nothing here.
"""

from dataclasses import dataclass
from typing import Any, cast

from google.protobuf.descriptor import FieldDescriptor, ServiceDescriptor
from google.protobuf.descriptor_pb2 import MethodOptions
from sentientx.sx.api.v1 import options_pb2
from sentientx.sx.autonomy.application.v1 import application_pb2
from sentientx.sx.autonomy.ask.v1 import ask_pb2
from sentientx.sx.autonomy.improve.v1 import improve_pb2
from sentientx.sx.autonomy.train.v1 import training_pb2
from sentientx.sx.common.v1 import common_pb2
from sentientx.sx.experience.catalog.v1 import (
    annotations_pb2,
    applications_pb2,
    catalog_pb2,
    evidence_pb2,
    membership_pb2,
    pipelines_pb2,
)
from sentientx.sx.experience.catalog.v1 import operations_pb2 as catalog_operations_pb2
from sentientx.sx.experience.factory.v1 import factory_pb2
from sentientx.sx.experience.taskpedia.v1 import taskpedia_pb2
from sentientx.sx.fleet.controlplane.v1 import controlplane_pb2 as fleet_pb2
from sentientx.sx.platform.auth.v1 import organization_pb2
from sentientx.sx.worlds.controlplane.v1 import controlplane_pb2 as worlds_pb2
from sx_contracts import OperationKind, PlatformPillar
from sx_service.registry import DoorId as Door


@dataclass(frozen=True, slots=True)
class OwnerService:
    door: Door
    # Absent for a door that is not a pillar. `sx_authd` is the platform's own
    # identity control plane, so its public verbs carry no pillar — and pillar is
    # only ever read beside an operation kind, which those verbs do not have.
    pillar: PlatformPillar | None
    descriptor: ServiceDescriptor


@dataclass(frozen=True, slots=True)
class RpcOperation:
    name: str
    door: Door
    service: str
    method: str
    projection: str
    rate_class: str
    pillar: PlatformPillar | None
    kind: OperationKind | None
    results: tuple[str, ...]

    @property
    def path(self) -> str:
        return f"/{self.service}/{self.method}"


def public_rpc_operations(owners: tuple[OwnerService, ...]) -> tuple[RpcOperation, ...]:
    """Read public methods from generated descriptors and reject incomplete owners."""

    found: list[RpcOperation] = []
    names: set[str] = set()
    for owner in owners:
        for method in owner.descriptor.methods:
            options = method.GetOptions()
            if not options.HasExtension(cast(Any, options_pb2.method_policy)):
                continue
            policy = _method_policy(options)
            if not policy.surface:
                # An internal method that declares only the rate class its work
                # costs. Declaring a surface is what mints a facade verb, so a
                # meter alone never reaches the SDK, CLI, MCP, or Console — but
                # only a meter alone: half a public projection is the same typed
                # refusal here as in `sx_service.rpc`, because a generator that
                # quietly dropped what the door refuses to mount would make the
                # two disagree about which methods exist.
                if (
                    policy.projection != options_pb2.PUBLIC_PROJECTION_UNSPECIFIED
                    or policy.HasField("operation_kind")
                ):
                    raise ValueError(
                        f"{method.full_name} declares half a public projection; a surface "
                        "and a projection are declared together or neither is declared"
                    )
                continue
            projection = {
                options_pb2.PUBLIC_PROJECTION_COMMON: "common",
                options_pb2.PUBLIC_PROJECTION_ADVANCED: "advanced",
            }.get(policy.projection)
            if projection is None:
                raise ValueError(f"{method.full_name} has no supported public projection")
            if policy.surface in names:
                raise ValueError(f"{method.full_name} has a duplicate public surface")
            if not policy.rate_class:
                raise ValueError(f"{method.full_name} has no rate class")
            kind = _operation_kind(options)
            results = () if kind is None else _operation_results(owner.descriptor, method.name)
            names.add(policy.surface)
            found.append(
                RpcOperation(
                    name=policy.surface,
                    door=owner.door,
                    service=owner.descriptor.full_name,
                    method=method.name,
                    projection=projection,
                    rate_class=policy.rate_class,
                    pillar=owner.pillar,
                    kind=kind,
                    results=results,
                )
            )
    return tuple(sorted(found, key=lambda item: item.name))


def _operation_kind(options: MethodOptions) -> OperationKind | None:
    policy = _method_policy(options)
    if not policy.HasField("operation_kind"):
        return None
    name = common_pb2.OperationKind.Name(policy.operation_kind)
    if not name.startswith("OPERATION_KIND_"):
        raise ValueError(f"unknown descriptor operation kind {name!r}")
    return OperationKind(name.removeprefix("OPERATION_KIND_").lower().replace("_", "-"))


def _method_policy(options: MethodOptions) -> options_pb2.MethodPolicy:
    """Bridge the generated extension stub's erased descriptor type."""

    return cast(
        options_pb2.MethodPolicy,
        options.Extensions[cast(Any, options_pb2.method_policy)],
    )


def _operation_results(service: ServiceDescriptor, admission_name: str) -> tuple[str, ...]:
    admission = service.methods_by_name[admission_name]
    operation_field = admission.output_type.fields_by_name.get("operation")
    if operation_field is None or operation_field.message_type is None:
        raise ValueError(f"{admission.full_name} does not return a typed operation")
    operation_name = operation_field.message_type.name
    if not operation_name.endswith("Operation"):
        raise ValueError(f"{admission.full_name} operation result has no operation suffix")
    family = operation_name.removesuffix("Operation")
    required = (
        f"Get{family}Operation",
        f"Get{family}OperationUpdates",
        f"Get{family}OperationResult",
        f"Cancel{family}Operation",
    )
    missing = tuple(name for name in required if name not in service.methods_by_name)
    if missing:
        raise ValueError(f"{admission.full_name} operation controls are incomplete: {missing}")
    for name in required[:3]:
        method = service.methods_by_name[name]
        if method.GetOptions().idempotency_level != MethodOptions.NO_SIDE_EFFECTS:
            raise ValueError(f"{method.full_name} is not declared side-effect-free")
    result_method = service.methods_by_name[f"Get{family}OperationResult"]
    result_field = result_method.output_type.fields_by_name.get("result")
    if result_field is None or result_field.message_type is None:
        raise ValueError(f"{result_method.full_name} has no typed result")
    result_oneof = result_field.message_type.oneofs_by_name.get("result")
    if result_oneof is None or not result_oneof.fields:
        raise ValueError(f"{result_method.full_name} has no closed result alternatives")
    if any(field.type != FieldDescriptor.TYPE_MESSAGE for field in result_oneof.fields):
        raise ValueError(f"{result_method.full_name} carries a non-message result")
    results: list[str] = []
    for field in result_oneof.fields:
        if field.message_type is None:
            raise ValueError(f"{result_method.full_name} carries an untyped result")
        results.append(field.message_type.name)
    return tuple(results)


PUBLIC_RPC_SERVICES: tuple[OwnerService, ...] = (
    OwnerService(
        Door.AUTONOMY,
        PlatformPillar.AUTONOMY,
        ask_pb2.DESCRIPTOR.services_by_name["ProjectAskService"],
    ),
    OwnerService(
        Door.AUTH,
        None,
        organization_pb2.DESCRIPTOR.services_by_name["OrganizationService"],
    ),
    OwnerService(
        Door.CATALOG,
        PlatformPillar.EXPERIENCE,
        catalog_pb2.DESCRIPTOR.services_by_name["CatalogSemanticService"],
    ),
    OwnerService(
        Door.CATALOG,
        PlatformPillar.EXPERIENCE,
        catalog_pb2.DESCRIPTOR.services_by_name["CatalogTaskService"],
    ),
    OwnerService(
        Door.CATALOG,
        PlatformPillar.EXPERIENCE,
        catalog_pb2.DESCRIPTOR.services_by_name["CatalogEmbodimentService"],
    ),
    OwnerService(
        Door.CATALOG,
        PlatformPillar.EXPERIENCE,
        applications_pb2.DESCRIPTOR.services_by_name["CatalogApplicationService"],
    ),
    OwnerService(
        Door.CATALOG,
        PlatformPillar.EXPERIENCE,
        evidence_pb2.DESCRIPTOR.services_by_name["CatalogEvidenceService"],
    ),
    OwnerService(
        Door.CATALOG,
        PlatformPillar.EXPERIENCE,
        annotations_pb2.DESCRIPTOR.services_by_name["CatalogAnnotationService"],
    ),
    OwnerService(
        Door.CATALOG,
        PlatformPillar.EXPERIENCE,
        pipelines_pb2.DESCRIPTOR.services_by_name["CatalogPipelineService"],
    ),
    OwnerService(
        Door.CATALOG,
        PlatformPillar.EXPERIENCE,
        catalog_operations_pb2.DESCRIPTOR.services_by_name["CatalogOperationService"],
    ),
    OwnerService(
        Door.CATALOG,
        PlatformPillar.EXPERIENCE,
        membership_pb2.DESCRIPTOR.services_by_name["CatalogMembershipService"],
    ),
    OwnerService(
        Door.FACTORY,
        PlatformPillar.EXPERIENCE,
        factory_pb2.DESCRIPTOR.services_by_name["FactoryService"],
    ),
    OwnerService(
        Door.TASKPEDIA,
        PlatformPillar.EXPERIENCE,
        taskpedia_pb2.DESCRIPTOR.services_by_name["TaskAuthoringService"],
    ),
    OwnerService(
        Door.AUTONOMY,
        PlatformPillar.AUTONOMY,
        training_pb2.DESCRIPTOR.services_by_name["TrainingJobService"],
    ),
    OwnerService(
        Door.AUTONOMY,
        PlatformPillar.AUTONOMY,
        application_pb2.DESCRIPTOR.services_by_name["ApplicationService"],
    ),
    OwnerService(
        Door.AUTONOMY,
        PlatformPillar.AUTONOMY,
        improve_pb2.DESCRIPTOR.services_by_name["ImprovementService"],
    ),
    OwnerService(
        Door.FLEET,
        PlatformPillar.FLEET,
        fleet_pb2.DESCRIPTOR.services_by_name["FleetControlPlaneService"],
    ),
    OwnerService(
        Door.WORLDS,
        PlatformPillar.WORLDS,
        worlds_pb2.DESCRIPTOR.services_by_name["WorldsControlPlaneService"],
    ),
)


PUBLIC_RPC_OPERATIONS: dict[str, RpcOperation] = {
    operation.name: operation for operation in public_rpc_operations(PUBLIC_RPC_SERVICES)
}

# Every generated method on an adopted public service is a mounted Connect route,
# including operation controls and list/detail reads that deliberately have no
# separately projected façade verb.  Keep this descriptor-derived: reconstructing
# companion paths in documentation tooling would create a second service registry.
PUBLIC_RPC_PATHS: frozenset[str] = frozenset(
    f"/{owner.descriptor.full_name}/{method.name}"
    for owner in PUBLIC_RPC_SERVICES
    for method in owner.descriptor.methods
)


# The common projection's durable verbs, in one sorted tuple. An advanced verb
# carrying an operation kind is deliberately outside it: the common projection is
# what the CLI and MCP register. This is a projection of the table above, not a
# second source, so no test can add information by re-asserting the predicate —
# what is worth pinning is that every family a verb here can mint has an owner in
# `Sx.operation()`, which `tests/test_agent_surface_contract.py` does.
MUTATION_NAMES: tuple[str, ...] = tuple(
    sorted(
        name
        for name, operation in PUBLIC_RPC_OPERATIONS.items()
        if operation.kind is not None and operation.projection == "common"
    )
)
