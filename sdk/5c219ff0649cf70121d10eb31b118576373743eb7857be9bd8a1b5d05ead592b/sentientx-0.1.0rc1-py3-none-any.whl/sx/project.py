"""Connect a local agent workspace to one governed robotics project."""

import json
import os
from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from types import MappingProxyType
from uuid import UUID

from connectrpc.errors import ConnectError
from pydantic import BaseModel, ConfigDict, Field, JsonValue, ValidationError
from sentientx.sx.platform.auth.v1 import organization_connect, organization_pb2
from sx_auth.principal import ProjectId
from sx_service.registry import DoorId

from sx._transport import ConnectionProfile, Endpoints
from sx.credentials import api_key_for


class ProjectConnectError(RuntimeError):
    """A local workspace cannot be connected without overwriting invalid state."""


class ProjectDiscoveryError(RuntimeError):
    """The signed-in principal's operable projects could not be discovered."""


class ProjectNotFoundError(ProjectDiscoveryError):
    """A human project selector matched no operable project."""


class AmbiguousProjectError(ProjectDiscoveryError):
    """A human project selector matched more than one operable project."""

    def __init__(self, selector: str | None, candidates: tuple[str, ...]) -> None:
        self.selector = selector
        self.candidates = candidates
        label = "project selection" if selector is None else repr(selector)
        super().__init__(f"{label} is ambiguous; choose one of {', '.join(candidates)}")


class Project(BaseModel):
    """One active project the signed-in principal can operate."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: UUID
    organization_id: UUID
    organization_slug: str
    slug: str
    display_name: str
    objective: str | None
    disabled: bool
    managed_access_role: str | None = None

    @property
    def name(self) -> str:
        return f"{self.organization_slug}/{self.slug}"


_PROJECT_ACCESS_ROLE = MappingProxyType(
    {
        organization_pb2.PROJECT_ACCESS_ROLE_VIEWER: "viewer",
        organization_pb2.PROJECT_ACCESS_ROLE_CONTRIBUTOR: "contributor",
        organization_pb2.PROJECT_ACCESS_ROLE_ADMIN: "admin",
    }
)


def _project(row: organization_pb2.Project) -> Project:
    """The one named transform from the wire projection to the public value."""

    return Project(
        id=UUID(row.id),
        organization_id=UUID(row.organization_id),
        organization_slug=row.organization_slug,
        slug=row.slug,
        display_name=row.display_name,
        objective=row.objective if row.HasField("objective") else None,
        disabled=row.disabled,
        managed_access_role=(
            _PROJECT_ACCESS_ROLE[row.managed_access_role]
            if row.HasField("managed_access_role")
            else None
        ),
    )


class _McpDocument(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    mcp_servers: dict[str, JsonValue] = Field(default_factory=dict, alias="mcpServers")


class _StdioServer(BaseModel):
    model_config = ConfigDict(extra="forbid")

    command: str
    args: tuple[str, ...]
    env: dict[str, str]


@dataclass(frozen=True, slots=True)
class ConnectedProject:
    project_id: ProjectId
    workspace: Path
    mcp_config: Path
    skill_directories: tuple[Path, ...]


def _read_mcp(path: Path) -> _McpDocument:
    if not path.exists():
        return _McpDocument()
    try:
        body: object = json.loads(path.read_text())
        return _McpDocument.model_validate(body)
    except (OSError, ValueError, ValidationError) as err:
        raise ProjectConnectError(f"cannot preserve invalid MCP config at {path}") from err


def connect_project(workspace: Path, project_id: ProjectId) -> ConnectedProject:
    """Install the project skill and merge the local lifecycle MCP server.

    The API key stays in the launching shell's ``SX_API_KEY`` environment. Only the
    non-secret project identity is written into the child server environment.
    """
    root = workspace.resolve()
    root.mkdir(parents=True, exist_ok=True)
    mcp_path = root / ".mcp.json"
    document = _read_mcp(mcp_path)
    servers = dict(document.mcp_servers)
    servers["sx"] = _StdioServer(
        command="sx-mcp",
        args=(),
        env={"SX_PROJECT_ID": str(project_id)},
    ).model_dump(mode="json")
    rendered = document.model_copy(update={"mcp_servers": servers})
    mcp_path.write_text(
        json.dumps(rendered.model_dump(mode="json", by_alias=True), indent=2) + "\n"
    )

    skill_source = resources.files("sx") / "skills" / "sx-project"
    skill_files = (Path("SKILL.md"), Path("agents/openai.yaml"))
    skill_dirs = (
        root / ".agents" / "skills" / "sx-project",
        root / ".claude" / "skills" / "sx-project",
    )
    for directory in skill_dirs:
        directory.mkdir(parents=True, exist_ok=True)
        for relative_path in skill_files:
            target = directory / relative_path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(skill_source.joinpath(*relative_path.parts).read_text())
    return ConnectedProject(project_id, root, mcp_path, skill_dirs)


def resolve_project(explicit: str | None, start: Path) -> ProjectId:
    """Resolve CLI project precedence: flag, environment, then nearest MCP config."""

    candidate = explicit or os.environ.get("SX_PROJECT_ID")
    if candidate is not None:
        return _project_id(candidate)
    root = start.resolve()
    for directory in (root, *root.parents):
        path = directory / ".mcp.json"
        if not path.exists():
            continue
        document = _read_mcp(path)
        for name, raw in document.mcp_servers.items():
            if name != "sx" or not isinstance(raw, dict):
                continue
            env = raw.get("env")
            if isinstance(env, dict):
                project = env.get("SX_PROJECT_ID")
                if isinstance(project, str):
                    return _project_id(project)
    raise ProjectConnectError(
        "no project is connected; pass --project, set SX_PROJECT_ID, or run sx project connect"
    )


async def list_projects(
    *,
    profile: ConnectionProfile = ConnectionProfile.HOSTED,
    api_key: str | None = None,
    endpoints: Endpoints | None = None,
) -> tuple[Project, ...]:
    """List every active project the current credential may operate."""

    credential = api_key_for(profile, api_key)
    if credential is None:
        raise ProjectDiscoveryError("not signed in; run `sx auth login`")
    selected_endpoints = endpoints or Endpoints.resolve(profile)
    client = organization_connect.OrganizationServiceClient(
        selected_endpoints.for_door(DoorId.AUTH).rstrip("/")
    )
    try:
        response = await client.list_projects(
            organization_pb2.ListProjectsRequest(),
            headers={"Authorization": f"Bearer {credential}"},
            timeout_ms=30_000,
        )
    except ConnectError as error:
        raise ProjectDiscoveryError(f"project discovery failed: {error}") from error
    finally:
        await client.close()
    # `Project` stays a rich value with its `name` property, because that is what
    # the CLI and every caller read. One named transform, not a dict codec.
    return tuple(_project(row) for row in response.projects)


def select_project(projects: tuple[Project, ...], selector: str | None) -> Project:
    """Select by organization/slug, slug, display name, or exact UUID."""

    if selector is None:
        if not projects:
            raise ProjectNotFoundError("this account has no operable projects")
        if len(projects) == 1:
            return projects[0]
        raise AmbiguousProjectError(None, tuple(project.name for project in projects))
    matches: list[Project] = [
        project
        for project in projects
        if selector
        in {
            str(project.id),
            project.name,
            project.slug,
            project.display_name,
        }
    ]
    if not matches:
        raise ProjectNotFoundError(f"no operable project matches {selector!r}")
    if len(matches) > 1:
        raise AmbiguousProjectError(selector, tuple(project.name for project in matches))
    return matches[0]


def _project_id(value: str) -> ProjectId:
    try:
        parsed = UUID(value)
    except ValueError as error:
        raise ProjectConnectError("project must be a canonical UUID") from error
    if str(parsed) != value:
        raise ProjectConnectError("project must use canonical lowercase UUID spelling")
    return ProjectId(parsed)
