"""Descriptor-native CLI commands alongside the intent-shaped convenience commands."""

import json
import re
from collections.abc import Callable
from inspect import Parameter, Signature
from typing import Any

import typer
from google.protobuf.descriptor import FieldDescriptor

from sx._descriptor_surface import PUBLIC_RPC_OPERATIONS, RpcOperation
from sx._projected_rpc import rpc_method


def register_commands(
    application: typer.Typer,
    invoke: Callable[[typer.Context, RpcOperation, dict[str, object]], None],
) -> None:
    """Generate named commands and their flags; an existing semantic command wins."""

    def group(parent: typer.Typer, name: str) -> typer.Typer:
        for registered in parent.registered_groups:
            if registered.name == name:
                if registered.typer_instance is None:
                    raise RuntimeError(f"CLI group {name} has no application")
                return registered.typer_instance
        child = typer.Typer(no_args_is_help=True)
        parent.add_typer(child, name=name)
        return child

    for operation in PUBLIC_RPC_OPERATIONS.values():
        if operation.projection != "common":
            continue
        components = operation.name.replace("_", "-").split(".")
        parent = application
        for component in components[:-1]:
            parent = group(parent, component)
        if any(command.name == components[-1] for command in parent.registered_commands):
            continue
        method = rpc_method(operation)
        has_children = any(
            other.name.startswith(operation.name + ".")
            for other in PUBLIC_RPC_OPERATIONS.values()
            if other.projection == "common"
        )

        def bind(selected: RpcOperation, *, callback: bool) -> Callable[..., None]:
            def invoke_command(ctx: typer.Context, **values: Any) -> None:
                if callback and ctx.invoked_subcommand is not None:
                    return
                request: dict[str, object] = {}
                for field in rpc_method(selected).input_type.fields:
                    value = values[field.name]
                    if value is None:
                        continue
                    if (
                        field.is_repeated
                        or (
                            field.message_type is not None
                            and field.message_type.full_name
                            not in (
                                "google.protobuf.Timestamp",
                                "google.protobuf.Duration",
                            )
                        )
                        or field.type
                        not in (
                            FieldDescriptor.TYPE_STRING,
                            FieldDescriptor.TYPE_BYTES,
                            FieldDescriptor.TYPE_ENUM,
                            FieldDescriptor.TYPE_MESSAGE,
                        )
                    ):
                        try:
                            value = json.loads(value)
                        except json.JSONDecodeError as error:
                            raise typer.BadParameter(
                                f"{field.name} requires its JSON value: {error.msg}"
                            ) from error
                    request[field.name] = value
                invoke(ctx, selected, request)

            return invoke_command

        command = bind(operation, callback=has_children)
        parameters = [Parameter("ctx", Parameter.POSITIONAL_OR_KEYWORD, annotation=typer.Context)]
        for field in method.input_type.fields:
            label = (
                field.message_type.name
                if field.message_type is not None
                else field.enum_type.name
                if field.enum_type is not None
                else field.name.replace("_", " ")
            )
            parameters.append(
                Parameter(
                    field.name,
                    Parameter.KEYWORD_ONLY,
                    annotation=str | None,
                    default=typer.Option(None, f"--{field.name.replace('_', '-')}", help=label),
                )
            )
        command.__name__ = operation.name.replace(".", "_")
        command.__doc__ = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", method.name) + "."
        # Typer reads Python's dynamic callable signature at this framework boundary.
        command.__signature__ = Signature(parameters, return_annotation=None)  # pyright: ignore[reportFunctionMemberAccess]
        if has_children:
            group(parent, components[-1]).callback(invoke_without_command=True)(command)
        else:
            parent.command(components[-1])(command)
