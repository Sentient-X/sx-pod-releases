"""Intent-shaped CLI projection of the public ``sx`` lifecycle."""

import asyncio
import json
import re
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path
from typing import Annotated, NoReturn, cast

import typer
from google.protobuf.json_format import Parse, ParseError
from sentientx.sx.autonomy.ask.v1 import ideas_pb2
from sentientx.sx.autonomy.train.v1 import training_pb2
from sx_auth.node import NodeKind
from sx_auth.principal import ProjectId
from sx_autonomy import ApplicationQualificationRef, CapabilityApprovalRef
from sx_contracts import (
    CatalogSegmentRef,
    DeploymentGroupRef,
    RobotApplicationRef,
    TaskContractRef,
    TaskId,
    TaskSchemaVersion,
    UpdateCursor,
    catalog_segment_from_dict,
)
from sx_contracts.content import ArtifactId, ContentRef, Sha256Digest
from sx_corpora import DatasetName
from sx_embodiments import embodiments
from sx_fleet.research import RunBudget
from sx_worlds import (
    MimicGenSource,
    PolicyArtifactKind,
    PolicyArtifactRef,
    SeedSelection,
    Simulator,
)

from sx._cli_projection import register_commands
from sx._descriptor_surface import RpcOperation
from sx._encode import json_value, proto_document
from sx._projected_rpc import parse_request
from sx._transport import ConnectionProfile
from sx.client import Sx
from sx.credentials import CredentialError
from sx.credentials import login as credential_login
from sx.credentials import logout as credential_logout
from sx.credentials import status as credential_status
from sx.node_join import NodeJoinError, redeem_and_install
from sx.ops import OperationsError, credentials_for, repository_root
from sx.project import (
    AmbiguousProjectError,
    ProjectConnectError,
    ProjectDiscoveryError,
    connect_project,
    list_projects,
    resolve_project,
    select_project,
)
from sx.rerun_viewer import EpisodeViewerError, open_in_rerun

app = typer.Typer(no_args_is_help=True)
worlds = typer.Typer(no_args_is_help=True)
autonomy = typer.Typer(no_args_is_help=True)
autonomy_ideas = typer.Typer(no_args_is_help=True)
fleet = typer.Typer(no_args_is_help=True)
fleet_station = typer.Typer(no_args_is_help=True)
fleet_controller = typer.Typer(no_args_is_help=True)
fleet_research_pod = typer.Typer(no_args_is_help=True)
experience = typer.Typer(no_args_is_help=True)
project = typer.Typer(no_args_is_help=True)
auth = typer.Typer(no_args_is_help=True)
ops = typer.Typer(no_args_is_help=True)
app.add_typer(worlds, name="worlds")
app.add_typer(autonomy, name="autonomy")
autonomy.add_typer(autonomy_ideas, name="ideas")
app.add_typer(fleet, name="fleet")
fleet.add_typer(fleet_station, name="station")
fleet.add_typer(fleet_controller, name="controller")
fleet.add_typer(fleet_research_pod, name="research-pod")
app.add_typer(experience, name="experience")
app.add_typer(project, name="project")
app.add_typer(auth, name="auth")
app.add_typer(ops, name="ops")

_WORKSPACE = typer.Option(Path.cwd(), "--workspace")
_GLOBAL_PROJECT = typer.Option(None, "--project", envvar="SX_PROJECT_ID")
_GLOBAL_PROFILE = typer.Option(ConnectionProfile.HOSTED, "--profile", envvar="SX_PROFILE")
_GENERATION_SIMULATOR = typer.Option(..., "--simulator")
_GENERATION_IDEMPOTENCY_KEY = typer.Option(None, "--idempotency-key")


@dataclass(frozen=True, slots=True)
class _Context:
    project: str
    profile: ConnectionProfile


@dataclass(frozen=True, slots=True)
class _Invocation:
    project: str | None
    profile: ConnectionProfile


@app.callback()
def global_options(
    ctx: typer.Context,
    project_id: str | None = _GLOBAL_PROJECT,
    profile: ConnectionProfile = _GLOBAL_PROFILE,
) -> None:
    """Bind project and connection profile once for the whole command."""

    ctx.obj = _Invocation(project_id, profile)


def _context(ctx: typer.Context) -> _Context:
    if not isinstance(ctx.obj, _Invocation):
        raise RuntimeError("CLI invocation context was not bound")
    try:
        return _Context(str(resolve_project(ctx.obj.project, Path.cwd())), ctx.obj.profile)
    except ProjectConnectError as error:
        raise typer.BadParameter(str(error)) from error


def _invocation(ctx: typer.Context) -> _Invocation:
    if not isinstance(ctx.obj, _Invocation):
        raise RuntimeError("CLI invocation context was not bound")
    return ctx.obj


@auth.command("login")
def auth_login(
    ctx: typer.Context,
    launch_browser: bool = typer.Option(True, "--browser/--no-browser"),
) -> None:
    """Authenticate once in the hosted browser and retain the CLI credential."""

    profile = _invocation(ctx).profile

    def announce(url: str, code: str) -> None:
        typer.echo(f"Authorize code {code} at {url}")

    try:
        identity = credential_login(
            profile,
            launch_browser=launch_browser,
            on_authorization=announce,
        )
    except CredentialError as error:
        raise typer.BadParameter(str(error)) from error
    typer.echo(f"Signed in as {identity.subject}")


@auth.command("status")
def auth_status(ctx: typer.Context) -> None:
    """Show the identity held by the selected connection profile."""

    try:
        subject = credential_status(_invocation(ctx).profile)
    except CredentialError as error:
        raise typer.BadParameter(str(error)) from error
    typer.echo(f"Signed in as {subject}")


@auth.command("logout")
def auth_logout(ctx: typer.Context) -> None:
    """Revoke this CLI credential at Auth and remove it from the OS store."""

    try:
        removed = credential_logout(_invocation(ctx).profile)
    except CredentialError as error:
        raise typer.BadParameter(str(error)) from error
    typer.echo("Signed out" if removed else "No stored credential")


@ops.command("credentials")
def ops_credentials(target: str = typer.Argument(..., help="Private service name")) -> None:
    """Print the reviewed username/password pair for one private service."""

    try:
        credential = credentials_for(repository_root(), target)
    except OperationsError as error:
        raise typer.BadParameter(str(error)) from error
    typer.echo(f"username: {credential.username}")
    typer.echo(f"password: {credential.password}")


def _emit(value: object) -> None:
    typer.echo(json.dumps(json_value(value), sort_keys=True, separators=(",", ":")))


def _read_object(path: Path, label: str) -> dict[str, object]:
    try:
        value: object = json.loads(path.read_text())
    except (OSError, ValueError) as error:
        raise typer.BadParameter(f"{label} is not readable JSON: {error}") from error
    if not isinstance(value, dict):
        raise typer.BadParameter(f"{label} must contain one JSON object")
    candidate = cast("dict[object, object]", value)
    if not all(isinstance(key, str) for key in candidate):
        raise typer.BadParameter(f"{label} must contain one JSON object")
    return {str(key): item for key, item in candidate.items()}


def _pinned(value: str, label: str) -> tuple[str, str]:
    name, marker, digest = value.rpartition("@")
    if not marker or not name or len(digest) != 64:
        raise typer.BadParameter(f"{label} must be NAME@SHA256")
    return name, digest


def _seed_segment(value: str) -> dict[str, str]:
    """One DATASET/SEGMENT@SHA256 seed reference, pinned to its digest."""
    segment, digest = _pinned(value, "seed segment")
    dataset, separator, segment_id = segment.partition("/")
    if not separator or not segment_id:
        raise typer.BadParameter("seed segment must be DATASET/SEGMENT@SHA256")
    return {"dataset_id": dataset, "segment_id": segment_id, "base_sha256": digest}


def _task_ref_exact(value: str) -> TaskContractRef:
    """One `TASK_ID@SCHEMA_VERSION@SHA256` argument as the exact revision it names."""

    parts = value.rsplit("@", 2)
    if len(parts) != 3 or not all(parts) or len(parts[2]) != 64:
        raise typer.BadParameter("task must be TASK_ID@SCHEMA_VERSION@SHA256")
    task_id, schema_version, sha256 = parts
    return TaskContractRef(
        TaskId(task_id),
        TaskSchemaVersion(schema_version),
        Sha256Digest(sha256),
    )


def _seed_segment_ref(value: str) -> CatalogSegmentRef:
    return catalog_segment_from_dict(_seed_segment(value))


def _duration_seconds(value: str) -> float:
    match = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)([smhd])", value.strip().lower())
    if match is None:
        raise typer.BadParameter(
            "duration must use a positive s, m, h, or d suffix (for example 2h)"
        )
    amount = float(match.group(1))
    if amount <= 0:
        raise typer.BadParameter("duration must be positive")
    return amount * {"s": 1.0, "m": 60.0, "h": 3_600.0, "d": 86_400.0}[match.group(2)]


async def _evaluate_async(
    ctx: _Context,
    *,
    application: str,
    task: str,
    seed: int | None,
    timeout_s: int,
) -> str:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        governed_application = await sx.autonomy.applications.get(application)
        governed_task = await sx.experience.tasks.get(task)
        operation = await sx.evaluate(
            governed_application,
            task=governed_task,
            seed=seed,
            timeout=timedelta(seconds=timeout_s),
        )
        return str(operation.ref)


@worlds.command("evaluate")
def worlds_evaluate(
    ctx: typer.Context,
    application: str = typer.Argument(..., help="Exact application reference"),
    task: str = typer.Option(..., "--task", help="Exact governed task id"),
    seed: int | None = typer.Option(None, "--seed"),
    timeout_s: int = typer.Option(21_600, "--timeout", min=1),
) -> None:
    """Evaluate an exact application through its robot-control boundary."""

    typer.echo(
        asyncio.run(
            _evaluate_async(
                _context(ctx),
                application=application,
                task=task,
                seed=seed,
                timeout_s=timeout_s,
            )
        )
    )


async def _capture_async(
    ctx: _Context,
    *,
    task: str,
    embodiment: str,
    episodes: int,
    timeout_s: int,
) -> str:
    try:
        robot = embodiments[embodiment]
    except KeyError as error:
        raise typer.BadParameter(f"unknown embodiment {embodiment!r}") from error
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        contract = await sx.experience.tasks.get(task)
        operation = await sx.experience.capture(
            contract,
            with_embodiment=robot,
            episodes=episodes,
            timeout=timedelta(seconds=timeout_s),
        )
        return str(operation.ref)


async def _task_async(ctx: _Context, task: str) -> object:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        return await sx.experience.tasks.get(task)


async def _task_opportunities_async(
    ctx: _Context, request: dict[str, object]
) -> list[dict[str, object]]:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        return [
            proto_document(item) for item in await sx.experience.authoring.opportunities(request)
        ]


async def _task_draft_async(ctx: _Context, draft_id: str) -> dict[str, object]:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        return proto_document(await sx.experience.authoring.draft(draft_id))


async def _task_check_async(ctx: _Context, draft_id: str) -> dict[str, object]:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        return proto_document(await sx.experience.authoring.check(draft_id))


async def _task_propose_async(
    ctx: _Context, draft_id: str, proposal: dict[str, object]
) -> dict[str, object]:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        return proto_document(await sx.experience.authoring.propose(draft_id, proposal))


@experience.command("task")
def experience_task(ctx: typer.Context, task: str) -> None:
    """Resolve one governed task contract."""

    _emit(asyncio.run(_task_async(_context(ctx), task)))


@experience.command("task-opportunities")
def experience_task_opportunities(ctx: typer.Context, request_file: Path) -> None:
    """Derive Taskpedia opportunities from exact selected object references."""

    request = _read_object(request_file, "opportunity search")
    _emit(asyncio.run(_task_opportunities_async(_context(ctx), request)))


@experience.command("task-draft")
def experience_task_draft(ctx: typer.Context, draft_id: str) -> None:
    """Read one project-shared task draft and exact server revision."""

    _emit(asyncio.run(_task_draft_async(_context(ctx), draft_id)))


@experience.command("task-check")
def experience_task_check(ctx: typer.Context, draft_id: str) -> None:
    """Evaluate one draft through Taskpedia, Catalog, and Worlds owner proofs."""

    _emit(asyncio.run(_task_check_async(_context(ctx), draft_id)))


@experience.command("task-propose")
def experience_task_propose(ctx: typer.Context, draft_id: str, proposal_file: Path) -> None:
    """Create an immutable proposal for later human review and application."""

    proposal = _read_object(proposal_file, "task proposal")
    _emit(asyncio.run(_task_propose_async(_context(ctx), draft_id, proposal)))


async def _snapshot_async(ctx: _Context, dataset: str, task: str) -> object:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        contract = await sx.experience.tasks.get(task)
        return await sx.experience.dataset(dataset).where(task=contract).snapshot()


@experience.command("snapshot")
def experience_snapshot(
    ctx: typer.Context,
    dataset: str,
    task: str = typer.Option(..., "--for-task"),
) -> None:
    """Snapshot conformant training episodes for one governed task."""

    _emit(asyncio.run(_snapshot_async(_context(ctx), dataset, task)))


@experience.command("capture")
def experience_capture(
    ctx: typer.Context,
    task: str = typer.Option(..., "--task"),
    embodiment: str = typer.Option(..., "--with"),
    episodes: int = typer.Option(..., "--episodes", min=1),
    timeout_s: int = typer.Option(86_400, "--timeout", min=1),
) -> None:
    """Capture governed episodes on an enrolled compatible station."""

    typer.echo(
        asyncio.run(
            _capture_async(
                _context(ctx),
                task=task,
                embodiment=embodiment,
                episodes=episodes,
                timeout_s=timeout_s,
            )
        )
    )


@worlds.command("evaluate-subject")
def worlds_evaluate_subject(
    ctx: typer.Context,
    task: str,
    subject: str = typer.Argument(""),
    kind: str = typer.Option(..., "--kind"),
    seed: int | None = typer.Option(None, "--seed"),
    timeout_s: int = typer.Option(21_600, "--timeout"),
) -> None:
    """Evaluate an authored SUBJECT@SHA256 — or the zero-action floor — for a task.

    `--kind zero_action` takes no SUBJECT: the baseline's whole request is its kind.
    """

    pinned: PolicyArtifactRef | None
    if kind == "zero_action":
        if subject:
            raise typer.BadParameter("the zero-action baseline pins no artifact")
        pinned = None
    else:
        artifact, digest = _pinned(subject, "subject")
        try:
            pinned = PolicyArtifactRef(
                kind=PolicyArtifactKind(kind),
                artifact=ContentRef(ArtifactId(artifact), Sha256Digest(digest)),
            )
        except ValueError as error:
            raise typer.BadParameter(str(error)) from error
    typer.echo(
        asyncio.run(
            _evaluate_subject_async(
                _context(ctx),
                task=_task_ref_exact(task),
                subject=pinned,
                seed=seed,
                timeout_s=timeout_s,
            )
        )
    )


async def _evaluate_subject_async(
    ctx: _Context,
    *,
    task: TaskContractRef,
    subject: PolicyArtifactRef | None,
    seed: int | None,
    timeout_s: int,
) -> str:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        operation = await (
            sx.worlds.evaluate_baseline(
                for_task=task,
                seed=seed,
                timeout=timedelta(seconds=timeout_s),
            )
            if subject is None
            else sx.worlds.evaluate_subject(
                subject,
                for_task=task,
                seed=seed,
                timeout=timedelta(seconds=timeout_s),
            )
        )
        return str(operation.ref)


@worlds.command("generate")
def worlds_generate(
    ctx: typer.Context,
    task: str,
    seed_segments: list[str],
    into: str = typer.Option(..., "--into"),
    count: int = typer.Option(..., "--count"),
    position_jitter_m: float = typer.Option(..., "--position-jitter-m"),
    rotation_jitter_rad: float = typer.Option(..., "--rotation-jitter-rad"),
    selection: str = typer.Option("random", "--selection"),
    simulator: Simulator = _GENERATION_SIMULATOR,
    idempotency_key: str | None = _GENERATION_IDEMPOTENCY_KEY,
    seed: int | None = typer.Option(None, "--seed"),
) -> None:
    """Run bounded MimicGen from a pool of DATASET/SEGMENT@SHA256 seed episodes."""

    try:
        source = MimicGenSource(
            seed_segments=tuple(_seed_segment_ref(ref) for ref in seed_segments),
            position_jitter_m=position_jitter_m,
            rotation_jitter_rad=rotation_jitter_rad,
            selection=SeedSelection(selection),
        )
    except ValueError as error:
        raise typer.BadParameter(str(error)) from error
    typer.echo(
        asyncio.run(
            _generate_async(
                _context(ctx),
                task=_task_ref_exact(task),
                source=source,
                into=DatasetName(into),
                count=count,
                simulator=simulator,
                idempotency_key=idempotency_key,
                seed=seed,
            )
        )
    )


async def _generate_async(
    ctx: _Context,
    *,
    task: TaskContractRef,
    source: MimicGenSource,
    into: DatasetName,
    count: int,
    simulator: Simulator,
    idempotency_key: str | None,
    seed: int | None,
) -> str:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        operation = await sx.worlds.generate(
            source,
            for_task=task,
            count=count,
            into=into,
            simulator=simulator,
            idempotency_key=idempotency_key,
            seed=seed,
        )
        return str(operation.ref)


async def _train_job(
    ctx: _Context,
    corpus: str,
    sha256: str,
    recipe: str,
    execution: Path,
    timeout_s: int,
    idempotency_key: str | None,
    *,
    custom: bool,
) -> str:
    try:
        execution_value = Parse(execution.read_text(), training_pb2.TrainingExecution())
        data = training_pb2.CorpusSnapshotRef(name=corpus, sha256=sha256)
        async with Sx(project=ctx.project, profile=ctx.profile) as sx:
            if custom:
                operation = await sx.train_custom(
                    data=data,
                    recipe=Parse(Path(recipe).read_text(), training_pb2.BCRecipe()),
                    execution=execution_value,
                    timeout=timedelta(seconds=timeout_s),
                    idempotency_key=idempotency_key,
                )
            else:
                operation = await sx.train(
                    data=data,
                    recipe=training_pb2.RecipePreset.Value(
                        "RECIPE_PRESET_" + recipe.upper().replace("-", "_")
                    ),
                    execution=execution_value,
                    timeout=timedelta(seconds=timeout_s),
                    idempotency_key=idempotency_key,
                )
            return str(operation.ref)
    except (OSError, ParseError, ValueError) as error:
        raise typer.BadParameter(str(error)) from error


@app.command("train")
def train_application(
    ctx: typer.Context,
    corpus: str,
    execution: Annotated[Path, typer.Option()],
    sha256: str = typer.Option(...),
    recipe: str = typer.Option(...),
    timeout_s: int = typer.Option(86400, min=1),
    idempotency_key: str | None = None,
) -> None:
    """Train one pinned corpus using a governed recipe and explicit execution request."""
    typer.echo(
        asyncio.run(
            _train_job(
                _context(ctx),
                corpus,
                sha256,
                recipe,
                execution,
                timeout_s,
                idempotency_key,
                custom=False,
            )
        )
    )


@app.command("train-custom")
def train_custom(
    ctx: typer.Context,
    corpus: str,
    recipe: Annotated[Path, typer.Option()],
    execution: Annotated[Path, typer.Option()],
    sha256: str = typer.Option(...),
    timeout_s: int = typer.Option(86400, min=1),
    idempotency_key: str | None = None,
) -> None:
    """Train one pinned corpus using the complete recipe in a JSON file."""
    typer.echo(
        asyncio.run(
            _train_job(
                _context(ctx),
                corpus,
                sha256,
                str(recipe),
                execution,
                timeout_s,
                idempotency_key,
                custom=True,
            )
        )
    )


async def _deploy_application(
    ctx: _Context,
    application: str,
    to: str,
    qualification: str,
    approvals: tuple[str, ...],
    timeout_s: int,
) -> str:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        operation = await sx.fleet.deploy(
            RobotApplicationRef(application),
            to=DeploymentGroupRef(to),
            qualification=ApplicationQualificationRef(qualification),
            approvals=tuple(CapabilityApprovalRef(value) for value in approvals),
            timeout=timedelta(seconds=timeout_s),
        )
        return str(operation.ref)


@app.command("deploy")
def deploy_application(
    ctx: typer.Context,
    application: str,
    approval: Annotated[list[str], typer.Option()],
    to: str = typer.Option(...),
    qualification: str = typer.Option(...),
    timeout_s: int = typer.Option(900, min=1),
) -> None:
    """Deploy an exact application through Fleet with existing qualification and approvals."""
    typer.echo(
        asyncio.run(
            _deploy_application(
                _context(ctx), application, to, qualification, tuple(approval), timeout_s
            )
        )
    )


async def _rollback_async(ctx: _Context, deployment: str, timeout_s: int) -> str:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        operation = await sx.fleet.rollback(deployment, timeout=timedelta(seconds=timeout_s))
        return str(operation.ref)


@app.command("rollback")
def rollback_application(
    ctx: typer.Context,
    deployment: str,
    timeout_s: int = typer.Option(900, "--timeout", min=1),
) -> None:
    """Restore a deployment's previous healthy application and capability set."""

    typer.echo(asyncio.run(_rollback_async(_context(ctx), deployment, timeout_s)))


async def _improve_async(
    ctx: _Context,
    task: TaskContractRef,
    base_application_ref: RobotApplicationRef,
    max_rounds: int,
    timeout_s: int,
) -> str:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        operation = await sx.autonomy.improve(
            task,
            base_application_ref=base_application_ref,
            max_rounds=max_rounds,
            timeout=timedelta(seconds=timeout_s),
        )
        return str(operation.ref)


@autonomy.command("improve")
def autonomy_improve(
    ctx: typer.Context,
    task: str,
    base_application: str = typer.Option(..., "--base-application"),
    max_rounds: int = typer.Option(..., "--max-rounds"),
    timeout_s: int = typer.Option(..., "--timeout"),
) -> None:
    """Improve one governed task revision over one exact base application."""

    typer.echo(
        asyncio.run(
            _improve_async(
                _context(ctx),
                _task_ref_exact(task),
                RobotApplicationRef(base_application),
                max_rounds,
                timeout_s,
            )
        )
    )


@fleet.command("research")
def fleet_research(
    ctx: typer.Context,
    deployment: str,
    approval: str = typer.Option(..., "--approval"),
    max_episodes: int = typer.Option(..., "--max-episodes"),
    max_duration: str = typer.Option(..., "--max-duration"),
) -> None:
    typer.echo(
        asyncio.run(
            _fleet_research_async(
                _context(ctx),
                deployment=deployment,
                approval=approval,
                max_episodes=max_episodes,
                max_duration_s=_duration_seconds(max_duration),
            )
        )
    )


async def _fleet_research_async(
    ctx: _Context,
    *,
    deployment: str,
    approval: str,
    max_episodes: int,
    max_duration_s: float,
) -> str:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        operation = await sx.fleet.research(
            deployment,
            approval=approval,
            budget=RunBudget(max_episodes=max_episodes, max_duration_s=max_duration_s),
        )
        return str(operation.ref)


async def _fleet_readiness_async(ctx: _Context, revision: dict[str, object]) -> object:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        return proto_document(await sx.fleet.commissioning.research_pod_readiness(revision))


async def _fleet_pod_commit_async(ctx: _Context, revision: dict[str, object]) -> object:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        return proto_document(await sx.fleet.commissioning.commit_research_pod(revision))


async def _fleet_controller_commit_async(ctx: _Context, controller: dict[str, object]) -> object:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        return proto_document(await sx.fleet.commissioning.commit_station_controller(controller))


def _join_node(ctx: typer.Context, code: str, kind: NodeKind) -> None:
    try:
        installation = redeem_and_install(code, kind, _invocation(ctx).profile)
    except NodeJoinError as error:
        raise typer.BadParameter(str(error)) from error
    typer.echo(f"Joined {installation.subject}")


@fleet_station.command("join")
def fleet_station_join(ctx: typer.Context, join_code: str) -> None:
    """Enroll this machine as the station named by a one-time Fleet join code."""

    _join_node(ctx, join_code, NodeKind.STATION)


@fleet_controller.command("join")
def fleet_controller_join(ctx: typer.Context, join_code: str) -> None:
    """Enroll this host as the controller bridge named by a one-time Fleet join code."""

    _join_node(ctx, join_code, NodeKind.CONTROLLER)


@fleet_research_pod.command("readiness")
def fleet_research_pod_readiness(ctx: typer.Context, revision_file: Path) -> None:
    """Validate a proposed research-pod revision against current station inventory."""

    body = _read_object(revision_file, "research-pod revision")
    _emit(asyncio.run(_fleet_readiness_async(_context(ctx), body)))


@fleet_research_pod.command("commit")
def fleet_research_pod_commit(ctx: typer.Context, revision_file: Path) -> None:
    """Commit one validated research-pod revision."""

    body = _read_object(revision_file, "research-pod revision")
    _emit(asyncio.run(_fleet_pod_commit_async(_context(ctx), body)))


@fleet_controller.command("commission-station")
def fleet_controller_commission_station(ctx: typer.Context, controller_file: Path) -> None:
    """Commission a station-attached controller from discovered inventory."""

    body = _read_object(controller_file, "station controller")
    _emit(asyncio.run(_fleet_controller_commit_async(_context(ctx), body)))


async def _operation_async(
    ctx: _Context,
    ref: str,
    action: str,
    *,
    reason: str | None = None,
) -> object:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        operation = sx.operation(ref)
        if action == "status":
            return await operation.status()
        if action == "result":
            return await operation.result()
        if action == "cancel":
            assert reason is not None
            return await operation.cancel(reason=reason)
        raise ValueError(f"unknown operation action {action!r}")


async def _watch_async(ctx: _Context, ref: str, *, after: int | None) -> None:
    async with Sx(project=ctx.project, profile=ctx.profile) as sx:
        operation = sx.operation(ref)
        async for update in operation.watch(after=None if after is None else UpdateCursor(after)):
            _emit(update)


@app.command("status")
def operation_status(
    ctx: typer.Context,
    ref: str,
) -> None:
    _emit(asyncio.run(_operation_async(_context(ctx), ref, "status")))


@app.command("watch")
def operation_watch(
    ctx: typer.Context,
    ref: str,
    after: int | None = typer.Option(None, "--after"),
) -> None:
    asyncio.run(_watch_async(_context(ctx), ref, after=after))


@app.command("result")
def operation_result(
    ctx: typer.Context,
    ref: str,
) -> None:
    _emit(asyncio.run(_operation_async(_context(ctx), ref, "result")))


@app.command("cancel")
def operation_cancel(
    ctx: typer.Context,
    ref: str,
    reason: str = typer.Option(..., "--reason"),
) -> None:
    _emit(asyncio.run(_operation_async(_context(ctx), ref, "cancel", reason=reason)))


@experience.command("episode-open")
def episode_open(path: Path) -> None:
    """Open one already-downloaded episode locally; this is not a platform API."""

    try:
        _emit(open_in_rerun(path))
    except EpisodeViewerError as error:
        raise typer.BadParameter(str(error)) from error


@project.command("list")
def project_list(ctx: typer.Context) -> None:
    """List every project the signed-in identity can operate."""

    try:
        available = asyncio.run(list_projects(profile=_invocation(ctx).profile))
    except ProjectDiscoveryError as error:
        raise typer.BadParameter(str(error)) from error
    if not available:
        typer.echo("No operable projects")
        return
    for item in available:
        typer.echo(f"{item.name}\t{item.display_name}")


@project.command("connect")
def project_connect(
    ctx: typer.Context,
    selector: str | None = typer.Argument(
        None,
        help="Project name, organization/slug, display name, or exact UUID",
    ),
    workspace: Path = _WORKSPACE,
) -> None:
    """Connect this workspace to one project visible to the signed-in identity."""

    try:
        available = asyncio.run(list_projects(profile=_invocation(ctx).profile))
        if selector is None and len(available) > 1:
            typer.echo("Choose a project:")
            for index, item in enumerate(available, start=1):
                typer.echo(f"  {index}. {item.name} — {item.display_name}")
            selection: int = typer.prompt("Project", type=int)
            if selection < 1 or selection > len(available):
                raise typer.BadParameter("project selection is out of range")
            selected = available[selection - 1]
        else:
            selected = select_project(available, selector)
        connect_project(workspace, ProjectId(selected.id))
    except (AmbiguousProjectError, ProjectConnectError, ProjectDiscoveryError) as error:
        raise typer.BadParameter(str(error)) from error
    typer.echo(f"Connected {selected.name}")


def main() -> NoReturn:
    app()
    raise SystemExit(0)


@autonomy_ideas.command("list")
def ideas_list(
    ctx: typer.Context, limit: int = 50, before: str | None = None, kept_only: bool = False
) -> None:
    """List saved ideas in this project."""
    context = _context(ctx)

    async def run() -> object:
        async with Sx(project=context.project, profile=context.profile) as client:
            return proto_document(
                await client.autonomy.ideas.list(limit=limit, before=before, kept_only=kept_only)
            )

    _emit(asyncio.run(run()))


@autonomy_ideas.command("get")
def ideas_get(ctx: typer.Context, id: str) -> None:
    """Read one exact idea revision."""
    context = _context(ctx)

    async def run() -> object:
        async with Sx(project=context.project, profile=context.profile) as client:
            return proto_document(await client.autonomy.ideas.get(id))

    _emit(asyncio.run(run()))


@autonomy_ideas.command("create")
def ideas_create(
    ctx: typer.Context,
    content: Path,
    idempotency_key: str = typer.Option(..., "--idempotency-key"),
    parent_id: str | None = None,
) -> None:
    """Save IdeaContent JSON from a file, optionally as a variation of an exact idea."""
    try:
        proposal = Parse(content.read_text(), ideas_pb2.IdeaContent())
    except (OSError, ParseError) as error:
        raise typer.BadParameter(str(error)) from error
    context = _context(ctx)

    async def run() -> object:
        async with Sx(project=context.project, profile=context.profile) as client:
            return proto_document(
                await client.autonomy.ideas.create(
                    proposal, parent_id=parent_id, idempotency_key=idempotency_key
                )
            )

    _emit(asyncio.run(run()))


@autonomy_ideas.command("keep")
def ideas_keep(ctx: typer.Context, id: str) -> None:
    """Keep a revision for later. This approves no work."""
    context = _context(ctx)

    async def run() -> object:
        async with Sx(project=context.project, profile=context.profile) as client:
            return proto_document(await client.autonomy.ideas.keep(id))

    _emit(asyncio.run(run()))


def _invoke_projection(
    ctx: typer.Context, operation: RpcOperation, document: dict[str, object]
) -> None:
    context = _context(ctx)
    request = parse_request(operation, document)

    async def run() -> None:
        async with Sx(project=context.project, profile=context.profile) as client:
            _emit(await client.rpc(operation, request))

    asyncio.run(run())


register_commands(app, _invoke_projection)
