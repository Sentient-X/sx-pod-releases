"""One descriptor-driven Connect call for the SDK, CLI and MCP projections."""

from collections.abc import Mapping
from typing import cast

from connectrpc.client import ConnectClient
from connectrpc.errors import ConnectError
from connectrpc.method import IdempotencyLevel, MethodInfo
from google.protobuf.descriptor import MethodDescriptor
from google.protobuf.descriptor_pb2 import MethodOptions
from google.protobuf.json_format import ParseDict, ParseError
from google.protobuf.message import Message
from google.protobuf.message_factory import GetMessageClass
from sx_contracts.identity import CanonicalDocument, content_digest

from sx._descriptor_surface import PUBLIC_RPC_OPERATIONS, PUBLIC_RPC_SERVICES, RpcOperation
from sx._encode import proto_document
from sx._errors import OperationProtocolError
from sx._rpc import raise_rpc, validated
from sx._transport import Transport


def rpc_method(operation: RpcOperation) -> MethodDescriptor:
    if PUBLIC_RPC_OPERATIONS.get(operation.name) != operation:
        raise OperationProtocolError(
            "RPC operation does not belong to the public descriptor surface"
        )
    method = next(
        owner.descriptor.methods_by_name[operation.method]
        for owner in PUBLIC_RPC_SERVICES
        if owner.descriptor.full_name == operation.service
    )
    if method.client_streaming or method.server_streaming:
        raise OperationProtocolError(f"{operation.name} is not a supported unary operation")
    return method


def parse_request(operation: RpcOperation, document: Mapping[str, object]) -> Message:
    method = rpc_method(operation)
    try:
        request = ParseDict(dict(document), GetMessageClass(method.input_type)())
    except (ParseError, ValueError, TypeError) as error:
        raise OperationProtocolError(f"{operation.name} request is malformed: {error}") from error
    return validated(request, label=f"{operation.name} request")


async def call_rpc(
    transport: Transport,
    operation: RpcOperation,
    request: Message,
    *,
    idempotency_key: str | None = None,
) -> Message:
    """Validate both ends and the owner's echoed request, preserving typed refusals."""
    method = rpc_method(operation)
    if request.DESCRIPTOR is not method.input_type:
        raise OperationProtocolError(f"{operation.name} requires {method.input_type.full_name}")
    validated(request, label=f"{operation.name} request")
    binding = transport.rpc_binding(operation.door)
    headers = dict(binding.headers)
    if method.GetOptions().idempotency_level != MethodOptions.NO_SIDE_EFFECTS:
        headers["Idempotency-Key"] = (
            idempotency_key
            if idempotency_key is not None
            else str(
                content_digest(
                    cast(
                        CanonicalDocument,
                        {
                            "surface": operation.name,
                            "project": headers["X-SX-Project-Id"],
                            "request": proto_document(request),
                        },
                    )
                )
            )
        )
    async with ConnectClient(binding.address) as client:
        try:
            response = await client.execute_unary(
                request=request,
                method=MethodInfo(
                    name=method.name,
                    service_name=operation.service,
                    input=GetMessageClass(method.input_type),
                    output=GetMessageClass(method.output_type),
                    idempotency_level={
                        MethodOptions.NO_SIDE_EFFECTS: IdempotencyLevel.NO_SIDE_EFFECTS,
                        MethodOptions.IDEMPOTENT: IdempotencyLevel.IDEMPOTENT,
                    }.get(method.GetOptions().idempotency_level, IdempotencyLevel.UNKNOWN),
                ),
                headers=headers,
                timeout_ms=30_000,
            )
        except ConnectError as error:
            raise_rpc(error)
    if response.DESCRIPTOR is not method.output_type:
        raise OperationProtocolError(f"{operation.name} returned another response type")
    validated(response, label=f"{operation.name} response")
    if "request" in method.output_type.fields_by_name:
        echoed: object = next(
            (value for field, value in response.ListFields() if field.name == "request"), None
        )
        if not isinstance(echoed, Message) or echoed != request:
            raise OperationProtocolError(f"{operation.name} returned another request")
    return response
