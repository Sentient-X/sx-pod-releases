"""Generated Connect client for the one Autonomy-owned improvement operation family.

A campaign's identity is derived from the content of its goal, so this client sends no
idempotency key: a replayed start answers the same operation identity by construction,
and a key here would be a value no path reads.

`ImprovementResult` and `ImprovementProgress` stay the rich `sx_autonomy` values the
façade promises; this module is the one named, total transform between them and the wire.
Only the five methods the façade's one public verb needs are here — the campaign list,
read, stop, and successor admission are the Console's, over its own generated client.
"""

from __future__ import annotations

from collections.abc import Sequence
from datetime import UTC, datetime, timedelta

from connectrpc.errors import ConnectError
from google.protobuf.timestamp_pb2 import Timestamp
from sentientx.sx.autonomy.improve.v1 import improve_connect, improve_pb2
from sentientx.sx.common.v1 import common_pb2
from sx_autonomy import (
    Improved,
    ImprovementExhausted,
    ImprovementProgress,
    ImprovementResult,
    ImprovementRound,
    ImprovementStopped,
    improvement_progress_from_dict,
    improvement_progress_to_dict,
)
from sx_contracts import (
    AcceptedOperation,
    CancelledOperation,
    FailedOperation,
    IdempotencyKey,
    OperationFailure,
    OperationId,
    OperationKind,
    OperationProgress,
    OperationReceipt,
    OperationRef,
    PlatformPillar,
    RobotApplicationRef,
    RunningOperation,
    SucceededOperation,
    TaskContractRef,
    TraceId,
    UpdateCursor,
)
from sx_worlds import WorldRunId

from sx._errors import OperationProtocolError
from sx._rpc import cancellation_from_proto as _cancellation
from sx._rpc import raise_rpc as _raise_rpc
from sx._rpc import resource_from_proto as _resource
from sx._rpc import validated as _validated
from sx._transport import RpcBinding

_RPC_TIMEOUT_MS = 30_000


def _operation_ref(ref: OperationRef[object, object]) -> common_pb2.OperationRef:
    if ref.pillar is not PlatformPillar.AUTONOMY or ref.kind is not OperationKind.IMPROVEMENT:
        raise OperationProtocolError(f"the improvement authority cannot own {ref}")
    return common_pb2.OperationRef(
        pillar=common_pb2.PLATFORM_PILLAR_AUTONOMY,
        kind=common_pb2.OPERATION_KIND_IMPROVEMENT,
        operation_id=str(ref.operation_id),
    )


def _task(ref: TaskContractRef) -> common_pb2.TaskContractRef:
    return common_pb2.TaskContractRef(
        task_id=str(ref.task_id),
        schema_version=str(ref.schema_version),
        sha256=str(ref.sha256),
    )


def _datetime(value: Timestamp) -> datetime:
    return value.ToDatetime(tzinfo=UTC)


def improvement_progress_from_proto(
    value: improve_pb2.ImprovementProgress,
) -> ImprovementProgress:
    """Rebuild the live campaign line, running the domain's own admitted-range law."""

    return ImprovementProgress(phase=value.phase, rounds_spent=value.rounds_spent)


def _rounds(
    rounds: Sequence[improve_pb2.ImprovementRound],
) -> tuple[ImprovementRound, ...]:
    return tuple(
        ImprovementRound(
            index=record.index,
            hypothesis=record.hypothesis,
            evidence_refs=tuple(record.evidence_refs),
        )
        for record in rounds
    )


def improvement_result_from_proto(
    value: improve_pb2.ImprovementOperationResult,
) -> ImprovementResult:
    """The alternative's arm *is* the verdict; the domain's three arms are the structure."""

    arm = value.WhichOneof("result")
    if arm == "improved":
        return Improved(WorldRunId(value.improved.evaluation), _rounds(value.improved.rounds))
    if arm == "exhausted":
        return ImprovementExhausted(_rounds(value.exhausted.rounds), value.exhausted.reason)
    if arm == "stopped":
        return ImprovementStopped(_rounds(value.stopped.rounds), value.stopped.reason)
    raise OperationProtocolError(f"unknown improvement result arm {arm!r}")


def _progress(value: improve_pb2.ImprovementOperation) -> OperationProgress | None:
    """The ledger mapping the receipt carries, built through the domain value.

    An accepted campaign has stated no phase, and that absence is the owner's answer
    rather than a zero either side invented — so it stays absent all the way through.
    """

    if not value.HasField("progress"):
        return None
    return improvement_progress_to_dict(improvement_progress_from_proto(value.progress))


def _receipt(value: improve_pb2.ImprovementOperation) -> OperationReceipt:
    _validated(value, label="Autonomy improvement operation")
    metadata = value.metadata
    ref = metadata.ref
    if (
        ref.pillar != common_pb2.PLATFORM_PILLAR_AUTONOMY
        or ref.kind != common_pb2.OPERATION_KIND_IMPROVEMENT
    ):
        raise OperationProtocolError(
            "the improvement authority returned a non-improvement operation"
        )
    operation_id = OperationId(ref.operation_id)
    resource = _resource(metadata.resource)
    trace_id = TraceId(metadata.trace_id)
    cursor = UpdateCursor(metadata.cursor)
    key = IdempotencyKey(metadata.idempotency_key) if metadata.HasField("idempotency_key") else None
    progress = _progress(value)
    created_at = _datetime(metadata.created_at)
    updated_at = _datetime(metadata.updated_at)
    arm = value.lifecycle.WhichOneof("state")
    if arm == "accepted":
        return AcceptedOperation(
            operation_id,
            PlatformPillar.AUTONOMY,
            OperationKind.IMPROVEMENT,
            resource,
            trace_id,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            cancellation=_cancellation(value.lifecycle.accepted),
            created_at=created_at,
            updated_at=updated_at,
        )
    if arm == "running":
        return RunningOperation(
            operation_id,
            PlatformPillar.AUTONOMY,
            OperationKind.IMPROVEMENT,
            resource,
            trace_id,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            cancellation=_cancellation(value.lifecycle.running),
            created_at=created_at,
            updated_at=updated_at,
        )
    if arm == "succeeded":
        return SucceededOperation(
            operation_id,
            PlatformPillar.AUTONOMY,
            OperationKind.IMPROVEMENT,
            resource,
            trace_id,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            created_at=created_at,
            updated_at=updated_at,
            completed_at=_datetime(value.lifecycle.succeeded.completed_at),
        )
    if arm == "failed":
        failed = value.lifecycle.failed
        return FailedOperation(
            operation_id,
            PlatformPillar.AUTONOMY,
            OperationKind.IMPROVEMENT,
            resource,
            trace_id,
            OperationFailure(
                failed.failure.code,
                failed.failure.message,
                failed.failure.retryable,
            ),
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            created_at=created_at,
            updated_at=updated_at,
            failed_at=_datetime(failed.failed_at),
        )
    if arm == "cancelled":
        cancelled = value.lifecycle.cancelled
        return CancelledOperation(
            operation_id,
            PlatformPillar.AUTONOMY,
            OperationKind.IMPROVEMENT,
            resource,
            trace_id,
            cancelled.reason,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            created_at=created_at,
            updated_at=updated_at,
            cancelled_at=_datetime(cancelled.cancelled_at),
        )
    raise OperationProtocolError(f"unknown improvement lifecycle arm {arm!r}")


def _receipt_for(
    expected: OperationRef[object, object],
    value: improve_pb2.ImprovementOperation,
) -> OperationReceipt:
    """Decode a receipt and prove the owner answered for the requested operation."""

    receipt = _receipt(value)
    if receipt.ref != expected:
        raise OperationProtocolError(
            f"the improvement authority returned {receipt.ref} while {expected} was requested"
        )
    return receipt


class ImprovementOwnerClient:
    """Generated Connect client for the one Autonomy-owned improvement family."""

    def __init__(self, binding: RpcBinding) -> None:
        self._headers = binding.headers
        self._client = improve_connect.ImprovementServiceClient(binding.address)

    async def close(self) -> None:
        await self._client.close()

    async def start(
        self,
        task: TaskContractRef,
        *,
        base_application_ref: RobotApplicationRef,
        max_rounds: int,
        timeout: timedelta,
    ) -> OperationReceipt:
        request = _validated(
            improve_pb2.StartCampaignRequest(
                task=_task(task),
                base_application_ref=str(base_application_ref),
                max_rounds=max_rounds,
                timeout=timeout,
            ),
            label="campaign admission request",
        )
        try:
            response = await self._client.start_campaign(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _receipt(_validated(response, label="campaign admission").operation)

    def progress(self, receipt: OperationReceipt) -> ImprovementProgress | None:
        """The live campaign line this receipt carries, as the domain value it is.

        Naming the decoder here rather than looking it up by pillar and kind is what
        lets Pyright prove a handle annotated `Operation[..., ImprovementProgress]`
        really is this owner's.

        `None` is the owner saying nothing yet: an accepted campaign has stated no
        phase, and that absence is its answer rather than a zero anyone invented.
        """

        if receipt.progress is None:
            return None
        return improvement_progress_from_dict(receipt.progress)

    async def status(self, ref: OperationRef[object, object]) -> OperationReceipt:
        request = _validated(
            improve_pb2.GetImprovementOperationRequest(operation=_operation_ref(ref)),
            label="improvement status request",
        )
        try:
            response = await self._client.get_improvement_operation(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _receipt_for(
            ref, _validated(response, label="improvement status response").operation
        )

    async def updates(
        self,
        ref: OperationRef[object, object],
        *,
        after: UpdateCursor | None,
        page_size: int,
        wait_s: float,
    ) -> tuple[OperationReceipt, ...]:
        """At most one snapshot per page: this owner derives its cursor, it keeps no ledger.

        ``page_size`` is therefore accepted and unused — the owner has exactly one thing
        to observe, and there is no history to page through or to have a gap in.
        """

        del page_size
        request = improve_pb2.GetImprovementOperationUpdatesRequest(
            operation=_operation_ref(ref),
            wait_timeout=timedelta(seconds=wait_s),
        )
        if after is not None:
            request.after_cursor = int(after)
        _validated(request, label="improvement updates request")
        try:
            response = await self._client.get_improvement_operation_updates(
                request, headers=self._headers, timeout_ms=int((wait_s + 5.0) * 1000)
            )
        except ConnectError as error:
            _raise_rpc(error)
        _validated(response, label="improvement updates response")
        return tuple(_receipt_for(ref, item) for item in response.page.updates)

    async def cancel(self, ref: OperationRef[object, object], *, reason: str) -> OperationReceipt:
        request = _validated(
            improve_pb2.CancelImprovementOperationRequest(
                operation=_operation_ref(ref), reason=reason
            ),
            label="improvement cancellation request",
        )
        try:
            response = await self._client.cancel_improvement_operation(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _receipt_for(
            ref, _validated(response, label="improvement cancellation response").operation
        )

    async def result(self, ref: OperationRef[object, object]) -> ImprovementResult:
        request = _validated(
            improve_pb2.GetImprovementOperationResultRequest(operation=_operation_ref(ref)),
            label="improvement result request",
        )
        try:
            response = await self._client.get_improvement_operation_result(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            _raise_rpc(error)
        _validated(response, label="improvement result response")
        return improvement_result_from_proto(response.result)
