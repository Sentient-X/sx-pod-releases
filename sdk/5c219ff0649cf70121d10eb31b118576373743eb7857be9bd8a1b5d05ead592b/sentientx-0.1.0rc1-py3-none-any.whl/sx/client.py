"""Project-scoped asynchronous client over the four platform pillars."""

from __future__ import annotations

import asyncio
import hashlib
import json
from collections.abc import AsyncIterator, Awaitable, Callable, Generator, Mapping, Sequence
from contextlib import AsyncExitStack
from dataclasses import dataclass, replace
from datetime import timedelta
from pathlib import Path
from typing import Protocol, Self, cast, overload
from uuid import UUID

from connectrpc.errors import ConnectError
from google.protobuf.json_format import MessageToDict
from google.protobuf.message import Message
from sentientx.sx.autonomy.train.v1 import training_pb2
from sentientx.sx.common.v1 import outcomes_pb2
from sentientx.sx.experience.catalog.v1 import catalog_pb2, membership_pb2
from sentientx.sx.platform.auth.v1 import organization_connect, organization_pb2
from sentientx.sx.worlds.controlplane.v1 import controlplane_pb2 as worlds_pb2
from sx_auth.credentials import DelegatedCredential, PresentedCredential
from sx_auth.principal import ProjectId
from sx_autonomy import (
    ApplicationQualification,
    ApplicationQualificationRef,
    CapabilityApproval,
    CapabilityApprovalRef,
    ImprovementProgress,
    ImprovementResult,
    SupervisionRequirements,
    TrainingProgress,
)
from sx_catalog_protocol import CATALOG_OPERATION_KINDS
from sx_contracts import (
    AcceptedOperation,
    ApplicationWorkload,
    CancelledOperation,
    CaptureOrderResult,
    CapturePolicy,
    CaptureProgress,
    ContentRef,
    FailedOperation,
    OperationId,
    OperationKind,
    OperationReceipt,
    OperationRef,
    PlatformPillar,
    ResourceRef,
    RobotApplication,
    RobotApplicationRef,
    RunningOperation,
    StationTarget,
    SucceededOperation,
    TaskContract,
    TaskContractRef,
    UpdateCursor,
    VlaPolicy,
    WorkloadName,
    contract_ref,
    operation_timeout_seconds,
    robot_application_to_dict,
)
from sx_contracts.decisions import DecisionIdentity, GoalVerificationReceipt
from sx_contracts.pipelines import Pipeline, PipelinePlan
from sx_contracts.usage import PlanEstimate
from sx_corpora import CorpusSnapshot, DatasetName, SelectionMember
from sx_embodiments import Embodiment
from sx_fleet import (
    ApplicationDeployment,
    ApplicationDeploymentRef,
    DeploymentGroupRef,
)
from sx_fleet.research import ResearchRun, RunBudget
from sx_service.registry import AUTH, AUTONOMY, CATALOG, FACTORY, FLEET, TASKPEDIA, WORLDS, DoorId
from sx_worlds import (
    EnvironmentBundle,
    EvaluationProgress,
    Generation,
    GenerationProgress,
    GenerationSource,
    ObjectAssetBundle,
    PolicyArtifactRef,
    RobotPartCandidate,
    ScanSeed,
    Scene,
    SessionStepReceipt,
    Simulator,
    SimulatorCapability,
    WorldEvaluation,
    WorldSession,
    evaluation_progress_from_dict,
    generation_progress_from_dict,
    generation_source_to_dict,
)

from sx._applications import ApplicationOwnerClient
from sx._catalog import (
    CatalogApplicationOwnerClient,
    CatalogEvidenceOwnerClient,
    CatalogMembershipOwnerClient,
    CatalogOwnerClient,
    CatalogPipelineOwnerClient,
    CatalogTaskOwnerClient,
)
from sx._catalog_native import EMBODIMENT_DESCRIPTION
from sx._catalog_operations import CatalogOperationOwnerClient
from sx._codec import read_only_progress
from sx._descriptor_surface import PUBLIC_RPC_OPERATIONS, RpcOperation
from sx._encode import encode
from sx._errors import OperationHistoryGapError, OperationProtocolError
from sx._factory import FactoryOwnerClient
from sx._fleet import FleetOwnerClient
from sx._ideas import Ideas
from sx._improve import ImprovementOwnerClient
from sx._ingest_native import IngestOperationClient
from sx._projected_rpc import call_rpc
from sx._rpc import raise_rpc
from sx._taskpedia import TaskAuthoringOwnerClient
from sx._training import TrainingOwnerClient
from sx._transport import ConnectionProfile, Endpoints, MultipartFile, Transport
from sx._worlds import (
    WorldsOwnerClient,
    environment_quality,
    environment_result,
    evaluation_result,
    generation_result,
    object_asset_result,
    object_quality,
    robot_part_result,
    scan_seed_result,
)
from sx._worlds_native import OBJECT_IMAGE_UPLOAD, PANO_UPLOAD, SCAN_UPLOAD
from sx.credentials import api_key_for
from sx.project import resolve_project

type TaskValue = TaskContract | TaskContractRef

_DEFAULT_CAPTURE_POLICY = CapturePolicy()


class OperationFailedError(RuntimeError):
    """Awaited durable work failed; ``status`` is its final authoritative receipt."""

    def __init__(self, status: FailedOperation) -> None:
        self.status = status
        super().__init__(f"{status.ref} failed ({status.failure.code}): {status.failure.message}")


class OperationCancelledError(RuntimeError):
    """Awaited durable work was cancelled explicitly at its owner."""

    def __init__(self, status: CancelledOperation) -> None:
        self.status = status
        super().__init__(f"{status.ref} was cancelled: {status.reason}")


class ResourceNotFoundError(LookupError):
    """A human selector matched no resource in the connected project."""

    def __init__(self, resource: str, selector: str) -> None:
        self.resource = resource
        self.selector = selector
        super().__init__(f"no {resource} named {selector!r} exists in the connected project")


class AmbiguousResourceError(LookupError):
    """A human selector matched more than one governed resource."""

    def __init__(self, resource: str, selector: str) -> None:
        self.resource = resource
        self.selector = selector
        super().__init__(f"more than one {resource} is named {selector!r}; use its exact ref")


class OperationNotCompleteError(RuntimeError):
    """A non-waiting result read found durable work still in progress."""

    def __init__(self, status: AcceptedOperation | RunningOperation) -> None:
        self.status = status
        super().__init__(f"{status.ref} is still {status.state.value}")


def _terminal(status: OperationReceipt) -> bool:
    return isinstance(status, SucceededOperation | FailedOperation | CancelledOperation)


class OperationOwnerClient[ResultT, ProgressT](Protocol):
    """The complete control plane one durable owner exposes to an operation handle.

    The owner declares both projections it publishes — the terminal result and the live
    detail — so `Operation[ResultT, ProgressT]` is checked against the client a façade
    method actually hands it, rather than asserted in an annotation beside a lookup.
    """

    def progress(self, receipt: OperationReceipt) -> ProgressT | None: ...

    async def status(self, ref: OperationRef[object, object]) -> OperationReceipt: ...

    async def updates(
        self,
        ref: OperationRef[object, object],
        *,
        after: UpdateCursor | None,
        page_size: int,
        wait_s: float,
    ) -> tuple[OperationReceipt, ...]: ...

    async def cancel(
        self, ref: OperationRef[object, object], *, reason: str
    ) -> OperationReceipt: ...

    async def result(self, ref: OperationRef[object, object]) -> ResultT: ...


class Operation[ResultT, ProgressT]:
    """Typed, durable operation handle. Local cancellation never cancels server work."""

    def __init__(
        self,
        owner: OperationOwnerClient[ResultT, ProgressT],
        ref: OperationRef[ResultT, ProgressT],
        admission: OperationReceipt | None = None,
    ) -> None:
        self._owner = owner
        self._last_status = admission
        self.ref = ref

    @property
    def id(self) -> OperationId:
        return self.ref.operation_id

    @property
    def resource(self) -> ResourceRef | None:
        return None if self._last_status is None else self._last_status.resource_ref

    @property
    def idempotency_key(self) -> str | None:
        status = self._last_status
        return (
            None
            if status is None or status.idempotency_key is None
            else str(status.idempotency_key)
        )

    def admission_receipt(self) -> OperationReceipt:
        """Return the receipt received with admission without another owner request."""

        if self._last_status is None:
            raise OperationProtocolError("reattached operation has no local admission receipt")
        return self._last_status

    def progress(self, status: OperationReceipt) -> ProgressT | None:
        """This receipt's live detail, as the type this operation family publishes.

        The owner decodes it, because the owner is the only thing that knows which
        family this is. ``None`` is that owner saying nothing yet — lawful absence, not
        a failure — and a malformed ledger is its typed refusal
        (:class:`~sx_contracts.OperationContractError`), never a silent absence.
        """

        self._require_identity(status)
        return self._owner.progress(status)

    async def status(self) -> OperationReceipt:
        status = await self._owner.status(cast("OperationRef[object, object]", self.ref))
        self._require_identity(status)
        self._last_status = status
        return status

    async def watch(
        self,
        *,
        after: UpdateCursor | None = None,
        page_size: int = 100,
        wait_s: float = 20.0,
    ) -> AsyncIterator[OperationReceipt]:
        if page_size < 1 or page_size > 1_000 or wait_s <= 0.0:
            raise ValueError("watch bounds must be positive and page_size must not exceed 1000")
        cursor = after
        while True:
            updates = await self.updates_page(after=cursor, page_size=page_size, wait_s=wait_s)
            for status in updates:
                cursor = status.cursor
                yield status
                if _terminal(status):
                    return

    async def updates_page(
        self,
        *,
        after: UpdateCursor | None,
        page_size: int,
        wait_s: float,
    ) -> tuple[OperationReceipt, ...]:
        try:
            raw_updates = await self._owner.updates(
                cast("OperationRef[object, object]", self.ref),
                after=after,
                page_size=page_size,
                wait_s=wait_s,
            )
        except OperationHistoryGapError as error:
            self._require_identity(error.latest)
            self._last_status = error.latest
            raise
        updates: list[OperationReceipt] = []
        cursor = after
        for status in raw_updates:
            self._require_identity(status)
            if cursor is not None and int(status.cursor) <= int(cursor):
                raise OperationProtocolError("operation owner returned a non-monotonic cursor")
            cursor = status.cursor
            self._last_status = status
            updates.append(status)
        return tuple(updates)

    async def cancel(self, *, reason: str) -> OperationReceipt:
        if not reason.strip():
            raise ValueError("cancellation reason must not be empty")
        status = await self._owner.cancel(
            cast("OperationRef[object, object]", self.ref), reason=reason
        )
        self._require_identity(status)
        self._last_status = status
        return status

    async def _wait(self) -> ResultT:
        status = self._last_status or await self.status()
        if not _terminal(status):
            async for update in self.watch(after=status.cursor):
                status = update
        return await self._terminal_result(status)

    async def result(self) -> ResultT:
        """Read a terminal result once without polling."""

        return await self._terminal_result(await self.status())

    async def _terminal_result(self, status: OperationReceipt) -> ResultT:
        if isinstance(status, AcceptedOperation | RunningOperation):
            raise OperationNotCompleteError(status)
        if isinstance(status, FailedOperation):
            raise OperationFailedError(status)
        if isinstance(status, CancelledOperation):
            raise OperationCancelledError(status)
        return await self._owner.result(cast("OperationRef[object, object]", self.ref))

    def __await__(self) -> Generator[object, None, ResultT]:
        return self._wait().__await__()

    def _require_identity(self, status: OperationReceipt) -> None:
        if status.ref != self.ref:
            raise OperationProtocolError(f"requested {self.ref}, owner answered {status.ref}")


@dataclass(frozen=True, slots=True)
class DatasetQuery:
    """An immutable, I/O-free query until :meth:`snapshot` is awaited."""

    _client: Sx
    _membership: CatalogMembershipOwnerClient
    name: DatasetName
    task_filter: TaskContractRef | None = None

    def where(self, *, task: TaskValue) -> DatasetQuery:
        return replace(self, task_filter=_task_ref(task))

    async def snapshot(self) -> CorpusSnapshot:
        if self.task_filter is None:
            raise ValueError("dataset snapshot requires .where(task=...)")
        return await self._membership.snapshot_dataset(str(self.name), self.task_filter)


class Embodiments:
    """The Experience embodiment door: parts catalog, validation, minting, resolution."""

    def __init__(self, client: Sx, owner: CatalogOwnerClient) -> None:
        self._client = client
        self._owner = owner

    async def parts(self) -> tuple[catalog_pb2.ComposablePartResource, ...]:
        """The composable part catalog with each part's derived drivability."""
        return await self._owner.parts()

    async def validate(self, definition: Mapping[str, object], *, urdf_xml: str) -> Embodiment:
        """Dry-run an assembly definition; typed refusals travel as door errors."""
        return await self._owner.validate(definition, urdf_xml=urdf_xml)

    async def register(self, definition: Mapping[str, object], *, urdf_xml: str) -> Embodiment:
        """Mint and register one body assembled from qualified parts."""
        return await self._owner.register(definition, urdf_xml=urdf_xml)

    async def get(self, name: str) -> Embodiment:
        """Resolve one governed embodiment by its tenant-scoped name."""
        return await self._owner.get(name)

    async def preview(
        self, task: TaskContract, *, body_name: str
    ) -> catalog_pb2.CandidateAdmissibility:
        """Check one complete unpublished contract against one exact body."""

        return await self._owner.preview(task, body_name=body_name)

    async def description(self, name: str) -> str:
        """One governed body's URDF description text, digest-verified by the door."""
        value = await self._client.download(
            EMBODIMENT_DESCRIPTION.method,
            EMBODIMENT_DESCRIPTION.door,
            EMBODIMENT_DESCRIPTION.path.format(name=name),
        )
        return EMBODIMENT_DESCRIPTION.decode(value)

    async def admissibility(self) -> catalog_pb2.AdmissibilityScorecard:
        """Every governed task against every registered body, derived by the door."""
        return await self._owner.admissibility()

    async def readiness(self) -> tuple[catalog_pb2.EmbodimentReadiness, ...]:
        """Per registered body: what has been recorded, declared and composed against it.

        The counts behind "is this design proven yet" — episodes captured on that exact
        revision and across its lineage family, the action interfaces it can record
        through, and the conformant scenes that embed it. Every figure is a row the
        catalog can point at; none of them is a model's estimate.
        """
        return await self._owner.readiness()

    async def frontier(self, *, depth: int | None = None) -> catalog_pb2.EmbodimentFrontier:
        """The swept design space: every body this catalog could compose, and the frontier.

        Which qualified parts attach to which registered body, scored on contracts covered
        against actuated axes, with the Pareto-optimal points marked. Candidates that
        could never be minted are refused before scoring, and the refusal count comes
        back with the result.
        """
        return await self._owner.frontier(depth=depth)

    async def admit_part(
        self,
        part: Mapping[str, object],
        *,
        urdf_xml: str,
        assets: tuple[Mapping[str, object], ...] = (),
    ) -> catalog_pb2.AdmitEmbodimentPartResponse:
        """Admit one customer part fragment into the tenant's composable catalog."""
        return await self._owner.admit_part(
            part,
            urdf_xml=urdf_xml,
            assets=assets,
        )


class Tasks:
    def __init__(
        self,
        owner: CatalogTaskOwnerClient,
        ensure_access: Callable[[], Awaitable[None]],
    ) -> None:
        self._owner = owner
        self._ensure_access = ensure_access

    async def list(self) -> tuple[TaskContract, ...]:
        await self._ensure_access()
        return await self._owner.list_project_tasks()

    async def get(self, selector: TaskContractRef | str) -> TaskContract:
        if isinstance(selector, TaskContractRef):
            await self._ensure_access()
            return await self._owner.get_project_task(selector)

        matches: list[TaskContract] = [
            task for task in await self.list() if selector in {str(task.task.id), task.task.name}
        ]
        if not matches:
            raise ResourceNotFoundError("task", selector)
        if len(matches) > 1:
            raise AmbiguousResourceError("task", selector)
        return matches[0]

    async def publish(self, contract: TaskContract) -> TaskContract:
        await self._ensure_access()
        return await self._owner.publish_task(contract)


class Experience:
    def __init__(
        self,
        client: Sx,
        ensure_access: Callable[[], Awaitable[None]],
        factory: FactoryOwnerClient,
        catalog: CatalogOwnerClient,
        catalog_tasks: CatalogTaskOwnerClient,
        pipelines: CatalogPipelineOwnerClient,
        taskpedia: TaskAuthoringOwnerClient,
        membership: CatalogMembershipOwnerClient,
    ) -> None:
        self._client = client
        self._factory = factory
        self._pipelines = pipelines
        self._membership = membership
        self.tasks = Tasks(catalog_tasks, ensure_access)
        self.embodiments = Embodiments(client, catalog)
        self.authoring = taskpedia

    async def estimate(
        self,
        *,
        pipeline: Pipeline,
        inputs: Mapping[str, str],
        destination: str,
        assumed_partition_seconds: int = 60,
    ) -> PlanEstimate:
        """Quote what this plan would consume before submitting it.

        Quantities under a meter version, never money — the same function that
        writes the bill produces the quote, and the assumptions come back as part
        of the answer so a caller can change one and ask again.

        A plan and not a dataset: the quote is authorized and priced against the
        destination the plan itself names, so there is no second dataset for a
        caller to name beside it.
        """
        return await self._pipelines.estimate_plan(
            PipelinePlan(pipeline, dict(inputs), destination),
            assumed_partition_seconds=assumed_partition_seconds,
        )

    async def atlas(self) -> catalog_pb2.GetSemanticAtlasResponse:
        """The governed corpus as topic-labeled embedding clusters (the overview)."""
        return cast(
            catalog_pb2.GetSemanticAtlasResponse,
            await self._client.rpc(
                PUBLIC_RPC_OPERATIONS["experience.atlas"], catalog_pb2.GetSemanticAtlasRequest()
            ),
        )

    async def atlas_points(
        self, cluster_id: int, *, offset: int = 0, limit: int = 1000
    ) -> catalog_pb2.ListSemanticAtlasPointsResponse:
        """One governed page of one atlas cluster's frame points."""
        return cast(
            catalog_pb2.ListSemanticAtlasPointsResponse,
            await self._client.rpc(
                PUBLIC_RPC_OPERATIONS["experience.atlas_points"],
                catalog_pb2.ListSemanticAtlasPointsRequest(
                    cluster_id=cluster_id,
                    offset=offset,
                    limit=limit,
                ),
            ),
        )

    async def search_frames(
        self,
        query: str | catalog_pb2.SemanticFrameReference,
        *,
        filters: catalog_pb2.SemanticFilters | None = None,
        limit: int | None = None,
    ) -> catalog_pb2.SearchFramesResponse:
        """Find governed frames by text or an exact indexed-frame reference."""
        frame_query = (
            catalog_pb2.SemanticFrameQuery(text=catalog_pb2.SemanticTextQuery(text=query))
            if isinstance(query, str)
            else catalog_pb2.SemanticFrameQuery(frame=query)
        )
        request = catalog_pb2.SearchFramesRequest(query=frame_query)
        if filters is not None:
            request.filters.CopyFrom(filters)
        if limit is not None:
            request.limit = limit
        return cast(
            catalog_pb2.SearchFramesResponse,
            await self._client.rpc(PUBLIC_RPC_OPERATIONS["experience.search_frames"], request),
        )

    async def search_clips(
        self,
        text: str,
        *,
        filters: catalog_pb2.SemanticFilters | None = None,
        limit: int | None = None,
    ) -> catalog_pb2.SearchClipsResponse:
        """Find governed action clips by meaning."""
        request = catalog_pb2.SearchClipsRequest(query=catalog_pb2.SemanticTextQuery(text=text))
        if filters is not None:
            request.filters.CopyFrom(filters)
        if limit is not None:
            request.limit = limit
        return cast(
            catalog_pb2.SearchClipsResponse,
            await self._client.rpc(PUBLIC_RPC_OPERATIONS["experience.search_clips"], request),
        )

    async def search_text(
        self,
        text: str,
        *,
        filters: catalog_pb2.SemanticFilters | None = None,
        limit: int | None = None,
    ) -> catalog_pb2.SearchTextResponse:
        """Search Catalog-resident text by meaning."""
        request = catalog_pb2.SearchTextRequest(query=catalog_pb2.SemanticTextQuery(text=text))
        if filters is not None:
            request.filters.CopyFrom(filters)
        if limit is not None:
            request.limit = limit
        return cast(
            catalog_pb2.SearchTextResponse,
            await self._client.rpc(PUBLIC_RPC_OPERATIONS["experience.search_text"], request),
        )

    async def search_segments(
        self,
        text: str,
        *,
        filters: catalog_pb2.SemanticFilters | None = None,
        limit: int | None = None,
    ) -> catalog_pb2.SearchSegmentsResponse:
        """Select whole governed episodes by meaning."""
        request = catalog_pb2.SearchSegmentsRequest(query=catalog_pb2.SemanticTextQuery(text=text))
        if filters is not None:
            request.filters.CopyFrom(filters)
        if limit is not None:
            request.limit = limit
        return cast(
            catalog_pb2.SearchSegmentsResponse,
            await self._client.rpc(PUBLIC_RPC_OPERATIONS["experience.search_segments"], request),
        )

    async def task_map(self) -> catalog_pb2.GetTaskMapResponse:
        """Read semantic clusters against the governed task taxonomy."""
        return cast(
            catalog_pb2.GetTaskMapResponse,
            await self._client.rpc(
                PUBLIC_RPC_OPERATIONS["experience.task_map"], catalog_pb2.GetTaskMapRequest()
            ),
        )

    async def capture(
        self,
        task: TaskValue,
        *,
        with_embodiment: Embodiment,
        episodes: int,
        policy: CapturePolicy = _DEFAULT_CAPTURE_POLICY,
        timeout: timedelta = timedelta(days=1),
        idempotency_key: str | None = None,
    ) -> Operation[CaptureOrderResult, CaptureProgress]:
        if episodes < 1:
            raise ValueError("capture episodes must be positive")
        task_ref = _task_ref(task)
        body = {
            "task": encode(task_ref),
            "embodiment_id": str(with_embodiment.id),
            "episodes": episodes,
            "policy": encode(policy),
            "timeout_s": operation_timeout_seconds(timeout),
        }
        admission = await self._factory.start_capture(
            task_ref,
            embodiment_id=str(with_embodiment.id),
            episodes=episodes,
            timeout=timeout,
            policy=policy,
            idempotency_key=idempotency_key or _structural_key("experience.capture", body),
        )
        ref = OperationRef[CaptureOrderResult, CaptureProgress](
            admission.pillar,
            admission.kind,
            admission.operation_id,
        )
        return Operation(self._factory, ref, admission)

    def dataset(self, name: DatasetName | str) -> DatasetQuery:
        return DatasetQuery(self._client, self._membership, DatasetName(str(name)))

    async def snapshot_selection(
        self, members: Sequence[SelectionMember]
    ) -> membership_pb2.DatasetSnapshot:
        """Freeze an explicit governed selection as one immutable membership.

        The atlas lasso and `search_segments` hits carry exactly this identity, so
        a chosen set of episodes becomes a value a corpus domain can name without
        anything in between re-deriving what was chosen.
        """

        return await self._membership.snapshot_selection(members)


class Worlds:
    def __init__(
        self, client: Sx, owner: WorldsOwnerClient, evidence: CatalogEvidenceOwnerClient
    ) -> None:
        self._client = client
        self._owner = owner
        self._evidence = evidence

    async def evaluate_subject(
        self,
        subject: PolicyArtifactRef,
        *,
        for_task: TaskValue,
        seed: int | None = None,
        timeout: timedelta = timedelta(hours=6),
        idempotency_key: str | None = None,
    ) -> Operation[worlds_pb2.WorldEvaluation, EvaluationProgress]:
        task = _task_ref(for_task)
        body = {
            "subject": encode(subject),
            "task": encode(task),
            "seed": seed,
            "timeout_s": operation_timeout_seconds(timeout),
        }
        admission = await self._owner.start_subject_evaluation(
            task,
            subject=subject,
            seed=seed,
            timeout=timeout,
            idempotency_key=(
                idempotency_key
                if idempotency_key is not None
                else _structural_key("worlds.evaluate_subject", body)
            ),
        )
        ref = OperationRef[worlds_pb2.WorldEvaluation, EvaluationProgress](
            admission.pillar, admission.kind, admission.operation_id
        )
        return Operation(
            self._owner.typed("evaluation", evaluation_result, evaluation_progress_from_dict),
            ref,
            admission,
        )

    async def evaluate_baseline(
        self,
        *,
        for_task: TaskValue,
        seed: int | None = None,
        timeout: timedelta = timedelta(hours=6),
        idempotency_key: str | None = None,
    ) -> Operation[worlds_pb2.WorldEvaluation, EvaluationProgress]:
        """Run the zero-action floor under a task's suite — the score a policy must beat.

        Door-local by construction: the verdict lives on the evaluation read, never in a
        canonical WorldRun, so `result()` answers a typed refusal directing there.
        """
        task = _task_ref(for_task)
        body = {
            "subject": {"kind": "zero_action"},
            "task": encode(task),
            "seed": seed,
            "timeout_s": operation_timeout_seconds(timeout),
        }
        admission = await self._owner.start_subject_evaluation(
            task,
            subject=None,
            seed=seed,
            timeout=timeout,
            idempotency_key=(
                idempotency_key
                if idempotency_key is not None
                else _structural_key("worlds.evaluate_subject", body)
            ),
        )
        ref = OperationRef[worlds_pb2.WorldEvaluation, EvaluationProgress](
            admission.pillar, admission.kind, admission.operation_id
        )
        return Operation(
            self._owner.typed("evaluation", evaluation_result, evaluation_progress_from_dict),
            ref,
            admission,
        )

    async def canonical_evaluation(
        self,
        operation: Operation[worlds_pb2.WorldEvaluation, EvaluationProgress],
    ) -> WorldEvaluation:
        """Resolve and verify the Catalog-owned evidence behind an application verdict."""

        if (
            operation.ref.pillar is not PlatformPillar.WORLDS
            or operation.ref.kind is not OperationKind.EVALUATION
        ):
            raise OperationProtocolError("canonical evidence requires a Worlds evaluation")
        projected = await operation
        if projected.evidence.WhichOneof("evidence") != "canonical_run":
            raise OperationProtocolError(
                "this evaluation is door-local and has no promotable WorldRun"
            )
        evidence_ref = projected.evidence.canonical_run
        if evidence_ref.artifact_id != evidence_ref.sha256:
            raise OperationProtocolError("Worlds returned a mismatched canonical evidence ref")
        run = await self._evidence.get_world_run(evidence_ref.artifact_id)
        if not isinstance(run.subject, RobotApplication):
            raise OperationProtocolError("canonical evaluation evidence is not application-owned")

        task = contract_ref(run.world.task)
        if (
            projected.task.task_id,
            projected.task.schema_version,
            projected.task.sha256,
        ) != (str(task.task_id), str(task.schema_version), str(task.sha256)):
            raise OperationProtocolError("Worlds verdict names another task")
        if projected.subject.WhichOneof(
            "subject"
        ) != "application_ref" or projected.subject.application_ref != str(run.subject.ref):
            raise OperationProtocolError("Worlds verdict names another application")

        evaluation = WorldEvaluation(run)
        verdict = projected.verdict
        if (verdict.passed, verdict.score, verdict.threshold) != (
            evaluation.passed,
            evaluation.score,
            evaluation.threshold,
        ):
            raise OperationProtocolError("Worlds verdict disagrees with its canonical evidence")
        observed_metrics: dict[str, float] = {}
        for metric in verdict.metrics.metrics:
            if metric.name in observed_metrics:
                raise OperationProtocolError("Worlds verdict repeats a metric name")
            observed_metrics[metric.name] = metric.value
        if any(
            observed_metrics.get(str(metric.name)) != metric.value for metric in evaluation.metrics
        ):
            raise OperationProtocolError("Worlds verdict metrics disagree with canonical evidence")

        counters: dict[str, int] = {}
        expected_cases: list[tuple[object, ...]] = []
        for case in run.cases:
            stratum = str(case.stratum)
            trial = counters.get(stratum, 0)
            counters[stratum] = trial + 1
            reason = outcomes_pb2.TerminationReason.Value(
                f"TERMINATION_REASON_{case.summary.end.reason.name}"
            )
            expected_cases.append(
                (
                    run.world.task_id,
                    stratum,
                    trial,
                    case.seed,
                    case.accepted,
                    reason,
                    case.summary.actions,
                    f"{case.segment.dataset_id}/{case.segment.segment_id}",
                    None,
                )
            )
        observed_cases = [
            (
                case.task_id,
                case.stratum,
                case.trial,
                case.seed,
                case.success,
                case.reason,
                case.steps,
                case.evidence_segment if case.HasField("evidence_segment") else None,
                case.refusal if case.HasField("refusal") else None,
            )
            for case in projected.cases
        ]
        if observed_cases != expected_cases:
            raise OperationProtocolError("Worlds scorecard disagrees with canonical evidence")
        expected_segments = tuple(
            dict.fromkeys(
                f"{case.segment.dataset_id}/{case.segment.segment_id}" for case in run.cases
            )
        )
        if tuple(projected.evidence_segments) != expected_segments:
            raise OperationProtocolError("Worlds evidence segments disagree with the WorldRun")
        return evaluation

    async def generate(
        self,
        source: GenerationSource,
        *,
        for_task: TaskValue,
        count: int,
        into: DatasetName,
        simulator: Simulator,
        idempotency_key: str | None = None,
        seed: int | None = None,
        timeout: timedelta = timedelta(days=1),
    ) -> Operation[Generation, GenerationProgress]:
        if count < 1:
            raise ValueError("generation count must be positive")
        task = _task_ref(for_task)
        body = {
            "source": generation_source_to_dict(source),
            "simulator": simulator.value,
            "task": encode(task),
            "count": count,
            "dataset": str(into),
            "seed": seed,
            "timeout_s": operation_timeout_seconds(timeout),
        }
        admission = await self._owner.start_generation(
            task,
            source=source,
            simulator=simulator,
            count=count,
            dataset=str(into),
            seed=seed,
            timeout=timeout,
            idempotency_key=idempotency_key or _structural_key("worlds.generate", body),
        )
        ref = OperationRef[Generation, GenerationProgress](
            admission.pillar, admission.kind, admission.operation_id
        )
        return Operation(
            self._owner.typed("generation", generation_result, generation_progress_from_dict),
            ref,
            admission,
        )

    async def environments(self) -> tuple[EnvironmentBundle, ...]:
        """List governed captured and generated places in this project."""
        return await self._owner.list_environments()

    async def scenes(self) -> tuple[Scene, ...]:
        """List complete, content-verified scenes in this project."""
        return await self._owner.list_scenes()

    async def object_assets(self) -> tuple[ObjectAssetBundle, ...]:
        """List governed reusable simulation objects in this project."""
        return await self._owner.list_object_assets()

    async def upload_pano(
        self,
        path: Path,
    ) -> str:
        """Govern and upload one local 2:1 panorama; return its Worlds pano id."""
        source = path.expanduser()
        suffix = source.suffix.lower()
        media_type = {
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".png": "image/png",
            ".webp": "image/webp",
        }.get(suffix)
        if media_type is None:
            raise ValueError("panorama must be JPEG, PNG, or WebP")
        content = source.read_bytes()
        if not content or len(content) > 20 * 1024 * 1024:
            raise ValueError("panorama must contain 1 byte to 20 MiB")
        value = await self._client.multipart(
            PANO_UPLOAD.method,
            PANO_UPLOAD.door,
            PANO_UPLOAD.path,
            data={},
            files={PANO_UPLOAD.field: (source.name, content, media_type)},
        )
        return PANO_UPLOAD.decode(value).pano_id

    async def upload_object_image(self, path: Path) -> str:
        """Govern one local source image and return its Worlds image id."""
        source = path.expanduser()
        media_type = {
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".png": "image/png",
            ".webp": "image/webp",
        }.get(source.suffix.lower())
        if media_type is None:
            raise ValueError("object image must be JPEG, PNG, or WebP")
        content = source.read_bytes()
        if not content or len(content) > 20 * 1024 * 1024:
            raise ValueError("object image must contain 1 byte to 20 MiB")
        value = await self._client.multipart(
            OBJECT_IMAGE_UPLOAD.method,
            OBJECT_IMAGE_UPLOAD.door,
            OBJECT_IMAGE_UPLOAD.path,
            data={},
            files={OBJECT_IMAGE_UPLOAD.field: (source.name, content, media_type)},
        )
        return OBJECT_IMAGE_UPLOAD.decode(value).image_id

    async def upload_scan(self, path: Path) -> str:
        """Stream and govern one Scanner capture archive; return its Worlds scan id.

        Capture archives run to gigabytes, so the open handle is handed to the
        transport rather than read into one ``bytes`` value first.
        """
        source = path.expanduser()
        if source.suffix.lower() != ".zip":
            raise ValueError("scan capture must be a ZIP archive")
        if not source.is_file():
            raise ValueError("scan capture must be a file")
        size = source.stat().st_size
        if size == 0 or size > 2 * 1024 * 1024 * 1024:
            raise ValueError("scan capture must contain 1 byte to 2 GiB")
        with source.open("rb") as content:
            value = await self._client.multipart(
                SCAN_UPLOAD.method,
                SCAN_UPLOAD.door,
                SCAN_UPLOAD.path,
                data={},
                files={SCAN_UPLOAD.field: (source.name, content, "application/zip")},
            )
        return SCAN_UPLOAD.decode(value).scan_id

    async def author(
        self,
        *,
        from_pano: str,
        name: str,
        description: str,
        prompt: str | None = None,
        model: str = "marble-1.1",
        seed: int | None = None,
        tags: tuple[str, ...] = (),
        timeout: timedelta = timedelta(hours=1),
    ) -> Operation[EnvironmentBundle, Mapping[str, object]]:
        """Author a governed environment from a Worlds-governed panorama upload."""
        body = {
            "pano_id": from_pano,
            "name": name,
            "description": description,
            "prompt": prompt,
            "model": model,
            "seed": seed,
            "tags": list(tags),
            "timeout_s": operation_timeout_seconds(timeout),
        }
        admission = await self._owner.start_environment_authoring(
            pano_id=from_pano,
            name=name,
            description=description,
            prompt=prompt,
            quality=environment_quality(model),
            seed=seed,
            tags=tags,
            timeout=timeout,
            idempotency_key=_structural_key("worlds.author", body),
        )
        ref = OperationRef[EnvironmentBundle, Mapping[str, object]](
            admission.pillar, admission.kind, admission.operation_id
        )
        return Operation(
            self._owner.typed("environment", environment_result, read_only_progress), ref, admission
        )

    async def author_object(
        self,
        *,
        from_image: str,
        name: str,
        description: str,
        category: str,
        longest_dimension_m: float,
        mass_kg: float,
        quality: str = "default",
        seed: int | None = None,
        tags: tuple[str, ...] = (),
        timeout: timedelta = timedelta(hours=1),
    ) -> Operation[ObjectAssetBundle, Mapping[str, object]]:
        """Author a governed reusable object from a Worlds-governed image."""
        body = {
            "image_id": from_image,
            "name": name,
            "description": description,
            "category": category,
            "longest_dimension_m": longest_dimension_m,
            "mass_kg": mass_kg,
            "quality": quality,
            "seed": seed,
            "tags": list(tags),
            "timeout_s": operation_timeout_seconds(timeout),
        }
        admission = await self._owner.start_object_authoring(
            image_id=from_image,
            name=name,
            description=description,
            category=category,
            longest_dimension_m=longest_dimension_m,
            mass_kg=mass_kg,
            quality=object_quality(quality),
            seed=seed,
            tags=tags,
            timeout=timeout,
            idempotency_key=_structural_key("worlds.author_object", body),
        )
        ref = OperationRef[ObjectAssetBundle, Mapping[str, object]](
            admission.pillar, admission.kind, admission.operation_id
        )
        return Operation(
            self._owner.typed("object_asset", object_asset_result, read_only_progress),
            ref,
            admission,
        )

    async def author_articulated_object(
        self,
        *,
        prompt: str,
        name: str,
        description: str,
        category: str,
        tags: tuple[str, ...] = (),
        timeout: timedelta = timedelta(hours=1),
        idempotency_key: str | None = None,
    ) -> Operation[ObjectAssetBundle, Mapping[str, object]]:
        """Design a governed articulated object from a prompt.

        Mass, bounds, and articulation are derived from the compiled design at
        the settle gate rather than declared up front.
        """
        body = {
            "prompt": prompt,
            "name": name,
            "description": description,
            "category": category,
            "tags": list(tags),
            "timeout_s": operation_timeout_seconds(timeout),
        }
        admission = await self._owner.start_articulated_object_authoring(
            prompt=prompt,
            name=name,
            description=description,
            category=category,
            tags=tags,
            timeout=timeout,
            idempotency_key=(
                idempotency_key
                if idempotency_key is not None
                else _structural_key("worlds.author_articulated_object", body)
            ),
        )
        ref = OperationRef[ObjectAssetBundle, Mapping[str, object]](
            admission.pillar, admission.kind, admission.operation_id
        )
        return Operation(
            self._owner.typed("object_asset", object_asset_result, read_only_progress),
            ref,
            admission,
        )

    async def author_robot_part(
        self,
        *,
        part_id: str,
        geometry_brief: str,
        timeout: timedelta = timedelta(hours=1),
        idempotency_key: str | None = None,
    ) -> Operation[RobotPartCandidate, Mapping[str, object]]:
        """Author one exact robot-part candidate for later Experience admission."""

        if not part_id.strip():
            raise ValueError("part id must not be empty")
        if not geometry_brief.strip():
            raise ValueError("robot-part geometry brief must not be empty")
        body = {
            "part_id": part_id,
            "geometry_brief": geometry_brief,
            "timeout_s": operation_timeout_seconds(timeout),
        }
        admission = await self._owner.start_robot_part_authoring(
            part_id=part_id,
            geometry_brief=geometry_brief,
            timeout=timeout,
            idempotency_key=(
                idempotency_key
                if idempotency_key is not None
                else _structural_key("worlds.author_robot_part", body)
            ),
        )
        ref = OperationRef[RobotPartCandidate, Mapping[str, object]](
            admission.pillar, admission.kind, admission.operation_id
        )
        return Operation(
            self._owner.typed("robot_part_candidate", robot_part_result, read_only_progress),
            ref,
            admission,
        )

    async def seed_scan(
        self,
        *,
        scan_id: str,
        timeout: timedelta = timedelta(hours=2),
        idempotency_key: str | None = None,
    ) -> Operation[ScanSeed, Mapping[str, object]]:
        """Reconstruct and seed one admitted scan capture.

        The deterministic half of the scan lane: it answers with a seed report,
        not a governed bundle, so a caller reads the splat quality and object
        count before paying for :meth:`publish_scan`'s agent window.
        """
        if not scan_id.strip():
            raise ValueError("scan id must not be empty")
        body = {
            "scan_id": scan_id,
            "timeout_s": operation_timeout_seconds(timeout),
        }
        admission = await self._owner.start_scan_seed(
            scan_id=scan_id,
            timeout=timeout,
            idempotency_key=(
                idempotency_key
                if idempotency_key is not None
                else _structural_key("worlds.seed_scan", body)
            ),
        )
        ref = OperationRef[ScanSeed, Mapping[str, object]](
            admission.pillar, admission.kind, admission.operation_id
        )
        return Operation(
            self._owner.typed("scan_seed", scan_seed_result, read_only_progress), ref, admission
        )

    async def publish_scan(
        self,
        *,
        scan_id: str,
        name: str,
        description: str,
        tags: tuple[str, ...] = (),
        timeout: timedelta = timedelta(hours=2),
        idempotency_key: str | None = None,
    ) -> Operation[EnvironmentBundle, Mapping[str, object]]:
        """Author and publish an already-seeded scan as a governed environment.

        Resumes the same durable run :meth:`seed_scan` built, so the seed half is
        never repaid.
        """
        if not scan_id.strip():
            raise ValueError("scan id must not be empty")
        body = {
            "scan_id": scan_id,
            "name": name,
            "description": description,
            "tags": list(tags),
            "timeout_s": operation_timeout_seconds(timeout),
        }
        admission = await self._owner.start_scan_publish(
            scan_id=scan_id,
            name=name,
            description=description,
            tags=tags,
            timeout=timeout,
            idempotency_key=(
                idempotency_key
                if idempotency_key is not None
                else _structural_key("worlds.publish_scan", body)
            ),
        )
        ref = OperationRef[EnvironmentBundle, Mapping[str, object]](
            admission.pillar, admission.kind, admission.operation_id
        )
        return Operation(
            self._owner.typed("environment", environment_result, read_only_progress), ref, admission
        )

    async def session(
        self,
        *,
        for_task: TaskValue,
        simulator: Simulator,
        ttl_s: int,
        idempotency_key: str,
        seed: int | None = None,
    ) -> WorldSession:
        """Open or replay one bounded interactive Gym session."""

        if ttl_s < 1:
            raise ValueError("session TTL must be positive")
        if not idempotency_key.strip():
            raise ValueError("session idempotency key must not be empty")
        return await self._owner.open_session(
            _task_ref(for_task),
            simulator=simulator,
            ttl_s=ttl_s,
            seed=seed,
            idempotency_key=idempotency_key,
        )

    async def sessions(self) -> tuple[WorldSession, ...]:
        """List active and recent sessions from authoritative server state."""

        return await self._owner.list_sessions()

    async def simulation_runs(self) -> tuple[OperationReceipt, ...]:
        """List recent evaluation and generation operations from the Worlds ledger."""

        return await self._owner.list_simulation_runs()

    async def simulators(self) -> tuple[SimulatorCapability, ...]:
        """Qualified simulator/job/resource combinations for this deployment."""

        return await self._owner.list_simulators()

    async def session_status(self, session_id: str) -> WorldSession:
        """Reattach to one session by its durable resource identity."""

        return await self._owner.get_session(session_id)

    async def step_session(
        self,
        session_id: str,
        *,
        step_id: str,
        expected_observation_sequence: int,
        tool: str,
        args: Mapping[str, object],
    ) -> SessionStepReceipt:
        """Apply one sequence-fenced step, replaying the same receipt after response loss."""

        if not step_id.strip() or not tool.strip():
            raise ValueError("session step and tool identities must not be empty")
        if expected_observation_sequence < 0:
            raise ValueError("expected observation sequence must be non-negative")
        return await self._owner.step_session(
            session_id,
            step_id=step_id,
            expected_observation_sequence=expected_observation_sequence,
            tool=tool,
            args=args,
        )

    async def verify_session(
        self,
        session_id: str,
        *,
        decision: DecisionIdentity,
    ) -> GoalVerificationReceipt:
        """Read the governed goal verdict without closing the session."""

        return await self._owner.verify_session(session_id, decision=decision)

    async def close_session(self, session_id: str) -> WorldSession:
        """Close one session and return its frozen evidence receipt."""

        return await self._owner.close_session(session_id)


class Applications:
    def __init__(
        self, catalog: CatalogApplicationOwnerClient, owner: ApplicationOwnerClient
    ) -> None:
        self._catalog = catalog
        self._owner = owner

    async def list(self, *, task: TaskContract | None = None) -> tuple[RobotApplication, ...]:
        applications = await self._catalog.list_applications()
        if task is None:
            return applications
        return tuple(
            application
            for application in applications
            if str(task.family) in {str(capability) for capability in application.capabilities}
        )

    async def get(self, selector: RobotApplicationRef | str) -> RobotApplication:
        """Resolve an application by its project-local name or exact immutable ref."""

        value = str(selector)
        if value.startswith("application:"):
            return await self._catalog.get_application(RobotApplicationRef(value))

        matches: list[RobotApplication] = [
            application for application in await self.list() if str(application.name) == value
        ]
        if not matches:
            raise ResourceNotFoundError("application", value)
        if len(matches) > 1:
            raise AmbiguousResourceError("application", value)
        return matches[0]

    async def revise(
        self,
        base: RobotApplication | RobotApplicationRef | str,
        candidate: RobotApplication,
        *,
        inputs: tuple[tuple[ContentRef, bytes], ...] = (),
    ) -> RobotApplication:
        """Register a complete candidate graph; evaluation and approval remain separate."""

        if isinstance(base, RobotApplication):
            base_ref = base.ref
        elif str(base).startswith("application:"):
            base_ref = RobotApplicationRef(str(base))
        else:
            base_ref = (await self.get(base)).ref
        await self.revise_ref(base_ref, candidate, inputs=inputs)
        return candidate

    async def specialize(
        self,
        base: RobotApplication,
        *,
        target: StationTarget,
        workloads: Mapping[WorkloadName, ApplicationWorkload],
    ) -> RobotApplication:
        """Publish a target-specific graph through the existing revision owner."""
        candidate = base.specialize(target=target, workloads=workloads)
        return await self.revise(base, candidate)

    async def revise_ref(
        self,
        base: RobotApplicationRef,
        candidate: RobotApplication,
        *,
        inputs: tuple[tuple[ContentRef, bytes], ...] = (),
    ) -> RobotApplicationRef:
        """Register an exact candidate under the base application's project authority."""

        return await self._owner.revise(base, candidate, inputs=inputs)


class Autonomy:
    def __init__(
        self,
        ensure_access: Callable[[], Awaitable[None]],
        catalog_applications: CatalogApplicationOwnerClient,
        applications: ApplicationOwnerClient,
        improvement: ImprovementOwnerClient,
        ideas: Ideas,
    ) -> None:
        self._ensure_access = ensure_access
        self._catalog_applications = catalog_applications
        self._improvement = improvement
        self.ideas = ideas
        self.applications = Applications(catalog_applications, applications)

    async def approve(
        self,
        evaluation: WorldEvaluation,
        qualification: ApplicationQualification,
        supervision: SupervisionRequirements,
        *,
        name: str,
    ) -> CapabilityApproval:
        """Register one exact Catalog-attested approval after both gates pass.

        The response schema binds the stored resource to the submitted name, the
        submitted canonical evidence, and Catalog's own attestation, so agreement
        is proved by the generated contract rather than re-checked field by field.
        """

        return await self._catalog_applications.register_capability_approval(
            CapabilityApproval(evaluation, qualification, supervision),
            name=name,
        )

    async def improve(
        self,
        task: TaskValue,
        *,
        base_application_ref: RobotApplicationRef,
        max_rounds: int,
        timeout: timedelta,
    ) -> Operation[ImprovementResult, ImprovementProgress]:
        """Improve one governed task revision over one exact base application.

        No idempotency key crosses the wire: the campaign id is derived from the goal's
        content, so the same goal is the same campaign and a replayed start answers the
        same operation identity.
        """

        await self._ensure_access()
        admission = await self._improvement.start(
            _task_ref(task),
            base_application_ref=base_application_ref,
            max_rounds=max_rounds,
            timeout=timeout,
        )
        ref = OperationRef[ImprovementResult, ImprovementProgress](
            admission.pillar, admission.kind, admission.operation_id
        )
        return Operation(self._improvement, ref, admission)


class Fleet:
    """The three Fleet admissions, over the one generated Fleet client."""

    def __init__(self, client: Sx, fleet: FleetOwnerClient) -> None:
        self._client = client
        self._fleet = fleet
        #: The commissioning admissions, which answer with their generated
        #: messages: a pod revision and a controller have no richer public value
        #: to rebuild, and the retired HTTP path returned them undecoded.
        self.commissioning = fleet

    def _handle(self, admission: OperationReceipt) -> Operation[object, Mapping[str, object]]:
        """One admitted receipt as its reattachable handle on this same client."""

        owner = cast("OperationOwnerClient[object, Mapping[str, object]]", self._fleet)
        ref = OperationRef[object, Mapping[str, object]](
            admission.pillar, admission.kind, admission.operation_id
        )
        return Operation(owner, ref, admission)

    async def deploy(
        self,
        application: RobotApplicationRef,
        *,
        to: DeploymentGroupRef,
        qualification: ApplicationQualificationRef,
        approvals: tuple[CapabilityApprovalRef, ...],
        timeout: timedelta = timedelta(minutes=15),
        idempotency_key: str | None = None,
    ) -> Operation[ApplicationDeployment, Mapping[str, object]]:
        body = {
            "application": str(application),
            "to": str(to),
            "qualification": str(qualification),
            "approvals": [str(approval) for approval in approvals],
            "timeout_s": operation_timeout_seconds(timeout),
        }
        admission = await self._fleet.deploy(
            application_ref=str(application),
            qualification_ref=str(qualification),
            approval_refs=tuple(str(approval) for approval in approvals),
            deployment_group_ref=str(to),
            timeout=timeout,
            idempotency_key=idempotency_key or _structural_key("fleet.deploy", body),
        )
        return cast(
            "Operation[ApplicationDeployment, Mapping[str, object]]", self._handle(admission)
        )

    async def rollback(
        self,
        deployment: ApplicationDeployment | ApplicationDeploymentRef | str,
        *,
        timeout: timedelta = timedelta(minutes=15),
        idempotency_key: str | None = None,
    ) -> Operation[ApplicationDeployment, Mapping[str, object]]:
        target = (
            str(deployment.deployment_ref)
            if isinstance(deployment, ApplicationDeployment)
            else str(deployment)
        )
        body = {"deployment": target, "timeout_s": operation_timeout_seconds(timeout)}
        admission = await self._fleet.rollback(
            deployment_ref=target,
            timeout=timeout,
            idempotency_key=idempotency_key or _structural_key("fleet.rollback", body),
        )
        return cast(
            "Operation[ApplicationDeployment, Mapping[str, object]]", self._handle(admission)
        )

    async def research(
        self,
        deployment: ApplicationDeploymentRef | str,
        *,
        approval: CapabilityApproval | CapabilityApprovalRef | str,
        budget: RunBudget,
        idempotency_key: str | None = None,
    ) -> Operation[ResearchRun, Mapping[str, object]]:
        enabled = str(approval.ref) if isinstance(approval, CapabilityApproval) else str(approval)
        body = {
            "deployment": str(deployment),
            "approval": enabled,
            "budget": encode(budget),
        }
        admission = await self._fleet.submit_research_run(
            deployment_ref=str(deployment),
            approval_ref=enabled,
            max_episodes=budget.max_episodes,
            max_duration=timedelta(seconds=budget.max_duration_s),
            idempotency_key=idempotency_key or _structural_key("fleet.research", body),
        )
        return cast("Operation[ResearchRun, Mapping[str, object]]", self._handle(admission))


class Sx:
    """One discoverable, project-scoped entry point for the complete platform."""

    def __init__(
        self,
        project: ProjectId | UUID | str | None = None,
        *,
        profile: ConnectionProfile = ConnectionProfile.HOSTED,
        api_key: str | None = None,
        credential: PresentedCredential | DelegatedCredential | None = None,
        endpoints: Endpoints | None = None,
        workspace: Path | None = None,
    ) -> None:
        project_id = (
            resolve_project(None, workspace or Path.cwd()) if project is None else _project(project)
        )
        if api_key is not None and credential is not None:
            raise ValueError("api_key and credential are mutually exclusive")
        transport = Transport(
            endpoints or Endpoints.resolve(profile),
            project_id,
            None if credential is not None else api_key_for(profile, api_key),
            credential=credential,
        )
        self._bind(transport, project_id=project_id, access_verified=False)

    @classmethod
    def _from_transport(
        cls,
        transport: Transport,
        *,
        project_id: ProjectId | None = None,
        access_verified: bool = True,
    ) -> Self:
        """Bind an injected transport for package tests and guarded doors."""

        value = cls.__new__(cls)
        value._bind(
            transport,
            project_id=project_id,
            access_verified=access_verified,
        )
        return value

    def _bind(
        self,
        transport: Transport,
        *,
        project_id: ProjectId | None,
        access_verified: bool,
    ) -> None:
        self._transport = transport
        self._project_id = project_id
        self._access_verified = access_verified
        self._access_lock = asyncio.Lock()
        self._factory = FactoryOwnerClient(transport.rpc_binding(FACTORY.name))
        self._catalog = CatalogOwnerClient(transport.rpc_binding(CATALOG.name))
        self._catalog_tasks = CatalogTaskOwnerClient(transport.rpc_binding(CATALOG.name))
        self._catalog_pipelines = CatalogPipelineOwnerClient(transport.rpc_binding(CATALOG.name))
        self._catalog_applications = CatalogApplicationOwnerClient(
            transport.rpc_binding(CATALOG.name)
        )
        self._evidence = CatalogEvidenceOwnerClient(transport.rpc_binding(CATALOG.name))
        self._catalog_operations = CatalogOperationOwnerClient(transport.rpc_binding(CATALOG.name))
        self._membership = CatalogMembershipOwnerClient(transport.rpc_binding(CATALOG.name))
        self._taskpedia = TaskAuthoringOwnerClient(transport.rpc_binding(TASKPEDIA.name))
        self._fleet = FleetOwnerClient(transport.rpc_binding(FLEET.name))
        self._applications = ApplicationOwnerClient(transport.rpc_binding(AUTONOMY.name))
        self._training = TrainingOwnerClient(transport.rpc_binding(AUTONOMY.name))
        self._improvement = ImprovementOwnerClient(transport.rpc_binding(AUTONOMY.name))
        self._ideas = Ideas(transport.rpc_binding(AUTONOMY.name))
        self._worlds = WorldsOwnerClient(transport.rpc_binding(WORLDS.name))
        self.experience = Experience(
            self,
            self._ensure_access,
            self._factory,
            self._catalog,
            self._catalog_tasks,
            self._catalog_pipelines,
            self._taskpedia,
            self._membership,
        )
        self.worlds = Worlds(self, self._worlds, self._evidence)
        self.autonomy = Autonomy(
            self._ensure_access,
            self._catalog_applications,
            self._applications,
            self._improvement,
            self._ideas,
        )
        self.fleet = Fleet(self, self._fleet)

    async def __aenter__(self) -> Self:
        await self._ensure_access()
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    async def rpc(
        self,
        operation: RpcOperation,
        request: Message,
        *,
        idempotency_key: str | None = None,
    ) -> Message:
        """Call a public descriptor with its generated request and response types.

        Intent-shaped helpers remain the usual Python interface; CLI and MCP use
        this projection where the generated contract is already the complete verb.
        """
        await self._ensure_access()
        return await call_rpc(self._transport, operation, request, idempotency_key=idempotency_key)

    async def evaluate(
        self,
        application: RobotApplication,
        *,
        task: TaskValue,
        seed: int | None = None,
        timeout: timedelta = timedelta(hours=6),
        idempotency_key: str | None = None,
    ) -> Operation[worlds_pb2.WorldEvaluation, EvaluationProgress]:
        """Evaluate a governed application against a governed task."""
        task_ref = _task_ref(task)
        body = {
            "application": robot_application_to_dict(application),
            "task": encode(task_ref),
            "seed": seed,
            "timeout_s": operation_timeout_seconds(timeout),
        }
        admission = await self._worlds.start_application_evaluation(
            task_ref,
            application_ref=str(application.ref),
            seed=seed,
            timeout=timeout,
            idempotency_key=(
                idempotency_key
                if idempotency_key is not None
                else _structural_key("worlds.evaluate", body)
            ),
        )
        ref = OperationRef[worlds_pb2.WorldEvaluation, EvaluationProgress](
            admission.pillar, admission.kind, admission.operation_id
        )
        return Operation(
            self._worlds.typed("evaluation", evaluation_result, evaluation_progress_from_dict),
            ref,
            admission,
        )

    async def train(
        self,
        *,
        data: training_pb2.CorpusSnapshotRef,
        recipe: training_pb2.RecipePreset.ValueType,
        execution: training_pb2.TrainingExecution,
        timeout: timedelta = timedelta(days=1),
        idempotency_key: str | None = None,
    ) -> Operation[VlaPolicy, TrainingProgress]:
        """Admit one executable training job over a pinned corpus."""
        request = training_pb2.CreateTrainingJobRequest(
            data=data,
            recipe=cast("training_pb2.RecipePreset", recipe),
            execution=execution,
            timeout=timeout,
        )
        admission = await self._training.start(
            request,
            idempotency_key=idempotency_key
            or _structural_key("autonomy.train", MessageToDict(request)),
        )
        ref = OperationRef[VlaPolicy, TrainingProgress](
            admission.pillar, admission.kind, admission.operation_id
        )
        return Operation(self._training, ref, admission)

    async def train_custom(
        self,
        *,
        data: training_pb2.CorpusSnapshotRef,
        recipe: training_pb2.BCRecipe,
        execution: training_pb2.TrainingExecution,
        timeout: timedelta = timedelta(days=1),
        idempotency_key: str | None = None,
    ) -> Operation[VlaPolicy, TrainingProgress]:
        """Admit one explicit BC recipe through the existing custom job owner."""
        request = training_pb2.CreateCustomTrainingJobRequest(
            data=data, recipe=recipe, execution=execution, timeout=timeout
        )
        admission = await self._training.start_custom(
            request,
            idempotency_key=idempotency_key
            or _structural_key("autonomy.train_custom", MessageToDict(request)),
        )
        ref = OperationRef[VlaPolicy, TrainingProgress](
            admission.pillar, admission.kind, admission.operation_id
        )
        return Operation(self._training, ref, admission)

    async def close(self) -> None:
        """Close every owner client and then the transport, in that order.

        One failing close never skips the rest: the stack unwinds in reverse
        registration order, so every remaining client still closes and the last
        failure reaches the caller. It is not the nested ``finally`` ladder in one
        respect — ``contextlib`` only chains a callback's failure onto the previous
        one when the new exception already carries a context, so a second failing
        close arrives without the first as its ``__context__``.
        """

        closables = (
            self._worlds,
            self._fleet,
            self._applications,
            self._training,
            self._improvement,
            self._ideas,
            self._taskpedia,
            self._catalog_operations,
            self._evidence,
            self._membership,
            self._catalog_applications,
            self._catalog_pipelines,
            self._catalog_tasks,
            self._catalog,
            self._factory,
            self._transport,
        )
        async with AsyncExitStack() as stack:
            for closable in reversed(closables):
                stack.push_async_callback(closable.close)

    @overload
    def operation[ResultT, ProgressT](
        self, ref: OperationRef[ResultT, ProgressT]
    ) -> Operation[ResultT, ProgressT]: ...

    @overload
    def operation(self, ref: str) -> Operation[object, object]: ...

    def operation[ResultT, ProgressT](
        self, ref: OperationRef[ResultT, ProgressT] | str
    ) -> Operation[ResultT, ProgressT] | Operation[object, object]:
        parsed = OperationRef.parse(ref) if isinstance(ref, str) else ref
        if parsed.pillar is PlatformPillar.EXPERIENCE and parsed.kind is OperationKind.CAPTURE:
            factory = cast("OperationOwnerClient[ResultT, ProgressT]", self._factory)
            return Operation(factory, cast("OperationRef[ResultT, ProgressT]", parsed))
        if parsed.pillar is PlatformPillar.FLEET:
            fleet = cast("OperationOwnerClient[ResultT, ProgressT]", self._fleet)
            return Operation(fleet, cast("OperationRef[ResultT, ProgressT]", parsed))
        if parsed.pillar is PlatformPillar.AUTONOMY and parsed.kind is OperationKind.TRAINING:
            training = cast("OperationOwnerClient[ResultT, ProgressT]", self._training)
            return Operation(training, cast("OperationRef[ResultT, ProgressT]", parsed))
        if parsed.pillar is PlatformPillar.AUTONOMY and parsed.kind is OperationKind.PROGRAM:
            raise ValueError(
                "Program operations are retired; their original records remain in the audit tables"
            )
        if parsed.pillar is PlatformPillar.AUTONOMY and parsed.kind is OperationKind.IMPROVEMENT:
            improvement = cast("OperationOwnerClient[ResultT, ProgressT]", self._improvement)
            return Operation(improvement, cast("OperationRef[ResultT, ProgressT]", parsed))
        if parsed.pillar is PlatformPillar.WORLDS:
            worlds = cast("OperationOwnerClient[ResultT, ProgressT]", self._worlds)
            return Operation(worlds, cast("OperationRef[ResultT, ProgressT]", parsed))
        if parsed.pillar is PlatformPillar.EXPERIENCE and parsed.kind in CATALOG_OPERATION_KINDS:
            catalog = cast("OperationOwnerClient[ResultT, ProgressT]", self._catalog_operations)
            return Operation(catalog, cast("OperationRef[ResultT, ProgressT]", parsed))
        if (
            parsed.pillar is PlatformPillar.EXPERIENCE
            and parsed.kind is OperationKind.EPISODE_INGEST
        ):
            ingest = cast(
                "OperationOwnerClient[ResultT, ProgressT]", IngestOperationClient(self._transport)
            )
            return Operation(ingest, cast("OperationRef[ResultT, ProgressT]", parsed))
        raise OperationProtocolError(
            f"no owner serves {parsed.pillar.value}/{parsed.kind.value} operations"
        )

    async def multipart(
        self,
        method: str,
        door: DoorId,
        path: str,
        *,
        data: Mapping[str, str],
        files: Mapping[str, MultipartFile],
    ) -> object:
        """Send one project-bound multipart request through the shared transport."""
        await self._ensure_access()
        return await self._transport.request(
            method,
            door,
            path,
            data=data,
            files=files,
        )

    async def download(self, method: str, door: DoorId, path: str) -> object:
        """Read one project-bound native resource through the shared transport."""
        await self._ensure_access()
        return await self._transport.request(method, door, path)

    async def _ensure_access(self) -> None:
        if self._access_verified:
            return
        async with self._access_lock:
            if self._access_verified:
                return
            if self._project_id is None:
                raise OperationProtocolError("client has no project identity to verify")
            binding = self._transport.rpc_binding(AUTH.name)
            tenancy = organization_connect.OrganizationServiceClient(binding.address)
            try:
                await tenancy.verify_project_access(
                    organization_pb2.VerifyProjectAccessRequest(project_id=str(self._project_id)),
                    headers=binding.headers,
                )
            except ConnectError as error:
                raise_rpc(error)
            finally:
                await tenancy.close()
            self._access_verified = True


def _task_ref(task: TaskValue) -> TaskContractRef:
    return contract_ref(task) if isinstance(task, TaskContract) else task


def _structural_key(call_name: str, body: object) -> str:
    encoded = json.dumps(body, sort_keys=True, separators=(",", ":"), default=str)
    return f"sx:{call_name}:{hashlib.sha256(encoded.encode()).hexdigest()}"


def _project(value: ProjectId | UUID | str) -> ProjectId:
    try:
        return ProjectId(UUID(str(value)))
    except ValueError as error:
        raise ValueError("project must be a canonical UUID") from error
