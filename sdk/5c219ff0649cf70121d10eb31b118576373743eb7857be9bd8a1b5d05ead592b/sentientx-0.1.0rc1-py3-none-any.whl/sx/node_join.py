"""One-time node enrollment at the machine installation boundary."""

from __future__ import annotations

import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path

import httpx
from sx_auth.join import JoinedNode
from sx_auth.node import NodeKind
from sx_service.registry import DoorId

from sx._transport import ConnectionProfile, Endpoints


class NodeJoinError(RuntimeError):
    """A join code was refused or its managed credential could not be installed."""


@dataclass(frozen=True, slots=True)
class NodeInstallation:
    subject: str
    credential: Path


def redeem_and_install(
    code: str,
    kind: NodeKind,
    profile: ConnectionProfile,
    *,
    root: Path | None = None,
    transport: httpx.BaseTransport | None = None,
) -> NodeInstallation:
    """Redeem one code and atomically install its least-privilege machine credential."""

    if kind not in {NodeKind.STATION, NodeKind.CONTROLLER}:
        raise NodeJoinError("only station and controller nodes can join")
    endpoints = Endpoints.resolve(profile)
    try:
        with httpx.Client(transport=transport, timeout=30.0) as client:
            response = client.post(
                f"{endpoints.for_door(DoorId.AUTH).rstrip('/')}/api/nodes/join",
                json={"code": code},
            )
    except httpx.HTTPError as error:
        raise NodeJoinError(f"Auth could not be reached: {error}") from error
    if response.is_error:
        raise NodeJoinError(
            "join code is invalid or no longer usable"
            if response.status_code in {404, 410}
            else f"Auth refused node enrollment with HTTP {response.status_code}"
        )
    try:
        joined = JoinedNode.model_validate(response.json())
    except (ValueError, TypeError) as error:
        raise NodeJoinError("Auth returned a malformed node enrollment") from error
    expected_prefix = f"{kind.value}:"
    if not joined.subject.startswith(expected_prefix):
        raise NodeJoinError(f"join code enrolled {joined.subject!r}, not a {kind.value}")

    installation_root = root or Path(f"/etc/sx-{kind.value}")
    credential = installation_root / "enrollment.json"
    _install_credential(credential, joined, endpoints.for_door(DoorId.FLEET))
    return NodeInstallation(joined.subject, credential)


def _install_credential(path: Path, joined: JoinedNode, fleet_endpoint: str) -> None:
    document = {
        "schema": "sx.node-enrollment/v1",
        "subject": joined.subject,
        "organization_id": str(joined.organization_id),
        "project_id": str(joined.project_id),
        "audiences": list(joined.audiences),
        "api_key": joined.key,
        "fleet_endpoint": fleet_endpoint,
    }
    try:
        path.parent.mkdir(mode=0o750, parents=True, exist_ok=True)
        fd, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
        temporary = Path(temporary_name)
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                json.dump(document, stream, sort_keys=True, separators=(",", ":"))
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)
    except OSError as error:
        raise NodeJoinError(f"could not install node credential at {path}: {error}") from error
