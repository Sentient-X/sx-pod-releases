"""Private codecs from generated door wire documents into canonical owner values."""

from collections.abc import Mapping
from types import MappingProxyType
from typing import Annotated, cast

from pydantic import Field, TypeAdapter
from sx_contracts import OperationProgress, OperationReceipt

_RECEIPT: TypeAdapter[OperationReceipt] = TypeAdapter(
    Annotated[OperationReceipt, Field(discriminator="state")]
)


def document(value: object, *, label: str) -> Mapping[str, object]:
    if not isinstance(value, dict):
        raise TypeError(f"{label} must be an object")
    candidate = cast("dict[object, object]", value)
    if not all(isinstance(key, str) for key in candidate):
        raise TypeError(f"{label} must be an object")
    return cast("dict[str, object]", candidate)


def operation_receipt(value: object) -> OperationReceipt:
    body = document(value, label="operation receipt")
    nested = body.get("operation")
    return _RECEIPT.validate_python(nested if nested is not None else body)


def read_only_progress(value: OperationProgress) -> Mapping[str, object]:
    """One owner's live detail, for a family that publishes no typed value for it.

    Handed back read-only because a receipt is frozen and its live detail is a fact,
    not a caller's scratch buffer.
    """

    return MappingProxyType(dict(value))
