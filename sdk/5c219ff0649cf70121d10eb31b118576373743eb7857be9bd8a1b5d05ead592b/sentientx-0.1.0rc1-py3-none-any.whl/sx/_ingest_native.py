"""The one durable operation family still served over native HTTP.

Episode ingest belongs to the pipeline's Ingest door, which has no generated owner
service yet, so what the door does serve is read over its own `/api/experience/...`
routes rather than through a generated client. Keeping the door, the operation
root, and the family's result decoder here makes that exception explicit — the
same shape `_catalog_native` and `_worlds_native` use for their byte and multipart
exceptions — instead of resolving it through a generic registry keyed by verb
strings.

**The door serves half the contract, and this says so.** `sxd.pipeline.api` mounts
`GET {operation_id}` and `POST {operation_id}/cancel` and nothing else: an ingest
operation is one mutable row carrying a monotonic `update_cursor`, not an
append-only receipt ledger, and no terminal segment ref is stored under the
operation id. So there is no history to page and no result to read. `updates` and
`result` therefore refuse with :class:`OperationLegNotServedError` naming the gap,
rather than sending a request the door answers 404. The predecessor of this module
built all four legs against a table that made them look served;
`tests/test_ingest_operation_legs.py` is what keeps the client and the door's route
list in agreement from here on.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import NoReturn

from sx_contracts import (
    CatalogSegmentRef,
    OperationReceipt,
    OperationRef,
    UpdateCursor,
)
from sx_service.registry import DoorId

from sx._codec import operation_receipt, read_only_progress
from sx._errors import OperationLeg, OperationLegNotServedError
from sx._transport import Transport

DOOR = DoorId.INGEST
OPERATION_ROOT = "/api/experience/operations"

#: The legs the Ingest door mounts, as (method, route template) pairs. Read by
#: `tests/test_ingest_operation_legs.py` against the door's own router, so the
#: refusals below cannot drift away from what is actually served.
SERVED_LEGS: Mapping[OperationLeg, tuple[str, str]] = {
    OperationLeg.STATUS: ("GET", f"{OPERATION_ROOT}/{{operation_id}}"),
    OperationLeg.CANCEL: ("POST", f"{OPERATION_ROOT}/{{operation_id}}/cancel"),
}

_UNSERVED_REASON: Mapping[OperationLeg, str] = {
    OperationLeg.UPDATES: (
        "an ingest operation is one mutable row with a monotonic cursor, not a "
        "retained receipt history, so there is no page to return"
    ),
    OperationLeg.RESULT: (
        "the ingest door records no terminal segment ref under the operation id; "
        "read the registered segment from the Catalog instead"
    ),
}


def _unserved(leg: OperationLeg) -> NoReturn:
    raise OperationLegNotServedError(door=DOOR, leg=leg, reason=_UNSERVED_REASON[leg])


class IngestOperationClient:
    """The Ingest door's operation control plane, spoken over its own HTTP routes.

    The door publishes no typed progress ledger, so live detail is handed back as
    the owner's own read-only mapping rather than a family value type.
    """

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    def progress(self, receipt: OperationReceipt) -> Mapping[str, object] | None:
        if receipt.progress is None:
            return None
        return read_only_progress(receipt.progress)

    async def status(self, ref: OperationRef[object, object]) -> OperationReceipt:
        value = await self._transport.request("GET", DOOR, _path(ref))
        return operation_receipt(value)

    async def updates(
        self,
        ref: OperationRef[object, object],
        *,
        after: UpdateCursor | None,
        page_size: int,
        wait_s: float,
    ) -> tuple[OperationReceipt, ...]:
        _unserved(OperationLeg.UPDATES)

    async def cancel(self, ref: OperationRef[object, object], *, reason: str) -> OperationReceipt:
        value = await self._transport.request(
            "POST", DOOR, _path(ref, "cancel"), body={"reason": reason}
        )
        return operation_receipt(value)

    async def result(self, ref: OperationRef[object, object]) -> CatalogSegmentRef:
        _unserved(OperationLeg.RESULT)


def _path(ref: OperationRef[object, object], action: str = "") -> str:
    suffix = f"/{action}" if action else ""
    return f"{OPERATION_ROOT}/{ref.operation_id}{suffix}"
