"""Public SDK errors shared by HTTP and generated RPC owner clients."""

from dataclasses import dataclass
from datetime import timedelta
from enum import StrEnum

from sx_contracts import OperationReceipt, ResourceRef, TraceId, UpdateCursor
from sx_service.registry import DoorId


class OperationProtocolError(RuntimeError):
    """An owner answered with another operation identity or malformed data."""


class OperationLeg(StrEnum):
    """The four calls an operation owner answers, named once."""

    STATUS = "status"
    UPDATES = "updates"
    RESULT = "result"
    CANCEL = "cancel"


class OperationLegNotServedError(RuntimeError):
    """This owner implements the operation contract only in part.

    Distinct from a refusal and from a transport failure: there is no route to
    call, so the request is refused here rather than sent somewhere that answers
    404. Carrying the door and the leg makes the gap readable by the caller that
    hit it instead of only by whoever reads the owner's route table.
    """

    def __init__(self, *, door: DoorId, leg: OperationLeg, reason: str) -> None:
        self.door = door
        self.leg = leg
        self.reason = reason
        super().__init__(f"the {door.value} door serves no operation {leg.value} leg: {reason}")


class OperationHistoryGapError(RuntimeError):
    """The requested cursor predates retained history; ``latest`` is authoritative."""

    def __init__(self, requested: UpdateCursor | None, latest: OperationReceipt) -> None:
        self.requested = requested
        self.latest = latest
        point = "initial history" if requested is None else f"history after cursor {requested}"
        super().__init__(f"operation {point} is no longer retained")


@dataclass(frozen=True, slots=True)
class Refusal:
    """Stable platform refusal detail carried independently of an RPC runtime."""

    code: str
    retryable: bool
    resource: ResourceRef | None
    trace_id: TraceId
    retry_after: timedelta | None


class RpcError(RuntimeError):
    """A generated RPC failed, with a typed platform refusal when one was supplied."""

    def __init__(self, rpc_code: str, message: str, refusal: Refusal | None) -> None:
        self.rpc_code = rpc_code
        self.message = message
        self.refusal = refusal
        detail = "" if refusal is None else f" ({refusal.code}, trace {refusal.trace_id})"
        super().__init__(f"RPC {rpc_code}: {message}{detail}")
