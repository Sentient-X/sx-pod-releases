"""Generated Taskpedia authoring client for the admitted CLI and MCP surface."""

from __future__ import annotations

from collections.abc import Mapping

from connectrpc.errors import ConnectError
from google.protobuf.json_format import ParseDict, ParseError
from google.protobuf.message import Message
from sentientx.sx.experience.taskpedia.v1 import taskpedia_connect, taskpedia_pb2

from sx._errors import OperationProtocolError
from sx._rpc import raise_rpc, validated
from sx._transport import RpcBinding

_RPC_TIMEOUT_MS = 30_000


def _parse[MessageT: Message](
    value: Mapping[str, object], message: MessageT, *, label: str
) -> MessageT:
    """Parse protobuf JSON strictly at the human-authored CLI/MCP edge."""

    try:
        ParseDict(dict(value), message, ignore_unknown_fields=False)
    except (ParseError, TypeError, ValueError) as error:
        raise OperationProtocolError(f"{label} is malformed: {error}") from error
    return validated(message, label=label)


class TaskAuthoringOwnerClient:
    """The generated client for Taskpedia's bounded agent authoring projection."""

    def __init__(self, binding: RpcBinding) -> None:
        self._headers = binding.headers
        self._client = taskpedia_connect.TaskAuthoringServiceClient(binding.address)

    async def close(self) -> None:
        await self._client.close()

    async def opportunities(
        self, request: Mapping[str, object]
    ) -> tuple[taskpedia_pb2.TaskOpportunity, ...]:
        message = _parse(
            request,
            taskpedia_pb2.SearchTaskOpportunitiesRequest(),
            label="Taskpedia opportunity request",
        )
        try:
            response = await self._client.search_task_opportunities(
                message,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            raise_rpc(error)
        return tuple(validated(response, label="Taskpedia opportunity response").opportunities)

    async def draft(self, draft_id: str) -> taskpedia_pb2.TaskDraft:
        request = validated(
            taskpedia_pb2.GetTaskDraftRequest(draft_id=draft_id),
            label="Taskpedia draft request",
        )
        try:
            response = await self._client.get_task_draft(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            raise_rpc(error)
        return validated(response, label="Taskpedia draft response").draft

    async def check(self, draft_id: str) -> taskpedia_pb2.TaskDraftEvaluation:
        request = validated(
            taskpedia_pb2.CheckTaskDraftRequest(draft_id=draft_id),
            label="Taskpedia check request",
        )
        try:
            response = await self._client.check_task_draft(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            raise_rpc(error)
        return validated(response, label="Taskpedia check response").evaluation

    async def propose(
        self, draft_id: str, proposal: Mapping[str, object]
    ) -> taskpedia_pb2.TaskDraftProposal:
        request = _parse(
            {**proposal, "draft_id": draft_id},
            taskpedia_pb2.CreateTaskDraftProposalRequest(),
            label="Taskpedia proposal request",
        )
        try:
            response = await self._client.create_task_draft_proposal(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            raise_rpc(error)
        return validated(response, label="Taskpedia proposal response").proposal
