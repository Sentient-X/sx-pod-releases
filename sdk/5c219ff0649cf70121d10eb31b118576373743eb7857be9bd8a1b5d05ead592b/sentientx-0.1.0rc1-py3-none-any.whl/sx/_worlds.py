"""Generated Worlds control-plane client and its canonical result crossings."""

from __future__ import annotations

import json
from collections.abc import Awaitable, Callable, Iterable, Mapping
from datetime import UTC, datetime, timedelta
from pathlib import PurePosixPath

from connectrpc.errors import ConnectError
from google.protobuf.json_format import MessageToJson
from google.protobuf.timestamp_pb2 import Timestamp
from sentientx.sx.common.v1 import assets_pb2, common_pb2
from sentientx.sx.worlds.controlplane.v1 import controlplane_connect, controlplane_pb2
from sx_contracts import (
    AcceptedOperation,
    CancelledOperation,
    FailedOperation,
    IdempotencyKey,
    OperationFailure,
    OperationId,
    OperationKind,
    OperationProgress,
    OperationReceipt,
    OperationRef,
    PlatformPillar,
    RunningOperation,
    Sha256Digest,
    SucceededOperation,
    TaskContractRef,
    TaskId,
    TaskSchemaVersion,
    TraceId,
    UpdateCursor,
)
from sx_contracts.assets import AssetFormat, AssetRef, AssetRole
from sx_contracts.content import ContentBlob
from sx_contracts.decisions import (
    DecisionIdentity,
    EffectIdentity,
    GoalVerificationReceipt,
    ObservationSequence,
    VerifierIdentity,
)
from sx_contracts.identity import freeze_json
from sx_contracts.outcomes import TaskVerdict
from sx_worlds import (
    ApplicationGenerationSource,
    AssetClosure,
    EngineConfigId,
    EnvironmentBundle,
    EnvironmentFacts,
    EnvironmentPlacement,
    EnvironmentSettlement,
    EnvironmentSource,
    Generation,
    GenerationSource,
    MimicGenSource,
    ObjectAssetBundle,
    ObjectAssetFacts,
    ObjectAssetSettlement,
    ObjectAssetSource,
    ObjectBounds,
    PolicyArtifactKind,
    PolicyArtifactRef,
    RobotPartCandidate,
    ScanSeed,
    Scene,
    SceneArticulation,
    SceneContractError,
    SceneJointKind,
    ScriptedDecisionKind,
    ScriptedGenerationSource,
    SessionImageResult,
    SessionJsonResult,
    SessionStepReceipt,
    SimulationJobFamily,
    SimulationResourceBand,
    Simulator,
    SimulatorCapability,
    SplatReport,
    WorldEvidenceError,
    WorldSession,
    WorldSessionClose,
    WorldSessionFailure,
    WorldSessionState,
    evaluation_progress_from_dict,
    generation_from_dict,
    generation_progress_from_dict,
    robot_part_candidate_from_dict,
    scene_from_dict,
)

from sx._codec import read_only_progress
from sx._errors import OperationHistoryGapError, OperationProtocolError
from sx._rpc import cancellation_from_proto as _cancellation
from sx._rpc import history_gap_cursor as _history_gap_cursor
from sx._rpc import raise_rpc as _raise_rpc
from sx._rpc import resource_from_proto as _resource
from sx._rpc import validated as _validated
from sx._transport import RpcBinding

_RPC_TIMEOUT_MS = 30_000

type WorldsResult = (
    controlplane_pb2.WorldEvaluation
    | Generation
    | EnvironmentBundle
    | ObjectAssetBundle
    | RobotPartCandidate
    | ScanSeed
)

type WorldsResultDecoder[ResultT] = Callable[
    [WorldsOwnerClient, controlplane_pb2.WorldsOperationResult, str],
    Awaitable[ResultT],
]


async def _call[ResponseT](awaitable: Awaitable[ResponseT]) -> ResponseT:
    """Await one generated call and keep Connect's error mapping in one place."""

    try:
        return await awaitable
    except ConnectError as error:
        _raise_rpc(error)


_KINDS_TO_PROTO = {
    OperationKind.EVALUATION: common_pb2.OPERATION_KIND_EVALUATION,
    OperationKind.GENERATION: common_pb2.OPERATION_KIND_GENERATION,
    OperationKind.AUTHORING: common_pb2.OPERATION_KIND_AUTHORING,
}
_KINDS_FROM_PROTO = {number: value for value, number in _KINDS_TO_PROTO.items()}
_SIMULATORS = {
    Simulator.MUJOCO: controlplane_pb2.SIMULATOR_MUJOCO,
    Simulator.ISAAC_LAB_NEWTON: controlplane_pb2.SIMULATOR_ISAAC_LAB_NEWTON,
}
_SIMULATORS_FROM = {number: value for value, number in _SIMULATORS.items()}
_SIMULATION_JOBS = {
    controlplane_pb2.SIMULATION_JOB_FAMILY_SESSION: SimulationJobFamily.SESSION,
    controlplane_pb2.SIMULATION_JOB_FAMILY_EVALUATION: SimulationJobFamily.EVALUATION,
    controlplane_pb2.SIMULATION_JOB_FAMILY_GENERATION: SimulationJobFamily.GENERATION,
}
_SIMULATION_BANDS = {
    controlplane_pb2.SIMULATION_RESOURCE_BAND_CPU: SimulationResourceBand.CPU,
    controlplane_pb2.SIMULATION_RESOURCE_BAND_GPU: SimulationResourceBand.GPU,
}
_SESSION_STATES = {
    controlplane_pb2.WORLD_SESSION_STATE_STARTING: WorldSessionState.STARTING,
    controlplane_pb2.WORLD_SESSION_STATE_READY: WorldSessionState.READY,
    controlplane_pb2.WORLD_SESSION_STATE_CLOSING: WorldSessionState.CLOSING,
    controlplane_pb2.WORLD_SESSION_STATE_CLOSED: WorldSessionState.CLOSED,
    controlplane_pb2.WORLD_SESSION_STATE_EXPIRED: WorldSessionState.EXPIRED,
    controlplane_pb2.WORLD_SESSION_STATE_SAFETY_STOPPED: WorldSessionState.SAFETY_STOPPED,
    controlplane_pb2.WORLD_SESSION_STATE_FAILED: WorldSessionState.FAILED,
}
_VERIFICATION_STATES = {
    controlplane_pb2.SESSION_VERIFICATION_STATUS_SATISFIED: TaskVerdict.SATISFIED,
    controlplane_pb2.SESSION_VERIFICATION_STATUS_NOT_SATISFIED: (TaskVerdict.NOT_SATISFIED),
    controlplane_pb2.SESSION_VERIFICATION_STATUS_UNKNOWN: TaskVerdict.UNKNOWN,
}


_POLICY_KINDS = {
    PolicyArtifactKind.CODE_POLICY: controlplane_pb2.POLICY_ARTIFACT_KIND_CODE_POLICY,
    PolicyArtifactKind.POLICY_GRAPH: controlplane_pb2.POLICY_ARTIFACT_KIND_POLICY_GRAPH,
}
_SCRIPTED_KINDS = {
    ScriptedDecisionKind.PICK: controlplane_pb2.SCRIPTED_DECISION_KIND_PICK,
    ScriptedDecisionKind.PLACE: controlplane_pb2.SCRIPTED_DECISION_KIND_PLACE,
    ScriptedDecisionKind.TRANSFER: controlplane_pb2.SCRIPTED_DECISION_KIND_TRANSFER,
    ScriptedDecisionKind.VLA: controlplane_pb2.SCRIPTED_DECISION_KIND_VLA,
}
_SEED_SELECTIONS = {
    "random": controlplane_pb2.SEED_SELECTION_RANDOM,
    "nearest_neighbor_object": controlplane_pb2.SEED_SELECTION_NEAREST_NEIGHBOR_OBJECT,
    "nearest_neighbor_robot_distance": (
        controlplane_pb2.SEED_SELECTION_NEAREST_NEIGHBOR_ROBOT_DISTANCE
    ),
}
_ASSET_FORMATS = {
    assets_pb2.ASSET_FORMAT_URDF: AssetFormat.URDF,
    assets_pb2.ASSET_FORMAT_SRDF: AssetFormat.SRDF,
    assets_pb2.ASSET_FORMAT_SDF: AssetFormat.SDF,
    assets_pb2.ASSET_FORMAT_STEP: AssetFormat.STEP,
    assets_pb2.ASSET_FORMAT_MJCF: AssetFormat.MJCF,
    assets_pb2.ASSET_FORMAT_USD: AssetFormat.USD,
    assets_pb2.ASSET_FORMAT_USDA: AssetFormat.USDA,
    assets_pb2.ASSET_FORMAT_USDC: AssetFormat.USDC,
    assets_pb2.ASSET_FORMAT_USDZ: AssetFormat.USDZ,
    assets_pb2.ASSET_FORMAT_MESH: AssetFormat.MESH,
    assets_pb2.ASSET_FORMAT_SPLAT: AssetFormat.SPLAT,
    assets_pb2.ASSET_FORMAT_CALIBRATION: AssetFormat.CALIBRATION,
    assets_pb2.ASSET_FORMAT_OTHER: AssetFormat.OTHER,
}
_ASSET_ROLES = {
    assets_pb2.ASSET_ROLE_DESCRIPTION: AssetRole.DESCRIPTION,
    assets_pb2.ASSET_ROLE_GEOMETRY: AssetRole.GEOMETRY,
    assets_pb2.ASSET_ROLE_COLLISION: AssetRole.COLLISION,
    assets_pb2.ASSET_ROLE_CALIBRATION: AssetRole.CALIBRATION,
    assets_pb2.ASSET_ROLE_TEXTURE: AssetRole.TEXTURE,
    assets_pb2.ASSET_ROLE_LICENSE: AssetRole.LICENSE,
    assets_pb2.ASSET_ROLE_OTHER: AssetRole.OTHER,
}
_ENVIRONMENT_SOURCES = {
    controlplane_pb2.ENVIRONMENT_SOURCE_XGRIDS_SCAN: EnvironmentSource.XGRIDS_SCAN,
    controlplane_pb2.ENVIRONMENT_SOURCE_MARBLE_GENERATION: EnvironmentSource.MARBLE_GENERATION,
    controlplane_pb2.ENVIRONMENT_SOURCE_TRELLIS_RECONSTRUCTION: (
        EnvironmentSource.TRELLIS_RECONSTRUCTION
    ),
    controlplane_pb2.ENVIRONMENT_SOURCE_SCENESMITH_GENERATION: (
        EnvironmentSource.SCENESMITH_GENERATION
    ),
    controlplane_pb2.ENVIRONMENT_SOURCE_MOLMOSPACES_GENERATION: (
        EnvironmentSource.MOLMOSPACES_GENERATION
    ),
    controlplane_pb2.ENVIRONMENT_SOURCE_LITEREALITY_GENERATION: (
        EnvironmentSource.LITEREALITY_GENERATION
    ),
}
_OBJECT_SOURCES = {
    controlplane_pb2.OBJECT_ASSET_SOURCE_TRELLIS_2: ObjectAssetSource.TRELLIS_2,
    controlplane_pb2.OBJECT_ASSET_SOURCE_ARTICULATED_AUTHORING: (
        ObjectAssetSource.ARTICULATED_AUTHORING
    ),
}
_JOINT_KINDS = {
    controlplane_pb2.SCENE_JOINT_KIND_HINGE: SceneJointKind.HINGE,
    controlplane_pb2.SCENE_JOINT_KIND_SLIDE: SceneJointKind.SLIDE,
}


def _task_ref(ref: TaskContractRef) -> common_pb2.TaskContractRef:
    return common_pb2.TaskContractRef(
        task_id=str(ref.task_id),
        schema_version=str(ref.schema_version),
        sha256=str(ref.sha256),
    )


def _task_ref_from(message: common_pb2.TaskContractRef) -> TaskContractRef:
    return TaskContractRef(
        TaskId(message.task_id),
        TaskSchemaVersion(message.schema_version),
        Sha256Digest(message.sha256),
    )


def _operation_ref(ref: OperationRef[object, object]) -> common_pb2.OperationRef:
    if ref.pillar is not PlatformPillar.WORLDS or ref.kind not in _KINDS_TO_PROTO:
        raise OperationProtocolError(f"Worlds cannot own {ref}")
    return common_pb2.OperationRef(
        pillar=common_pb2.PLATFORM_PILLAR_WORLDS,
        kind=_KINDS_TO_PROTO[ref.kind],
        operation_id=str(ref.operation_id),
    )


def _datetime(value: Timestamp) -> datetime:
    return value.ToDatetime(tzinfo=UTC)


def _progress(value: controlplane_pb2.WorldsOperation) -> Mapping[str, object] | None:
    arm = value.WhichOneof("progress")
    if arm is None:
        return None
    if arm == "evaluation_progress":
        progress = value.evaluation_progress
        return {
            "completed_cases": progress.completed_cases,
            "total_cases": progress.total_cases,
            "current_case": progress.current_case if progress.HasField("current_case") else None,
        }
    if arm == "generation_progress":
        progress = value.generation_progress
        return {
            "completed_attempts": progress.completed_attempts,
            "total_attempts": progress.total_attempts,
            "registered_episodes": progress.registered_episodes,
        }
    if arm == "authoring_progress":
        progress = value.authoring_progress
        return {
            "stage": progress.stage,
            "completed_stages": progress.completed_stages,
            "total_stages": progress.total_stages,
            "note": progress.note,
        }
    raise OperationProtocolError(f"Worlds returned unknown progress arm {arm!r}")


def _receipt(value: controlplane_pb2.WorldsOperation) -> OperationReceipt:
    _validated(value, label="Worlds operation")
    metadata = value.metadata
    ref = metadata.ref
    if ref.pillar != common_pb2.PLATFORM_PILLAR_WORLDS:
        raise OperationProtocolError("Worlds returned a non-Worlds operation")
    try:
        kind = _KINDS_FROM_PROTO[ref.kind]
    except KeyError as error:
        raise OperationProtocolError("Worlds returned an unsupported operation kind") from error
    operation_id = OperationId(ref.operation_id)
    resource = _resource(metadata.resource)
    trace_id = TraceId(metadata.trace_id)
    cursor = UpdateCursor(metadata.cursor)
    key = IdempotencyKey(metadata.idempotency_key) if metadata.HasField("idempotency_key") else None
    progress = _progress(value)
    created_at = _datetime(metadata.created_at)
    updated_at = _datetime(metadata.updated_at)
    arm = value.lifecycle.WhichOneof("state")
    if arm == "accepted":
        return AcceptedOperation(
            operation_id,
            PlatformPillar.WORLDS,
            kind,
            resource,
            trace_id,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            cancellation=_cancellation(value.lifecycle.accepted),
            created_at=created_at,
            updated_at=updated_at,
        )
    if arm == "running":
        return RunningOperation(
            operation_id,
            PlatformPillar.WORLDS,
            kind,
            resource,
            trace_id,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            cancellation=_cancellation(value.lifecycle.running),
            created_at=created_at,
            updated_at=updated_at,
        )
    if arm == "succeeded":
        return SucceededOperation(
            operation_id,
            PlatformPillar.WORLDS,
            kind,
            resource,
            trace_id,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            created_at=created_at,
            updated_at=updated_at,
            completed_at=_datetime(value.lifecycle.succeeded.completed_at),
        )
    if arm == "failed":
        failure = value.lifecycle.failed
        return FailedOperation(
            operation_id,
            PlatformPillar.WORLDS,
            kind,
            resource,
            trace_id,
            OperationFailure(
                failure.failure.code,
                failure.failure.message,
                failure.failure.retryable,
            ),
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            created_at=created_at,
            updated_at=updated_at,
            failed_at=_datetime(failure.failed_at),
        )
    if arm == "cancelled":
        cancelled = value.lifecycle.cancelled
        return CancelledOperation(
            operation_id,
            PlatformPillar.WORLDS,
            kind,
            resource,
            trace_id,
            cancelled.reason,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            created_at=created_at,
            updated_at=updated_at,
            cancelled_at=_datetime(cancelled.cancelled_at),
        )
    raise OperationProtocolError(f"Worlds returned unknown lifecycle arm {arm!r}")


def _receipt_for(
    expected: OperationRef[object, object], value: controlplane_pb2.WorldsOperation
) -> OperationReceipt:
    receipt = _receipt(value)
    if receipt.ref != expected:
        raise OperationProtocolError(
            f"Worlds returned {receipt.ref} while {expected} was requested"
        )
    return receipt


def _subject(subject: PolicyArtifactRef | None) -> controlplane_pb2.EvaluationSubject:
    if subject is None:
        return controlplane_pb2.EvaluationSubject(zero_action=controlplane_pb2.ZeroActionSubject())
    return controlplane_pb2.EvaluationSubject(
        artifact=controlplane_pb2.PolicyArtifactSubject(
            kind=_POLICY_KINDS[subject.kind],
            artifact=common_pb2.ContentRef(
                artifact_id=str(subject.artifact.artifact_id),
                sha256=str(subject.artifact.sha256),
            ),
        )
    )


def _generation_source(source: GenerationSource) -> controlplane_pb2.GenerationSource:
    if isinstance(source, ScriptedGenerationSource):
        script = source.script
        return controlplane_pb2.GenerationSource(
            scripted=controlplane_pb2.ScriptedGenerationSource(
                script=controlplane_pb2.ScriptedSource(
                    steps=tuple(
                        controlplane_pb2.ScriptedStep(
                            kind=_SCRIPTED_KINDS[step.kind],
                            **(
                                {"object_name": step.object_name}
                                if step.object_name is not None
                                else {}
                            ),
                            **(
                                {"target_name": step.target_name}
                                if step.target_name is not None
                                else {}
                            ),
                            **(
                                {"instruction": step.instruction}
                                if step.instruction is not None
                                else {}
                            ),
                        )
                        for step in script.steps
                    ),
                    replan_interval=controlplane_pb2.ReplanInterval(
                        chunks=script.replan_interval.chunks,
                        wall_ms=script.replan_interval.wall_ms,
                    ),
                    retry_budget=script.retry_budget,
                )
            )
        )
    if isinstance(source, ApplicationGenerationSource):
        return controlplane_pb2.GenerationSource(
            application=controlplane_pb2.ApplicationGenerationSource(
                application_ref=str(source.application.ref),
                replan_horizon=source.replan_horizon,
            )
        )
    if isinstance(source, MimicGenSource):
        return controlplane_pb2.GenerationSource(
            mimicgen=controlplane_pb2.MimicGenSource(
                seed_segments=tuple(
                    controlplane_pb2.CatalogSegmentRef(
                        dataset_id=str(segment.dataset_id),
                        segment_id=str(segment.segment_id),
                        base_sha256=str(segment.base_sha256),
                    )
                    for segment in source.seed_segments
                ),
                position_jitter_m=source.position_jitter_m,
                rotation_jitter_rad=source.rotation_jitter_rad,
                selection=_SEED_SELECTIONS[source.selection.value],
            )
        )
    return controlplane_pb2.GenerationSource(agentic=controlplane_pb2.AgenticSceneSource())


def _triple(values: Iterable[float], *, label: str) -> tuple[float, float, float]:
    items = tuple(float(value) for value in values)
    if len(items) != 3:
        raise OperationProtocolError(f"{label} must carry exactly three components")
    return items[0], items[1], items[2]


def _quad(values: Iterable[float], *, label: str) -> tuple[float, float, float, float]:
    items = tuple(float(value) for value in values)
    if len(items) != 4:
        raise OperationProtocolError(f"{label} must carry exactly four components")
    return items[0], items[1], items[2], items[3]


def _asset(message: assets_pb2.AssetRef) -> AssetRef:
    try:
        asset_format = _ASSET_FORMATS[message.format]
        role = _ASSET_ROLES[message.role]
    except KeyError as error:
        raise OperationProtocolError("Worlds returned an unknown asset enum") from error
    return AssetRef(
        location=message.location,
        content=ContentBlob(
            sha256=Sha256Digest(message.content.sha256),
            size_bytes=message.content.size_bytes,
        ),
        format=asset_format,
        role=role,
        media_type=message.media_type if message.HasField("media_type") else None,
        logical_path=(
            PurePosixPath(message.logical_path) if message.HasField("logical_path") else None
        ),
    )


def _closure(message: controlplane_pb2.AssetClosure) -> AssetClosure:
    return AssetClosure(_asset(message.root), tuple(_asset(member) for member in message.members))


def _environment(message: controlplane_pb2.EnvironmentBundle) -> EnvironmentBundle:
    try:
        source = _ENVIRONMENT_SOURCES[message.facts.source]
    except KeyError as error:
        raise OperationProtocolError("Worlds returned an unknown environment source") from error
    facts = message.facts
    bundle = EnvironmentBundle(
        assets=_closure(message.assets),
        facts=EnvironmentFacts(
            source=source,
            source_ref=facts.source_ref,
            placement=EnvironmentPlacement(
                quaternion_wxyz=_quad(
                    facts.placement.quaternion_wxyz, label="environment quaternion"
                ),
                scale=facts.placement.scale,
                translation_xyz=_triple(
                    facts.placement.translation_xyz, label="environment translation"
                ),
            ),
            name=facts.name,
            description=facts.description,
            license_id=facts.license_id,
            tags=tuple(facts.tags),
            source_uri=facts.source_uri if facts.HasField("source_uri") else None,
        ),
        settlement=EnvironmentSettlement(
            mjcf_sha256=Sha256Digest(message.settlement.mjcf_sha256),
            geoms=message.settlement.geoms,
            meshes=message.settlement.meshes,
            steps=message.settlement.steps,
            engine=message.settlement.engine,
        ),
    )
    if str(bundle.id) != message.environment_id:
        raise OperationProtocolError("Worlds environment id disagrees with its canonical content")
    return bundle


def _object_asset(message: controlplane_pb2.ObjectAssetBundle) -> ObjectAssetBundle:
    try:
        source = _OBJECT_SOURCES[message.facts.source]
    except KeyError as error:
        raise OperationProtocolError("Worlds returned an unknown object source") from error
    articulation: list[SceneArticulation] = []
    for item in message.facts.articulation:
        try:
            kind = _JOINT_KINDS[item.kind]
        except KeyError as error:
            raise OperationProtocolError("Worlds returned an unknown joint kind") from error
        articulation.append(
            SceneArticulation(item.name, item.joint, kind, item.lower, item.upper, item.home)
        )
    facts = message.facts
    bundle = ObjectAssetBundle(
        assets=_closure(message.assets),
        facts=ObjectAssetFacts(
            source=source,
            source_ref=facts.source_ref,
            producer_model=facts.producer_model,
            name=facts.name,
            description=facts.description,
            category=facts.category,
            license_id=facts.license_id,
            longest_dimension_m=facts.longest_dimension_m,
            mass_kg=facts.mass_kg,
            bounds=ObjectBounds(
                center_xyz=_triple(facts.bounds.center_xyz, label="object bounds center"),
                half_extents_xyz=_triple(
                    facts.bounds.half_extents_xyz, label="object bounds half extents"
                ),
            ),
            tags=tuple(facts.tags),
            articulation=tuple(articulation),
        ),
        settlement=ObjectAssetSettlement(
            mjcf_sha256=Sha256Digest(message.settlement.mjcf_sha256),
            geoms=message.settlement.geoms,
            collision_geoms=message.settlement.collision_geoms,
            meshes=message.settlement.meshes,
            joints=message.settlement.joints,
            steps=message.settlement.steps,
            engine=message.settlement.engine,
        ),
    )
    if str(bundle.id) != message.object_asset_id:
        raise OperationProtocolError("Worlds object id disagrees with its canonical content")
    return bundle


def _scan_seed(message: controlplane_pb2.ScanSeed) -> ScanSeed:
    return ScanSeed(
        scan_id=message.scan_id,
        run_id=message.run_id,
        objects=message.objects,
        stages=tuple(message.stages),
        splat=SplatReport(
            psnr=message.splat.psnr,
            gaussians=message.splat.gaussians,
            iterations=message.splat.iterations,
        ),
    )


def _simulator_capability(
    message: controlplane_pb2.SimulatorCapability,
) -> SimulatorCapability:
    _validated(message, label="Worlds simulator capability")
    try:
        simulator = _SIMULATORS_FROM[message.simulator]
        job = _SIMULATION_JOBS[message.job]
        resource_band = _SIMULATION_BANDS[message.resource_band]
    except KeyError as error:
        raise OperationProtocolError("Worlds returned an unknown simulator capability") from error
    return SimulatorCapability(
        simulator=simulator,
        job=job,
        resource_band=resource_band,
        available=message.available,
        reason=message.reason if message.HasField("reason") else None,
    )


def _session(message: controlplane_pb2.WorldSession) -> WorldSession:
    _validated(message, label="Worlds session")
    try:
        simulator = _SIMULATORS_FROM[message.simulator]
        state = _SESSION_STATES[message.state]
    except KeyError as error:
        raise OperationProtocolError("Worlds returned an unknown session enum") from error

    close: WorldSessionClose | None = None
    failure: WorldSessionFailure | None = None
    outcome = message.WhichOneof("outcome")
    if outcome == "close":
        evidence = message.close.WhichOneof("evidence")
        if evidence not in {"episode_segment", "reason"}:
            raise OperationProtocolError("Worlds returned a session close without evidence")
        close = WorldSessionClose(
            success=message.close.success,
            steps=message.close.steps,
            episode_segment=(
                message.close.episode_segment if evidence == "episode_segment" else None
            ),
            reason=message.close.reason if evidence == "reason" else None,
        )
    elif outcome == "failure":
        failure = WorldSessionFailure(
            code=message.failure.code,
            message=message.failure.message,
            retryable=message.failure.retryable,
        )
    elif outcome is not None:
        raise OperationProtocolError(f"Worlds returned unknown session outcome {outcome!r}")

    return WorldSession(
        session_id=message.session_id,
        task=_task_ref_from(message.task),
        simulator=simulator,
        engine_config_id=EngineConfigId(message.engine_config_id),
        allocation_ref=message.allocation_ref,
        operation_ref=message.operation_ref,
        state=state,
        expires_at=_datetime(message.expires_at),
        observation_sequence=message.observation_sequence,
        tools=tuple(message.tools),
        evidence_refs=tuple(message.evidence_refs),
        usage_ref=message.usage_ref if message.HasField("usage_ref") else None,
        close=close,
        failure=failure,
    )


def _step_result(message: controlplane_pb2.StepSessionResponse) -> SessionStepReceipt:
    _validated(message, label="Worlds session step")
    arm = message.result.WhichOneof("result")
    if arm == "json":
        result = SessionJsonResult(
            freeze_json(json.loads(MessageToJson(message.result.json.value)))
        )
    elif arm == "image":
        result = SessionImageResult(
            dtype=message.result.image.dtype,
            shape=tuple(message.result.image.shape),
            png=message.result.image.png,
        )
    else:
        raise OperationProtocolError(f"Worlds returned unknown session result arm {arm!r}")
    return SessionStepReceipt(
        step_id=message.step_id,
        previous_observation_sequence=message.previous_observation_sequence,
        observation_sequence=message.observation_sequence,
        replayed=message.replayed,
        result=result,
    )


def _decision_message(value: DecisionIdentity) -> controlplane_pb2.SessionDecisionIdentity:
    return controlplane_pb2.SessionDecisionIdentity(
        environment_generation=value.environment_generation,
        effect=controlplane_pb2.SessionEffectIdentity(
            effect_id=value.effect.effect_id,
            request_sha256=str(value.effect.request_digest),
        ),
        goal_id=value.goal_id,
        goal_revision=value.goal_revision,
        decision_id=value.decision_id,
    )


def _verification(message: controlplane_pb2.VerifySessionResponse) -> GoalVerificationReceipt:
    _validated(message, label="Worlds session verification")
    try:
        status = _VERIFICATION_STATES[message.status]
        state = _SESSION_STATES[message.evidence.state]
    except KeyError as error:
        raise OperationProtocolError("Worlds returned an unknown verification enum") from error
    decision = DecisionIdentity(
        environment_generation=message.decision.environment_generation,
        effect=EffectIdentity(
            effect_id=message.decision.effect.effect_id,
            request_digest=Sha256Digest(message.decision.effect.request_sha256),
        ),
        goal_id=message.decision.goal_id,
        goal_revision=message.decision.goal_revision,
        decision_id=message.decision.decision_id,
    )
    task = _task_ref_from(message.evidence.task)
    return GoalVerificationReceipt(
        decision=decision,
        status=status,
        summary=message.summary,
        observation_sequence=ObservationSequence(message.observation_sequence),
        verifier=VerifierIdentity(message.verifier.name, message.verifier.version),
        evidence={
            "session_id": message.evidence.session_id,
            "task": {
                "task_id": str(task.task_id),
                "schema_version": str(task.schema_version),
                "sha256": str(task.sha256),
            },
            "state": state.value,
        },
    )


_RESULT_RESOURCE_KINDS = {
    "evaluation": "worlds-eval",
    "generation": "world-generation",
    "environment": "world-authoring",
    "object_asset": "object-authoring",
    "robot_part_candidate": "robot-part-authoring",
    "scan_seed": "scan-seed",
}


def _result_origin(
    response: controlplane_pb2.GetWorldsOperationResultResponse,
    ref: OperationRef[object, object],
    arm: str,
) -> str:
    if response.operation != _operation_ref(ref):
        raise OperationProtocolError(f"Worlds returned a result for another operation than {ref}")
    resource = response.resource
    expected_kind = _RESULT_RESOURCE_KINDS[arm]
    if resource.owner != "worlds" or resource.kind != expected_kind:
        raise OperationProtocolError(
            f"Worlds returned {resource.owner}/{resource.kind} for a {arm} result"
        )
    return f"{resource.kind}:{resource.id}"


#: The typed ledger each Worlds family publishes. A family absent here has no shared
#: progress value yet and answers with the owner's own mapping.
_KIND_PROGRESS: Mapping[OperationKind, Callable[[OperationProgress], object]] = {
    OperationKind.EVALUATION: evaluation_progress_from_dict,
    OperationKind.GENERATION: generation_progress_from_dict,
}

type WorldsProgressDecoder[ProgressT] = Callable[[OperationProgress], ProgressT]


class WorldsResultClient[ResultT, ProgressT]:
    """One expected result *and* progress arm over the shared Worlds operation owner.

    Worlds runs four families through one durable ledger, so the family is chosen here
    rather than at the owner: this is the object a façade method hands to `Operation`,
    and carrying both decoders is what lets Pyright check that method's
    `Operation[ResultT, ProgressT]` annotation instead of trusting it.
    """

    def __init__(
        self,
        owner: WorldsOwnerClient,
        expected: str,
        decoder: WorldsResultDecoder[ResultT],
        progress: WorldsProgressDecoder[ProgressT],
    ) -> None:
        self._owner = owner
        self._expected = expected
        self._decoder = decoder
        self._progress = progress

    def progress(self, receipt: OperationReceipt) -> ProgressT | None:
        if receipt.progress is None:
            return None
        return self._progress(receipt.progress)

    async def status(self, ref: OperationRef[object, object]) -> OperationReceipt:
        return await self._owner.status(ref)

    async def updates(
        self,
        ref: OperationRef[object, object],
        *,
        after: UpdateCursor | None,
        page_size: int,
        wait_s: float,
    ) -> tuple[OperationReceipt, ...]:
        return await self._owner.updates(
            ref,
            after=after,
            page_size=page_size,
            wait_s=wait_s,
        )

    async def cancel(self, ref: OperationRef[object, object], *, reason: str) -> OperationReceipt:
        return await self._owner.cancel(ref, reason=reason)

    async def result(self, ref: OperationRef[object, object]) -> ResultT:
        response = await self._owner.result_response(ref)
        result = response.result
        arm = result.WhichOneof("result")
        if arm != self._expected:
            raise OperationProtocolError(
                f"Worlds returned {arm!r} while {self._expected!r} was requested"
            )
        return await self._decoder(self._owner, result, _result_origin(response, ref, arm))


class WorldsOwnerClient:
    """Generated Connect client for Worlds' shared durable operation ledger."""

    def __init__(self, binding: RpcBinding) -> None:
        self._headers = binding.headers
        self._client = controlplane_connect.WorldsControlPlaneServiceClient(binding.address)

    async def close(self) -> None:
        await self._client.close()

    def typed[ResultT, ProgressT](
        self,
        expected: str,
        decoder: WorldsResultDecoder[ResultT],
        progress: WorldsProgressDecoder[ProgressT],
    ) -> WorldsResultClient[ResultT, ProgressT]:
        return WorldsResultClient(self, expected, decoder, progress)

    def progress(self, receipt: OperationReceipt) -> object | None:
        """The reattach projection: the family is read off the receipt, not chosen.

        `Sx.operation` hands back a handle built from a bare `OperationRef`, so the
        caller — not this client — names `ProgressT`, and no assignment here can be
        checked against it. What is checked is that the *value* matches the receipt's
        own kind, which is the only family fact a reattached handle carries.
        """

        if receipt.progress is None:
            return None
        decoder = _KIND_PROGRESS.get(receipt.kind)
        if decoder is None:
            return read_only_progress(receipt.progress)
        return decoder(receipt.progress)

    def _admission_headers(self, idempotency_key: str) -> dict[str, str]:
        headers = dict(self._headers)
        headers["Idempotency-Key"] = idempotency_key
        return headers

    async def start_application_evaluation(
        self,
        task: TaskContractRef,
        *,
        application_ref: str,
        seed: int | None,
        timeout: timedelta,
        idempotency_key: str,
    ) -> OperationReceipt:
        request = controlplane_pb2.StartApplicationEvaluationRequest(
            task=_task_ref(task), application_ref=application_ref, timeout=timeout
        )
        if seed is not None:
            request.seed = seed
        _validated(request, label="application evaluation admission")
        response = await _call(
            self._client.start_application_evaluation(
                request,
                headers=self._admission_headers(idempotency_key),
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        )
        return _receipt(
            _validated(response, label="application evaluation admission response").operation
        )

    async def start_subject_evaluation(
        self,
        task: TaskContractRef,
        *,
        subject: PolicyArtifactRef | None,
        seed: int | None,
        timeout: timedelta,
        idempotency_key: str,
    ) -> OperationReceipt:
        request = controlplane_pb2.StartSubjectEvaluationRequest(
            task=_task_ref(task), subject=_subject(subject), timeout=timeout
        )
        if seed is not None:
            request.seed = seed
        _validated(request, label="subject evaluation admission")
        response = await _call(
            self._client.start_subject_evaluation(
                request,
                headers=self._admission_headers(idempotency_key),
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        )
        return _receipt(
            _validated(response, label="subject evaluation admission response").operation
        )

    async def start_generation(
        self,
        task: TaskContractRef,
        *,
        source: GenerationSource,
        simulator: Simulator,
        count: int,
        dataset: str,
        seed: int | None,
        timeout: timedelta,
        idempotency_key: str,
    ) -> OperationReceipt:
        request = controlplane_pb2.StartGenerationRequest(
            task=_task_ref(task),
            simulator=_SIMULATORS[simulator],
            source=_generation_source(source),
            count=count,
            dataset=dataset,
            timeout=timeout,
        )
        if seed is not None:
            request.seed = seed
        _validated(request, label="generation admission")
        response = await _call(
            self._client.start_generation(
                request,
                headers=self._admission_headers(idempotency_key),
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        )
        return _receipt(_validated(response, label="generation admission response").operation)

    async def start_environment_authoring(
        self,
        *,
        pano_id: str,
        name: str,
        description: str,
        prompt: str | None,
        quality: controlplane_pb2.EnvironmentAuthoringQuality,
        seed: int | None,
        tags: tuple[str, ...],
        timeout: timedelta,
        idempotency_key: str,
    ) -> OperationReceipt:
        request = controlplane_pb2.StartEnvironmentAuthoringRequest(
            pano_id=pano_id,
            name=name,
            description=description,
            quality=quality,
            tags=tags,
            timeout=timeout,
        )
        if prompt is not None:
            request.prompt = prompt
        if seed is not None:
            request.seed = seed
        _validated(request, label="environment authoring admission")
        response = await _call(
            self._client.start_environment_authoring(
                request,
                headers=self._admission_headers(idempotency_key),
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        )
        return _receipt(
            _validated(response, label="environment authoring admission response").operation
        )

    async def start_object_authoring(
        self,
        *,
        image_id: str,
        name: str,
        description: str,
        category: str,
        longest_dimension_m: float,
        mass_kg: float,
        quality: controlplane_pb2.ObjectAuthoringQuality,
        seed: int | None,
        tags: tuple[str, ...],
        timeout: timedelta,
        idempotency_key: str,
    ) -> OperationReceipt:
        request = controlplane_pb2.StartObjectAuthoringRequest(
            image_id=image_id,
            name=name,
            description=description,
            category=category,
            longest_dimension_m=longest_dimension_m,
            mass_kg=mass_kg,
            quality=quality,
            tags=tags,
            timeout=timeout,
        )
        if seed is not None:
            request.seed = seed
        _validated(request, label="object authoring admission")
        response = await _call(
            self._client.start_object_authoring(
                request,
                headers=self._admission_headers(idempotency_key),
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        )
        return _receipt(_validated(response, label="object authoring admission response").operation)

    async def start_articulated_object_authoring(
        self,
        *,
        prompt: str,
        name: str,
        description: str,
        category: str,
        tags: tuple[str, ...],
        timeout: timedelta,
        idempotency_key: str,
    ) -> OperationReceipt:
        request = _validated(
            controlplane_pb2.StartArticulatedObjectAuthoringRequest(
                prompt=prompt,
                name=name,
                description=description,
                category=category,
                tags=tags,
                timeout=timeout,
            ),
            label="articulated object authoring admission",
        )
        response = await _call(
            self._client.start_articulated_object_authoring(
                request,
                headers=self._admission_headers(idempotency_key),
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        )
        return _receipt(
            _validated(response, label="articulated object authoring admission response").operation
        )

    async def start_robot_part_authoring(
        self,
        *,
        part_id: str,
        geometry_brief: str,
        timeout: timedelta,
        idempotency_key: str,
    ) -> OperationReceipt:
        request = _validated(
            controlplane_pb2.StartRobotPartAuthoringRequest(
                part_id=part_id,
                geometry_brief=geometry_brief,
                timeout=timeout,
            ),
            label="robot-part authoring admission",
        )
        response = await _call(
            self._client.start_robot_part_authoring(
                request,
                headers=self._admission_headers(idempotency_key),
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        )
        return _receipt(
            _validated(response, label="robot-part authoring admission response").operation
        )

    async def start_scan_seed(
        self, *, scan_id: str, timeout: timedelta, idempotency_key: str
    ) -> OperationReceipt:
        request = _validated(
            controlplane_pb2.StartScanSeedRequest(scan_id=scan_id, timeout=timeout),
            label="scan seed admission",
        )
        response = await _call(
            self._client.start_scan_seed(
                request,
                headers=self._admission_headers(idempotency_key),
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        )
        return _receipt(_validated(response, label="scan seed admission response").operation)

    async def start_scan_publish(
        self,
        *,
        scan_id: str,
        name: str,
        description: str,
        tags: tuple[str, ...],
        timeout: timedelta,
        idempotency_key: str,
    ) -> OperationReceipt:
        request = _validated(
            controlplane_pb2.StartScanPublishRequest(
                scan_id=scan_id,
                name=name,
                description=description,
                tags=tags,
                timeout=timeout,
            ),
            label="scan publish admission",
        )
        response = await _call(
            self._client.start_scan_publish(
                request,
                headers=self._admission_headers(idempotency_key),
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        )
        return _receipt(_validated(response, label="scan publish admission response").operation)

    async def preview_task_binding(
        self,
        *,
        canonical_json: str,
        scene_ref: str,
        objects: tuple[tuple[str, str | None], ...],
    ) -> controlplane_pb2.PreviewTaskBindingResponse:
        request = _validated(
            controlplane_pb2.PreviewTaskBindingRequest(
                canonical_json=canonical_json,
                scene_ref=scene_ref,
                objects=tuple(
                    controlplane_pb2.TaskBindingObject(
                        object_id=object_id,
                        **({"object_head": head} if head is not None else {}),
                    )
                    for object_id, head in objects
                ),
            ),
            label="task binding preview",
        )
        try:
            response = await self._client.preview_task_binding(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _validated(response, label="task binding preview response")

    async def get_evaluation(self, evaluation_id: str) -> controlplane_pb2.WorldEvaluation:
        request = _validated(
            controlplane_pb2.GetEvaluationRequest(evaluation_id=evaluation_id),
            label="evaluation read request",
        )
        response = await _call(
            self._client.get_evaluation(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        )
        _validated(response, label="evaluation read response")
        if response.evaluation_id != evaluation_id:
            raise OperationProtocolError("Worlds returned another evaluation resource")
        return response.evaluation

    async def get_generation(
        self, generation_id: str
    ) -> tuple[Generation, controlplane_pb2.Generation]:
        request = _validated(
            controlplane_pb2.GetGenerationRequest(generation_id=generation_id),
            label="generation read request",
        )
        response = await _call(
            self._client.get_generation(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        )
        _validated(response, label="generation read response")
        try:
            generation = generation_from_dict(json.loads(response.canonical_json))
        except (json.JSONDecodeError, WorldEvidenceError) as error:
            raise OperationProtocolError(
                "Worlds returned malformed canonical Generation content"
            ) from error
        if response.generation.generation_id != str(generation.id):
            raise OperationProtocolError(
                "Worlds Generation projection disagrees with its canonical content identity"
            )
        return generation, response.generation

    async def get_robot_part_authoring(self, authoring_id: str) -> RobotPartCandidate:
        request = _validated(
            controlplane_pb2.GetRobotPartAuthoringRequest(authoring_id=authoring_id),
            label="robot-part authoring read request",
        )
        response = await _call(
            self._client.get_robot_part_authoring(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        )
        candidate = _robot_part_candidate(
            _validated(response, label="robot-part authoring read response").candidate
        )
        return candidate

    async def list_environments(self) -> tuple[EnvironmentBundle, ...]:
        request = _validated(
            controlplane_pb2.ListEnvironmentsRequest(), label="environment list request"
        )
        response = await _call(
            self._client.list_environments(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        )
        _validated(response, label="environment list response")
        return tuple(_environment(item) for item in response.environments)

    async def list_scenes(self) -> tuple[Scene, ...]:
        request = _validated(controlplane_pb2.ListScenesRequest(), label="scene list request")
        response = await _call(
            self._client.list_scenes(request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS)
        )
        _validated(response, label="scene list response")
        if not response.HasField("request") or response.request != request:
            raise OperationProtocolError("Worlds returned scenes for another request")
        try:
            return tuple(
                scene_from_dict(json.loads(item.canonical_json)) for item in response.scenes
            )
        except (json.JSONDecodeError, SceneContractError) as error:
            raise OperationProtocolError("Worlds returned a malformed canonical scene") from error

    async def list_object_assets(self) -> tuple[ObjectAssetBundle, ...]:
        request = _validated(
            controlplane_pb2.ListObjectAssetsRequest(), label="object asset list request"
        )
        response = await _call(
            self._client.list_object_assets(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        )
        _validated(response, label="object asset list response")
        return tuple(_object_asset(item) for item in response.object_assets)

    async def list_simulation_runs(self) -> tuple[OperationReceipt, ...]:
        request = _validated(
            controlplane_pb2.ListSimulationRunsRequest(), label="simulation run list request"
        )
        response = await _call(
            self._client.list_simulation_runs(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        )
        if any(
            item.metadata.ref.kind
            not in {
                common_pb2.OPERATION_KIND_EVALUATION,
                common_pb2.OPERATION_KIND_GENERATION,
            }
            for item in response.runs
        ):
            raise OperationProtocolError(
                "Worlds returned a non-simulation operation in the simulation run ledger"
            )
        _validated(response, label="simulation run list response")
        return tuple(_receipt(item) for item in response.runs)

    async def list_simulators(self) -> tuple[SimulatorCapability, ...]:
        request = _validated(
            controlplane_pb2.ListSimulatorsRequest(), label="simulator list request"
        )
        response = await _call(
            self._client.list_simulators(request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS)
        )
        _validated(response, label="simulator list response")
        return tuple(_simulator_capability(item) for item in response.simulators)

    async def open_session(
        self,
        task: TaskContractRef,
        *,
        simulator: Simulator,
        ttl_s: int,
        seed: int | None,
        idempotency_key: str,
    ) -> WorldSession:
        request = controlplane_pb2.OpenSessionRequest(
            task=_task_ref(task),
            simulator=_SIMULATORS[simulator],
            ttl_seconds=ttl_s,
        )
        if seed is not None:
            request.seed = seed
        _validated(request, label="session open request")
        response = await _call(
            self._client.open_session(
                request,
                headers=self._admission_headers(idempotency_key),
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        )
        session = _session(_validated(response, label="session open response").session)
        if session.task != task or session.simulator is not simulator:
            raise OperationProtocolError("Worlds opened a session for another task or simulator")
        return session

    async def list_sessions(self) -> tuple[WorldSession, ...]:
        request = _validated(controlplane_pb2.ListSessionsRequest(), label="session list request")
        response = await _call(
            self._client.list_sessions(request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS)
        )
        _validated(response, label="session list response")
        return tuple(_session(item) for item in response.sessions)

    async def get_session(self, session_id: str) -> WorldSession:
        request = _validated(
            controlplane_pb2.GetSessionRequest(session_id=session_id),
            label="session read request",
        )
        response = await _call(
            self._client.get_session(request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS)
        )
        session = _session(_validated(response, label="session read response").session)
        if session.session_id != session_id:
            raise OperationProtocolError("Worlds returned another session")
        return session

    async def step_session(
        self,
        session_id: str,
        *,
        step_id: str,
        expected_observation_sequence: int,
        tool: str,
        args: Mapping[str, object],
    ) -> SessionStepReceipt:
        request = _validated(
            controlplane_pb2.StepSessionRequest(
                session_id=session_id,
                step_id=step_id,
                expected_observation_sequence=expected_observation_sequence,
                tool=tool,
                arguments=dict(args),
            ),
            label="session step request",
        )
        response = await _call(
            self._client.step_session(request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS)
        )
        if response.request != request:
            raise OperationProtocolError("Worlds returned a receipt for another session request")
        if response.previous_observation_sequence != expected_observation_sequence:
            raise OperationProtocolError("Worlds returned a receipt for another observation fence")
        result = _step_result(response)
        if result.step_id != step_id:
            raise OperationProtocolError("Worlds returned another session step")
        return result

    async def verify_session(
        self,
        session_id: str,
        *,
        decision: DecisionIdentity,
    ) -> GoalVerificationReceipt:
        request = _validated(
            controlplane_pb2.VerifySessionRequest(
                session_id=session_id,
                decision=_decision_message(decision),
            ),
            label="session verification request",
        )
        response = await _call(
            self._client.verify_session(request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS)
        )
        result = _verification(response)
        if result.decision != decision:
            raise OperationProtocolError("Worlds returned another session decision")
        if result.evidence.get("session_id") != session_id:
            raise OperationProtocolError("Worlds returned another session verification")
        return result

    async def close_session(self, session_id: str) -> WorldSession:
        request = _validated(
            controlplane_pb2.CloseSessionRequest(session_id=session_id),
            label="session close request",
        )
        response = await _call(
            self._client.close_session(request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS)
        )
        session = _session(_validated(response, label="session close response").session)
        if session.session_id != session_id:
            raise OperationProtocolError("Worlds closed another session")
        return session

    async def status(self, ref: OperationRef[object, object]) -> OperationReceipt:
        request = _validated(
            controlplane_pb2.GetWorldsOperationRequest(operation=_operation_ref(ref)),
            label="Worlds status request",
        )
        try:
            response = await self._client.get_worlds_operation(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _receipt_for(ref, _validated(response, label="Worlds status response").operation)

    async def updates(
        self,
        ref: OperationRef[object, object],
        *,
        after: UpdateCursor | None,
        page_size: int,
        wait_s: float,
    ) -> tuple[OperationReceipt, ...]:
        request = controlplane_pb2.GetWorldsOperationUpdatesRequest(
            operation=_operation_ref(ref),
            limit=page_size,
            wait_timeout=timedelta(seconds=wait_s),
        )
        if after is not None:
            request.after_cursor = int(after)
        _validated(request, label="Worlds updates request")
        try:
            response = await self._client.get_worlds_operation_updates(
                request,
                headers=self._headers,
                timeout_ms=int((wait_s + 5.0) * 1000),
            )
        except ConnectError as error:
            _raise_rpc(error)
        _validated(response, label="Worlds updates response")
        arm = response.WhichOneof("outcome")
        if arm == "page":
            return tuple(_receipt_for(ref, item) for item in response.page.updates)
        if arm == "history_gap":
            latest = await self.status(ref)
            raise OperationHistoryGapError(_history_gap_cursor(response.history_gap), latest)
        raise OperationProtocolError(f"unknown Worlds updates outcome {arm!r}")

    async def cancel(self, ref: OperationRef[object, object], *, reason: str) -> OperationReceipt:
        request = _validated(
            controlplane_pb2.CancelWorldsOperationRequest(
                operation=_operation_ref(ref), reason=reason
            ),
            label="Worlds cancellation request",
        )
        try:
            response = await self._client.cancel_worlds_operation(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _receipt_for(
            ref, _validated(response, label="Worlds cancellation response").operation
        )

    async def result_response(
        self, ref: OperationRef[object, object]
    ) -> controlplane_pb2.GetWorldsOperationResultResponse:
        request = _validated(
            controlplane_pb2.GetWorldsOperationResultRequest(operation=_operation_ref(ref)),
            label="Worlds result request",
        )
        try:
            response = await self._client.get_worlds_operation_result(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _validated(response, label="Worlds result response")

    async def result(self, ref: OperationRef[object, object]) -> WorldsResult:
        response = await self.result_response(ref)
        result = response.result
        arm = result.WhichOneof("result")
        if arm is None:
            raise OperationProtocolError("Worlds returned no result arm")
        origin = _result_origin(response, ref, arm)
        if arm == "evaluation":
            return await evaluation_result(self, result, origin)
        if arm == "generation":
            return await generation_result(self, result, origin)
        if arm == "environment":
            return await environment_result(self, result, origin)
        if arm == "object_asset":
            return await object_asset_result(self, result, origin)
        if arm == "robot_part_candidate":
            return await robot_part_result(self, result, origin)
        if arm == "scan_seed":
            return await scan_seed_result(self, result, origin)
        raise OperationProtocolError(f"Worlds returned unknown result arm {arm!r}")


async def evaluation_result(
    owner: WorldsOwnerClient,
    message: controlplane_pb2.WorldsOperationResult,
    resource_id: str,
) -> controlplane_pb2.WorldEvaluation:
    evaluation = await owner.get_evaluation(resource_id)
    if evaluation != message.evaluation:
        raise OperationProtocolError("Worlds evaluation read disagrees with its operation result")
    return evaluation


async def generation_result(
    owner: WorldsOwnerClient,
    message: controlplane_pb2.WorldsOperationResult,
    resource_id: str,
) -> Generation:
    generation, projection = await owner.get_generation(resource_id)
    if projection != message.generation:
        raise OperationProtocolError("Worlds generation read disagrees with its operation result")
    return generation


async def environment_result(
    owner: WorldsOwnerClient,
    message: controlplane_pb2.WorldsOperationResult,
    resource_id: str,
) -> EnvironmentBundle:
    del owner, resource_id
    return _environment(message.environment)


async def object_asset_result(
    owner: WorldsOwnerClient,
    message: controlplane_pb2.WorldsOperationResult,
    resource_id: str,
) -> ObjectAssetBundle:
    del owner, resource_id
    return _object_asset(message.object_asset)


async def scan_seed_result(
    owner: WorldsOwnerClient,
    message: controlplane_pb2.WorldsOperationResult,
    resource_id: str,
) -> ScanSeed:
    del owner, resource_id
    return _scan_seed(message.scan_seed)


async def robot_part_result(
    owner: WorldsOwnerClient,
    message: controlplane_pb2.WorldsOperationResult,
    resource_id: str,
) -> RobotPartCandidate:
    candidate = _robot_part_candidate(message.robot_part_candidate)
    if await owner.get_robot_part_authoring(resource_id) != candidate:
        raise OperationProtocolError("Worlds robot-part read disagrees with its operation result")
    return candidate


def _robot_part_candidate(message: controlplane_pb2.RobotPartCandidate) -> RobotPartCandidate:
    try:
        candidate = robot_part_candidate_from_dict(json.loads(message.canonical_json))
    except (UnicodeDecodeError, ValueError) as error:
        raise OperationProtocolError(
            "Worlds returned malformed canonical RobotPartCandidate content"
        ) from error
    if str(candidate.id) != message.candidate_id:
        raise OperationProtocolError(
            "Worlds RobotPartCandidate envelope disagrees with its canonical content identity"
        )
    return candidate


def environment_quality(model: str) -> controlplane_pb2.EnvironmentAuthoringQuality:
    try:
        return {
            "marble-1.1": controlplane_pb2.ENVIRONMENT_AUTHORING_QUALITY_DEFAULT,
            "marble-1.1-plus": controlplane_pb2.ENVIRONMENT_AUTHORING_QUALITY_HIGH,
        }[model]
    except KeyError as error:
        raise ValueError("environment model must be 'marble-1.1' or 'marble-1.1-plus'") from error


def object_quality(quality: str) -> controlplane_pb2.ObjectAuthoringQuality:
    try:
        return {
            "default": controlplane_pb2.OBJECT_AUTHORING_QUALITY_DEFAULT,
            "high": controlplane_pb2.OBJECT_AUTHORING_QUALITY_HIGH,
        }[quality]
    except KeyError as error:
        raise ValueError("object authoring quality must be 'default' or 'high'") from error
