"""Total generated-Factory transforms and the sole Python capture RPC client."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from connectrpc.errors import ConnectError
from google.protobuf.timestamp_pb2 import Timestamp
from sentientx.sx.common.v1 import common_pb2
from sentientx.sx.experience.factory.v1 import factory_connect, factory_pb2
from sentientx.sx.operations.v1 import operations_pb2
from sx_contracts import (
    AcceptedOperation,
    BooleanAnswer,
    BooleanPrompt,
    CancellationRequest,
    CancelledOperation,
    CaptureAnnotationMode,
    CaptureArtifactUri,
    CaptureAssignmentId,
    CaptureEpisodeReceipt,
    CaptureOrderResult,
    CaptureOrderState,
    CapturePolicy,
    CaptureProgress,
    CaptureSessionId,
    CaptureSessionReceipt,
    ChoiceAnswer,
    CollectorAnswer,
    CollectorId,
    CollectorPrompt,
    CollectorPromptId,
    CollectorPromptScope,
    EpisodeId,
    FailedOperation,
    IdempotencyKey,
    OperationFailure,
    OperationId,
    OperationKind,
    OperationReceipt,
    OperationRef,
    PlatformPillar,
    RunningOperation,
    Sha256Digest,
    ShortTextPrompt,
    SingleChoicePrompt,
    SubtaskBoundaryHint,
    SucceededOperation,
    TaskContractRef,
    TaskId,
    TaskSchemaVersion,
    TaskVerdict,
    Terminated,
    TerminationReason,
    TextAnswer,
    TraceId,
    Truncated,
    UpdateCursor,
)

from sx._errors import OperationHistoryGapError, OperationProtocolError
from sx._rpc import history_gap_cursor as _history_gap_cursor
from sx._rpc import raise_rpc as _raise_rpc
from sx._rpc import resource_from_proto as _resource
from sx._rpc import validated as _validated
from sx._transport import RpcBinding

_RPC_TIMEOUT_MS = 30_000

_ANNOTATION_TO_PROTO = {
    CaptureAnnotationMode.NONE: factory_pb2.CAPTURE_ANNOTATION_MODE_NONE,
    CaptureAnnotationMode.BOUNDARY_HINTS: factory_pb2.CAPTURE_ANNOTATION_MODE_BOUNDARY_HINTS,
}
_SCOPE_TO_PROTO = {
    CollectorPromptScope.EPISODE: factory_pb2.COLLECTOR_PROMPT_SCOPE_EPISODE,
    CollectorPromptScope.BATCH: factory_pb2.COLLECTOR_PROMPT_SCOPE_BATCH,
}
_ORDER_STATE_FROM_PROTO = {
    factory_pb2.CAPTURE_ORDER_STATE_PENDING: CaptureOrderState.PENDING,
    factory_pb2.CAPTURE_ORDER_STATE_COLLECTING: CaptureOrderState.COLLECTING,
    factory_pb2.CAPTURE_ORDER_STATE_QA: CaptureOrderState.QA,
    factory_pb2.CAPTURE_ORDER_STATE_DELIVERING: CaptureOrderState.DELIVERING,
    factory_pb2.CAPTURE_ORDER_STATE_COMPLETE: CaptureOrderState.COMPLETE,
    factory_pb2.CAPTURE_ORDER_STATE_CANCELLED: CaptureOrderState.CANCELLED,
    factory_pb2.CAPTURE_ORDER_STATE_FAILED: CaptureOrderState.FAILED,
}
_REASON_FROM_PROTO = {
    factory_pb2.TERMINATION_REASON_SUCCESS: TerminationReason.SUCCESS,
    factory_pb2.TERMINATION_REASON_FAILURE: TerminationReason.FAILURE,
    factory_pb2.TERMINATION_REASON_SAFETY_VIOLATION: TerminationReason.SAFETY_VIOLATION,
    factory_pb2.TERMINATION_REASON_MAX_STEPS: TerminationReason.MAX_STEPS,
    factory_pb2.TERMINATION_REASON_STOPPED: TerminationReason.STOPPED,
    factory_pb2.TERMINATION_REASON_POLICY_FAILURE: TerminationReason.POLICY_FAILURE,
}
_VERDICT_FROM_PROTO = {
    factory_pb2.TASK_VERDICT_SATISFIED: TaskVerdict.SATISFIED,
    factory_pb2.TASK_VERDICT_NOT_SATISFIED: TaskVerdict.NOT_SATISFIED,
    factory_pb2.TASK_VERDICT_UNKNOWN: TaskVerdict.UNKNOWN,
}


def _task_ref(ref: TaskContractRef) -> common_pb2.TaskContractRef:
    return common_pb2.TaskContractRef(
        task_id=str(ref.task_id),
        schema_version=str(ref.schema_version),
        sha256=str(ref.sha256),
    )


def _operation_ref(ref: OperationRef[object, object]) -> common_pb2.OperationRef:
    if ref.pillar is not PlatformPillar.EXPERIENCE or ref.kind is not OperationKind.CAPTURE:
        raise OperationProtocolError(f"Factory cannot own {ref}")
    return common_pb2.OperationRef(
        pillar=common_pb2.PLATFORM_PILLAR_EXPERIENCE,
        kind=common_pb2.OPERATION_KIND_CAPTURE,
        operation_id=str(ref.operation_id),
    )


def _prompt(prompt: CollectorPrompt) -> factory_pb2.CollectorPrompt:
    if isinstance(prompt, BooleanPrompt):
        return factory_pb2.CollectorPrompt(
            id=str(prompt.id),
            label=prompt.label,
            scope=_SCOPE_TO_PROTO[prompt.scope],
            required=prompt.required,
            boolean_prompt=factory_pb2.BooleanPrompt(),
        )
    if isinstance(prompt, SingleChoicePrompt):
        return factory_pb2.CollectorPrompt(
            id=str(prompt.id),
            label=prompt.label,
            scope=_SCOPE_TO_PROTO[prompt.scope],
            required=prompt.required,
            single_choice_prompt=factory_pb2.SingleChoicePrompt(choices=prompt.choices),
        )
    return factory_pb2.CollectorPrompt(
        id=str(prompt.id),
        label=prompt.label,
        scope=_SCOPE_TO_PROTO[prompt.scope],
        required=prompt.required,
        short_text_prompt=factory_pb2.ShortTextPrompt(),
    )


def _policy(policy: CapturePolicy) -> factory_pb2.CapturePolicy:
    return factory_pb2.CapturePolicy(
        annotation_mode=_ANNOTATION_TO_PROTO[policy.annotation_mode],
        prompts=tuple(_prompt(item) for item in policy.prompts),
    )


def _datetime(value: Timestamp, *, label: str) -> datetime:
    parsed = value.ToDatetime(tzinfo=UTC)
    return parsed


def _progress(value: factory_pb2.CaptureOperation) -> CaptureProgress | None:
    arm = value.WhichOneof("progress")
    if arm is None:
        return None
    if arm != "capture_progress":
        raise OperationProtocolError(f"unknown Factory progress arm {arm!r}")
    progress = value.capture_progress
    try:
        state = _ORDER_STATE_FROM_PROTO[progress.state]
    except KeyError as error:
        raise OperationProtocolError("Factory returned an unknown capture order state") from error
    return CaptureProgress(state, progress.episodes_target, progress.episodes_completed)


def _cancellation(
    value: operations_pb2.AcceptedOperation | operations_pb2.RunningOperation,
) -> CancellationRequest | None:
    if not value.HasField("cancellation"):
        return None
    cancellation = value.cancellation
    return CancellationRequest(
        reason=cancellation.reason,
        requested_at=_datetime(cancellation.requested_at, label="cancellation request time"),
    )


def _receipt(value: factory_pb2.CaptureOperation) -> OperationReceipt:
    _validated(value, label="Factory capture operation")
    metadata = value.metadata
    ref = metadata.ref
    if (
        ref.pillar != common_pb2.PLATFORM_PILLAR_EXPERIENCE
        or ref.kind != common_pb2.OPERATION_KIND_CAPTURE
    ):
        raise OperationProtocolError("Factory returned a non-capture operation")
    operation_id = OperationId(ref.operation_id)
    resource = _resource(metadata.resource)
    trace_id = TraceId(metadata.trace_id)
    cursor = UpdateCursor(metadata.cursor)
    key = IdempotencyKey(metadata.idempotency_key) if metadata.HasField("idempotency_key") else None
    progress = _progress(value)
    created_at = _datetime(metadata.created_at, label="operation creation time")
    updated_at = _datetime(metadata.updated_at, label="operation update time")
    arm = value.lifecycle.WhichOneof("state")
    if arm == "accepted":
        return AcceptedOperation(
            operation_id,
            PlatformPillar.EXPERIENCE,
            OperationKind.CAPTURE,
            resource,
            trace_id,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            cancellation=_cancellation(value.lifecycle.accepted),
            created_at=created_at,
            updated_at=updated_at,
        )
    if arm == "running":
        return RunningOperation(
            operation_id,
            PlatformPillar.EXPERIENCE,
            OperationKind.CAPTURE,
            resource,
            trace_id,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            cancellation=_cancellation(value.lifecycle.running),
            created_at=created_at,
            updated_at=updated_at,
        )
    if arm == "succeeded":
        return SucceededOperation(
            operation_id,
            PlatformPillar.EXPERIENCE,
            OperationKind.CAPTURE,
            resource,
            trace_id,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            created_at=created_at,
            updated_at=updated_at,
            completed_at=_datetime(
                value.lifecycle.succeeded.completed_at,
                label="operation completion time",
            ),
        )
    if arm == "failed":
        failure = value.lifecycle.failed
        return FailedOperation(
            operation_id,
            PlatformPillar.EXPERIENCE,
            OperationKind.CAPTURE,
            resource,
            trace_id,
            OperationFailure(
                failure.failure.code,
                failure.failure.message,
                failure.failure.retryable,
            ),
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            created_at=created_at,
            updated_at=updated_at,
            failed_at=_datetime(failure.failed_at, label="operation failure time"),
        )
    if arm == "cancelled":
        cancelled = value.lifecycle.cancelled
        return CancelledOperation(
            operation_id,
            PlatformPillar.EXPERIENCE,
            OperationKind.CAPTURE,
            resource,
            trace_id,
            cancelled.reason,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            created_at=created_at,
            updated_at=updated_at,
            cancelled_at=_datetime(cancelled.cancelled_at, label="operation cancellation time"),
        )
    raise OperationProtocolError(f"unknown Factory lifecycle arm {arm!r}")


def _receipt_for(
    expected: OperationRef[object, object],
    value: factory_pb2.CaptureOperation,
) -> OperationReceipt:
    """Decode a receipt and prove the owner answered for the requested operation."""

    receipt = _receipt(value)
    if receipt.ref != expected:
        raise OperationProtocolError(
            f"Factory returned {receipt.ref} while {expected} was requested"
        )
    return receipt


def _answer(value: factory_pb2.CollectorAnswer) -> CollectorAnswer:
    prompt_id = CollectorPromptId(value.prompt_id)
    arm = value.WhichOneof("answer")
    if arm == "boolean_answer":
        return BooleanAnswer(prompt_id, value.boolean_answer.value, kind="boolean")
    if arm == "choice_answer":
        return ChoiceAnswer(prompt_id, value.choice_answer.value, kind="choice")
    if arm == "text_answer":
        return TextAnswer(prompt_id, value.text_answer.value, kind="text")
    raise OperationProtocolError(f"unknown collector answer arm {arm!r}")


def _capture_policy(value: factory_pb2.CapturePolicy) -> CapturePolicy:
    annotation = {
        factory_pb2.CAPTURE_ANNOTATION_MODE_NONE: CaptureAnnotationMode.NONE,
        factory_pb2.CAPTURE_ANNOTATION_MODE_BOUNDARY_HINTS: CaptureAnnotationMode.BOUNDARY_HINTS,
    }.get(value.annotation_mode)
    if annotation is None:
        raise OperationProtocolError("Factory returned an unknown annotation mode")
    prompts: list[CollectorPrompt] = []
    for item in value.prompts:
        scope = {
            factory_pb2.COLLECTOR_PROMPT_SCOPE_EPISODE: CollectorPromptScope.EPISODE,
            factory_pb2.COLLECTOR_PROMPT_SCOPE_BATCH: CollectorPromptScope.BATCH,
        }.get(item.scope)
        if scope is None:
            raise OperationProtocolError("Factory returned an unknown collector prompt scope")
        prompt_id = CollectorPromptId(item.id)
        arm = item.WhichOneof("prompt")
        if arm == "boolean_prompt":
            prompts.append(
                BooleanPrompt(prompt_id, item.label, scope, item.required, kind="boolean")
            )
        elif arm == "single_choice_prompt":
            prompts.append(
                SingleChoicePrompt(
                    prompt_id,
                    item.label,
                    scope,
                    tuple(item.single_choice_prompt.choices),
                    item.required,
                    kind="single_choice",
                )
            )
        elif arm == "short_text_prompt":
            prompts.append(
                ShortTextPrompt(prompt_id, item.label, scope, item.required, kind="short_text")
            )
        else:
            raise OperationProtocolError(f"unknown collector prompt arm {arm!r}")
    return CapturePolicy(annotation, tuple(prompts))


def _episode_end(value: factory_pb2.EpisodeEnd) -> Terminated | Truncated:
    arm = value.WhichOneof("ending")
    ending = value.terminated if arm == "terminated" else value.truncated
    try:
        reason = _REASON_FROM_PROTO[ending.reason]
        verdict = _VERDICT_FROM_PROTO[ending.verdict]
    except KeyError as error:
        raise OperationProtocolError("Factory returned an unknown episode ending") from error
    if arm == "terminated":
        return Terminated(reason, verdict)
    if arm == "truncated":
        return Truncated(reason, verdict)
    raise OperationProtocolError(f"unknown episode ending arm {arm!r}")


def _session_receipt(value: factory_pb2.CaptureSessionReceipt) -> CaptureSessionReceipt:
    return CaptureSessionReceipt(
        schema_version=value.schema_version,
        session_id=CaptureSessionId(value.session_id),
        assignment_id=CaptureAssignmentId(value.assignment_id),
        task=TaskContractRef(
            task_id=TaskId(value.task.task_id),
            schema_version=TaskSchemaVersion(value.task.schema_version),
            sha256=Sha256Digest(value.task.sha256),
        ),
        collector_id=CollectorId(value.collector_id),
        dataset_uri=CaptureArtifactUri(value.dataset_uri),
        started_at=_datetime(value.started_at, label="capture session start"),
        finalized_at=_datetime(value.finalized_at, label="capture session finalization"),
        policy=_capture_policy(value.policy),
        episodes=tuple(
            CaptureEpisodeReceipt(
                episode_id=EpisodeId(episode.episode_id),
                source_episode_index=episode.source_episode_index,
                artifact_uri=CaptureArtifactUri(episode.artifact_uri),
                frame_count=episode.frame_count,
                end=_episode_end(episode.end),
                attention=episode.attention,
                note=episode.note if episode.HasField("note") else None,
                boundary_hints=tuple(
                    SubtaskBoundaryHint(
                        step_index=hint.step_index,
                        occurrence=hint.occurrence,
                        recorded_at=_datetime(hint.recorded_at, label="boundary hint time"),
                    )
                    for hint in episode.boundary_hints
                ),
                answers=tuple(_answer(answer) for answer in episode.answers),
            )
            for episode in value.episodes
        ),
        answers=tuple(_answer(answer) for answer in value.answers),
    )


def _capture_order_result_for(
    expected: OperationRef[object, object],
    value: factory_pb2.CaptureOrderResult,
) -> CaptureOrderResult:
    if value.order_id != str(expected.operation_id):
        raise OperationProtocolError(
            f"Factory returned result for {value.order_id!r} while {expected} was requested"
        )
    return CaptureOrderResult(
        value.order_id,
        tuple(_session_receipt(receipt) for receipt in value.session_receipts),
    )


class FactoryOwnerClient:
    """Generated Connect client for the one Factory-owned capture operation family."""

    def __init__(self, binding: RpcBinding) -> None:
        self._headers = binding.headers
        self._client = factory_connect.FactoryServiceClient(binding.address)

    async def close(self) -> None:
        await self._client.close()

    async def start_capture(
        self,
        task: TaskContractRef,
        *,
        embodiment_id: str,
        episodes: int,
        timeout: timedelta,
        policy: CapturePolicy,
        idempotency_key: str,
    ) -> OperationReceipt:
        request = _validated(
            factory_pb2.StartCaptureRequest(
                task=_task_ref(task),
                embodiment_id=embodiment_id,
                episodes=episodes,
                timeout=timeout,
                policy=_policy(policy),
            ),
            label="capture admission",
        )
        headers = dict(self._headers)
        headers["Idempotency-Key"] = idempotency_key
        try:
            response = await self._client.start_capture(
                request,
                headers=headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _receipt(_validated(response, label="capture admission response").operation)

    def progress(self, receipt: OperationReceipt) -> CaptureProgress | None:
        """The live capture ledger this receipt carries, as the domain value it is.

        The order's own state and episode counts, parsed exactly: a mapping missing a
        field, carrying an unknown one, or spelling a count as text is a typed refusal
        rather than a progress value with a hole in it.
        """

        if receipt.progress is None:
            return None
        if isinstance(receipt.progress, CaptureProgress):
            return receipt.progress
        body = receipt.progress
        if set(body) != {"state", "episodes_target", "episodes_completed"}:
            raise TypeError("capture progress fields are incomplete or unknown")
        state = body["state"]
        target = body["episodes_target"]
        completed = body["episodes_completed"]
        if not isinstance(state, str):
            raise TypeError("capture progress state is not text")
        if (
            isinstance(target, bool)
            or not isinstance(target, int)
            or isinstance(completed, bool)
            or not isinstance(completed, int)
        ):
            raise TypeError("capture progress episode counts are not integers")
        return CaptureProgress(CaptureOrderState(state), target, completed)

    async def status(self, ref: OperationRef[object, object]) -> OperationReceipt:
        request = _validated(
            factory_pb2.GetCaptureOperationRequest(operation=_operation_ref(ref)),
            label="capture status request",
        )
        try:
            response = await self._client.get_capture_operation(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _receipt_for(
            ref,
            _validated(response, label="capture status response").operation,
        )

    async def updates(
        self,
        ref: OperationRef[object, object],
        *,
        after: UpdateCursor | None,
        page_size: int,
        wait_s: float,
    ) -> tuple[OperationReceipt, ...]:
        request = factory_pb2.GetCaptureOperationUpdatesRequest(
            operation=_operation_ref(ref),
            limit=page_size,
            wait_timeout=timedelta(seconds=wait_s),
        )
        if after is not None:
            request.after_cursor = int(after)
        _validated(request, label="capture updates request")
        try:
            response = await self._client.get_capture_operation_updates(
                request,
                headers=self._headers,
                timeout_ms=int((wait_s + 5.0) * 1000),
            )
        except ConnectError as error:
            _raise_rpc(error)
        _validated(response, label="capture updates response")
        arm = response.WhichOneof("outcome")
        if arm == "page":
            return tuple(_receipt_for(ref, item) for item in response.page.updates)
        if arm == "history_gap":
            latest = await self.status(ref)
            raise OperationHistoryGapError(_history_gap_cursor(response.history_gap), latest)
        raise OperationProtocolError(f"unknown capture updates outcome {arm!r}")

    async def cancel(self, ref: OperationRef[object, object], *, reason: str) -> OperationReceipt:
        request = _validated(
            factory_pb2.CancelCaptureOperationRequest(
                operation=_operation_ref(ref),
                reason=reason,
            ),
            label="capture cancellation request",
        )
        try:
            response = await self._client.cancel_capture_operation(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _receipt_for(
            ref,
            _validated(response, label="capture cancellation response").operation,
        )

    async def result(self, ref: OperationRef[object, object]) -> CaptureOrderResult:
        request = _validated(
            factory_pb2.GetCaptureOperationResultRequest(operation=_operation_ref(ref)),
            label="capture result request",
        )
        try:
            response = await self._client.get_capture_operation_result(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            _raise_rpc(error)
        _validated(response, label="capture result response")
        if response.result.WhichOneof("result") != "capture_order":
            raise OperationProtocolError("Factory returned an unknown capture result")
        return _capture_order_result_for(ref, response.result.capture_order)
