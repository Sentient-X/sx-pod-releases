"""Closed SDK bindings for the six resources that are truthfully native HTTP.

Only the three multipart uploads need JSON decoding. The three immutable/range
asset streams are consumed directly by their byte-oriented callers. Keeping the
upload paths and their exact receipts here makes the exception explicit without
projecting the Worlds domain back through the generic OpenAPI façade.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Literal, cast

from sx_contracts import Sha256Digest
from sx_service.registry import DoorId

from sx._errors import OperationProtocolError


@dataclass(frozen=True, slots=True)
class PanoUploadReceipt:
    pano_id: str
    sha256: Sha256Digest
    byte_size: int


@dataclass(frozen=True, slots=True)
class ObjectImageUploadReceipt:
    image_id: str
    sha256: Sha256Digest
    byte_size: int


@dataclass(frozen=True, slots=True)
class ScanUploadReceipt:
    scan_id: str
    sha256: Sha256Digest
    byte_size: int
    frames: int


@dataclass(frozen=True, slots=True)
class NativeWorldsUpload[ReceiptT]:
    path: str
    field: str
    decode: Callable[[object], ReceiptT]
    method: Literal["POST"] = "POST"
    door: DoorId = DoorId.WORLDS


def _record(value: object, *, label: str, fields: frozenset[str]) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise OperationProtocolError(f"{label} is not an object")
    record = cast("Mapping[object, object]", value)
    if not all(isinstance(key, str) for key in record):
        raise OperationProtocolError(f"{label} has unexpected fields")
    narrowed = cast("Mapping[str, object]", record)
    if frozenset(narrowed) != fields:
        raise OperationProtocolError(f"{label} has unexpected fields")
    return narrowed


def _text(value: object, *, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise OperationProtocolError(f"{label} is not non-empty text")
    return value


def _digest(value: object, *, label: str) -> Sha256Digest:
    try:
        return Sha256Digest(_text(value, label=label))
    except ValueError as error:
        raise OperationProtocolError(f"{label} is not a SHA-256 digest") from error


def _positive_integer(value: object, *, label: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise OperationProtocolError(f"{label} is not a positive integer")
    return value


def pano_upload_receipt(value: object) -> PanoUploadReceipt:
    record = _record(
        value,
        label="panorama upload receipt",
        fields=frozenset({"pano_id", "sha256", "byte_size"}),
    )
    return PanoUploadReceipt(
        _text(record["pano_id"], label="panorama upload pano_id"),
        _digest(record["sha256"], label="panorama upload sha256"),
        _positive_integer(record["byte_size"], label="panorama upload byte_size"),
    )


def object_image_upload_receipt(value: object) -> ObjectImageUploadReceipt:
    record = _record(
        value,
        label="object-image upload receipt",
        fields=frozenset({"image_id", "sha256", "byte_size"}),
    )
    return ObjectImageUploadReceipt(
        _text(record["image_id"], label="object-image upload image_id"),
        _digest(record["sha256"], label="object-image upload sha256"),
        _positive_integer(record["byte_size"], label="object-image upload byte_size"),
    )


def scan_upload_receipt(value: object) -> ScanUploadReceipt:
    record = _record(
        value,
        label="scan upload receipt",
        fields=frozenset({"scan_id", "sha256", "byte_size", "frames"}),
    )
    return ScanUploadReceipt(
        _text(record["scan_id"], label="scan upload scan_id"),
        _digest(record["sha256"], label="scan upload sha256"),
        _positive_integer(record["byte_size"], label="scan upload byte_size"),
        _positive_integer(record["frames"], label="scan upload frames"),
    )


PANO_UPLOAD = NativeWorldsUpload(
    "/api/worlds/panos",
    "pano",
    pano_upload_receipt,
)
OBJECT_IMAGE_UPLOAD = NativeWorldsUpload(
    "/api/worlds/object-images",
    "image",
    object_image_upload_receipt,
)
SCAN_UPLOAD = NativeWorldsUpload(
    "/api/worlds/scans",
    "scan",
    scan_upload_receipt,
)
