"""Repository-local operations surfaces and their deliberate credential reveal."""

from __future__ import annotations

import base64
import binascii
import json
import re
import subprocess
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import cast
from urllib.parse import urlsplit
from uuid import UUID

import yaml


class OperationsError(ValueError):
    """The private-operations registry or credential response is invalid."""


class SurfaceKind(StrEnum):
    UI = "ui"
    API = "api"


class SurfaceAuthentication(StrEnum):
    ADMIN_ACCOUNT = "admin-account"
    SSO = "sso"
    ACCOUNT = "account"
    PROVIDER_ACCOUNT = "provider-account"
    TAILNET = "tailnet"
    SHARED_CREDENTIAL = "shared-credential"
    SERVICE = "service"


@dataclass(frozen=True, slots=True)
class TailnetBackend:
    namespace: str
    service: str
    port: int | str


@dataclass(frozen=True, slots=True)
class PrivateSurface:
    id: str
    name: str
    group: str
    description: str
    kind: SurfaceKind
    authentication: SurfaceAuthentication
    hostname: str
    backend: TailnetBackend
    credential: str | None
    entry_path: str = "/"


@dataclass(frozen=True, slots=True)
class ExternalConsole:
    id: str
    name: str
    group: str
    description: str
    authentication: SurfaceAuthentication
    url: str


@dataclass(frozen=True, slots=True)
class FieldCredential:
    path: str
    username_key: str
    password_key: str


@dataclass(frozen=True, slots=True)
class DockerConfigCredential:
    path: str
    secret_key: str


CredentialSource = FieldCredential | DockerConfigCredential


@dataclass(frozen=True, slots=True)
class OperationsRegistry:
    home_hostname: str
    surfaces: tuple[PrivateSurface, ...]
    external_consoles: tuple[ExternalConsole, ...]
    credentials: dict[str, CredentialSource]


@dataclass(frozen=True, slots=True)
class UsernamePassword:
    username: str
    password: str


_NAME = re.compile(r"^[a-z][a-z0-9-]*$")


def _mapping(value: object, field: str) -> dict[str, object]:
    if not isinstance(value, dict):
        raise OperationsError(f"{field} must be a mapping")
    parsed: dict[str, object] = {}
    for key, item in cast("dict[object, object]", value).items():
        if not isinstance(key, str):
            raise OperationsError(f"{field} must be a mapping")
        parsed[key] = item
    return parsed


def _sequence(value: object, field: str) -> list[object]:
    if not isinstance(value, list):
        raise OperationsError(f"{field} must be a sequence")
    return cast("list[object]", value)


def _text(value: object, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise OperationsError(f"{field} must be non-empty text")
    return value.strip()


def _name(value: object, field: str) -> str:
    name = _text(value, field)
    if _NAME.fullmatch(name) is None:
        raise OperationsError(f"{field} must be a lowercase DNS-style name")
    return name


def _entry_path(value: object, field: str) -> str:
    path = _text(value, field)
    if (
        not path.startswith("/")
        or path.startswith("//")
        or any(character.isspace() for character in path)
        or "?" in path
        or "#" in path
        or "\\" in path
    ):
        raise OperationsError(f"{field} must be an absolute URL path without query or fragment")
    return path


def _https_url(value: object, field: str) -> str:
    url = _text(value, field)
    try:
        parsed = urlsplit(url)
        hostname = parsed.hostname
        _port = parsed.port
    except ValueError as error:
        raise OperationsError(
            f"{field} must be an HTTPS URL without embedded credentials"
        ) from error
    if (
        parsed.scheme != "https"
        or hostname is None
        or parsed.username is not None
        or parsed.password is not None
        or any(character.isspace() for character in url)
        or "\\" in url
    ):
        raise OperationsError(f"{field} must be an HTTPS URL without embedded credentials")
    return url


def _credential_source(name: str, value: object) -> CredentialSource:
    item = _mapping(value, f"credentials.{name}")
    path = _text(item.get("path"), f"credentials.{name}.path")
    if not path.startswith("/"):
        raise OperationsError(f"credentials.{name}.path must be absolute")
    format_name = _text(item.get("format"), f"credentials.{name}.format")
    if format_name == "fields":
        expected = {"path", "format", "username_key", "password_key"}
        if set(item) != expected:
            raise OperationsError(f"credentials.{name} fields differ from {sorted(expected)}")
        return FieldCredential(
            path,
            _text(item["username_key"], f"credentials.{name}.username_key"),
            _text(item["password_key"], f"credentials.{name}.password_key"),
        )
    if format_name == "dockerconfigjson":
        expected = {"path", "format", "secret_key"}
        if set(item) != expected:
            raise OperationsError(f"credentials.{name} fields differ from {sorted(expected)}")
        return DockerConfigCredential(
            path,
            _text(item["secret_key"], f"credentials.{name}.secret_key"),
        )
    raise OperationsError(f"credentials.{name}.format is unknown: {format_name}")


def load_operations(path: Path) -> OperationsRegistry:
    """Parse the one private-surface inventory and reject ambiguous entries."""

    try:
        document = _mapping(yaml.safe_load(path.read_text(encoding="utf-8")), "registry")
    except (OSError, yaml.YAMLError) as error:
        raise OperationsError(f"private-surface registry is unreadable: {error}") from error
    if set(document) != {
        "schema_version",
        "home",
        "surfaces",
        "external_consoles",
        "credentials",
    }:
        raise OperationsError(
            "registry fields must be schema_version/home/surfaces/external_consoles/credentials"
        )
    if document["schema_version"] != 2:
        raise OperationsError("private-surface registry must use schema_version 2")

    home = _mapping(document["home"], "home")
    if set(home) != {"hostname"}:
        raise OperationsError("home must contain only hostname")
    home_hostname = _name(home["hostname"], "home.hostname")

    raw_credentials = _mapping(document["credentials"], "credentials")
    credentials = {
        _name(name, f"credentials.{name}"): _credential_source(name, value)
        for name, value in raw_credentials.items()
    }

    surfaces: list[PrivateSurface] = []
    for index, raw_surface in enumerate(_sequence(document["surfaces"], "surfaces")):
        item = _mapping(raw_surface, f"surfaces[{index}]")
        prefix = f"surfaces[{index}]"
        surface_id = _name(item.get("id"), f"{prefix}.id")
        name = _text(item.get("name"), f"{prefix}.name")
        group = _text(item.get("group"), f"{prefix}.group")
        description = _text(item.get("description"), f"{prefix}.description")
        try:
            kind = SurfaceKind(_text(item.get("kind"), f"{prefix}.kind"))
            authentication = SurfaceAuthentication(
                _text(item.get("authentication"), f"{prefix}.authentication")
            )
        except ValueError as error:
            raise OperationsError(f"{prefix} has an unknown kind or authentication") from error
        raw_credential = item.get("credential")
        credential = (
            _name(raw_credential, f"{prefix}.credential") if raw_credential is not None else None
        )
        if authentication is SurfaceAuthentication.SHARED_CREDENTIAL:
            if credential is None or credential not in credentials:
                raise OperationsError(f"{prefix}.credential must name a declared credential")
        elif credential is not None:
            raise OperationsError(f"{prefix}.credential is only valid for shared-credential")

        expected = {
            "id",
            "name",
            "group",
            "description",
            "kind",
            "hostname",
            "namespace",
            "service",
            "port",
            "authentication",
        }
        if credential is not None:
            expected.add("credential")
        if "entry_path" in item:
            expected.add("entry_path")
        if set(item) != expected:
            raise OperationsError(f"{prefix} fields differ from {sorted(expected)}")
        hostname = _name(item["hostname"], f"{prefix}.hostname")
        namespace = _name(item["namespace"], f"{prefix}.namespace")
        service = _name(item["service"], f"{prefix}.service")
        raw_port = item["port"]
        if not isinstance(raw_port, int | str) or isinstance(raw_port, bool):
            raise OperationsError(f"{prefix}.port must be an integer or named port")
        if isinstance(raw_port, int) and not 1 <= raw_port <= 65535:
            raise OperationsError(f"{prefix}.port is outside the TCP port range")
        if isinstance(raw_port, str):
            raw_port = _name(raw_port, f"{prefix}.port")
        entry_path = _entry_path(item.get("entry_path", "/"), f"{prefix}.entry_path")
        surfaces.append(
            PrivateSurface(
                surface_id,
                name,
                group,
                description,
                kind,
                authentication,
                hostname,
                TailnetBackend(namespace, service, raw_port),
                credential,
                entry_path,
            )
        )

    external_consoles: list[ExternalConsole] = []
    for index, raw_console in enumerate(
        _sequence(document["external_consoles"], "external_consoles")
    ):
        item = _mapping(raw_console, f"external_consoles[{index}]")
        prefix = f"external_consoles[{index}]"
        expected = {"id", "name", "group", "description", "url", "authentication"}
        if set(item) != expected:
            raise OperationsError(f"{prefix} fields differ from {sorted(expected)}")
        try:
            authentication = SurfaceAuthentication(
                _text(item["authentication"], f"{prefix}.authentication")
            )
        except ValueError as error:
            raise OperationsError(f"{prefix} has an unknown authentication") from error
        if authentication not in {
            SurfaceAuthentication.ADMIN_ACCOUNT,
            SurfaceAuthentication.SSO,
            SurfaceAuthentication.PROVIDER_ACCOUNT,
        }:
            raise OperationsError(f"{prefix}.authentication is not valid for an external console")
        external_consoles.append(
            ExternalConsole(
                id=_name(item["id"], f"{prefix}.id"),
                name=_text(item["name"], f"{prefix}.name"),
                group=_text(item["group"], f"{prefix}.group"),
                description=_text(item["description"], f"{prefix}.description"),
                authentication=authentication,
                url=_https_url(item["url"], f"{prefix}.url"),
            )
        )

    ids = [surface.id for surface in surfaces] + [console.id for console in external_consoles]
    if len(ids) != len(set(ids)):
        raise OperationsError("directory ids must be unique")
    hostnames = [surface.hostname for surface in surfaces]
    if home_hostname in hostnames or len(hostnames) != len(set(hostnames)):
        raise OperationsError("home and surface hostnames must be unique")
    return OperationsRegistry(
        home_hostname,
        tuple(surfaces),
        tuple(external_consoles),
        credentials,
    )


def repository_root(start: Path | None = None) -> Path:
    """Find the sx checkout whose reviewed coordinates authorize this operation."""

    origin = Path.cwd() if start is None else start
    for candidate in (origin.resolve(), *origin.resolve().parents):
        if (candidate / "infra/tailscale/private-surfaces.yaml").is_file():
            return candidate
    raise OperationsError("run this command from inside a sx checkout")


def _project_id(root: Path) -> str:
    path = root / "infra/kubernetes/clusters/production/cluster-vars.yaml"
    try:
        document = _mapping(yaml.safe_load(path.read_text(encoding="utf-8")), "cluster vars")
        data = _mapping(document["data"], "cluster vars data")
        project_id = _text(data["INFISICAL_PROJECT_ID"], "INFISICAL_PROJECT_ID")
        UUID(project_id)
    except (KeyError, OSError, ValueError, yaml.YAMLError) as error:
        raise OperationsError(f"production Infisical project id is invalid: {error}") from error
    return project_id


def _secret(project_id: str, path: str, key: str) -> str:
    command = [
        "infisical",
        "secrets",
        "get",
        key,
        "--projectId",
        project_id,
        "--env",
        "prod",
        "--path",
        path,
        "--plain",
    ]
    try:
        result = subprocess.run(command, check=False, capture_output=True, text=True)
    except FileNotFoundError:
        raise OperationsError("infisical CLI is not installed") from None
    if result.returncode != 0:
        detail = result.stderr.strip() or "Infisical returned no error detail"
        raise OperationsError(f"Infisical could not read {path}/{key}: {detail}")
    value = result.stdout.strip()
    if not value:
        raise OperationsError(f"Infisical returned an empty value for {path}/{key}")
    return value


def _docker_username_password(document: str) -> UsernamePassword:
    try:
        value = _mapping(json.loads(document), "docker config")
        auths = _mapping(value["auths"], "docker config auths")
        if len(auths) != 1:
            raise OperationsError("docker config must contain exactly one registry authority")
        registry = _mapping(next(iter(auths.values())), "docker registry auth")
        encoded = _text(registry["auth"], "docker registry auth token")
        decoded = base64.b64decode(encoded, validate=True).decode("utf-8")
        username, separator, password = decoded.partition(":")
        if not separator or not username or not password:
            raise OperationsError("docker registry auth is not a username/password pair")
        return UsernamePassword(username, password)
    except (KeyError, UnicodeDecodeError, binascii.Error, json.JSONDecodeError) as error:
        raise OperationsError(f"docker config credential is invalid: {error}") from error


def credentials_for(root: Path, target: str) -> UsernamePassword:
    """Reveal one reviewed UI/service login without exposing storage encoding."""

    registry = load_operations(root / "infra/tailscale/private-surfaces.yaml")
    try:
        source = registry.credentials[target]
    except KeyError:
        available = ", ".join(sorted(registry.credentials))
        raise OperationsError(f"unknown credential target {target!r}; choose {available}") from None
    project_id = _project_id(root)
    if isinstance(source, FieldCredential):
        return UsernamePassword(
            _secret(project_id, source.path, source.username_key),
            _secret(project_id, source.path, source.password_key),
        )
    return _docker_username_password(_secret(project_id, source.path, source.secret_key))
