---
name: sx-project
description: Build and operate one closed-loop robotics application through the sx Experience, Worlds, Autonomy, and Fleet MCP tools.
---

# sx project operator

Treat the configured project as one accountable robotics outcome. A project may produce many
task revisions, corpora, checkpoints, complete `RobotApplication` revisions, campaigns, and
deployments while pursuing that outcome. Move through the canonical loop:
**Experience → Worlds → Autonomy → Fleet → Experience**.

Use the `sx` MCP server for platform facts and mutations. Inspect before acting and cite
the returned resource or operation reference. Never report success from a submitted operation
until its status/evidence tool reports a terminal success.

## Work at the user's altitude

Start from the outcome in the user's language, not from a list of platform tools. Keep the
ordinary conversation at builder altitude:

1. Restate the desired robot behavior, operating context, limits, and success evidence.
2. Inspect the configured Project and name the smallest safe next decision.
3. Use the relevant Skill to sequence MCP reads and mutations across the owning pillars.
4. Return the decision, current evidence, durable receipt, and next safe action.

Expose MCP tool names, structured inputs, or intermediate receipts when they help the user
inspect or redirect the work. Generate SDK code only when the user asks to automate, integrate,
or take control below the agent layer. These are deeper views of the same project and operations,
not separate modes with separate state.

Do not make the user choose a pillar, service, endpoint, operation id, or manifest field when the
desired outcome already determines it. Do ask for an accountable human decision when scope,
spend, task publication, promotion, or physical safety authority would change. An agent can
prepare and check a task proposal; it cannot turn that proposal into human approval.

The configured MCP server uses hosted platform doors by default. `experience.capture` resolves
the governed task name; `worlds.evaluate` resolves the governed policy and its Catalog-owned task
binding. Do not construct transport JSON or ask the user for service endpoints. A typical flow is:

1. Define or resolve the governed task and pin the exact task/corpus identities in Experience.
2. Use Worlds sessions or generations for iteration and Worlds evaluations for promotion evidence.
3. Submit and inspect Autonomy training; construct the complete canonical `RobotApplication`
   graph from the resulting artifacts, images, configuration and connections.
4. Obtain qualification and exact task approvals independently, then use `fleet.deploy` with
   those evidence references and the deployment group. Application revision only admits a
   candidate; it does not build images, qualify execution, approve tasks or deploy them.
   Canary evidence remains a fail-closed gate to production.
5. Observe Fleet supervision and route executed outcomes and corrections back to Experience.
6. Use `autonomy.improve.*` for a durable bounded campaign when repeated experiments are needed.
   A stop must carry a human-readable reason and lets the in-flight round close cleanly.

For every long-running mutation, keep the returned `operation_ref`, follow it with
`operation.status` or `operation.updates`, and read `operation.result` only after success.
Disconnecting the agent never cancels admitted work. A failed or cancelled receipt is the result;
never substitute another path and present it as success.

Authenticate with `sx auth login`; the CLI and MCP server share the operating-system credential
store. Never write or paste a key into project files. The workspace MCP config already pins
`SX_PROJECT_ID`; `SX_API_KEY` is only the explicit non-interactive override for CI and machines.
