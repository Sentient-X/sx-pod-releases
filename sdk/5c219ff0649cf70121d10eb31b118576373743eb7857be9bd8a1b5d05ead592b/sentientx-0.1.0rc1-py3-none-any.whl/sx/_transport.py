"""One shared asynchronous HTTP transport bound to an explicit project."""

from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from types import MappingProxyType
from typing import BinaryIO, cast

import httpx
from sx_auth.credentials import SESSION_COOKIE, DelegatedCredential, PresentedCredential
from sx_auth.principal import CredentialKind, ProjectId
from sx_service.registry import (
    AUTH,
    AUTONOMY,
    CATALOG,
    FACTORY,
    FLEET,
    INGEST,
    TASKPEDIA,
    WORLDS,
    DoorId,
    EndpointProfile,
    resolve_url,
)


class ConnectionProfile(StrEnum):
    """Where the public client sends pillar requests."""

    HOSTED = "hosted"
    DEVELOPMENT = "development"


@dataclass(frozen=True, slots=True)
class Endpoints:
    """Resolved transport addresses keyed by the registry's canonical door identity."""

    values: dict[DoorId, str]

    @classmethod
    def resolve(cls, profile: object) -> "Endpoints":
        if not isinstance(profile, ConnectionProfile):
            raise ValueError(f"unknown connection profile {profile!r}")
        registry_profile = {
            ConnectionProfile.HOSTED: EndpointProfile.HOSTED,
            ConnectionProfile.DEVELOPMENT: EndpointProfile.DEVELOPMENT,
        }.get(profile)
        if registry_profile is None:
            raise ValueError(f"unknown connection profile {profile!r}")
        doors = (AUTH, FACTORY, CATALOG, TASKPEDIA, WORLDS, AUTONOMY, FLEET, INGEST)
        return cls({door.name: resolve_url(door, registry_profile) for door in doors})

    @classmethod
    def uniform(cls, base_url: str) -> "Endpoints":
        """Bind every client door to one test server without a second endpoint schema."""

        return cls({door: base_url for door in DoorId if door in _CLIENT_DOORS})

    def for_door(self, door: DoorId) -> str:
        try:
            return self.values[DoorId(door)]
        except KeyError as error:
            raise ValueError(f"client has no endpoint for door {door}") from error


_CLIENT_DOORS = frozenset(
    {
        AUTH.name,
        FACTORY.name,
        CATALOG.name,
        TASKPEDIA.name,
        WORLDS.name,
        AUTONOMY.name,
        FLEET.name,
        INGEST.name,
    }
)


type MultipartFile = tuple[str, bytes | BinaryIO, str]
"""One multipart part: filename, content, media type.

The content is an open binary handle as well as ``bytes`` so a caller streaming a
capture archive of arbitrary size never has to materialize it in memory first.
"""


class ResponseError(RuntimeError):
    """A platform door refused a request with its complete response body."""

    def __init__(self, response: httpx.Response) -> None:
        self.status_code = response.status_code
        try:
            self.body: object = response.json()
        except ValueError:
            self.body = response.text
        super().__init__(f"platform request failed with HTTP {response.status_code}: {self.body}")


@dataclass(frozen=True, slots=True)
class RpcBinding:
    """One generated client address plus the already-resolved project credential."""

    address: str
    headers: Mapping[str, str]


class Transport:
    def __init__(
        self,
        endpoints: Endpoints,
        project: ProjectId,
        api_key: str | None,
        *,
        credential: PresentedCredential | DelegatedCredential | None = None,
        http: httpx.AsyncClient | None = None,
    ) -> None:
        if api_key is not None and credential is not None:
            raise ValueError("api_key and credential are mutually exclusive")
        self._endpoints = endpoints
        self._owns_http = http is None
        self._http = http or httpx.AsyncClient(timeout=30.0)
        self._headers = {"X-SX-Project-Id": str(project)}
        if api_key is not None:
            self._headers["X-API-Key"] = api_key
        elif isinstance(credential, DelegatedCredential):
            if credential.holder.kind is not CredentialKind.API_KEY:
                raise ValueError("a delegated credential holder must be an API key")
            self._headers["X-API-Key"] = credential.holder.raw
            self._headers["X-SX-Delegation-Id"] = str(credential.delegation_id)
        elif credential is not None:
            if credential.kind is CredentialKind.SESSION:
                self._headers["Cookie"] = f"{SESSION_COOKIE}={credential.raw}"
            else:
                self._headers["X-API-Key"] = credential.raw

    async def close(self) -> None:
        if self._owns_http:
            await self._http.aclose()

    def rpc_binding(self, door: DoorId) -> RpcBinding:
        """Bind a generated owner client without exposing mutable auth state."""

        return RpcBinding(
            address=self._endpoints.for_door(door),
            headers=MappingProxyType(dict(self._headers)),
        )

    async def request(
        self,
        method: str,
        door: DoorId,
        path: str,
        *,
        body: object | None = None,
        params: dict[str, str | int | float] | None = None,
        idempotency_key: str | None = None,
        data: Mapping[str, str] | None = None,
        files: Mapping[str, MultipartFile] | None = None,
    ) -> object:
        if body is not None and (data is not None or files is not None):
            raise ValueError("JSON body and multipart fields are mutually exclusive")
        headers = dict(self._headers)
        if idempotency_key is not None:
            headers["Idempotency-Key"] = idempotency_key
        response = await self._http.request(
            method,
            f"{self._endpoints.for_door(door).rstrip('/')}{path}",
            headers=headers,
            json=body if data is None and files is None else None,
            params=params,
            data=data,
            files=files,
        )
        if response.is_error:
            raise ResponseError(response)
        if response.status_code == 204 or not response.content:
            return None
        if "json" not in response.headers.get("content-type", "").lower():
            return response.text
        return cast(object, response.json())
