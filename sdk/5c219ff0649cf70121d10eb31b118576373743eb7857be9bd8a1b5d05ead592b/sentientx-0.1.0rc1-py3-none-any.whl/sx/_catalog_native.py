"""Closed SDK binding for the one Catalog resource that is truthfully native HTTP.

A governed body's description is served as exact bytes with their digest in the
ETag, so it is a download and not an RPC payload — the Catalog proto says so, and a
browser fetches the same URL directly. Keeping the method, door, path, and a total
decoder here makes that exception explicit instead of projecting the download back
through the generic OpenAPI façade, exactly as Worlds' native uploads do.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Literal

from sx_service.registry import DoorId

from sx._errors import OperationProtocolError


@dataclass(frozen=True, slots=True)
class NativeCatalogDownload:
    path: str
    decode: Callable[[object], str]
    method: Literal["GET"] = "GET"
    door: DoorId = DoorId.CATALOG


def description_text(value: object) -> str:
    """The description door answers XML text; an empty or non-text body is a break."""

    if not isinstance(value, str) or not value:
        raise OperationProtocolError("the description door returned no description text")
    return value


EMBODIMENT_DESCRIPTION = NativeCatalogDownload(
    "/api/embodiments/{name}/description",
    description_text,
)
