"""Private canonical request encoding; pillar services contain no wire DTOs."""

from collections.abc import Iterable, Mapping
from dataclasses import is_dataclass
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Protocol, cast
from uuid import UUID

from google.protobuf.json_format import MessageToDict
from google.protobuf.message import Message
from sx_autonomy import (
    FromScratch,
    PhysicalTarget,
    SimulationTarget,
    StepPrompt,
    WholeTaskPrompt,
)


class _DataclassValue(Protocol):
    __dataclass_fields__: dict[str, object]


def proto_document(value: Message) -> dict[str, object]:
    """Render a typed generated result only at a JSON protocol edge.

    The generated message is the truth everywhere inside the process. A message is not
    a mapping, so this is the one transform that turns it into wire JSON; the CLI and the
    MCP server both use it instead of inventing projections.
    """

    document = MessageToDict(value, preserving_proto_field_name=True)
    return {str(key): item for key, item in document.items()}


def json_value(value: object) -> object:
    """Render one public value at a CLI/MCP JSON edge.

    Generated messages stay typed inside the SDK and cross into JSON exactly
    here. Canonical domain values continue through their owner codecs below;
    treating protobuf messages as generic dataclasses would leak implementation
    fields and bypass ProtoJSON's enum/oneof spelling.
    """

    return proto_document(value) if isinstance(value, Message) else encode(value)


def encode(value: object) -> object:
    """Project a canonical domain value onto JSON without authoring a mirror model."""

    if value is None or isinstance(value, bool | int | float | str):
        return value
    if isinstance(value, Enum):
        return encode(value.value)
    if isinstance(value, UUID):
        return str(value)
    if isinstance(value, datetime):
        if value.tzinfo is None:
            raise ValueError("wire timestamps must be timezone-aware")
        return value.isoformat()
    if isinstance(value, timedelta):
        seconds = value.total_seconds()
        if seconds <= 0:
            raise ValueError("wire durations must be positive")
        return seconds
    if isinstance(value, Path):
        raise TypeError("local paths cannot cross a platform door; use a governed ContentRef")
    if isinstance(value, tuple | list | set | frozenset):
        return [encode(item) for item in cast("Iterable[object]", value)]
    if isinstance(value, dict):
        mapping = cast("Mapping[object, object]", value)
        return {str(key): encode(item) for key, item in mapping.items()}
    tagged: str | None = None
    if isinstance(value, FromScratch):
        tagged = "from_scratch"
    elif isinstance(value, WholeTaskPrompt):
        tagged = "whole_task"
    elif isinstance(value, StepPrompt):
        tagged = "step"
    elif isinstance(value, SimulationTarget):
        tagged = "simulation"
    elif isinstance(value, PhysicalTarget):
        tagged = "physical"
    if is_dataclass(value) and not isinstance(value, type):
        dataclass_value = cast("_DataclassValue", value)
        rendered = {
            name: encode(getattr(value, name)) for name in dataclass_value.__dataclass_fields__
        }
        if tagged is not None:
            return {"kind": tagged, **rendered}
        return rendered
    raise TypeError(f"{type(value).__name__} has no canonical wire encoding")
