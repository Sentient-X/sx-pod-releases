"""The project's immutable ideas, through the same owner used by the Console."""

from connectrpc.errors import ConnectError
from sentientx.sx.autonomy.ask.v1 import ask_connect, ideas_pb2

from sx._rpc import raise_rpc, validated
from sx._transport import RpcBinding


class Ideas:
    def __init__(self, binding: RpcBinding) -> None:
        self._headers = binding.headers
        self._client = ask_connect.ProjectAskServiceClient(binding.address)

    async def close(self) -> None:
        await self._client.close()

    async def list(
        self, *, limit: int = 50, before: str | None = None, kept_only: bool = False
    ) -> ideas_pb2.ListIdeasResponse:
        request = ideas_pb2.ListIdeasRequest(limit=limit, kept_only=kept_only)
        if before is not None:
            request.before = before
        try:
            return validated(
                await self._client.list_ideas(
                    validated(request, label="idea page"), headers=self._headers, timeout_ms=30_000
                ),
                label="idea page",
            )
        except ConnectError as error:
            raise_rpc(error)

    async def get(self, id: str) -> ideas_pb2.Idea:
        try:
            response = await self._client.get_idea(
                validated(ideas_pb2.GetIdeaRequest(id=id), label="idea lookup"),
                headers=self._headers,
                timeout_ms=30_000,
            )
            return validated(response, label="idea").idea
        except ConnectError as error:
            raise_rpc(error)

    async def create(
        self, content: ideas_pb2.IdeaContent, *, parent_id: str | None = None, idempotency_key: str
    ) -> ideas_pb2.Idea:
        request = ideas_pb2.CreateIdeaRequest(content=content)
        if parent_id is not None:
            request.parent_id = parent_id
        try:
            response = await self._client.create_idea(
                validated(request, label="idea revision"),
                headers={**self._headers, "idempotency-key": idempotency_key},
                timeout_ms=30_000,
            )
            return validated(response, label="idea revision").idea
        except ConnectError as error:
            raise_rpc(error)

    async def keep(self, id: str) -> ideas_pb2.Idea:
        try:
            response = await self._client.keep_idea(
                validated(ideas_pb2.KeepIdeaRequest(id=id), label="keep idea"),
                headers=self._headers,
                timeout_ms=30_000,
            )
            return validated(response, label="kept idea").idea
        except ConnectError as error:
            raise_rpc(error)
