"""Generated Connect client for the one Autonomy-owned training operation family.

Reattachment, bounded replay, typed refusals and explicit cancellation all cross this
boundary as generated messages. `TrainingProgress` from `sx_autonomy` and `VlaPolicy`
from `sx_contracts` are the domain values the façade returns; this module transforms
between those values and the wire.
"""

from __future__ import annotations

from dataclasses import asdict
from datetime import UTC, datetime, timedelta

from connectrpc.errors import ConnectError
from google.protobuf.timestamp_pb2 import Timestamp
from sentientx.sx.autonomy.train.v1 import training_connect, training_pb2
from sentientx.sx.common.v1 import common_pb2
from sx_autonomy import TrainingProgress, training_progress_from_dict
from sx_contracts import (
    AcceptedOperation,
    ArtifactId,
    CancelledOperation,
    ContentRef,
    FailedOperation,
    IdempotencyKey,
    OperationFailure,
    OperationId,
    OperationKind,
    OperationProgress,
    OperationReceipt,
    OperationRef,
    PlatformPillar,
    RunningOperation,
    Sha256Digest,
    SucceededOperation,
    TraceId,
    UpdateCursor,
    VlaPolicy,
)

from sx._errors import OperationHistoryGapError, OperationProtocolError
from sx._rpc import cancellation_from_proto as _cancellation
from sx._rpc import history_gap_cursor as _history_gap_cursor
from sx._rpc import raise_rpc as _raise_rpc
from sx._rpc import resource_from_proto as _resource
from sx._rpc import validated as _validated
from sx._transport import RpcBinding

_RPC_TIMEOUT_MS = 30_000


def _operation_ref(ref: OperationRef[object, object]) -> common_pb2.OperationRef:
    if ref.pillar is not PlatformPillar.AUTONOMY or ref.kind is not OperationKind.TRAINING:
        raise OperationProtocolError(f"training cannot own {ref}")
    return common_pb2.OperationRef(
        pillar=common_pb2.PLATFORM_PILLAR_AUTONOMY,
        kind=common_pb2.OPERATION_KIND_TRAINING,
        operation_id=str(ref.operation_id),
    )


def _datetime(value: Timestamp) -> datetime:
    return value.ToDatetime(tzinfo=UTC)


def _progress(value: training_pb2.TrainingProgress) -> OperationProgress:
    """The ledger mapping the receipt carries, built through the domain value.

    `TrainingProgress` runs the admitted-step-range law on the way through, so a snapshot
    that leaves that range is refused here. Unlike `CaptureProgress` it is not itself a
    `Mapping`, so the receipt carries its ledger form and this client's own `progress`
    reconstructs the typed value for the caller — one representation, not two.
    """

    return asdict(
        TrainingProgress(
            completed_steps=value.completed_steps,
            total_steps=value.total_steps,
            latest_checkpoint=(
                value.latest_checkpoint if value.HasField("latest_checkpoint") else None
            ),
        )
    )


def _content_ref(value: common_pb2.ContentRef) -> ContentRef:
    return ContentRef(ArtifactId(value.artifact_id), Sha256Digest(value.sha256))


def _receipt(value: training_pb2.TrainingOperation) -> OperationReceipt:
    _validated(value, label="Autonomy training operation")
    metadata = value.metadata
    ref = metadata.ref
    if (
        ref.pillar != common_pb2.PLATFORM_PILLAR_AUTONOMY
        or ref.kind != common_pb2.OPERATION_KIND_TRAINING
    ):
        raise OperationProtocolError("training returned a non-training operation")
    operation_id = OperationId(ref.operation_id)
    resource = _resource(metadata.resource)
    trace_id = TraceId(metadata.trace_id)
    cursor = UpdateCursor(metadata.cursor)
    key = IdempotencyKey(metadata.idempotency_key) if metadata.HasField("idempotency_key") else None
    progress = _progress(value.progress)
    created_at = _datetime(metadata.created_at)
    updated_at = _datetime(metadata.updated_at)
    arm = value.lifecycle.WhichOneof("state")
    if arm == "accepted":
        return AcceptedOperation(
            operation_id,
            PlatformPillar.AUTONOMY,
            OperationKind.TRAINING,
            resource,
            trace_id,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            cancellation=_cancellation(value.lifecycle.accepted),
            created_at=created_at,
            updated_at=updated_at,
        )
    if arm == "running":
        return RunningOperation(
            operation_id,
            PlatformPillar.AUTONOMY,
            OperationKind.TRAINING,
            resource,
            trace_id,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            cancellation=_cancellation(value.lifecycle.running),
            created_at=created_at,
            updated_at=updated_at,
        )
    if arm == "succeeded":
        return SucceededOperation(
            operation_id,
            PlatformPillar.AUTONOMY,
            OperationKind.TRAINING,
            resource,
            trace_id,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            created_at=created_at,
            updated_at=updated_at,
            completed_at=_datetime(value.lifecycle.succeeded.completed_at),
        )
    if arm == "failed":
        failed = value.lifecycle.failed
        return FailedOperation(
            operation_id,
            PlatformPillar.AUTONOMY,
            OperationKind.TRAINING,
            resource,
            trace_id,
            OperationFailure(
                failed.failure.code,
                failed.failure.message,
                failed.failure.retryable,
            ),
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            created_at=created_at,
            updated_at=updated_at,
            failed_at=_datetime(failed.failed_at),
        )
    if arm == "cancelled":
        cancelled = value.lifecycle.cancelled
        return CancelledOperation(
            operation_id,
            PlatformPillar.AUTONOMY,
            OperationKind.TRAINING,
            resource,
            trace_id,
            cancelled.reason,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            created_at=created_at,
            updated_at=updated_at,
            cancelled_at=_datetime(cancelled.cancelled_at),
        )
    raise OperationProtocolError(f"unknown training lifecycle arm {arm!r}")


def _receipt_for(
    expected: OperationRef[object, object],
    value: training_pb2.TrainingOperation,
) -> OperationReceipt:
    """Decode a receipt and prove the owner answered for the requested operation."""

    receipt = _receipt(value)
    if receipt.ref != expected:
        raise OperationProtocolError(
            f"training returned {receipt.ref} while {expected} was requested"
        )
    return receipt


class TrainingOwnerClient:
    """Generated Connect client for the one Autonomy-owned training operation family."""

    def __init__(self, binding: RpcBinding) -> None:
        self._headers = binding.headers
        self._client = training_connect.TrainingJobServiceClient(binding.address)

    async def close(self) -> None:
        await self._client.close()

    def progress(self, receipt: OperationReceipt) -> TrainingProgress | None:
        """The live step ledger this receipt carries, as the domain value it is."""

        if receipt.progress is None:
            return None
        return training_progress_from_dict(receipt.progress)

    async def start(
        self, request: training_pb2.CreateTrainingJobRequest, *, idempotency_key: str
    ) -> OperationReceipt:
        _validated(request, label="training admission")
        try:
            response = await self._client.create_training_job(
                request,
                headers={**self._headers, "Idempotency-Key": idempotency_key},
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _receipt(_validated(response, label="training admission response").operation)

    async def start_custom(
        self, request: training_pb2.CreateCustomTrainingJobRequest, *, idempotency_key: str
    ) -> OperationReceipt:
        _validated(request, label="custom training admission")
        try:
            response = await self._client.create_custom_training_job(
                request,
                headers={**self._headers, "Idempotency-Key": idempotency_key},
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _receipt(_validated(response, label="custom training admission response").operation)

    async def status(self, ref: OperationRef[object, object]) -> OperationReceipt:
        request = _validated(
            training_pb2.GetTrainingOperationRequest(operation=_operation_ref(ref)),
            label="training status request",
        )
        try:
            response = await self._client.get_training_operation(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _receipt_for(ref, _validated(response, label="training status response").operation)

    async def updates(
        self,
        ref: OperationRef[object, object],
        *,
        after: UpdateCursor | None,
        page_size: int,
        wait_s: float,
    ) -> tuple[OperationReceipt, ...]:
        request = training_pb2.GetTrainingOperationUpdatesRequest(
            operation=_operation_ref(ref),
            limit=page_size,
            wait_timeout=timedelta(seconds=wait_s),
        )
        if after is not None:
            request.after_cursor = int(after)
        _validated(request, label="training updates request")
        try:
            response = await self._client.get_training_operation_updates(
                request, headers=self._headers, timeout_ms=int((wait_s + 5.0) * 1000)
            )
        except ConnectError as error:
            _raise_rpc(error)
        _validated(response, label="training updates response")
        arm = response.WhichOneof("outcome")
        if arm == "page":
            return tuple(_receipt_for(ref, item) for item in response.page.updates)
        if arm == "history_gap":
            latest = await self.status(ref)
            raise OperationHistoryGapError(_history_gap_cursor(response.history_gap), latest)
        raise OperationProtocolError(f"unknown training updates outcome {arm!r}")

    async def cancel(self, ref: OperationRef[object, object], *, reason: str) -> OperationReceipt:
        request = _validated(
            training_pb2.CancelTrainingOperationRequest(
                operation=_operation_ref(ref), reason=reason
            ),
            label="training cancellation request",
        )
        try:
            response = await self._client.cancel_training_operation(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _receipt_for(
            ref, _validated(response, label="training cancellation response").operation
        )

    async def result(self, ref: OperationRef[object, object]) -> VlaPolicy:
        request = _validated(
            training_pb2.GetTrainingOperationResultRequest(operation=_operation_ref(ref)),
            label="training result request",
        )
        try:
            response = await self._client.get_training_operation_result(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            _raise_rpc(error)
        _validated(response, label="training result response")
        if response.result.WhichOneof("result") != "training":
            raise OperationProtocolError("training returned an unknown result")
        vla = response.result.training.vla
        return VlaPolicy(
            artifact=_content_ref(vla.artifact),
            checkpoint=_content_ref(vla.checkpoint),
        )
