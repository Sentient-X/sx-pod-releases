"""Shared fail-closed laws for generated Python RPC clients."""

from datetime import UTC
from typing import NoReturn

from connectrpc.errors import ConnectError
from google.protobuf.message import Message
from protovalidate import ValidationError, Validator
from sentientx.sx.common.v1 import common_pb2
from sentientx.sx.operations.v1 import operations_pb2
from sx_contracts import CancellationRequest, ResourceRef, TraceId, UpdateCursor

from sx._errors import OperationProtocolError, Refusal, RpcError

_VALIDATOR = Validator()


def validated[MessageT: Message](message: MessageT, *, label: str) -> MessageT:
    try:
        _VALIDATOR.validate(message)
    except ValidationError as error:
        raise OperationProtocolError(f"{label} violates its protobuf contract: {error}") from error
    return message


def resource_from_proto(value: common_pb2.ResourceRef) -> ResourceRef:
    return ResourceRef(f"{value.owner}/{value.kind}/{value.id}")


def cancellation_from_proto(
    value: operations_pb2.AcceptedOperation | operations_pb2.RunningOperation,
) -> CancellationRequest | None:
    """The one live lifecycle arm that may carry a caller's pending cancellation.

    Lawful absence: an owner that has not been asked to stop has nothing to report,
    and every family shares this exact arm of the common lifecycle message.
    """

    if not value.HasField("cancellation"):
        return None
    cancellation = value.cancellation
    return CancellationRequest(
        reason=cancellation.reason,
        requested_at=cancellation.requested_at.ToDatetime(tzinfo=UTC),
    )


def history_gap_cursor(value: operations_pb2.OperationHistoryGap) -> UpdateCursor | None:
    """Preserve the wire's lawful absence for a request before the first cursor."""

    return UpdateCursor(value.requested_after) if value.HasField("requested_after") else None


def raise_rpc(error: ConnectError) -> NoReturn:
    """Raise one typed SDK refusal and reject opaque or malformed RPC errors."""

    refusal: Refusal | None = None
    for packed in error.details:
        detail = common_pb2.RefusalDetail()
        if packed.type_url != "type.googleapis.com/sentientx.sx.common.v1.RefusalDetail":
            continue
        if not packed.Unpack(detail):
            raise OperationProtocolError("RPC carried an unreadable RefusalDetail") from error
        validated(detail, label="RPC refusal")
        refusal = Refusal(
            code=detail.code,
            retryable=detail.retryable,
            resource=(
                resource_from_proto(detail.resource) if detail.HasField("resource") else None
            ),
            trace_id=TraceId(detail.trace_id),
            retry_after=(
                detail.retry_after.ToTimedelta() if detail.HasField("retry_after") else None
            ),
        )
        break
    if refusal is None:
        raise OperationProtocolError(
            "RPC did not carry the required generated RefusalDetail"
        ) from error
    raise RpcError(error.code.value, error.message, refusal) from error
