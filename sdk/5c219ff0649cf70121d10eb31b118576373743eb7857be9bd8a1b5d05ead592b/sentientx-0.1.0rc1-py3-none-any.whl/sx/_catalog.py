"""Generated Catalog clients and typed transforms at its public boundaries."""

from __future__ import annotations

from collections.abc import Mapping, Sequence

from connectrpc.errors import ConnectError
from google.protobuf.message import Message
from sentientx.sx.experience.catalog.v1 import (
    applications_connect,
    applications_pb2,
    catalog_connect,
    catalog_pb2,
    evidence_connect,
    evidence_pb2,
    membership_connect,
    membership_pb2,
    pipelines_connect,
    pipelines_pb2,
)
from sx_autonomy import CapabilityApproval
from sx_catalog_protocol import (
    ProtocolTransformError,
    assembly_definition_to_proto,
    asset_from_dict,
    asset_to_proto,
    capability_approval_from_proto,
    capability_approval_to_proto,
    corpus_snapshot_from_proto,
    embodiment_from_proto,
    part_to_proto,
    pipeline_plan_to_proto,
    plan_estimate_from_proto,
    robot_application_from_proto,
    selection_member_to_proto,
    task_contract_from_proto,
    task_contract_ref_from_proto,
    task_contract_ref_to_proto,
    task_contract_to_proto,
    world_run_from_proto,
)
from sx_contracts import (
    RobotApplication,
    RobotApplicationRef,
    TaskContract,
    TaskContractRef,
    contract_ref,
)
from sx_contracts.pipelines import PipelinePlan
from sx_contracts.usage import PlanEstimate
from sx_corpora import CorpusSnapshot, SelectionMember
from sx_embodiments import Embodiment
from sx_embodiments.assemble import part_from_dict
from sx_worlds import WorldRun

from sx._errors import OperationProtocolError
from sx._rpc import raise_rpc, validated
from sx._transport import RpcBinding

_RPC_TIMEOUT_MS = 30_000
_TASK_PAGE_SIZE = 2_000
# The application page is bounded by its own schema at 200; asking for more is
# refused by the owner rather than silently truncated.
_APPLICATION_PAGE_SIZE = 200


def _correlated[ResponseT: Message](
    request: Message,
    response: ResponseT,
    *,
    label: str,
) -> ResponseT:
    validated(response, label=f"{label} response")
    echoed = getattr(response, "request", None)
    if not isinstance(echoed, Message) or echoed != request:
        raise OperationProtocolError(f"Catalog {label} returned another request")
    return response


class CatalogTaskOwnerClient:
    """The generated Catalog task boundary, projected into canonical contracts."""

    def __init__(self, binding: RpcBinding) -> None:
        self._headers = binding.headers
        self._client = catalog_connect.CatalogTaskServiceClient(binding.address)

    async def close(self) -> None:
        await self._client.close()

    async def list_project_tasks(self) -> tuple[TaskContract, ...]:
        tasks: list[TaskContract] = []
        after_task_id: str | None = None
        while True:
            request = catalog_pb2.ListProjectTasksRequest(limit=_TASK_PAGE_SIZE)
            if after_task_id is not None:
                request.after_task_id = after_task_id
            response = await self._list_project_task_page(request)
            tasks.extend(self._project_contract(task) for task in response.tasks)
            if not response.HasField("next_page_after"):
                return tuple(tasks)
            after_task_id = response.next_page_after

    async def get_project_task(self, reference: TaskContractRef) -> TaskContract:
        request = validated(
            catalog_pb2.GetProjectTaskRequest(task_id=str(reference.task_id)),
            label="project task request",
        )
        try:
            response = await self._client.get_project_task(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            raise_rpc(error)
        task = self._project_contract(_correlated(request, response, label="project task").task)
        if contract_ref(task) != reference:
            raise OperationProtocolError("Catalog returned another task revision")
        return task

    async def publish_task(self, contract: TaskContract) -> TaskContract:
        request = validated(
            catalog_pb2.PublishTaskRequest(contract=task_contract_to_proto(contract)),
            label="task publication request",
        )
        try:
            response = await self._client.publish_task(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            raise_rpc(error)
        published = self._project_contract(
            _correlated(request, response, label="task publication").task
        )
        if contract_ref(published) != contract_ref(contract):
            raise OperationProtocolError("Catalog returned another published task revision")
        return published

    async def _list_project_task_page(
        self, request: catalog_pb2.ListProjectTasksRequest
    ) -> catalog_pb2.ListProjectTasksResponse:
        validated(request, label="project task list request")
        try:
            response = await self._client.list_project_tasks(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            raise_rpc(error)
        return _correlated(request, response, label="project task list")

    @staticmethod
    def _project_contract(value: catalog_pb2.ProjectTaskResource) -> TaskContract:
        try:
            contract = task_contract_from_proto(value.definition.contract)
            defined = task_contract_ref_from_proto(value.definition.reference)
            admitted = task_contract_ref_from_proto(value.admission.task)
        except ProtocolTransformError as error:
            raise OperationProtocolError("Catalog returned a malformed task") from error
        canonical = contract_ref(contract)
        if defined != canonical or admitted != defined:
            raise OperationProtocolError(
                "Catalog task admission disagrees with its complete contract"
            )
        return contract


class CatalogApplicationOwnerClient:
    """The generated Catalog application boundary, projected into domain values."""

    def __init__(self, binding: RpcBinding) -> None:
        self._headers = binding.headers
        self._client = applications_connect.CatalogApplicationServiceClient(binding.address)

    async def close(self) -> None:
        await self._client.close()

    async def list_applications(self) -> tuple[RobotApplication, ...]:
        """Drain the project registry one bounded, cursor-correlated page at a time."""

        applications: list[RobotApplication] = []
        after_application_ref: str | None = None
        while True:
            request = applications_pb2.ListApplicationsRequest(limit=_APPLICATION_PAGE_SIZE)
            if after_application_ref is not None:
                request.after_application_ref = after_application_ref
            response = await self._list_application_page(request)
            applications.extend(
                self._application(resource.application) for resource in response.applications
            )
            if not response.HasField("next_page_after"):
                return tuple(applications)
            after_application_ref = response.next_page_after

    async def get_application(self, reference: RobotApplicationRef) -> RobotApplication:
        request = validated(
            applications_pb2.GetApplicationRequest(application_ref=str(reference)),
            label="robot application request",
        )
        try:
            response = await self._client.get_application(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            raise_rpc(error)
        correlated = _correlated(request, response, label="robot application")
        return self._application(correlated.application.application)

    async def register_capability_approval(
        self, approval: CapabilityApproval, *, name: str
    ) -> CapabilityApproval:
        """Register one exact approval; its schema binds name, evidence, and identity."""

        request = validated(
            applications_pb2.RegisterCapabilityApprovalRequest(
                name=name,
                approval=capability_approval_to_proto(approval),
            ),
            label="capability approval request",
        )
        try:
            response = await self._client.register_capability_approval(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            raise_rpc(error)
        correlated = _correlated(request, response, label="capability approval")
        try:
            return capability_approval_from_proto(correlated.approval.approval)
        except ProtocolTransformError as error:
            raise OperationProtocolError(
                "Catalog returned a malformed capability approval"
            ) from error

    async def _list_application_page(
        self, request: applications_pb2.ListApplicationsRequest
    ) -> applications_pb2.ListApplicationsResponse:
        validated(request, label="robot application list request")
        try:
            response = await self._client.list_applications(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            raise_rpc(error)
        return _correlated(request, response, label="robot application list")

    @staticmethod
    def _application(value: applications_pb2.RobotApplicationDocument) -> RobotApplication:
        try:
            return robot_application_from_proto(value)
        except ProtocolTransformError as error:
            raise OperationProtocolError(
                "Catalog returned a malformed robot application"
            ) from error


class CatalogEvidenceOwnerClient:
    """The generated Catalog evidence boundary, projected into canonical runs."""

    def __init__(self, binding: RpcBinding) -> None:
        self._headers = binding.headers
        self._client = evidence_connect.CatalogEvidenceServiceClient(binding.address)

    async def close(self) -> None:
        await self._client.close()

    async def get_world_run(self, run_id: str) -> WorldRun:
        """Resolve one exact governed run; the transform re-derives its identity.

        The response schema binds the stored resource to the echoed request id and
        to the entry name minted from it, and the transform refuses bytes that are
        not canonical or that name another run — so the returned run's identity is
        proved rather than restated at this call site.
        """

        request = validated(
            evidence_pb2.GetWorldRunRequest(run_id=run_id),
            label="world run request",
        )
        try:
            response = await self._client.get_world_run(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            raise_rpc(error)
        correlated = _correlated(request, response, label="world run")
        try:
            return world_run_from_proto(correlated.run.run)
        except ProtocolTransformError as error:
            raise OperationProtocolError("Catalog returned a malformed world run") from error


class CatalogPipelineOwnerClient:
    """The generated Catalog pipeline boundary; one public verb reaches it.

    Submission and run control belong to `sx-catalog-client` and the pipeline
    executor, so the only method here is the quote — the one thing a person asks
    before deciding to spend.
    """

    def __init__(self, binding: RpcBinding) -> None:
        self._headers = binding.headers
        self._client = pipelines_connect.CatalogPipelineServiceClient(binding.address)

    async def close(self) -> None:
        await self._client.close()

    async def estimate_plan(
        self, plan: PipelinePlan, *, assumed_partition_seconds: int
    ) -> PlanEstimate:
        """Quote this plan under this assumed partition duration, and prove it.

        The response schema binds the quote's assumed duration to the echoed
        request's, so a quote priced under an assumption nobody asked for cannot
        be read as one that was.
        """

        request = validated(
            pipelines_pb2.EstimatePlanRequest(
                plan=pipeline_plan_to_proto(plan),
                assumed_partition_seconds=assumed_partition_seconds,
            ),
            label="plan estimate request",
        )
        try:
            response = await self._client.estimate_plan(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            raise_rpc(error)
        correlated = _correlated(request, response, label="plan estimate")
        try:
            return plan_estimate_from_proto(correlated.estimate)
        except ProtocolTransformError as error:
            raise OperationProtocolError("Catalog returned a malformed plan estimate") from error


class CatalogOwnerClient:
    """The generated async client for Catalog's embodiment owner family."""

    def __init__(self, binding: RpcBinding) -> None:
        self._headers = binding.headers
        self._client = catalog_connect.CatalogEmbodimentServiceClient(binding.address)

    @staticmethod
    def _definition(value: Mapping[str, object]) -> catalog_pb2.AssemblyDefinition:
        try:
            return assembly_definition_to_proto(value)
        except ProtocolTransformError as error:
            raise OperationProtocolError("assembly definition is malformed") from error

    async def close(self) -> None:
        await self._client.close()

    async def parts(self) -> tuple[catalog_pb2.ComposablePartResource, ...]:
        try:
            response = await self._client.list_composable_parts(
                catalog_pb2.ListComposablePartsRequest(),
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            raise_rpc(error)
        return tuple(validated(response, label="Catalog part list").parts)

    async def validate(self, definition: Mapping[str, object], *, urdf_xml: str) -> Embodiment:
        request = validated(
            catalog_pb2.ValidateEmbodimentAssemblyRequest(
                definition=self._definition(definition),
                urdf=urdf_xml.encode(),
            ),
            label="embodiment validation request",
        )
        try:
            response = await self._client.validate_embodiment_assembly(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            raise_rpc(error)
        return self._embodiment(
            validated(response, label="embodiment validation response").embodiment
        )

    async def register(self, definition: Mapping[str, object], *, urdf_xml: str) -> Embodiment:
        request = validated(
            catalog_pb2.RegisterAssembledEmbodimentRequest(
                definition=self._definition(definition),
                urdf=urdf_xml.encode(),
            ),
            label="embodiment registration request",
        )
        try:
            response = await self._client.register_assembled_embodiment(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            raise_rpc(error)
        return self._embodiment(
            validated(response, label="embodiment registration response").embodiment.embodiment
        )

    async def get(self, name: str) -> Embodiment:
        request = validated(
            catalog_pb2.GetEmbodimentRequest(name=name),
            label="embodiment get request",
        )
        try:
            response = await self._client.get_embodiment(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            raise_rpc(error)
        return self._embodiment(
            validated(response, label="embodiment get response").embodiment.embodiment
        )

    async def preview(
        self, task: TaskContract, *, body_name: str
    ) -> catalog_pb2.CandidateAdmissibility:
        request = validated(
            catalog_pb2.PreviewCandidateAdmissibilityRequest(
                task=task_contract_to_proto(task),
                body_name=body_name,
            ),
            label="candidate admissibility request",
        )
        try:
            response = await self._client.preview_candidate_admissibility(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            raise_rpc(error)
        return validated(response, label="candidate admissibility response").admissibility

    async def admissibility(self) -> catalog_pb2.AdmissibilityScorecard:
        try:
            response = await self._client.get_embodiment_admissibility(
                catalog_pb2.GetEmbodimentAdmissibilityRequest(),
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            raise_rpc(error)
        return validated(response, label="embodiment admissibility response").scorecard

    async def readiness(self) -> tuple[catalog_pb2.EmbodimentReadiness, ...]:
        try:
            response = await self._client.get_embodiment_readiness(
                catalog_pb2.GetEmbodimentReadinessRequest(),
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            raise_rpc(error)
        return tuple(validated(response, label="embodiment readiness response").embodiments)

    async def frontier(self, *, depth: int | None = None) -> catalog_pb2.EmbodimentFrontier:
        request = catalog_pb2.GetEmbodimentFrontierRequest()
        if depth is not None:
            request.depth = depth
        validated(request, label="embodiment frontier request")
        try:
            response = await self._client.get_embodiment_frontier(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            raise_rpc(error)
        return validated(response, label="embodiment frontier response").frontier

    async def admit_part(
        self,
        part: Mapping[str, object],
        *,
        urdf_xml: str,
        assets: tuple[Mapping[str, object], ...],
    ) -> catalog_pb2.AdmitEmbodimentPartResponse:
        try:
            domain_part = part_from_dict(part)
            asset_messages = [
                asset_to_proto(asset_from_dict(value, label=f"part admission assets[{index}]"))
                for index, value in enumerate(assets)
            ]
        except ValueError as error:
            raise OperationProtocolError(f"part admission is malformed: {error}") from error
        request = validated(
            catalog_pb2.AdmitEmbodimentPartRequest(
                part=part_to_proto(domain_part),
                urdf=urdf_xml.encode(),
                assets=asset_messages,
            ),
            label="part admission request",
        )
        try:
            response = await self._client.admit_embodiment_part(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            raise_rpc(error)
        return validated(response, label="part admission response")

    @staticmethod
    def _embodiment(value: catalog_pb2.Embodiment) -> Embodiment:
        try:
            return embodiment_from_proto(value)
        except ProtocolTransformError as error:
            raise OperationProtocolError("Catalog returned a malformed embodiment") from error


class CatalogMembershipOwnerClient:
    """The generated Catalog membership boundary: the two public mints.

    Both answer a value the caller can hold — a corpus for a dataset taken under
    one task revision, and the immutable membership a lasso froze — so both echo
    their request and both reconstruct the domain value rather than returning the
    message.
    """

    def __init__(self, binding: RpcBinding) -> None:
        self._headers = binding.headers
        self._client = membership_connect.CatalogMembershipServiceClient(binding.address)

    async def close(self) -> None:
        await self._client.close()

    async def snapshot_dataset(self, dataset: str, task: TaskContractRef) -> CorpusSnapshot:
        """Freeze this dataset for this exact revision and compose its corpus.

        Idempotent by the request rather than by what the request finds: asking
        twice answers the same corpus, including after the dataset has admitted a
        member in between.
        """

        request = validated(
            membership_pb2.SnapshotDatasetRequest(
                dataset=dataset, task=task_contract_ref_to_proto(task)
            ),
            label="dataset snapshot request",
        )
        try:
            response = await self._client.snapshot_dataset(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            raise_rpc(error)
        correlated = _correlated(request, response, label="dataset snapshot")
        try:
            return corpus_snapshot_from_proto(correlated.corpus)
        except ProtocolTransformError as error:
            raise OperationProtocolError("Catalog returned a malformed corpus") from error

    async def snapshot_selection(
        self, members: Sequence[SelectionMember]
    ) -> membership_pb2.DatasetSnapshot:
        """Freeze exactly these members as one immutable membership.

        The answer is the generated projection: a snapshot's facts are fixed-width
        scalars and one structural identity arm, and there is no richer in-process
        value for them to be narrowed into.
        """

        request = validated(
            membership_pb2.SnapshotSelectionRequest(
                members=[selection_member_to_proto(member) for member in members]
            ),
            label="selection snapshot request",
        )
        try:
            response = await self._client.snapshot_selection(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            raise_rpc(error)
        return _correlated(request, response, label="selection snapshot").snapshot
