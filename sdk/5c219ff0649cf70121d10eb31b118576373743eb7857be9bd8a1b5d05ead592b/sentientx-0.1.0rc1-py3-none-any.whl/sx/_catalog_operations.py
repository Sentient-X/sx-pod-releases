"""Catalog's durable-operation cluster and its policy reads, over one generated client.

Catalog's nine admissions all write one ledger, so the four controls every
Catalog operation is reattached through belong to the same owner service. This
module is the SDK half of that cluster: it turns a canonical
:class:`~sx_contracts.OperationRef` into the generated request, and the generated
answer back into the canonical receipt.

The terminal value is the generated ``CatalogOperationResult`` itself — one
closed thirteen-arm oneof — rather than thirteen hand-written Python records.
Only two of those arms name a value this repository already owns as a domain
type; minting eleven more here would be the second object model the cutover
exists to remove. A caller discriminates with ``WhichOneof("result")``, which is
exactly the closed set the owner is allowed to answer with.
"""

from __future__ import annotations

from collections.abc import Awaitable
from datetime import timedelta

from connectrpc.errors import ConnectError
from sentientx.sx.common.v1 import common_pb2
from sentientx.sx.experience.catalog.v1 import operations_connect, operations_pb2
from sx_catalog_protocol import (
    CATALOG_KINDS_TO_PROTO,
    ProtocolTransformError,
    operation_receipt_from_proto,
)
from sx_contracts import (
    OperationReceipt,
    OperationRef,
    PlatformPillar,
    UpdateCursor,
)

from sx._errors import OperationHistoryGapError, OperationProtocolError
from sx._rpc import history_gap_cursor as _history_gap_cursor
from sx._rpc import raise_rpc as _raise_rpc
from sx._rpc import validated as _validated
from sx._transport import RpcBinding

_RPC_TIMEOUT_MS = 30_000


async def _call[ResponseT](awaitable: Awaitable[ResponseT]) -> ResponseT:
    """Await one generated call and keep Connect's error mapping in one place."""

    try:
        return await awaitable
    except ConnectError as error:
        _raise_rpc(error)


def _operation_ref(ref: OperationRef[object, object]) -> common_pb2.OperationRef:
    if ref.pillar is not PlatformPillar.EXPERIENCE or ref.kind not in CATALOG_KINDS_TO_PROTO:
        raise OperationProtocolError(f"Catalog cannot own {ref}")
    return common_pb2.OperationRef(
        pillar=common_pb2.PLATFORM_PILLAR_EXPERIENCE,
        kind=CATALOG_KINDS_TO_PROTO[ref.kind],
        operation_id=str(ref.operation_id),
    )


def _receipt(value: operations_pb2.CatalogOperation) -> OperationReceipt:
    _validated(value, label="Catalog operation")
    try:
        return operation_receipt_from_proto(value)
    except (ProtocolTransformError, ValueError) as error:
        raise OperationProtocolError(str(error)) from error


def _receipt_for(
    expected: OperationRef[object, object], value: operations_pb2.CatalogOperation
) -> OperationReceipt:
    receipt = _receipt(value)
    if receipt.ref != expected:
        raise OperationProtocolError(
            f"Catalog returned {receipt.ref} while {expected} was requested"
        )
    return receipt


class CatalogOperationOwnerClient:
    """Generated Connect client for Catalog's one durable-operation ledger."""

    def __init__(self, binding: RpcBinding) -> None:
        self._headers = binding.headers
        self._client = operations_connect.CatalogOperationServiceClient(binding.address)

    async def close(self) -> None:
        await self._client.close()

    def progress(self, receipt: OperationReceipt) -> None:
        """Catalog measures none.

        The REST door's `progress` was the terminal outputs document read early,
        which is why the generated operation has no progress oneof: a caller that
        wants detail before completion has nothing truthful to read. Answering
        `None` says exactly that.
        """

        del receipt
        return None

    async def status(self, ref: OperationRef[object, object]) -> OperationReceipt:
        request = _validated(
            operations_pb2.GetCatalogOperationRequest(operation=_operation_ref(ref)),
            label="Catalog status request",
        )
        response = await _call(
            self._client.get_catalog_operation(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        )
        return _receipt_for(ref, _validated(response, label="Catalog status response").operation)

    async def updates(
        self,
        ref: OperationRef[object, object],
        *,
        after: UpdateCursor | None,
        page_size: int,
        wait_s: float,
    ) -> tuple[OperationReceipt, ...]:
        request = operations_pb2.GetCatalogOperationUpdatesRequest(
            operation=_operation_ref(ref),
            limit=page_size,
            wait_timeout=timedelta(seconds=wait_s),
        )
        if after is not None:
            request.after_cursor = int(after)
        _validated(request, label="Catalog updates request")
        response = await _call(
            self._client.get_catalog_operation_updates(
                request, headers=self._headers, timeout_ms=int((wait_s + 5.0) * 1000)
            )
        )
        _validated(response, label="Catalog updates response")
        arm = response.WhichOneof("outcome")
        if arm == "page":
            return tuple(_receipt_for(ref, item) for item in response.page.updates)
        if arm == "history_gap":
            # The gap carries cursors only, so the current receipt is read from
            # the one method that mints it rather than embedded in the gap.
            latest = await self.status(ref)
            raise OperationHistoryGapError(_history_gap_cursor(response.history_gap), latest)
        raise OperationProtocolError(f"unknown Catalog updates outcome {arm!r}")

    async def cancel(self, ref: OperationRef[object, object], *, reason: str) -> OperationReceipt:
        request = _validated(
            operations_pb2.CancelCatalogOperationRequest(
                operation=_operation_ref(ref), reason=reason
            ),
            label="Catalog cancellation request",
        )
        response = await _call(
            self._client.cancel_catalog_operation(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        )
        return _receipt_for(
            ref, _validated(response, label="Catalog cancellation response").operation
        )

    async def result(
        self, ref: OperationRef[object, object]
    ) -> operations_pb2.CatalogOperationResult:
        request = _validated(
            operations_pb2.GetCatalogOperationResultRequest(operation=_operation_ref(ref)),
            label="Catalog result request",
        )
        response = await _call(
            self._client.get_catalog_operation_result(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        )
        _validated(response, label="Catalog result response")
        if response.operation != _operation_ref(ref):
            raise OperationProtocolError(
                f"Catalog returned a result for another operation than {ref}"
            )
        if response.result.WhichOneof("result") is None:
            raise OperationProtocolError("Catalog returned no result arm")
        return response.result

    async def policy(self, artifact_id: str) -> operations_pb2.DeployablePolicyResource:
        """Resolve one governed deployable policy — the `autonomy.policy` verb."""

        request = _validated(
            operations_pb2.GetPolicyRequest(artifact_id=artifact_id),
            label="Catalog policy request",
        )
        response = await _call(
            self._client.get_policy(request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS)
        )
        policy = _validated(response, label="Catalog policy response").policy
        if policy.policy.artifact.artifact_id != artifact_id:
            raise OperationProtocolError("Catalog returned another deployable policy")
        return policy

    async def policy_artifact_url(
        self, artifact_id: str
    ) -> operations_pb2.GetPolicyArtifactUrlResponse:
        """One short-lived presigned GET for the exact published policy bytes."""

        request = _validated(
            operations_pb2.GetPolicyArtifactUrlRequest(artifact_id=artifact_id),
            label="Catalog policy artifact request",
        )
        response = await _call(
            self._client.get_policy_artifact_url(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        )
        return _validated(response, label="Catalog policy artifact response")
