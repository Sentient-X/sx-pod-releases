"""Explicit CLI-local effect for opening episode bytes in Rerun."""

import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class OpenedEpisode:
    path: Path
    process_id: int


class EpisodeViewerError(RuntimeError):
    """The local episode or Rerun viewer is unavailable."""


def open_in_rerun(path: Path) -> OpenedEpisode:
    episode = path.resolve()
    if not episode.is_file() or episode.suffix.lower() != ".rrd":
        raise EpisodeViewerError("episode-open requires an existing local .rrd file")
    try:
        process = subprocess.Popen(
            [sys.executable, "-m", "rerun", str(episode)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except OSError as error:
        raise EpisodeViewerError("could not start the installed Rerun viewer") from error
    return OpenedEpisode(episode, process.pid)
