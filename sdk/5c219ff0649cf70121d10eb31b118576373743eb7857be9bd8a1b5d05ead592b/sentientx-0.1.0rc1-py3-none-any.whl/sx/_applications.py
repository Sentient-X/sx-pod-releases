"""Generated Autonomy client for content-addressed RobotApplication revisions."""

from connectrpc.errors import ConnectError
from sentientx.sx.autonomy.application.v1 import application_connect, application_pb2
from sx_catalog_protocol import content_ref_to_proto, robot_application_to_proto
from sx_contracts import ContentRef, RobotApplication, RobotApplicationRef

from sx._errors import OperationProtocolError
from sx._rpc import raise_rpc, validated
from sx._transport import RpcBinding

_RPC_TIMEOUT_MS = 30_000


class ApplicationOwnerClient:
    """The generated owner boundary behind ``sx.autonomy.applications.revise``."""

    def __init__(self, binding: RpcBinding) -> None:
        self._headers = binding.headers
        self._client = application_connect.ApplicationServiceClient(binding.address)

    async def close(self) -> None:
        await self._client.close()

    async def revise(
        self,
        base_application_ref: RobotApplicationRef,
        candidate: RobotApplication,
        *,
        inputs: tuple[tuple[ContentRef, bytes], ...] = (),
    ) -> RobotApplicationRef:
        request = validated(
            application_pb2.ReviseApplicationRequest(
                base_application_ref=str(base_application_ref),
                candidate=robot_application_to_proto(candidate),
                inputs=[
                    application_pb2.ApplicationInput(
                        content=content_ref_to_proto(content), data=data
                    )
                    for content, data in inputs
                ],
            ),
            label="Autonomy application revision request",
        )
        try:
            response = await self._client.revise_application(
                request,
                headers=self._headers,
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            raise_rpc(error)
        validated(response, label="Autonomy application revision response")
        if response.application_ref != str(candidate.ref):
            raise OperationProtocolError("Autonomy returned another application revision")
        return candidate.ref
