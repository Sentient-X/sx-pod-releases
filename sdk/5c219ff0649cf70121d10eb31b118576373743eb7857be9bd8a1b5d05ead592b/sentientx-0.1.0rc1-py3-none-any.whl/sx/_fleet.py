"""Total generated-Fleet transforms and the sole Python Fleet RPC client.

Deployment, rollback, and physical research share one durable ledger on the
Fleet door, so they share one client here. Commissioning admissions return their
generated messages: unlike a deployment there is no richer public value to
rebuild, and the previous HTTP path returned undecoded JSON for them.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC, datetime, timedelta
from typing import Literal
from uuid import UUID

from connectrpc.errors import ConnectError
from google.protobuf.json_format import ParseDict, ParseError
from google.protobuf.message import Message
from google.protobuf.timestamp_pb2 import Timestamp
from sentientx.sx.common.v1 import common_pb2, outcomes_pb2
from sentientx.sx.fleet.controlplane.v1 import controlplane_connect, controlplane_pb2
from sx_autonomy import CapabilityApprovalRef
from sx_contracts import (
    AcceptedOperation,
    CancelledOperation,
    CatalogRegistrationState,
    ContentRef,
    DeploymentGroupRef,
    FailedOperation,
    IdempotencyKey,
    OperationFailure,
    OperationId,
    OperationKind,
    OperationReceipt,
    OperationRef,
    PlatformPillar,
    ResearchRunState,
    RobotApplicationRef,
    RunningOperation,
    Sha256Digest,
    SucceededOperation,
    TaskVerdict,
    TraceId,
    UpdateCursor,
)
from sx_contracts.content import ArtifactId
from sx_fleet import (
    ApplicationDeployment,
    ApplicationDeploymentRef,
    ControlCause,
    ControlModality,
    ControlPurpose,
    ControlRequest,
    ControlRequestState,
    DeploymentState,
    ObservationActionSpan,
    RolloutRef,
    RolloutWave,
    StationId,
    SupervisionPolicyRef,
)
from sx_fleet.commissioning import CatalogDatasetName, ResearchPodId
from sx_fleet.deployment import TaskLease, TaskLeaseRef
from sx_fleet.research import (
    ApplicationProof,
    CatalogCommit,
    EpisodeCommit,
    ResearchRun,
    ResearchRunId,
    ResolvedService,
    RunBudget,
)

from sx._codec import read_only_progress
from sx._errors import OperationHistoryGapError, OperationProtocolError
from sx._rpc import cancellation_from_proto as _cancellation
from sx._rpc import history_gap_cursor as _history_gap_cursor
from sx._rpc import raise_rpc as _raise_rpc
from sx._rpc import resource_from_proto as _resource
from sx._rpc import validated as _validated
from sx._transport import RpcBinding

_RPC_TIMEOUT_MS = 30_000

_KIND_TO_PROTO = {
    OperationKind.DEPLOYMENT: common_pb2.OPERATION_KIND_DEPLOYMENT,
    OperationKind.ROLLBACK: common_pb2.OPERATION_KIND_ROLLBACK,
    OperationKind.RESEARCH: common_pb2.OPERATION_KIND_RESEARCH,
}
_KIND_FROM_PROTO = {number: kind for kind, number in _KIND_TO_PROTO.items()}
_DEPLOYMENT_STATE_FROM_PROTO = {
    controlplane_pb2.DEPLOYMENT_STATE_ROLLING_OUT: DeploymentState.ROLLING_OUT,
    controlplane_pb2.DEPLOYMENT_STATE_ACTIVE: DeploymentState.ACTIVE,
    controlplane_pb2.DEPLOYMENT_STATE_SAFE_STOPPED: DeploymentState.SAFE_STOPPED,
    controlplane_pb2.DEPLOYMENT_STATE_FAILED: DeploymentState.FAILED,
    controlplane_pb2.DEPLOYMENT_STATE_RETIRED: DeploymentState.RETIRED,
}
_RUN_STATE_FROM_PROTO = {
    controlplane_pb2.RESEARCH_RUN_STATE_ADMITTED: ResearchRunState.ADMITTED,
    controlplane_pb2.RESEARCH_RUN_STATE_PREPARING: ResearchRunState.PREPARING,
    controlplane_pb2.RESEARCH_RUN_STATE_RUNNING: ResearchRunState.RUNNING,
    controlplane_pb2.RESEARCH_RUN_STATE_WAITING_FOR_CONTROL: (ResearchRunState.WAITING_FOR_CONTROL),
    controlplane_pb2.RESEARCH_RUN_STATE_RESETTING: ResearchRunState.RESETTING,
    controlplane_pb2.RESEARCH_RUN_STATE_FINALIZING: ResearchRunState.FINALIZING,
    controlplane_pb2.RESEARCH_RUN_STATE_SUCCEEDED: ResearchRunState.SUCCEEDED,
    controlplane_pb2.RESEARCH_RUN_STATE_FAILED: ResearchRunState.FAILED,
    controlplane_pb2.RESEARCH_RUN_STATE_CANCELLED: ResearchRunState.CANCELLED,
}
_VERDICT_FROM_PROTO = {
    outcomes_pb2.TASK_VERDICT_SATISFIED: TaskVerdict.SATISFIED,
    outcomes_pb2.TASK_VERDICT_NOT_SATISFIED: TaskVerdict.NOT_SATISFIED,
    outcomes_pb2.TASK_VERDICT_UNKNOWN: TaskVerdict.UNKNOWN,
}
_REGISTRATION_FROM_PROTO = {
    controlplane_pb2.CATALOG_REGISTRATION_STATE_PENDING: CatalogRegistrationState.PENDING,
    controlplane_pb2.CATALOG_REGISTRATION_STATE_READY: CatalogRegistrationState.READY,
    controlplane_pb2.CATALOG_REGISTRATION_STATE_FAILED: CatalogRegistrationState.FAILED,
}
_PURPOSE_FROM_PROTO = {
    controlplane_pb2.CONTROL_PURPOSE_SUPERVISION_ESCALATION: (
        ControlPurpose.SUPERVISION_ESCALATION
    ),
    controlplane_pb2.CONTROL_PURPOSE_TERMINAL_VERIFICATION: (ControlPurpose.TERMINAL_VERIFICATION),
    controlplane_pb2.CONTROL_PURPOSE_RESET: ControlPurpose.RESET,
}
_CAUSE_FROM_PROTO = {
    controlplane_pb2.CONTROL_CAUSE_SUPERVISOR_STOP: ControlCause.SUPERVISOR_STOP,
    controlplane_pb2.CONTROL_CAUSE_ROBOMETER_UNKNOWN: ControlCause.ROBOMETER_UNKNOWN,
    controlplane_pb2.CONTROL_CAUSE_RESET_REQUIRED: ControlCause.RESET_REQUIRED,
    controlplane_pb2.CONTROL_CAUSE_RESET_VERIFICATION_UNKNOWN: (
        ControlCause.RESET_VERIFICATION_UNKNOWN
    ),
}
_MODALITY_FROM_PROTO = {
    controlplane_pb2.CONTROL_MODALITY_LOCAL_LEADER: ControlModality.LOCAL_LEADER,
    controlplane_pb2.CONTROL_MODALITY_REMOTE_TELEOPERATOR: ControlModality.REMOTE_TELEOPERATOR,
    controlplane_pb2.CONTROL_MODALITY_HANDS: ControlModality.HANDS,
    controlplane_pb2.CONTROL_MODALITY_AUTOMATED_RESET: ControlModality.AUTOMATED_RESET,
}
_REQUEST_STATE_FROM_PROTO = {
    controlplane_pb2.CONTROL_REQUEST_STATE_PENDING: ControlRequestState.PENDING,
    controlplane_pb2.CONTROL_REQUEST_STATE_OFFERED: ControlRequestState.OFFERED,
    controlplane_pb2.CONTROL_REQUEST_STATE_LEASED: ControlRequestState.LEASED,
    controlplane_pb2.CONTROL_REQUEST_STATE_AWAITING_VERDICT: (ControlRequestState.AWAITING_VERDICT),
    controlplane_pb2.CONTROL_REQUEST_STATE_COMPLETED: ControlRequestState.COMPLETED,
    controlplane_pb2.CONTROL_REQUEST_STATE_EXPIRED: ControlRequestState.EXPIRED,
    controlplane_pb2.CONTROL_REQUEST_STATE_CANCELLED: ControlRequestState.CANCELLED,
}
_PROTOCOL_FROM_PROTO: Mapping[int, Literal["http", "websocket"]] = {
    controlplane_pb2.ENDPOINT_PROTOCOL_HTTP: "http",
    controlplane_pb2.ENDPOINT_PROTOCOL_WEBSOCKET: "websocket",
}


def _parse[MessageT: Message](
    value: Mapping[str, object], message: MessageT, *, label: str
) -> MessageT:
    """Parse protobuf JSON strictly at the human-authored CLI/MCP edge."""

    try:
        ParseDict(dict(value), message, ignore_unknown_fields=False)
    except (ParseError, TypeError, ValueError) as error:
        raise OperationProtocolError(f"{label} is malformed: {error}") from error
    return _validated(message, label=label)


def _closed[NumberT, ValueT](
    table: Mapping[NumberT, ValueT], number: NumberT, *, label: str
) -> ValueT:
    try:
        return table[number]
    except KeyError as error:
        raise OperationProtocolError(f"Fleet returned an unknown {label}") from error


def _operation_ref(ref: OperationRef[object, object]) -> common_pb2.OperationRef:
    kind = _KIND_TO_PROTO.get(ref.kind)
    if ref.pillar is not PlatformPillar.FLEET or kind is None:
        raise OperationProtocolError(f"Fleet cannot own {ref}")
    return common_pb2.OperationRef(
        pillar=common_pb2.PLATFORM_PILLAR_FLEET,
        kind=kind,
        operation_id=str(ref.operation_id),
    )


def _datetime(value: Timestamp) -> datetime:
    return value.ToDatetime(tzinfo=UTC)


def _progress(value: controlplane_pb2.FleetOperation) -> Mapping[str, object] | None:
    arm = value.WhichOneof("progress")
    if arm is None:
        return None
    if arm != "research_progress":
        raise OperationProtocolError(f"unknown Fleet progress arm {arm!r}")
    progress = value.research_progress
    state = _closed(_RUN_STATE_FROM_PROTO, progress.run_state, label="research run state")
    return {
        "run_state": state.value,
        "episodes": progress.episodes,
        "max_episodes": progress.max_episodes,
    }


def _receipt(value: controlplane_pb2.FleetOperation) -> OperationReceipt:
    _validated(value, label="Fleet operation")
    metadata = value.metadata
    ref = metadata.ref
    if ref.pillar != common_pb2.PLATFORM_PILLAR_FLEET:
        raise OperationProtocolError("Fleet returned a non-Fleet operation")
    kind = _closed(_KIND_FROM_PROTO, ref.kind, label="operation kind")
    operation_id = OperationId(ref.operation_id)
    resource = _resource(metadata.resource)
    trace_id = TraceId(metadata.trace_id)
    cursor = UpdateCursor(metadata.cursor)
    key = IdempotencyKey(metadata.idempotency_key) if metadata.HasField("idempotency_key") else None
    progress = _progress(value)
    created_at = _datetime(metadata.created_at)
    updated_at = _datetime(metadata.updated_at)
    common = (operation_id, PlatformPillar.FLEET, kind, resource, trace_id)
    arm = value.lifecycle.WhichOneof("state")
    if arm == "accepted":
        return AcceptedOperation(
            *common,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            cancellation=_cancellation(value.lifecycle.accepted),
            created_at=created_at,
            updated_at=updated_at,
        )
    if arm == "running":
        return RunningOperation(
            *common,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            cancellation=_cancellation(value.lifecycle.running),
            created_at=created_at,
            updated_at=updated_at,
        )
    if arm == "succeeded":
        return SucceededOperation(
            *common,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            created_at=created_at,
            updated_at=updated_at,
            completed_at=_datetime(value.lifecycle.succeeded.completed_at),
        )
    if arm == "failed":
        failed = value.lifecycle.failed
        return FailedOperation(
            *common,
            failure=OperationFailure(
                failed.failure.code, failed.failure.message, failed.failure.retryable
            ),
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            created_at=created_at,
            updated_at=updated_at,
            failed_at=_datetime(failed.failed_at),
        )
    if arm == "cancelled":
        cancelled = value.lifecycle.cancelled
        return CancelledOperation(
            *common,
            reason=cancelled.reason,
            cursor=cursor,
            idempotency_key=key,
            progress=progress,
            created_at=created_at,
            updated_at=updated_at,
            cancelled_at=_datetime(cancelled.cancelled_at),
        )
    raise OperationProtocolError(f"unknown Fleet lifecycle arm {arm!r}")


def _receipt_for(
    expected: OperationRef[object, object], value: controlplane_pb2.FleetOperation
) -> OperationReceipt:
    """Decode a receipt and prove the owner answered for the requested operation."""

    receipt = _receipt(value)
    if receipt.ref != expected:
        raise OperationProtocolError(f"Fleet returned {receipt.ref} while {expected} was requested")
    return receipt


def _content_ref(value: controlplane_pb2.ContentRef) -> ContentRef:
    return ContentRef(ArtifactId(value.artifact_id), Sha256Digest(value.sha256))


def _deployment(value: controlplane_pb2.ApplicationDeployment) -> ApplicationDeployment:
    return ApplicationDeployment(
        ApplicationDeploymentRef(value.deployment_ref),
        DeploymentGroupRef(value.deployment_group_ref),
        RobotApplicationRef(value.application_ref),
        tuple(CapabilityApprovalRef(ref) for ref in value.approval_refs),
        SupervisionPolicyRef(value.supervision_policy_ref),
        RolloutRef(value.rollout_ref),
        _closed(_DEPLOYMENT_STATE_FROM_PROTO, value.state, label="deployment state"),
        tuple(
            RolloutWave(wave.index, tuple(StationId(station) for station in wave.stations))
            for wave in value.waves
        ),
    )


def _span(value: controlplane_pb2.ObservationActionSpan) -> ObservationActionSpan:
    return ObservationActionSpan(
        first_observation=value.first_observation,
        last_observation=value.last_observation,
        action_receipts=tuple(value.action_receipts),
    )


def _control_request(value: controlplane_pb2.ControlRequest) -> ControlRequest:
    return ControlRequest(
        request_id=value.request_id,
        purpose=_closed(_PURPOSE_FROM_PROTO, value.purpose, label="control purpose"),
        cause=_closed(_CAUSE_FROM_PROTO, value.cause, label="control cause"),
        run_id=value.run_id,
        episode_id=value.episode_id,
        station_id=value.station_id,
        route=tuple(
            _closed(_MODALITY_FROM_PROTO, modality, label="control modality")
            for modality in value.route
        ),
        route_index=value.route_index,
        selected_modality=(
            _closed(_MODALITY_FROM_PROTO, value.selected_modality, label="control modality")
            if value.HasField("selected_modality")
            else None
        ),
        deadline=_datetime(value.deadline),
        lease_id=UUID(value.lease_id) if value.HasField("lease_id") else None,
        evidence_span=_span(value.evidence_span) if value.HasField("evidence_span") else None,
        state=_closed(_REQUEST_STATE_FROM_PROTO, value.state, label="control request state"),
    )


def _catalog_commit(value: controlplane_pb2.CatalogCommit) -> CatalogCommit:
    return CatalogCommit(
        content=_content_ref(value.content),
        registration_id=UUID(value.registration_id),
        state=_closed(_REGISTRATION_FROM_PROTO, value.state, label="Catalog registration state"),
        receipt=value.receipt,
    )


def _episode(value: controlplane_pb2.EpisodeCommit) -> EpisodeCommit:
    return EpisodeCommit(
        episode=value.episode,
        index=value.index,
        outcome=_closed(_VERDICT_FROM_PROTO, value.outcome, label="task verdict"),
        raw_capture=_catalog_commit(value.raw_capture),
        canonical_episode=_catalog_commit(value.canonical_episode),
    )


def _application_proof(value: controlplane_pb2.ApplicationProof) -> ApplicationProof:
    lease = value.task_lease
    return ApplicationProof(
        deployment=ApplicationDeploymentRef(value.deployment_ref),
        application=value.application_ref,
        approval=value.approval_ref,
        task_lease=TaskLease(
            TaskLeaseRef(lease.lease_ref),
            ApplicationDeploymentRef(lease.deployment_ref),
            CapabilityApprovalRef(lease.approval_ref),
            lease.sequence,
            _datetime(lease.issued_at),
            _datetime(lease.expires_at),
        ),
        supervision_policy=SupervisionPolicyRef(value.supervision_policy_ref),
        calibrations=tuple(_content_ref(ref) for ref in value.calibrations),
    )


def _research_run(value: controlplane_pb2.ResearchRun, *, project_id: UUID) -> ResearchRun:
    """Rebuild the owner's record around the project the caller authenticated as.

    The wire deliberately omits the project: it is derived from credentials on
    every call, so echoing it back would be a second, caller-visible tenant fact
    that could disagree with the one that authorized the read.
    """

    return ResearchRun(
        run_id=ResearchRunId(value.run_id),
        project_id=project_id,
        operation_id=value.operation_id,
        idempotency_key=value.idempotency_key,
        trace_id=value.trace_id,
        deployment_group=DeploymentGroupRef(value.deployment_group_ref),
        station_id=StationId(value.station_id),
        pod_id=ResearchPodId(value.pod_id),
        pod_revision=value.pod_revision,
        dataset=CatalogDatasetName(value.dataset),
        application=_application_proof(value.application),
        services=tuple(
            ResolvedService(
                workload=service.workload,
                endpoint=service.endpoint,
                protocol=_closed(_PROTOCOL_FROM_PROTO, service.protocol, label="service protocol"),
            )
            for service in value.services
        ),
        budget=RunBudget(
            max_episodes=value.budget.max_episodes,
            max_duration_s=value.budget.max_duration.ToTimedelta().total_seconds(),
        ),
        state=_closed(_RUN_STATE_FROM_PROTO, value.state, label="research run state"),
        last_sequence=value.last_sequence,
        episodes=tuple(_episode(episode) for episode in value.episodes),
        active_control_request=(
            _control_request(value.active_control_request)
            if value.HasField("active_control_request")
            else None
        ),
        created_at=_datetime(value.created_at),
        updated_at=_datetime(value.updated_at),
        reason=value.reason if value.HasField("reason") else None,
    )


class FleetOwnerClient:
    """Generated Connect client for the one Fleet-owned operation family."""

    def __init__(self, binding: RpcBinding) -> None:
        self._headers = binding.headers
        project = binding.headers.get("X-SX-Project-Id")
        if project is None:
            raise OperationProtocolError("the Fleet client needs an authenticated project")
        self._project = UUID(project)
        self._client = controlplane_connect.FleetControlPlaneServiceClient(binding.address)

    async def close(self) -> None:
        await self._client.close()

    def _admitting(self, idempotency_key: str) -> dict[str, str]:
        return {**dict(self._headers), "Idempotency-Key": idempotency_key}

    async def deploy(
        self,
        *,
        application_ref: str,
        qualification_ref: str,
        approval_refs: tuple[str, ...],
        deployment_group_ref: str,
        timeout: timedelta,
        idempotency_key: str,
    ) -> OperationReceipt:
        request = _validated(
            controlplane_pb2.DeployRequest(
                deployment_group_ref=deployment_group_ref,
                application_ref=application_ref,
                qualification_ref=qualification_ref,
                approval_refs=list(approval_refs),
                timeout=timeout,
            ),
            label="deployment admission",
        )
        try:
            response = await self._client.deploy(
                request,
                headers=self._admitting(idempotency_key),
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _receipt(_validated(response, label="deployment admission response").operation)

    async def rollback(
        self, *, deployment_ref: str, timeout: timedelta, idempotency_key: str
    ) -> OperationReceipt:
        request = _validated(
            controlplane_pb2.RollbackRequest(deployment_ref=deployment_ref, timeout=timeout),
            label="rollback admission",
        )
        try:
            response = await self._client.rollback(
                request,
                headers=self._admitting(idempotency_key),
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _receipt(_validated(response, label="rollback admission response").operation)

    async def submit_research_run(
        self,
        *,
        deployment_ref: str,
        approval_ref: str,
        max_episodes: int,
        max_duration: timedelta,
        idempotency_key: str,
    ) -> OperationReceipt:
        request = _validated(
            controlplane_pb2.SubmitResearchRunRequest(
                deployment_ref=deployment_ref,
                approval_ref=approval_ref,
                budget=controlplane_pb2.RunBudget(
                    max_episodes=max_episodes, max_duration=max_duration
                ),
            ),
            label="research admission",
        )
        try:
            response = await self._client.submit_research_run(
                request,
                headers=self._admitting(idempotency_key),
                timeout_ms=_RPC_TIMEOUT_MS,
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _receipt(_validated(response, label="research admission response").operation)

    async def research_pod_readiness(
        self, commit: Mapping[str, object]
    ) -> controlplane_pb2.CommissioningReadiness:
        request = _parse(
            {"commit": dict(commit)},
            controlplane_pb2.CheckResearchPodReadinessRequest(),
            label="research pod revision",
        )
        try:
            response = await self._client.check_research_pod_readiness(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _validated(response, label="research pod readiness response").readiness

    async def commit_research_pod(
        self, commit: Mapping[str, object]
    ) -> controlplane_pb2.ResearchPod:
        request = _parse(
            {"commit": dict(commit)},
            controlplane_pb2.CommitResearchPodRequest(),
            label="research pod revision",
        )
        try:
            response = await self._client.commit_research_pod(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _validated(response, label="research pod commit response").pod

    async def commit_station_controller(
        self, commit: Mapping[str, object]
    ) -> controlplane_pb2.Controller:
        request = _parse(
            commit,
            controlplane_pb2.CommitStationControllerRequest(),
            label="station controller",
        )
        try:
            response = await self._client.commit_station_controller(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _validated(response, label="station controller response").controller

    def progress(self, receipt: OperationReceipt) -> Mapping[str, object] | None:
        """Fleet's live detail, as the owner's own mapping.

        The control plane publishes research and rollout detail no shared value names
        yet, so the honest projection is the mapping itself rather than a type invented
        here to look symmetrical with the families that do have one.
        """

        if receipt.progress is None:
            return None
        return read_only_progress(receipt.progress)

    async def status(self, ref: OperationRef[object, object]) -> OperationReceipt:
        request = _validated(
            controlplane_pb2.GetFleetOperationRequest(operation=_operation_ref(ref)),
            label="Fleet status request",
        )
        try:
            response = await self._client.get_fleet_operation(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _receipt_for(ref, _validated(response, label="Fleet status response").operation)

    async def updates(
        self,
        ref: OperationRef[object, object],
        *,
        after: UpdateCursor | None,
        page_size: int,
        wait_s: float,
    ) -> tuple[OperationReceipt, ...]:
        request = controlplane_pb2.GetFleetOperationUpdatesRequest(
            operation=_operation_ref(ref),
            limit=page_size,
            wait_timeout=timedelta(seconds=wait_s),
        )
        if after is not None:
            request.after_cursor = int(after)
        _validated(request, label="Fleet updates request")
        try:
            response = await self._client.get_fleet_operation_updates(
                request, headers=self._headers, timeout_ms=int((wait_s + 5.0) * 1000)
            )
        except ConnectError as error:
            _raise_rpc(error)
        _validated(response, label="Fleet updates response")
        arm = response.WhichOneof("outcome")
        if arm == "page":
            return tuple(_receipt_for(ref, item) for item in response.page.updates)
        if arm == "history_gap":
            latest = await self.status(ref)
            raise OperationHistoryGapError(_history_gap_cursor(response.history_gap), latest)
        raise OperationProtocolError(f"unknown Fleet updates outcome {arm!r}")

    async def cancel(self, ref: OperationRef[object, object], *, reason: str) -> OperationReceipt:
        request = _validated(
            controlplane_pb2.CancelFleetOperationRequest(
                operation=_operation_ref(ref), reason=reason
            ),
            label="Fleet cancellation request",
        )
        try:
            response = await self._client.cancel_fleet_operation(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            _raise_rpc(error)
        return _receipt_for(
            ref, _validated(response, label="Fleet cancellation response").operation
        )

    async def result(
        self, ref: OperationRef[object, object]
    ) -> ApplicationDeployment | ResearchRun:
        request = _validated(
            controlplane_pb2.GetFleetOperationResultRequest(operation=_operation_ref(ref)),
            label="Fleet result request",
        )
        try:
            response = await self._client.get_fleet_operation_result(
                request, headers=self._headers, timeout_ms=_RPC_TIMEOUT_MS
            )
        except ConnectError as error:
            _raise_rpc(error)
        _validated(response, label="Fleet result response")
        arm = response.result.WhichOneof("result")
        if arm == "deployment":
            if ref.kind is OperationKind.RESEARCH:
                raise OperationProtocolError("Fleet returned a deployment for a research run")
            return _deployment(response.result.deployment)
        if arm == "research_run":
            if ref.kind is not OperationKind.RESEARCH:
                raise OperationProtocolError("Fleet returned a research run for a deployment")
            return _research_run(response.result.research_run, project_id=self._project)
        raise OperationProtocolError(f"unknown Fleet result arm {arm!r}")
