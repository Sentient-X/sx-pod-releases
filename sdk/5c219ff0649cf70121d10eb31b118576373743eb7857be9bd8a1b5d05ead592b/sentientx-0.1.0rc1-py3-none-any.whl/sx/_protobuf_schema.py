"""JSON projections of protobuf descriptors; validation remains protovalidate-owned."""

from typing import Any, cast

from buf.validate import validate_pb2
from google.protobuf.descriptor import Descriptor, FieldDescriptor
from pydantic import JsonValue


def message_schema(descriptor: Descriptor, *, inline: bool = False) -> dict[str, Any]:
    """Project the closed ProtoJSON vocabulary, presence and oneofs recursively.

    CEL and cross-field rules remain executable at the protobuf boundary; this schema
    describes their field vocabulary, not a second implementation of those rules.
    """
    definitions: dict[str, Any] = {}

    def reference(message: Descriptor) -> dict[str, Any]:
        if message.full_name in ("google.protobuf.Timestamp", "google.protobuf.Duration"):
            return {"type": "string"}
        if message.full_name == "google.protobuf.Struct":
            return {"type": "object"}
        if message.full_name == "google.protobuf.Value":
            return {}
        if message.full_name == "google.protobuf.ListValue":
            return {"type": "array"}
        if inline:
            return shape(message)
        name = message.full_name
        if name not in definitions:
            definitions[name] = {}
            definitions[name] = shape(message)
        return {"$ref": f"#/$defs/{name}"}

    def field_shape(field: FieldDescriptor) -> dict[str, Any]:
        rules = field.GetOptions().Extensions[cast(Any, validate_pb2.field)]
        item_rules = rules.repeated.items if field.is_repeated else rules
        value: dict[str, Any]
        if field.message_type is not None:
            if field.message_type.GetOptions().map_entry:
                return {
                    "type": "object",
                    "additionalProperties": field_shape(field.message_type.fields_by_name["value"]),
                }
            value = reference(field.message_type)
        elif field.enum_type is not None:
            value = {"type": "string", "enum": [item.name for item in field.enum_type.values]}
        elif field.type in (FieldDescriptor.TYPE_STRING, FieldDescriptor.TYPE_BYTES):
            value = {"type": "string"}
            if field.type == FieldDescriptor.TYPE_BYTES:
                value["contentEncoding"] = "base64"
        elif field.type == FieldDescriptor.TYPE_BOOL:
            value = {"type": "boolean"}
        elif field.type in (FieldDescriptor.TYPE_DOUBLE, FieldDescriptor.TYPE_FLOAT):
            numeric_rules = (
                item_rules.double if field.type == FieldDescriptor.TYPE_DOUBLE else item_rules.float
            )
            value = (
                {"type": "number"}
                if numeric_rules.finite
                else {"anyOf": [{"type": "number"}, {"enum": ["NaN", "Infinity", "-Infinity"]}]}
            )
        elif field.type in (
            FieldDescriptor.TYPE_INT64,
            FieldDescriptor.TYPE_UINT64,
            FieldDescriptor.TYPE_SINT64,
            FieldDescriptor.TYPE_FIXED64,
            FieldDescriptor.TYPE_SFIXED64,
        ):
            # ProtoJSON emits decimal strings for 64-bit values and accepts numbers too.
            value = {"anyOf": [{"type": "integer"}, {"type": "string", "pattern": r"^-?[0-9]+$"}]}
        else:
            value = {"type": "integer"}
        if item_rules.HasField("string"):
            strings = item_rules.string
            for source, target in (
                ("min_len", "minLength"),
                ("max_len", "maxLength"),
                ("pattern", "pattern"),
            ):
                if strings.HasField(source):
                    value[target] = getattr(strings, source)
        if field.enum_type is not None and item_rules.HasField("enum"):
            excluded = set(item_rules.enum.not_in)
            allowed = set(getattr(item_rules.enum, "in"))
            value["enum"] = [
                item.name
                for item in field.enum_type.values
                if item.number not in excluded and (not allowed or item.number in allowed)
            ]
        if field.is_repeated:
            value = {"type": "array", "items": value}
            for source, target in (("min_items", "minItems"), ("max_items", "maxItems")):
                if rules.repeated.HasField(source):
                    value[target] = getattr(rules.repeated, source)
            if rules.repeated.unique:
                value["uniqueItems"] = True
        return value

    def shape(message: Descriptor) -> dict[str, Any]:
        properties = {field.name: field_shape(field) for field in message.fields}
        required = [
            field.name
            for field in message.fields
            if field.GetOptions().Extensions[cast(Any, validate_pb2.field)].required
        ]
        result: dict[str, Any] = {
            "type": "object",
            "properties": properties,
            "additionalProperties": False,
        }
        if required:
            result["required"] = required
        groups: list[dict[str, Any]] = []
        for oneof in message.oneofs:
            # Proto3 optional scalars have synthetic oneofs. Their single member
            # has ordinary optional presence, not a required variant selection.
            if len(oneof.fields) == 1 and oneof.name == f"_{oneof.fields[0].name}":
                continue
            variants = [
                {
                    "required": [field.name],
                    "not": {
                        "anyOf": [
                            {"required": [other.name]} for other in oneof.fields if other != field
                        ]
                    },
                }
                if len(oneof.fields) > 1
                else {"required": [field.name]}
                for field in oneof.fields
            ]
            if not oneof.GetOptions().Extensions[cast(Any, validate_pb2.oneof)].required:
                variants.append(
                    {"not": {"anyOf": [{"required": [field.name]} for field in oneof.fields]}}
                )
            groups.append({"oneOf": variants})
        if groups:
            result["allOf"] = groups
        return result

    result = shape(descriptor)
    if definitions:
        result["$defs"] = definitions
    return result


def json_document(value: object) -> dict[str, JsonValue]:
    """Narrow framework JSON after protobuf parsing has established its shape."""
    return cast(dict[str, JsonValue], value)
