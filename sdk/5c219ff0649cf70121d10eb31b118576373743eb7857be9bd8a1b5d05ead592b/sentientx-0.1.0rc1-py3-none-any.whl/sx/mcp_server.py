"""Project-bound MCP projection of the public ``sx`` lifecycle."""

import base64
import os
from collections.abc import Awaitable, Callable, Mapping
from contextvars import ContextVar
from dataclasses import dataclass, replace
from datetime import datetime, timedelta
from enum import StrEnum
from functools import wraps
from hashlib import sha256
from pathlib import Path
from typing import Annotated, Literal, ParamSpec, TypeVar, cast

from google.protobuf.descriptor import Descriptor
from google.protobuf.json_format import ParseDict
from mcp.server.fastmcp import Context, FastMCP
from mcp.server.session import ServerSession
from posthog import Posthog
from posthog.mcp import instrument
from pydantic import (
    AwareDatetime,
    BaseModel,
    ConfigDict,
    Field,
    JsonValue,
    RootModel,
    WithJsonSchema,
)
from sentientx.sx.autonomy.ask.v1 import ideas_pb2
from sentientx.sx.autonomy.train.v1 import training_pb2
from sentientx.sx.experience.catalog.v1 import catalog_pb2
from sx_autonomy import (
    ApplicationQualificationRef,
    CapabilityApprovalRef,
)
from sx_contracts import (
    ROBOT_APPLICATION_REF_PATTERN,
    AcceptedOperation,
    ApplicationWorkload,
    ArtifactMount,
    ArtifactSlot,
    CatalogSegmentRef,
    DatasetKind,
    DeploymentGroupRef,
    OperationReceipt,
    RobotApplicationRef,
    RunningOperation,
    TaskContractRef,
    TaskId,
    TaskSchemaVersion,
    UpdateCursor,
    WorkloadName,
    catalog_segment_from_dict,
    contract_ref,
    from_canonical_json,
    robot_application_from_dict,
)
from sx_contracts.content import ArtifactId, ContentRef, Sha256Digest
from sx_contracts.conversations import (
    EffectId,
    TurnFence,
    TurnId,
    decision_effect_idempotency_key,
)
from sx_contracts.decisions import (
    GOAL_VERIFICATION_SCHEMA,
    DecisionIdentity,
    GoalVerificationReceipt,
    parse_decision_identity,
)

# The identity serializer, not the task one: `sx_contracts.canonical_json` is the
# TaskContract projection, and what arrives here is still a document.
from sx_contracts.identity import CanonicalDocument, FrozenJsonValue
from sx_contracts.identity import canonical_json as canonical_document
from sx_contracts.outcomes import TaskVerdict
from sx_contracts.pipelines import pipeline_from_json
from sx_corpora import DatasetName, SelectionMember
from sx_embodiments import embodiments
from sx_fleet.research import RunBudget
from sx_worlds import (
    EnvironmentBundle,
    MimicGenSource,
    ObjectAssetBundle,
    PolicyArtifactKind,
    PolicyArtifactRef,
    Scene,
    SeedSelection,
    SessionJsonResult,
    SessionStepReceipt,
    SimulationJobFamily,
    SimulationResourceBand,
    Simulator,
    SimulatorCapability,
    WorldSession,
    WorldSessionFailure,
    WorldSessionState,
)

from sx._descriptor_surface import PUBLIC_RPC_OPERATIONS, RpcOperation
from sx._encode import json_value, proto_document
from sx._mcp_projection import protobuf_tool, register_projections
from sx._projected_rpc import parse_request, rpc_method
from sx._protobuf_schema import json_document, message_schema
from sx._transport import ConnectionProfile
from sx.client import Operation, Sx

mcp = FastMCP(
    "sx",
    instructions=(
        "Operate one startup-bound sentientx project. Mutations return durable receipts; "
        "use the bounded operation tools to follow them."
    ),
)


@dataclass(frozen=True, slots=True)
class _Settings:
    project: str
    profile: ConnectionProfile
    decision_turn: bool = False


class _ClosedMcpModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, from_attributes=True)


class ApplicationRevisionResult(_ClosedMcpModel):
    """Closed MCP result for one generated application-owner revision."""

    application_ref: Annotated[
        RobotApplicationRef,
        Field(pattern=ROBOT_APPLICATION_REF_PATTERN),
    ]


class TaskContractRefResult(_ClosedMcpModel):
    task_id: str
    schema_version: str
    sha256: Sha256Digest


class WorldSessionCloseResult(_ClosedMcpModel):
    success: bool
    steps: int
    episode_segment: str | None
    reason: str | None


class WorldSessionResult(_ClosedMcpModel):
    session_id: str
    task: TaskContractRefResult
    simulator: Simulator
    engine_config_id: str
    allocation_ref: str
    operation_ref: str
    state: WorldSessionState
    expires_at: datetime
    observation_sequence: int
    tools: tuple[str, ...]
    evidence_refs: tuple[str, ...]
    usage_ref: str | None
    close: WorldSessionCloseResult | None
    failure: WorldSessionFailure | None


class WorldsEnvironmentsResult(_ClosedMcpModel):
    environments: tuple[EnvironmentBundle, ...]


class WorldsScenesResult(_ClosedMcpModel):
    scenes: tuple[Scene, ...]


class WorldsPanoUploadResult(_ClosedMcpModel):
    pano_id: str


class WorldsObjectImageUploadResult(_ClosedMcpModel):
    image_id: str


class WorldsObjectAssetsResult(_ClosedMcpModel):
    object_assets: tuple[ObjectAssetBundle, ...]


class WorldsSessionsResult(RootModel[tuple[WorldSessionResult, ...]]):
    pass


class WorldsRunsResult(RootModel[tuple[OperationReceipt, ...]]):
    pass


class SimulatorCapabilityResult(_ClosedMcpModel):
    simulator: Simulator
    job: SimulationJobFamily
    resource_band: SimulationResourceBand
    available: bool
    reason: str | None = None


class WorldsSimulatorsResult(RootModel[tuple[SimulatorCapabilityResult, ...]]):
    pass


class SessionJsonResultOutput(_ClosedMcpModel):
    kind: Literal["json"] = "json"
    value: JsonValue


class SessionImageResultOutput(_ClosedMcpModel):
    kind: Literal["image"] = "image"
    dtype: str
    shape: tuple[int, ...]
    data_b64: str


type SessionStepResultOutput = Annotated[
    SessionJsonResultOutput | SessionImageResultOutput,
    Field(discriminator="kind"),
]


class SessionStepReceiptResult(_ClosedMcpModel):
    step_id: str
    previous_observation_sequence: int
    observation_sequence: int
    replayed: bool
    result: SessionStepResultOutput


class EffectIdentityModel(_ClosedMcpModel):
    effect_id: str
    request_digest: Sha256Digest


class DecisionIdentityModel(_ClosedMcpModel):
    environment_generation: Annotated[int, Field(gt=0)]
    effect: EffectIdentityModel
    goal_id: str
    goal_revision: Annotated[int, Field(gt=0)]
    decision_id: str

    def domain(self) -> DecisionIdentity:
        """Parse the closed MCP document through the canonical decision boundary."""

        return parse_decision_identity(self.model_dump(mode="python"))


class VerifierIdentityResult(_ClosedMcpModel):
    name: str
    version: str


class GoalVerificationEvidenceResult(_ClosedMcpModel):
    session_id: str
    task: TaskContractRefResult
    state: WorldSessionState


class GoalVerificationResult(_ClosedMcpModel):
    schema_: str = Field(
        alias="schema",
        serialization_alias="schema",
        pattern=f"^{GOAL_VERIFICATION_SCHEMA}$",
    )
    decision: DecisionIdentityModel
    status: TaskVerdict
    summary: str
    observation_sequence: int
    verifier: VerifierIdentityResult
    evidence: GoalVerificationEvidenceResult


type SemanticText = Annotated[str, Field(min_length=1, max_length=1024)]
type SemanticDatasetName = Annotated[
    str,
    Field(
        min_length=1,
        max_length=200,
        pattern=r"^[a-z0-9][a-z0-9_-]*(?:[.][a-z0-9][a-z0-9_-]*)*$",
    ),
]


class SemanticFrameReferenceInput(_ClosedMcpModel):
    dataset: SemanticDatasetName
    segment_id: Annotated[str, Field(min_length=1, max_length=1000)]
    entity_path: Annotated[str, Field(min_length=1, max_length=4000)]
    time_ns: int

    def proto(self) -> catalog_pb2.SemanticFrameReference:
        return catalog_pb2.SemanticFrameReference(
            dataset=self.dataset,
            segment_id=self.segment_id,
            entity_path=self.entity_path,
            time_ns=self.time_ns,
        )


class SemanticFiltersInput(_ClosedMcpModel):
    datasets: Annotated[tuple[SemanticDatasetName, ...], Field(max_length=64)] = ()
    dataset_kinds: Annotated[tuple[DatasetKind, ...], Field(max_length=3)] = ()
    embodiment_id: Annotated[str, Field(min_length=1, max_length=256)] | None = None
    registered_after: AwareDatetime | None = None
    registered_before: AwareDatetime | None = None

    def proto(self) -> catalog_pb2.SemanticFilters:
        kinds = {
            DatasetKind.ONLINE: catalog_pb2.SEMANTIC_DATASET_KIND_ONLINE,
            DatasetKind.CORRECTION: catalog_pb2.SEMANTIC_DATASET_KIND_CORRECTION,
            DatasetKind.DEMO: catalog_pb2.SEMANTIC_DATASET_KIND_DEMO,
        }
        value = catalog_pb2.SemanticFilters(
            datasets=self.datasets,
            dataset_kinds=[kinds[kind] for kind in self.dataset_kinds],
        )
        if self.embodiment_id is not None:
            value.embodiment_id = self.embodiment_id
        if self.registered_after is not None:
            value.registered_after.FromDatetime(self.registered_after)
        if self.registered_before is not None:
            value.registered_before.FromDatetime(self.registered_before)
        return value


_EMPTY_SEMANTIC_FILTERS = SemanticFiltersInput()


_settings: _Settings | None = None


def bind_from_environment() -> None:
    """Bind non-secret context once; ``SX_API_KEY`` remains transport-owned environment."""

    global _settings
    project = os.environ.get("SX_PROJECT_ID")
    if project is None:
        raise RuntimeError("SX_PROJECT_ID is required when the MCP server starts")
    raw_profile = os.environ.get("SX_PROFILE", ConnectionProfile.HOSTED.value)
    try:
        profile = ConnectionProfile(raw_profile)
    except ValueError as error:
        raise RuntimeError("SX_PROFILE must be 'hosted' or 'development'") from error
    raw_decision_turn = os.environ.get("SX_DECISION_TURN")
    if raw_decision_turn not in (None, "1"):
        raise RuntimeError("SX_DECISION_TURN must be absent or '1'")
    _settings = _Settings(project, profile, decision_turn=raw_decision_turn == "1")


def _bound() -> _Settings:
    if _settings is None:
        bind_from_environment()
    assert _settings is not None
    return _settings


def _mapping(value: object) -> dict[str, object]:
    encoded = json_value(value)
    if not isinstance(encoded, dict):
        raise TypeError("MCP result did not encode as an object")
    mapping = cast("dict[object, object]", encoded)
    return {str(key): item for key, item in mapping.items()}


def _world_session_result(value: WorldSession) -> WorldSessionResult:
    return WorldSessionResult.model_validate(value)


def _simulator_result(value: SimulatorCapability) -> SimulatorCapabilityResult:
    return SimulatorCapabilityResult.model_validate(value)


def _mcp_json(value: FrozenJsonValue) -> JsonValue:
    if isinstance(value, Mapping):
        return {key: _mcp_json(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [_mcp_json(item) for item in value]
    return value


def _session_step_result(value: SessionStepReceipt) -> SessionStepReceiptResult:
    if isinstance(value.result, SessionJsonResult):
        result: SessionStepResultOutput = SessionJsonResultOutput(
            value=_mcp_json(value.result.value)
        )
    else:
        result = SessionImageResultOutput(
            dtype=value.result.dtype,
            shape=value.result.shape,
            data_b64=base64.b64encode(value.result.png).decode("ascii"),
        )
    return SessionStepReceiptResult(
        step_id=value.step_id,
        previous_observation_sequence=value.previous_observation_sequence,
        observation_sequence=value.observation_sequence,
        replayed=value.replayed,
        result=result,
    )


def _verification_result(value: GoalVerificationReceipt) -> GoalVerificationResult:
    return GoalVerificationResult.model_validate(value.to_wire())


class DecisionMutationMetadataError(ValueError):
    """A DecisionTurn mutation did not carry its exact durable effect identity."""


class _DecisionMutationLaw(StrEnum):
    EFFECT_KEY = "effect_key"
    CONTENT_KEY = "content_key"
    RECONCILE_CANCEL = "reconcile_cancel"


@dataclass(frozen=True, slots=True)
class _DecisionEffect:
    effect_id: EffectId
    request_sha256: Sha256Digest
    turn_id: TurnId
    fence: TurnFence


# This is the production owner's complete DecisionTurn mutation law. The execution
# profile registry is independently projected and a cross-package test requires exact
# equality, so adding a model-visible mutation without choosing its recovery law fails.
DECISION_MUTATION_LAWS: Mapping[str, _DecisionMutationLaw] = {
    "task.authoring.propose": _DecisionMutationLaw.CONTENT_KEY,
    "autonomy.application.revise": _DecisionMutationLaw.CONTENT_KEY,
    "fleet.deploy": _DecisionMutationLaw.EFFECT_KEY,
    "autonomy.improve": _DecisionMutationLaw.CONTENT_KEY,
    "autonomy.ideas.create": _DecisionMutationLaw.EFFECT_KEY,
    "autonomy.ideas.keep": _DecisionMutationLaw.CONTENT_KEY,
    "autonomy.train": _DecisionMutationLaw.EFFECT_KEY,
    "autonomy.train_custom": _DecisionMutationLaw.EFFECT_KEY,
    "embodiment.register": _DecisionMutationLaw.CONTENT_KEY,
    "experience.capture": _DecisionMutationLaw.EFFECT_KEY,
    "experience.publish_task": _DecisionMutationLaw.CONTENT_KEY,
    "experience.selection.snapshot": _DecisionMutationLaw.CONTENT_KEY,
    "fleet.research": _DecisionMutationLaw.EFFECT_KEY,
    "operation.cancel": _DecisionMutationLaw.RECONCILE_CANCEL,
    "part.admit": _DecisionMutationLaw.CONTENT_KEY,
    "worlds.author_articulated_object": _DecisionMutationLaw.EFFECT_KEY,
    "worlds.author_robot_part": _DecisionMutationLaw.EFFECT_KEY,
    "worlds.evaluate": _DecisionMutationLaw.EFFECT_KEY,
    "worlds.evaluate_subject": _DecisionMutationLaw.EFFECT_KEY,
    "worlds.generate": _DecisionMutationLaw.EFFECT_KEY,
    "worlds.publish_scan": _DecisionMutationLaw.EFFECT_KEY,
    "worlds.seed_scan": _DecisionMutationLaw.EFFECT_KEY,
}

_P = ParamSpec("_P")
_R = TypeVar("_R")
type McpContext = Context[ServerSession, object, object]
_active_decision_mutation: ContextVar[tuple[str, _DecisionEffect] | None] = ContextVar(
    "sx_active_decision_mutation", default=None
)
_DECISION_METADATA_FIELDS = frozenset(
    {"sx_effect_id", "sx_request_sha256", "sx_turn_id", "sx_fence"}
)


def _decision_mutation(
    name: str,
) -> Callable[
    [Callable[_P, Awaitable[_R]]],
    Callable[_P, Awaitable[_R]],
]:
    """Require durable effect metadata before a DecisionTurn reaches an owner."""

    if name not in DECISION_MUTATION_LAWS:
        raise RuntimeError(f"DecisionTurn mutation {name!r} has no recovery law")

    def decorate(
        function: Callable[_P, Awaitable[_R]],
    ) -> Callable[_P, Awaitable[_R]]:
        @wraps(function)
        async def guarded(*args: _P.args, **kwargs: _P.kwargs) -> _R:
            if not _bound().decision_turn:
                return await function(*args, **kwargs)
            context = cast("dict[str, object]", kwargs).get("ctx")
            if not isinstance(context, Context):
                raise DecisionMutationMetadataError(
                    f"DecisionTurn mutation {name!r} has no MCP request context"
                )
            effect = _parse_decision_effect(cast("McpContext", context))
            token = _active_decision_mutation.set((name, effect))
            try:
                return await function(*args, **kwargs)
            finally:
                _active_decision_mutation.reset(token)

        return guarded

    return decorate


def _parse_decision_effect(context: McpContext) -> _DecisionEffect:
    try:
        request_context = context.request_context
    except ValueError as error:
        raise DecisionMutationMetadataError("DecisionTurn mutation metadata is required") from error
    if request_context.meta is None:
        raise DecisionMutationMetadataError("DecisionTurn mutation metadata is required")
    document = request_context.meta.model_dump(mode="python", by_alias=True, exclude_none=True)
    sx_fields = {key: value for key, value in document.items() if key.startswith("sx_")}
    names = frozenset(sx_fields)
    if names != _DECISION_METADATA_FIELDS:
        missing = sorted(_DECISION_METADATA_FIELDS - names)
        unknown = sorted(names - _DECISION_METADATA_FIELDS)
        raise DecisionMutationMetadataError(
            f"DecisionTurn mutation metadata is not exact; missing={missing}, unknown={unknown}"
        )
    effect_id = sx_fields["sx_effect_id"]
    request_sha256 = sx_fields["sx_request_sha256"]
    turn_id = sx_fields["sx_turn_id"]
    fence = sx_fields["sx_fence"]
    if (
        not isinstance(effect_id, str)
        or not effect_id.startswith("effect-")
        or not isinstance(turn_id, str)
        or not turn_id.strip()
        or any(character.isspace() for character in turn_id)
        or isinstance(fence, bool)
        or not isinstance(fence, int)
        or fence < 1
    ):
        raise DecisionMutationMetadataError("DecisionTurn mutation identity is malformed")
    if not isinstance(request_sha256, str):
        raise DecisionMutationMetadataError("DecisionTurn request digest is malformed")
    try:
        digest = Sha256Digest(request_sha256)
        decision_effect_idempotency_key(EffectId(effect_id))
    except ValueError as error:
        raise DecisionMutationMetadataError(
            "DecisionTurn effect identity or request digest is malformed"
        ) from error
    return _DecisionEffect(EffectId(effect_id), digest, TurnId(turn_id), TurnFence(fence))


def _decision_effect_key(name: str) -> str | None:
    active = _active_decision_mutation.get()
    if active is None:
        return None
    active_name, effect = active
    if active_name != name:
        raise RuntimeError(
            f"DecisionTurn mutation context is {active_name!r}, not owner call {name!r}"
        )
    if DECISION_MUTATION_LAWS[name] is _DecisionMutationLaw.EFFECT_KEY:
        return decision_effect_idempotency_key(effect.effect_id)
    return None


def _task_ref(task_id: str, schema_version: str, sha256: str) -> TaskContractRef:
    return TaskContractRef(TaskId(task_id), TaskSchemaVersion(schema_version), Sha256Digest(sha256))


def _seed_ref(dataset: str, segment: str, sha256: str) -> CatalogSegmentRef:
    return catalog_segment_from_dict(
        {"dataset_id": dataset, "segment_id": segment, "base_sha256": sha256}
    )


def _admission[ResultT, ProgressT](
    operation: Operation[ResultT, ProgressT],
) -> dict[str, object]:
    return {"operation_ref": str(operation.ref), **_mapping(operation.admission_receipt())}


@mcp.tool(name="experience.task")
async def experience_task(task: str) -> dict[str, object]:
    """Resolve one governed task contract by its project-local name or id."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return _mapping(await client.experience.tasks.get(task))


@mcp.tool(name="experience.tasks")
async def experience_tasks() -> list[dict[str, object]]:
    """List the governed task contracts readable in the connected project."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return [_mapping(task) for task in await client.experience.tasks.list()]


@mcp.tool(name="task.authoring.opportunities")
async def task_authoring_opportunities(
    scenes: list[dict[str, object]],
    body_ref: str | None = None,
) -> list[dict[str, object]]:
    """Find deterministic Taskpedia opportunities from exact governed scene selections."""

    request: dict[str, object] = {"scenes": scenes}
    if body_ref is not None:
        request["body_ref"] = body_ref
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return [
            proto_document(item)
            for item in await client.experience.authoring.opportunities(request)
        ]


IdeaContentInput = Annotated[
    dict[str, JsonValue],
    WithJsonSchema(message_schema(cast(Descriptor, ideas_pb2.IdeaContent.DESCRIPTOR), inline=True)),
]


@mcp.tool(name="autonomy.ideas.list")
async def autonomy_ideas_list(
    limit: int = 50, before: str | None = None, kept_only: bool = False
) -> dict[str, object]:
    """Read saved project ideas, newest first; continue with next_before when present."""
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return proto_document(
            await client.autonomy.ideas.list(limit=limit, before=before, kept_only=kept_only)
        )


@mcp.tool(name="autonomy.ideas.get")
async def autonomy_ideas_get(id: str) -> dict[str, object]:
    """Read one exact proposal snapshot. Its citations do not prove compatibility."""
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return proto_document(await client.autonomy.ideas.get(id))


@mcp.tool(name="autonomy.ideas.create")
@_decision_mutation("autonomy.ideas.create")
async def autonomy_ideas_create(
    content: IdeaContentInput,
    ctx: Context[ServerSession, object, object],
    parent_id: str | None = None,
    idempotency_key: str | None = None,
) -> dict[str, object]:
    """Present an editable idea in the project workbench. Save a complete proposal with short,
    relevant sections. Stable section keys survive renaming/reordering. Optional scenario
    steps explain the proposed work; next_step offers one context-specific continuation.
    Varying an idea requires its exact parent_id. This never launches a job or alters the
    referenced task, robot, dataset, model, or scene. Keep speculative statements explicit.
    """
    del ctx
    parsed = ParseDict(content, ideas_pb2.IdeaContent())
    settings = _bound()
    key = _decision_effect_key("autonomy.ideas.create") or idempotency_key
    if key is None:
        raise ValueError(
            "Supply a stable idempotency_key when creating an idea outside a decision turn."
        )
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return proto_document(
            await client.autonomy.ideas.create(parsed, parent_id=parent_id, idempotency_key=key)
        )


@mcp.tool(name="autonomy.ideas.keep")
@_decision_mutation("autonomy.ideas.keep")
async def autonomy_ideas_keep(
    id: str, ctx: Context[ServerSession, object, object]
) -> dict[str, object]:
    """Keep an exact idea for later. This bookmarks a proposal; it approves no work."""
    del ctx
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return proto_document(await client.autonomy.ideas.keep(id))


@mcp.tool(name="task.authoring.draft")
async def task_authoring_draft(draft_id: str) -> dict[str, object]:
    """Read one shared task draft, including its exact server revision and context."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return proto_document(await client.experience.authoring.draft(draft_id))


@mcp.tool(name="task.authoring.check")
async def task_authoring_check(draft_id: str) -> dict[str, object]:
    """Ask each owner for revision-pinned validity, body-fit, and Worlds proof."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return proto_document(await client.experience.authoring.check(draft_id))


@mcp.tool(name="task.authoring.propose")
@_decision_mutation("task.authoring.propose")
async def task_authoring_propose(
    draft_id: str,
    base_revision: int,
    content: dict[str, object],
    rationale: str,
    conversation_id: str,
    turn_id: str,
    tool_receipts: list[str],
    evidence_refs: list[str],
    ctx: Context[ServerSession, object, object],
) -> dict[str, object]:
    """Create an immutable proposal for human review; exact retries return the same receipt."""

    del ctx

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return proto_document(
            await client.experience.authoring.propose(
                draft_id,
                {
                    "base_revision": base_revision,
                    "content": content,
                    "rationale": rationale,
                    "conversation_id": conversation_id,
                    "turn_id": turn_id,
                    "tool_receipts": tool_receipts,
                    "evidence_refs": evidence_refs,
                },
            )
        )


@mcp.tool(name="experience.dataset.snapshot")
async def experience_dataset_snapshot(
    dataset: str,
    for_task: str,
) -> dict[str, object]:
    """Snapshot conformant training episodes for one governed task."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        task = await client.experience.tasks.get(for_task)
        snapshot = await client.experience.dataset(dataset).where(task=task).snapshot()
        return _mapping(snapshot)


@mcp.tool(name="experience.estimate")
async def experience_estimate(
    pipeline: str,
    inputs: dict[str, str],
    destination: str,
    assumed_partition_seconds: int = 60,
) -> dict[str, object]:
    """Quote what a plan would consume before submitting it.

    Quantities under a meter version, never money; the assumptions come back as
    part of the answer. `pipeline` is the canonical pipeline JSON
    (sx_contracts.pipelines.pipeline_json), and `destination` is the dataset the
    plan publishes into — the one the quote is authorized and priced against.
    """

    plan = pipeline_from_json(pipeline)
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        estimate = await client.experience.estimate(
            pipeline=plan,
            inputs=inputs,
            destination=destination,
            assumed_partition_seconds=assumed_partition_seconds,
        )
        return _mapping(estimate)


@mcp.tool(name="embodiment.validate")
async def embodiment_validate(definition: dict[str, object], urdf_xml: str) -> dict[str, object]:
    """Dry-run an assembly definition against the minting door; refusals name the fix."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        validated = await client.experience.embodiments.validate(definition, urdf_xml=urdf_xml)
        return validated.to_dict()


@mcp.tool(name="embodiment.register")
@_decision_mutation("embodiment.register")
async def embodiment_register(
    definition: dict[str, object],
    urdf_xml: str,
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    """Mint and register one body assembled from qualified parts."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        registered = await client.experience.embodiments.register(definition, urdf_xml=urdf_xml)
        return registered.to_dict()


@mcp.tool(name="embodiment.get")
async def embodiment_get(name: str) -> dict[str, object]:
    """Resolve one governed embodiment document by its tenant-scoped name."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return (await client.experience.embodiments.get(name)).to_dict()


@mcp.tool(name="embodiment.description")
async def embodiment_description(name: str) -> str:
    """One governed body's URDF description text — the exact bytes it registered."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return await client.experience.embodiments.description(name)


@mcp.tool(name="experience.publish_task")
@_decision_mutation("experience.publish_task")
async def experience_publish_task(
    contract: dict[str, object],
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    """Publish one task contract — the spec a design is held to — from its document.

    The scenario IS the draft task contract: what the robot must do, where, under what
    limits, and the machine-checkable goal every design is scored against. This takes the
    contract document; the shared codec parses it (fail-closed on an unknown id, a bad
    enum, a malformed goal) and derives its identity, because a digest computed by hand
    is how a digest and its document drift apart.

    Publishing requires the `taskpedia.contracts` write grant. Without it the door
    refuses, and that refusal is the governance boundary working — contracts are
    Taskpedia's to admit, and this verb is the same admission path, not a second one.
    """

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        published = await client.experience.tasks.publish(
            from_canonical_json(canonical_document(cast("CanonicalDocument", contract)))
        )
        return {
            "task_id": str(published.task.id),
            "family": str(published.family),
            "name": published.task.name,
            "sha256": str(contract_ref(published).sha256),
        }


@mcp.tool(name="part.admit")
@_decision_mutation("part.admit")
async def part_admit(
    part: dict[str, object],
    urdf_xml: str,
    assets: list[dict[str, object]],
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    """Admit one customer part fragment into the tenant's composable catalog."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        admitted = await client.experience.embodiments.admit_part(
            part, urdf_xml=urdf_xml, assets=tuple(assets)
        )
        return proto_document(admitted)


@mcp.tool(name="experience.capture")
@_decision_mutation("experience.capture")
async def experience_capture(
    task: str,
    embodiment: str,
    episodes: int,
    timeout_s: int = 86_400,
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    """Capture a bounded number of governed episodes."""

    settings = _bound()
    try:
        robot = embodiments[embodiment]
    except KeyError as error:
        raise ValueError(f"unknown embodiment {embodiment!r}") from error
    async with Sx(project=settings.project, profile=settings.profile) as client:
        contract = await client.experience.tasks.get(task)
        effect_key = _decision_effect_key("experience.capture")
        if effect_key is None:
            operation = await client.experience.capture(
                contract,
                with_embodiment=robot,
                episodes=episodes,
                timeout=timedelta(seconds=timeout_s),
            )
        else:
            operation = await client.experience.capture(
                contract,
                with_embodiment=robot,
                episodes=episodes,
                timeout=timedelta(seconds=timeout_s),
                idempotency_key=effect_key,
            )
        return {"operation_ref": str(operation.ref), **_mapping(operation.admission_receipt())}


@protobuf_tool(mcp, PUBLIC_RPC_OPERATIONS["experience.search_frames"])
async def experience_search_frames(
    query: SemanticText | SemanticFrameReferenceInput,
    filters: SemanticFiltersInput = _EMPTY_SEMANTIC_FILTERS,
    limit: Annotated[int, Field(gt=0, le=128)] = 32,
) -> catalog_pb2.SearchFramesResponse:
    """Find governed frames by meaning.

    Pass text, or one exact indexed-frame reference. Hits carry governed thumbnail
    and viewer links; thumbnail JPEG bytes remain on Catalog's native HTTP route.
    """

    settings = _bound()
    frame_query = query.proto() if isinstance(query, SemanticFrameReferenceInput) else query
    async with Sx(project=settings.project, profile=settings.profile) as client:
        response = await client.experience.search_frames(
            frame_query,
            filters=filters.proto(),
            limit=limit,
        )
    return response


@protobuf_tool(mcp, PUBLIC_RPC_OPERATIONS["experience.search_clips"])
async def experience_search_clips(
    text: SemanticText,
    filters: SemanticFiltersInput = _EMPTY_SEMANTIC_FILTERS,
    limit: Annotated[int, Field(gt=0, le=128)] = 32,
) -> catalog_pb2.SearchClipsResponse:
    """Find governed action clips (time ranges within episodes) by meaning."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        response = await client.experience.search_clips(
            text,
            filters=filters.proto(),
            limit=limit,
        )
    return response


@protobuf_tool(mcp, PUBLIC_RPC_OPERATIONS["experience.search_text"])
async def experience_search_text(
    text: SemanticText,
    filters: SemanticFiltersInput = _EMPTY_SEMANTIC_FILTERS,
    limit: Annotated[int, Field(gt=0, le=100)] = 20,
) -> catalog_pb2.SearchTextResponse:
    """Word-level search over catalog-resident text (task contracts, agent layers)."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        response = await client.experience.search_text(
            text,
            filters=filters.proto(),
            limit=limit,
        )
    return response


@protobuf_tool(mcp, PUBLIC_RPC_OPERATIONS["experience.search_segments"])
async def experience_search_segments(
    text: SemanticText,
    filters: SemanticFiltersInput = _EMPTY_SEMANTIC_FILTERS,
    limit: Annotated[int, Field(gt=0, le=500)] = 50,
) -> catalog_pb2.SearchSegmentsResponse:
    """Select whole episodes by meaning. Hits carry exactly the identities a
    corpus member selection takes, so topic-driven training streams are this tool
    piped into corpus assembly."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        response = await client.experience.search_segments(
            text,
            filters=filters.proto(),
            limit=limit,
        )
    return response


@mcp.tool(name="experience.selection.snapshot")
@_decision_mutation("experience.selection.snapshot")
async def experience_selection_snapshot(
    members: list[dict[str, str]],
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    """Freeze an explicit governed selection as one immutable membership.

    ``members`` is a list of {"dataset": ..., "segment_id": ...} — exactly the
    identity atlas points and ``experience.search_segments`` hits carry. The
    minted snapshot's name goes straight into a corpus domain.
    """

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        chosen = [_selection_member(member) for member in members]
        return proto_document(await client.experience.snapshot_selection(chosen))


def _selection_member(member: Mapping[str, str]) -> SelectionMember:
    """Parse one member at the protocol edge, or refuse it there.

    The tool's argument is JSON, so the pair is admitted once, here, and travels
    inward as the domain value the owner will reconstruct from the wire.
    """

    unknown = set(member) - {"dataset", "segment_id"}
    if unknown:
        raise ValueError(f"a selection member has no field {sorted(unknown)[0]!r}")
    try:
        return SelectionMember(DatasetName(member["dataset"]), member["segment_id"])
    except KeyError as error:
        raise ValueError("a selection member names one dataset and one segment") from error


@mcp.tool(name="worlds.evaluate")
@_decision_mutation("worlds.evaluate")
async def worlds_evaluate(
    application: str,
    task: str,
    seed: int | None = None,
    timeout_s: int = 21_600,
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    """Evaluate an exact application through its robot-control boundary."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        governed_application = await client.autonomy.applications.get(application)
        governed_task = await client.experience.tasks.get(task)
        effect_key = _decision_effect_key("worlds.evaluate")
        if effect_key is None:
            operation = await client.evaluate(
                governed_application,
                task=governed_task,
                seed=seed,
                timeout=timedelta(seconds=timeout_s),
            )
        else:
            operation = await client.evaluate(
                governed_application,
                task=governed_task,
                seed=seed,
                timeout=timedelta(seconds=timeout_s),
                idempotency_key=effect_key,
            )
        return {"operation_ref": str(operation.ref), **_mapping(operation.admission_receipt())}


@mcp.tool(name="worlds.evaluate_subject")
@_decision_mutation("worlds.evaluate_subject")
async def worlds_evaluate_subject(
    subject_kind: str,
    task: str,
    task_schema_version: str,
    task_sha256: str,
    subject: str = "",
    subject_sha256: str = "",
    seed: int | None = None,
    timeout_s: int = 21_600,
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    """Evaluate an authored subject — or the zero-action floor — for an explicit task.

    `subject_kind="zero_action"` needs no artifact: the baseline's whole request is
    its kind. Every other kind pins exact content with `subject` + `subject_sha256`.
    """

    if subject_kind == "zero_action":
        if subject or subject_sha256:
            raise ValueError("the zero-action baseline pins no artifact")
        pinned = None
    else:
        if not subject or not subject_sha256:
            raise ValueError("an authored subject pins exact content: subject + subject_sha256")
        pinned = PolicyArtifactRef(
            kind=PolicyArtifactKind(subject_kind),
            artifact=ContentRef(ArtifactId(subject), Sha256Digest(subject_sha256)),
        )
    task_ref = _task_ref(task, task_schema_version, task_sha256)
    effect_key = _decision_effect_key("worlds.evaluate_subject")
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        operation = await (
            client.worlds.evaluate_baseline(
                for_task=task_ref,
                seed=seed,
                timeout=timedelta(seconds=timeout_s),
                idempotency_key=effect_key,
            )
            if pinned is None
            else client.worlds.evaluate_subject(
                pinned,
                for_task=task_ref,
                seed=seed,
                timeout=timedelta(seconds=timeout_s),
                idempotency_key=effect_key,
            )
        )
        return _admission(operation)


@mcp.tool(name="worlds.generate")
@_decision_mutation("worlds.generate")
async def worlds_generate(
    task: str,
    task_schema_version: str,
    task_sha256: str,
    seed_dataset: str,
    seed_segments: list[str],
    seed_segment_sha256s: list[str],
    into: str,
    count: int,
    simulator: Simulator,
    idempotency_key: str,
    position_jitter_m: float,
    rotation_jitter_rad: float,
    selection: str = "random",
    seed: int | None = None,
    timeout_s: int = 86_400,
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    """Generate governed episodes with a bounded MimicGen source over a pool of seed episodes."""

    effect_key = _decision_effect_key("worlds.generate")
    if effect_key is not None and idempotency_key != effect_key:
        raise DecisionMutationMetadataError(
            "DecisionTurn mutation 'worlds.generate' cannot supply another owner idempotency key"
        )
    if len(seed_segments) != len(seed_segment_sha256s):
        raise ValueError("every seed segment must be pinned to exactly one sha256")
    source = MimicGenSource(
        seed_segments=tuple(
            _seed_ref(seed_dataset, segment, digest)
            for segment, digest in zip(seed_segments, seed_segment_sha256s, strict=True)
        ),
        position_jitter_m=position_jitter_m,
        rotation_jitter_rad=rotation_jitter_rad,
        selection=SeedSelection(selection),
    )
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        operation = await client.worlds.generate(
            source,
            for_task=_task_ref(task, task_schema_version, task_sha256),
            count=count,
            into=DatasetName(into),
            simulator=simulator,
            idempotency_key=idempotency_key,
            seed=seed,
            timeout=timedelta(seconds=timeout_s),
        )
        return _admission(operation)


@mcp.tool(name="worlds.environments")
async def worlds_environments() -> WorldsEnvironmentsResult:
    """List governed captured and generated places in the connected project."""
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        environments = await client.worlds.environments()
    return WorldsEnvironmentsResult(environments=environments)


@mcp.tool(name="worlds.scenes")
async def worlds_scenes() -> WorldsScenesResult:
    """List complete, content-verified scenes in the connected project."""
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        scenes = await client.worlds.scenes()
    return WorldsScenesResult(scenes=scenes)


@mcp.tool(name="worlds.object_assets")
async def worlds_object_assets() -> WorldsObjectAssetsResult:
    """List governed reusable simulation objects in the connected project."""
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        objects = await client.worlds.object_assets()
    return WorldsObjectAssetsResult(object_assets=objects)


@mcp.tool(name="worlds.session")
async def worlds_session(
    task: str,
    task_schema_version: str,
    task_sha256: str,
    simulator: Simulator,
    ttl_s: int,
    idempotency_key: str,
    seed: int | None = None,
) -> WorldSessionResult:
    """Open or replay one bounded interactive Gym session."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        session = await client.worlds.session(
            for_task=_task_ref(task, task_schema_version, task_sha256),
            simulator=simulator,
            ttl_s=ttl_s,
            idempotency_key=idempotency_key,
            seed=seed,
        )
    return _world_session_result(session)


@mcp.tool(name="worlds.sessions")
async def worlds_sessions() -> WorldsSessionsResult:
    """List active and recent Gym sessions from authoritative Worlds state."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        sessions = await client.worlds.sessions()
    return WorldsSessionsResult(root=tuple(_world_session_result(session) for session in sessions))


@mcp.tool(name="worlds.runs")
async def worlds_runs() -> WorldsRunsResult:
    """List recent evaluation and generation operations from the Worlds ledger."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        runs = await client.worlds.simulation_runs()
    return WorldsRunsResult(root=runs)


@mcp.tool(name="worlds.simulators")
async def worlds_simulators() -> WorldsSimulatorsResult:
    """List qualified simulator/job/resource combinations without provider inventory."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        capabilities = await client.worlds.simulators()
    return WorldsSimulatorsResult(
        root=tuple(_simulator_result(capability) for capability in capabilities)
    )


@mcp.tool(name="worlds.session.get")
async def worlds_session_get(session_id: str) -> WorldSessionResult:
    """Reattach to one Gym session by its durable resource identity."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return _world_session_result(await client.worlds.session_status(session_id))


@mcp.tool(name="worlds.session.step")
async def worlds_session_step(
    session_id: str,
    step_id: str,
    expected_observation_sequence: int,
    tool: str,
    args: dict[str, JsonValue],
) -> SessionStepReceiptResult:
    """Apply one sequence-fenced Gym step exactly once, including after response loss."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        receipt = await client.worlds.step_session(
            session_id,
            step_id=step_id,
            expected_observation_sequence=expected_observation_sequence,
            tool=tool,
            args=args,
        )
    return _session_step_result(receipt)


@mcp.tool(name="worlds.session.verify")
async def worlds_session_verify(
    session_id: str,
    decision: DecisionIdentityModel,
) -> GoalVerificationResult:
    """Read the governed goal verdict without closing the Gym session."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        result = await client.worlds.verify_session(session_id, decision=decision.domain())
    return _verification_result(result)


@mcp.tool(name="worlds.session.close")
async def worlds_session_close(session_id: str) -> WorldSessionResult:
    """Close a Gym session and freeze its episode evidence receipt."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return _world_session_result(await client.worlds.close_session(session_id))


@mcp.tool(name="worlds.upload_pano")
async def worlds_upload_pano(pano_path: str) -> WorldsPanoUploadResult:
    """Upload and govern a local 2:1 panorama for a later worlds.author call."""
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        pano_id = await client.worlds.upload_pano(Path(pano_path))
    return WorldsPanoUploadResult(pano_id=pano_id)


@mcp.tool(name="worlds.upload_object_image")
async def worlds_upload_object_image(image_path: str) -> WorldsObjectImageUploadResult:
    """Upload and govern a source image for a later worlds.author_object call."""
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        image_id = await client.worlds.upload_object_image(Path(image_path))
    return WorldsObjectImageUploadResult(image_id=image_id)


@mcp.tool(name="worlds.author")
async def worlds_author(
    pano_id: str,
    name: str,
    description: str,
    prompt: str | None = None,
    model: str = "marble-1.1",
    seed: int | None = None,
    tags: list[str] | None = None,
    timeout_s: int = 3600,
) -> dict[str, object]:
    """Create a governed environment from a Worlds-governed panorama upload."""
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        operation = await client.worlds.author(
            from_pano=pano_id,
            name=name,
            description=description,
            prompt=prompt,
            model=model,
            seed=seed,
            tags=tuple(tags or ()),
            timeout=timedelta(seconds=timeout_s),
        )
        return _admission(operation)


@mcp.tool(name="worlds.author_object")
async def worlds_author_object(
    image_id: str,
    name: str,
    description: str,
    category: str,
    longest_dimension_m: float,
    mass_kg: float,
    quality: str = "default",
    seed: int | None = None,
    tags: list[str] | None = None,
    timeout_s: int = 3600,
) -> dict[str, object]:
    """Create a governed reusable simulation object from a governed image."""
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        operation = await client.worlds.author_object(
            from_image=image_id,
            name=name,
            description=description,
            category=category,
            longest_dimension_m=longest_dimension_m,
            mass_kg=mass_kg,
            quality=quality,
            seed=seed,
            tags=tuple(tags or ()),
            timeout=timedelta(seconds=timeout_s),
        )
        return _admission(operation)


@mcp.tool(name="worlds.author_articulated_object")
@_decision_mutation("worlds.author_articulated_object")
async def worlds_author_articulated_object(
    prompt: str,
    name: str,
    description: str,
    category: str,
    tags: list[str] | None = None,
    timeout_s: int = 3600,
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    """Design a governed articulated simulation object from a prompt.

    Mass, bounds, and articulation are derived from the compiled design at the
    settle gate rather than declared up front.
    """
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        operation = await client.worlds.author_articulated_object(
            prompt=prompt,
            name=name,
            description=description,
            category=category,
            tags=tuple(tags or ()),
            timeout=timedelta(seconds=timeout_s),
            idempotency_key=_decision_effect_key("worlds.author_articulated_object"),
        )
        return _admission(operation)


@mcp.tool(name="worlds.author_robot_part")
@_decision_mutation("worlds.author_robot_part")
async def worlds_author_robot_part(
    part_id: str,
    geometry_brief: str,
    timeout_s: int = 3600,
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    """Author exact robot-part bytes for later Experience review and admission.

    The brief is the complete immutable authoring intent. Worlds returns an
    ``OperationRef``; only a later, exact-hash ``part.admit`` call can add the
    reviewed candidate to the Experience part catalog.
    """
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        operation = await client.worlds.author_robot_part(
            part_id=part_id,
            geometry_brief=geometry_brief,
            timeout=timedelta(seconds=timeout_s),
            idempotency_key=_decision_effect_key("worlds.author_robot_part"),
        )
        return _admission(operation)


@mcp.tool(name="worlds.seed_scan")
@_decision_mutation("worlds.seed_scan")
async def worlds_seed_scan(
    scan_id: str,
    timeout_s: int = 7200,
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    """Reconstruct and seed an admitted scan capture; answers with a seed report.

    The deterministic half of the scan lane: read the returned splat quality and
    object count before paying for worlds.publish_scan's agent window.
    """
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        operation = await client.worlds.seed_scan(
            scan_id=scan_id,
            timeout=timedelta(seconds=timeout_s),
            idempotency_key=_decision_effect_key("worlds.seed_scan"),
        )
        return _admission(operation)


@mcp.tool(name="worlds.publish_scan")
@_decision_mutation("worlds.publish_scan")
async def worlds_publish_scan(
    scan_id: str,
    name: str,
    description: str,
    tags: list[str] | None = None,
    timeout_s: int = 7200,
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    """Author and publish an already-seeded scan as a governed environment.

    Resumes the durable run worlds.seed_scan built, so the seed half is never
    repaid.
    """
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        operation = await client.worlds.publish_scan(
            scan_id=scan_id,
            name=name,
            description=description,
            tags=tuple(tags or ()),
            timeout=timedelta(seconds=timeout_s),
            idempotency_key=_decision_effect_key("worlds.publish_scan"),
        )
        return _admission(operation)


@mcp.tool(name="autonomy.train")
@_decision_mutation("autonomy.train")
async def autonomy_train(
    data: dict[str, object],
    recipe: str,
    execution: dict[str, object],
    timeout_s: int = 86400,
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    """Admit one real training job over a content-pinned corpus."""
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        operation = await client.train(
            data=ParseDict(data, training_pb2.CorpusSnapshotRef()),
            recipe=training_pb2.RecipePreset.Value(
                "RECIPE_PRESET_" + recipe.upper().replace("-", "_")
            ),
            execution=ParseDict(execution, training_pb2.TrainingExecution()),
            timeout=timedelta(seconds=timeout_s),
            idempotency_key=_decision_effect_key("autonomy.train"),
        )
        return _admission(operation)


@mcp.tool(name="autonomy.train_custom")
@_decision_mutation("autonomy.train_custom")
async def autonomy_train_custom(
    data: dict[str, object],
    recipe: dict[str, object],
    execution: dict[str, object],
    timeout_s: int = 86400,
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    """Admit one explicit BC recipe through the real training owner."""
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        operation = await client.train_custom(
            data=ParseDict(data, training_pb2.CorpusSnapshotRef()),
            recipe=ParseDict(recipe, training_pb2.BCRecipe()),
            execution=ParseDict(execution, training_pb2.TrainingExecution()),
            timeout=timedelta(seconds=timeout_s),
            idempotency_key=_decision_effect_key("autonomy.train_custom"),
        )
        return _admission(operation)


@mcp.tool(name="fleet.deploy")
@_decision_mutation("fleet.deploy")
async def fleet_deploy(
    application: str,
    to: str,
    qualification: str,
    approvals: list[str],
    timeout_s: int = 900,
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    """Ask Fleet to deploy an exact application with existing evidence and approvals."""
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        operation = await client.fleet.deploy(
            RobotApplicationRef(application),
            to=DeploymentGroupRef(to),
            qualification=ApplicationQualificationRef(qualification),
            approvals=tuple(CapabilityApprovalRef(value) for value in approvals),
            timeout=timedelta(seconds=timeout_s),
            idempotency_key=_decision_effect_key("fleet.deploy"),
        )
        return _admission(operation)


@mcp.tool(name="autonomy.application")
async def autonomy_application(application: str) -> dict[str, object]:
    """Resolve one governed robot application by its project-local name or exact ref."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return _mapping(await client.autonomy.applications.get(application))


@mcp.tool(name="autonomy.application.revise")
@_decision_mutation("autonomy.application.revise")
async def autonomy_application_revise(
    base_application_ref: str,
    candidate: dict[str, object],
    source_archive: str | None = None,
    source_bindings: dict[str, str] | None = None,
    ctx: Context[ServerSession, object, object] | None = None,
) -> ApplicationRevisionResult:
    """Register an exact graph, optionally publishing small source bytes to its artifact slots.

    source_archive is base64 and source_bindings maps workload names to artifact
    slots whose image consumes that source. In a campaign plan, "$proposal-source" requests
    the settled proposal's exported Git archive; the harness resolves it before owner dispatch.
    Image environments continue to own Python dependencies, compilers and native kernels.
    """
    application = robot_application_from_dict(candidate)
    inputs: tuple[tuple[ContentRef, bytes], ...] = ()
    if (source_archive is None) != (source_bindings is None):
        raise ValueError("source archive and its workload bindings must be supplied together")
    if source_archive is not None and source_bindings is not None:
        if not source_bindings:
            raise ValueError("source bytes need at least one application consumer")
        if len(source_archive) > 4 * ((1024 * 1024 + 2) // 3):
            raise ValueError("authored application source exceeds one MiB")
        data = base64.b64decode(source_archive, validate=True)
        if not data:
            raise ValueError("source archive is empty")
        digest = Sha256Digest(sha256(data).hexdigest())
        content = ContentRef(ArtifactId(f"application-source:{digest}"), digest)
        by_name = {workload.name: workload for workload in application.workloads}
        replacements: dict[WorkloadName, ApplicationWorkload] = {}
        for name, slot in source_bindings.items():
            workload_name, artifact_slot = WorkloadName(name), ArtifactSlot(slot)
            if workload_name not in by_name:
                raise ValueError("source binding names an unknown workload")
            workload = by_name[workload_name]
            mounts = tuple(
                ArtifactMount(mount.slot, content) if mount.slot == artifact_slot else mount
                for mount in workload.artifacts
            )
            if not any(mount.slot == artifact_slot for mount in mounts):
                mounts = (*mounts, ArtifactMount(artifact_slot, content))
            replacements[workload_name] = replace(
                workload,
                artifacts=mounts,
            )
        application = application.specialize(target=application.target, workloads=replacements)
        inputs = ((content, data),)

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        application_ref = await client.autonomy.applications.revise_ref(
            RobotApplicationRef(base_application_ref),
            application,
            inputs=inputs,
        )
        return ApplicationRevisionResult(application_ref=application_ref)


@mcp.tool(name="autonomy.applications")
async def autonomy_applications() -> list[dict[str, object]]:
    """List the governed robot applications readable in the connected project."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return [_mapping(application) for application in await client.autonomy.applications.list()]


@mcp.tool(name="autonomy.improve")
@_decision_mutation("autonomy.improve")
async def autonomy_improve(
    task: str,
    task_schema_version: str,
    task_sha256: str,
    base_application_ref: str,
    max_rounds: int,
    timeout_s: int,
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    """Start a governed improvement campaign with explicit round and time bounds.

    The campaign's identity is its goal's content, so this mutation carries no owner
    idempotency key — its recovery law is CONTENT_KEY and a replayed goal is the
    same campaign.
    """

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return _admission(
            await client.autonomy.improve(
                _task_ref(task, task_schema_version, task_sha256),
                base_application_ref=RobotApplicationRef(base_application_ref),
                max_rounds=max_rounds,
                timeout=timedelta(seconds=timeout_s),
            )
        )


@mcp.tool(name="fleet.rollback")
async def fleet_rollback(
    deployment: str,
    timeout_s: int = 900,
) -> dict[str, object]:
    """Restore a deployment's previous healthy application and capability set."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        operation = await client.fleet.rollback(deployment, timeout=timedelta(seconds=timeout_s))
        return {"operation_ref": str(operation.ref), **_mapping(operation.admission_receipt())}


@mcp.tool(name="fleet.research")
@_decision_mutation("fleet.research")
async def fleet_research(
    deployment: str,
    approval: str,
    max_episodes: int,
    max_duration_s: float,
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    """Run physical research under explicit episode and duration bounds."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        effect_key = _decision_effect_key("fleet.research")
        operation = await client.fleet.research(
            deployment,
            approval=approval,
            budget=RunBudget(max_episodes=max_episodes, max_duration_s=max_duration_s),
            idempotency_key=effect_key,
        )
        return {"operation_ref": str(operation.ref), **_mapping(operation.admission_receipt())}


@mcp.tool(name="fleet.research_pod.readiness")
async def fleet_research_pod_readiness(
    revision: dict[str, object],
) -> dict[str, object]:
    """Validate a proposed pod revision against authenticated station inventory."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return proto_document(await client.fleet.commissioning.research_pod_readiness(revision))


@mcp.tool(name="fleet.research_pod.commit")
async def fleet_research_pod_commit(revision: dict[str, object]) -> dict[str, object]:
    """Commit one validated, immutable research-pod revision."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return proto_document(await client.fleet.commissioning.commit_research_pod(revision))


@mcp.tool(name="fleet.controller.commit_station")
async def fleet_controller_commit_station(controller: dict[str, object]) -> dict[str, object]:
    """Commission a station-attached controller from discovered inventory."""

    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return proto_document(
            await client.fleet.commissioning.commit_station_controller(controller)
        )


def _operation_document(
    operation: Operation[object, object], status: OperationReceipt
) -> dict[str, object]:
    """One receipt as an agent reads it, with progress in the shape its owner declared.

    An agent polling an evaluation sees ``completed_cases``/``total_cases`` here and
    nowhere else — there is no dashboard in this loop. ``Operation.progress`` decodes
    the families whose owner publishes a typed ledger, so a malformed one is refused
    at this door instead of reaching an agent as owner-shaped noise; a family with no
    typed ledger passes its mapping through unchanged, and an operation that has
    published nothing yet carries no ``progress`` key at all rather than a null.
    """

    document = _mapping(status)
    progress = operation.progress(status)
    if progress is None:
        document.pop("progress", None)
    elif not isinstance(progress, Mapping):
        document["progress"] = _mapping(progress)
    return document


@mcp.tool(name="operation.status")
async def operation_status(ref: str) -> dict[str, object]:
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        operation = client.operation(ref)
        return _operation_document(operation, await operation.status())


@mcp.tool(name="operation.updates")
async def operation_updates(
    ref: str,
    after: int | None = None,
    limit: int = 100,
    wait_s: float = 0.1,
) -> dict[str, object]:
    """Return one bounded owner-ledger page; this call never streams indefinitely."""

    if limit < 1 or limit > 1_000 or wait_s <= 0.0 or wait_s > 30.0:
        raise ValueError("updates bounds are invalid")
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        operation = client.operation(ref)
        updates = await operation.updates_page(
            after=None if after is None else UpdateCursor(after),
            page_size=limit,
            wait_s=wait_s,
        )
    return {
        "ref": ref,
        "after": after,
        "updates": [_operation_document(operation, update) for update in updates],
        "next_cursor": after if not updates else int(updates[-1].cursor),
        "terminal": bool(
            updates and updates[-1].state.value in {"succeeded", "failed", "cancelled"}
        ),
    }


@mcp.tool(name="operation.result")
async def operation_result(ref: str) -> dict[str, object]:
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        return _mapping(await client.operation(ref).result())


@mcp.tool(name="operation.cancel")
@_decision_mutation("operation.cancel")
async def operation_cancel(
    ref: str,
    reason: str,
    ctx: Context[ServerSession, object, object] | None = None,
) -> dict[str, object]:
    settings = _bound()
    async with Sx(project=settings.project, profile=settings.profile) as client:
        operation = client.operation(ref)
        current = await operation.status()
        if not isinstance(current, (AcceptedOperation, RunningOperation)):
            return _mapping(current)
        if current.cancellation is not None:
            if current.cancellation.reason != reason:
                raise ValueError("operation already carries another cancellation request")
            return _mapping(current)
        return _mapping(await operation.cancel(reason=reason))


def _forbid_unknown_tool_fields() -> None:
    """FastMCP defaults generated argument models to ``extra=ignore``; close them."""

    # FastMCP does not expose generated tool models publicly. Keep this narrow access
    # at the framework boundary so every installed tool still rejects extra fields.
    for tool in mcp._tool_manager._tools.values():  # pyright: ignore[reportPrivateUsage]
        model = tool.fn_metadata.arg_model
        model.model_config["extra"] = "forbid"
        model.model_rebuild(force=True)
        tool.parameters = model.model_json_schema()


_forbid_unknown_tool_fields()


async def _invoke_projection(
    operation: RpcOperation, arguments: dict[str, object]
) -> dict[str, JsonValue]:
    settings = _bound()
    context = arguments.pop("ctx", None)
    key: str | None = None
    if settings.decision_turn and rpc_method(operation).GetOptions().idempotency_level != 1:
        if operation.name not in DECISION_MUTATION_LAWS:
            raise DecisionMutationMetadataError(
                f"DecisionTurn mutation {operation.name!r} has no admitted recovery law"
            )
        if not isinstance(context, Context):
            raise DecisionMutationMetadataError("DecisionTurn mutation metadata is required")
        effect = _parse_decision_effect(cast(McpContext, context))
        if DECISION_MUTATION_LAWS[operation.name] is _DecisionMutationLaw.EFFECT_KEY:
            key = decision_effect_idempotency_key(effect.effect_id)
    request = parse_request(
        operation, {key: value for key, value in arguments.items() if value is not None}
    )
    async with Sx(project=settings.project, profile=settings.profile) as client:
        response = await client.rpc(operation, request, idempotency_key=key)
    return json_document(proto_document(response))


# Native methods are complete descriptor projections. The functions above remain
# only where task/name resolution, uploads, stepping or effect admission add semantics.
register_projections(mcp, _invoke_projection)


def _posthog_from_environment() -> Posthog | None:
    """Build analytics only when its complete startup configuration is present."""

    project_token = os.environ.get("POSTHOG_PROJECT_TOKEN")
    host = os.environ.get("POSTHOG_HOST")
    if project_token is None and host is None:
        return None
    if project_token is None:
        raise RuntimeError("POSTHOG_PROJECT_TOKEN is required when POSTHOG_HOST is set")
    if host is None:
        raise RuntimeError("POSTHOG_HOST is required when POSTHOG_PROJECT_TOKEN is set")
    return Posthog(project_token, host=host)


def main() -> None:
    import signal

    def _shutdown(_signum: int, _frame: object) -> None:
        raise SystemExit(0)

    bind_from_environment()
    posthog = _posthog_from_environment()
    if posthog is not None:
        instrument(mcp, posthog)
    signal.signal(signal.SIGTERM, _shutdown)
    try:
        mcp.run()
    finally:
        if posthog is not None:
            posthog.shutdown()
