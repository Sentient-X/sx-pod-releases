"""Damped least-squares inverse kinematics — a pure morphism over (forward, jacobian).

The solver is parameterized by two callables and knows nothing about the embodiment:

* ``forward(q) -> (position(3,), quaternion(4,))`` — the arm's FK,
* ``jacobian(q) -> (6, n)`` — the spatial Jacobian mapping joint velocities to EE twist.

This is the morphism rule from ``docs/ABSTRACTIONS.md``: the numerical method is one kernel;
each embodiment supplies its own ``(forward, jacobian)``. Levenberg-Marquardt damping keeps the
step well-behaved near singularities (the grasp-alignment regime where naive pseudo-inverse IK
blows up).
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

import numpy as np

from sx_geometry.geometry import Pose, quat_conjugate, quat_multiply, quat_normalize
from sx_geometry.shapes import JacobianMatrix, JointVector, Quat, Vec3

Forward = Callable[[JointVector], tuple[Vec3, Quat]]
Jacobian = Callable[[JointVector], JacobianMatrix]


@dataclass(frozen=True, slots=True, eq=False)
class IKResult:
    """One configuration and how well it achieved the target it was solved for.

    ``converged`` is the verdict of whoever measured the residuals: the solver against the
    tolerances it was given, or a consumer that re-measured them through its own forward
    kinematics. ``at_joint_limits`` names the 1-based joints the configuration sits against a
    limit of, which is how a caller distinguishes "no solution exists" from "the arm ran out of
    travel getting there"; it is empty when the solve was unbounded.
    """

    q: JointVector
    position_error: float
    orientation_error: float
    iterations: int
    converged: bool
    at_joint_limits: tuple[int, ...] = ()


def orientation_error(current: Quat, target: Quat) -> Vec3:
    """Rotation-vector error (3,) taking ``current`` orientation to ``target`` (both wxyz).

    The error quaternion is canonicalized to ``w >= 0`` first (``q`` and ``-q`` are the same
    rotation), so the rotation vector is always the *shortest* geodesic (magnitude in ``[0, pi]``).
    Skipping this lets a ``w < 0`` error drive the joint the long way round — up to 2*pi of
    needless travel — which saturates a wrist and corrupts the orientation metric.
    """
    q_err = quat_multiply(quat_normalize(target), quat_conjugate(quat_normalize(current)))
    if q_err[0] < 0.0:
        q_err = -q_err
    w = float(np.clip(q_err[0], -1.0, 1.0))
    vec = q_err[1:]
    n = float(np.linalg.norm(vec))
    if n < 1e-9:
        return np.zeros(3)
    angle = 2.0 * np.arctan2(n, w)
    return (vec / n) * angle


JOINT_LIMIT_ATOL_RAD = 1e-3
"""How close to a bound a clipped joint counts as resting on it, per :attr:`IKResult`.

Loose on purpose: the iterate is clipped *onto* the bound, so exact equality would be the only
match, and a caller diagnosing a failed reach wants "this joint ran out of travel", not a
floating-point identity test.
"""


def _at_joint_limits(
    q: JointVector, joint_limits: tuple[JointVector, JointVector]
) -> tuple[int, ...]:
    """The 1-based joints of ``q`` resting against either bound."""
    lo, hi = joint_limits
    against = np.isclose(q, lo, atol=JOINT_LIMIT_ATOL_RAD) | np.isclose(
        q, hi, atol=JOINT_LIMIT_ATOL_RAD
    )
    return tuple(index + 1 for index, near in enumerate(against) if near)


def solve_ik(
    forward: Forward,
    jacobian: Jacobian,
    target: Pose,
    q0: JointVector,
    *,
    max_iters: int = 100,
    damping: float = 0.05,
    pos_tol: float = 1e-4,
    rot_tol: float = 1e-3,
    rot_weight: float = 1.0,
    step_clip: float = 0.3,
    joint_limits: tuple[JointVector, JointVector] | None = None,
) -> IKResult:
    """Solve for joints placing the EE at ``target``, starting from ``q0`` (damped least squares).

    Returns the best configuration found; ``converged`` is True iff both position and orientation
    residuals fell within tolerance. ``joint_limits`` (lo, hi) clamps each iterate if given, and
    the result then reports which joints came to rest against a bound.

    ``rot_weight`` scales the orientation task relative to position (1.0 = equal). Lower it
    (e.g. 0.3) to prioritize reaching a point over matching orientation, or set 0.0 for
    position-only IK — the robust regime for a redundant/near-singular arm whose grasp is
    orientation-agnostic (the orientation tolerance is then ignored for convergence).
    """
    q = np.array(q0, dtype=np.float64)
    pos_err = rot_err = float("inf")
    it = 0
    at_limits: tuple[int, ...] = () if joint_limits is None else _at_joint_limits(q, joint_limits)
    for it in range(1, max_iters + 1):
        pos, quat = forward(q)
        e_pos = target.position - pos
        e_rot = orientation_error(quat, target.quaternion) * rot_weight
        pos_err = float(np.linalg.norm(e_pos))
        rot_err = float(np.linalg.norm(e_rot)) / rot_weight if rot_weight > 0 else 0.0
        if pos_err < pos_tol and rot_err < rot_tol:
            return IKResult(q, pos_err, rot_err, it, True, at_limits)

        error = np.concatenate([e_pos, e_rot])
        jac = jacobian(q).copy()
        jac[3:] *= rot_weight  # scale the orientation rows to match the weighted error
        # damped least squares: dq = Jᵀ (J Jᵀ + λ²I)⁻¹ e
        jjt = jac @ jac.T + (damping**2) * np.eye(6)
        dq = jac.T @ np.linalg.solve(jjt, error)
        norm = float(np.linalg.norm(dq))
        if norm > step_clip:
            dq *= step_clip / norm
        q = q + dq
        if joint_limits is not None:
            q = np.clip(q, joint_limits[0], joint_limits[1])
            at_limits = _at_joint_limits(q, joint_limits)

    converged = pos_err < pos_tol and rot_err < rot_tol
    return IKResult(q, pos_err, rot_err, it, converged, at_limits)
