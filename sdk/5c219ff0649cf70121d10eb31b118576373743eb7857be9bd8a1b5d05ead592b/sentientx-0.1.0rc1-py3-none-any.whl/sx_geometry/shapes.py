"""Array shapes whose dimensions are laws of the rigid-motion domain."""

import numpy as np
from jaxtyping import Float64
from numpy.typing import NDArray

type Vec3 = Float64[NDArray[np.float64], "3"]
"""A three-dimensional position, direction, or rotation vector."""

type Quat = Float64[NDArray[np.float64], "4"]
"""A quaternion in canonical ``(w, x, y, z)`` order."""

type Mat3 = Float64[NDArray[np.float64], "3 3"]
"""A three-dimensional rotation matrix."""

type Mat4 = Float64[NDArray[np.float64], "4 4"]
"""A homogeneous rigid transform."""

type JointVector = Float64[NDArray[np.float64], "joints"]
"""One embodiment-native joint configuration."""

type SpatialVector = Float64[NDArray[np.float64], "6"]
"""A spatial velocity, force, or pose-error vector."""

type JacobianMatrix = Float64[NDArray[np.float64], "6 joints"]
"""A spatial Jacobian sharing its joint axis with :data:`JointVector`."""
