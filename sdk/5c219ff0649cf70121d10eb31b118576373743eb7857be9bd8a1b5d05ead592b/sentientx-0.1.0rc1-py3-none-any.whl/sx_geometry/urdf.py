"""Forward kinematics from a URDF: the first real conformer of ``(forward, jacobian)``.

:func:`~sx_geometry.solve_ik` has always been a morphism over two callables, and until now
nothing in the stack supplied them for an actual arm. This module builds them from the one
authoritative description every embodiment already carries — its URDF — so a chain is derived
from the robot's own description rather than transcribed into a second table that can drift
from it.

The whole module is a pure function of bytes. It parses no files, loads no meshes, resolves no
package paths, and knows nothing about any embodiment registry: a caller supplies the URDF text
and names the two links it wants a transform between. That keeps this package what its charter
says it is — numerics over geometry — and leaves *which* links those are as a fact of the
consumer, matching the standing decision that runtime FK is a consumer adapter rather than a
centralized service.

The kinematics are ordinary URDF semantics, stated once so the code below can stay short. A
joint's ``origin`` transforms the parent frame into the joint frame; the joint's own motion is
then applied **about/along ``axis``, expressed in that joint frame**::

    T_parent_child(q) = T_origin  *  T_motion(q)

with ``T_motion`` a rotation about ``axis`` for a revolute or continuous joint, a translation
along ``axis`` for a prismatic one, and the identity for a fixed one. Getting the order the
other way round is the classic URDF FK bug: it produces a chain that is correct at ``q = 0``
and wrong everywhere else, which unit tests seeded at the home configuration will not catch.
"""

import xml.etree.ElementTree as ET
from dataclasses import dataclass
from enum import StrEnum

import numpy as np

from sx_geometry.geometry import (
    Pose,
    Quat,
    Vec3,
    mat_to_quat,
    quat_to_mat,
    rotation_about_axis,
    rpy_to_matrix,
)
from sx_geometry.shapes import JacobianMatrix, JointVector, SpatialVector


class UrdfError(ValueError):
    """A URDF cannot be read as a kinematic chain."""


class JointKind(StrEnum):
    """The URDF joint types this module realizes. Anything else is refused by name."""

    REVOLUTE = "revolute"
    CONTINUOUS = "continuous"
    PRISMATIC = "prismatic"
    FIXED = "fixed"

    @property
    def actuated(self) -> bool:
        return self is not JointKind.FIXED


@dataclass(frozen=True, slots=True, eq=False)
class UrdfJoint:
    """One edge of the kinematic tree: where the child frame sits, and how it moves."""

    name: str
    kind: JointKind
    parent: str
    child: str
    origin: Pose
    axis: Vec3

    def motion(self, value: float) -> Pose:
        """The joint's own contribution, in the joint frame — never including ``origin``."""
        if self.kind is JointKind.PRISMATIC:
            return Pose(
                position=self.axis * float(value),
                quaternion=np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float64),
            )
        if self.kind is JointKind.FIXED:
            return Pose.identity()
        return Pose(
            position=np.zeros(3, dtype=np.float64),
            quaternion=mat_to_quat(rotation_about_axis(self.axis, float(value))),
        )


@dataclass(frozen=True, slots=True, eq=False)
class KinematicChain:
    """An ordered base-to-tip run of joints, and the FK/Jacobian pair it induces.

    ``joints`` are in traversal order, fixed ones included, because a fixed joint still moves
    the tool frame. Only the actuated ones consume a value from ``q``, in the order they appear
    here — which is the order :attr:`actuated_names` reports, and the order a caller must
    reconcile with whatever its state vector declares.
    """

    base_link: str
    tip_link: str
    joints: tuple[UrdfJoint, ...]

    @property
    def actuated_names(self) -> tuple[str, ...]:
        """The joints that consume a value, base to tip."""
        return tuple(joint.name for joint in self.joints if joint.kind.actuated)

    @property
    def dof(self) -> int:
        return len(self.actuated_names)

    def poses(self, q: JointVector) -> tuple[Pose, ...]:
        """The base-frame pose of every joint frame along the chain, then the tip.

        Returned rather than recomputed per query because both :meth:`forward` and
        :meth:`jacobian` need exactly this sequence, and a Jacobian derived from a *second*
        traversal is a second chance to disagree with the FK it is supposed to differentiate.
        """
        values = self._values(q)
        frames: list[Pose] = []
        current = Pose.identity()
        consumed = 0
        for joint in self.joints:
            current = current.compose(joint.origin)
            if joint.kind.actuated:
                frames.append(current)
                current = current.compose(joint.motion(values[consumed]))
                consumed += 1
            else:
                frames.append(current)
        frames.append(current)
        return tuple(frames)

    def forward(self, q: JointVector) -> tuple[Vec3, Quat]:
        """Tip pose in the base frame — conforms to :data:`~sx_geometry.Forward`."""
        tip = self.poses(q)[-1]
        return tip.position, tip.quaternion

    def jacobian(self, q: JointVector) -> JacobianMatrix:
        """The geometric Jacobian ``(6, dof)`` — conforms to :data:`~sx_geometry.Jacobian`.

        Analytic, from the same traversal the FK uses: a revolute joint contributes
        ``(z x (p_tip - p_joint), z)`` and a prismatic one ``(z, 0)``, with ``z`` its axis in
        base coordinates.
        """
        frames = self.poses(q)
        tip = frames[-1].position
        columns: list[SpatialVector] = []
        for frame, joint in zip(frames, self.joints, strict=False):
            if not joint.kind.actuated:
                continue
            axis = quat_to_mat(frame.quaternion) @ joint.axis
            if joint.kind is JointKind.PRISMATIC:
                columns.append(np.asarray(np.concatenate([axis, np.zeros(3)]), dtype=np.float64))
            else:
                columns.append(
                    np.asarray(
                        np.concatenate([np.cross(axis, tip - frame.position), axis]),
                        dtype=np.float64,
                    )
                )
        return np.stack(columns, axis=1) if columns else np.zeros((6, 0), dtype=np.float64)

    def _values(self, q: JointVector) -> JointVector:
        values = np.asarray(q, dtype=np.float64).reshape(-1)
        if values.size != self.dof:
            raise UrdfError(
                f"chain {self.base_link!r} -> {self.tip_link!r} has {self.dof} actuated "
                f"joints, got {values.size} values"
            )
        if not bool(np.isfinite(values).all()):
            raise UrdfError("joint values must be finite")
        return values


def chain_from_urdf(urdf: bytes | str, *, base_link: str, tip_link: str) -> KinematicChain:
    """Build the chain from ``base_link`` to ``tip_link``, or refuse.

    The path is unique because a URDF is a tree: each link has exactly one parent joint. That
    is checked rather than assumed, so a malformed description fails here instead of producing
    a chain that silently omits a link.
    """
    try:
        text = urdf if isinstance(urdf, str) else bytes(urdf).decode()
        root = ET.fromstring(text)
    except (ET.ParseError, UnicodeDecodeError) as exc:
        raise UrdfError(f"URDF is not well-formed XML: {exc}") from exc

    by_child: dict[str, UrdfJoint] = {}
    for element in root.findall("joint"):
        joint = _parse_joint(element)
        if joint.child in by_child:
            raise UrdfError(
                f"link {joint.child!r} has more than one parent joint; this is not a tree"
            )
        by_child[joint.child] = joint

    reversed_path: list[UrdfJoint] = []
    link = tip_link
    seen: set[str] = set()
    while link != base_link:
        if link in seen:  # pragma: no cover - a cycle contradicts the single-parent check
            raise UrdfError(f"kinematic tree contains a cycle at {link!r}")
        seen.add(link)
        joint = by_child.get(link)
        if joint is None:
            raise UrdfError(
                f"no path from {base_link!r} to {tip_link!r}: {link!r} has no parent joint"
            )
        reversed_path.append(joint)
        link = joint.parent
    return KinematicChain(
        base_link=base_link, tip_link=tip_link, joints=tuple(reversed(reversed_path))
    )


def _parse_joint(element: ET.Element) -> UrdfJoint:
    name = element.get("name") or ""
    raw_kind = element.get("type") or ""
    if not name:
        raise UrdfError("every URDF joint needs a name")
    try:
        kind = JointKind(raw_kind)
    except ValueError as exc:
        raise UrdfError(
            f"joint {name!r} has type {raw_kind!r}; this chain realizes "
            f"{', '.join(sorted(k.value for k in JointKind))} and refuses the rest rather "
            "than treating it as fixed"
        ) from exc
    parent = element.find("parent")
    child = element.find("child")
    if parent is None or child is None:
        raise UrdfError(f"joint {name!r} needs both a parent and a child link")
    parent_link = parent.get("link") or ""
    child_link = child.get("link") or ""
    if not parent_link or not child_link:
        raise UrdfError(f"joint {name!r} names an empty parent or child link")
    return UrdfJoint(
        name=name,
        kind=kind,
        parent=parent_link,
        child=child_link,
        origin=_parse_origin(element.find("origin"), name),
        axis=_parse_axis(element.find("axis"), name, kind),
    )


def _parse_origin(element: ET.Element | None, joint: str) -> Pose:
    if element is None:
        return Pose.identity()
    xyz = _triple(element.get("xyz"), joint, "origin xyz", default=(0.0, 0.0, 0.0))
    rpy = _triple(element.get("rpy"), joint, "origin rpy", default=(0.0, 0.0, 0.0))
    return Pose(
        position=np.asarray(xyz, dtype=np.float64),
        quaternion=mat_to_quat(rpy_to_matrix(rpy[0], rpy[1], rpy[2])),
    )


def _parse_axis(element: ET.Element | None, joint: str, kind: JointKind) -> Vec3:
    if not kind.actuated:
        return np.array([0.0, 0.0, 1.0], dtype=np.float64)
    # URDF's own default. Stated rather than inherited silently, because an actuated joint whose
    # axis is missing moves in a direction nothing wrote down.
    xyz = _triple(
        element.get("xyz") if element is not None else None,
        joint,
        "axis",
        default=(1.0, 0.0, 0.0),
    )
    axis = np.asarray(xyz, dtype=np.float64)
    norm = float(np.linalg.norm(axis))
    if norm < 1e-12:
        raise UrdfError(f"joint {joint!r} has a zero-length axis")
    return axis / norm


def _triple(
    raw: str | None, joint: str, field: str, *, default: tuple[float, float, float]
) -> tuple[float, float, float]:
    if raw is None:
        return default
    parts = raw.split()
    if len(parts) != 3:
        raise UrdfError(f"joint {joint!r} {field} needs three numbers, got {raw!r}")
    try:
        values = tuple(float(part) for part in parts)
    except ValueError as exc:
        raise UrdfError(f"joint {joint!r} {field} is not numeric: {raw!r}") from exc
    if not all(np.isfinite(value) for value in values):
        raise UrdfError(f"joint {joint!r} {field} is not finite: {raw!r}")
    return (values[0], values[1], values[2])


def chain_for_joints(
    urdf: bytes | str, joint_names: tuple[str, ...], *, through_fixed: bool = True
) -> KinematicChain:
    """The chain driven by exactly these joints, base and tool frame derived from them.

    A consumer knows which joints its state vector reports — an embodiment declares them — but
    not which URDF *links* bound them, and hardcoding a pair of link names per robot is the
    second table this module exists to avoid. Both ends are therefore derived:

    * the base is the parent of the first named joint;
    * the tool frame is found by walking **fixed** joints down from the last named joint's
      child, which is what mounts a gripper onto a wrist. Walking through an actuated joint
      instead would put the tool frame past the fingers, so the walk stops at the first one.

    The result is validated to be driven by exactly ``joint_names``, in order, so a chain that
    picked up an extra actuated joint — or lost one to a branch — is refused rather than
    silently consuming a state vector that means something else.
    """
    if not joint_names:
        raise UrdfError("a chain needs at least one actuated joint")
    text = urdf if isinstance(urdf, str) else bytes(urdf).decode()
    try:
        root = ET.fromstring(text)
    except ET.ParseError as exc:
        raise UrdfError(f"URDF is not well-formed XML: {exc}") from exc

    joints = [_parse_joint(element) for element in root.findall("joint")]
    by_name = {joint.name: joint for joint in joints}
    missing = [name for name in joint_names if name not in by_name]
    if missing:
        raise UrdfError(f"this URDF declares no joint named {', '.join(repr(m) for m in missing)}")

    base_link = by_name[joint_names[0]].parent
    tip_link = by_name[joint_names[-1]].child
    if through_fixed:
        children: dict[str, list[UrdfJoint]] = {}
        for joint in joints:
            children.setdefault(joint.parent, []).append(joint)
        while True:
            onward = [
                joint for joint in children.get(tip_link, ()) if joint.kind is JointKind.FIXED
            ]
            if len(onward) != 1:
                break  # a fork, or nothing further: this is the tool frame
            tip_link = onward[0].child

    chain = chain_from_urdf(text, base_link=base_link, tip_link=tip_link)
    if chain.actuated_names != tuple(joint_names):
        raise UrdfError(
            f"the chain from {base_link!r} to {tip_link!r} is driven by "
            f"{chain.actuated_names}, not by the declared {tuple(joint_names)}"
        )
    return chain
