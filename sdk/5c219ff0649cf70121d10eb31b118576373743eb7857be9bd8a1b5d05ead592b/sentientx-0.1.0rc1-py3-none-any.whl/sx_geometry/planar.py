"""An analytic planar N-link arm — a closed-form embodiment to validate the IK kernel against.

Real embodiments (a MuJoCo arm) supply ``(forward, jacobian)`` from the physics model; this
pure arm supplies them in closed form, so the IK solver can be checked against exact ground
truth with no simulator. Links lie in the x-y plane; the EE orientation is a yaw about z equal
to the sum of joint angles, so the full 6-D spatial Jacobian is exercised.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray


@dataclass(frozen=True, slots=True, eq=False)
class PlanarArm:
    """A planar revolute arm with the given link lengths, rooted at the origin."""

    link_lengths: NDArray[np.float64]

    @property
    def num_joints(self) -> int:
        return int(self.link_lengths.shape[0])

    def forward(self, q: NDArray[np.float64]) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
        """FK: EE ``(position(3,), quaternion(4,) wxyz)`` for joint angles ``q``."""
        angles = np.cumsum(q)
        x = float(np.sum(self.link_lengths * np.cos(angles)))
        y = float(np.sum(self.link_lengths * np.sin(angles)))
        yaw = float(angles[-1])
        quat = np.array([np.cos(yaw / 2.0), 0.0, 0.0, np.sin(yaw / 2.0)])
        return np.array([x, y, 0.0]), quat

    def jacobian(self, q: NDArray[np.float64]) -> NDArray[np.float64]:
        """Spatial Jacobian ``(6, n)``: rows are (vx, vy, vz, wx, wy, wz) per joint."""
        angles = np.cumsum(q)
        n = self.num_joints
        jac = np.zeros((6, n))
        for j in range(n):
            # a joint moves the EE by the cross product of z with the vector from joint j to EE
            dx = -float(np.sum(self.link_lengths[j:] * np.sin(angles[j:])))
            dy = float(np.sum(self.link_lengths[j:] * np.cos(angles[j:])))
            jac[0, j] = dx
            jac[1, j] = dy
            jac[5, j] = 1.0  # each joint rotates about +z
        return jac
