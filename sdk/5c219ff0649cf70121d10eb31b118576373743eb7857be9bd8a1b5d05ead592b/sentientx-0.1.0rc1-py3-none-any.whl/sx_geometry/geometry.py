"""SE(3) rigid-transform primitives — the pose vocabulary shared by every layer.

MimicGen's diversifier is object-centric: it records seed segments *relative to* the object
frame and replays them transformed into each new scene's object frame. That is a chain of
SE(3) composes/inverses, so the platform needs one small, pure, dependency-light rigid-motion
kernel. Quaternions are ``(w, x, y, z)`` (MuJoCo's convention) and are kept normalized.

**One rigid pose, two parametrizations.** :class:`Pose` carries an orientation *quaternion*: it
is the record/wire form (compact, singularity-free, the shape scene and task records serialize).
:class:`Pose6D` carries an orientation *matrix*: it is the computation form the perception and
robot layers work in, where the columns are the frame's axes and a grasp's approach direction is
literally the ``+z`` column. They are the same concept, and conversion is explicit at the
boundary — :meth:`Pose6D.to_pose` and :meth:`Pose6D.from_pose` are the one conversion path, so no
layer keeps a private matrix/quaternion translation of its own.

Everything here is float64 and frozen. Records that carry NumPy arrays set ``eq=False``
(element-wise ``==`` would break truth-testing) and treat their arrays as read-only by
convention.

This package is numpy-only on purpose: it is the stack's rigid-motion leaf, below ``sx_worlds``
(whose scene/task records carry poses) and below the FK/IK kernels next door
(:mod:`sx_geometry.ik`, :mod:`sx_geometry.urdf`), so the records vocabulary never has to depend
on a solver to share one ``Pose``. It is the correctness reference every engine adapter and
solver is checked against. It is also effect-free: the hand-eye calibration exchanges *text*
(:meth:`HandEyeCalibration.from_text`/:meth:`~HandEyeCalibration.to_text`), never a file — the
filesystem stays at the caller's edge.
"""

from __future__ import annotations

import io
import math
from dataclasses import dataclass
from typing import Self

import numpy as np
from numpy.typing import NDArray

from sx_geometry.shapes import Mat3, Mat4, Quat, Vec3


def _frozen_array(value: object, shape: tuple[int, ...], field: str) -> NDArray[np.float64]:
    array = np.array(value, dtype=np.float64, copy=True)
    if array.shape != shape:
        raise ValueError(f"{field} must have shape {shape}, got {array.shape}")
    if not bool(np.isfinite(array).all()):
        raise ValueError(f"{field} must contain only finite values")
    array.setflags(write=False)
    return array


def _rotation(value: object, field: str) -> Mat3:
    rotation = _frozen_array(value, (3, 3), field)
    if not np.allclose(rotation.T @ rotation, np.eye(3), atol=1e-9, rtol=0.0):
        raise ValueError(f"{field} must be orthonormal")
    if not math.isclose(float(np.linalg.det(rotation)), 1.0, abs_tol=1e-9):
        raise ValueError(f"{field} must have determinant +1")
    return rotation


def _transform(value: object, field: str) -> Mat4:
    matrix = _frozen_array(value, (4, 4), field)
    if not np.array_equal(matrix[3], np.array([0.0, 0.0, 0.0, 1.0])):
        raise ValueError(f"{field} must have homogeneous bottom row [0, 0, 0, 1]")
    _rotation(matrix[:3, :3], f"{field} rotation")
    return matrix


def _canonical_quaternion(value: object, field: str) -> Quat:
    quaternion = _frozen_array(value, (4,), field)
    norm = float(np.linalg.norm(quaternion))
    if norm < 1e-12:
        raise ValueError(f"{field} must be non-zero")
    normalized = np.array(quaternion / norm, dtype=np.float64, copy=True)
    first = next((item for item in normalized if abs(float(item)) > 1e-15), 1.0)
    if float(first) < 0.0:
        normalized *= -1.0
    normalized.setflags(write=False)
    return normalized


def quat_normalize(q: Quat) -> Quat:
    """Return ``q`` scaled to unit norm; identity for a (numerically) zero quaternion."""
    n = float(np.linalg.norm(q))
    if n < 1e-12:
        return np.array([1.0, 0.0, 0.0, 0.0])
    return np.asarray(q, dtype=np.float64) / n


def quat_conjugate(q: Quat) -> Quat:
    """Conjugate ``(w, -x, -y, -z)`` — the inverse of a unit quaternion."""
    w, x, y, z = q
    return np.array([w, -x, -y, -z], dtype=np.float64)


def quat_multiply(a: Quat, b: Quat) -> Quat:
    """Hamilton product ``a ⊗ b`` (apply ``b`` then ``a``)."""
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return np.array(
        [
            aw * bw - ax * bx - ay * by - az * bz,
            aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw,
        ],
        dtype=np.float64,
    )


def quat_rotate(q: Quat, v: Vec3) -> Vec3:
    """Rotate vector ``v`` by unit quaternion ``q``."""
    qv = np.array([0.0, v[0], v[1], v[2]], dtype=np.float64)
    out = quat_multiply(quat_multiply(q, qv), quat_conjugate(q))
    return out[1:]


def quat_to_mat(q: Quat) -> Mat3:
    """Rotation matrix for unit quaternion ``q``."""
    w, x, y, z = quat_normalize(q)
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ],
        dtype=np.float64,
    )


def mat_to_quat(m: Mat3) -> Quat:
    """Unit quaternion ``(w, x, y, z)`` for rotation matrix ``m`` (Shepperd's method).

    The inverse of :func:`quat_to_mat`; numerically stable across all rotation regimes by
    branching on the largest diagonal term.
    """
    t = float(np.trace(m))
    if t > 0.0:
        s = np.sqrt(t + 1.0) * 2.0
        return quat_normalize(
            np.array(
                [
                    0.25 * s,
                    (m[2, 1] - m[1, 2]) / s,
                    (m[0, 2] - m[2, 0]) / s,
                    (m[1, 0] - m[0, 1]) / s,
                ]
            )
        )
    i = int(np.argmax(np.diagonal(m)))
    j, k = (i + 1) % 3, (i + 2) % 3
    s = np.sqrt(m[i, i] - m[j, j] - m[k, k] + 1.0) * 2.0
    q = np.empty(4)
    q[0] = (m[k, j] - m[j, k]) / s
    q[1 + i] = 0.25 * s
    q[1 + j] = (m[j, i] + m[i, j]) / s
    q[1 + k] = (m[k, i] + m[i, k]) / s
    return quat_normalize(q)


def quat_angle(a: Quat, b: Quat) -> float:
    """Geodesic angle (radians) between two orientations, in ``[0, pi]``."""
    d = abs(float(np.dot(quat_normalize(a), quat_normalize(b))))
    return float(2.0 * np.arccos(min(1.0, d)))


def rpy_to_matrix(roll: float, pitch: float, yaw: float) -> Mat3:
    """Fixed-axis roll/pitch/yaw (radians, ``R = Rz(yaw) @ Ry(pitch) @ Rx(roll)``) -> matrix."""
    cr, sr = math.cos(roll), math.sin(roll)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cy, sy = math.cos(yaw), math.sin(yaw)
    return np.array(
        [
            [cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
            [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
            [-sp, cp * sr, cp * cr],
        ],
        dtype=np.float64,
    )


def matrix_to_rpy(rotation: Mat3) -> tuple[float, float, float]:
    """Rotation matrix -> fixed-axis roll/pitch/yaw radians (inverse of :func:`rpy_to_matrix`).

    At the pitch = +/-90 deg gimbal singularity, roll is conventionally set to zero and the
    remaining rotation is folded into yaw.
    """
    r20 = float(np.clip(rotation[2, 0], -1.0, 1.0))
    pitch = -math.asin(r20)
    if abs(r20) < 1.0 - 1e-6:
        roll = math.atan2(float(rotation[2, 1]), float(rotation[2, 2]))
        yaw = math.atan2(float(rotation[1, 0]), float(rotation[0, 0]))
    else:
        roll = 0.0
        yaw = math.atan2(-float(rotation[0, 1]), float(rotation[1, 1]))
    return roll, pitch, yaw


def rotation_about_axis(axis: Vec3, angle_rad: float) -> Mat3:
    """Rodrigues' rotation about an arbitrary (non-zero) axis."""
    norm = float(np.linalg.norm(axis))
    if norm < 1e-12:
        raise ValueError("rotation axis must be non-zero")
    x, y, z = (float(v) / norm for v in axis)
    c, s = math.cos(angle_rad), math.sin(angle_rad)
    t = 1.0 - c
    return np.array(
        [
            [t * x * x + c, t * x * y - s * z, t * x * z + s * y],
            [t * x * y + s * z, t * y * y + c, t * y * z - s * x],
            [t * x * z - s * y, t * y * z + s * x, t * z * z + c],
        ],
        dtype=np.float64,
    )


@dataclass(frozen=True, slots=True, eq=False)
class Pose:
    """A rigid transform (position + orientation) in some parent frame.

    Read as a point in SE(3): :meth:`compose` is the group operation, :meth:`inverse` the
    group inverse, and :meth:`relative_to` expresses this pose in another pose's frame — the
    exact operation MimicGen uses to make a seed segment object-centric.
    """

    position: Vec3
    quaternion: Quat

    def __post_init__(self) -> None:
        object.__setattr__(self, "position", _frozen_array(self.position, (3,), "Pose.position"))
        object.__setattr__(
            self,
            "quaternion",
            _canonical_quaternion(self.quaternion, "Pose.quaternion"),
        )

    @staticmethod
    def identity() -> Pose:
        """The identity transform (origin, no rotation)."""
        return Pose(np.zeros(3), np.array([1.0, 0.0, 0.0, 0.0]))

    @staticmethod
    def from_matrix(t: Mat4) -> Pose:
        """Pose from a 4x4 homogeneous transform."""
        matrix = _transform(t, "Pose transform")
        return Pose(matrix[:3, 3], mat_to_quat(matrix[:3, :3]))

    def to_matrix(self) -> Mat4:
        """4x4 homogeneous transform for this pose."""
        t = np.eye(4)
        t[:3, :3] = quat_to_mat(self.quaternion)
        t[:3, 3] = self.position
        return t

    def normalized(self) -> Pose:
        """This pose with its quaternion renormalized."""
        return Pose(np.asarray(self.position, dtype=np.float64), quat_normalize(self.quaternion))

    def compose(self, other: Pose) -> Pose:
        """``self ∘ other`` — apply ``other`` in this frame (``self`` is the parent)."""
        pos = self.position + quat_rotate(self.quaternion, other.position)
        rot = quat_multiply(self.quaternion, other.quaternion)
        return Pose(pos, quat_normalize(rot))

    def inverse(self) -> Pose:
        """The inverse transform, so that ``p.compose(p.inverse())`` is identity."""
        qi = quat_conjugate(quat_normalize(self.quaternion))
        return Pose(-quat_rotate(qi, self.position), qi)

    def relative_to(self, frame: Pose) -> Pose:
        """Express this pose in ``frame``'s coordinates: ``frame⁻¹ ∘ self``.

        The object-centric transform: given a gripper pose and the object's pose, this is the
        gripper *as seen from the object*, which is invariant to where the object was placed.
        """
        return frame.inverse().compose(self)

    def transform_point(self, point: Vec3) -> Vec3:
        """Map a point from this frame into the parent frame."""
        return self.position + quat_rotate(self.quaternion, point)


@dataclass(frozen=True, slots=True, eq=False)
class Pose6D:
    """A rigid pose in the matrix parametrization: position plus rotation matrix.

    The computation form of :class:`Pose` (see the module docstring): the rotation's columns are
    the pose's own axes, which is what perception, grasp planning, and arm drivers work in.
    Convention used across the stack: for a *grasp* pose, the gripper's approach direction is the
    rotation's **+z column** (:meth:`approach_axis`) -- planner adapters must convert into this
    convention at the seam.
    """

    position: Vec3
    rotation: Mat3

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "position",
            _frozen_array(self.position, (3,), "Pose6D.position"),
        )
        object.__setattr__(self, "rotation", _rotation(self.rotation, "Pose6D.rotation"))

    def as_matrix(self) -> Mat4:
        """This pose as a ``(4, 4)`` homogeneous transform."""
        matrix = np.eye(4, dtype=np.float64)
        matrix[:3, :3] = self.rotation
        matrix[:3, 3] = self.position
        return matrix

    @classmethod
    def from_matrix(cls, matrix: Mat4) -> Self:
        """Build a pose from a ``(4, 4)`` homogeneous transform."""
        matrix = _transform(matrix, "Pose6D transform")
        return cls(
            position=matrix[:3, 3].astype(np.float64),
            rotation=matrix[:3, :3].astype(np.float64),
        )

    def to_pose(self) -> Pose:
        """This pose in the quaternion parametrization -- the one conversion path."""
        return Pose(
            position=self.position.astype(np.float64),
            quaternion=mat_to_quat(self.rotation),
        )

    @classmethod
    def from_pose(cls, pose: Pose) -> Self:
        """This pose from the quaternion parametrization -- the one conversion path."""
        return cls(
            position=np.asarray(pose.position, dtype=np.float64),
            rotation=quat_to_mat(pose.quaternion),
        )

    def transformed_by(self, transform: Mat4) -> Pose6D:
        """This pose re-expressed through ``transform`` (e.g. camera frame -> base frame)."""
        return Pose6D.from_matrix(np.asarray(transform, dtype=np.float64) @ self.as_matrix())

    def approach_axis(self) -> Vec3:
        """The gripper approach direction: the rotation's +z column (unit vector)."""
        return self.rotation[:, 2].astype(np.float64)

    def translated(self, offset: Vec3) -> Pose6D:
        """This pose shifted by ``offset`` (same frame), rotation unchanged."""
        return Pose6D(position=(self.position + offset).astype(np.float64), rotation=self.rotation)


@dataclass(frozen=True, slots=True)
class CameraIntrinsics:
    """Pinhole intrinsics of a depth-aligned camera stream."""

    fx: float
    fy: float
    cx: float
    cy: float
    width: int
    height: int

    def __post_init__(self) -> None:
        values = (self.fx, self.fy, self.cx, self.cy)
        if any(isinstance(value, bool) or not math.isfinite(value) for value in values):
            raise ValueError("camera intrinsics must be finite")
        if self.fx <= 0.0 or self.fy <= 0.0:
            raise ValueError("camera focal lengths must be positive")
        if (
            isinstance(self.width, bool)
            or isinstance(self.height, bool)
            or self.width <= 0
            or self.height <= 0
        ):
            raise ValueError("camera dimensions must be positive integers")

    def deproject(self, u: float, v: float, depth_m: float) -> Vec3:
        """Pixel ``(u, v)`` at ``depth_m`` meters -> a camera-frame 3D point."""
        x = (u - self.cx) * depth_m / self.fx
        y = (v - self.cy) * depth_m / self.fy
        return np.array([x, y, depth_m], dtype=np.float64)


@dataclass(frozen=True, slots=True)
class FramedTransform:
    """One checked ``parent_from_child`` transform with frame identity attached."""

    parent: str
    child: str
    pose: Pose

    def __post_init__(self) -> None:
        if not self.parent.strip() or not self.child.strip():
            raise ValueError("transform frames must be non-empty")

    def compose(self, other: FramedTransform) -> FramedTransform:
        if self.child != other.parent:
            raise ValueError(
                f"cannot compose {self.parent}<-{self.child} with {other.parent}<-{other.child}"
            )
        return FramedTransform(self.parent, other.child, self.pose.compose(other.pose))

    def inverse(self) -> FramedTransform:
        return FramedTransform(self.child, self.parent, self.pose.inverse())


@dataclass(frozen=True, slots=True, eq=False)
class WorkspaceBox:
    """An axis-aligned reachable/safe region in the arm base frame (meters)."""

    lo: Vec3
    hi: Vec3

    def __post_init__(self) -> None:
        lo = _frozen_array(self.lo, (3,), "WorkspaceBox.lo")
        hi = _frozen_array(self.hi, (3,), "WorkspaceBox.hi")
        if bool(np.any(lo > hi)):
            raise ValueError("workspace lower bounds must not exceed upper bounds")
        object.__setattr__(self, "lo", lo)
        object.__setattr__(self, "hi", hi)

    def contains(self, point: Vec3) -> bool:
        """Whether ``point`` lies inside the box (inclusive)."""
        return bool(np.all(point >= self.lo) and np.all(point <= self.hi))


@dataclass(frozen=True, slots=True, eq=False)
class GraspCandidate:
    """One proposed grasp: pose (approach = +z), jaw width in meters, planner score."""

    pose: Pose6D
    width: float
    score: float


@dataclass(frozen=True, slots=True, eq=False)
class HandEyeCalibration:
    """The camera-to-arm-base rigid transform from hand-eye calibration (e.g. TSAI).

    Exchanged as a plain-text ``(4, 4)`` matrix so a calibration produced by an external tool
    (the reBot-style ``collect_handeye`` + TSAI solver) drops in directly and stays
    human-checkable. The *text* is the contract (:meth:`from_text`/:meth:`to_text`); reading and
    writing the file is the caller's effect, not this leaf's.
    """

    camera_to_base: Mat4

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "camera_to_base",
            _transform(self.camera_to_base, "camera_to_base"),
        )

    def to_base(self, pose: Pose6D) -> Pose6D:
        """Re-express a camera-frame pose in the arm base frame."""
        return pose.transformed_by(self.camera_to_base)

    def point_to_base(self, point: Vec3) -> Vec3:
        """Re-express a camera-frame point in the arm base frame."""
        homogeneous = np.append(np.asarray(point, dtype=np.float64), 1.0)
        return (self.camera_to_base @ homogeneous)[:3].astype(np.float64)

    @classmethod
    def identity(cls) -> Self:
        """A no-op calibration (camera frame == base frame); useful for tests and dry runs."""
        return cls(camera_to_base=np.eye(4, dtype=np.float64))

    @classmethod
    def from_text(cls, text: str) -> Self:
        """Parse a whitespace-separated 4x4 text matrix (the exchanged calibration form)."""
        return cls(camera_to_base=np.loadtxt(io.StringIO(text), dtype=np.float64).reshape(4, 4))

    def to_text(self) -> str:
        """This calibration as a whitespace-separated 4x4 text matrix."""
        buffer = io.StringIO()
        np.savetxt(buffer, np.asarray(self.camera_to_base, dtype=np.float64))
        return buffer.getvalue()
