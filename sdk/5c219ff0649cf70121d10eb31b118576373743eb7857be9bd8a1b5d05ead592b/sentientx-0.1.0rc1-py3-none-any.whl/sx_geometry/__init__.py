"""sx-geometry — the stack's rigid-motion leaf, and the kinematics built directly on it.

One small, pure rigid-motion kernel — the quaternion algebra, the fixed-axis roll/pitch/yaw and
Rodrigues matrix constructors, and one rigid pose in its two parametrizations (``Pose``, carrying
a ``(w, x, y, z)`` MuJoCo-convention quaternion, and ``Pose6D``, carrying a rotation matrix) —
plus the small frozen records that ride on it across the perception/robot boundary
(``CameraIntrinsics``, ``WorkspaceBox``, ``GraspCandidate``, ``HandEyeCalibration``).

On top of that pose algebra sit the kinematics every arm consumer shares:

* :func:`solve_ik`, a damped-least-squares solver written as a **pure morphism** over
  ``(forward, jacobian)`` callables — the numerical method is one kernel, and each embodiment
  supplies its own FK/Jacobian, so the same solver retargets a UMI trajectory onto any arm
  without knowing the arm;
* :func:`chain_from_urdf` / :func:`chain_for_joints`, which derive that ``(forward, jacobian)``
  pair from the one authoritative description an embodiment already carries — its URDF;
* :class:`PlanarArm`, the closed-form embodiment the solver is checked against with no simulator.

The kinematics compose the poses rather than restating them, which is why they live here rather
than one package up: an IK kernel that depended on a records package for one ``Pose`` type, or a
geometry leaf that could not be exercised against an arm, were the two halves of one seam.

This is the platform's generic dependency-free IK. Embodiment-specific analytic methods can live
at their consuming edge without entering this leaf: the standalone Experience
``data-pipeline/teleop-retarget`` runtime, for example, uses :class:`Pose` and the shared URDF
chain as its geometry/FK oracle while keeping its RBY1-only Stereo-SEW/Paden-Kahan solver local.

Dependency budget: numpy only (enforced by ``tests/test_purity.py``), so it imports in any
consumer's environment. See ``sx/docs/ABSTRACTIONS.md`` (Map 3, and the accepted asymmetries).
"""

from sx_geometry.geometry import (
    CameraIntrinsics,
    FramedTransform,
    GraspCandidate,
    HandEyeCalibration,
    Mat3,
    Mat4,
    Pose,
    Pose6D,
    Quat,
    Vec3,
    WorkspaceBox,
    mat_to_quat,
    matrix_to_rpy,
    quat_angle,
    quat_conjugate,
    quat_multiply,
    quat_normalize,
    quat_rotate,
    quat_to_mat,
    rotation_about_axis,
    rpy_to_matrix,
)
from sx_geometry.ik import Forward, IKResult, Jacobian, orientation_error, solve_ik
from sx_geometry.planar import PlanarArm
from sx_geometry.shapes import JacobianMatrix, JointVector, SpatialVector
from sx_geometry.urdf import (
    JointKind,
    KinematicChain,
    UrdfError,
    chain_for_joints,
    chain_from_urdf,
)

__all__ = [
    "CameraIntrinsics",
    "Forward",
    "FramedTransform",
    "GraspCandidate",
    "HandEyeCalibration",
    "IKResult",
    "Jacobian",
    "JacobianMatrix",
    "JointKind",
    "JointVector",
    "KinematicChain",
    "Mat3",
    "Mat4",
    "PlanarArm",
    "Pose",
    "Pose6D",
    "Quat",
    "SpatialVector",
    "UrdfError",
    "Vec3",
    "WorkspaceBox",
    "chain_for_joints",
    "chain_from_urdf",
    "mat_to_quat",
    "matrix_to_rpy",
    "orientation_error",
    "quat_angle",
    "quat_conjugate",
    "quat_multiply",
    "quat_normalize",
    "quat_rotate",
    "quat_to_mat",
    "rotation_about_axis",
    "rpy_to_matrix",
    "solve_ik",
]
