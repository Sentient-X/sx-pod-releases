"""The immutable Catalog → Autonomy corpus membership contract."""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass
from enum import IntEnum
from typing import NewType, cast

from sx_actions import ActionInterfaceId
from sx_contracts import decode
from sx_contracts.catalog import DatasetSnapshotId, DatasetSnapshotIdError
from sx_contracts.content import Sha256Digest
from sx_contracts.identity import JsonValue, canonical_bytes, content_id
from sx_contracts.wire import WireString
from sx_embodiments import EmbodimentId


class CorpusSchemaVersion(IntEnum):
    V3 = 3


CORPUS_SCHEMA_VERSION = CorpusSchemaVersion.V3

CorpusName = NewType("CorpusName", str)
DatasetName = NewType("DatasetName", str)


class CorpusContractError(ValueError):
    """A corpus cannot satisfy the governed episode-membership contract."""


class MalformedCorpusError(CorpusContractError):
    """Stored or received corpus JSON is not the canonical wire shape."""


class DomainName(WireString):
    """Stable human-readable identity for one normalization/action domain.

    Its invariant is its own — it admits digits and case a `DottedIdentifier` refuses —
    so it keeps its `__new__` rather than being bent onto a shared predicate.
    """

    def __new__(cls, value: str) -> DomainName:
        segments = value.split(".")
        if (
            not value
            or any(char.isspace() for char in value)
            or any(not segment for segment in segments)
            or any(not segment.replace("_", "").replace("-", "").isalnum() for segment in segments)
        ):
            raise CorpusContractError(
                f"domain name must be a non-empty dotted identifier: {value!r}"
            )
        return super().__new__(cls, value)


@dataclass(frozen=True, slots=True)
class Domain:
    """Episodes sharing one exact embodiment and controller, named by one snapshot.

    A domain says *which* episodes only through `snapshot`. That is the whole of the
    schema-3 change and the reason for it: which episodes a corpus selects is the
    Catalog's fact, held as an immutable content-addressed membership it can stream,
    and a corpus that repeated the members inline was a second copy of that fact
    whose size grew with the dataset. What stays here is what the Catalog does *not*
    know — how much weight this domain carries in the mix, and which normalization
    domain its episodes belong to.
    """

    name: DomainName
    embodiment_id: EmbodimentId
    action_interface_id: ActionInterfaceId
    snapshot: DatasetSnapshotId
    weight: float = 1.0

    def __post_init__(self) -> None:
        if not math.isfinite(self.weight) or self.weight <= 0.0:
            raise CorpusContractError(
                f"domain {self.name!r} weight must be finite and > 0, got {self.weight}"
            )


@dataclass(frozen=True, slots=True)
class CorpusManifest:
    """An ordered immutable selection of governed episode snapshots."""

    domains: tuple[Domain, ...]
    schema_version: CorpusSchemaVersion = CORPUS_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version is not CORPUS_SCHEMA_VERSION:
            raise CorpusContractError(
                f"unsupported corpus schema {self.schema_version}; expected {CORPUS_SCHEMA_VERSION}"
            )
        if not self.domains:
            raise CorpusContractError("a training corpus needs at least one domain")
        names = tuple(domain.name for domain in self.domains)
        if len(set(names)) != len(names):
            raise CorpusContractError("a training corpus repeats a domain name")
        snapshots = tuple(domain.snapshot for domain in self.domains)
        if len(set(snapshots)) != len(snapshots):
            # Two domains over one membership would train on the same episodes twice
            # under two weights, and claim two embodiments for them. Neither is a
            # selection anyone meant to express.
            raise CorpusContractError("a training corpus repeats a snapshot across domains")

    @property
    def snapshots(self) -> tuple[DatasetSnapshotId, ...]:
        """Every membership this corpus reads, in manifest order."""
        return tuple(domain.snapshot for domain in self.domains)

    @property
    def canonical_bytes(self) -> bytes:
        """The ordered canonical manifest as bytes — the form the digest covers.

        Anything that transports or content-addresses a corpus outside the
        Catalog (lineage edges, caches, attestations) sends these bytes, so the
        identity it records is the identity the Catalog governs.
        """
        return canonical_bytes(manifest_to_dict(self))

    @property
    def digest(self) -> Sha256Digest:
        """The digest Catalog computes over the ordered canonical manifest."""
        return content_id(Sha256Digest, manifest_to_dict(self))

    @property
    def embodiment_ids(self) -> frozenset[EmbodimentId]:
        return frozenset(domain.embodiment_id for domain in self.domains)

    @property
    def action_interface_ids(self) -> frozenset[ActionInterfaceId]:
        return frozenset(domain.action_interface_id for domain in self.domains)


def manifest_to_dict(manifest: CorpusManifest) -> dict[str, JsonValue]:
    """Return the sole canonical stable manifest projection."""
    return {
        "schema_version": manifest.schema_version,
        "domains": [_domain_to_dict(domain) for domain in manifest.domains],
    }


def _domain_to_dict(domain: Domain) -> dict[str, JsonValue]:
    return {
        "name": str(domain.name),
        "weight": domain.weight,
        "embodiment_id": str(domain.embodiment_id),
        "action_interface_id": str(domain.action_interface_id),
        "snapshot": str(domain.snapshot),
    }


def manifest_from_dict(document: Mapping[str, object]) -> CorpusManifest:
    """Parse canonical manifest JSON once, rejecting unknown or missing structure."""
    _require_keys(document, {"schema_version", "domains"}, "corpus manifest")
    try:
        schema_version = CorpusSchemaVersion(decode.integer(document, "schema_version"))
    except ValueError as error:
        raise MalformedCorpusError("unsupported corpus schema version") from error
    raw_domains = document["domains"]
    if not isinstance(raw_domains, list):
        raise MalformedCorpusError("domains must be an array")
    return CorpusManifest(
        domains=tuple(_domain_from_object(raw) for raw in cast("list[object]", raw_domains)),
        schema_version=schema_version,
    )


def _domain_from_object(raw: object) -> Domain:
    domain = decode.document(raw, where="domain", error=MalformedCorpusError)
    _require_keys(
        domain,
        {"name", "weight", "embodiment_id", "action_interface_id", "snapshot"},
        "domain",
    )
    try:
        snapshot = DatasetSnapshotId(_string(domain, "snapshot"))
    except DatasetSnapshotIdError as error:
        # `DatasetSnapshotId` owns "is this a snapshot name"; this boundary owns which
        # error the corpus door answers with. Both halves are needed for fail-closed to
        # mean anything to a caller.
        raise CorpusContractError(f"invalid domain snapshot: {error}") from error
    return Domain(
        name=DomainName(_string(domain, "name")),
        weight=decode.number(domain, "weight"),
        embodiment_id=EmbodimentId(_string(domain, "embodiment_id")),
        action_interface_id=ActionInterfaceId(_string(domain, "action_interface_id")),
        snapshot=snapshot,
    )


def _require_keys(value: Mapping[str, object], expected: set[str], field: str) -> None:
    actual = set(value)
    if actual != expected:
        raise MalformedCorpusError(
            f"{field} keys differ: missing={sorted(expected - actual)}, "
            f"extra={sorted(actual - expected)}"
        )


def _string(document: Mapping[str, object], key: str) -> str:
    """A corpus identity that is blank selects nothing — the one rule beyond the kit."""
    value = decode.text(document, key)
    if not value:
        raise MalformedCorpusError(f"{key} must be a non-empty string")
    return value
