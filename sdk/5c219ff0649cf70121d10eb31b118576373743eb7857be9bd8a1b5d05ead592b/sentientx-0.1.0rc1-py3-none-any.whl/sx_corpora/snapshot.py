"""A bounded, immutable Catalog snapshot selected for Autonomy training."""

from dataclasses import dataclass

from sx_contracts import Sha256Digest, decode

from sx_corpora.model import (
    CorpusContractError,
    CorpusManifest,
    CorpusName,
    DatasetName,
    manifest_from_dict,
    manifest_to_dict,
)


@dataclass(frozen=True, slots=True)
class SelectionMember:
    """One governed episode, named the way whoever chose it names it.

    A dataset and a segment and nothing else. This is exactly the identity an atlas
    point and a segment-search hit carry, which is what lets a lasso be posted
    straight back as a membership to freeze.

    Deliberately not `sx_contracts.CatalogSegmentRef`: that value carries the
    member's `base_sha256`, and the base bytes are precisely the fact the mint is
    being asked to establish. A caller says which episodes; the catalog resolves
    which bytes and seals them into the snapshot's identity.
    """

    dataset: DatasetName
    segment_id: str

    def __post_init__(self) -> None:
        if not str(self.dataset).strip() or not self.segment_id.strip():
            raise CorpusContractError("a selection member names one dataset and one segment")


@dataclass(frozen=True, slots=True)
class CorpusSnapshot:
    name: CorpusName
    sha256: Sha256Digest
    manifest: CorpusManifest

    def __post_init__(self) -> None:
        if self.manifest.digest != self.sha256:
            raise ValueError("snapshot digest does not identify its corpus manifest")


@dataclass(frozen=True, slots=True)
class CorpusSnapshotRef:
    """A project-local, content-pinned reference to a Catalog corpus snapshot."""

    name: CorpusName
    sha256: Sha256Digest


def corpus_snapshot_ref_to_dict(snapshot: CorpusSnapshotRef) -> dict[str, str]:
    return {"name": str(snapshot.name), "sha256": str(snapshot.sha256)}


def corpus_snapshot_ref_from_dict(value: object) -> CorpusSnapshotRef:
    document = decode.document(value, where="corpus snapshot ref", error=ValueError)
    if set(document) != {"name", "sha256"}:
        raise ValueError("corpus snapshot ref fields are incomplete")
    return CorpusSnapshotRef(
        name=CorpusName(decode.text(document, "name")),
        sha256=Sha256Digest(decode.text(document, "sha256")),
    )


def corpus_snapshot_to_dict(snapshot: CorpusSnapshot) -> dict[str, object]:
    return {
        "name": str(snapshot.name),
        "sha256": str(snapshot.sha256),
        "manifest": manifest_to_dict(snapshot.manifest),
    }


def corpus_snapshot_from_dict(value: object) -> CorpusSnapshot:
    document = decode.document(value, where="corpus snapshot", error=ValueError)
    if set(document) != {"name", "sha256", "manifest"}:
        raise ValueError("corpus snapshot fields are incomplete")
    manifest_value = document["manifest"]
    manifest_document = decode.document(
        manifest_value, where="corpus snapshot manifest", error=ValueError
    )
    return CorpusSnapshot(
        name=CorpusName(decode.text(document, "name")),
        sha256=Sha256Digest(decode.text(document, "sha256")),
        manifest=manifest_from_dict(manifest_document),
    )
