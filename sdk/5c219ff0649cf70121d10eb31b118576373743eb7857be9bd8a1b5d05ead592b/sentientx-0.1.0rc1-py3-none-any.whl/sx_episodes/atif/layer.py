"""Complete domain value for one ATIF-backed episode layer."""

from __future__ import annotations

import hashlib
import re
from collections.abc import Iterator
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta, timezone
from enum import StrEnum
from itertools import pairwise

from sx_contracts import Sha256Digest
from sx_contracts.wire import DottedIdentifier

from sx_episodes.atif.model import InvalidAtifTrajectoryError, Trajectory, load_trajectory


class AgentTraceError(Exception):
    """An agent trace cannot form a complete synchronized episode layer."""


class AgentTraceClockError(AgentTraceError):
    """Agent wall time cannot be mapped unambiguously onto episode time."""


class AgentTraceRrdError(AgentTraceError):
    """An RRD is not a valid agent episode layer."""


class CapabilityName(DottedIdentifier):
    """A stable, path-safe robot capability identity."""

    error = AgentTraceError
    noun = "capability"


class CapabilityOutcome(StrEnum):
    """The observed terminal result of one capability invocation."""

    SUCCEEDED = "succeeded"
    FAILED = "failed"
    SAFE_STOPPED = "safe_stopped"


class AgentLayerKind(StrEnum):
    """The one Catalog layer name owned by this contract."""

    AGENT = "agent"


@dataclass(frozen=True, slots=True)
class ClockAnchor:
    """One exact correspondence between Unix wall time and episode-relative time."""

    wall_time_ns: int
    episode_time_ns: int

    def __post_init__(self) -> None:
        if self.wall_time_ns < 0 or self.episode_time_ns < 0:
            raise AgentTraceClockError("clock anchor times must be non-negative nanoseconds")


@dataclass(frozen=True, slots=True)
class ClockCalibration:
    """Affine wall-clock to episode-clock calibration, bounded by two observed anchors."""

    start: ClockAnchor
    end: ClockAnchor
    uncertainty_ns: int = 0

    def __post_init__(self) -> None:
        if self.end.wall_time_ns <= self.start.wall_time_ns:
            raise AgentTraceClockError("clock wall-time anchors must increase")
        if self.end.episode_time_ns <= self.start.episode_time_ns:
            raise AgentTraceClockError("clock episode-time anchors must increase")
        if self.uncertainty_ns < 0:
            raise AgentTraceClockError("clock uncertainty must be non-negative")

    def episode_time_ns(self, wall_time_ns: int) -> int:
        """Map one bounded wall timestamp with deterministic integer interpolation."""
        if not self.start.wall_time_ns <= wall_time_ns <= self.end.wall_time_ns:
            raise AgentTraceClockError(
                f"wall timestamp {wall_time_ns} lies outside the calibrated interval"
            )
        wall_offset = wall_time_ns - self.start.wall_time_ns
        wall_span = self.end.wall_time_ns - self.start.wall_time_ns
        episode_span = self.end.episode_time_ns - self.start.episode_time_ns
        return self.start.episode_time_ns + (wall_offset * episode_span) // wall_span


@dataclass(frozen=True, slots=True)
class CapabilitySpan:
    """Causal bridge from one ATIF tool call to executed robot-control time."""

    trajectory_id: str
    atif_step_id: int
    tool_call_id: str
    invocation_id: str
    capability: CapabilityName
    started_wall_time_ns: int
    ended_wall_time_ns: int
    first_control_step: int
    last_control_step: int
    outcome: CapabilityOutcome

    def __post_init__(self) -> None:
        identities = (
            self.trajectory_id,
            self.tool_call_id,
            self.invocation_id,
        )
        if any(not value.strip() for value in identities):
            raise AgentTraceError(
                "capability trajectory, call, and invocation ids must be non-empty"
            )
        if self.atif_step_id < 1:
            raise AgentTraceError("capability ATIF step id must be positive")
        if self.started_wall_time_ns < 0 or self.ended_wall_time_ns < self.started_wall_time_ns:
            raise AgentTraceClockError("capability wall-time interval is invalid")
        if self.first_control_step < 0 or self.last_control_step < self.first_control_step:
            raise AgentTraceError("capability control-step interval is invalid")


@dataclass(frozen=True, slots=True)
class AgentEpisodeLayer:
    """Exact ATIF plus the minimum facts needed to align it to one immutable episode."""

    recording_id: str
    base_sha256: Sha256Digest
    atif_document: bytes
    clock: ClockCalibration
    capabilities: tuple[CapabilitySpan, ...] = ()

    def __post_init__(self) -> None:
        if not self.recording_id.strip():
            raise AgentTraceError("agent layer recording identity must be non-empty")
        if re.fullmatch(r"[a-f0-9]{64}", self.base_sha256) is None:
            raise AgentTraceError("agent layer base SHA-256 must be 64 lowercase hex")
        try:
            self.atif_document.decode("utf-8")
            trajectory = load_trajectory(self.atif_document)
        except UnicodeDecodeError as error:
            raise AgentTraceError("ATIF document must be UTF-8 JSON") from error
        except InvalidAtifTrajectoryError as error:
            raise AgentTraceError(str(error)) from error
        trajectories = tuple(walk_trajectories(trajectory))
        if any(item.continued_trajectory_ref is not None for item in trajectories):
            raise AgentTraceError(
                "episode agent layers require self-contained ATIF; "
                "external continuations are incomplete"
            )
        if not any(item.steps for item in trajectories):
            raise AgentTraceError("agent layer ATIF must contain at least one step")
        for item in trajectories:
            wall_times = tuple(step_wall_time_ns(step.timestamp) for step in item.steps)
            if any(right < left for left, right in pairwise(wall_times)):
                raise AgentTraceClockError("ATIF step timestamps must be non-decreasing")
            for wall_time in wall_times:
                self.clock.episode_time_ns(wall_time)
        invocation_ids = tuple(span.invocation_id for span in self.capabilities)
        if len(set(invocation_ids)) != len(invocation_ids):
            raise AgentTraceError("capability invocation ids must be unique within an agent layer")
        tool_calls = {
            (item.trajectory_id, step.step_id, call.tool_call_id)
            for item in trajectories
            if item.trajectory_id is not None
            for step in item.steps
            for call in step.tool_calls or ()
        }
        for span in self.capabilities:
            if (
                span.trajectory_id,
                span.atif_step_id,
                span.tool_call_id,
            ) not in tool_calls:
                raise AgentTraceError(
                    "capability span must reference an ATIF tool call in the embedded document"
                )
            self.clock.episode_time_ns(span.started_wall_time_ns)
            self.clock.episode_time_ns(span.ended_wall_time_ns)

    @property
    def trajectory(self) -> Trajectory:
        """Parse the canonical embedded bytes into Harbor's ATIF model."""
        return load_trajectory(self.atif_document)

    @property
    def atif_sha256(self) -> str:
        return hashlib.sha256(self.atif_document).hexdigest()


@dataclass(frozen=True, slots=True)
class AgentLayerSummary:
    schema: str
    kind: AgentLayerKind
    recording_id: str
    base_sha256: Sha256Digest
    atif_sha256: Sha256Digest
    agent_name: str
    num_steps: int
    num_tool_calls: int
    num_capabilities: int


def walk_trajectories(trajectory: Trajectory) -> Iterator[Trajectory]:
    """Yield a complete embedded ATIF hierarchy in deterministic pre-order."""
    yield trajectory
    for child in trajectory.subagent_trajectories or ():
        yield from walk_trajectories(child)


_RFC3339 = re.compile(
    r"^(?P<whole>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})"
    r"(?:\.(?P<fraction>\d{1,9}))?"
    r"(?P<zone>Z|[+-]\d{2}:\d{2})$"
)
_EPOCH = datetime(1970, 1, 1, tzinfo=UTC)


def step_wall_time_ns(timestamp: str | None) -> int:
    """Parse one required RFC3339 ATIF timestamp without losing nanosecond precision."""
    if timestamp is None:
        raise AgentTraceClockError("every ATIF step needs a timestamp for episode alignment")
    match = _RFC3339.fullmatch(timestamp)
    if match is None:
        raise AgentTraceClockError(
            f"ATIF timestamp must be timezone-qualified RFC3339: {timestamp!r}"
        )
    zone = match.group("zone")
    if zone == "Z":
        tz = UTC
    else:
        sign = 1 if zone[0] == "+" else -1
        hours, minutes = (int(part) for part in zone[1:].split(":"))
        if hours > 23 or minutes > 59:
            raise AgentTraceClockError(f"ATIF timestamp has an invalid offset: {timestamp!r}")
        tz = timezone(sign * timedelta(hours=hours, minutes=minutes))
    try:
        whole = datetime.strptime(match.group("whole"), "%Y-%m-%dT%H:%M:%S").replace(tzinfo=tz)
    except ValueError as error:
        raise AgentTraceClockError(f"ATIF timestamp is invalid: {timestamp!r}") from error
    delta = whole.astimezone(UTC) - _EPOCH
    seconds = delta.days * 86_400 + delta.seconds
    fraction = (match.group("fraction") or "").ljust(9, "0")
    return seconds * 1_000_000_000 + int(fraction or "0")
