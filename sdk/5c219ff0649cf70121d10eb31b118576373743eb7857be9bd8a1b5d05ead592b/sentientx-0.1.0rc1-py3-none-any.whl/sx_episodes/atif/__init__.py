"""The agent trajectory boundary: Harbor's canonical ATIF, and the episode layer it becomes.

An episode records what the robot executed; an agent trace records what decided it. This
subpackage is the one place the two meet — :mod:`~sx_episodes.atif.model` parses and serializes
Harbor's ATIF contract, :mod:`~sx_episodes.atif.layer` holds the complete layer value (exact ATIF
plus the clock calibration and capability spans that pin it to one immutable base episode), and
:mod:`~sx_episodes.atif.rrd` writes and reads that layer as an RRD over the ``agent/…`` entity
paths ``sx_episodes.schema`` declares.

It is a *subpackage*, not the top level, because Harbor and pydantic enter the dependency budget
with it and nothing else in ``sx_episodes`` may reach them — an episode reader must stay
installable without the agent stack. Import these names from ``sx_episodes.atif``; they are
deliberately not flattened into ``sx_episodes`` (``sx/docs/ABSTRACTIONS.md``, accepted
asymmetries).
"""

from sx_episodes.atif.layer import (
    AgentEpisodeLayer,
    AgentLayerKind,
    AgentLayerSummary,
    AgentTraceClockError,
    AgentTraceError,
    AgentTraceRrdError,
    CapabilityName,
    CapabilityOutcome,
    CapabilitySpan,
    ClockAnchor,
    ClockCalibration,
    step_wall_time_ns,
)
from sx_episodes.atif.model import (
    CURRENT_ATIF_VERSION,
    HARBOR_VERSION,
    SUPPORTED_ATIF_VERSIONS,
    Agent,
    AtifContractError,
    AtifReadError,
    ContentPart,
    FinalMetrics,
    ImageSource,
    InvalidAtifTrajectoryError,
    Metrics,
    Observation,
    ObservationResult,
    Step,
    SubagentTrajectoryRef,
    ToolCall,
    Trajectory,
    dump_trajectory,
    load_trajectory,
    read_trajectory,
)
from sx_episodes.atif.rrd import (
    read_agent_episode_layer,
    validate_agent_episode_layer,
    write_agent_episode_layer,
)

__all__ = [
    "CURRENT_ATIF_VERSION",
    "HARBOR_VERSION",
    "SUPPORTED_ATIF_VERSIONS",
    "Agent",
    "AgentEpisodeLayer",
    "AgentLayerKind",
    "AgentLayerSummary",
    "AgentTraceClockError",
    "AgentTraceError",
    "AgentTraceRrdError",
    "AtifContractError",
    "AtifReadError",
    "CapabilityName",
    "CapabilityOutcome",
    "CapabilitySpan",
    "ClockAnchor",
    "ClockCalibration",
    "ContentPart",
    "FinalMetrics",
    "ImageSource",
    "InvalidAtifTrajectoryError",
    "Metrics",
    "Observation",
    "ObservationResult",
    "Step",
    "SubagentTrajectoryRef",
    "ToolCall",
    "Trajectory",
    "dump_trajectory",
    "load_trajectory",
    "read_agent_episode_layer",
    "read_trajectory",
    "step_wall_time_ns",
    "validate_agent_episode_layer",
    "write_agent_episode_layer",
]
