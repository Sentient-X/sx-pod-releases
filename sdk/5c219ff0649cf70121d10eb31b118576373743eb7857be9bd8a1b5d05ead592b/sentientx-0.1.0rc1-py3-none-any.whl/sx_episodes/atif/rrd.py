"""Arrow-native RRD codec for synchronized ATIF episode layers."""

from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Iterator, Mapping
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import cast
from urllib.parse import quote
from uuid import uuid4

import numpy as np
import pyarrow as pa
import rerun as rr
from pydantic import BaseModel
from rerun.experimental import Chunk, LazyChunkStream, OptimizationProfile, RrdReader
from sx_contracts import Sha256Digest, decode
from sx_contracts.identity import file_digest

from sx_episodes import APPLICATION_ID, read_episode, static_value
from sx_episodes.atif.layer import (
    AgentEpisodeLayer,
    AgentLayerKind,
    AgentLayerSummary,
    AgentTraceError,
    AgentTraceRrdError,
    CapabilityName,
    CapabilityOutcome,
    CapabilitySpan,
    ClockAnchor,
    ClockCalibration,
    step_wall_time_ns,
)
from sx_episodes.atif.model import Step, Trajectory
from sx_episodes.schema import (
    AGENT_OBSERVATION_TIMELINE,
    AGENT_SCHEMA_NAME,
    AGENT_STEP_TIMELINE,
    AGENT_TOOL_TIMELINE,
    CONTROL_TIMELINE,
    PATH_AGENT_ACTIVITY,
    PATH_AGENT_ALIGNMENT,
    PATH_AGENT_ATIF,
    PATH_AGENT_CAPABILITIES,
    PATH_AGENT_MESSAGES,
    PATH_AGENT_META,
    PATH_AGENT_METRICS,
    PATH_AGENT_OBSERVATIONS,
    PATH_AGENT_TOOL_CALLS,
    TIME_TIMELINE,
    WALL_TIMELINE,
)


@dataclass(frozen=True, slots=True)
class _ProjectedStep:
    trace_index: int
    trajectory_key: str
    trajectory_id_json: str
    agent_name: str
    step: Step
    wall_time_ns: int
    episode_time_ns: int


def write_agent_episode_layer(
    atif_document: bytes,
    path: Path,
    *,
    base: Path,
    clock: ClockCalibration,
    capabilities: tuple[CapabilitySpan, ...] = (),
) -> Path:
    """Atomically write one self-contained ATIF layer pinned to an immutable base episode."""
    if path.suffix != ".rrd":
        raise AgentTraceRrdError(f"agent layer path must end in .rrd: {path}")
    if path.exists():
        raise FileExistsError(f"agent layer RRD already exists: {path}")
    episode = read_episode(base)
    layer = AgentEpisodeLayer(
        recording_id=episode.facts.recording_id,
        base_sha256=file_digest(base),
        atif_document=atif_document,
        clock=clock,
        capabilities=capabilities,
    )
    for span in layer.capabilities:
        if span.last_control_step >= episode.num_steps:
            raise AgentTraceError(
                f"capability {span.invocation_id!r} ends at control step "
                f"{span.last_control_step}, but the base has {episode.num_steps} steps"
            )
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_name(f".{path.name}.{uuid4().hex}.partial")
    try:
        store = LazyChunkStream.from_iter(_chunks(layer)).collect(
            optimize=OptimizationProfile.OBJECT_STORE
        )
        store.write_rrd(
            partial,
            application_id=APPLICATION_ID,
            recording_id=layer.recording_id,
        )
        if read_agent_episode_layer(partial) != layer:
            raise AgentTraceRrdError("agent layer changed during RRD round trip")
        if path.exists():
            raise FileExistsError(f"agent layer RRD already exists: {path}")
        os.replace(partial, path)
    finally:
        partial.unlink(missing_ok=True)
    return path


def read_agent_episode_layer(path: Path) -> AgentEpisodeLayer:
    """Read exact ATIF and synchronization facts from one agent layer RRD."""
    try:
        metadata = _json_object(static_value(path, PATH_AGENT_META, "json"), "metadata")
        document = static_value(path, PATH_AGENT_ATIF, "document")
        if document is None:
            raise AgentTraceRrdError("agent layer has no embedded ATIF document")
        encoded = document.encode("utf-8")
        if hashlib.sha256(encoded).hexdigest() != _text(metadata, "atif_sha256"):
            raise AgentTraceRrdError("embedded ATIF bytes disagree with the recorded digest")
        clock_document = _object(metadata, "clock")
        start = _object(clock_document, "start")
        end = _object(clock_document, "end")
        raw_capabilities = metadata.get("capabilities")
        if not isinstance(raw_capabilities, list):
            raise AgentTraceRrdError("agent layer capabilities must be an array")
        layer = AgentEpisodeLayer(
            recording_id=_text(metadata, "recording_id"),
            base_sha256=Sha256Digest(_text(metadata, "base_sha256")),
            atif_document=encoded,
            clock=ClockCalibration(
                start=ClockAnchor(
                    decode.integer(start, "wall_time_ns"),
                    decode.integer(start, "episode_time_ns"),
                ),
                end=ClockAnchor(
                    decode.integer(end, "wall_time_ns"),
                    decode.integer(end, "episode_time_ns"),
                ),
                uncertainty_ns=decode.integer(clock_document, "uncertainty_ns"),
            ),
            capabilities=tuple(
                _capability(_as_object(item, "capability"))
                for item in cast("list[object]", raw_capabilities)
            ),
        )
        if (
            _text(metadata, "schema") != AGENT_SCHEMA_NAME
            or _text(metadata, "layer") != AgentLayerKind.AGENT.value
        ):
            raise AgentTraceRrdError("agent layer metadata has another schema or layer name")
        if _recording_id(path) != layer.recording_id:
            raise AgentTraceRrdError("agent layer RRD recording id disagrees with its facts")
        _validate_projection(path, layer)
        return layer
    except AgentTraceError:
        raise
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as error:
        raise AgentTraceRrdError(f"invalid agent episode layer {path}: {error}") from error


def validate_agent_episode_layer(path: Path) -> AgentLayerSummary:
    layer = read_agent_episode_layer(path)
    trajectories = tuple(_walk(layer.trajectory))
    return AgentLayerSummary(
        schema=AGENT_SCHEMA_NAME,
        kind=AgentLayerKind.AGENT,
        recording_id=layer.recording_id,
        base_sha256=layer.base_sha256,
        atif_sha256=Sha256Digest(layer.atif_sha256),
        agent_name=layer.trajectory.agent.name,
        num_steps=sum(len(item.steps) for _, item in trajectories),
        num_tool_calls=sum(
            len(step.tool_calls or ()) for _, item in trajectories for step in item.steps
        ),
        num_capabilities=len(layer.capabilities),
    )


def _chunks(layer: AgentEpisodeLayer) -> tuple[Chunk, ...]:
    projected = _project(layer)
    chunks: list[Chunk] = [
        Chunk.from_columns(
            PATH_AGENT_META,
            indexes=[],
            columns=rr.AnyValues.columns(json=[_json(_metadata(layer))]),
        ),
        Chunk.from_columns(
            PATH_AGENT_ATIF,
            indexes=[],
            columns=rr.AnyValues.columns(document=[layer.atif_document.decode("utf-8")]),
        ),
        _message_chunk(projected),
        _activity_chunk(projected),
    ]
    tool_chunk = _tool_chunk(projected)
    if tool_chunk is not None:
        chunks.append(tool_chunk)
    observation_chunk = _observation_chunk(projected)
    if observation_chunk is not None:
        chunks.append(observation_chunk)
    chunks.extend(_metric_chunks(projected))
    chunks.extend(_capability_chunks(layer))
    return tuple(chunks)


def _project(layer: AgentEpisodeLayer) -> tuple[_ProjectedStep, ...]:
    projected: list[_ProjectedStep] = []
    for trajectory_key, trajectory in _walk(layer.trajectory):
        trajectory_id_json = _json(trajectory.trajectory_id)
        for step in trajectory.steps:
            wall_time = step_wall_time_ns(step.timestamp)
            projected.append(
                _ProjectedStep(
                    trace_index=len(projected) + 1,
                    trajectory_key=trajectory_key,
                    trajectory_id_json=trajectory_id_json,
                    agent_name=trajectory.agent.name,
                    step=step,
                    wall_time_ns=wall_time,
                    episode_time_ns=layer.clock.episode_time_ns(wall_time),
                )
            )
    return tuple(projected)


def _walk(
    trajectory: Trajectory,
    key: str = "root",
) -> Iterator[tuple[str, Trajectory]]:
    yield key, trajectory
    for index, child in enumerate(trajectory.subagent_trajectories or ()):
        yield from _walk(child, f"{key}/subagent-{index}")


def _indexes(rows: tuple[_ProjectedStep, ...]) -> list[rr.TimeColumn]:
    return [
        rr.TimeColumn(AGENT_STEP_TIMELINE, sequence=[row.trace_index for row in rows]),
        rr.TimeColumn(
            WALL_TIMELINE,
            timestamp=np.asarray([row.wall_time_ns for row in rows], dtype="datetime64[ns]"),
        ),
        rr.TimeColumn(
            TIME_TIMELINE,
            duration=np.asarray([row.episode_time_ns for row in rows], dtype="timedelta64[ns]"),
        ),
    ]


def _message_chunk(rows: tuple[_ProjectedStep, ...]) -> Chunk:
    return Chunk.from_columns(
        PATH_AGENT_MESSAGES,
        indexes=_indexes(rows),
        columns=[
            *rr.TextLog.columns(
                text=[_readable(row.step.message) for row in rows],
                level=["INFO" for _ in rows],
            ),
            *rr.AnyValues.columns(
                trajectory_key=[row.trajectory_key for row in rows],
                trajectory_id_json=[row.trajectory_id_json for row in rows],
                agent_name=[row.agent_name for row in rows],
                atif_step_id=[row.step.step_id for row in rows],
                source=[row.step.source for row in rows],
                model_name_json=[_json(row.step.model_name) for row in rows],
                message_json=[_json_value(row.step.message) for row in rows],
                reasoning_content_json=[_json(row.step.reasoning_content) for row in rows],
                reasoning_effort_json=[_json(row.step.reasoning_effort) for row in rows],
                is_copied_context_json=[_json(row.step.is_copied_context) for row in rows],
                llm_call_count_json=[_json(row.step.llm_call_count) for row in rows],
                extra_json=[_json(row.step.extra) for row in rows],
            ),
        ],
    )


def _activity_chunk(rows: tuple[_ProjectedStep, ...]) -> Chunk:
    states: list[str] = []
    for row in rows:
        if row.step.source != "agent":
            states.append(row.step.source)
        elif row.step.tool_calls:
            states.append("agent:tool")
        else:
            states.append("agent:response")
    return Chunk.from_columns(
        PATH_AGENT_ACTIVITY,
        indexes=_indexes(rows),
        columns=rr.StateChange.columns(state=states),
    )


def _tool_chunk(rows: tuple[_ProjectedStep, ...]) -> Chunk | None:
    expanded = [(row, call) for row in rows for call in row.step.tool_calls or ()]
    if not expanded:
        return None
    owner_rows = tuple(row for row, _ in expanded)
    return Chunk.from_columns(
        PATH_AGENT_TOOL_CALLS,
        indexes=[
            *_indexes(owner_rows),
            rr.TimeColumn(AGENT_TOOL_TIMELINE, sequence=range(1, len(expanded) + 1)),
        ],
        columns=[
            *rr.TextLog.columns(
                text=[f"{call.function_name}({_json(call.arguments)})" for _, call in expanded],
                level=["INFO" for _ in expanded],
            ),
            *rr.AnyValues.columns(
                trajectory_key=[row.trajectory_key for row, _ in expanded],
                atif_step_id=[row.step.step_id for row, _ in expanded],
                tool_call_id=[call.tool_call_id for _, call in expanded],
                function_name=[call.function_name for _, call in expanded],
                arguments_json=[_json(call.arguments) for _, call in expanded],
                extra_json=[_json(call.extra) for _, call in expanded],
            ),
        ],
    )


def _observation_chunk(rows: tuple[_ProjectedStep, ...]) -> Chunk | None:
    expanded = [
        (row, result)
        for row in rows
        if row.step.observation is not None
        for result in row.step.observation.results
    ]
    if not expanded:
        return None
    owner_rows = tuple(row for row, _ in expanded)
    return Chunk.from_columns(
        PATH_AGENT_OBSERVATIONS,
        indexes=[
            *_indexes(owner_rows),
            rr.TimeColumn(AGENT_OBSERVATION_TIMELINE, sequence=range(1, len(expanded) + 1)),
        ],
        columns=[
            *rr.TextLog.columns(
                text=[_readable(result.content) for _, result in expanded],
                level=["INFO" for _ in expanded],
            ),
            *rr.AnyValues.columns(
                trajectory_key=[row.trajectory_key for row, _ in expanded],
                atif_step_id=[row.step.step_id for row, _ in expanded],
                source_call_id_json=[_json(result.source_call_id) for _, result in expanded],
                content_json=[_json_value(result.content) for _, result in expanded],
                subagent_trajectory_ref_json=[
                    _json_value(result.subagent_trajectory_ref) for _, result in expanded
                ],
                extra_json=[_json(result.extra) for _, result in expanded],
            ),
        ],
    )


def _metric_chunks(rows: tuple[_ProjectedStep, ...]) -> tuple[Chunk, ...]:
    metrics = (
        "prompt_tokens",
        "completion_tokens",
        "cached_tokens",
        "cost_usd",
    )
    chunks: list[Chunk] = []
    for name in metrics:
        selected = tuple(
            (row, getattr(row.step.metrics, name))
            for row in rows
            if row.step.metrics is not None and getattr(row.step.metrics, name) is not None
        )
        if selected:
            owner_rows = tuple(row for row, _ in selected)
            chunks.append(
                Chunk.from_columns(
                    f"{PATH_AGENT_METRICS}/{name}",
                    indexes=_indexes(owner_rows),
                    columns=rr.Scalars.columns(scalars=[float(value) for _, value in selected]),
                )
            )
    return tuple(chunks)


def _capability_chunks(layer: AgentEpisodeLayer) -> tuple[Chunk, ...]:
    chunks: list[Chunk] = []
    if not layer.capabilities:
        return ()
    spans = layer.capabilities
    chunks.append(
        Chunk.from_columns(
            PATH_AGENT_ALIGNMENT,
            indexes=[
                rr.TimeColumn(
                    CONTROL_TIMELINE,
                    sequence=[span.first_control_step for span in spans],
                ),
                rr.TimeColumn(
                    WALL_TIMELINE,
                    timestamp=np.asarray(
                        [span.started_wall_time_ns for span in spans], dtype="datetime64[ns]"
                    ),
                ),
                rr.TimeColumn(
                    TIME_TIMELINE,
                    duration=np.asarray(
                        [layer.clock.episode_time_ns(span.started_wall_time_ns) for span in spans],
                        dtype="timedelta64[ns]",
                    ),
                ),
            ],
            columns=[
                *rr.TextLog.columns(
                    text=[
                        f"{span.capability}: controls "
                        f"{span.first_control_step}-{span.last_control_step}"
                        for span in spans
                    ]
                ),
                *rr.AnyValues.columns(
                    trajectory_id=[span.trajectory_id for span in spans],
                    atif_step_id=[span.atif_step_id for span in spans],
                    tool_call_id=[span.tool_call_id for span in spans],
                    invocation_id=[span.invocation_id for span in spans],
                    capability=[str(span.capability) for span in spans],
                    last_control_step=[span.last_control_step for span in spans],
                    outcome=[span.outcome.value for span in spans],
                ),
            ],
        )
    )
    for span in spans:
        chunks.append(
            Chunk.from_columns(
                _capability_path(span),
                indexes=[
                    rr.TimeColumn(
                        CONTROL_TIMELINE,
                        sequence=[span.first_control_step, span.last_control_step],
                    ),
                    rr.TimeColumn(
                        WALL_TIMELINE,
                        timestamp=np.asarray(
                            [span.started_wall_time_ns, span.ended_wall_time_ns],
                            dtype="datetime64[ns]",
                        ),
                    ),
                    rr.TimeColumn(
                        TIME_TIMELINE,
                        duration=np.asarray(
                            [
                                layer.clock.episode_time_ns(span.started_wall_time_ns),
                                layer.clock.episode_time_ns(span.ended_wall_time_ns),
                            ],
                            dtype="timedelta64[ns]",
                        ),
                    ),
                ],
                columns=rr.StateChange.columns(state=["running", span.outcome.value]),
            )
        )
    return tuple(chunks)


def _capability_path(span: CapabilitySpan) -> str:
    return f"{PATH_AGENT_CAPABILITIES}/{span.capability}/{quote(span.invocation_id, safe='')}"


def _metadata(layer: AgentEpisodeLayer) -> dict[str, object]:
    return {
        "schema": AGENT_SCHEMA_NAME,
        "layer": AgentLayerKind.AGENT.value,
        "recording_id": layer.recording_id,
        "base_sha256": layer.base_sha256,
        "atif_sha256": layer.atif_sha256,
        "clock": asdict(layer.clock),
        "capabilities": [asdict(span) for span in layer.capabilities],
    }


def _capability(document: dict[str, object]) -> CapabilitySpan:
    return CapabilitySpan(
        trajectory_id=_text(document, "trajectory_id"),
        atif_step_id=decode.integer(document, "atif_step_id"),
        tool_call_id=_text(document, "tool_call_id"),
        invocation_id=_text(document, "invocation_id"),
        capability=CapabilityName(_text(document, "capability")),
        started_wall_time_ns=decode.integer(document, "started_wall_time_ns"),
        ended_wall_time_ns=decode.integer(document, "ended_wall_time_ns"),
        first_control_step=decode.integer(document, "first_control_step"),
        last_control_step=decode.integer(document, "last_control_step"),
        outcome=CapabilityOutcome(_text(document, "outcome")),
    )


def _validate_projection(path: Path, layer: AgentEpisodeLayer) -> None:
    counts: dict[str, int] = {}
    timelines: dict[str, set[str]] = {}
    message_times: list[tuple[int, int, int]] = []
    for chunk in RrdReader(str(path)).stream().to_chunks():
        entity = str(chunk.entity_path).lstrip("/")
        if entity == "__properties":
            raise AgentTraceRrdError("agent layers must not inject recording properties")
        counts[entity] = counts.get(entity, 0) + chunk.num_rows
        timelines.setdefault(entity, set()).update(chunk.timeline_names)
        if entity == PATH_AGENT_MESSAGES:
            batch = chunk.to_record_batch()
            traces = _integer_column(batch, AGENT_STEP_TIMELINE)
            wall_times = _integer_column(batch, WALL_TIMELINE)
            episode_times = _integer_column(batch, TIME_TIMELINE)
            message_times.extend(zip(traces, wall_times, episode_times, strict=True))
    projected = _project(layer)
    expected_tools = sum(len(row.step.tool_calls or ()) for row in projected)
    expected_observations = sum(
        len(row.step.observation.results) if row.step.observation is not None else 0
        for row in projected
    )
    expected = {
        PATH_AGENT_META: 1,
        PATH_AGENT_ATIF: 1,
        PATH_AGENT_MESSAGES: len(projected),
        PATH_AGENT_ACTIVITY: len(projected),
    }
    if expected_tools:
        expected[PATH_AGENT_TOOL_CALLS] = expected_tools
    if expected_observations:
        expected[PATH_AGENT_OBSERVATIONS] = expected_observations
    if layer.capabilities:
        expected[PATH_AGENT_ALIGNMENT] = len(layer.capabilities)
        expected.update({_capability_path(span): 2 for span in layer.capabilities})
    for entity, count in expected.items():
        if counts.get(entity) != count:
            raise AgentTraceRrdError(
                f"agent projection row count for {entity!r} is {counts.get(entity)}, "
                f"expected {count}"
            )
    temporal = {AGENT_STEP_TIMELINE, WALL_TIMELINE, TIME_TIMELINE}
    if (
        timelines.get(PATH_AGENT_MESSAGES) != temporal
        or timelines.get(PATH_AGENT_ACTIVITY) != temporal
    ):
        raise AgentTraceRrdError(
            "agent step projections lack exact step, wall, or episode timelines"
        )
    capability_timelines = {CONTROL_TIMELINE, WALL_TIMELINE, TIME_TIMELINE}
    if layer.capabilities and timelines.get(PATH_AGENT_ALIGNMENT) != capability_timelines:
        raise AgentTraceRrdError("agent capability alignment lacks control, wall, or episode time")
    for span in layer.capabilities:
        if timelines.get(_capability_path(span)) != capability_timelines:
            raise AgentTraceRrdError(
                f"agent capability {span.invocation_id!r} lacks exact alignment timelines"
            )
    expected_times = [(row.trace_index, row.wall_time_ns, row.episode_time_ns) for row in projected]
    if sorted(message_times) != expected_times:
        raise AgentTraceRrdError("agent message timestamps disagree with ATIF clock projection")


def _integer_column(batch: pa.RecordBatch, name: str) -> list[int]:
    index = batch.schema.get_field_index(name)
    if index < 0:
        raise AgentTraceRrdError(f"agent projection is missing {name!r}")
    values = batch.column(index).cast(pa.int64()).to_pylist()
    if not all(isinstance(value, int) for value in values):
        raise AgentTraceRrdError(f"agent projection {name!r} is not a total integer column")
    return [cast("int", value) for value in values]


def _recording_id(path: Path) -> str:
    recordings = RrdReader(str(path)).recordings()
    if len(recordings) != 1:
        raise AgentTraceRrdError("agent layer RRD must contain exactly one recording")
    return str(recordings[0].recording_id)


def _readable(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return _json_value(value)


def _json_value(value: object) -> str:
    if isinstance(value, list):
        documents: list[object] = []
        for item in cast("list[object]", value):
            if not isinstance(item, BaseModel):
                raise AgentTraceRrdError("ATIF structured content must contain Pydantic models")
            documents.append(item.model_dump(mode="json", exclude_none=False))
        return _json(documents)
    return _json(value)


def _json(value: object) -> str:
    # Deliberately NOT `sx_contracts.identity.canonical_json`: this serializes ATIF
    # *values*, including scalars (`llm_call_count`, `is_copied_context`, a bare model
    # name). A canonical document is an object or an array; a JSON scalar is neither,
    # so sharing the encoder here would widen that type to mean nothing.
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def _json_object(value: str | None, name: str) -> dict[str, object]:
    if value is None:
        raise AgentTraceRrdError(f"agent layer has no canonical {name}")
    return _as_object(json.loads(value), name)


def _as_object(value: object, name: str) -> dict[str, object]:
    if not isinstance(value, dict):
        raise AgentTraceRrdError(f"agent layer {name} must be an object with text keys")
    mapping = cast("dict[object, object]", value)
    if not all(isinstance(key, str) for key in mapping):
        raise AgentTraceRrdError(f"agent layer {name} must be an object with text keys")
    return {cast("str", key): item for key, item in mapping.items()}


def _object(document: dict[str, object], field: str) -> dict[str, object]:
    return _as_object(document.get(field), field)


def _text(document: Mapping[str, object], field: str) -> str:
    """Agent-layer text that is blank names nothing — the one rule beyond the kit."""
    value = decode.text(document, field, where="agent layer", error=AgentTraceRrdError)
    if not value:
        raise AgentTraceRrdError(f"agent layer {field} must be non-empty text")
    return value
