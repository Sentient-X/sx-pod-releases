"""Harbor's ATIF model with one typed sentientx parse and serialization boundary."""

from importlib.metadata import version as distribution_version
from pathlib import Path
from typing import get_args

from harbor.models.trajectories import (
    Agent,
    ContentPart,
    FinalMetrics,
    ImageSource,
    Metrics,
    Observation,
    ObservationResult,
    Step,
    SubagentTrajectoryRef,
    ToolCall,
    Trajectory,
)
from harbor.utils.trajectory_validator import TrajectoryValidator
from pydantic import ValidationError


class AtifContractError(Exception):
    """The installed Harbor package does not expose the ATIF contract we require."""


class AtifReadError(Exception):
    """An ATIF artifact could not be read from its explicit filesystem boundary."""

    def __init__(self, path: Path, reason: str) -> None:
        self.path = path
        self.reason = reason
        super().__init__(f"cannot read ATIF trajectory {path}: {reason}")


class InvalidAtifTrajectoryError(Exception):
    """Harbor rejected an ATIF document."""

    def __init__(self, source: str, errors: tuple[str, ...]) -> None:
        self.source = source
        self.errors = errors
        super().__init__(f"invalid ATIF trajectory from {source}: {'; '.join(errors)}")


def _supported_versions() -> tuple[str, ...]:
    annotation = Trajectory.model_fields["schema_version"].annotation
    versions = get_args(annotation)
    if not versions or not all(isinstance(version, str) for version in versions):
        raise AtifContractError("Harbor Trajectory.schema_version is not a string Literal")
    return tuple(version for version in versions if isinstance(version, str))


SUPPORTED_ATIF_VERSIONS = _supported_versions()
HARBOR_VERSION = distribution_version("harbor")

_current_version = Trajectory.model_fields["schema_version"].default
if not isinstance(_current_version, str) or _current_version not in SUPPORTED_ATIF_VERSIONS:
    raise AtifContractError("Harbor Trajectory has no supported default schema version")
CURRENT_ATIF_VERSION = _current_version


def load_trajectory(document: str | bytes) -> Trajectory:
    """Parse JSON bytes once into Harbor's complete ATIF trajectory model."""

    try:
        return Trajectory.model_validate_json(document)
    except ValidationError as error:
        raise InvalidAtifTrajectoryError("document", (str(error),)) from error


def read_trajectory(path: Path) -> Trajectory:
    """Read and validate an ATIF file, including Harbor's referenced-image checks."""

    validator = TrajectoryValidator()
    try:
        valid = validator.validate(path)
    except OSError as error:
        raise AtifReadError(path, str(error)) from error
    if not valid:
        raise InvalidAtifTrajectoryError(str(path), tuple(validator.get_errors()))
    try:
        document = path.read_bytes()
    except OSError as error:
        raise AtifReadError(path, str(error)) from error
    return load_trajectory(document)


def dump_trajectory(trajectory: Trajectory, *, indent: int | None = None) -> bytes:
    """Serialize one already-valid Harbor trajectory as UTF-8 JSON."""

    return trajectory.model_dump_json(exclude_none=True, indent=indent).encode("utf-8")


__all__ = [
    "CURRENT_ATIF_VERSION",
    "HARBOR_VERSION",
    "SUPPORTED_ATIF_VERSIONS",
    "Agent",
    "AtifContractError",
    "AtifReadError",
    "ContentPart",
    "FinalMetrics",
    "ImageSource",
    "InvalidAtifTrajectoryError",
    "Metrics",
    "Observation",
    "ObservationResult",
    "Step",
    "SubagentTrajectoryRef",
    "ToolCall",
    "Trajectory",
    "dump_trajectory",
    "load_trajectory",
    "read_trajectory",
]
