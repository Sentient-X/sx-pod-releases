"""Array shapes owned by the native-time episode and window contracts."""

import numpy as np
from jaxtyping import Bool, Float, Float32, UInt8
from numpy.typing import NDArray

type StateVector = Float[NDArray[np.floating], "state"]
"""One native embodiment-state sample."""

type RgbImage = UInt8[NDArray[np.uint8], "height width 3"]
"""One calibrated RGB sample."""

type TimeMajorStates = Float32[NDArray[np.float32], "history state"]
"""Action-aligned observation history."""

type Float32State = Float32[NDArray[np.float32], "state"]
"""One normalized state at a training boundary."""

type TimeMajorImages = UInt8[NDArray[np.uint8], "history height width 3"]
"""Action-aligned image history."""

type ActionWindow = Float32[NDArray[np.float32], "horizon action"]
"""The action horizon for one training window."""

type TerminationFlags = Bool[NDArray[np.bool_], "horizon"]
"""Termination or truncation flags sharing the action horizon."""
