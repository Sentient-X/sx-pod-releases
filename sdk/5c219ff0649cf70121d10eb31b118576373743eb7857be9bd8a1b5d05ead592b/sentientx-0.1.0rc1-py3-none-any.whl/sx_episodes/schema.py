"""The one entity-path vocabulary for native-time episode RRDs."""

from sx_contracts import RepresentationFormat, SchemaId, SchemaRevision, ValidatorId

SCHEMA_NAME = SchemaId("sx.episode/v8")
LAYER_SCHEMA_NAME = "sx.episode.layer/v1"
APPLICATION_ID = "sx-episode"
STEP_TIMELINE = "step"
TIME_TIMELINE = "episode_time"

PATH_STATE = "state"
PATH_ACTION = "action/executed"
PATH_ACTION_FACTS = "action/facts"
PATH_ACTION_SOURCE = "action/source"
PATH_REWARD = "reward"
PATH_TERMINAL = "episode/terminal"
PATH_META = "episode/meta"
PATH_LAYER_META = "layer/meta"
PATH_WORLD = "world"
PATH_TF = "tf"
PATH_EVENTS = "events"
# Preserved byte-for-byte from the existing v7 contract; this is the episode's authoritative
# embedded asset, not a second recording envelope.
PATH_URDF = "recording/embodiment/urdf"
PATH_CAMERAS = "sensors/camera"
WORLD_FRAME = "world"

# The agent layer's paths and timelines. Additive to the one-recording episode experience:
# `sx_episodes.atif` projects and persists them, but the vocabulary is the episode's, so the
# whole family is declared here rather than half here and half beside the projector.
AGENT_SCHEMA_NAME = "sx.episode.agent/v1"
PATH_AGENT = "agent"
PATH_AGENT_META = f"{PATH_AGENT}/meta"
PATH_AGENT_ATIF = f"{PATH_AGENT}/atif"
PATH_AGENT_MESSAGES = f"{PATH_AGENT}/messages"
PATH_AGENT_ACTIVITY = f"{PATH_AGENT}/activity"
PATH_AGENT_TOOL_CALLS = f"{PATH_AGENT}/tool_calls"
PATH_AGENT_OBSERVATIONS = f"{PATH_AGENT}/observations"
PATH_AGENT_ALIGNMENT = f"{PATH_AGENT}/alignment"
PATH_AGENT_CAPABILITIES = f"{PATH_AGENT}/capabilities"
PATH_AGENT_METRICS = f"{PATH_AGENT}/metrics"

AGENT_STEP_TIMELINE = "agent_step"
AGENT_TOOL_TIMELINE = "agent_tool_call"
AGENT_OBSERVATION_TIMELINE = "agent_observation"
WALL_TIMELINE = "wall_time"
CONTROL_TIMELINE = "control_step"


def state_path(name: str) -> str:
    return f"{PATH_STATE}/{name}"


def camera_path(name: str) -> str:
    return f"{camera_frame_path(name)}/rgb"


def camera_name_from_path(entity: str) -> str | None:
    """`camera_path`'s inverse, spelled once beside it.

    None for any entity that is not a camera rgb path — legitimate for callers
    walking mixed recordings. Consumers include the semantic index's frame walk,
    which used to hand-spell this grammar in four places (2026-08 audit).
    """
    prefix = f"{PATH_CAMERAS}/"
    suffix = "/rgb"
    if entity.startswith(prefix) and entity.endswith(suffix):
        return entity[len(prefix) : -len(suffix)]
    return None


def camera_frame_path(name: str) -> str:
    return f"{PATH_CAMERAS}/{name}"


def calibration_path(name: str) -> str:
    return f"{camera_frame_path(name)}/calibration"


def tf_path(frame: str) -> str:
    return f"{PATH_TF}/{frame}"


EPISODE_VALIDATOR = ValidatorId("sx.episode.conformance/v1")
"""The procedure that proves an RRD really is a complete v8 episode.

It is `read_episode`, which parses every required fact and refuses rather than
defaulting. Naming it here is what lets an admission path check that the validator
it actually ran is the one the pinned revision asks for — if this file ever starts
proving conformance a different way, that name changes and ingest says so instead
of quietly continuing to run the old check.
"""


def episode_schema_revision() -> SchemaRevision:
    """This package's own statement of what `sx.episode/v8` is.

    The catalog governs episodes; it does not define them. So the contract it stores
    and enforces is emitted from here, beside the constants that are the contract —
    a copy in the catalog's SQL or models would be a second source that drifts the
    first time either moves.

    The document is the vocabulary, split by whether a path is fixed or one of a
    family: `state/<joint>`, `sensors/camera/<name>/...` and `tf/<frame>` are named
    by the embodiment, so a contract can pin the prefix and nothing below it.
    """
    return SchemaRevision(
        id=SCHEMA_NAME,
        representation=RepresentationFormat.RRD,
        validator=EPISODE_VALIDATOR,
        document={
            "application_id": APPLICATION_ID,
            "timelines": (STEP_TIMELINE, TIME_TIMELINE),
            "world_frame": WORLD_FRAME,
            "entities": tuple(
                sorted(
                    (
                        PATH_ACTION,
                        PATH_ACTION_FACTS,
                        PATH_ACTION_SOURCE,
                        PATH_EVENTS,
                        PATH_META,
                        PATH_REWARD,
                        PATH_TERMINAL,
                        PATH_URDF,
                        PATH_WORLD,
                    )
                )
            ),
            "entity_prefixes": tuple(sorted((PATH_CAMERAS, PATH_STATE, PATH_TF))),
        },
    )
