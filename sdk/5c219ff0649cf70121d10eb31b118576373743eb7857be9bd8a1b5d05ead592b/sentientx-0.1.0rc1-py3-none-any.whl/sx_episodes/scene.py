"""Rerun scene emission for complete episodes and local static bench views."""

import re
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np
import rerun as rr
import rerun.urdf as rr_urdf
from numpy.typing import NDArray
from sx_embodiments import ChannelKind, Embodiment

from sx_episodes.calibration import CameraCalibration, validate_episode_physical_facts
from sx_episodes.schema import (
    PATH_EVENTS,
    PATH_URDF,
    PATH_WORLD,
    WORLD_FRAME,
    calibration_path,
    camera_frame_path,
    camera_path,
    tf_path,
)

if TYPE_CHECKING:
    from sx_episodes.records import EpisodeFacts

_JOINT_KINDS = frozenset({ChannelKind.ARM_JOINT, ChannelKind.BODY_JOINT, ChannelKind.GRIPPER})
_PACKAGE_URI = re.compile(r"package://(?P<package>[^/\"']+)/(?P<member>[^\"']+)")


class RobotMountError(ValueError):
    """A robot mount pose cannot be resolved against the embodiment's URDF."""


def _urdf_root_link(urdf_bytes: bytes) -> str:
    """The URDF's root link: the one link that is no joint's child."""
    import xml.etree.ElementTree as ET

    tree = ET.fromstring(urdf_bytes)
    links = [link.attrib["name"] for link in tree.findall("link")]
    children = {
        child.attrib["link"] for joint in tree.findall("joint") for child in joint.findall("child")
    }
    roots = [name for name in links if name not in children]
    if len(roots) != 1:
        raise RobotMountError(f"URDF must have exactly one root link, found {roots}")
    return roots[0]


def log_robot_mount(
    rec: rr.RecordingStream | None,
    embodiment: Embodiment,
    pose7: NDArray[np.floating],
) -> None:
    """Place the episode URDF's root at the robot's mount pose in the world frame.

    The default convention is base == world (the scene emission anchors the root at
    identity); a producer whose world frame is a scene of its own — a sim world, a
    room-calibrated cell — logs the measured mount once, statically, and this later
    static write is the one the viewer keeps. ``pose7`` is position + wxyz quaternion.
    """
    mount = np.asarray(pose7, dtype=np.float64)
    if mount.shape != (7,):
        raise RobotMountError(f"mount pose must be pos3 + wxyz quat, got shape {mount.shape}")
    w, x, y, z = (float(value) for value in mount[3:7])
    root = _urdf_root_link(embodiment.urdf_bytes)
    rr.log(
        tf_path(root),
        rr.Transform3D(
            translation=mount[:3],
            quaternion=rr.Quaternion(xyzw=[x, y, z, w]),
            parent_frame=WORLD_FRAME,
            child_frame=root,
        ),
        static=True,
        recording=rec,
    )


def urdf_driven_joints(embodiment: Embodiment) -> frozenset[str]:
    """The joints the episode writer animates: the embodiment's joint-kind state coordinates.

    Producers that also draw the world some other way (a sim's primitive replica) use this
    set to leave the robot to the URDF rather than drawing it twice.
    """
    return frozenset(
        coordinate.joint_name
        for coordinate in embodiment.state.coordinates
        if coordinate.kind in _JOINT_KINDS
    )


@dataclass(frozen=True, slots=True)
class _DrivenJoint:
    joint: rr_urdf.UrdfJoint
    column: int
    followers: tuple[tuple[rr_urdf.UrdfJoint, float, float], ...]


@dataclass(frozen=True, slots=True)
class EpisodeScene:
    """The logged scene's animation handle; empty ``driven`` means a static robot."""

    driven: tuple[_DrivenJoint, ...]


def log_episode_scene(
    rec: rr.RecordingStream | None,
    facts: "EpisodeFacts",
) -> EpisodeScene:
    """Emit the scene directly from one complete episode fact value."""
    return _log_scene(rec, facts.embodiment, facts.cameras)


def log_static_scene(
    rec: rr.RecordingStream | None,
    embodiment: Embodiment,
    cameras: tuple[CameraCalibration, ...],
) -> EpisodeScene:
    """Emit body and calibrated cameras for an explicitly non-governed bench view."""
    return _log_scene(rec, embodiment, cameras)


def _log_scene(
    rec: rr.RecordingStream | None,
    embodiment: Embodiment,
    cameras: tuple[CameraCalibration, ...],
) -> EpisodeScene:
    validate_episode_physical_facts(embodiment, cameras, embodiment.urdf_bytes)
    rr.log(
        PATH_URDF,
        rr.AnyValues(xml=embodiment.urdf_bytes.decode("utf-8")),
        static=True,
        recording=rec,
    )
    for camera in cameras:
        matrix = np.asarray(camera.parent_from_camera, dtype=np.float64).reshape(4, 4)
        path = camera_frame_path(camera.name)
        rr.log(path, rr.CoordinateFrame(camera.name), static=True, recording=rec)
        # The image stream is a child entity; binding it to the camera frame is what puts
        # the recorded feed on the pinhole frustum in frame-graph 3D views.
        rr.log(
            camera_path(camera.name),
            rr.CoordinateFrame(camera.name),
            static=True,
            recording=rec,
        )
        rr.log(
            path,
            rr.Pinhole(
                image_from_camera=np.asarray(camera.image_from_camera).reshape(3, 3),
                resolution=[camera.width, camera.height],
                child_frame=camera.name,
                parent_frame=camera.parent_frame,
            ),
            static=True,
            recording=rec,
        )
        rr.log(
            path,
            rr.Transform3D(
                translation=matrix[:3, 3],
                mat3x3=matrix[:3, :3],
                # The calibration stores parent_from_camera — the camera's pose IN the
                # parent frame — which is rerun's ParentFromChild. ChildFromParent would
                # render the frustum at the inverse pose, mirrored through the origin.
                relation=rr.TransformRelation.ParentFromChild,
                child_frame=camera.name,
                parent_frame=camera.parent_frame,
            ),
            static=True,
            recording=rec,
        )
        rr.log(
            calibration_path(camera.name),
            rr.AnyValues(json=camera.canonical_json(), sha256=camera.digest()),
            static=True,
            recording=rec,
        )
    return _log_world_scene(rec, embodiment)


def _resolve_package_uris(urdf_path: Path) -> str | None:
    text = urdf_path.read_text()
    if "package://" not in text:
        return None

    def rewrite(match: re.Match[str]) -> str:
        candidate = urdf_path.parent / match.group("package") / match.group("member")
        return str(candidate) if candidate.is_file() else match.group(0)

    return _PACKAGE_URI.sub(rewrite, text)


def _log_world_scene(
    rec: rr.RecordingStream | None,
    embodiment: Embodiment,
) -> EpisodeScene:
    urdf_path = embodiment.urdf_path
    resolved_text = _resolve_package_uris(urdf_path)
    try:
        with tempfile.TemporaryDirectory() as scratch:
            load_path = urdf_path
            if resolved_text is not None:
                load_path = Path(scratch) / urdf_path.name
                load_path.write_text(resolved_text)
            tree = rr_urdf.UrdfTree.from_file_path(load_path, PATH_WORLD)
            tree.log_urdf_to_recording(rec)
    except RuntimeError as error:
        rr.log(
            PATH_EVENTS,
            rr.TextLog(f"scene: URDF geometry could not be embedded: {error}"),
            static=True,
            recording=rec,
        )
        return EpisodeScene(driven=())
    root_frame = tree.root_link().name
    if root_frame != WORLD_FRAME:
        rr.log(
            tf_path(root_frame),
            rr.Transform3D(
                translation=(0.0, 0.0, 0.0),
                parent_frame=WORLD_FRAME,
                child_frame=root_frame,
            ),
            static=True,
            recording=rec,
        )

    mimics_by_driver: dict[str, list[tuple[rr_urdf.UrdfJoint, float, float]]] = {}
    for joint in tree.joints():
        mimic = joint.mimic
        if mimic is not None:
            mimics_by_driver.setdefault(mimic.joint, []).append(
                (joint, mimic.multiplier, mimic.offset)
            )

    driven: list[_DrivenJoint] = []
    unresolved: list[str] = []
    # The episode state is always the embodiment's canonical ordered coordinates
    # (``ordered_state``), whatever the action interface commands — a Cartesian-target
    # episode still measures and records joint state, so its URDF animates identically.
    selected = tuple(enumerate(embodiment.state.coordinates))
    for column, coordinate in selected:
        if coordinate.kind not in _JOINT_KINDS:
            continue
        joint = tree.get_joint_by_name(coordinate.joint_name)
        if joint is None:
            unresolved.append(f"{coordinate.instance}/{coordinate.joint_name}")
            continue
        driven.append(
            _DrivenJoint(
                joint=joint,
                column=column,
                followers=tuple(mimics_by_driver.get(coordinate.joint_name, ())),
            )
        )
    if unresolved:
        rr.log(
            PATH_EVENTS,
            rr.TextLog(
                f"scene: state coordinates without a URDF joint (not animated): {unresolved}"
            ),
            static=True,
            recording=rec,
        )
    return EpisodeScene(driven=tuple(driven))


def log_joint_state(
    rec: rr.RecordingStream | None,
    scene: EpisodeScene,
    values: NDArray[np.floating],
) -> None:
    """Animate the episode URDF from its ordered native state values."""
    for driven in scene.driven:
        value = float(values[driven.column])
        rr.log(
            tf_path(driven.joint.child_link),
            driven.joint.compute_transform(value, clamp=True),
            recording=rec,
        )
        for follower, multiplier, offset in driven.followers:
            rr.log(
                tf_path(follower.child_link),
                follower.compute_transform(multiplier * value + offset, clamp=True),
                recording=rec,
            )
