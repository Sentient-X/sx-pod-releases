"""The viewer layout embedded in every episode RRD."""

from collections.abc import Sequence
from functools import lru_cache

import rerun as rr
import rerun.blueprint as rrb
import rerun_bindings
from rerun.blueprint.api import create_in_memory_blueprint

from sx_episodes.schema import (
    APPLICATION_ID,
    PATH_ACTION,
    PATH_ACTION_SOURCE,
    PATH_AGENT,
    PATH_CAMERAS,
    PATH_EVENTS,
    PATH_REWARD,
    PATH_STATE,
    PATH_TERMINAL,
    PATH_TF,
    PATH_WORLD,
    camera_path,
)


def send_episode_blueprint(rec: rr.RecordingStream, camera_names: Sequence[str]) -> None:
    """Write the episode layout into one recording, without minting it per episode.

    :meth:`rerun.RecordingStream.send_blueprint` builds the blueprint's own recording on
    every call and never releases it: each call costs two OS threads and their arenas
    for the life of the process, which is unbounded in the number of episodes a bulk
    producer writes. The layout depends only on the camera slots, so the built storage
    is minted once per slot set and sent as often as there are episodes — the same
    bytes reach the file either way.
    """
    rerun_bindings.send_blueprint(
        _blueprint_storage(tuple(camera_names)), True, True, rec.to_native()
    )


@lru_cache(maxsize=8)
def _blueprint_storage(camera_names: tuple[str, ...]) -> rerun_bindings.PyMemorySinkStorage:
    return create_in_memory_blueprint(
        application_id=APPLICATION_ID, blueprint=episode_blueprint(camera_names)
    ).storage


def episode_blueprint(camera_names: Sequence[str]) -> rrb.Blueprint:
    # The 3D view's contract: the animated URDF plus the calibrated camera frusta (their
    # feeds project through recorded intrinsics/extrinsics) — nothing else. Producer-side
    # projections (sim replicas, ground-truth traces) live outside `world/` and stay out
    # of this view; a viewer can add those streams when privileged state is wanted.
    world = rrb.Spatial3DView(
        name="Robot & world",
        origin=f"/{PATH_WORLD}",
        contents=[
            f"+ /{PATH_WORLD}/**",
            f"+ /{PATH_TF}/**",
            f"+ /{PATH_CAMERAS}/**",
        ],
    )
    cameras = rrb.Tabs(
        *(rrb.Spatial2DView(name=name, origin=f"/{camera_path(name)}") for name in camera_names)
    )
    series = rrb.Tabs(
        rrb.TimeSeriesView(name="Reward", origin=f"/{PATH_REWARD}"),
        rrb.TimeSeriesView(name="Named state", origin=f"/{PATH_STATE}"),
        rrb.TimeSeriesView(name="Action", origin=f"/{PATH_ACTION}"),
    )
    events = rrb.Tabs(
        rrb.TextLogView(name="Events", origin=f"/{PATH_EVENTS}"),
        rrb.TextLogView(name="Action source", origin=f"/{PATH_ACTION_SOURCE}"),
        rrb.TextLogView(name="Terminal & receipts", origin=f"/{PATH_TERMINAL}"),
        rrb.TextLogView(name="Agent trace", origin=f"/{PATH_AGENT}"),
        rrb.StateTimelineView(name="Agent activity", origin=f"/{PATH_AGENT}"),
    )
    return rrb.Blueprint(
        rrb.Vertical(
            rrb.Horizontal(cameras, world, column_shares=[1, 1]),
            rrb.Horizontal(series, events, column_shares=[2, 1]),
            row_shares=[3, 2],
        ),
        rrb.TimePanel(
            timeline="episode_time",
            play_state=rrb.components.PlayState.Following,
        ),
        collapse_panels=True,
    )
