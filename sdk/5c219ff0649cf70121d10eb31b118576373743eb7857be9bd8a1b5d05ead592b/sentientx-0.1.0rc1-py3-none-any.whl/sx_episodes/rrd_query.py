"""Small typed read helpers shared by episode bases and additive RRD layers."""

from collections.abc import Sequence
from pathlib import Path
from typing import cast

import rerun.experimental as rr_experimental
from rerun.experimental import Chunk

type RrdSource = Path | Sequence[Chunk]


def chunks(source: RrdSource) -> list[Chunk]:
    """Materialize a file once, or reuse chunks already loaded by a richer codec."""
    if isinstance(source, Path):
        return rr_experimental.RrdReader(str(source)).store().stream().to_chunks()
    return list(source)


def static_value(source: RrdSource, entity_path: str, suffix: str) -> str | None:
    """Read one static scalar-like value from a Rerun component column."""
    for chunk in chunks(source):
        if str(chunk.entity_path).lstrip("/") != entity_path:
            continue
        batch = chunk.to_record_batch()
        for name in batch.schema.names:
            if not name.endswith(suffix):
                continue
            values = cast("list[object | None]", batch.column(name).to_pylist())
            if values and values[0] is not None:
                value: object = values[0]
                if isinstance(value, list):
                    if not value:
                        continue
                    value = cast("list[object]", value)[0]
                return str(value)
    return None
