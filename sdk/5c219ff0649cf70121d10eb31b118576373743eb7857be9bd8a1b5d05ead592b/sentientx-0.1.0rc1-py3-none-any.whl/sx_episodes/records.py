"""The complete native-time episode value persisted as one immutable RRD."""

import math
import re
from collections import defaultdict
from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum

import numpy as np
from numpy.typing import NDArray
from sx_actions import (
    Action,
    ActionEmbodimentMismatchError,
    ActionInterface,
    validate_for_embodiment,
)
from sx_contracts import (
    ActionSource,
    Ended,
    EpisodeEnd,
    EpisodeId,
    EpisodeUse,
    RolloutId,
    Sha256Digest,
    StepProgress,
    TaskContractRef,
    TaskVerdict,
    TerminationReason,
)
from sx_embodiments import Embodiment, EmbodimentId

from sx_episodes.calibration import (
    CameraCalibration,
    EpisodePhysicalFactsError,
    validate_episode_physical_facts,
)
from sx_episodes.shapes import Float32State, RgbImage, StateVector


class EpisodeError(ValueError):
    """An episode is incomplete or internally inconsistent."""


class EpisodeActionError(EpisodeError):
    """An executed action disagrees with the episode's exact interface or proof."""


class EpisodeObservationError(EpisodeError):
    """A state or image sample disagrees with the episode's calibrated sensors."""


class EpisodeClockError(EpisodeError):
    """A native-time stream is not finite, non-negative, and strictly monotonic."""


class EpisodeRewardError(EpisodeError):
    """A reward sample does not identify an executed step."""


class LineageKind(StrEnum):
    """The admitted immutable parents of a produced episode."""

    RAW_CAPTURE = "raw_capture"
    FUSED_MCAP = "fused_mcap"
    SOURCE_EPISODE = "source_episode"
    AUTONOMY_CHECKPOINT = "autonomy_checkpoint"
    ROBOT_APPLICATION = "robot_application"
    APPLICATION_DEPLOYMENT = "application_deployment"
    WORLD_SEED = "world_seed"


@dataclass(frozen=True, slots=True)
class EpisodeProducer:
    """The exact code producer that closed an episode."""

    name: str
    version: str

    def __post_init__(self) -> None:
        if not self.name.strip() or not self.version.strip():
            raise EpisodeError("episode producer name and version must be non-empty")


@dataclass(frozen=True, slots=True)
class EpisodeParent:
    """One content-addressed immutable lineage parent."""

    kind: LineageKind
    uri: str
    sha256: Sha256Digest

    def __post_init__(self) -> None:
        if not self.uri.strip():
            raise EpisodeError("episode lineage URI must be non-empty")
        if re.fullmatch(r"[a-f0-9]{64}", self.sha256) is None:
            raise EpisodeError("episode lineage SHA-256 must be 64 lowercase hex characters")


@dataclass(frozen=True, slots=True)
class EpisodeFacts:
    """Static facts that apply to every native-time stream in one episode."""

    rollout_id: RolloutId
    episode_id: EpisodeId
    task: TaskContractRef
    embodiment: Embodiment
    action_interface: ActionInterface
    cameras: tuple[CameraCalibration, ...]
    producer: EpisodeProducer
    use: EpisodeUse
    instruction: str
    lineage: tuple[EpisodeParent, ...] = ()

    def __post_init__(self) -> None:
        if not self.instruction.strip():
            raise EpisodeError("episode instruction must be non-empty")
        if len({(parent.kind, parent.uri, parent.sha256) for parent in self.lineage}) != len(
            self.lineage
        ):
            raise EpisodeError("episode lineage repeats a parent")
        try:
            validate_for_embodiment(self.action_interface, self.embodiment)
            validate_episode_physical_facts(
                self.embodiment, self.cameras, self.embodiment.urdf_bytes
            )
        except (ActionEmbodimentMismatchError, EpisodePhysicalFactsError) as exc:
            raise EpisodeError(str(exc)) from exc

    @property
    def recording_id(self) -> str:
        return f"{self.rollout_id}/{self.episode_id}"


@dataclass(frozen=True, slots=True, eq=False)
class StateSample:
    """One embodiment-native state vector at its acquisition time."""

    at: float
    values: StateVector


@dataclass(frozen=True, slots=True, eq=False)
class ImageSample:
    """One calibrated RGB image at its sensor acquisition time."""

    camera: str
    at: float
    image: RgbImage


@dataclass(frozen=True, slots=True)
class FleetReceipt:
    """Fleet authority and receipt facts for an applied robot command."""

    lease_id: str
    receipt_id: str
    sha256: Sha256Digest

    def __post_init__(self) -> None:
        if not self.lease_id.strip() or not self.receipt_id.strip():
            raise EpisodeActionError("Fleet lease and receipt identities must be non-empty")
        if re.fullmatch(r"[a-f0-9]{64}", self.sha256) is None:
            raise EpisodeActionError("Fleet receipt SHA-256 must be 64 lowercase hex characters")


@dataclass(frozen=True, slots=True, eq=False)
class RobotExecutionProof:
    """Proof from the robot execution boundary that an exact action was applied.

    ``receipts`` is empty for robot execution outside Fleet. Once Fleet owns the
    control lease, every receipt for the applied action travels here unchanged.
    """

    execution_id: str
    applied_at: float
    executed_action: Action
    receipts: tuple[FleetReceipt, ...] = ()

    def __post_init__(self) -> None:
        if not self.execution_id.strip():
            raise EpisodeActionError("robot execution identity must be non-empty")
        if len({receipt.receipt_id for receipt in self.receipts}) != len(self.receipts):
            raise EpisodeActionError("robot execution proof repeats a Fleet receipt")


@dataclass(frozen=True, slots=True)
class SimulatorExecutionProof:
    """The environment step result that proves a simulator action executed."""

    environment_step: int
    simulation_time: float
    reward: float
    progress: StepProgress

    def __post_init__(self) -> None:
        if self.environment_step < 0:
            raise EpisodeActionError("simulator environment step must be non-negative")
        if not math.isfinite(self.reward):
            raise EpisodeActionError("simulator step reward must be finite")


type ExecutionProof = RobotExecutionProof | SimulatorExecutionProof


def same_execution_proof(left: ExecutionProof, right: ExecutionProof) -> bool:
    """Exact receipt equality for transport replay and immutable episode publication."""
    if isinstance(left, RobotExecutionProof) and isinstance(right, RobotExecutionProof):
        return (
            left.execution_id == right.execution_id
            and left.applied_at == right.applied_at
            and left.receipts == right.receipts
            and left.executed_action.interface == right.executed_action.interface
            and np.array_equal(left.executed_action.values, right.executed_action.values)
        )
    return (
        isinstance(left, SimulatorExecutionProof)
        and isinstance(right, SimulatorExecutionProof)
        and left == right
    )


@dataclass(frozen=True, slots=True, eq=False)
class ExecutedAction:
    """One action that actually ran, with observation/application clocks and proof."""

    step: int
    observed_at: float
    applied_at: float
    action: Action
    source: ActionSource
    proof: ExecutionProof


class EpisodeExecution:
    """The streaming fold over exact executed actions and one episode ending.

    This is the same lifecycle for simulator results and physical receipts. An execution
    owner still admits authority and performs the action; this boundary accepts only its
    returned proof. It retains one action, so a streaming recorder never retains images or
    grows with episode length. Batch Episode validation replays exactly the same fold.
    """

    def __init__(self, interface: ActionInterface) -> None:
        self.interface = interface
        self._last: ExecutedAction | None = None
        self._end: EpisodeEnd | None = None

    @property
    def steps(self) -> int:
        return 0 if self._last is None else self._last.step + 1

    @property
    def ended(self) -> bool:
        if self._end is not None:
            return True
        last = self._last
        return (
            last is not None
            and isinstance(last.proof, SimulatorExecutionProof)
            and isinstance(last.proof.progress, Ended)
        )

    @property
    def sealed(self) -> bool:
        return self._end is not None

    @property
    def last_action(self) -> ExecutedAction:
        if self._last is None:
            raise EpisodeActionError("an episode needs at least one executed action")
        return self._last

    @property
    def end(self) -> EpisodeEnd:
        if self._end is None:
            raise EpisodeError("episode must be finished before it can close")
        return self._end

    def check_action(self, action: Action) -> None:
        """Refuse stale episode commands before an execution owner touches its actuator."""
        if self.ended:
            raise EpisodeActionError("a completed episode cannot have successor actions")
        if action.interface != self.interface:
            raise EpisodeActionError("bound interface does not match the episode")

    def commit(self, executed: ExecutedAction) -> None:
        """Accept one receipt atomically; rejection never advances the episode cursor."""
        if executed.step != self.steps:
            raise EpisodeActionError("executed action steps must be contiguous from zero")
        self.check_action(executed.action)
        times = (
            (executed.applied_at,)
            if self._last is None
            else (self._last.applied_at, executed.applied_at)
        )
        _validate_clock("action application", times)
        if not _valid_time(executed.observed_at) or executed.observed_at > executed.applied_at:
            raise EpisodeClockError(
                f"action {executed.step}: observed_at must be finite, non-negative, and "
                "not later than applied_at"
            )
        if self._last is not None and executed.observed_at < self._last.observed_at:
            raise EpisodeClockError("action observation times must be monotonic")
        _validate_execution_proof(executed)
        if (
            isinstance(executed.proof, SimulatorExecutionProof)
            and executed.proof.environment_step != executed.step
        ):
            raise EpisodeActionError(
                f"action {executed.step}: simulator proof identifies environment step "
                f"{executed.proof.environment_step}"
            )
        self._last = executed

    def finish(self, end: EpisodeEnd) -> None:
        """Seal exact terminal facts; replaying the same seal is idempotent."""
        if self._end is not None:
            if self._end == end:
                return
            raise EpisodeError("episode ending is already sealed with different terminal facts")
        last = self._last
        if (
            last is not None
            and isinstance(last.proof, SimulatorExecutionProof)
            and isinstance(last.proof.progress, Ended)
            and last.proof.progress.end != end
        ):
            raise EpisodeActionError("final simulator proof termination disagrees with episode end")
        self._end = end


@dataclass(frozen=True, slots=True)
class RewardSample:
    """One dense scalar reward observed for an executed step."""

    step: int
    at: float
    value: float


@dataclass(frozen=True, slots=True, eq=False)
class Episode:
    """One train-ready and directly viewable episode with truthful native cadences."""

    facts: EpisodeFacts
    states: tuple[StateSample, ...]
    images: tuple[ImageSample, ...]
    actions: tuple[ExecutedAction, ...]
    rewards: tuple[RewardSample, ...]
    end: EpisodeEnd

    def __post_init__(self) -> None:
        if not self.actions:
            raise EpisodeError("an episode needs at least one executed action")
        if not self.states:
            raise EpisodeObservationError("an episode needs at least one embodiment-state sample")
        self._validate_states()
        self._validate_images()
        self._validate_actions()
        self._validate_rewards()

    def _validate_states(self) -> None:
        _validate_clock("state", tuple(sample.at for sample in self.states))
        for index, sample in enumerate(self.states):
            validate_state_sample(self.embodiment, index, sample.values)

    def _validate_images(self) -> None:
        calibrated = calibrated_cameras(self.cameras)
        grouped: defaultdict[str, list[ImageSample]] = defaultdict(list)
        for sample in self.images:
            validate_image_sample(calibrated, sample.camera, sample.image)
            grouped[sample.camera].append(sample)
        for camera, samples in grouped.items():
            _validate_clock(f"camera {camera}", tuple(sample.at for sample in samples))

    def _validate_actions(self) -> None:
        execution = EpisodeExecution(self.action_interface)
        for action in self.actions:
            execution.commit(action)
        execution.finish(self.end)

    def _validate_rewards(self) -> None:
        seen: set[int] = set()
        for reward in self.rewards:
            if reward.step in seen:
                raise EpisodeRewardError(f"episode repeats reward step {reward.step}")
            seen.add(reward.step)
            if reward.step < 0 or reward.step >= len(self.actions):
                raise EpisodeRewardError(f"reward identifies unknown action step {reward.step}")
            if not _valid_time(reward.at) or not math.isfinite(reward.value):
                raise EpisodeRewardError(
                    "reward time must be finite and non-negative; reward value must be finite"
                )
            if reward.at < self.actions[reward.step].applied_at:
                raise EpisodeRewardError(
                    f"reward {reward.step} was observed before its action was applied"
                )
            proof = self.actions[reward.step].proof
            if isinstance(proof, SimulatorExecutionProof) and not math.isclose(
                reward.value, proof.reward, rel_tol=0.0, abs_tol=1e-6
            ):
                raise EpisodeRewardError(
                    f"reward {reward.step} disagrees with the simulator step result"
                )

    @property
    def rollout_id(self) -> RolloutId:
        return self.facts.rollout_id

    @property
    def episode_id(self) -> EpisodeId:
        return self.facts.episode_id

    @property
    def task(self) -> TaskContractRef:
        return self.facts.task

    @property
    def embodiment(self) -> Embodiment:
        return self.facts.embodiment

    @property
    def embodiment_id(self) -> EmbodimentId:
        return self.embodiment.id

    @property
    def action_interface(self) -> ActionInterface:
        return self.facts.action_interface

    @property
    def cameras(self) -> tuple[CameraCalibration, ...]:
        return self.facts.cameras

    @property
    def use(self) -> EpisodeUse:
        return self.facts.use

    @property
    def instruction(self) -> str:
        return self.facts.instruction

    @property
    def verdict(self) -> TaskVerdict:
        return self.end.verdict

    @property
    def succeeded(self) -> bool:
        return self.verdict is TaskVerdict.SATISFIED

    @property
    def reason(self) -> TerminationReason:
        return self.end.reason

    @property
    def num_steps(self) -> int:
        return len(self.actions)

    @property
    def state_names(self) -> tuple[str, ...]:
        return self.embodiment.state.names


def ordered_state(
    embodiment: Embodiment, state: Mapping[str, float] | NDArray[np.floating]
) -> Float32State:
    """Parse a named state mapping or exact native vector into Embodiment.state order."""
    names = embodiment.state.names
    if isinstance(state, np.ndarray):
        return np.asarray(state, dtype=np.float32)
    if set(state) != set(names):
        raise EpisodeObservationError(
            f"state names differ: missing={sorted(set(names) - set(state))}, "
            f"extra={sorted(set(state) - set(names))}"
        )
    return np.asarray([state[name] for name in names], dtype=np.float32)


def calibrated_cameras(cameras: tuple[CameraCalibration, ...]) -> Mapping[str, CameraCalibration]:
    """The episode's camera calibrations by slot name; an episode needs at least one."""
    if not cameras:
        raise EpisodeObservationError("an episode needs at least one calibrated camera")
    return {camera.name: camera for camera in cameras}


def validate_state_sample(embodiment: Embodiment, index: int, values: StateVector) -> None:
    """One state sample's shape, dtype, finiteness, and per-coordinate limits."""
    coordinates = embodiment.state.coordinates
    if (
        values.ndim != 1
        or values.shape != (len(coordinates),)
        or not np.issubdtype(values.dtype, np.floating)
        or not bool(np.isfinite(values).all())
    ):
        raise EpisodeObservationError(
            f"state sample {index} must be a finite {len(coordinates)}-value float vector "
            "in Embodiment.state order"
        )
    for coordinate, value in zip(coordinates, values, strict=True):
        if (
            coordinate.lower is not None
            and coordinate.upper is not None
            and (float(value) < coordinate.lower - 1e-6 or float(value) > coordinate.upper + 1e-6)
        ):
            name = f"{coordinate.instance}/{coordinate.joint_name}"
            raise EpisodeObservationError(
                f"state sample {index}: {name} value {float(value):g} is outside "
                f"[{coordinate.lower:g}, {coordinate.upper:g}]"
            )


def validate_image_sample(
    calibrated: Mapping[str, CameraCalibration], camera: str, image: RgbImage
) -> None:
    """One image sample's calibrated slot, shape, and dtype."""
    calibration = calibrated.get(camera)
    if calibration is None:
        raise EpisodeObservationError(f"image stream {camera!r} has no camera calibration")
    if image.dtype != np.uint8 or image.shape != (calibration.height, calibration.width, 3):
        raise EpisodeObservationError(
            f"{camera} image shape/dtype {image.shape}/{image.dtype} "
            f"does not match {(calibration.height, calibration.width, 3)}/uint8"
        )


@dataclass(slots=True)
class NativeClock:
    """One native-time stream, advanced sample by sample.

    The same law :class:`Episode` applies to a complete stream, in the shape a recorder
    that never holds the stream can enforce: finite, non-negative, strictly increasing.
    """

    label: str
    previous: float = -math.inf

    def advance(self, at: float) -> float:
        if not _valid_time(at) or at <= self.previous:
            raise EpisodeClockError(
                f"{self.label} times must be finite, non-negative, and strictly increasing"
            )
        self.previous = at
        return at


def _validate_execution_proof(executed: ExecutedAction) -> None:
    proof = executed.proof
    if isinstance(proof, RobotExecutionProof):
        if not _valid_time(proof.applied_at) or not math.isclose(
            proof.applied_at, executed.applied_at, rel_tol=0.0, abs_tol=1e-9
        ):
            raise EpisodeActionError(f"action {executed.step}: robot proof applied time disagrees")
        if not np.array_equal(proof.executed_action.values, executed.action.values):
            raise EpisodeActionError(
                f"action {executed.step}: robot receipt action disagrees with recorded action"
            )
        if proof.executed_action.interface != executed.action.interface:
            raise EpisodeActionError(
                f"action {executed.step}: robot receipt interface disagrees with recorded action"
            )
        return
    if not _valid_time(proof.simulation_time):
        raise EpisodeActionError(
            f"action {executed.step}: simulator time must be finite and non-negative"
        )


def _validate_clock(label: str, times: tuple[float, ...]) -> None:
    clock = NativeClock(label)
    for at in times:
        clock.advance(at)


def _valid_time(value: float) -> bool:
    return math.isfinite(value) and value >= 0.0
