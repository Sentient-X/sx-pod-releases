"""Action-aligned training windows derived from native-time episode streams."""

import math
from bisect import bisect_right
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from sx_contracts import ActionSource

from sx_episodes.records import (
    Episode,
    ExecutedAction,
    ImageSample,
    RewardSample,
    StateSample,
)
from sx_episodes.rrd import read_episode
from sx_episodes.shapes import (
    ActionWindow,
    Float32State,
    RgbImage,
    TerminationFlags,
    TimeMajorImages,
    TimeMajorStates,
)


class EpisodeWindowError(ValueError):
    """A requested training projection cannot be derived truthfully."""


class StaleModalityError(EpisodeWindowError):
    """A required native-time sample is missing or outside its explicit age limit."""


@dataclass(frozen=True, slots=True)
class WindowSpec:
    """The history, horizon, source filter, and per-modality freshness contract."""

    history: int
    horizon: int
    state_max_age_s: float
    camera_max_age_s: dict[str, float]
    sources: frozenset[ActionSource] = frozenset(ActionSource)

    def __post_init__(self) -> None:
        if self.history <= 0 or self.horizon <= 0:
            raise EpisodeWindowError("window history and horizon must be positive")
        if not math.isfinite(self.state_max_age_s) or self.state_max_age_s < 0.0:
            raise EpisodeWindowError("state staleness must be finite and non-negative")
        if not self.camera_max_age_s:
            raise EpisodeWindowError("a training window needs at least one camera")
        if any(
            not name.strip() or not math.isfinite(limit) or limit < 0.0
            for name, limit in self.camera_max_age_s.items()
        ):
            raise EpisodeWindowError(
                "camera names must be non-empty and staleness limits finite and non-negative"
            )
        if not self.sources:
            raise EpisodeWindowError("a training window source filter must not be empty")


@dataclass(frozen=True, slots=True, eq=False)
class EpisodeWindow:
    """One faithful action-aligned projection; no frame is repeated to fill a gap."""

    episode_id: str
    steps: tuple[int, ...]
    observation_steps: tuple[int, ...]
    states: TimeMajorStates
    next_state: Float32State
    images: dict[str, TimeMajorImages]
    next_images: dict[str, RgbImage]
    actions: ActionWindow
    sources: tuple[ActionSource, ...]
    rewards: tuple[RewardSample, ...]
    terminated: TerminationFlags
    truncated: TerminationFlags
    execution: tuple[ExecutedAction, ...]


def episode_windows(path_or_episode: Path | Episode, spec: WindowSpec) -> tuple[EpisodeWindow, ...]:
    """Derive action windows with latest-at sampling and fail-closed staleness."""
    episode = (
        read_episode(path_or_episode) if isinstance(path_or_episode, Path) else path_or_episode
    )
    calibrated = {camera.name for camera in episode.cameras}
    requested = set(spec.camera_max_age_s)
    if not requested <= calibrated:
        raise EpisodeWindowError(
            f"window requests uncalibrated cameras {sorted(requested - calibrated)}"
        )

    state_times = [sample.at for sample in episode.states]
    images_by_camera: defaultdict[str, list[ImageSample]] = defaultdict(list)
    for sample in episode.images:
        images_by_camera[sample.camera].append(sample)
    image_times = {
        camera: [sample.at for sample in images_by_camera[camera]] for camera in requested
    }
    rewards_by_step = {reward.step: reward for reward in episode.rewards}

    windows: list[EpisodeWindow] = []
    first_anchor = spec.history - 1
    last_anchor = episode.num_steps - spec.horizon
    for anchor in range(first_anchor, last_anchor + 1):
        horizon_actions = episode.actions[anchor : anchor + spec.horizon]
        if any(action.source not in spec.sources for action in horizon_actions):
            continue
        observation_actions = episode.actions[anchor - spec.history + 1 : anchor + 1]
        selected_states = tuple(
            _latest_state(
                episode.states,
                state_times,
                action.observed_at,
                spec.state_max_age_s,
                action.step,
            )
            for action in observation_actions
        )
        selected_images = {
            camera: tuple(
                _latest_image(
                    images_by_camera[camera],
                    image_times[camera],
                    action.observed_at,
                    spec.camera_max_age_s[camera],
                    action.step,
                )
                for action in observation_actions
            )
            for camera in requested
        }
        final_action = horizon_actions[-1]
        next_state = _next_state(
            episode.states,
            state_times,
            final_action.applied_at,
            spec.state_max_age_s,
            final_action.step,
        )
        next_images = {
            camera: _next_image(
                images_by_camera[camera],
                image_times[camera],
                final_action.applied_at,
                spec.camera_max_age_s[camera],
                final_action.step,
            )
            for camera in requested
        }
        steps = tuple(action.step for action in horizon_actions)
        terminated = np.zeros(spec.horizon, dtype=np.bool_)
        truncated = np.zeros(spec.horizon, dtype=np.bool_)
        if steps[-1] == episode.num_steps - 1:
            terminated[-1] = episode.end.terminated
            truncated[-1] = episode.end.truncated
        windows.append(
            EpisodeWindow(
                episode_id=str(episode.episode_id),
                steps=steps,
                observation_steps=tuple(action.step for action in observation_actions),
                states=np.stack([sample.values for sample in selected_states]).astype(np.float32),
                next_state=next_state.values.astype(np.float32),
                images={
                    camera: np.stack([sample.image for sample in samples]).astype(np.uint8)
                    for camera, samples in selected_images.items()
                },
                next_images={
                    camera: sample.image.astype(np.uint8) for camera, sample in next_images.items()
                },
                actions=np.stack([action.action.values for action in horizon_actions]).astype(
                    np.float32
                ),
                sources=tuple(action.source for action in horizon_actions),
                rewards=tuple(rewards_by_step[step] for step in steps if step in rewards_by_step),
                terminated=terminated,
                truncated=truncated,
                execution=tuple(horizon_actions),
            )
        )
    return tuple(windows)


def _latest_state(
    samples: tuple[StateSample, ...],
    times: list[float],
    at: float,
    limit: float,
    step: int,
) -> StateSample:
    index = bisect_right(times, at) - 1
    if index < 0 or at - times[index] > limit:
        raise StaleModalityError(f"step {step}: state is missing or stale at observed_at")
    return samples[index]


def _next_state(
    samples: tuple[StateSample, ...],
    times: list[float],
    after: float,
    limit: float,
    step: int,
) -> StateSample:
    index = bisect_right(times, after)
    if index >= len(samples) or times[index] - after > limit:
        raise StaleModalityError(f"step {step}: next state is missing or stale after applied_at")
    return samples[index]


def _latest_image(
    samples: list[ImageSample],
    times: list[float],
    at: float,
    limit: float,
    step: int,
) -> ImageSample:
    index = bisect_right(times, at) - 1
    if index < 0 or at - times[index] > limit:
        raise StaleModalityError(f"step {step}: camera is missing or stale at observed_at")
    return samples[index]


def _next_image(
    samples: list[ImageSample],
    times: list[float],
    after: float,
    limit: float,
    step: int,
) -> ImageSample:
    index = bisect_right(times, after)
    if index >= len(samples) or times[index] - after > limit:
        raise StaleModalityError(f"step {step}: next camera frame is missing or stale")
    return samples[index]
