"""Measured camera and physical-asset facts carried by every episode."""

import hashlib
import math
from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from typing import cast

import numpy as np
from sx_contracts import Sha256Digest
from sx_contracts.identity import JsonValue, content_digest
from sx_contracts.identity import canonical_json as canonical_document
from sx_embodiments import Embodiment


class EpisodePhysicalFactsError(ValueError):
    """An episode's measured camera or body facts are invalid."""


class MissingCameraCalibrationError(EpisodePhysicalFactsError):
    """An episode has no camera or an image stream lacks calibration."""


class InvalidCameraCalibrationError(EpisodePhysicalFactsError):
    """A measured camera intrinsic or extrinsic value is malformed."""


class EpisodeAssetMismatchError(EpisodePhysicalFactsError):
    """Embedded URDF bytes disagree with the episode embodiment."""


class DistortionModel(StrEnum):
    """Canonical camera-model spellings carried by native episode documents."""

    NONE = "none"
    PLUMB_BOB = "plumb_bob"
    RATIONAL_POLYNOMIAL = "rational_polynomial"
    KANNALA_BRANDT = "kannala_brandt"


class CameraOwner(StrEnum):
    EMBODIMENT = "embodiment"
    WORLD = "world"


@dataclass(frozen=True, slots=True)
class CameraCalibration:
    """Measured intrinsics and pose for one camera during an episode.

    The embodiment registry supplies camera identity, rate, sourced default optics, and its URDF
    optical-frame mount. This value pins the higher-authority serial-specific calibration that
    was measured for the recorded episode.
    """

    name: str
    width: int
    height: int
    image_from_camera: tuple[float, ...]
    distortion_model: DistortionModel
    distortion_coefficients: tuple[float, ...]
    parent_frame: str
    parent_from_camera: tuple[float, ...]
    owner: CameraOwner
    owner_ref: str
    serial: str | None = None

    def __post_init__(self) -> None:
        if not self.name.strip() or "/" in self.name:
            raise InvalidCameraCalibrationError("camera name must be a non-empty path segment")
        if self.width <= 0 or self.height <= 0:
            raise InvalidCameraCalibrationError(f"{self.name}: image dimensions must be positive")
        if len(self.image_from_camera) != 9 or not all(
            math.isfinite(value) for value in self.image_from_camera
        ):
            raise InvalidCameraCalibrationError(f"{self.name}: intrinsic matrix must be finite 3x3")
        if self.image_from_camera[0] <= 0.0 or self.image_from_camera[4] <= 0.0:
            raise InvalidCameraCalibrationError(f"{self.name}: focal lengths must be positive")
        if not all(math.isfinite(value) for value in self.distortion_coefficients):
            raise InvalidCameraCalibrationError(
                f"{self.name}: distortion coefficients must be finite"
            )
        if len(self.parent_from_camera) != 16 or not all(
            math.isfinite(value) for value in self.parent_from_camera
        ):
            raise InvalidCameraCalibrationError(f"{self.name}: extrinsic must be finite 4x4")
        matrix = np.asarray(self.parent_from_camera, dtype=np.float64).reshape(4, 4)
        if not np.allclose(matrix[3], [0.0, 0.0, 0.0, 1.0], atol=1e-6):
            raise InvalidCameraCalibrationError(f"{self.name}: extrinsic has invalid bottom row")
        rotation = matrix[:3, :3]
        if not np.allclose(rotation.T @ rotation, np.eye(3), atol=1e-5) or not np.isclose(
            np.linalg.det(rotation), 1.0, atol=1e-5
        ):
            raise InvalidCameraCalibrationError(f"{self.name}: extrinsic rotation is not rigid")
        if not self.parent_frame.strip() or not self.owner_ref.strip():
            raise InvalidCameraCalibrationError(
                f"{self.name}: parent_frame and owner_ref are mandatory"
            )

    @classmethod
    def pinhole(
        cls,
        name: str,
        width: int,
        height: int,
        *,
        focal_length: float,
        owner: CameraOwner,
        owner_ref: str,
        principal_point: tuple[float, float] | None = None,
        parent_frame: str = "world",
        serial: str | None = None,
    ) -> "CameraCalibration":
        """An undistorted pinhole camera sitting at the origin of its parent frame.

        The common case that had no constructor: a square-pixel camera with no lens
        distortion and identity extrinsics — what a simulated camera is, and what nine
        separate test fixtures across seven repositories were each spelling out as a
        nine-element intrinsic matrix and a sixteen-element identity pose.

        ``principal_point`` defaults to the image centre. It is explicit rather than
        derived-only because the two conventions in use here disagree by half a pixel,
        and silently picking one would change measured calibrations.
        """
        centre_x, centre_y = principal_point or (width / 2, height / 2)
        return cls(
            name=name,
            width=width,
            height=height,
            image_from_camera=(
                focal_length,
                0.0,
                centre_x,
                0.0,
                focal_length,
                centre_y,
                0.0,
                0.0,
                1.0,
            ),
            distortion_model=DistortionModel.NONE,
            distortion_coefficients=(),
            parent_frame=parent_frame,
            parent_from_camera=(
                1.0,
                0.0,
                0.0,
                0.0,
                0.0,
                1.0,
                0.0,
                0.0,
                0.0,
                0.0,
                1.0,
                0.0,
                0.0,
                0.0,
                0.0,
                1.0,
            ),
            owner=owner,
            owner_ref=owner_ref,
            serial=serial,
        )

    def to_dict(self) -> dict[str, JsonValue]:
        return {
            "name": self.name,
            "width": self.width,
            "height": self.height,
            "image_from_camera": list(self.image_from_camera),
            "distortion_model": self.distortion_model.value,
            "distortion_coefficients": list(self.distortion_coefficients),
            "parent_frame": self.parent_frame,
            "parent_from_camera": list(self.parent_from_camera),
            "owner": self.owner.value,
            "owner_ref": self.owner_ref,
            "serial": self.serial,
        }

    def canonical_json(self) -> str:
        return canonical_document(self.to_dict())

    def digest(self) -> Sha256Digest:
        return content_digest(self.to_dict())

    @classmethod
    def from_dict(cls, document: Mapping[str, object]) -> "CameraCalibration":
        return cls(
            name=str(document["name"]),
            width=int(cast("int", document["width"])),
            height=int(cast("int", document["height"])),
            image_from_camera=tuple(
                float(value) for value in cast("list[float]", document["image_from_camera"])
            ),
            distortion_model=DistortionModel(str(document["distortion_model"])),
            distortion_coefficients=tuple(
                float(value) for value in cast("list[float]", document["distortion_coefficients"])
            ),
            parent_frame=str(document["parent_frame"]),
            parent_from_camera=tuple(
                float(value) for value in cast("list[float]", document["parent_from_camera"])
            ),
            owner=CameraOwner(str(document["owner"])),
            owner_ref=str(document["owner_ref"]),
            serial=str(document["serial"]) if document.get("serial") is not None else None,
        )


def validate_episode_physical_facts(
    embodiment: Embodiment,
    cameras: tuple[CameraCalibration, ...],
    urdf: bytes,
) -> None:
    """Prove exact body assets and complete, unique measured camera calibration."""
    if hashlib.sha256(urdf).hexdigest() != embodiment.urdf.sha256:
        raise EpisodeAssetMismatchError("embedded URDF digest does not match the embodiment")
    if not urdf.lstrip().startswith((b"<?xml", b"<robot")):
        raise EpisodeAssetMismatchError("embedded URDF is not an XML robot document")
    if not cameras:
        raise MissingCameraCalibrationError("every episode needs at least one camera")
    names = [camera.name for camera in cameras]
    if len(set(names)) != len(names):
        raise MissingCameraCalibrationError("camera calibration names must be unique")
    declared = {camera.name for camera in embodiment.cameras}
    for camera in cameras:
        if camera.owner is CameraOwner.EMBODIMENT:
            if camera.owner_ref != str(embodiment.id):
                raise InvalidCameraCalibrationError(
                    f"{camera.name}: camera owner does not match the embodiment"
                )
            if camera.name not in declared:
                raise InvalidCameraCalibrationError(
                    f"{camera.name}: embodiment-owned camera is not declared"
                )
