"""Typed immutable overlay RRDs pinned to one canonical base episode."""

from __future__ import annotations

import json
import math
import os
import re
from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from itertools import pairwise
from pathlib import Path
from typing import cast
from uuid import uuid4

import rerun as rr
from rerun.experimental import RrdReader
from sx_contracts import Decision, Sha256Digest, SupervisionLayer, decode
from sx_contracts.identity import JsonValue, canonical_json, file_digest
from sx_contracts.wire import DottedIdentifier

from sx_episodes.records import EpisodeProducer
from sx_episodes.rrd import read_episode
from sx_episodes.rrd_query import static_value
from sx_episodes.schema import (
    APPLICATION_ID,
    LAYER_SCHEMA_NAME,
    PATH_LAYER_META,
    STEP_TIMELINE,
    TIME_TIMELINE,
)


class EpisodeLayerError(ValueError):
    """An overlay is malformed or does not pin the selected base episode."""


class EpisodeLayerKind(StrEnum):
    """Overlay kinds with implemented platform consumers."""

    EVALUATION = "evaluation"
    SUPERVISION = "supervision"
    SEGMENTATION = "segmentation"


class MetricName(DottedIdentifier):
    """A stable path-safe evaluation metric identity."""

    error = EpisodeLayerError
    noun = "metric name"


@dataclass(frozen=True, slots=True)
class EvaluationMetric:
    name: MetricName
    at: float
    value: float

    def __post_init__(self) -> None:
        if not _valid_time(self.at) or not math.isfinite(self.value):
            raise EpisodeLayerError("evaluation metric time and value must be finite")


@dataclass(frozen=True, slots=True)
class SupervisionVerdict:
    step: int
    at: float
    layer: SupervisionLayer
    decision: Decision
    reason: str

    def __post_init__(self) -> None:
        if self.step < 0 or not _valid_time(self.at):
            raise EpisodeLayerError("supervision verdict step and time must be non-negative")
        if not self.reason.strip():
            raise EpisodeLayerError("supervision verdict reason must be non-empty")


@dataclass(frozen=True, slots=True)
class StepBoundary:
    """Where one authored contract step begins inside an episode.

    A long-horizon episode is one instruction and many steps; this is the only place
    that says which step is running when. The active step at any native time is the
    last boundary at or before it, and the episode's completion closes the final one.

    ``step_index`` indexes the task contract's own ``TaskStep`` tuple — a segmentation
    names no vocabulary of its own — and may legitimately repeat, because a
    demonstrator who re-attempted a step really did enter it twice.

    It is an overlay rather than an episode field because a segmentation is derived and
    improvable: a better segmenter re-derives it against the same immutable base, and
    the base episode's bytes never move.
    """

    step: int
    at: float
    step_index: int

    def __post_init__(self) -> None:
        if self.step < 0 or not _valid_time(self.at):
            raise EpisodeLayerError("step boundary step and time must be non-negative")
        if self.step_index < 0:
            raise EpisodeLayerError("a step boundary indexes the contract's steps from zero")


type EpisodeLayerRecord = EvaluationMetric | SupervisionVerdict | StepBoundary


@dataclass(frozen=True, slots=True)
class EpisodeLayerFacts:
    recording_id: str
    base_sha256: Sha256Digest
    kind: EpisodeLayerKind
    producer: EpisodeProducer

    def __post_init__(self) -> None:
        if not self.recording_id.strip():
            raise EpisodeLayerError("overlay recording identity must be non-empty")
        if re.fullmatch(r"[a-f0-9]{64}", self.base_sha256) is None:
            raise EpisodeLayerError("overlay base SHA-256 must be 64 lowercase hex")


@dataclass(frozen=True, slots=True)
class EpisodeLayer:
    facts: EpisodeLayerFacts
    records: tuple[EpisodeLayerRecord, ...]

    def __post_init__(self) -> None:
        if not self.records:
            raise EpisodeLayerError("an overlay needs at least one record")
        expected = {
            EpisodeLayerKind.EVALUATION: EvaluationMetric,
            EpisodeLayerKind.SUPERVISION: SupervisionVerdict,
            EpisodeLayerKind.SEGMENTATION: StepBoundary,
        }[self.facts.kind]
        if any(type(record) is not expected for record in self.records):
            raise EpisodeLayerError(f"{self.facts.kind.value} overlay contains another record kind")
        times = tuple(record.at for record in self.records)
        if any(right < left for left, right in pairwise(times)):
            raise EpisodeLayerError("overlay records must be ordered by native time")
        if self.facts.kind is EpisodeLayerKind.SEGMENTATION:
            self._validate_segmentation()

    def _validate_segmentation(self) -> None:
        """A segmentation must answer "which step is running?" for every step of the base.

        Two invariants make :func:`active_step_index` total and unambiguous: the first
        boundary opens the episode, and boundaries strictly advance. Two boundaries at one
        episode step would leave the active step decided by tuple order, which is not a
        contract.
        """
        boundaries = cast("tuple[StepBoundary, ...]", self.records)
        if boundaries[0].step != 0:
            raise EpisodeLayerError("a segmentation's first boundary must open the episode")
        steps = tuple(boundary.step for boundary in boundaries)
        if any(right <= left for left, right in pairwise(steps)):
            raise EpisodeLayerError("segmentation boundaries must strictly advance in step")


@dataclass(frozen=True, slots=True)
class EpisodeLayerSummary:
    schema: str
    recording_id: str
    base_sha256: Sha256Digest
    kind: EpisodeLayerKind
    num_records: int


def write_episode_layer(
    layer: EpisodeLayer,
    path: Path,
    *,
    base: Path,
) -> Path:
    """Validate the base pin, flush, re-read, and atomically publish one overlay."""
    if path.suffix != ".rrd":
        raise EpisodeLayerError(f"overlay path must end in .rrd: {path}")
    if path.exists():
        raise FileExistsError(f"overlay RRD already exists: {path}")
    base_episode = read_episode(base)
    if file_digest(base) != layer.facts.base_sha256:
        raise EpisodeLayerError("overlay base SHA-256 disagrees with the selected RRD")
    if base_episode.facts.recording_id != layer.facts.recording_id:
        raise EpisodeLayerError("overlay recording identity disagrees with the base RRD")
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_name(f".{path.name}.{uuid4().hex}.partial")
    try:
        _write_layer(layer, partial)
        if read_episode_layer(partial) != layer:
            raise EpisodeLayerError("overlay changed during RRD round trip")
        if path.exists():
            raise FileExistsError(f"overlay RRD already exists: {path}")
        os.replace(partial, path)
    finally:
        partial.unlink(missing_ok=True)
    return path


def read_episode_layer(path: Path) -> EpisodeLayer:
    """Read the canonical static layer document and verify its recording identity."""
    try:
        raw = static_value(path, PATH_LAYER_META, "json")
        if raw is None:
            raise EpisodeLayerError("overlay has no canonical metadata")
        document: object = json.loads(raw)
        layer = _layer_from_document(
            decode.document(document, where="overlay record", error=EpisodeLayerError)
        )
        if _recording_id(path) != layer.facts.recording_id:
            raise EpisodeLayerError("overlay RRD recording id disagrees with its facts")
        return layer
    except EpisodeLayerError:
        raise
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as exc:
        raise EpisodeLayerError(f"invalid episode overlay {path}: {exc}") from exc


def step_boundaries(layer: EpisodeLayer) -> tuple[StepBoundary, ...]:
    """The layer's boundaries; anything but a segmentation overlay is refused."""
    if layer.facts.kind is not EpisodeLayerKind.SEGMENTATION:
        raise EpisodeLayerError(f"a {layer.facts.kind.value} overlay carries no step boundaries")
    return cast("tuple[StepBoundary, ...]", layer.records)


def active_step_index(boundaries: tuple[StepBoundary, ...], step: int) -> int:
    """Which contract step is running at episode ``step``: the last boundary at or before it.

    Total for every step of the base episode, because a segmentation's first boundary
    opens it (:meth:`EpisodeLayer._validate_segmentation`). A negative step is a caller
    bug rather than a missing fact, so it refuses instead of clamping.
    """
    if step < 0:
        raise EpisodeLayerError(f"episode step must be non-negative, got {step}")
    active = boundaries[0].step_index
    for boundary in boundaries:
        if boundary.step > step:
            break
        active = boundary.step_index
    return active


def validate_episode_layer(path: Path) -> EpisodeLayerSummary:
    layer = read_episode_layer(path)
    return EpisodeLayerSummary(
        LAYER_SCHEMA_NAME,
        layer.facts.recording_id,
        layer.facts.base_sha256,
        layer.facts.kind,
        len(layer.records),
    )


def _write_layer(layer: EpisodeLayer, path: Path) -> None:
    recording = rr.RecordingStream(
        APPLICATION_ID,
        recording_id=layer.facts.recording_id,
    )
    recording.save(str(path))
    rr.log(
        PATH_LAYER_META,
        rr.AnyValues(json=canonical_json(_layer_document(layer))),
        static=True,
        recording=recording,
    )
    for record in layer.records:
        rr.set_time(TIME_TIMELINE, duration=record.at, recording=recording)
        if isinstance(record, EvaluationMetric):
            rr.log(
                f"evaluation/metrics/{record.name}",
                rr.Scalars([record.value]),
                recording=recording,
            )
        elif isinstance(record, SupervisionVerdict):
            rr.set_time(STEP_TIMELINE, sequence=record.step, recording=recording)
            rr.log(
                f"supervision/{record.layer.name.lower()}",
                rr.TextLog(f"{record.decision.value}: {record.reason}"),
                recording=recording,
            )
        else:
            rr.set_time(STEP_TIMELINE, sequence=record.step, recording=recording)
            rr.log(
                "segmentation/step",
                rr.TextLog(f"step {record.step_index}"),
                recording=recording,
            )
    recording.flush()
    del recording


def _layer_document(layer: EpisodeLayer) -> dict[str, JsonValue]:
    records: list[JsonValue] = [_record_document(record) for record in layer.records]
    return {
        "schema": LAYER_SCHEMA_NAME,
        "recording_id": layer.facts.recording_id,
        "base_sha256": layer.facts.base_sha256,
        "kind": layer.facts.kind.value,
        "producer": {
            "name": layer.facts.producer.name,
            "version": layer.facts.producer.version,
        },
        "records": records,
    }


def _record_document(record: EpisodeLayerRecord) -> dict[str, JsonValue]:
    if isinstance(record, EvaluationMetric):
        return {
            "type": "evaluation_metric",
            "name": str(record.name),
            "at": record.at,
            "value": record.value,
        }
    if isinstance(record, SupervisionVerdict):
        return {
            "type": "supervision_verdict",
            "step": record.step,
            "at": record.at,
            "layer": record.layer.value,
            "decision": record.decision.value,
            "reason": record.reason,
        }
    return {
        "type": "step_boundary",
        "step": record.step,
        "at": record.at,
        "step_index": record.step_index,
    }


def _layer_from_document(document: decode.Document) -> EpisodeLayer:
    expected = {
        "schema",
        "recording_id",
        "base_sha256",
        "kind",
        "producer",
        "records",
    }
    if set(document) != expected or document.get("schema") != LAYER_SCHEMA_NAME:
        raise EpisodeLayerError("overlay metadata has another schema or wire shape")
    producer = decode.document(
        document["producer"], where="overlay record", error=EpisodeLayerError
    )
    raw_records = document["records"]
    if not isinstance(raw_records, list):
        raise EpisodeLayerError("overlay records must be an array")
    facts = EpisodeLayerFacts(
        _text(document, "recording_id"),
        Sha256Digest(_text(document, "base_sha256")),
        EpisodeLayerKind(_text(document, "kind")),
        EpisodeProducer(_text(producer, "name"), _text(producer, "version")),
    )
    return EpisodeLayer(
        facts,
        tuple(_record_from_object(value) for value in cast("list[object]", raw_records)),
    )


def _record_from_object(value: object) -> EpisodeLayerRecord:
    record = decode.document(value, where="overlay record", error=EpisodeLayerError)
    kind = _text(record, "type")
    if kind == "evaluation_metric":
        return EvaluationMetric(
            MetricName(_text(record, "name")),
            decode.number(record, "at"),
            decode.number(record, "value"),
        )
    if kind == "supervision_verdict":
        return SupervisionVerdict(
            decode.integer(record, "step"),
            decode.number(record, "at"),
            SupervisionLayer(decode.integer(record, "layer")),
            Decision(_text(record, "decision")),
            _text(record, "reason"),
        )
    if kind == "step_boundary":
        return StepBoundary(
            decode.integer(record, "step"),
            decode.number(record, "at"),
            decode.integer(record, "step_index"),
        )
    raise EpisodeLayerError(f"unknown overlay record type {kind!r}")


def _recording_id(path: Path) -> str:
    recordings = RrdReader(str(path)).recordings()
    if len(recordings) != 1:
        raise EpisodeLayerError("overlay RRD must contain exactly one recording")
    return str(recordings[0].recording_id)


def _text(document: Mapping[str, object], field: str) -> str:
    """Overlay text that is blank annotates nothing — the one rule beyond the kit."""
    value = decode.text(document, field, where="overlay", error=EpisodeLayerError)
    if not value:
        raise EpisodeLayerError(f"overlay {field} must be non-empty text")
    return value


def _valid_time(value: float) -> bool:
    return math.isfinite(value) and value >= 0.0
