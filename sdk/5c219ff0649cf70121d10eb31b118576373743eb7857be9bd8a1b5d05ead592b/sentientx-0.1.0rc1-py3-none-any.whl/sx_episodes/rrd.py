"""Canonical native-time RRD codec and atomic recorder for complete episodes."""

from __future__ import annotations

import json
import math
import os
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from types import TracebackType
from typing import cast
from uuid import uuid4

import numpy as np
import pyarrow as pa
import rerun as rr
import rerun_bindings
from numpy.typing import NDArray
from rerun.experimental import Chunk, RrdReader
from sx_actions import Action, ActionInterface, ActionInterfaceId, action_interface_from_dict
from sx_contracts import (
    ActionSource,
    DatasetKind,
    EpisodeEnd,
    EpisodeId,
    EpisodeUse,
    RolloutId,
    SchemaId,
    Sha256Digest,
    TaskContractRef,
    TaskId,
    TaskSchemaVersion,
    dataset_for_source,
    decode,
    episode_end_from_dict,
    episode_end_to_dict,
    step_progress_from_dict,
    step_progress_to_dict,
)
from sx_embodiments import Embodiment

from sx_episodes.blueprint import send_episode_blueprint
from sx_episodes.calibration import (
    CameraCalibration,
    EpisodePhysicalFactsError,
    validate_episode_physical_facts,
)
from sx_episodes.records import (
    Episode,
    EpisodeActionError,
    EpisodeError,
    EpisodeExecution,
    EpisodeFacts,
    EpisodeParent,
    EpisodeProducer,
    ExecutedAction,
    FleetReceipt,
    ImageSample,
    LineageKind,
    NativeClock,
    RewardSample,
    RobotExecutionProof,
    SimulatorExecutionProof,
    StateSample,
    calibrated_cameras,
    ordered_state,
    validate_image_sample,
    validate_state_sample,
)
from sx_episodes.rrd_query import chunks, static_value
from sx_episodes.scene import log_episode_scene, log_joint_state
from sx_episodes.schema import (
    APPLICATION_ID,
    PATH_ACTION,
    PATH_ACTION_FACTS,
    PATH_ACTION_SOURCE,
    PATH_EVENTS,
    PATH_META,
    PATH_REWARD,
    PATH_TERMINAL,
    PATH_URDF,
    SCHEMA_NAME,
    STEP_TIMELINE,
    TIME_TIMELINE,
    camera_path,
    state_path,
)


class EpisodeRrdError(EpisodeError):
    """An RRD cannot be decoded as one complete v8 episode."""


@dataclass(frozen=True, slots=True)
class EpisodeSummary:
    schema: SchemaId
    episode_id: EpisodeId
    rollout_id: RolloutId
    task: TaskContractRef
    use: EpisodeUse
    embodiment_id: str
    action_interface_id: ActionInterfaceId
    camera_names: tuple[str, ...]
    camera_calibration_sha256: tuple[Sha256Digest, ...]
    action_sources: frozenset[ActionSource]
    dataset_kinds: frozenset[DatasetKind]
    num_steps: int


class EpisodeRecorder:
    """Human-readable recording boundary that atomically publishes one immutable RRD.

    Samples are written to the recording stream as they arrive, so the recorder's own
    footprint is a handful of clocks and counters rather than the episode: a 250-step
    three-camera gate episode is ~140 MiB of raw pixels, and holding hundreds of them
    to publish at ``close`` is what made bulk generation grow without bound.

    Nothing about the published artifact changes, and nothing about its validation is
    relaxed. ``close`` still re-reads the file it just wrote and constructs a complete
    :class:`Episode` from it, so **every** law in :class:`Episode` still decides whether
    the episode publishes — on the bytes, which is the stronger place to decide it. Two
    laws are additionally enforced sample by sample here, because they are the two a
    round trip cannot see: an image logged to an uncalibrated slot is invisible to the
    reader, and the reader sorts each stream by time, so a sample that arrived out of
    order would be silently reordered instead of refused.
    """

    def __init__(
        self,
        path: Path,
        facts: EpisodeFacts,
        *,
        static_logger: Callable[[rr.RecordingStream], None] | None = None,
        action_logger: Callable[[rr.RecordingStream, ExecutedAction], None] | None = None,
    ) -> None:
        if path.suffix != ".rrd":
            raise EpisodeRrdError(f"episode path must end in .rrd: {path}")
        if path.exists():
            raise FileExistsError(f"episode rrd already exists: {path} — episodes are immutable")
        self.path = path
        self.facts = facts
        self._action_logger = action_logger
        self._calibrated = calibrated_cameras(facts.cameras)
        self._state_clock = NativeClock("state")
        self._camera_clocks = {name: NativeClock(f"camera {name}") for name in self._calibrated}
        self._states = 0
        self.execution = EpisodeExecution(facts.action_interface)

        path.parent.mkdir(parents=True, exist_ok=True)
        self._partial = path.with_name(f".{path.name}.{uuid4().hex}.partial")
        stream = rr.RecordingStream(APPLICATION_ID, recording_id=facts.recording_id)
        stream.save(str(self._partial))
        send_episode_blueprint(stream, tuple(c.name for c in facts.cameras))
        self._scene = log_episode_scene(stream, facts)
        if static_logger is not None:
            static_logger(stream)
        self._rec: rr.RecordingStream | None = stream

    @property
    def closed(self) -> bool:
        """Whether this recorder released its stream, by publishing or abandoning it."""
        return self._rec is None

    def __enter__(self) -> EpisodeRecorder:
        return self

    def __exit__(
        self,
        exception_type: type[BaseException] | None,
        exception: BaseException | None,
        traceback: TracebackType | None,
    ) -> bool:
        del exception, traceback
        if exception_type is None:
            self.close()
        else:
            self.abandon()
        return False

    def observe(
        self,
        *,
        at: float,
        state: Mapping[str, float] | NDArray[np.floating],
        images: Mapping[str, NDArray[np.uint8]] = {},
    ) -> None:
        """Record one named embodiment-state sample and any images acquired with it."""
        stream = self._open()
        values = ordered_state(self.facts.embodiment, state)
        validate_state_sample(self.facts.embodiment, self._states, values)
        self._state_clock.advance(at)
        self._states += 1
        self._observation_time(stream, at)
        for name, value in zip(self.facts.embodiment.state.names, values, strict=True):
            rr.log(state_path(name), rr.Scalars([float(value)]), recording=stream)
        log_joint_state(stream, self._scene, values)
        for camera, image in images.items():
            self.image(at=at, camera=camera, image=image)

    def image(self, *, at: float, camera: str, image: NDArray[np.uint8]) -> None:
        """Record a camera frame acquired independently of the state cadence."""
        stream = self._open()
        validate_image_sample(self._calibrated, camera, image)
        self._camera_clocks[camera].advance(at)
        self._observation_time(stream, at)
        rr.log(camera_path(camera), rr.Image(image), recording=stream)

    def act(
        self,
        *,
        step: int,
        observed_at: float,
        applied_at: float,
        action: Action,
        source: ActionSource,
        proof: RobotExecutionProof | SimulatorExecutionProof,
    ) -> None:
        """Record only an action proven to have executed."""
        stream = self._open()
        executed = ExecutedAction(step, observed_at, applied_at, action, source, proof)
        self.execution.commit(executed)
        rr.set_time(STEP_TIMELINE, sequence=step, recording=stream)
        rr.set_time(TIME_TIMELINE, duration=applied_at, recording=stream)
        rr.log(PATH_ACTION, rr.Scalars(action.values), recording=stream)
        rr.log(
            PATH_ACTION_FACTS,
            rr.AnyValues(json=json.dumps(_executed_action_document(executed), sort_keys=True)),
            recording=stream,
        )
        rr.log(PATH_ACTION_SOURCE, rr.TextLog(source.value), recording=stream)
        if isinstance(proof, RobotExecutionProof):
            for receipt in proof.receipts:
                rr.log(
                    PATH_TERMINAL,
                    rr.TextLog(
                        f"step={step} receipt={receipt.receipt_id} lease={receipt.lease_id}"
                    ),
                    recording=stream,
                )
        rr.log(
            PATH_EVENTS,
            rr.TextLog(f"executed step={step} source={source.value}"),
            recording=stream,
        )
        if self._action_logger is not None:
            self._action_logger(stream, executed)

    def reward(self, *, step: int, at: float, value: float) -> None:
        """Record a dense scalar reward only when one was actually observed."""
        stream = self._open()
        rr.set_time(STEP_TIMELINE, sequence=step, recording=stream)
        rr.set_time(TIME_TIMELINE, duration=at, recording=stream)
        rr.log(PATH_REWARD, rr.Scalars([value]), recording=stream)

    def finish(self, end: EpisodeEnd) -> None:
        """Close the domain episode with one validated ending."""
        self._open()
        if self.execution.sealed:
            raise EpisodeRrdError("episode finish may be called only once")
        self.execution.finish(end)

    def close(self) -> Path:
        """Seal the stream, re-read every law from the bytes, and atomically publish."""
        end = self.execution.end
        last = self.execution.last_action
        try:
            self._log_ending(end, last.step, last.applied_at)
            self._seal()
            _read_episode(self._partial)
            if self.path.exists():
                raise FileExistsError(
                    f"episode rrd already exists: {self.path} — episodes are immutable"
                )
            os.replace(self._partial, self.path)
        finally:
            self._partial.unlink(missing_ok=True)
        return self.path

    def abandon(self) -> None:
        """Discard an unpublishable recording and its partial file."""
        if self._rec is not None:
            self._seal()
        self._partial.unlink(missing_ok=True)

    def _log_ending(self, end: EpisodeEnd, step: int, applied_at: float) -> None:
        """The static episode document and the terminal marker, both known only now."""
        stream = self._open()
        rr.log(
            PATH_META,
            rr.AnyValues(json=json.dumps(_episode_document(self.facts, end), sort_keys=True)),
            static=True,
            recording=stream,
        )
        rr.set_time(STEP_TIMELINE, sequence=step, recording=stream)
        rr.set_time(TIME_TIMELINE, duration=applied_at, recording=stream)
        rr.log(
            PATH_TERMINAL,
            rr.TextLog(
                f"verdict={end.verdict.value} reason={end.reason.value} "
                f"kind={'terminated' if end.terminated else 'truncated'}"
            ),
            recording=stream,
        )

    def _seal(self) -> None:
        """Flush the stream, close its file sink, and release the native recording.

        Detaching the sink is what writes the RRD's footer — a flushed but attached
        sink leaves a legacy footerless file the reader can only whole-file scan. The
        release then has to be completed by hand: dropping the last handle only marks
        the native recording *orphaned*, and an orphan keeps its batcher threads and
        their arenas until something reaps it. Only ``rerun.init`` reaps, and nothing
        here calls it, so a bulk producer would accumulate two OS threads and ~10 MiB
        of native memory per episode until the kernel killed it.
        """
        stream = self._open()
        self._rec = None
        stream.flush()
        stream.set_sinks()
        del stream
        rerun_bindings.flush_and_cleanup_orphaned_recordings()

    def _observation_time(self, stream: rr.RecordingStream, at: float) -> None:
        """Stamp an observation on the time timeline only: it has no executed step."""
        rr.disable_timeline(STEP_TIMELINE, recording=stream)
        rr.set_time(TIME_TIMELINE, duration=at, recording=stream)

    def _open(self) -> rr.RecordingStream:
        """The live recording stream; a sealed recorder has none and accepts nothing."""
        if self._rec is None:
            raise EpisodeRrdError("episode recorder is already closed")
        return self._rec


def write_episode(
    episode: Episode,
    path: Path,
    *,
    static_logger: Callable[[rr.RecordingStream], None] | None = None,
    action_logger: Callable[[rr.RecordingStream, ExecutedAction], None] | None = None,
) -> Path:
    """Write a complete batch value through the same atomic recorder boundary."""
    with EpisodeRecorder(
        path,
        episode.facts,
        static_logger=static_logger,
        action_logger=action_logger,
    ) as recorder:
        for state in episode.states:
            recorder.observe(at=state.at, state=state.values)
        for image in episode.images:
            recorder.image(at=image.at, camera=image.camera, image=image.image)
        for executed in episode.actions:
            recorder.act(
                step=executed.step,
                observed_at=executed.observed_at,
                applied_at=executed.applied_at,
                action=executed.action,
                source=executed.source,
                proof=executed.proof,
            )
        for reward in episode.rewards:
            recorder.reward(step=reward.step, at=reward.at, value=reward.value)
        recorder.finish(episode.end)
    return path


def read_episode(path: Path) -> Episode:
    """Parse every canonical episode fact, translating SDK failures at this boundary."""
    try:
        return _read_episode(path)
    except EpisodeRrdError:
        raise
    except (OSError, RuntimeError, ValueError) as exc:
        raise EpisodeRrdError(f"invalid episode RRD {path}: {exc}") from exc


def _read_episode(path: Path) -> Episode:
    episode_chunks = chunks(path)
    meta = _json_static(path, episode_chunks, PATH_META, "episode metadata")
    if meta.get("schema") != SCHEMA_NAME:
        raise EpisodeRrdError(f"unsupported episode schema: {meta.get('schema')!r}")
    embodiment, cameras = _physical_facts_from_document(path, episode_chunks, meta)
    interface = _action_interface_from_document(meta)
    facts = _facts_from_document(meta, embodiment, interface, cameras)
    recordings = RrdReader(str(path)).recordings()
    if len(recordings) != 1 or str(recordings[0].recording_id) != facts.recording_id:
        raise EpisodeRrdError(
            "episode RRD recording id disagrees with its rollout/episode identity"
        )

    state_times: list[float] = []
    state_columns: list[list[float]] = []
    for index, name in enumerate(embodiment.state.names):
        times, rows = _timed_scalar_rows(episode_chunks, state_path(name))
        values = [_singleton_number(row, f"state {name}") for row in rows]
        if index == 0:
            state_times = times
        elif not _same_times(state_times, times):
            raise EpisodeRrdError(f"state coordinate {name} is not aligned with state samples")
        state_columns.append(values)
    states = tuple(
        StateSample(
            at,
            np.asarray([column[index] for column in state_columns], dtype=np.float32),
        )
        for index, at in enumerate(state_times)
    )

    images = tuple(
        sample for camera in cameras for sample in _timed_image_rows(episode_chunks, camera)
    )
    action_steps, action_times, action_rows = _stepped_scalar_rows(episode_chunks, PATH_ACTION)
    fact_steps, documents = _stepped_json_rows(episode_chunks, PATH_ACTION_FACTS)
    if action_steps != fact_steps:
        raise EpisodeRrdError("episode action values and execution facts are misaligned")
    actions = tuple(
        _executed_action_from_document(
            documents[index],
            facts.action_interface.action(np.asarray(action_rows[index], dtype=np.float32)),
            action_times[index],
        )
        for index in range(len(action_steps))
    )

    reward_steps, reward_times, reward_rows = _stepped_scalar_rows(
        episode_chunks, PATH_REWARD, allow_empty=True
    )
    rewards = tuple(
        RewardSample(
            step,
            reward_times[index],
            _singleton_number(reward_rows[index], f"reward {step}"),
        )
        for index, step in enumerate(reward_steps)
    )
    end = _end_from_document(meta)
    try:
        return Episode(facts, states, images, actions, rewards, end)
    except (EpisodeError, ValueError) as exc:
        raise EpisodeRrdError(f"invalid episode {path}: {exc}") from exc


def validate_episode(path: Path) -> EpisodeSummary:
    """Validate and summarize one complete episode RRD."""
    episode = read_episode(path)
    sources = frozenset(executed.source for executed in episode.actions)
    return EpisodeSummary(
        SCHEMA_NAME,
        episode.episode_id,
        episode.rollout_id,
        episode.task,
        episode.use,
        str(episode.embodiment_id),
        episode.action_interface.id,
        tuple(camera.name for camera in episode.cameras),
        tuple(camera.digest() for camera in episode.cameras),
        sources,
        frozenset(dataset_for_source(source) for source in sources),
        episode.num_steps,
    )


def _episode_document(facts: EpisodeFacts, end: EpisodeEnd) -> dict[str, object]:
    from sx_actions import action_interface_to_dict

    return {
        "schema": SCHEMA_NAME,
        "rollout_id": str(facts.rollout_id),
        "episode_id": str(facts.episode_id),
        "task": {
            "task_id": str(facts.task.task_id),
            "schema_version": str(facts.task.schema_version),
            "sha256": str(facts.task.sha256),
        },
        "embodiment": facts.embodiment.to_dict(),
        "action_interface": action_interface_to_dict(facts.action_interface),
        "cameras": [camera.to_dict() for camera in facts.cameras],
        "producer": {"name": facts.producer.name, "version": facts.producer.version},
        "use": facts.use.value,
        "lineage": [
            {"kind": parent.kind.value, "uri": parent.uri, "sha256": parent.sha256}
            for parent in facts.lineage
        ],
        "instruction": facts.instruction,
        "end": episode_end_to_dict(end),
    }


def _physical_facts_from_document(
    path: Path,
    episode_chunks: Sequence[Chunk],
    meta: dict[str, object],
) -> tuple[Embodiment, tuple[CameraCalibration, ...]]:
    raw_embodiment = meta.get("embodiment")
    raw_cameras = meta.get("cameras")
    if not isinstance(raw_embodiment, dict) or not isinstance(raw_cameras, list):
        raise EpisodeRrdError("episode metadata has no complete embodiment and cameras")
    camera_documents = cast("list[object]", raw_cameras)
    try:
        embodiment = Embodiment.from_dict(cast("dict[str, object]", raw_embodiment))
        cameras = tuple(
            CameraCalibration.from_dict(cast("dict[str, object]", camera))
            for camera in camera_documents
            if isinstance(camera, dict)
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise EpisodeRrdError("malformed episode embodiment or camera facts") from exc
    if len(cameras) != len(camera_documents):
        raise EpisodeRrdError("episode camera facts must be objects")
    raw_urdf = static_value(episode_chunks, PATH_URDF, "xml")
    if raw_urdf is None:
        raise EpisodeRrdError(f"episode rrd {path} has no authoritative URDF")
    try:
        validate_episode_physical_facts(embodiment, cameras, raw_urdf.encode())
    except EpisodePhysicalFactsError as exc:
        raise EpisodeRrdError(f"invalid episode physical facts: {exc}") from exc
    return embodiment, cameras


def _action_interface_from_document(meta: dict[str, object]) -> ActionInterface:
    document = meta.get("action_interface")
    if not isinstance(document, dict):
        raise EpisodeRrdError("episode metadata has no action interface")
    try:
        return action_interface_from_dict(cast("dict[str, object]", document))
    except (KeyError, TypeError, ValueError) as exc:
        raise EpisodeRrdError("malformed action interface") from exc


def _facts_from_document(
    meta: dict[str, object],
    embodiment: Embodiment,
    interface: ActionInterface,
    cameras: tuple[CameraCalibration, ...],
) -> EpisodeFacts:
    task = decode.mapping(meta, "task", where="episode metadata", error=EpisodeRrdError)
    producer = decode.mapping(meta, "producer", where="episode metadata", error=EpisodeRrdError)
    raw_lineage = meta.get("lineage")
    if not isinstance(raw_lineage, list):
        raise EpisodeRrdError("episode lineage must be an array")
    try:
        return EpisodeFacts(
            rollout_id=RolloutId(_required_text(meta, "rollout_id")),
            episode_id=EpisodeId(_required_text(meta, "episode_id")),
            task=TaskContractRef(
                task_id=TaskId(_required_text(task, "task_id")),
                schema_version=TaskSchemaVersion(_required_text(task, "schema_version")),
                sha256=Sha256Digest(_required_text(task, "sha256")),
            ),
            embodiment=embodiment,
            action_interface=interface,
            cameras=cameras,
            producer=EpisodeProducer(
                _required_text(producer, "name"), _required_text(producer, "version")
            ),
            use=EpisodeUse(_required_text(meta, "use")),
            instruction=_required_text(meta, "instruction"),
            lineage=tuple(_parent_from_object(item) for item in cast("list[object]", raw_lineage)),
        )
    except (EpisodeError, ValueError) as exc:
        raise EpisodeRrdError(f"invalid static episode facts: {exc}") from exc


def _parent_from_object(value: object) -> EpisodeParent:
    parent = decode.document(value, where="lineage parent", error=EpisodeRrdError)
    try:
        return EpisodeParent(
            LineageKind(_required_text(parent, "kind")),
            _required_text(parent, "uri"),
            Sha256Digest(_required_text(parent, "sha256")),
        )
    except (EpisodeError, ValueError) as exc:
        raise EpisodeRrdError(f"invalid lineage parent: {exc}") from exc


def _end_from_document(meta: dict[str, object]) -> EpisodeEnd:
    try:
        return episode_end_from_dict(meta.get("end"))
    except (EpisodeError, ValueError) as exc:
        raise EpisodeRrdError(f"invalid episode end: {exc}") from exc


def _executed_action_document(executed: ExecutedAction) -> dict[str, object]:
    proof = executed.proof
    proof_document: dict[str, object]
    if isinstance(proof, RobotExecutionProof):
        proof_document = {
            "kind": "robot",
            "execution_id": proof.execution_id,
            "applied_at": proof.applied_at,
            "executed_action": [float(value) for value in proof.executed_action.values],
            "receipts": [
                {
                    "lease_id": receipt.lease_id,
                    "receipt_id": receipt.receipt_id,
                    "sha256": receipt.sha256,
                }
                for receipt in proof.receipts
            ],
        }
    else:
        proof_document = {
            "kind": "simulator",
            "environment_step": proof.environment_step,
            "simulation_time": proof.simulation_time,
            "reward": proof.reward,
            "progress": step_progress_to_dict(proof.progress),
        }
    return {
        "step": executed.step,
        "observed_at": executed.observed_at,
        "applied_at": executed.applied_at,
        "source": executed.source.value,
        "proof": proof_document,
    }


def _executed_action_from_document(
    document: dict[str, object], action: Action, logged_at: float
) -> ExecutedAction:
    proof = decode.mapping(document, "proof", where="action", error=EpisodeRrdError)
    kind = _required_text(proof, "kind")
    step = decode.integer(document, "step")
    observed_at = decode.number(document, "observed_at")
    applied_at = decode.number(document, "applied_at")
    if not math.isclose(logged_at, applied_at, rel_tol=0.0, abs_tol=1e-9):
        raise EpisodeRrdError(f"action {step} timeline disagrees with applied_at")
    try:
        if kind == "robot":
            raw_action = proof.get("executed_action")
            if not isinstance(raw_action, list):
                raise EpisodeRrdError("robot proof executed_action must be an array")
            receipt_values = proof.get("receipts")
            if not isinstance(receipt_values, list):
                raise EpisodeRrdError("robot proof receipts must be an array")
            receipts = tuple(
                _receipt_from_document(
                    decode.document(item, where="Fleet receipt", error=EpisodeRrdError)
                )
                for item in cast("list[object]", receipt_values)
            )
            execution_proof: RobotExecutionProof | SimulatorExecutionProof = RobotExecutionProof(
                execution_id=_required_text(proof, "execution_id"),
                applied_at=decode.number(proof, "applied_at"),
                executed_action=action.interface.action(
                    np.asarray(
                        [
                            _scalar(item, "robot proof executed_action[]")
                            for item in cast("list[object]", raw_action)
                        ],
                        dtype=np.float32,
                    )
                ),
                receipts=receipts,
            )
        elif kind == "simulator":
            execution_proof = SimulatorExecutionProof(
                environment_step=decode.integer(proof, "environment_step"),
                simulation_time=decode.number(proof, "simulation_time"),
                reward=decode.number(proof, "reward"),
                progress=step_progress_from_dict(proof.get("progress")),
            )
        else:
            raise EpisodeRrdError(f"unknown execution proof kind {kind!r}")
        return ExecutedAction(
            step,
            observed_at,
            applied_at,
            action,
            ActionSource(_required_text(document, "source")),
            execution_proof,
        )
    except (EpisodeActionError, ValueError) as exc:
        raise EpisodeRrdError(f"invalid action proof at step {step}: {exc}") from exc


def _receipt_from_document(document: Mapping[str, object]) -> FleetReceipt:
    return FleetReceipt(
        _required_text(document, "lease_id"),
        _required_text(document, "receipt_id"),
        Sha256Digest(_required_text(document, "sha256")),
    )


def _json_static(
    path: Path,
    episode_chunks: Sequence[Chunk],
    entity: str,
    label: str,
) -> dict[str, object]:
    raw = static_value(episode_chunks, entity, "json")
    if raw is None:
        raise EpisodeRrdError(f"episode rrd {path} has no {label}")
    return _json_document(raw, label)


def _json_document(raw: str, label: str) -> dict[str, object]:
    try:
        value: object = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise EpisodeRrdError(f"malformed {label}") from exc
    if not isinstance(value, dict):
        raise EpisodeRrdError(f"malformed {label}")
    untyped = cast("dict[object, object]", value)
    if not all(isinstance(key, str) for key in untyped):
        raise EpisodeRrdError(f"malformed {label}")
    return {cast("str", key): item for key, item in untyped.items()}


def _timed_scalar_rows(
    episode_chunks: Sequence[Chunk], entity: str
) -> tuple[list[float], list[list[float]]]:
    times: list[float] = []
    rows: list[list[float]] = []
    for chunk in episode_chunks:
        if str(chunk.entity_path).lstrip("/") != entity:
            continue
        batch = chunk.to_record_batch()
        scalar = next((name for name in batch.schema.names if name.endswith(":scalars")), None)
        if TIME_TIMELINE not in batch.schema.names or scalar is None:
            continue
        times.extend(
            _duration_seconds(value)
            for value in batch.column(TIME_TIMELINE).to_numpy(zero_copy_only=False)
        )
        rows.extend(cast("list[list[float]]", batch.column(scalar).to_pylist()))
    order = sorted(range(len(times)), key=times.__getitem__)
    return [times[index] for index in order], [rows[index] for index in order]


def _stepped_scalar_rows(
    episode_chunks: Sequence[Chunk],
    entity: str,
    *,
    allow_empty: bool = False,
) -> tuple[list[int], list[float], list[list[float]]]:
    steps: list[int] = []
    times: list[float] = []
    rows: list[list[float]] = []
    for chunk in episode_chunks:
        if str(chunk.entity_path).lstrip("/") != entity:
            continue
        batch = chunk.to_record_batch()
        scalar = next((name for name in batch.schema.names if name.endswith(":scalars")), None)
        if (
            STEP_TIMELINE not in batch.schema.names
            or TIME_TIMELINE not in batch.schema.names
            or scalar is None
        ):
            continue
        steps.extend(cast("list[int]", batch.column(STEP_TIMELINE).to_pylist()))
        times.extend(
            _duration_seconds(value)
            for value in batch.column(TIME_TIMELINE).to_numpy(zero_copy_only=False)
        )
        rows.extend(cast("list[list[float]]", batch.column(scalar).to_pylist()))
    if not steps and not allow_empty:
        raise EpisodeRrdError(f"episode has no {entity} rows")
    order = sorted(range(len(steps)), key=steps.__getitem__)
    return (
        [steps[index] for index in order],
        [times[index] for index in order],
        [rows[index] for index in order],
    )


def _stepped_json_rows(
    episode_chunks: Sequence[Chunk], entity: str
) -> tuple[list[int], list[dict[str, object]]]:
    steps: list[int] = []
    documents: list[dict[str, object]] = []
    for chunk in episode_chunks:
        if str(chunk.entity_path).lstrip("/") != entity:
            continue
        batch = chunk.to_record_batch()
        column = next(
            (name for name in batch.schema.names if name == "json" or name.endswith(":json")),
            None,
        )
        if STEP_TIMELINE not in batch.schema.names or column is None:
            continue
        chunk_steps = cast("list[int]", batch.column(STEP_TIMELINE).to_pylist())
        raw_documents = cast("list[object]", batch.column(column).to_pylist())
        for step, raw in zip(chunk_steps, raw_documents, strict=True):
            value = _singleton(raw)
            if not isinstance(value, str):
                raise EpisodeRrdError(f"action {step} facts must be JSON text")
            steps.append(step)
            documents.append(_json_document(value, f"action {step} facts"))
    order = sorted(range(len(steps)), key=steps.__getitem__)
    return [steps[index] for index in order], [documents[index] for index in order]


@dataclass(frozen=True, slots=True)
class RawImageRow:
    """One raw-RGB image row of a camera chunk: nanosecond time and pixels."""

    t_ns: int
    pixels: NDArray[np.uint8]


def raw_image_rows(
    batch: pa.RecordBatch,
    *,
    timeline: str = TIME_TIMELINE,
    wanted: frozenset[int] | set[int] | None = None,
) -> list[RawImageRow] | None:
    """Decode one camera chunk's raw-RGB image rows — THE spelling of the layout.

    The one place Rerun's image-chunk physical shape (`Image:buffer` +
    `Image:format` list columns over a timeline) is known; the canonical episode
    reader and the semantic index's frame walk both consume it (the 2026-08
    audit found a second hand-rolled decoder in the catalog). Returns ``None``
    when the batch carries no image buffer, format, or requested timeline — a
    non-image chunk, whose meaning belongs to the caller (skip or refusal).
    Encoded pixel formats raise: their decoders do not belong in control-plane
    processes. ``wanted`` restricts decoding to specific times, because decoding
    is the expensive half.
    """
    timeline_index = batch.schema.get_field_index(timeline)
    buffer_index = next((i for i, f in enumerate(batch.schema) if f.name.endswith(":buffer")), -1)
    format_index = next((i for i, f in enumerate(batch.schema) if f.name.endswith(":format")), -1)
    if timeline_index < 0 or buffer_index < 0 or format_index < 0:
        return None
    t_ns = np.asarray(
        batch.column(timeline_index).cast(pa.int64()).to_numpy(zero_copy_only=False), np.int64
    )
    outer_buffers = batch.column(buffer_index)
    if not isinstance(outer_buffers, pa.ListArray) or not isinstance(
        outer_buffers.values, pa.ListArray
    ):
        raise EpisodeRrdError("image buffer column is not a list of byte lists")
    inner_buffers = outer_buffers.values
    byte_values = inner_buffers.values
    if not isinstance(byte_values, pa.UInt8Array) or byte_values.null_count:
        raise EpisodeRrdError("image buffer column does not contain non-null uint8 values")
    outer_offsets = outer_buffers.offsets.to_numpy(zero_copy_only=False)
    inner_offsets = inner_buffers.offsets.to_numpy(zero_copy_only=False)
    outer_valid = outer_buffers.is_valid().to_numpy(zero_copy_only=False)
    inner_valid = inner_buffers.is_valid().to_numpy(zero_copy_only=False)
    formats = cast(
        "list[list[Mapping[str, object]] | None]", batch.column(format_index).to_pylist()
    )
    rows: list[RawImageRow] = []
    for row, t in enumerate(t_ns):
        t_int = int(t)
        if wanted is not None and t_int not in wanted:
            continue
        row_formats = formats[row]
        if not outer_valid[row] or not row_formats:
            continue
        buffer_start, buffer_end = int(outer_offsets[row]), int(outer_offsets[row + 1])
        if buffer_end - buffer_start != 1 or not inner_valid[buffer_start]:
            raise EpisodeRrdError(f"image row at {t_int}ns does not contain exactly one buffer")
        image_format = row_formats[0]
        width, height = int(str(image_format["width"])), int(str(image_format["height"]))
        if image_format.get("pixel_format") is not None:
            raise EpisodeRrdError(
                f"image row at {t_int}ns uses an encoded pixel format; "
                "only raw RGB u8 rows are decodable here"
            )
        byte_start = int(inner_offsets[buffer_start])
        byte_end = int(inner_offsets[buffer_start + 1])
        flat = byte_values.slice(byte_start, byte_end - byte_start).to_numpy(zero_copy_only=True)
        if flat.size != width * height * 3:
            raise EpisodeRrdError(
                f"image row at {t_int}ns is {flat.size} bytes, not the "
                f"{width}x{height}x3 its format declares"
            )
        rows.append(RawImageRow(t_ns=t_int, pixels=flat.reshape(height, width, 3)))
    return rows


def _timed_image_rows(
    episode_chunks: Sequence[Chunk], camera: CameraCalibration
) -> tuple[ImageSample, ...]:
    times: list[float] = []
    images: list[NDArray[np.uint8]] = []
    for chunk in episode_chunks:
        if str(chunk.entity_path).lstrip("/") != camera_path(camera.name):
            continue
        decoded = raw_image_rows(chunk.to_record_batch())
        if decoded is None:
            continue  # a non-image chunk on the camera entity
        expected_size = camera.height * camera.width * 3
        for row in decoded:
            if row.pixels.size != expected_size:
                raise EpisodeRrdError(
                    f"camera {camera.name} image has {row.pixels.size} bytes, "
                    f"expected {expected_size}"
                )
            # ns → seconds through timedelta64 division, the exact arithmetic
            # `_duration_seconds` demands (never pandas' truncating total_seconds).
            times.append(float(np.timedelta64(row.t_ns, "ns") / np.timedelta64(1, "s")))
            images.append(row.pixels.reshape(camera.height, camera.width, 3))
    order = sorted(range(len(times)), key=times.__getitem__)
    return tuple(ImageSample(camera.name, times[index], images[index]) for index in order)


def _duration_seconds(value: object) -> float:
    # np.timedelta64 FIRST, and the timeline columns decode via to_numpy on purpose:
    # arrow's to_pylist yields (pandas) Timedelta whose total_seconds() truncates to
    # microseconds, which silently breaks the nanosecond round-trip law for any
    # control rate whose periods are not exact microseconds (e.g. 30 Hz).
    if isinstance(value, np.timedelta64):
        return float(value / np.timedelta64(1, "s"))
    total_seconds = getattr(value, "total_seconds", None)
    if callable(total_seconds):
        result: object = total_seconds()
        if isinstance(result, int | float):
            return float(result)
    raise EpisodeRrdError(f"malformed {TIME_TIMELINE} duration {value!r}")


def _same_times(left: list[float], right: list[float]) -> bool:
    return len(left) == len(right) and all(
        math.isclose(a, b, rel_tol=0.0, abs_tol=1e-9) for a, b in zip(left, right, strict=True)
    )


def _singleton(value: object) -> object:
    if isinstance(value, list):
        items = cast("list[object]", value)
        return items[0] if len(items) == 1 else items
    return value


def _singleton_number(row: list[float], label: str) -> float:
    if len(row) != 1:
        raise EpisodeRrdError(f"{label} row must contain one scalar")
    return _scalar(row[0], label)


def _scalar(value: object, label: str) -> float:
    """One number out of an *array* — the kit reads fields, arrays are this file's."""
    if not isinstance(value, int | float) or isinstance(value, bool):
        raise EpisodeRrdError(f"episode metadata {label} must be a number")
    return float(value)


def _required_text(document: Mapping[str, object], name: str) -> str:
    """Episode metadata that is blank identifies nothing — the one rule beyond the kit."""
    value = decode.text(document, name, where="episode metadata", error=EpisodeRrdError)
    if not value:
        raise EpisodeRrdError(f"episode metadata needs non-empty {name}")
    return value
