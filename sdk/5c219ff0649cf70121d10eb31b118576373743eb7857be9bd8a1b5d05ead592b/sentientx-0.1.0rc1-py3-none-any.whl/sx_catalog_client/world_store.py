"""The catalog-backed ``sx_worlds.SceneAssetReader`` — scene bytes come from the catalog.

A ``Scene`` is a path-free value: it names its closure by content, and an engine can only
load it once someone has proven those bytes locally. ``sx_worlds.materialize_scene`` does the
proving and owns the layout; all it needs is a reader. This is that reader, over this
package's typed client, so a caller materializes a governed scene with

    materialize_scene(scene, CatalogSceneAssets(client, scene_id), workdir)

and the verification, the closure ordering, and the logical-path layout stay in one place
rather than being re-implemented per backend. The old ``CatalogWorldAssetStore`` — which
carried its own cache, its own digest checks, and a mutable ``mjcf_path`` — is gone with the
``WorldAssetStore`` Protocol it conformed to.
"""

from __future__ import annotations

import hashlib
import tempfile
from pathlib import Path

from sx_contracts.assets import AssetRef

from sx_catalog_client.client import CatalogClient, CatalogNotFoundError


class SceneNotRegisteredError(KeyError):
    """Resolving a scene id the catalog does not hold."""


class SceneAssetUnavailableError(ValueError):
    """The catalog could not produce the bytes an asset names."""


class CatalogSceneAssets:
    """Content bytes for one registered scene, cached by digest across reads.

    The cache is keyed by digest, never by name: two scenes sharing a mesh share the
    fetch, and a byte that fails its own digest is never returned to the materializer.
    """

    def __init__(
        self, client: CatalogClient, scene_id: str, cache_dir: str | Path | None = None
    ) -> None:
        self._client = client
        self._scene_id = scene_id
        self._cache = Path(cache_dir) if cache_dir is not None else Path(tempfile.gettempdir())

    def read(self, asset: AssetRef) -> bytes:
        digest = str(asset.content.sha256)
        cached = self._cache / "sx-scene-assets" / digest
        if cached.is_file():
            payload = cached.read_bytes()
            if hashlib.sha256(payload).hexdigest() == digest:
                return payload
        cached.parent.mkdir(parents=True, exist_ok=True)
        try:
            self._client.download_scene_asset(self._scene_id, digest, cached)
        except CatalogNotFoundError as error:
            raise SceneNotRegisteredError(self._scene_id) from error
        payload = cached.read_bytes()
        if hashlib.sha256(payload).hexdigest() != digest:
            raise SceneAssetUnavailableError(
                f"catalog bytes for {digest} do not hash to their own digest"
            )
        return payload
