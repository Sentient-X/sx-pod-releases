"""Typed Catalog client for canonical domain values, bytes, and durable operations."""

from __future__ import annotations

import os
import time
from collections.abc import Callable, Iterator, Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from enum import StrEnum
from pathlib import Path
from typing import IO, TYPE_CHECKING, ClassVar, Never, Protocol, cast
from uuid import UUID, uuid4

import httpx
from connectrpc.code import Code
from connectrpc.errors import ConnectError
from protovalidate import ValidationError, Validator
from pyqwest import Headers as PyqwestHeaders
from pyqwest import SyncClient as PyqwestClient
from pyqwest import SyncRequest as PyqwestRequest
from pyqwest import SyncResponse as PyqwestResponse
from pyqwest import SyncTransport as PyqwestTransport
from sentientx.sx.common.v1 import common_pb2
from sentientx.sx.experience.catalog.v1 import (
    annotations_connect,
    annotations_pb2,
    applications_connect,
    applications_pb2,
    catalog_connect,
    catalog_pb2,
    evidence_connect,
    evidence_pb2,
    membership_connect,
    membership_pb2,
    operations_connect,
    operations_pb2,
    pipelines_connect,
    pipelines_pb2,
)
from sx_actions import (
    ActionInterface,
    ActionInterfaceError,
    ActionInterfaceId,
    action_interface_from_dict,
    action_interface_to_dict,
)
from sx_auth.credentials import SESSION_COOKIE, DelegatedCredential, PresentedCredential
from sx_auth.principal import CredentialKind, ProjectId
from sx_autonomy import (
    ApplicationQualification,
    CapabilityApproval,
    EvidenceAttestation,
)
from sx_catalog_protocol import (
    ProtocolTransformError,
    admitted_plan_from_proto,
    annotation_stage_from_proto,
    annotation_to_proto,
    application_qualification_from_proto,
    application_qualification_to_proto,
    asset_to_proto,
    capability_approval_from_proto,
    capability_approval_to_proto,
    capture_receipt_to_canonical_json,
    content_ref_from_proto,
    content_ref_to_proto,
    corpus_snapshot_from_proto,
    deployable_policy_from_proto,
    deployable_policy_to_proto,
    embodiment_from_proto,
    embodiment_to_proto,
    operation_receipt_from_proto,
    pipeline_plan_to_proto,
    robot_application_from_proto,
    robot_application_to_proto,
    run_phase_from_proto,
    run_receipt_from_proto,
    task_contract_from_proto,
    task_contract_ref_from_proto,
    task_contract_ref_to_proto,
    world_run_from_proto,
    world_run_to_proto,
)
from sx_contracts import (
    Access,
    AnnotationStage,
    ArtifactId,
    CaptureArtifactFormat,
    CaptureArtifactManifest,
    CaptureSessionReceipt,
    ComputeExecutionId,
    ComputeOutput,
    ComputeOutputKind,
    ContentRef,
    DatasetKind,
    DatasetSnapshotId,
    DeliverySourceManifest,
    DeployablePolicy,
    EpisodeAnnotation,
    InnerAgent,
    ObjectRead,
    ObjectReads,
    OperationId,
    OperationKind,
    OperationReceipt,
    OperationRef,
    OperationState,
    PlatformPillar,
    QueryPlane,
    Representation,
    RepresentationFormat,
    RobotApplication,
    SchemaId,
    Sha256Digest,
    TaskContract,
    TaskContractRef,
    VlaPolicy,
    annotation_sha256,
    capture_receipt_sha256,
    contract_ref,
    decode,
    deployable_policy_to_dict,
    match_capabilities,
)
from sx_contracts.assets import AssetRef, AssetRole, ProvenancedAsset
from sx_contracts.identity import (
    CanonicalDocument,
    JsonValue,
    content_digest,
    file_digest,
    stream_blob,
)
from sx_contracts.pipelines import (
    AdmittedPlan,
    PipelinePlan,
    RunPhase,
)
from sx_corpora import (
    CorpusName,
    CorpusSnapshot,
)
from sx_embodiments import Embodiment, EmbodimentId
from sx_worlds import (
    EnvironmentBundle,
    EnvironmentContractError,
    ObjectAssetBundle,
    ObjectAssetContractError,
    PolicyArtifactKind,
    Scene,
    SceneContractError,
    SuiteManifest,
    WorldRun,
    environment_from_dict,
    environment_to_dict,
    object_asset_from_dict,
    object_asset_to_dict,
    scene_from_dict,
    scene_to_dict,
    suite_digest,
    suite_from_dict,
    suite_to_dict,
)

_PROTO_VALIDATOR = Validator()

if TYPE_CHECKING:
    from sx_episodes import EpisodeLayerSummary, EpisodeSummary
    from sx_episodes.atif import AgentLayerSummary

type NativeLayerSummary = EpisodeLayerSummary | AgentLayerSummary


class _ConnectHttpxTransport(PyqwestTransport):
    """Let the existing explicit HTTP test transport exercise generated Connect calls."""

    def __init__(self, transport: httpx.BaseTransport) -> None:
        self._transport = transport

    def execute_sync(self, request: PyqwestRequest) -> PyqwestResponse:
        content = request.content
        payload = content if isinstance(content, bytes) else b"".join(content)
        response = self._transport.handle_request(
            httpx.Request(
                request.method,
                request.url,
                headers=dict(request.headers),
                content=payload,
            )
        )
        response.read()
        headers = PyqwestHeaders()
        for name, value in response.headers.multi_items():
            headers.add(name, value)
        return PyqwestResponse(
            status=response.status_code,
            headers=headers,
            content=response.content,
        )


class CatalogClientError(RuntimeError):
    """A Catalog request failed or returned a malformed contract."""


class CatalogUnavailableError(CatalogClientError):
    """Catalog is transiently unreachable or overloaded; retrying may succeed."""


class CatalogPermissionError(CatalogClientError, PermissionError):
    """Catalog refused the presented identity or its authority."""


@dataclass(frozen=True, slots=True)
class ComputeOutputRead:
    """One short-lived read of finalized compute candidate bytes."""

    output: ComputeOutput
    size_bytes: int
    object: ObjectRead

    def __post_init__(self) -> None:
        if isinstance(self.size_bytes, bool) or self.size_bytes < 0:
            raise CatalogClientError("compute output size must be non-negative")
        if self.object.sha256 != self.output.content.sha256:
            raise CatalogClientError("compute output read grant names different bytes")


def validate_native_layer(path: Path) -> NativeLayerSummary:
    """Parse either implemented typed layer without inventing a parallel layer schema."""
    from sx_episodes import EpisodeLayerError, validate_episode_layer
    from sx_episodes.atif import AgentTraceError, validate_agent_episode_layer

    try:
        return validate_agent_episode_layer(path)
    except AgentTraceError as agent_error:
        try:
            return validate_episode_layer(path)
        except EpisodeLayerError as episode_error:
            raise CatalogClientError(
                f"RRD is neither an agent layer nor an episode annotation layer: "
                f"{agent_error}; {episode_error}"
            ) from episode_error


class CatalogNotFoundError(CatalogClientError, LookupError):
    """The catalog has no resource with the requested identity (HTTP 404).

    Also a ``LookupError`` so callers gating on "unknown id" (the Fleet promotion
    door) can distinguish absence from an outage without matching message text.
    """


class CompositionBindingConflictError(CatalogClientError):
    """Checkpoint lineage has zero or multiple deployable bindings."""


class CatalogDigestMismatchError(CatalogClientError):
    """A content-pinned reference names live Catalog bytes with another digest."""


class CatalogRegistrationFailed(CatalogClientError):
    """Catalog rejected or failed an episode registration."""


class CatalogRegistrationTimeout(CatalogClientError):
    """Catalog did not reach READY before the caller's batch deadline."""


class RegistrationState(StrEnum):
    RUNNING = "running"
    READY = "completed"
    FAILED = "failed"


class RegistrationConflict(StrEnum):
    ERROR = "error"
    OVERWRITE = "overwrite"


class MultipartUploadState(StrEnum):
    INITIATED = "initiated"
    COMPLETED = "completed"
    ABORTED = "aborted"


type OperationRpc = operations_connect.CatalogOperationServiceClientSync

# How long each admission may run before the owner abandons it. These were the
# defaults of the deleted request models; the caller that asks for the work is
# where they belong, because the owner never invents a bound of its own.
_ASSET_TIMEOUT_S = 1_800
_SEGMENT_TIMEOUT_S = 1_800
_BATCH_TIMEOUT_S = 21_600
_CAPTURE_TIMEOUT_S = 7_200
_CHECKPOINT_TIMEOUT_S = 7_200
_POLICY_TIMEOUT_S = 7_200
_EXPORT_TIMEOUT_S = 7_200

_DUPLICATE_POLICY = {
    RegistrationConflict.ERROR: operations_pb2.DUPLICATE_SEGMENT_POLICY_ERROR,
    RegistrationConflict.OVERWRITE: operations_pb2.DUPLICATE_SEGMENT_POLICY_OVERWRITE,
}
_CAPTURE_FORMATS = {
    CaptureArtifactFormat.MCAP: operations_pb2.CAPTURE_ARTIFACT_FORMAT_MCAP,
    CaptureArtifactFormat.LEROBOT_V3_TAR: operations_pb2.CAPTURE_ARTIFACT_FORMAT_LEROBOT_V3_TAR,
    CaptureArtifactFormat.SIMULATION_JSON: operations_pb2.CAPTURE_ARTIFACT_FORMAT_SIMULATION_JSON,
}


def _arm(
    result: operations_pb2.CatalogOperationResult, expected: str
) -> operations_pb2.CatalogOperationResult:
    """Prove the owner settled the family that asked, before anything is read off it."""

    arm = result.WhichOneof("result")
    if arm != expected:
        raise CatalogRegistrationFailed(
            f"Catalog completed a {arm!r} operation where {expected!r} was registered"
        )
    return result


def _capture_manifest(
    manifest: CaptureArtifactManifest,
) -> operations_pb2.CaptureArtifactManifest:
    """One sealed raw-artifact manifest, exactly as the admission declares it."""

    artifact_format = _CAPTURE_FORMATS.get(manifest.format)
    if artifact_format is None:
        raise CatalogClientError(f"unsupported capture artifact format {manifest.format!r}")
    return operations_pb2.CaptureArtifactManifest(
        schema_version=manifest.schema_version,
        format=artifact_format,
        sha256=str(manifest.sha256),
        size_bytes=manifest.size_bytes,
        episode_ids=[str(episode) for episode in manifest.episode_ids],
        files=[
            operations_pb2.CaptureArtifactFile(
                path=item.path, sha256=str(item.sha256), size_bytes=item.size_bytes
            )
            for item in manifest.files
        ],
    )


def _segment_request(
    *,
    dataset: str,
    source_uri: str,
    sha256: Sha256Digest,
    layer: str,
    on_duplicate: RegistrationConflict,
    capture: CaptureEvidence | None,
) -> operations_pb2.RegisterSegmentRequest:
    """The one segment admission both the base and the overlay lanes send."""

    request = operations_pb2.RegisterSegmentRequest(
        dataset=dataset,
        source_uri=source_uri,
        source_format=operations_pb2.SEGMENT_SOURCE_FORMAT_RRD,
        source_sha256=str(sha256),
        layer=layer,
        on_duplicate=_DUPLICATE_POLICY[on_duplicate],
        timeout=timedelta(seconds=_SEGMENT_TIMEOUT_S),
    )
    if capture is not None:
        request.capture.receipt_json = capture_receipt_to_canonical_json(capture.receipt)
        request.capture.episode_id = capture.episode_id
    return request


class Registrable[C](Protocol):
    """A Catalog registration request: which admission it calls, and what its
    terminal result must prove.

    One record owns its family's whole round trip. ``result`` is why completion can
    be total: the proof lives beside the request that demanded it, so a caller never
    reads identities off a status document and hopes they belong to its own workflow.
    """

    operation_kind: ClassVar[OperationKind]

    def admit(
        self, rpc: OperationRpc, headers: Mapping[str, str]
    ) -> operations_pb2.CatalogOperation:
        """Call this family's own admission and return the operation it minted."""
        ...

    def result(self, result: operations_pb2.CatalogOperationResult, resource_ref: str) -> C:
        """What a successful operation result proves, or a typed refusal.

        The owner answers with one closed result arm plus the resource it says the
        operation governs; the request proves both name what it submitted.
        """
        ...


@dataclass(frozen=True, slots=True)
class CatalogOperation[C]:
    """One canonical operation reference plus its family-specific result proof."""

    ref: OperationRef[C, Mapping[str, object]]
    resource_ref: str
    request: Registrable[C]

    @property
    def id(self) -> str:
        return str(self.ref.operation_id)


@dataclass(frozen=True, slots=True)
class BatchEpisodeUpload:
    """One completed multipart object and the segment identity its RRD must carry."""

    episode_id: str
    upload_id: UUID
    sha256: Sha256Digest

    def __post_init__(self) -> None:
        if not self.episode_id.strip() or self.episode_id != self.episode_id.strip():
            raise CatalogClientError("batch episode identity must be non-empty and trimmed")
        if len(self.sha256) != 64 or any(c not in "0123456789abcdef" for c in self.sha256):
            raise CatalogClientError("batch episode sha256 must be lowercase hexadecimal")


@dataclass(frozen=True, slots=True)
class RegisteredEpisode:
    workflow_id: str
    segment_id: str
    sha256: Sha256Digest
    summary: EpisodeSummary


@dataclass(frozen=True, slots=True)
class RegisteredLayer:
    workflow_id: str
    segment_id: str
    sha256: Sha256Digest
    summary: NativeLayerSummary


@dataclass(frozen=True, slots=True)
class EpisodeStatus:
    segment_id: str
    state: RegistrationState


@dataclass(frozen=True, slots=True)
class InitiatedStagingUpload:
    """One active multipart upload, idempotent by caller key and filename."""

    upload_id: UUID
    source_uri: str
    part_size_bytes: int
    expires_in_s: int


@dataclass(frozen=True, slots=True)
class CompletedStagingUpload:
    """An idempotent begin found the already-completed immutable object."""

    upload_id: UUID
    source_uri: str
    part_size_bytes: int
    expires_in_s: int
    size_bytes: int


@dataclass(frozen=True, slots=True)
class AbortedStagingUpload:
    """The caller's stable upload identity was explicitly aborted."""

    upload_id: UUID
    source_uri: str
    part_size_bytes: int
    expires_in_s: int


StagingUpload = InitiatedStagingUpload | CompletedStagingUpload | AbortedStagingUpload


@dataclass(frozen=True, slots=True)
class MultipartPart:
    part_number: int
    etag: str

    def __post_init__(self) -> None:
        if not 1 <= self.part_number <= 10_000:
            raise CatalogClientError("multipart part number must be between 1 and 10000")
        if not self.etag:
            raise CatalogClientError("multipart part ETag must be non-empty")


@dataclass(frozen=True, slots=True)
class MultipartPartGrant:
    upload_id: UUID
    part_number: int
    url: str
    expires_in_s: int


@dataclass(frozen=True, slots=True)
class StagedObject:
    upload_id: UUID
    source_uri: str
    size_bytes: int


@dataclass(frozen=True, slots=True)
class CaptureEvidence:
    """The sealed capture receipt plus the one episode a registration represents.

    Carried into segment registration so the trainable joins the capture-session
    lineage node the capture registration minted.
    """

    receipt: CaptureSessionReceipt
    episode_id: str

    def __post_init__(self) -> None:
        if not self.episode_id:
            raise CatalogClientError("capture evidence needs the episode id")


@dataclass(frozen=True, slots=True)
class CaptureArtifactSource:
    """One immutable raw artifact plus the staged replica Catalog must promote."""

    manifest: CaptureArtifactManifest
    source_uri: str

    def __post_init__(self) -> None:
        if not self.source_uri:
            raise CatalogClientError("capture artifact source URI must be non-empty")


@dataclass(frozen=True, slots=True)
class DeployablePolicyRecord:
    """The catalog's governed runnable-policy lineage used by Worlds and Fleet."""

    name: str
    policy: DeployablePolicy
    task: TaskContractRef
    embodiment_id: EmbodimentId
    action_interface_id: ActionInterfaceId
    dataset: str


@dataclass(frozen=True, slots=True)
class TrainingCheckpointRecord:
    name: str
    checkpoint: ContentRef
    size_bytes: int
    corpus: CorpusName
    corpus_sha256: Sha256Digest
    source_uri: str


@dataclass(frozen=True, slots=True)
class CapabilityApprovalRecord:
    """One governed task approval plus Catalog's evidence attestation."""

    name: str
    approval: CapabilityApproval
    evidence_attestation: EvidenceAttestation


@dataclass(frozen=True, slots=True)
class WorldRunRecord:
    """One catalog-registered Worlds run: the complete evidence body plus catalog facts."""

    name: str
    run: WorldRun
    created_at: datetime


@dataclass(frozen=True, slots=True)
class SegmentAnnotationRecord:
    """What Catalog stored for one segment's reviewed annotation.

    The document is not echoed: a registrant already holds the annotation it
    sent, so the record carries only what Catalog derived — the digest that
    enters the segment's content fingerprint, the stage it filed the review
    under, and when it landed.
    """

    dataset: str
    segment_id: str
    stage: AnnotationStage
    sha256: Sha256Digest
    annotated_at: datetime


@dataclass(frozen=True, slots=True)
class ApplicationQualificationRecord:
    qualification: ApplicationQualification
    created_at: datetime


@dataclass(frozen=True, slots=True)
class RobotApplicationRecord:
    name: str
    application: RobotApplication
    created_at: datetime


@dataclass(frozen=True, slots=True)
class SuiteRecord:
    """One catalog-registered evaluation suite: the manifest plus its content address.

    ``sha256`` is the catalog's stored digest, verified here against a local
    ``suite_digest`` of the parsed manifest — a contract's ``GateSuiteRef`` pins
    that pair, so a resource whose two halves disagree is refused, not trusted.
    """

    name: str
    suite_id: str
    sha256: Sha256Digest
    manifest: SuiteManifest
    created_at: datetime


@dataclass(frozen=True, slots=True)
class PolicyArtifactRecord:
    """One catalog-registered policy artifact: the canonical document an agent
    authored, plus its content address.

    ``content`` crosses as the raw document on purpose — the policy vocabulary
    (``sx_policies``) belongs to whoever executes it, so a resolver parses it into
    a ``PolicyGraph`` or a ``CodePolicy`` while this client stays kind-agnostic.
    What the client does own is the pin: ``sha256`` is re-derived from the document
    here, so an artifact whose two halves disagree never reaches a runner.
    """

    artifact_id: str
    kind: PolicyArtifactKind
    name: str
    sha256: Sha256Digest
    content: Mapping[str, object]
    created_at: datetime


@dataclass(frozen=True, slots=True)
class DatasetRecord:
    """One catalog dataset entry: the governed destination a producer writes into.

    Resolved before work is accepted (a Worlds generation naming an unknown
    dataset is refused up front, not after a run has produced episodes).
    """

    id: UUID
    project_id: UUID
    name: str
    created_at: datetime
    updated_at: datetime


@dataclass(frozen=True, slots=True)
class SnapshotFacts:
    """One immutable membership, as the control plane holds it.

    Every field is fixed-width, and that is the contract: there is no member list
    here and there must never be one. `members` says how many there are; *which*
    ones is the Parquet index, read through the ordinary entry grant.

    A plain value, so it persists into a job row or an exported artifact and comes
    back without a live catalog: reading a membership needs one, saying exactly
    which membership was read does not.
    """

    id: DatasetSnapshotId
    dataset: str
    schema_id: SchemaId
    members: int
    member_bytes: int
    parts: int

    def __post_init__(self) -> None:
        if not self.dataset.strip():
            raise CatalogClientError(f"snapshot {self.id} names no dataset")
        if self.members <= 0 or self.parts <= 0 or self.member_bytes < 0:
            raise CatalogClientError(f"snapshot {self.id} claims no membership to read")

    def to_dict(self) -> dict[str, str | int]:
        return {
            "id": str(self.id),
            "dataset": self.dataset,
            "schema_id": str(self.schema_id),
            "members": self.members,
            "member_bytes": self.member_bytes,
            "parts": self.parts,
        }


def snapshot_facts_from_dict(value: object) -> SnapshotFacts:
    """Parse persisted snapshot facts, rejecting an incomplete or altered record."""
    document = decode.exactly(
        decode.document(value, where="snapshot facts", error=CatalogClientError),
        {"id", "dataset", "schema_id", "members", "member_bytes", "parts"},
        where="snapshot facts",
    )
    try:
        return SnapshotFacts(
            id=DatasetSnapshotId(_text(document, "id")),
            dataset=_text(document, "dataset"),
            schema_id=SchemaId(_text(document, "schema_id")),
            members=_integer(document, "members"),
            member_bytes=_integer(document, "member_bytes"),
            parts=_integer(document, "parts"),
        )
    except ValueError as error:
        raise CatalogClientError(f"invalid snapshot facts: {error}") from error


@dataclass(frozen=True, slots=True)
class DeliverySourceRegistration:
    dataset: str
    segment_id: str
    manifest_sha256: Sha256Digest
    registered_at: datetime


@dataclass(frozen=True, slots=True)
class PipelineRun:
    """One submitted run: the platform receipt, and what a run adds to one.

    The receipt is not copied into fields here — it *is* the receipt, so the state,
    cursor, failure, cancellation and timestamps have one definition and this value
    cannot drift from it. Beside it sit the two facts a receipt has no room for: the
    live phase, and the snapshot the run published.
    """

    receipt: OperationReceipt
    plan_digest: Sha256Digest
    destination: str
    phase: RunPhase | None
    output_snapshot: UUID | None

    @property
    def run_id(self) -> OperationId:
        return self.receipt.operation_id

    @property
    def state(self) -> OperationState:
        return self.receipt.state

    @property
    def settled(self) -> bool:
        """Whether polling this run again can still change the answer."""
        return self.state in {
            OperationState.SUCCEEDED,
            OperationState.FAILED,
            OperationState.CANCELLED,
        }


# --- the registration requests -----------------------------------------------------------
#
# Every durable Catalog registration is the same three-step story: POST a document, retain
# its canonical operation ref, and decode the owner result. The families differ only in what
# they send and what "proved" means, so that pair — and nothing else — is what each record owns.
# Bytes are staged by the ``of`` constructors, so a record is a pure value by the time it
# reaches the wire and its ``body`` is a total function of facts already established.


@dataclass(frozen=True, slots=True)
class EpisodeUpload:
    """One exact v8 RRD staged for registration as a dataset segment."""

    operation_kind: ClassVar[OperationKind] = OperationKind.REGISTRATION

    dataset: str
    source_uri: str
    sha256: Sha256Digest
    summary: EpisodeSummary
    on_duplicate: RegistrationConflict = RegistrationConflict.ERROR
    capture: CaptureEvidence | None = None

    @classmethod
    def of(
        cls,
        catalog: CatalogClient,
        dataset: str,
        path: Path,
        *,
        on_duplicate: RegistrationConflict = RegistrationConflict.ERROR,
        capture: CaptureEvidence | None = None,
    ) -> EpisodeUpload:
        """Validate, hash, and stage one local RRD into a registrable request."""
        from sx_episodes import validate_episode

        if not dataset.strip():
            raise CatalogClientError("Catalog dataset name must be non-empty")
        summary = validate_episode(path)
        digest = file_digest(path)
        staged = catalog.stage_file(
            path, idempotency_key=digest, filename=f"{summary.episode_id}.rrd"
        )
        return cls(dataset, staged.source_uri, digest, summary, on_duplicate, capture)

    def admit(
        self, rpc: OperationRpc, headers: Mapping[str, str]
    ) -> operations_pb2.CatalogOperation:
        return rpc.register_segment(
            _segment_request(
                dataset=self.dataset,
                source_uri=self.source_uri,
                sha256=self.sha256,
                layer="base",
                on_duplicate=self.on_duplicate,
                capture=self.capture,
            ),
            headers=headers,
        ).operation

    def result(self, result: operations_pb2.CatalogOperationResult, resource_ref: str) -> str:
        """The immutable segment the bytes registered as."""
        del resource_ref  # the arm carries the segment's own dataset and digest
        segment = _arm(result, "segment").segment
        if segment.dataset_id != self.dataset:
            raise CatalogRegistrationFailed("Catalog registered bytes in another dataset")
        if segment.base_sha256 != self.sha256:
            raise CatalogRegistrationFailed("Catalog registered different episode bytes")
        return segment.segment_id


@dataclass(frozen=True, slots=True)
class LayerUpload:
    """One exact typed overlay staged for attachment to its pinned base."""

    operation_kind: ClassVar[OperationKind] = OperationKind.REGISTRATION

    dataset: str
    source_uri: str
    sha256: Sha256Digest
    summary: NativeLayerSummary
    on_duplicate: RegistrationConflict = RegistrationConflict.ERROR

    @classmethod
    def of(
        cls,
        catalog: CatalogClient,
        dataset: str,
        path: Path,
        *,
        on_duplicate: RegistrationConflict = RegistrationConflict.ERROR,
    ) -> LayerUpload:
        """Validate, hash, and stage one local overlay RRD into a registrable request."""
        if not dataset.strip():
            raise CatalogClientError("Catalog dataset name must be non-empty")
        summary = validate_native_layer(path)
        digest = file_digest(path)
        staged = catalog.stage_file(
            path,
            idempotency_key=digest,
            filename=f"{summary.recording_id.replace('/', '_')}.{summary.kind.value}.rrd",
        )
        return cls(dataset, staged.source_uri, digest, summary, on_duplicate)

    def admit(
        self, rpc: OperationRpc, headers: Mapping[str, str]
    ) -> operations_pb2.CatalogOperation:
        return rpc.register_segment(
            _segment_request(
                dataset=self.dataset,
                source_uri=self.source_uri,
                sha256=self.sha256,
                layer=self.summary.kind.value,
                on_duplicate=self.on_duplicate,
                capture=None,
            ),
            headers=headers,
        ).operation

    def result(self, result: operations_pb2.CatalogOperationResult, resource_ref: str) -> str:
        """The segment the overlay attached to."""
        del resource_ref  # the arm carries the segment's own dataset
        segment = _arm(result, "segment").segment
        if segment.dataset_id != self.dataset:
            raise CatalogRegistrationFailed("Catalog attached the layer in another dataset")
        return segment.segment_id


@dataclass(frozen=True, slots=True)
class CaptureUpload:
    """One sealed capture session: the receipt plus every episode's staged bytes.

    Byte-complete or rejected — Catalog refuses a registration whose artifact set is
    not exactly the receipt's episode set, failures included. ``instruction`` is the
    text shown during execution, a capture fact the sealed receipt does not carry.
    """

    operation_kind: ClassVar[OperationKind] = OperationKind.CAPTURE_REGISTRATION

    receipt: CaptureSessionReceipt
    artifacts: tuple[CaptureArtifactSource, ...]
    instruction: str

    def __post_init__(self) -> None:
        if not self.instruction.strip():
            raise CatalogClientError("capture registration needs the executed instruction")

    def admit(
        self, rpc: OperationRpc, headers: Mapping[str, str]
    ) -> operations_pb2.CatalogOperation:
        request = operations_pb2.RegisterCaptureRequest(
            receipt_json=capture_receipt_to_canonical_json(self.receipt),
            instruction=self.instruction,
            artifacts=[
                operations_pb2.CaptureArtifact(
                    source_uri=artifact.source_uri,
                    manifest=_capture_manifest(artifact.manifest),
                )
                for artifact in self.artifacts
            ],
            timeout=timedelta(seconds=_CAPTURE_TIMEOUT_S),
        )
        return rpc.register_capture(request, headers=headers).operation

    def result(self, result: operations_pb2.CatalogOperationResult, resource_ref: str) -> str:
        """The capture session Catalog made durable — never a segment, which a
        capture does not mint."""
        del resource_ref  # the arm carries the session id and its receipt digest
        capture = _arm(result, "capture").capture
        if capture.receipt_sha256 != str(capture_receipt_sha256(self.receipt)):
            raise CatalogRegistrationFailed("Catalog registered another capture receipt")
        return capture.session_id


@dataclass(frozen=True, slots=True)
class BatchUpload:
    """One native-RRD batch, registered after all its multipart uploads complete."""

    operation_kind: ClassVar[OperationKind] = OperationKind.BATCH_REGISTRATION

    dataset: str
    idempotency_key: str
    batch_ref: str
    episodes: tuple[BatchEpisodeUpload, ...]

    def __post_init__(self) -> None:
        identities = (self.dataset, self.idempotency_key, self.batch_ref)
        if any(not value.strip() or value != value.strip() for value in identities):
            raise CatalogClientError(
                "Catalog batch registration needs trimmed dataset, idempotency key, and batch ref"
            )
        if not self.episodes:
            raise CatalogClientError("Catalog batch registration needs at least one episode")
        if len({episode.episode_id for episode in self.episodes}) != len(self.episodes):
            raise CatalogClientError("Catalog batch registration repeats an episode")
        if len({episode.upload_id for episode in self.episodes}) != len(self.episodes):
            raise CatalogClientError("Catalog batch registration repeats an upload")

    def admit(
        self, rpc: OperationRpc, headers: Mapping[str, str]
    ) -> operations_pb2.CatalogOperation:
        request = operations_pb2.RegisterBatchRequest(
            dataset=self.dataset,
            idempotency_key=self.idempotency_key,
            batch_ref=self.batch_ref,
            episodes=[
                operations_pb2.BatchEpisode(
                    episode_id=episode.episode_id,
                    upload_id=str(episode.upload_id),
                    source_sha256=str(episode.sha256),
                )
                for episode in self.episodes
            ],
            timeout=timedelta(seconds=_BATCH_TIMEOUT_S),
        )
        return rpc.register_batch(request, headers=headers).operation

    def result(
        self, result: operations_pb2.CatalogOperationResult, resource_ref: str
    ) -> tuple[str, ...]:
        """Every segment the batch minted, under the batch identity it was accepted as."""
        batch = _arm(result, "batch").batch
        if _uuid(batch.batch_id, "batch identity") != _batch_id(resource_ref):
            raise CatalogClientError("Catalog batch receipt changed its identity")
        segment_ids = tuple(batch.segment_ids)
        if not segment_ids:
            raise CatalogClientError("a READY batch must identify its segments")
        if len(set(segment_ids)) != len(segment_ids):
            raise CatalogClientError("a batch receipt cannot repeat a segment")
        return segment_ids


@dataclass(frozen=True, slots=True)
class CheckpointUpload:
    """One staged foundation checkpoint bound to its exact training corpus.

    The bytes are already staged (:meth:`CatalogClient.stage_file`); this publishes
    the shared weights and their corpus lineage. It claims no deployability: Train
    exports a separate runnable artifact for a concrete domain and runtime.
    """

    operation_kind: ClassVar[OperationKind] = OperationKind.TRAINING_CHECKPOINT_REGISTRATION

    name: str
    source_uri: str
    size_bytes: int
    checkpoint: ContentRef
    corpus: CorpusName
    corpus_sha256: Sha256Digest

    def __post_init__(self) -> None:
        if not self.name.strip() or not self.source_uri.strip():
            raise CatalogClientError("training checkpoint registration needs a name and source URI")
        if self.size_bytes <= 0:
            raise CatalogClientError("training checkpoint byte size must be positive")

    def admit(
        self, rpc: OperationRpc, headers: Mapping[str, str]
    ) -> operations_pb2.CatalogOperation:
        request = operations_pb2.RegisterTrainingCheckpointRequest(
            name=self.name,
            source_uri=self.source_uri,
            size_bytes=self.size_bytes,
            checkpoint=content_ref_to_proto(self.checkpoint),
            corpus=str(self.corpus),
            corpus_sha256=str(self.corpus_sha256),
            timeout=timedelta(seconds=_CHECKPOINT_TIMEOUT_S),
        )
        return rpc.register_training_checkpoint(request, headers=headers).operation

    def result(
        self, result: operations_pb2.CatalogOperationResult, resource_ref: str
    ) -> ContentRef:
        """The exact checkpoint Catalog durably recorded.

        A completion naming another checkpoint, or a digest other than the one the
        caller staged, is a failed registration: a publisher never reports weights
        the catalog did not record from exactly those bytes.
        """
        try:
            recorded = content_ref_from_proto(_arm(result, "checkpoint").checkpoint.checkpoint)
        except ProtocolTransformError as error:
            raise CatalogClientError("Catalog returned a malformed checkpoint ref") from error
        if recorded != self.checkpoint:
            raise CatalogRegistrationFailed("Catalog registration completed another checkpoint")
        return recorded


@dataclass(frozen=True, slots=True)
class PolicyUpload:
    """One runnable policy artifact staged with its source-checkpoint lineage."""

    operation_kind: ClassVar[OperationKind] = OperationKind.POLICY_REGISTRATION

    name: str
    source_uri: str
    size_bytes: int
    policy: DeployablePolicy
    task: TaskContractRef
    embodiment_id: EmbodimentId
    action_interface_id: ActionInterfaceId
    dataset: str

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise CatalogClientError("Catalog policy registration needs a name")
        if not self.dataset.strip():
            raise CatalogClientError("Catalog policy registration needs a contributing dataset")

    @classmethod
    def of(
        cls,
        catalog: CatalogClient,
        *,
        name: str,
        path: Path,
        policy: DeployablePolicy,
        task: TaskContractRef,
        embodiment_id: EmbodimentId,
        action_interface_id: ActionInterfaceId,
        dataset: str,
    ) -> PolicyUpload:
        """Verify the local bytes against the declared artifact and stage them."""
        if file_digest(path) != str(policy.artifact.sha256):
            raise CatalogClientError("policy artifact digest does not match the staged file")
        staged = catalog.stage_file(
            path,
            idempotency_key=str(policy.artifact.sha256),
            filename=f"{policy.artifact.sha256}.tar",
        )
        return cls(
            name=name,
            source_uri=staged.source_uri,
            size_bytes=path.stat().st_size,
            policy=policy,
            task=task,
            embodiment_id=embodiment_id,
            action_interface_id=action_interface_id,
            dataset=dataset,
        )

    def admit(
        self, rpc: OperationRpc, headers: Mapping[str, str]
    ) -> operations_pb2.CatalogOperation:
        request = operations_pb2.RegisterPolicyRequest(
            name=self.name,
            source_uri=self.source_uri,
            size_bytes=self.size_bytes,
            policy=deployable_policy_to_proto(self.policy),
            task=task_contract_ref_to_proto(self.task),
            embodiment_id=str(self.embodiment_id),
            action_interface_id=str(self.action_interface_id),
            dataset=self.dataset,
            timeout=timedelta(seconds=_POLICY_TIMEOUT_S),
        )
        return rpc.register_policy(request, headers=headers).operation

    def result(
        self, result: operations_pb2.CatalogOperationResult, resource_ref: str
    ) -> DeployablePolicy:
        """The runnable policy Catalog registered, proved against the submitted bytes."""
        del resource_ref  # the arm carries the policy's own artifact identity
        resource = _arm(result, "policy").policy
        artifact = resource.policy.artifact
        if artifact.artifact_id != str(self.policy.artifact.artifact_id):
            raise CatalogRegistrationFailed("Catalog registered another policy artifact")
        if artifact.sha256 != str(self.policy.artifact.sha256):
            raise CatalogRegistrationFailed("Catalog registered different policy bytes")
        return self.policy


def _asset_ref_wire(ref: AssetRef) -> dict[str, object]:
    """One `AssetRef` as the catalog's asset doors read it.

    Two doors carry this value — `POST /api/assets` promotes one blob, and
    `POST /api/asset-packs` names a set of already-promoted ones — so the shape is
    written once here rather than twice at the call sites that would then drift.
    """
    return {
        "location": ref.location,
        "content": {
            "sha256": str(ref.content.sha256),
            "size_bytes": ref.content.size_bytes,
        },
        "format": ref.format.value,
        "role": ref.role.value,
        "media_type": ref.media_type,
        "logical_path": None if ref.logical_path is None else str(ref.logical_path),
    }


@dataclass(frozen=True, slots=True)
class AssetPackMember:
    """One asset a governed pack owns: which content, under which URI, as what."""

    sha256: Sha256Digest
    uri: str
    role: AssetRole


@dataclass(frozen=True, slots=True)
class CatalogAssetPack:
    """One named, immutable set of governed asset bytes."""

    name: str
    members: tuple[AssetPackMember, ...]
    created_at: datetime


@dataclass(frozen=True, slots=True)
class AssetUpload:
    """One staged robotics asset blob, promoted into catalog-managed storage.

    The bytes are staged first and the worker re-hashes them before promotion, so
    the declared :class:`ProvenancedAsset` is a claim the catalog verifies rather
    than metadata it takes on trust. Use :meth:`of`, which refuses a local file
    that does not already match the declaration.
    """

    operation_kind: ClassVar[OperationKind] = OperationKind.ASSET_REGISTRATION

    source_uri: str
    asset: ProvenancedAsset

    @classmethod
    def of(cls, catalog: CatalogClient, asset: ProvenancedAsset, path: Path) -> AssetUpload:
        """Measure the local bytes against the declaration, then stage them."""
        source = path.expanduser()
        measured = AssetRef.from_path(
            source,
            format=asset.format,
            role=asset.role,
            media_type=asset.media_type,
        )
        if measured.sha256 != asset.sha256 or measured.byte_size != asset.byte_size:
            raise CatalogClientError(
                f"local bytes for {asset.uri!r} do not match the declared asset facts"
            )
        staged = catalog.stage_file(
            source,
            idempotency_key=asset.sha256,
            filename=source.name,
        )
        return cls(source_uri=staged.source_uri, asset=asset)

    def admit(
        self, rpc: OperationRpc, headers: Mapping[str, str]
    ) -> operations_pb2.CatalogOperation:
        request = operations_pb2.RegisterAssetRequest(
            source_uri=self.source_uri,
            asset=asset_to_proto(self.asset),
            timeout=timedelta(seconds=_ASSET_TIMEOUT_S),
        )
        return rpc.register_asset(request, headers=headers).operation

    def result(
        self, result: operations_pb2.CatalogOperationResult, resource_ref: str
    ) -> Sha256Digest:
        """The digest Catalog promoted, proved to be the one the caller staged."""
        del resource_ref  # the arm carries the promoted content digest itself
        promoted = _arm(result, "asset").asset.sha256
        if promoted != self.asset.sha256:
            raise CatalogRegistrationFailed("Catalog promoted another asset's bytes")
        return Sha256Digest(promoted)


class CatalogClient:
    """The one cross-pillar Catalog episode client."""

    def __init__(
        self,
        base_url: str,
        *,
        token: str = "",
        api_key: str = "",
        credential: PresentedCredential | DelegatedCredential | None = None,
        project_id: ProjectId | None = None,
        timeout_s: float = 30.0,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        if not base_url.rstrip("/"):
            raise CatalogClientError("Catalog base URL must be non-empty")
        if sum((bool(token), bool(api_key), credential is not None)) > 1:
            raise CatalogClientError("use at most one bearer token, API key, or credential")
        if (token or api_key or credential is not None) and project_id is None:
            raise CatalogClientError("authenticated Catalog clients require an explicit project_id")
        headers: dict[str, str] = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        elif api_key:
            headers["X-API-Key"] = api_key
        elif isinstance(credential, DelegatedCredential):
            if (
                credential.holder.kind is not CredentialKind.API_KEY
                or not credential.holder.raw.strip()
            ):
                raise CatalogClientError("a delegated Catalog holder must be an API key")
            headers["X-API-Key"] = credential.holder.raw
            headers["X-SX-Delegation-Id"] = str(credential.delegation_id)
        elif credential is not None:
            if credential.kind is CredentialKind.SESSION:
                headers["Cookie"] = f"{SESSION_COOKIE}={credential.raw}"
            else:
                headers["X-API-Key"] = credential.raw
        if project_id is not None:
            headers["X-SX-Project-Id"] = str(project_id)
        endpoint = base_url.rstrip("/")
        self._rpc_headers = headers
        self._rpc_timeout_ms = round(timeout_s * 1000)

        def rpc_http() -> PyqwestClient | None:
            return (
                PyqwestClient(transport=_ConnectHttpxTransport(transport))
                if transport is not None
                else None
            )

        self._embodiments = catalog_connect.CatalogEmbodimentServiceClientSync(
            endpoint,
            send_compression=None,
            timeout_ms=self._rpc_timeout_ms,
            http_client=rpc_http(),
        )
        self._tasks = catalog_connect.CatalogTaskServiceClientSync(
            endpoint,
            send_compression=None,
            timeout_ms=self._rpc_timeout_ms,
            http_client=rpc_http(),
        )
        self._applications = applications_connect.CatalogApplicationServiceClientSync(
            endpoint,
            send_compression=None,
            timeout_ms=self._rpc_timeout_ms,
            http_client=rpc_http(),
        )
        self._evidence = evidence_connect.CatalogEvidenceServiceClientSync(
            endpoint,
            send_compression=None,
            timeout_ms=self._rpc_timeout_ms,
            http_client=rpc_http(),
        )
        self._annotations = annotations_connect.CatalogAnnotationServiceClientSync(
            endpoint,
            send_compression=None,
            timeout_ms=self._rpc_timeout_ms,
            http_client=rpc_http(),
        )
        self._pipelines = pipelines_connect.CatalogPipelineServiceClientSync(
            endpoint,
            send_compression=None,
            timeout_ms=self._rpc_timeout_ms,
            http_client=rpc_http(),
        )
        self._operations = operations_connect.CatalogOperationServiceClientSync(
            endpoint,
            send_compression=None,
            timeout_ms=self._rpc_timeout_ms,
            http_client=rpc_http(),
        )
        self._membership = membership_connect.CatalogMembershipServiceClientSync(
            endpoint,
            send_compression=None,
            timeout_ms=self._rpc_timeout_ms,
            http_client=rpc_http(),
        )
        self._http = httpx.Client(
            base_url=endpoint,
            headers=headers,
            timeout=timeout_s,
            transport=transport,
        )
        # Presigned object URLs are complete credentials and must never inherit
        # Catalog authorization headers.
        self._objects = httpx.Client(timeout=timeout_s, transport=transport)

    def close(self) -> None:
        self._operations.close()
        self._pipelines.close()
        self._membership.close()
        self._annotations.close()
        self._evidence.close()
        self._applications.close()
        self._tasks.close()
        self._embodiments.close()
        self._objects.close()
        self._http.close()

    def __enter__(self) -> CatalogClient:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def require_ready(self) -> None:
        """Fail unless the Catalog control plane reports itself ready."""
        document = self._json("GET", "/api/healthz")
        if document.get("ok") is not True:
            raise CatalogClientError("Catalog health response did not report ready")

    def compute_output(
        self,
        execution_id: ComputeExecutionId,
        generation: int,
        kind: ComputeOutputKind,
    ) -> ComputeOutputRead:
        """Read one finalized candidate through a project-scoped presigned grant."""

        document = self._json(
            "GET",
            f"/api/compute/outputs/{execution_id}/{generation}/{kind.value}",
        )
        output = _string_mapping(document.get("output"), "compute output")
        try:
            returned_kind = ComputeOutputKind(_text(output, "kind"))
        except ValueError as error:
            raise CatalogClientError("Catalog returned an unknown compute output kind") from error
        content_document = _string_mapping(output.get("content"), "compute output content")
        content = ContentRef(
            ArtifactId(_text(content_document, "artifact_id")),
            Sha256Digest(_text(content_document, "sha256")),
        )
        size_bytes = document.get("size_bytes")
        if isinstance(size_bytes, bool) or not isinstance(size_bytes, int):
            raise CatalogClientError("Catalog compute output size must be an integer")
        if returned_kind is not kind:
            raise CatalogClientError("Catalog returned another compute output kind")
        return ComputeOutputRead(
            ComputeOutput(returned_kind, content),
            size_bytes,
            ObjectRead(content.sha256, _text(document, "get_url")),
        )

    def compute_input_access(self, content: ContentRef) -> ObjectRead:
        """Grant one exact project-owned input without changing its content identity."""
        grant = self._json(
            "POST",
            "/api/compute/inputs:read",
            {"artifact_id": str(content.artifact_id), "sha256": str(content.sha256)},
        )
        if _text(grant, "sha256") != str(content.sha256):
            raise CatalogClientError("Catalog granted another application input")
        return ObjectRead(content.sha256, _text(grant, "url"))

    def download_compute_input(self, content: ContentRef, cache_dir: Path) -> Path:
        """Read an exact project-owned input through the existing verified object cache."""
        return self.fetch_object(self.compute_input_access(content), cache_dir, suffix=".input")

    def register_compute_input(self, path: Path, artifact_id: ArtifactId) -> ContentRef:
        """Register exact bytes and receive no authority beyond their content identity."""

        size_bytes = path.stat().st_size
        if size_bytes < 1:
            raise CatalogClientError("compute input must not be empty")
        content = ContentRef(artifact_id, file_digest(path))
        body: dict[str, object] = {
            "content": {
                "artifact_id": str(content.artifact_id),
                "sha256": str(content.sha256),
            },
            "size_bytes": size_bytes,
        }
        upload = self._json("POST", "/api/compute/inputs:begin", body)
        if _content_ref(upload.get("content"), "compute input") != content:
            raise CatalogClientError("Catalog offered an upload for another compute input")
        maximum = upload.get("max_bytes")
        if isinstance(maximum, bool) or not isinstance(maximum, int) or maximum < size_bytes:
            raise CatalogClientError("Catalog compute input upload bound is too small")
        headers = _string_mapping(upload.get("headers"), "compute input upload headers")
        try:
            with path.open("rb") as stream:
                response = self._objects.put(
                    _text(upload, "put_url"),
                    content=stream,
                    headers={key: _text(headers, key) for key in headers},
                )
            _raise_for_status(response)
        except httpx.HTTPError as exc:
            raise CatalogClientError(f"compute input upload failed: {exc}") from exc
        completed = self._json("POST", "/api/compute/inputs:complete", body)
        if _content_ref(completed.get("content"), "compute input") != content:
            raise CatalogClientError("Catalog completed another compute input")
        completed_size = completed.get("size_bytes")
        if completed_size != size_bytes:
            raise CatalogClientError("Catalog completed compute input with another size")
        return content

    def register[C](self, request: Registrable[C]) -> CatalogOperation[C]:
        """Start one durable Catalog registration — the door for every family.

        The request owns its admission and the proof its completion must carry, so
        this stays one line of policy: accept the operation receipt or fail.
        """
        try:
            admitted = request.admit(self._operations, self._rpc_headers)
        except ConnectError as error:
            _raise_connect_error(error)
        ref, resource_ref = _accepted_operation(admitted)
        if ref.kind is not request.operation_kind:
            raise CatalogClientError(
                "Catalog registered through unexpected operation kind "
                f"{ref.kind.value!r}; expected {request.operation_kind.value!r}"
            )
        return CatalogOperation(
            cast("OperationRef[C, Mapping[str, object]]", ref),
            resource_ref,
            request,
        )

    def result[C](
        self,
        operation: CatalogOperation[C],
        *,
        timeout_s: float = 120.0,
        poll_s: float = 0.5,
        heartbeat: Callable[[], None] | None = None,
    ) -> C:
        """Wait through the common owner ledger and return exactly what it proved.

        This is the synchronous worker-side counterpart of ``await sx.Operation``: it
        long-polls bounded update pages, then reads the owner's terminal result once.
        """
        deadline = time.monotonic() + timeout_s
        ref = _operation_ref(operation.ref)
        if heartbeat is not None:
            heartbeat()
        status = self._operation_status(ref)
        while time.monotonic() < deadline:
            if heartbeat is not None:
                heartbeat()
            match _operation_receipt(status).state:
                case OperationState.SUCCEEDED:
                    settled, resource_ref = self._operation_result(ref)
                    if resource_ref != operation.resource_ref:
                        raise CatalogRegistrationFailed(
                            "Catalog completed a different resource than it admitted"
                        )
                    return operation.request.result(settled, resource_ref)
                case OperationState.FAILED | OperationState.CANCELLED:
                    raise CatalogRegistrationFailed(f"Catalog registration {operation.id!r} failed")
                case OperationState.ACCEPTED | OperationState.RUNNING:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        break
                    page = self._operation_updates(
                        ref,
                        after=int(status.metadata.cursor),
                        wait_s=min(max(poll_s, 0.001), remaining, 30.0),
                    )
                    if page is None:
                        # The retained window moved past this cursor. The owner
                        # answered immediately, so continuing on the same stale
                        # snapshot would spin: re-read the one method that mints
                        # the current receipt instead.
                        status = self._operation_status(ref)
                    elif page:
                        status = page[-1]
        raise CatalogRegistrationTimeout(
            f"Catalog registration {operation.id!r} did not reach READY in {timeout_s:g}s"
        )

    def status(self, ref: OperationRef[object, object]) -> OperationReceipt:
        """Read the owner's actual receipt for a durable operation reference."""
        return _operation_receipt(self._operation_status(_operation_ref(ref)))

    def operation_result(
        self, ref: OperationRef[object, object]
    ) -> operations_pb2.CatalogOperationResult:
        """Read the closed family result; the caller proves its expected identity."""
        result, _ = self._operation_result(_operation_ref(ref))
        return result

    def _operation_status(self, ref: common_pb2.OperationRef) -> operations_pb2.CatalogOperation:
        try:
            response = self._operations.get_catalog_operation(
                operations_pb2.GetCatalogOperationRequest(operation=ref),
                headers=self._rpc_headers,
            )
        except ConnectError as error:
            _raise_connect_error(error)
        if response.operation.metadata.ref != ref:
            raise CatalogClientError("Catalog returned a status for another operation")
        return response.operation

    def _operation_updates(
        self, ref: common_pb2.OperationRef, *, after: int, wait_s: float
    ) -> tuple[operations_pb2.CatalogOperation, ...] | None:
        """One bounded update page, or `None` when the retained window moved past.

        A history gap and an empty page are different answers: the gap returns at
        once and says this cursor can never be resumed, while an empty page is the
        long poll expiring. Collapsing them would turn the gap into a busy loop.
        """

        request = operations_pb2.GetCatalogOperationUpdatesRequest(
            operation=ref, limit=100, wait_timeout=timedelta(seconds=wait_s)
        )
        request.after_cursor = after
        try:
            response = self._operations.get_catalog_operation_updates(
                request,
                headers=self._rpc_headers,
                timeout_ms=round((wait_s + 5.0) * 1000),
            )
        except ConnectError as error:
            _raise_connect_error(error)
        arm = response.WhichOneof("outcome")
        if arm == "history_gap":
            return None
        if arm != "page":
            raise CatalogClientError(f"Catalog returned unknown updates outcome {arm!r}")
        if any(update.metadata.ref != ref for update in response.page.updates):
            raise CatalogClientError("Catalog returned updates for another operation")
        return tuple(response.page.updates)

    def _operation_result(
        self, ref: common_pb2.OperationRef
    ) -> tuple[operations_pb2.CatalogOperationResult, str]:
        """The settled arm and the resource the owner says this operation governs."""

        try:
            response = self._operations.get_catalog_operation_result(
                operations_pb2.GetCatalogOperationResultRequest(operation=ref),
                headers=self._rpc_headers,
            )
        except ConnectError as error:
            _raise_connect_error(error)
        if response.operation != ref:
            raise CatalogClientError("Catalog returned a result for another operation")
        resource = response.resource
        if not resource.kind or not resource.id:
            raise CatalogClientError("Catalog result names no governed resource")
        return response.result, f"{resource.kind}:{resource.id}"

    def begin_staging_upload(self, idempotency_key: str, filename: str) -> StagingUpload:
        """Begin or recover one multipart staging upload."""
        document = self._json(
            "POST",
            "/api/uploads",
            {"idempotency_key": idempotency_key, "filename": filename},
        )
        expires = document.get("expires_in_s")
        if not isinstance(expires, int) or expires <= 0:
            raise CatalogClientError("Catalog upload response needs a positive expires_in_s")
        part_size = document.get("part_size_bytes")
        if not isinstance(part_size, int) or part_size < 5 * 1024**2:
            raise CatalogClientError("Catalog upload response needs an S3-valid part size")
        raw_upload_id = _text(document, "upload_id")
        try:
            upload_id = UUID(raw_upload_id)
            state = MultipartUploadState(_text(document, "state"))
        except ValueError as exc:
            raise CatalogClientError("Catalog returned a malformed multipart upload") from exc
        source_uri = _text(document, "source_uri")
        if state is MultipartUploadState.INITIATED:
            return InitiatedStagingUpload(upload_id, source_uri, part_size, expires)
        if state is MultipartUploadState.ABORTED:
            return AbortedStagingUpload(upload_id, source_uri, part_size, expires)
        size = document.get("size_bytes")
        if not isinstance(size, int) or size <= 0:
            raise CatalogClientError("completed Catalog upload needs a positive byte size")
        return CompletedStagingUpload(
            upload_id,
            source_uri,
            part_size,
            expires,
            size,
        )

    def staging_upload_part(self, upload_id: UUID, part_number: int) -> MultipartPartGrant:
        document = self._json(
            "POST",
            f"/api/uploads/{upload_id}/parts",
            {"part_number": part_number},
        )
        returned_part = document.get("part_number")
        expires = document.get("expires_in_s")
        try:
            returned_upload = UUID(_text(document, "upload_id"))
        except ValueError as exc:
            raise CatalogClientError("Catalog returned a malformed multipart upload id") from exc
        if returned_upload != upload_id or returned_part != part_number:
            raise CatalogClientError("Catalog multipart part grant changed its identity")
        if not isinstance(expires, int) or expires <= 0:
            raise CatalogClientError("Catalog part grant needs a positive expires_in_s")
        return MultipartPartGrant(
            upload_id,
            part_number,
            _text(document, "url"),
            expires,
        )

    def complete_staging_upload(
        self,
        upload_id: UUID,
        *,
        size_bytes: int,
        parts: tuple[MultipartPart, ...],
    ) -> StagedObject:
        document = self._json(
            "POST",
            f"/api/uploads/{upload_id}/complete",
            {
                "size_bytes": size_bytes,
                "parts": [{"part_number": part.part_number, "etag": part.etag} for part in parts],
            },
        )
        try:
            returned_upload = UUID(_text(document, "upload_id"))
        except ValueError as exc:
            raise CatalogClientError("Catalog returned a malformed multipart upload id") from exc
        returned_size = document.get("size_bytes")
        if returned_upload != upload_id or returned_size != size_bytes:
            raise CatalogClientError("Catalog multipart completion changed immutable facts")
        if _text(document, "state") != MultipartUploadState.COMPLETED:
            raise CatalogClientError("Catalog multipart completion is not completed")
        return StagedObject(upload_id, _text(document, "source_uri"), size_bytes)

    def stage_file(
        self,
        path: Path,
        *,
        idempotency_key: str,
        filename: str,
        heartbeat: Callable[[], None] | None = None,
    ) -> StagedObject:
        """Upload one file through the sole multipart protocol.

        A small file is one part. Retrying with the same key recovers the same
        upload; already-uploaded part numbers are overwritten before completion.
        """
        size_bytes = path.stat().st_size
        if size_bytes <= 0:
            raise CatalogClientError("Catalog staging refuses an empty file")
        upload = self.begin_staging_upload(idempotency_key, filename)
        if isinstance(upload, CompletedStagingUpload):
            if upload.size_bytes != size_bytes:
                raise CatalogClientError(
                    "completed Catalog upload has a different immutable byte size"
                )
            return StagedObject(upload.upload_id, upload.source_uri, upload.size_bytes)
        if isinstance(upload, AbortedStagingUpload):
            raise CatalogClientError(
                "Catalog upload identity is aborted; choose a new idempotency key"
            )
        part_count = (size_bytes + upload.part_size_bytes - 1) // upload.part_size_bytes
        if part_count > 10_000:
            raise CatalogClientError("file exceeds the Catalog multipart size limit")
        parts: list[MultipartPart] = []
        with path.open("rb") as stream:
            for part_number in range(1, part_count + 1):
                if heartbeat is not None:
                    heartbeat()
                payload = stream.read(upload.part_size_bytes)
                grant = self.staging_upload_part(upload.upload_id, part_number)
                try:
                    response = self._objects.put(grant.url, content=payload)
                except httpx.HTTPError as exc:
                    raise CatalogClientError(f"object store upload failed: {exc}") from exc
                _raise_for_status(response)
                etag = response.headers.get("ETag")
                if not etag:
                    raise CatalogClientError("object store multipart response has no ETag receipt")
                parts.append(MultipartPart(part_number, etag))
        if heartbeat is not None:
            heartbeat()
        return self.complete_staging_upload(
            upload.upload_id,
            size_bytes=size_bytes,
            parts=tuple(parts),
        )

    def register_delivery_source(
        self,
        dataset: str,
        segment_id: str,
        manifest: DeliverySourceManifest,
    ) -> DeliverySourceRegistration:
        """Pin the exact SXD MCAP/sidecar handoff after the native RRD is READY."""

        if not dataset.strip() or not segment_id.strip():
            raise CatalogClientError("delivery source needs dataset and segment identities")
        document = self._json(
            "POST",
            "/api/delivery-sources",
            {
                "dataset": dataset,
                "segment_id": segment_id,
                "manifest": manifest.to_dict(),
            },
        )
        digest = _text(document, "manifest_sha256")
        if digest != manifest.sha256():
            raise CatalogClientError("Catalog changed the delivery-source content identity")
        returned_dataset = _text(document, "dataset")
        returned_segment = _text(document, "segment_id")
        if returned_dataset != dataset or returned_segment != segment_id:
            raise CatalogClientError("Catalog changed the delivery-source resource identity")
        try:
            registered_at = datetime.fromisoformat(_text(document, "registered_at"))
        except ValueError as error:
            raise CatalogClientError(
                "Catalog returned an invalid delivery-source timestamp"
            ) from error
        return DeliverySourceRegistration(
            dataset=returned_dataset,
            segment_id=returned_segment,
            manifest_sha256=Sha256Digest(digest),
            registered_at=registered_at,
        )

    def episode_status(self, dataset: str, segment_id: str) -> EpisodeStatus:
        """Look up one immutable episode segment without starting a mutation."""
        detail = self._json(
            "GET",
            f"/api/datasets/{dataset}/segments/{segment_id}",
        )
        raw_status = _text(detail, "status")
        states = {
            "registering": RegistrationState.RUNNING,
            "ready": RegistrationState.READY,
            "failed": RegistrationState.FAILED,
        }
        state = states.get(raw_status)
        if state is None:
            raise CatalogClientError(f"Catalog returned unknown segment status {raw_status!r}")
        returned_segment = _text(detail, "segment_id")
        return EpisodeStatus(returned_segment, state)

    def episode_access(
        self,
        dataset: str,
        segment_id: str,
        *,
        layer: str = "base",
    ) -> ObjectRead:
        """Resolve one immutable episode or overlay to an expiring signed read."""
        if not layer.strip():
            raise CatalogClientError("Catalog layer name must be non-empty")
        document = self._json(
            "GET",
            f"/api/datasets/{dataset}/segments/{segment_id}/url?layer={layer}",
        )
        return _object_read(document)

    def start_export(
        self,
        dataset: str,
        *,
        target: str,
        idempotency_key: str,
        prefix: str = "",
        dataset_kinds: tuple[DatasetKind, ...] = (),
        segment_id: str | None = None,
    ) -> OperationReceipt:
        """Start one governed dataset or episode export through Catalog.

        The receipt preserves the admitted lifecycle, including terminal replay.
        Its reference can be observed with :meth:`status` after a restart.
        The caller's own key, not the request digest, is what separates two lawful
        deliveries of the same dataset to the same target.
        """
        if not target.strip() or not idempotency_key.strip():
            raise CatalogClientError("Catalog export needs a target and idempotency key")
        plan = operations_pb2.ExportPlan(
            target=target,
            prefix=prefix,
            dataset_kinds=[kind.value for kind in dataset_kinds],
            timeout=timedelta(seconds=_EXPORT_TIMEOUT_S),
        )
        headers = {**self._rpc_headers, "Idempotency-Key": idempotency_key}
        try:
            if segment_id is None:
                started = self._operations.start_dataset_export(
                    operations_pb2.StartDatasetExportRequest(dataset=dataset, plan=plan),
                    headers=headers,
                ).operation
            else:
                started = self._operations.start_segment_export(
                    operations_pb2.StartSegmentExportRequest(
                        dataset=dataset, segment_id=segment_id, plan=plan
                    ),
                    headers=headers,
                ).operation
        except ConnectError as error:
            _raise_connect_error(error)
        operation, _ = _accepted_operation(started)
        if operation.kind is not OperationKind.EXPORT:
            raise CatalogClientError(
                f"Catalog export used unexpected operation kind {operation.kind.value!r}"
            )
        return _operation_receipt(started)

    def corpus(
        self,
        name: CorpusName,
        sha256: Sha256Digest,
    ) -> CorpusSnapshot:
        """Read one stable manifest and require the caller's exact digest pin.

        Two identities are checked and neither is believed. The transform
        re-derives the manifest's digest from its own canonical bytes and refuses
        a message whose declared `sha256` is not that digest; this then refuses a
        corpus that is not the one the caller pinned. A catalog answering about
        other content fails closed here rather than training on it.
        """
        request = membership_pb2.GetCorpusRequest(name=str(name))
        try:
            response = self._membership.get_corpus(
                request, headers=self._rpc_headers, timeout_ms=self._rpc_timeout_ms
            )
        except ConnectError as error:
            _raise_connect_error(error)
        _correlated(request, response.request, "corpus")
        try:
            snapshot = corpus_snapshot_from_proto(response.corpus.corpus)
        except ProtocolTransformError as error:
            raise CatalogDigestMismatchError(
                f"Catalog returned a malformed corpus: {error}"
            ) from error
        if snapshot.name != name:
            raise CatalogClientError("Catalog returned another corpus name")
        if snapshot.sha256 != sha256:
            raise CatalogDigestMismatchError(
                f"corpus digest mismatch: expected {sha256}, got {snapshot.sha256}"
            )
        return snapshot

    def task_contract(self, task_id: str) -> TaskContract:
        """Resolve one published task contract to its complete typed record.

        The canonical bytes are parsed through the one legal reader and the returned
        digest is verified against the recomputed content identity — a Catalog that
        returns tampered or mislabeled contract bytes fails closed here.
        """
        request = catalog_pb2.GetProjectTaskRequest(task_id=task_id)
        try:
            response = self._tasks.get_project_task(
                request,
                headers=self._rpc_headers,
                timeout_ms=self._rpc_timeout_ms,
            )
            _PROTO_VALIDATOR.validate(response)
            contract = task_contract_from_proto(response.task.definition.contract)
            defined_ref = task_contract_ref_from_proto(response.task.definition.reference)
            admitted_ref = task_contract_ref_from_proto(response.task.admission.task)
        except ConnectError as error:
            _raise_connect_error(error)
        except (ProtocolTransformError, ValidationError) as error:
            raise CatalogClientError("Catalog returned an invalid task contract") from error
        ref = contract_ref(contract)
        if response.request != request or str(ref.task_id) != task_id:
            raise CatalogClientError("Catalog returned another task contract")
        if defined_ref != ref or admitted_ref != defined_ref:
            raise CatalogClientError("Catalog task definition and admission disagree")
        return contract

    def get_policy(self, artifact_id: str) -> DeployablePolicyRecord:
        """Resolve one runnable policy artifact's governed lineage facts."""
        try:
            response = self._operations.get_policy(
                operations_pb2.GetPolicyRequest(artifact_id=artifact_id),
                headers=self._rpc_headers,
            )
        except ConnectError as error:
            _raise_connect_error(error)
        try:
            record = _policy_record(response.policy)
        except ProtocolTransformError as error:
            raise CatalogClientError(f"Catalog returned an invalid policy: {error}") from error
        if str(record.policy.artifact.artifact_id) != artifact_id:
            raise CatalogClientError("Catalog returned another policy artifact")
        return record

    def training_checkpoint(self, checkpoint_id: str) -> TrainingCheckpointRecord:
        document = self._json("GET", f"/api/training-checkpoints/{checkpoint_id}")
        checkpoint = _checkpoint_ref(document.get("checkpoint"))
        if str(checkpoint.artifact_id) != checkpoint_id:
            raise CatalogClientError("Catalog returned another training checkpoint")
        artifact = self._json("GET", f"/api/training-checkpoints/{checkpoint_id}/artifact")
        if _text(artifact, "sha256") != str(checkpoint.sha256):
            raise CatalogClientError("checkpoint artifact URL disagrees with its digest")
        size_bytes = document.get("size_bytes")
        if isinstance(size_bytes, bool) or not isinstance(size_bytes, int) or size_bytes < 0:
            raise CatalogClientError("Catalog checkpoint has an invalid byte size")
        return TrainingCheckpointRecord(
            name=_text(document, "name"),
            checkpoint=checkpoint,
            size_bytes=size_bytes,
            corpus=CorpusName(_text(document, "corpus")),
            corpus_sha256=Sha256Digest(_text(document, "corpus_sha256")),
            source_uri=_text(artifact, "url"),
        )

    def compose_policy(
        self,
        vla: VlaPolicy,
        *,
        task: TaskContractRef,
        agent: InnerAgent | None = None,
        name: str | None = None,
        embodiment: str | None = None,
        action_interface: str | None = None,
        dataset: str | None = None,
        timeout_s: float = 120.0,
    ) -> DeployablePolicy:
        """Resolve checkpoint lineage, register exact bytes, and return the Catalog echo."""

        checkpoint = self.training_checkpoint(str(vla.checkpoint.artifact_id))
        if checkpoint.checkpoint != vla.checkpoint or vla.artifact.sha256 != vla.checkpoint.sha256:
            raise CompositionBindingConflictError(
                "VLA/checkpoint digests disagree; pass the exact training result"
            )
        contract = self.task_contract(str(task.task_id))
        if contract_ref(contract) != task:
            raise CompositionBindingConflictError("task contract digest mismatch")
        corpus = self.corpus(checkpoint.corpus, checkpoint.corpus_sha256)
        candidates: list[tuple[EmbodimentId, ActionInterfaceId, str]] = []
        for domain in corpus.manifest.domains:
            if embodiment is not None and str(domain.embodiment_id) != embodiment:
                continue
            if action_interface is not None and str(domain.action_interface_id) != action_interface:
                continue
            datasets = {self.snapshot(domain.snapshot).dataset}
            if dataset is not None:
                datasets &= {dataset}
            try:
                body = self.embodiment(domain.embodiment_id)
                interface = self.action_interface(domain.action_interface_id)
                match_capabilities(contract.task.embodiment, body.capabilities)
            except ValueError:
                continue
            if interface.embodiment_id != body.id:
                continue
            candidates.extend(
                (domain.embodiment_id, domain.action_interface_id, candidate)
                for candidate in sorted(datasets)
                if candidate
            )
        candidates = list(dict.fromkeys(candidates))
        if len(candidates) != 1:
            dimensions = (
                ("embodiment", embodiment, {str(item[0]) for item in candidates}),
                (
                    "action_interface",
                    action_interface,
                    {str(item[1]) for item in candidates},
                ),
                ("dataset", dataset, {item[2] for item in candidates}),
            )
            required = [
                flag
                for flag, value, choices in dimensions
                if value is None and (len(choices) > 1 or not candidates)
            ]
            raise CompositionBindingConflictError(
                f"checkpoint lineage has {len(candidates)} matching bindings; "
                f"set explicit {', '.join(required) or 'binding overrides'}"
            )
        embodiment_id, action_interface_id, dataset_name = candidates[0]
        provisional = DeployablePolicy(
            ContentRef(ArtifactId("policy:composition"), checkpoint.checkpoint.sha256),
            vla,
            agent,
        )
        payload = deployable_policy_to_dict(provisional)
        payload.pop("artifact")
        payload["task"] = {
            "task_id": str(task.task_id),
            "schema_version": str(task.schema_version),
            "sha256": str(task.sha256),
        }
        payload["binding"] = {
            "embodiment_id": str(embodiment_id),
            "action_interface_id": str(action_interface_id),
            "dataset": dataset_name,
        }
        digest = content_digest(cast("CanonicalDocument", payload))
        policy = DeployablePolicy(
            ContentRef(ArtifactId(f"policy:{digest}"), checkpoint.checkpoint.sha256),
            vla,
            agent,
        )
        request = PolicyUpload(
            name=name or f"autonomy.policies.{digest[:16]}",
            source_uri=checkpoint.source_uri,
            size_bytes=checkpoint.size_bytes,
            policy=policy,
            task=task,
            embodiment_id=embodiment_id,
            action_interface_id=action_interface_id,
            dataset=dataset_name,
        )
        return self.result(self.register(request), timeout_s=timeout_s)

    def register_capability_approval(
        self, approval: CapabilityApproval, *, name: str
    ) -> CapabilityApprovalRecord:
        """Durably register one exact task approval and its complete evidence.

        The approval is content-addressed by its ref, so registration is
        naturally idempotent — the catalog returns the existing row on replay. The
        returned resource must equal the submitted approval exactly; a catalog that
        echoes different facts fails closed here.
        """
        if not name.strip():
            raise CatalogClientError("Catalog capability approval name must be non-empty")
        request = applications_pb2.RegisterCapabilityApprovalRequest(
            name=name,
            approval=capability_approval_to_proto(approval),
        )
        try:
            response = self._applications.register_capability_approval(
                request,
                headers=self._rpc_headers,
                timeout_ms=self._rpc_timeout_ms,
            )
        except ConnectError as error:
            _raise_connect_error(error)
        _correlated(request, response.request, "capability approval")
        record = _capability_approval_record(response.approval)
        _echo(approval, record.approval, "capability approval")
        return record

    def capability_approval(self, approval_ref: str) -> CapabilityApprovalRecord:
        """Resolve one registered approval to its complete, verified domain record.

        The reconstructed approval's content ref must equal the requested one, so a
        tampered or mislabeled row cannot reproduce it and fails closed here.
        """
        request = applications_pb2.GetCapabilityApprovalRequest(approval_ref=approval_ref)
        try:
            response = self._applications.get_capability_approval(
                request,
                headers=self._rpc_headers,
                timeout_ms=self._rpc_timeout_ms,
            )
        except ConnectError as error:
            _raise_connect_error(error)
        _correlated(request, response.request, "capability approval")
        record = _capability_approval_record(response.approval)
        if str(record.approval.ref) != approval_ref:
            raise CatalogClientError("Catalog returned another capability approval")
        return record

    def register_world_run(self, run: WorldRun) -> WorldRunRecord:
        """Durably register one completed Worlds run as a governed catalog resource.

        The request carries the run's own canonical bytes, so the release door's
        body-agreement law holds by construction. Registration is idempotent by
        content: an identical replay returns the stored resource and different bytes
        for the same id are refused by the catalog. The echoed resource must equal
        the submitted run exactly; a catalog that echoes different facts fails closed.
        """
        request = evidence_pb2.RegisterWorldRunRequest(run=world_run_to_proto(run))
        try:
            response = self._evidence.register_world_run(
                request,
                headers=self._rpc_headers,
                timeout_ms=self._rpc_timeout_ms,
            )
        except ConnectError as error:
            _raise_connect_error(error)
        _correlated(request, response.request, "world run")
        record = _world_run_record(response.run)
        _echo(run, record.run, "world run")
        return record

    def world_run(self, run_id: str) -> WorldRunRecord:
        """Resolve one registered Worlds run to its complete, verified evidence record.

        An unknown id raises :class:`CatalogNotFoundError` (a ``LookupError``), so the
        promotion door answers "no such run" distinctly from an outage. The transform
        re-derives the id from the canonical bytes and this reader binds it to the id
        that was asked for, so a run that is not the requested one fails closed —
        the schema states the same law in CEL, but no client evaluates a response.
        """
        request = evidence_pb2.GetWorldRunRequest(run_id=run_id)
        try:
            response = self._evidence.get_world_run(
                request,
                headers=self._rpc_headers,
                timeout_ms=self._rpc_timeout_ms,
            )
        except ConnectError as error:
            _raise_connect_error(error)
        _correlated(request, response.request, "world run")
        record = _world_run_record(response.run)
        if str(record.run.id) != run_id:
            raise CatalogClientError("Catalog returned another world run")
        return record

    def register_annotation(
        self, annotation: EpisodeAnnotation, *, dataset: str
    ) -> SegmentAnnotationRecord:
        """Register one reviewed `sx.annotation/v1` fact about a governed segment.

        The segment is the annotation's own ``episode_id`` — the schema binds the
        two, so nothing declared beside the review could disagree with it — and the
        digest is derived from the same value the request carries, which is what
        Catalog re-derives and refuses on mismatch. Registration is idempotent by
        content: a replay of the same review is the same stored row.
        """
        request = annotations_pb2.RegisterAnnotationRequest(
            dataset=dataset,
            segment_id=annotation.episode_id,
            annotation=annotation_to_proto(annotation),
            annotation_sha256=str(annotation_sha256(annotation)),
        )
        try:
            response = self._annotations.register_annotation(
                request,
                headers=self._rpc_headers,
                timeout_ms=self._rpc_timeout_ms,
            )
        except ConnectError as error:
            _raise_connect_error(error)
        _correlated(request, response.request, "segment annotation")
        record = _segment_annotation_record(response.annotation)
        if (record.dataset, record.segment_id, str(record.sha256)) != (
            dataset,
            annotation.episode_id,
            request.annotation_sha256,
        ):
            raise CatalogClientError("Catalog receipt names another segment annotation")
        if record.stage is not annotation.stage:
            raise CatalogClientError("Catalog filed the annotation under another review stage")
        return record

    def register_application_qualification(
        self, qualification: ApplicationQualification
    ) -> ApplicationQualificationRecord:
        request = applications_pb2.RegisterApplicationQualificationRequest(
            qualification=application_qualification_to_proto(qualification),
        )
        try:
            response = self._applications.register_application_qualification(
                request,
                headers=self._rpc_headers,
                timeout_ms=self._rpc_timeout_ms,
            )
        except ConnectError as error:
            _raise_connect_error(error)
        _correlated(request, response.request, "application qualification")
        record = _application_qualification_record(response.qualification)
        _echo(qualification, record.qualification, "application qualification")
        return record

    def register_robot_application(
        self, application: RobotApplication, *, name: str
    ) -> RobotApplicationRecord:
        if not name.strip():
            raise CatalogClientError("Catalog application name must be non-empty")
        request = applications_pb2.RegisterApplicationRequest(
            name=name,
            application=robot_application_to_proto(application),
        )
        try:
            response = self._applications.register_application(
                request,
                headers=self._rpc_headers,
                timeout_ms=self._rpc_timeout_ms,
            )
        except ConnectError as error:
            _raise_connect_error(error)
        _correlated(request, response.request, "robot application")
        record = _robot_application_record(response.application)
        _echo(application, record.application, "robot application")
        return record

    def robot_application(self, application_ref: str) -> RobotApplicationRecord:
        request = applications_pb2.GetApplicationRequest(application_ref=application_ref)
        try:
            response = self._applications.get_application(
                request,
                headers=self._rpc_headers,
                timeout_ms=self._rpc_timeout_ms,
            )
        except ConnectError as error:
            _raise_connect_error(error)
        _correlated(request, response.request, "robot application")
        record = _robot_application_record(response.application)
        if str(record.application.ref) != application_ref:
            raise CatalogClientError("Catalog returned another robot application")
        return record

    def application_qualification(self, qualification_ref: str) -> ApplicationQualificationRecord:
        request = applications_pb2.GetApplicationQualificationRequest(
            qualification_ref=qualification_ref
        )
        try:
            response = self._applications.get_application_qualification(
                request,
                headers=self._rpc_headers,
                timeout_ms=self._rpc_timeout_ms,
            )
        except ConnectError as error:
            _raise_connect_error(error)
        _correlated(request, response.request, "application qualification")
        record = _application_qualification_record(response.qualification)
        if str(record.qualification.ref) != qualification_ref:
            raise CatalogClientError("Catalog returned another application qualification")
        return record

    def register_suite(self, name: str, manifest: SuiteManifest) -> SuiteRecord:
        """Durably register one evaluation suite as a governed catalog resource.

        A suite is immutable and content-addressed, so registration is naturally
        idempotent by ``suite_id``: an identical replay returns the stored
        resource, a different manifest under that id is refused by the catalog.
        The echoed manifest must equal the submitted one and its digest must be
        the locally recomputed ``suite_digest``; anything else fails closed.
        """
        if not name.strip():
            raise CatalogClientError("Catalog suite name must be non-empty")
        document = self._json("POST", "/api/suites", _suite_in_wire(name, manifest))
        record = _suite_record(document)
        _echo(manifest, record.manifest, "suite")
        return record

    def suite(self, suite_id: str) -> SuiteRecord:
        """Resolve one registered suite to its complete, verified manifest.

        An unknown id raises :class:`CatalogNotFoundError` (a ``LookupError``), so
        the Worlds door answers "no such suite" distinctly from an outage — a
        contract that pins a suite the registry does not hold fails closed there.
        """
        document = self._json("GET", f"/api/suites/{suite_id}")
        record = _suite_record(document)
        if record.manifest.suite_id != suite_id or record.suite_id != suite_id:
            raise CatalogClientError("Catalog returned another suite")
        return record

    def policy_artifact(self, artifact_id: str) -> PolicyArtifactRecord:
        """Resolve one registered policy artifact to its verified canonical document.

        An unknown id raises :class:`CatalogNotFoundError` (a ``LookupError``), so a
        runner answers "no such policy" distinctly from an outage. The stored digest
        must be the document's own: an artifact whose halves disagree would let a run
        cite a policy other than the bytes it executed, so it fails closed here.
        """
        document = self._json("GET", f"/api/policy-artifacts/{artifact_id}")
        record = _policy_artifact_record(document)
        if record.artifact_id != artifact_id:
            raise CatalogClientError("Catalog returned another policy artifact")
        return record

    def dataset(self, name: str) -> DatasetRecord:
        """Resolve one governed dataset entry by name.

        An unknown or cross-tenant name raises :class:`CatalogNotFoundError`, so a
        producer's destination is settled before any work is accepted.
        """
        if not name.strip():
            raise CatalogClientError("Catalog dataset name must be non-empty")
        document = self._json("GET", f"/api/datasets/{name}")
        record = _dataset_record(document)
        if record.name != name:
            raise CatalogClientError("Catalog returned another dataset")
        return record

    def representations(self, name: str) -> tuple[Representation, ...]:
        """Which forms this entry's bytes exist in, whatever kind of thing it is.

        The cheap question, so it is the one to ask first: it grants nothing, costs
        the same for a scene as for a whole dataset, and an empty answer means the
        entry is a document rather than that anything went wrong.
        """
        document = self._json("GET", f"/api/entries/{name}/representations")
        listed = document.get("representations")
        if not isinstance(listed, list):
            raise CatalogClientError("Catalog representations must be an array")
        return tuple(_representation(item) for item in cast("list[object]", listed))

    def access(self, name: str, form: RepresentationFormat) -> Access:
        """Read one entry in one form, now.

        The answer has two arms and the catalog picks: episodes served as tables
        come back as a `QueryPlane` to open lazily, and everything else — including
        those episodes wherever no such server is deployed — comes back as the
        objects themselves. Match on what you get; there is nothing to ask for.
        """
        document = self._json("POST", f"/api/entries/{name}/access", {"format": form.value})
        grant = _text(document, "grant")
        if grant == "query_plane":
            return QueryPlane(
                server_url=_text(document, "server_url"),
                dataset_id=_text(document, "dataset_id"),
                dataset_name=_text(document, "dataset_name"),
            )
        if grant != "objects":
            raise CatalogClientError(f"Catalog offered an unknown grant {grant!r}")
        return _object_reads(document)

    def snapshot(self, snapshot_id: DatasetSnapshotId) -> SnapshotFacts:
        """What this immutable membership is, without reading which episodes it holds.

        Fixed-width whatever the snapshot contains, so this call costs the same for
        ten episodes and ten million — which is the property the whole snapshot
        design exists for. The returned digest is checked against the one the id
        already carries: a catalog answering about other content fails closed here
        rather than training on it.
        """
        request = membership_pb2.GetSnapshotRequest(snapshot=str(snapshot_id))
        try:
            response = self._membership.get_snapshot(
                request, headers=self._rpc_headers, timeout_ms=self._rpc_timeout_ms
            )
        except ConnectError as error:
            _raise_connect_error(error)
        _correlated(request, response.request, "snapshot")
        return _snapshot_facts(snapshot_id, response.snapshot)

    def snapshot_objects(
        self, snapshot_id: DatasetSnapshotId, digests: Sequence[Sha256Digest], *, part: int
    ) -> ObjectReads:
        """Grant reads for exactly these members of exactly this part of this snapshot.

        The paged half of reading a membership: the caller has streamed one part of
        the index and asks for bytes it just read there. The part travels with the
        digests because it is what keeps the answer bounded — proving a digest
        belongs to *this* snapshot without it would cost the whole membership per
        page. A digest that is not in that part is refused rather than granted, so
        a stale index cannot widen what a training run reads, and the page size is
        the caller's: one request per batch, never one per episode.
        """
        if not digests:
            raise CatalogClientError("a snapshot object grant needs at least one digest")
        request = membership_pb2.GrantSnapshotObjectsRequest(
            snapshot=str(snapshot_id),
            part=part,
            sha256=[str(digest) for digest in digests],
        )
        try:
            response = self._membership.grant_snapshot_objects(
                request, headers=self._rpc_headers, timeout_ms=self._rpc_timeout_ms
            )
        except ConnectError as error:
            _raise_connect_error(error)
        _correlated(request, response.request, "snapshot object grant")
        granted = tuple(
            ObjectRead(Sha256Digest(item.sha256), item.url) for item in response.objects
        )
        missing = set(digests) - {item.sha256 for item in granted}
        if missing:
            raise CatalogNotFoundError(
                f"snapshot {snapshot_id} part {part} no longer offers {len(missing)} of "
                f"the {len(digests)} objects asked for"
            )
        return ObjectReads(granted, int(response.expires_in.ToSeconds()))

    def plan(self, plan: PipelinePlan) -> AdmittedPlan:
        """Ask whether this graph may run here, over these values, into that dataset.

        The cheap half of running something: it resolves every input against what this
        project can actually see, proves the schema transition into the destination, and
        returns the stage order and the digest — all from metadata, with nothing
        estimated, reserved or scanned. Ask before paying for compute that was never
        going to be admitted.

        The plan crosses as the graph's own canonical wire, so the digest that comes
        back is a fact about the plan rather than about whoever encoded it.
        """
        request = pipelines_pb2.ValidatePlanRequest(plan=pipeline_plan_to_proto(plan))
        try:
            response = self._pipelines.validate_plan(
                request, headers=self._rpc_headers, timeout_ms=self._rpc_timeout_ms
            )
        except ConnectError as error:
            _raise_connect_error(error)
        _correlated(request, response.request, "pipeline plan")
        admitted = _admitted_plan(response.plan)
        if admitted.digest != plan.digest:
            raise CatalogClientError("Catalog admitted another plan")
        return admitted

    def submit_run(self, plan: PipelinePlan, *, idempotency_key: str) -> PipelineRun:
        """Run this plan. The key is what makes "once" true.

        The expensive half: the catalog re-proves the plan, makes it durable, writes
        the run, and returns immediately with a receipt rather than a result. The key
        names that run in this project forever — retry with the same key and the same
        plan to reach the same run, and never reuse one across plans, because that is
        the one thing the catalog refuses rather than guesses at.
        """
        if not idempotency_key.strip():
            raise CatalogClientError("Catalog run submission needs an idempotency key")
        request = pipelines_pb2.SubmitRunRequest(plan=pipeline_plan_to_proto(plan))
        try:
            response = self._pipelines.submit_run(
                request,
                headers={**self._rpc_headers, "Idempotency-Key": idempotency_key},
                timeout_ms=self._rpc_timeout_ms,
            )
        except ConnectError as error:
            _raise_connect_error(error)
        _correlated(request, response.request, "pipeline run")
        admitted = _pipeline_run(response.run)
        if admitted.plan_digest != plan.digest:
            raise CatalogClientError("Catalog admitted a run of another plan")
        return admitted

    def run(self, run_id: OperationId) -> PipelineRun:
        """Where one run has got to, as of now. Bounded, and safe to poll."""
        request = pipelines_pb2.GetRunRequest(run=_run_ref(run_id))
        try:
            response = self._pipelines.get_run(
                request, headers=self._rpc_headers, timeout_ms=self._rpc_timeout_ms
            )
        except ConnectError as error:
            _raise_connect_error(error)
        _correlated(request, response.request, "pipeline run")
        return _pipeline_run(response.run)

    def cancel_run(self, run_id: OperationId, *, reason: str) -> PipelineRun:
        """Ask a run to stop, and read what that meant for it.

        A run nothing has started yet comes back cancelled. One already executing
        comes back in the state it is in, carrying the request on its receipt: the
        catalog converges it safely rather than declaring an ending it cannot know.
        """
        if not reason.strip():
            raise CatalogClientError("Catalog run cancellation needs a reason")
        request = pipelines_pb2.CancelRunRequest(run=_run_ref(run_id), reason=reason)
        try:
            response = self._pipelines.cancel_run(
                request, headers=self._rpc_headers, timeout_ms=self._rpc_timeout_ms
            )
        except ConnectError as error:
            _raise_connect_error(error)
        _correlated(request, response.request, "pipeline run")
        return _pipeline_run(response.run)

    def embodiment(self, embodiment_id: EmbodimentId) -> Embodiment:
        """Resolve one complete embodiment and require its exact content identity."""
        try:
            response = self._embodiments.resolve_embodiment(
                catalog_pb2.ResolveEmbodimentRequest(id=str(embodiment_id)),
                headers=self._rpc_headers,
                timeout_ms=self._rpc_timeout_ms,
            )
            embodiment = embodiment_from_proto(response.embodiment.embodiment)
        except ConnectError as error:
            _raise_connect_error(error)
        except ProtocolTransformError as error:
            raise CatalogClientError("Catalog returned a malformed embodiment") from error
        if embodiment.id != embodiment_id:
            raise CatalogClientError("Catalog resolved another embodiment revision")
        return embodiment

    def register_embodiment(
        self,
        name: str,
        embodiment: Embodiment,
        asset_paths: Mapping[str, Path] | None = None,
    ) -> Embodiment:
        """Register one embodiment entry, promoting the blobs it cites first.

        Catalog refuses unattributed bytes, so every asset the document names is
        published through the verified asset door before the embodiment that cites
        them; omit ``asset_paths`` when the project already holds the blobs.
        Registration is idempotent by content digest, and the echoed document must
        be the submitted one — a catalog storing other semantics under this
        identity fails closed here rather than at the robot.
        """
        if asset_paths is not None:
            expected = {asset.sha256 for asset in embodiment.assets}
            if set(asset_paths) != expected:
                raise CatalogClientError("asset_paths must contain exactly the asset digests")
            for asset in embodiment.assets:
                self.result(self.register(AssetUpload.of(self, asset, asset_paths[asset.sha256])))
        try:
            response = self._embodiments.register_embodiment(
                catalog_pb2.RegisterEmbodimentRequest(
                    name=name,
                    embodiment=embodiment_to_proto(embodiment),
                ),
                headers=self._rpc_headers,
                timeout_ms=self._rpc_timeout_ms,
            )
            stored = embodiment_from_proto(response.embodiment.embodiment)
        except ConnectError as error:
            _raise_connect_error(error)
        except ProtocolTransformError as error:
            raise CatalogClientError("Catalog returned a malformed embodiment") from error
        return _echo(embodiment, stored, "embodiment")

    def register_action_interface(self, interface: ActionInterface) -> None:
        """Publish one controller document so consumers can resolve it by id alone.

        The document IS the contract and carries its own content id and embodiment
        revision, so nothing else is needed at the door and registration is
        idempotent by content: a producer republishing an interface the catalog
        already holds is a no-op. The entry name is derived from that same content
        id — a label over bytes that cannot move, never a second fact to keep in
        step. The echoed document must be the submitted one; a catalog that stores
        other semantics under this id fails closed here, because a checkpoint or a
        pod resolving it later would execute them.
        """
        document = self._json(
            "POST",
            "/api/action-interfaces",
            {
                "name": f"action-interfaces.{interface.id}",
                "action_interface": action_interface_to_dict(interface),
            },
        )
        raw = document.get("action_interface")
        try:
            stored = action_interface_from_dict(_string_mapping(raw, "action_interface"))
        except ActionInterfaceError as exc:
            raise CatalogClientError("Catalog returned a malformed action interface") from exc
        _echo(interface, stored, "action interface")

    def action_interface(
        self,
        action_interface_id: ActionInterfaceId,
    ) -> ActionInterface:
        """Resolve one complete controller and require its exact content identity."""
        document = self._json(
            "GET",
            f"/api/action-interfaces/resolve?action_interface_id={action_interface_id}",
        )
        raw = document.get("action_interface")
        try:
            interface = action_interface_from_dict(_string_mapping(raw, "action_interface"))
        except ActionInterfaceError as exc:
            raise CatalogClientError("Catalog returned a malformed action interface") from exc
        if interface.id != action_interface_id:
            raise CatalogClientError("Catalog resolved another action-interface revision")
        return interface

    def register_scene(self, scene: Scene) -> Scene:
        """Register one complete scene document (idempotent by content digest).

        Every bundle member must already be a managed blob of this tenant: a scene
        names its closure by content, and Catalog refuses unattributed bytes, so the
        blobs are published through the asset door before the scene that cites them.
        """
        document = self._json("POST", "/api/scenes", {"scene": scene_to_dict(scene)})
        return _scene_record(document, expected_id=str(scene.id))

    def scene(self, scene_id: str) -> Scene:
        """Resolve one complete registered scene document by its id."""
        return _scene_record(self._json("GET", f"/api/scenes/{scene_id}"), expected_id=scene_id)

    def scenes(self) -> tuple[Scene, ...]:
        """List every governed scene readable in the active project."""
        return tuple(
            _scene_record(row, expected_id=_text(row, "scene_id"))
            for row in self._json_list("/api/scenes")
        )

    def register_environment(
        self, environment: EnvironmentBundle, *, public: bool = False
    ) -> EnvironmentBundle:
        """Register one complete place and optionally publish it for every project."""
        document = self._json(
            "POST",
            "/api/environments",
            {"environment": environment_to_dict(environment), "public": public},
        )
        return _environment_record(document, expected_id=str(environment.id))

    def environment(self, environment_id: str) -> EnvironmentBundle:
        """Resolve one governed place by content identity."""
        return _environment_record(
            self._json("GET", f"/api/environments/{environment_id}"),
            expected_id=environment_id,
        )

    def environment_asset_access(self, environment_id: str, sha256: Sha256Digest) -> ObjectReads:
        """Read one exact environment member without enumerating its closure."""

        return _object_reads(
            self._json(
                "POST",
                f"/api/environments/{environment_id}/assets/{sha256}/access",
            )
        )

    def environments(self) -> tuple[EnvironmentBundle, ...]:
        """List governed captured and generated places in the active project."""
        return tuple(
            _environment_record(row, expected_id=_text(row, "environment_id"))
            for row in self._json_list("/api/environments")
        )

    def register_object_asset(self, object_asset: ObjectAssetBundle) -> ObjectAssetBundle:
        """Register one complete reusable physical object."""
        document = self._json(
            "POST",
            "/api/object-assets",
            {"object_asset": object_asset_to_dict(object_asset)},
        )
        return _object_asset_record(document, expected_id=str(object_asset.id))

    def object_asset(self, object_asset_id: str) -> ObjectAssetBundle:
        """Resolve one reusable object by content identity."""
        return _object_asset_record(
            self._json("GET", f"/api/object-assets/{object_asset_id}"),
            expected_id=object_asset_id,
        )

    def object_assets(self) -> tuple[ObjectAssetBundle, ...]:
        """List governed reusable objects in the active project."""
        return tuple(
            _object_asset_record(row, expected_id=_text(row, "object_asset_id"))
            for row in self._json_list("/api/object-assets")
        )

    def object_asset_access(self, object_asset_id: str, sha256: Sha256Digest) -> ObjectReads:
        """Read one exact member of a reusable object closure."""
        return _object_reads(
            self._json(
                "POST",
                f"/api/object-assets/{object_asset_id}/assets/{sha256}/access",
            )
        )

    def register_asset_pack(
        self, name: str, assets: Sequence[ProvenancedAsset]
    ) -> CatalogAssetPack:
        """Name a set of already-promoted assets so its bytes can be read back.

        Promotion (:class:`AssetUpload`) governs bytes; it does not make them
        readable, because every byte grant is entry-scoped. This is the entry, and a
        pack is read exactly as an embodiment's bundle is —
        :meth:`download_bundle_member` under the pack's own name. Registration is
        idempotent by membership: the identical set replays, and a different set
        under the same name is refused.
        """
        document = self._json(
            "POST",
            "/api/asset-packs",
            {"name": name, "assets": [_asset_ref_wire(asset.asset) for asset in assets]},
        )
        return _asset_pack_record(document, expected_name=name)

    def download_bundle_member(self, entry: str, sha256: str, target: Path) -> Path:
        """Materialize one member of an entry's asset bundle at ``target``.

        The grant covers the whole bundle, because a bundle is the form these bytes
        take; one member is picked out of it by digest here. A scene closure and an
        embodiment description take the same path — they were two routes describing
        one idea.
        """
        grant = self.access(entry, RepresentationFormat.ASSET_BUNDLE)
        if not isinstance(grant, ObjectReads):
            raise CatalogClientError(f"Catalog offered a query plane for {entry!r}'s bundle")
        member = next((item for item in grant.objects if item.sha256 == sha256), None)
        if member is None:
            raise CatalogClientError(f"{entry!r} has no bundle member {sha256!r}")
        cached = self.fetch_object(member, target.parent, suffix=f".{uuid4().hex[:8]}.member")
        os.replace(cached, target)
        return target

    def download_scene_asset(self, scene_id: str, sha256: str, target: Path) -> Path:
        """Materialize one member of a scene's bundle, digest-verified.

        A scene's entry name is derived from its content id, so this is the one
        place that derivation is spelled for readers of scene bytes.
        """
        return self.download_bundle_member(f"scenes.{scene_id}", sha256, target)

    def fetch_object(self, item: ObjectRead, cache_dir: Path, *, suffix: str = ".rrd") -> Path:
        """Hydrate one signed object into a full-SHA content cache atomically."""
        cache_dir.mkdir(parents=True, exist_ok=True)
        target = cache_dir / f"{item.sha256}{suffix}"
        if target.exists():
            if file_digest(target) != item.sha256:
                raise CatalogClientError(f"Catalog cache digest mismatch: {target}")
            return target
        temporary = cache_dir / f".{item.sha256}.{uuid4().hex}.partial"
        try:
            # A separate client, NOT self._http: the presigned URL is its own
            # complete credential, and object stores reject a request that
            # carries the catalog bearer as a second auth mechanism.
            try:
                with self._objects.stream("GET", item.url) as response:
                    if response.status_code >= 300:
                        response.read()  # streaming bodies must be read before .text
                    _raise_for_status(response)
                    with temporary.open("xb") as stream:
                        digest = stream_blob(_landing(response.iter_bytes(), stream)).sha256
                        stream.flush()
                        os.fsync(stream.fileno())
            except httpx.HTTPError as exc:
                raise CatalogClientError(f"object download failed: {exc}") from exc
            if digest != item.sha256:
                raise CatalogClientError(
                    f"downloaded Catalog object disagrees with SHA-256 {item.sha256}"
                )
            os.replace(temporary, target)
        finally:
            temporary.unlink(missing_ok=True)
        return target

    def _json(
        self,
        method: str,
        path: str,
        body: dict[str, object] | None = None,
        *,
        headers: dict[str, str] | None = None,
        params: Mapping[str, str | int | float] | None = None,
    ) -> dict[str, object]:
        try:
            response = self._http.request(
                method,
                path,
                json=body,
                headers=headers,
                params=params,
            )
        except httpx.HTTPError as exc:
            # Transport failures (refused, DNS, timeout) speak the same typed language
            # as retryable HTTP errors: consumers map CatalogUnavailableError to their
            # unavailable path, never a raw httpx exception through a door.
            raise CatalogUnavailableError(f"Catalog request failed: {exc}") from exc
        _raise_for_status(response)
        try:
            value: object = response.json()
        except ValueError as exc:
            raise CatalogClientError("Catalog returned non-JSON data") from exc
        if not isinstance(value, dict):
            raise CatalogClientError("Catalog returned a non-object response")
        raw = cast("dict[object, object]", value)
        if not all(isinstance(key, str) for key in raw):
            raise CatalogClientError("Catalog response keys must be text")
        return {cast("str", key): item for key, item in raw.items()}

    def _json_list(self, path: str) -> tuple[dict[str, object], ...]:
        """Read an array of JSON objects from one Catalog collection route."""
        try:
            response = self._http.get(path)
        except httpx.HTTPError as exc:
            raise CatalogUnavailableError(f"Catalog request failed: {exc}") from exc
        _raise_for_status(response)
        try:
            value: object = response.json()
        except ValueError as exc:
            raise CatalogClientError("Catalog returned non-JSON data") from exc
        if not isinstance(value, list):
            raise CatalogClientError("Catalog collection response must be an array of objects")
        result: list[dict[str, object]] = []
        for item in cast("list[object]", value):
            if not isinstance(item, dict):
                raise CatalogClientError("Catalog collection response must be an array of objects")
            row = cast("dict[object, object]", item)
            if any(not isinstance(key, str) for key in row):
                raise CatalogClientError("Catalog collection response keys must be text")
            result.append({cast("str", key): value for key, value in row.items()})
        return tuple(result)


def _landing(chunks: Iterator[bytes], out: IO[bytes]) -> Iterator[bytes]:
    """Yield each chunk once it is on disk, so landing and verifying share one pass."""
    for chunk in chunks:
        out.write(chunk)
        yield chunk


def _raise_for_status(response: httpx.Response) -> None:
    if response.status_code < 300:
        return
    detail = response.text[:500]
    if response.status_code == 404:
        raise CatalogNotFoundError(f"Catalog HTTP 404: {detail}")
    if response.status_code in {401, 403}:
        raise CatalogPermissionError(f"Catalog HTTP {response.status_code}: {detail}")
    if response.status_code == 429 or response.status_code >= 500:
        raise CatalogUnavailableError(f"Catalog HTTP {response.status_code}: {detail}")
    raise CatalogClientError(f"Catalog HTTP {response.status_code}: {detail}")


def _raise_connect_error(error: ConnectError) -> Never:
    """Keep Connect refusal semantics inside the Catalog client boundary."""

    detail = error.message[:500]
    if error.code is Code.NOT_FOUND:
        raise CatalogNotFoundError(f"Catalog Connect not_found: {detail}") from error
    if error.code in {Code.UNAUTHENTICATED, Code.PERMISSION_DENIED}:
        raise CatalogPermissionError(f"Catalog Connect {error.code.value}: {detail}") from error
    if error.code in {
        Code.CANCELED,
        Code.UNKNOWN,
        Code.DEADLINE_EXCEEDED,
        Code.RESOURCE_EXHAUSTED,
        Code.ABORTED,
        Code.INTERNAL,
        Code.UNAVAILABLE,
    }:
        raise CatalogUnavailableError(f"Catalog Connect {error.code.value}: {detail}") from error
    raise CatalogClientError(f"Catalog Connect {error.code.value}: {detail}") from error


def _text(document: Mapping[str, object], name: str) -> str:
    """A catalog identity that is blank resolves nothing — the one rule beyond the kit."""
    value = decode.text(document, name, where="Catalog response", error=CatalogClientError)
    if not value:
        raise CatalogClientError(f"Catalog response needs non-empty {name}")
    return value


def _scene_record(document: dict[str, object], *, expected_id: str) -> Scene:
    """Fail-closed parse of one catalog scene response into the shared record."""
    raw = document.get("scene")
    if not isinstance(raw, dict):
        raise CatalogClientError("Catalog scene response carries no document")
    try:
        scene = scene_from_dict(cast("Mapping[str, object]", raw))
    except SceneContractError as exc:
        raise CatalogClientError("Catalog returned a malformed scene") from exc
    if str(scene.id) != expected_id:
        raise CatalogClientError("Catalog resolved another scene")
    return scene


def _environment_record(document: dict[str, object], *, expected_id: str) -> EnvironmentBundle:
    """Fail-closed parse of one catalog environment response."""
    raw = document.get("environment")
    if not isinstance(raw, dict):
        raise CatalogClientError("Catalog environment response carries no document")
    try:
        environment = environment_from_dict(cast("Mapping[str, object]", raw))
    except EnvironmentContractError as exc:
        raise CatalogClientError("Catalog returned a malformed environment") from exc
    if str(environment.id) != expected_id:
        raise CatalogClientError("Catalog resolved another environment")
    return environment


def _object_asset_record(document: dict[str, object], *, expected_id: str) -> ObjectAssetBundle:
    """Fail-closed parse of one catalog reusable-object response."""
    raw = document.get("object_asset")
    if not isinstance(raw, dict):
        raise CatalogClientError("Catalog object asset response carries no document")
    try:
        object_asset = object_asset_from_dict(cast("Mapping[str, object]", raw))
    except ObjectAssetContractError as exc:
        raise CatalogClientError("Catalog returned a malformed object asset") from exc
    if str(object_asset.id) != expected_id:
        raise CatalogClientError("Catalog resolved another object asset")
    return object_asset


def _asset_pack_record(document: dict[str, object], *, expected_name: str) -> CatalogAssetPack:
    """Fail-closed parse of one catalog asset-pack response.

    The name is proved rather than assumed: a pack is the entry that makes its
    members readable, so a response naming another one would send the next
    :meth:`CatalogClient.download_bundle_member` at somebody else's bytes.
    """
    name = _text(document, "name")
    if name != expected_name:
        raise CatalogClientError(f"Catalog answered for pack {name!r}, not {expected_name!r}")
    listed = document.get("members")
    if not isinstance(listed, list):
        raise CatalogClientError("Catalog asset pack members must be an array")
    members: list[AssetPackMember] = []
    for item in cast("list[object]", listed):
        if not isinstance(item, dict):
            raise CatalogClientError("Catalog asset pack member must be an object")
        member = cast("dict[str, object]", item)
        members.append(
            AssetPackMember(
                sha256=Sha256Digest(_text(member, "sha256")),
                uri=_text(member, "uri"),
                role=AssetRole(_text(member, "role")),
            )
        )
    if not members:
        raise CatalogClientError(f"Catalog asset pack {name!r} owns no members")
    return CatalogAssetPack(
        name=name,
        members=tuple(members),
        created_at=datetime.fromisoformat(_text(document, "created_at")),
    )


def _accepted_operation(
    operation: operations_pb2.CatalogOperation,
) -> tuple[OperationRef[object, Mapping[str, object]], str]:
    """The generated operation as its one durable reference and governed resource."""

    ref = operation.metadata.ref
    if ref.pillar != common_pb2.PLATFORM_PILLAR_EXPERIENCE:
        raise CatalogClientError("Catalog operation receipt belongs to another platform pillar")
    raw_kind = common_pb2.OperationKind.Name(ref.kind)
    try:
        kind = OperationKind(raw_kind.removeprefix("OPERATION_KIND_").lower().replace("_", "-"))
    except ValueError as error:
        raise CatalogClientError(f"Catalog returned unknown operation kind {raw_kind!r}") from error
    _operation_receipt(operation)
    resource = operation.metadata.resource
    if not resource.kind or not resource.id:
        raise CatalogClientError("Catalog operation names no governed resource")
    return (
        OperationRef(PlatformPillar.EXPERIENCE, kind, OperationId(ref.operation_id)),
        f"{resource.kind}:{resource.id}",
    )


def _operation_ref(ref: OperationRef[object, object]) -> common_pb2.OperationRef:
    """One canonical reference as the wire's ``(pillar, kind, id)`` triple."""

    if ref.pillar is not PlatformPillar.EXPERIENCE:
        raise CatalogClientError("Catalog operations belong to the Experience pillar")
    name = f"OPERATION_KIND_{ref.kind.value.upper().replace('-', '_')}"
    try:
        kind = common_pb2.OperationKind.Value(name)
    except ValueError as error:
        raise CatalogClientError(f"no wire value for operation kind {ref.kind.value!r}") from error
    return common_pb2.OperationRef(
        pillar=common_pb2.PLATFORM_PILLAR_EXPERIENCE,
        kind=cast("common_pb2.OperationKind", kind),
        operation_id=str(ref.operation_id),
    )


def _operation_receipt(operation: operations_pb2.CatalogOperation) -> OperationReceipt:
    try:
        _PROTO_VALIDATOR.validate(operation)
        return operation_receipt_from_proto(operation)
    except (ValidationError, ProtocolTransformError, ValueError) as error:
        raise CatalogClientError(f"Catalog returned a malformed operation: {error}") from error


def _run_ref(run_id: OperationId) -> common_pb2.OperationRef:
    """The platform handle a run is named by, re-proved against the row at the owner."""
    return common_pb2.OperationRef(
        pillar=common_pb2.PLATFORM_PILLAR_EXPERIENCE,
        kind=common_pb2.OPERATION_KIND_PIPELINE_RUN,
        operation_id=str(run_id),
    )


def _pipeline_run(message: pipelines_pb2.PipelineRun) -> PipelineRun:
    """One run answer: the receipt it carries, and the two facts beside it."""
    try:
        receipt = run_receipt_from_proto(message)
        phase = run_phase_from_proto(message.phase) if message.HasField("phase") else None
    except ProtocolTransformError as error:
        raise CatalogClientError(f"Catalog returned a malformed run: {error}") from error
    return PipelineRun(
        receipt=receipt,
        plan_digest=Sha256Digest(message.plan_digest),
        destination=message.destination,
        phase=phase,
        output_snapshot=(
            _uuid(message.output_snapshot_id, "run output snapshot")
            if message.HasField("output_snapshot_id")
            else None
        ),
    )


def _admitted_plan(message: pipelines_pb2.AdmittedPlan) -> AdmittedPlan:
    """One admission, refusing an outlet compatibility the domain does not name."""
    try:
        return admitted_plan_from_proto(message)
    except ProtocolTransformError as error:
        raise CatalogClientError(f"Catalog returned a malformed plan admission: {error}") from error


def _integer(document: Mapping[str, object], name: str) -> int:
    value = document.get(name)
    if isinstance(value, bool) or not isinstance(value, int):
        raise CatalogClientError(f"Catalog response needs integer {name}")
    return value


def _batch_id(resource_ref: str) -> UUID:
    """The batch identity inside the `registration-batch:<uuid>` ref the owner echoes."""

    kind, _, identity = resource_ref.partition(":")
    if kind != "registration-batch" or not identity:
        raise CatalogClientError(f"Catalog operation did not name a batch: {resource_ref!r}")
    return _uuid(identity, "batch identity")


def _uuid(value: str, what: str) -> UUID:
    try:
        return UUID(value)
    except ValueError as exc:
        raise CatalogClientError(f"Catalog returned a malformed {what}") from exc


def _echo[T](submitted: T, stored: T, what: str) -> T:
    """The one echo law: a resource Catalog stores must be the resource it was sent.

    Every synchronous registration below is idempotent by content, so the response
    body is the stored resource. A catalog that answers with different facts under
    the submitted identity would let a later reader cite semantics nobody published.
    """
    if stored != submitted:
        raise CatalogClientError(f"Catalog registered {what} disagrees with the submitted one")
    return stored


def _string_mapping(value: object, field: str) -> dict[str, object]:
    """Parse one untrusted Catalog value into a string-keyed document.

    The sole owner of "this response field must be a text-keyed object", so callers
    hand over the raw value instead of re-checking it and re-narrowing to Unknown.
    """
    if not isinstance(value, dict):
        raise CatalogClientError(f"Catalog {field} must be an object")
    raw = cast("dict[object, object]", value)
    if not all(isinstance(key, str) for key in raw):
        raise CatalogClientError(f"Catalog {field} keys must be text")
    return {cast("str", key): item for key, item in raw.items()}


def _representation(value: object) -> Representation:
    document = _string_mapping(value, "representation")
    objects = document.get("objects")
    size = document.get("size_bytes")
    if not isinstance(objects, int) or isinstance(objects, bool):
        raise CatalogClientError("Catalog representation object count must be an integer")
    if not isinstance(size, int) or isinstance(size, bool):
        raise CatalogClientError("Catalog representation size must be an integer")
    try:
        form = RepresentationFormat(_text(document, "format"))
    except ValueError as error:
        raise CatalogClientError("Catalog named a form this client cannot read") from error
    return Representation(form, objects, size)


def _object_read(value: object) -> ObjectRead:
    document = _string_mapping(value, "object access")
    digest = _text(document, "sha256")
    if len(digest) != 64 or any(char not in "0123456789abcdef" for char in digest):
        raise CatalogClientError("Catalog object access has a malformed SHA-256")
    return ObjectRead(Sha256Digest(digest), _text(document, "url"))


def _content_ref(value: object, field: str) -> ContentRef:
    document = _string_mapping(value, field)
    return ContentRef(
        ArtifactId(_text(document, "artifact_id")),
        Sha256Digest(_text(document, "sha256")),
    )


def _object_reads(document: Mapping[str, object]) -> ObjectReads:
    """Parse the expiring object grant shared by generic and typed access."""

    if _text(document, "grant") != "objects":
        raise CatalogClientError("Catalog did not offer object reads")
    expires = document.get("expires_in_s")
    if not isinstance(expires, int) or isinstance(expires, bool) or expires <= 0:
        raise CatalogClientError("Catalog access expiry must be a positive integer")
    listed = document.get("objects")
    if not isinstance(listed, list):
        raise CatalogClientError("Catalog access objects must be an array")
    return ObjectReads(tuple(_object_read(item) for item in cast("list[object]", listed)), expires)


# --- Capability approvals: the one wire ⇄ domain transform beside the routes --------------


def _suite_in_wire(name: str, manifest: SuiteManifest) -> dict[str, object]:
    # No sha256 on the wire: the catalog recomputes the content address from the
    # manifest, and this client re-verifies it on the echo.
    return {"name": name, "suite": suite_to_dict(manifest)}


def _checkpoint_ref(value: object) -> ContentRef:
    document = _string_mapping(value, "training checkpoint")
    return ContentRef(
        ArtifactId(_text(document, "checkpoint_id")),
        Sha256Digest(_text(document, "sha256")),
    )


def _policy_record(resource: operations_pb2.DeployablePolicyResource) -> DeployablePolicyRecord:
    """One governed policy resource, reconstructed as its complete domain record."""

    return DeployablePolicyRecord(
        name=resource.name,
        policy=deployable_policy_from_proto(resource.policy),
        task=task_contract_ref_from_proto(resource.task),
        embodiment_id=EmbodimentId(resource.embodiment_id),
        action_interface_id=ActionInterfaceId(resource.action_interface_id),
        dataset=resource.dataset,
    )


def _snapshot_facts(
    snapshot_id: DatasetSnapshotId, message: membership_pb2.DatasetSnapshot
) -> SnapshotFacts:
    """The fixed-width membership facts, proved to be about the pinned content.

    The name a caller holds carries the digest, so the two must agree: a catalog
    answering about other content fails closed here rather than training on it.
    The dataset comes from whichever identity arm the snapshot has — a selection
    belongs to no dataset and answers to its own entry name, which is what every
    reader of a selection binds to.
    """

    if message.digest != str(snapshot_id.digest):
        raise CatalogDigestMismatchError(
            f"snapshot digest mismatch: {snapshot_id} resolved to {message.digest}"
        )
    arm = message.WhichOneof("identity")
    if arm == "dataset":
        dataset = message.dataset.dataset
    elif arm == "selection":
        dataset = message.name
    else:
        raise CatalogClientError(f"snapshot {snapshot_id} names neither a dataset nor a selection")
    try:
        return SnapshotFacts(
            id=snapshot_id,
            dataset=dataset,
            schema_id=SchemaId(message.schema_id),
            members=message.members,
            member_bytes=message.member_bytes,
            parts=message.parts,
        )
    except ValueError as error:
        raise CatalogClientError(f"invalid snapshot facts: {error}") from error


def _correlated[RequestT](request: RequestT, echoed: RequestT, what: str) -> None:
    """The one correlation law: a resource must answer the request that asked for it."""
    if echoed != request:
        raise CatalogClientError(f"Catalog returned another {what} request")


def _entry_name(value: str, what: str) -> str:
    """A catalog entry that answers to no name is not a record — the schema says so."""
    if not value:
        raise CatalogClientError(f"Catalog returned a {what} without its entry name")
    return value


def _capability_approval_record(
    resource: applications_pb2.CapabilityApprovalResource,
) -> CapabilityApprovalRecord:
    """One generated resource → the approval, through the transform Autonomy owns."""
    try:
        approval = capability_approval_from_proto(resource.approval)
    except ProtocolTransformError as error:
        raise CatalogClientError(
            f"Catalog returned a malformed capability approval: {error}"
        ) from error
    if resource.evidence_attestation != applications_pb2.EVIDENCE_ATTESTATION_CATALOG:
        raise CatalogClientError("Catalog did not attest the approval evidence")
    return CapabilityApprovalRecord(
        name=_entry_name(resource.name, "capability approval"),
        approval=approval,
        evidence_attestation=EvidenceAttestation.CATALOG,
    )


def _suite_record(document: dict[str, object]) -> SuiteRecord:
    try:
        manifest = suite_from_dict(document.get("suite"))
        sha256 = _text(document, "sha256")
        created_at = datetime.fromisoformat(_text(document, "created_at"))
    except ValueError as exc:
        raise CatalogClientError(f"Catalog returned a malformed evaluation suite: {exc}") from exc
    # The pinned pair must agree: a stored digest that is not this manifest's own
    # would let a gate cite a suite whose entries it never ran.
    if suite_digest(manifest) != sha256:
        raise CatalogClientError("Catalog suite digest disagrees with its recomputed manifest")
    return SuiteRecord(
        name=_text(document, "name"),
        suite_id=_text(document, "suite_id"),
        sha256=Sha256Digest(sha256),
        manifest=manifest,
        created_at=created_at,
    )


def _policy_content_digest(content: Mapping[str, object]) -> str:
    """The content address of one policy document.

    The canonical serialization is the catalog's frozen one
    (``sx_catalog.model.policy_content_digest``, the ``suite_digest`` shape); it is
    re-derived rather than imported precisely so that verifying an artifact never
    requires the catalog's or the policy vocabulary's code — a document plus this
    rule is enough.
    """
    # The values come straight out of `response.json()`, so they are JSON by
    # construction; `content_digest` rejects anything that is not.
    return content_digest(cast("Mapping[str, JsonValue]", content))


def _policy_artifact_record(document: dict[str, object]) -> PolicyArtifactRecord:
    try:
        kind = PolicyArtifactKind(_text(document, "kind"))
        content = _string_mapping(document.get("content"), "policy artifact content")
        sha256 = _text(document, "sha256")
        created_at = datetime.fromisoformat(_text(document, "created_at"))
    except ValueError as exc:
        raise CatalogClientError(f"Catalog returned a malformed policy artifact: {exc}") from exc
    if _policy_content_digest(content) != sha256:
        raise CatalogClientError("Catalog policy-artifact digest disagrees with its content")
    return PolicyArtifactRecord(
        artifact_id=_text(document, "artifact_id"),
        kind=kind,
        name=_text(document, "name"),
        sha256=Sha256Digest(sha256),
        content=content,
        created_at=created_at,
    )


def _dataset_record(document: dict[str, object]) -> DatasetRecord:
    try:
        return DatasetRecord(
            id=UUID(_text(document, "id")),
            project_id=UUID(_text(document, "project_id")),
            name=_text(document, "name"),
            created_at=datetime.fromisoformat(_text(document, "created_at")),
            updated_at=datetime.fromisoformat(_text(document, "updated_at")),
        )
    except ValueError as exc:
        raise CatalogClientError(f"Catalog returned a malformed dataset: {exc}") from exc


def _segment_annotation_record(
    resource: annotations_pb2.SegmentAnnotationResource,
) -> SegmentAnnotationRecord:
    if not resource.HasField("annotated_at"):
        raise CatalogClientError("Catalog returned a segment annotation without its write time")
    try:
        stage = annotation_stage_from_proto(resource.stage)
    except ProtocolTransformError as error:
        raise CatalogClientError(f"Catalog returned an unknown annotation stage: {error}") from (
            error
        )
    return SegmentAnnotationRecord(
        dataset=resource.dataset,
        segment_id=resource.segment_id,
        stage=stage,
        sha256=Sha256Digest(resource.annotation_sha256),
        annotated_at=resource.annotated_at.ToDatetime(tzinfo=UTC),
    )


def _world_run_record(resource: evidence_pb2.WorldRunResource) -> WorldRunRecord:
    try:
        run = world_run_from_proto(resource.run)
    except ProtocolTransformError as error:
        raise CatalogClientError(f"Catalog returned a malformed world run: {error}") from error
    if not resource.HasField("created_at"):
        raise CatalogClientError("Catalog returned a world run without its creation time")
    return WorldRunRecord(
        name=_entry_name(resource.name, "world run"),
        run=run,
        created_at=resource.created_at.ToDatetime(tzinfo=UTC),
    )


def _application_qualification_record(
    resource: applications_pb2.ApplicationQualificationResource,
) -> ApplicationQualificationRecord:
    try:
        qualification = application_qualification_from_proto(resource.qualification)
    except ProtocolTransformError as error:
        raise CatalogClientError(
            f"Catalog returned a malformed application qualification: {error}"
        ) from error
    if not resource.HasField("created_at"):
        raise CatalogClientError(
            "Catalog returned an application qualification without its creation time"
        )
    return ApplicationQualificationRecord(
        qualification=qualification,
        created_at=resource.created_at.ToDatetime(tzinfo=UTC),
    )


def _robot_application_record(
    resource: applications_pb2.RobotApplicationResource,
) -> RobotApplicationRecord:
    try:
        application = robot_application_from_proto(resource.application)
    except ProtocolTransformError as error:
        raise CatalogClientError(
            f"Catalog returned a malformed robot application: {error}"
        ) from error
    if not resource.HasField("created_at"):
        raise CatalogClientError("Catalog returned a robot application without its creation time")
    return RobotApplicationRecord(
        name=_entry_name(resource.name, "robot application"),
        application=application,
        created_at=resource.created_at.ToDatetime(tzinfo=UTC),
    )
