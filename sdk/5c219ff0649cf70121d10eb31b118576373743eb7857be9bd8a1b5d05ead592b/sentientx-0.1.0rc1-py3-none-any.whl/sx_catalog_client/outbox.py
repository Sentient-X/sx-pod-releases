"""Durable local episode outbox; capture never waits for the network."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import time
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, cast
from uuid import uuid4

from sx_contracts import CatalogSegmentRef, Sha256Digest, decode
from sx_contracts.identity import JsonValue, canonical_json, file_digest

from sx_catalog_client.client import (
    CatalogClient,
    EpisodeUpload,
    LayerUpload,
    RegisteredEpisode,
    RegisteredLayer,
    RegistrationConflict,
    validate_native_layer,
)

if TYPE_CHECKING:
    from sx_episodes import EpisodeLayerKind
    from sx_episodes.atif import AgentLayerKind


class EpisodeOutboxError(RuntimeError):
    """The durable outbox cannot preserve or register an episode safely."""


@dataclass(frozen=True, slots=True)
class PendingEpisode:
    sha256: Sha256Digest
    dataset: str
    rrd: Path
    marker: Path
    created_at: datetime


@dataclass(frozen=True, slots=True)
class PendingLayer:
    sha256: Sha256Digest
    base_sha256: Sha256Digest
    dataset: str
    kind: EpisodeLayerKind | AgentLayerKind
    rrd: Path
    marker: Path
    created_at: datetime


@dataclass(frozen=True, slots=True)
class OutboxHealth:
    pending: int
    oldest_pending_age_s: float
    bytes_on_disk: int


@dataclass(frozen=True, slots=True)
class OutboxRetention:
    """Explicit policy for pruning registered RRD copies, never raw capture."""

    keep_registered_for_s: float

    def __post_init__(self) -> None:
        if self.keep_registered_for_s < 0.0:
            raise EpisodeOutboxError("outbox retention must be non-negative")


class EpisodeOutbox:
    """An atomic RRD copy plus marker queue retried by dataset and content SHA-256."""

    def __init__(self, root: Path) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)

    def enqueue(self, path: Path, *, dataset: str) -> PendingEpisode:
        from sx_episodes import validate_episode

        summary = validate_episode(path)
        if not dataset.strip():
            raise EpisodeOutboxError("outbox dataset name must be non-empty")
        digest = file_digest(path)
        stem = _registration_stem(dataset, digest)
        rrd = self.root / f"{stem}.rrd"
        pending = self.root / f"{stem}.pending.json"
        registered = self.root / f"{stem}.registered.json"
        if registered.exists():
            return _pending_from_registered(registered, rrd)
        _copy_rrd(path, rrd, digest)
        created_at = datetime.now(UTC)
        marker = {
            "sha256": digest,
            "dataset": dataset,
            "episode_id": str(summary.episode_id),
            "use": summary.use.value,
            "created_at": created_at.isoformat(),
        }
        _atomic_json(pending, marker)
        return PendingEpisode(digest, dataset, rrd, pending, created_at)

    def enqueue_layer(self, path: Path, *, dataset: str) -> PendingLayer:
        """Durably queue a typed overlay after it has atomically closed locally."""
        summary = validate_native_layer(path)
        if not dataset.strip():
            raise EpisodeOutboxError("outbox dataset name must be non-empty")
        digest = file_digest(path)
        stem = _registration_stem(dataset, digest)
        rrd = self.root / f"{stem}.rrd"
        pending = self.root / f"{stem}.pending-layer.json"
        registered = self.root / f"{stem}.registered-layer.json"
        if registered.exists():
            return _pending_layer_from_registered(registered, rrd)
        _copy_rrd(path, rrd, digest)
        created_at = datetime.now(UTC)
        _atomic_json(
            pending,
            {
                "sha256": digest,
                "base_sha256": summary.base_sha256,
                "dataset": dataset,
                "kind": summary.kind.value,
                "recording_id": summary.recording_id,
                "created_at": created_at.isoformat(),
            },
        )
        return PendingLayer(
            digest,
            summary.base_sha256,
            dataset,
            summary.kind,
            rrd,
            pending,
            created_at,
        )

    def pending(self) -> tuple[PendingEpisode, ...]:
        return tuple(
            sorted(
                (_read_pending(path) for path in self.root.glob("*.pending.json")),
                key=lambda item: item.created_at,
            )
        )

    def pending_layers(self) -> tuple[PendingLayer, ...]:
        return tuple(
            sorted(
                (_read_pending_layer(path) for path in self.root.glob("*.pending-layer.json")),
                key=lambda item: item.created_at,
            )
        )

    def flush(
        self,
        client: CatalogClient,
        *,
        timeout_s: float = 120.0,
        poll_s: float = 0.5,
    ) -> tuple[RegisteredEpisode, ...]:
        """Attempt every pending SHA and return only registrations proven READY.

        A failed item remains pending, but it does not prevent independent later
        items from making progress.  After the pass, the first failure is raised
        with its original type so existing retry boundaries remain truthful.
        """
        completed: list[RegisteredEpisode] = []
        first_failure: Exception | None = None
        for item in self.pending():
            try:
                upload = EpisodeUpload.of(
                    client,
                    item.dataset,
                    item.rrd,
                    on_duplicate=RegistrationConflict.ERROR,
                )
                operation = client.register(upload)
                segment_id = client.result(operation, timeout_s=timeout_s, poll_s=poll_s)
                marker = self.root / (
                    f"{_registration_stem(item.dataset, item.sha256)}.registered.json"
                )
                _atomic_json(
                    marker,
                    {
                        "sha256": item.sha256,
                        "dataset": item.dataset,
                        "segment_id": segment_id,
                        "workflow_id": operation.id,
                        "registered_at": datetime.now(UTC).isoformat(),
                        "created_at": item.created_at.isoformat(),
                    },
                )
                item.marker.unlink()
                completed.append(
                    RegisteredEpisode(operation.id, segment_id, upload.sha256, upload.summary)
                )
            except Exception as error:
                if first_failure is None:
                    first_failure = error
        if first_failure is not None:
            raise first_failure
        return tuple(completed)

    def flush_layers(
        self,
        client: CatalogClient,
        *,
        timeout_s: float = 120.0,
        poll_s: float = 0.5,
    ) -> tuple[RegisteredLayer, ...]:
        """Attach queued overlays only to their exact locally proven READY base."""
        completed: list[RegisteredLayer] = []
        first_failure: Exception | None = None
        for item in self.pending_layers():
            try:
                base = self.registered_segment(item.dataset, str(item.base_sha256))
                upload = LayerUpload.of(
                    client,
                    item.dataset,
                    item.rrd,
                    on_duplicate=RegistrationConflict.OVERWRITE,
                )
                operation = client.register(upload)
                segment_id = client.result(operation, timeout_s=timeout_s, poll_s=poll_s)
                if segment_id != base.segment_id:
                    raise EpisodeOutboxError(
                        "overlay registration resolved to a segment other than its exact base: "
                        f"{segment_id!r} != {base.segment_id!r}"
                    )
                marker = self.root / (
                    f"{_registration_stem(item.dataset, item.sha256)}.registered-layer.json"
                )
                _atomic_json(
                    marker,
                    {
                        "sha256": item.sha256,
                        "base_sha256": item.base_sha256,
                        "dataset": item.dataset,
                        "kind": item.kind.value,
                        "segment_id": segment_id,
                        "workflow_id": operation.id,
                        "registered_at": datetime.now(UTC).isoformat(),
                        "created_at": item.created_at.isoformat(),
                    },
                )
                item.marker.unlink()
                completed.append(
                    RegisteredLayer(operation.id, segment_id, upload.sha256, upload.summary)
                )
            except Exception as error:
                if first_failure is None:
                    first_failure = error
        if first_failure is not None:
            raise first_failure
        return tuple(completed)

    def registered_segment(self, dataset: str, sha256: str) -> CatalogSegmentRef:
        """The exact catalog segment a flushed episode registered as.

        Reads the durable ``.registered.json`` marker — one path for fresh and
        crash-replayed registrations. An episode without a marker has not completed
        registration in this dataset; that is a typed error, never a guessed segment
        paired with the caller's dataset.
        """
        marker = self.root / f"{_registration_stem(dataset, sha256)}.registered.json"
        if not marker.exists():
            raise EpisodeOutboxError(
                f"no registered outbox marker for dataset {dataset!r} and sha256 {sha256}"
            )
        document = _read_json(marker)
        if _text(document, "sha256") != sha256:
            raise EpisodeOutboxError(f"registered outbox marker names another sha256: {marker}")
        if _text(document, "dataset") != dataset:
            raise EpisodeOutboxError(f"registered outbox marker names another dataset: {marker}")
        return CatalogSegmentRef(dataset, _text(document, "segment_id"), Sha256Digest(sha256))

    def health(self) -> OutboxHealth:
        pending = (*self.pending(), *self.pending_layers())
        ordered = sorted(pending, key=lambda item: item.created_at)
        now = datetime.now(UTC)
        oldest = max(0.0, (now - ordered[0].created_at).total_seconds()) if ordered else 0.0
        size = sum(path.stat().st_size for path in self.root.glob("*") if path.is_file())
        return OutboxHealth(len(ordered), oldest, size)

    def prune(self, policy: OutboxRetention) -> tuple[Path, ...]:
        """Remove only registered outbox copies older than the explicit policy."""
        now = time.time()
        removed: list[Path] = []
        markers = (
            *self.root.glob("*.registered.json"),
            *self.root.glob("*.registered-layer.json"),
        )
        for marker in markers:
            document = _read_json(marker)
            registered_at = _datetime(document, "registered_at")
            if now - registered_at.timestamp() < policy.keep_registered_for_s:
                continue
            rrd = _rrd_for_marker(
                marker,
                dataset=_text(document, "dataset"),
                sha256=_text(document, "sha256"),
            )
            rrd.unlink(missing_ok=True)
            marker.unlink()
            removed.extend((rrd, marker))
        return tuple(removed)


def _atomic_json(path: Path, document: Mapping[str, JsonValue]) -> None:
    temporary = path.with_name(f".{path.name}.{uuid4().hex}.partial")
    try:
        with temporary.open("x", encoding="utf-8") as stream:
            stream.write(canonical_json(document))
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _read_pending(path: Path) -> PendingEpisode:
    document = _read_json(path)
    digest = _text(document, "sha256")
    dataset = _text(document, "dataset")
    return PendingEpisode(
        Sha256Digest(digest),
        dataset,
        _rrd_for_marker(path, dataset=dataset, sha256=digest),
        path,
        _datetime(document, "created_at"),
    )


def _read_pending_layer(path: Path) -> PendingLayer:
    from sx_episodes import EpisodeLayerKind
    from sx_episodes.atif import AgentLayerKind

    document = _read_json(path)
    digest = _text(document, "sha256")
    base_digest = _text(document, "base_sha256")
    dataset = _text(document, "dataset")
    try:
        kind = EpisodeLayerKind(_text(document, "kind"))
    except ValueError:
        try:
            kind = AgentLayerKind(_text(document, "kind"))
        except ValueError as error:
            raise EpisodeOutboxError("outbox marker has unknown overlay kind") from error
    return PendingLayer(
        Sha256Digest(digest),
        Sha256Digest(base_digest),
        dataset,
        kind,
        _rrd_for_marker(path, dataset=dataset, sha256=digest),
        path,
        _datetime(document, "created_at"),
    )


def _pending_from_registered(path: Path, rrd: Path) -> PendingEpisode:
    document = _read_json(path)
    digest = _text(document, "sha256")
    dataset = _text(document, "dataset")
    expected = path.with_name(f"{_registration_stem(dataset, digest)}.registered.json")
    if path != expected:
        raise EpisodeOutboxError(
            f"registered outbox marker identity disagrees with its path: {path}"
        )
    return PendingEpisode(
        Sha256Digest(digest),
        dataset,
        rrd,
        path,
        _datetime(document, "created_at"),
    )


def _pending_layer_from_registered(path: Path, rrd: Path) -> PendingLayer:
    from sx_episodes import EpisodeLayerKind
    from sx_episodes.atif import AgentLayerKind

    document = _read_json(path)
    digest = _text(document, "sha256")
    base_digest = _text(document, "base_sha256")
    dataset = _text(document, "dataset")
    expected = path.with_name(f"{_registration_stem(dataset, digest)}.registered-layer.json")
    if path != expected:
        raise EpisodeOutboxError(
            f"registered outbox marker identity disagrees with its path: {path}"
        )
    try:
        kind = EpisodeLayerKind(_text(document, "kind"))
    except ValueError:
        try:
            kind = AgentLayerKind(_text(document, "kind"))
        except ValueError as error:
            raise EpisodeOutboxError("outbox marker has unknown overlay kind") from error
    return PendingLayer(
        Sha256Digest(digest),
        Sha256Digest(base_digest),
        dataset,
        kind,
        rrd,
        path,
        _datetime(document, "created_at"),
    )


def _registration_stem(dataset: str, sha256: str) -> str:
    """Filesystem identity for one registration, not merely one byte string."""
    if not dataset.strip():
        raise EpisodeOutboxError("outbox dataset name must be non-empty")
    if re.fullmatch(r"[a-f0-9]{64}", sha256) is None:
        raise EpisodeOutboxError("outbox sha256 must be lowercase SHA-256")
    dataset_digest = hashlib.sha256(dataset.encode()).hexdigest()
    return f"{sha256}.{dataset_digest}"


def _rrd_for_marker(
    marker: Path,
    *,
    dataset: str | None = None,
    sha256: str | None = None,
) -> Path:
    if dataset is not None and sha256 is not None:
        stem = _registration_stem(dataset, sha256)
        allowed = {
            f"{stem}.pending.json",
            f"{stem}.pending-layer.json",
            f"{stem}.registered.json",
            f"{stem}.registered-layer.json",
        }
        if marker.name not in allowed:
            raise EpisodeOutboxError(f"outbox marker identity disagrees with its path: {marker}")
        return marker.with_name(f"{stem}.rrd")
    for suffix in (".registered-layer.json", ".registered.json"):
        if marker.name.endswith(suffix):
            return marker.with_name(f"{marker.name.removesuffix(suffix)}.rrd")
    raise EpisodeOutboxError(f"unknown outbox marker path: {marker}")


def _copy_rrd(path: Path, rrd: Path, digest: str) -> None:
    if not rrd.exists():
        temporary = rrd.with_name(f".{digest}.{uuid4().hex}.partial")
        try:
            with path.open("rb") as source, temporary.open("xb") as destination:
                shutil.copyfileobj(source, destination)
                destination.flush()
                os.fsync(destination.fileno())
            if file_digest(temporary) != digest:
                raise EpisodeOutboxError("outbox copy digest changed")
            os.replace(temporary, rrd)
        finally:
            temporary.unlink(missing_ok=True)
    elif file_digest(rrd) != digest:
        raise EpisodeOutboxError(f"outbox RRD digest mismatch: {rrd}")


def _read_json(path: Path) -> dict[str, object]:
    try:
        value: object = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as exc:
        raise EpisodeOutboxError(f"malformed outbox marker: {path}") from exc
    if not isinstance(value, dict):
        raise EpisodeOutboxError(f"outbox marker must be an object: {path}")
    raw = cast("dict[object, object]", value)
    if not all(isinstance(key, str) for key in raw):
        raise EpisodeOutboxError(f"outbox marker keys must be text: {path}")
    return {cast("str", key): item for key, item in raw.items()}


def _text(document: Mapping[str, object], name: str) -> str:
    """An outbox marker field that is blank names nothing — the one rule beyond the kit."""
    value = decode.text(document, name, where="outbox marker", error=EpisodeOutboxError)
    if not value:
        raise EpisodeOutboxError(f"outbox marker needs non-empty {name}")
    return value


def _datetime(document: dict[str, object], name: str) -> datetime:
    try:
        value = datetime.fromisoformat(_text(document, name))
    except ValueError as exc:
        raise EpisodeOutboxError(f"outbox marker has invalid {name}") from exc
    if value.tzinfo is None:
        raise EpisodeOutboxError(f"outbox marker {name} must include a timezone")
    return value
