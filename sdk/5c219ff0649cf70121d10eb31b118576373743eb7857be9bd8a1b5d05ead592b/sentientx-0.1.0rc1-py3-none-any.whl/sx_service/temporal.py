"""The only Temporal client connection seam.

Every starter and worker gets the wire-safe converter and OpenTelemetry interceptor from
the same connection.  Workflow payloads remain payloads; the interceptor propagates W3C
context in Temporal headers and emits replay-safe workflow/activity operation spans.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from sx_contracts.wire import temporal_data_converter
from temporalio.client import Client, Interceptor
from temporalio.contrib.opentelemetry import TracingInterceptor

from sx_service.observability import current_observability


async def connect_temporal(
    address: str,
    *,
    namespace: str = "default",
    interceptors: Sequence[Interceptor] = (),
    **options: Any,
) -> Client:
    """Connect with propagation and the canonical payload converter by construction."""
    if "data_converter" in options:
        raise TypeError("connect_temporal owns the platform data_converter")
    if "interceptors" in options:
        raise TypeError("pass interceptors through the named interceptors parameter")
    runtime = current_observability()
    return await Client.connect(
        address,
        namespace=namespace,
        data_converter=temporal_data_converter(),
        interceptors=(
            TracingInterceptor(tracer=runtime.tracer("sx-service.temporal")),
            *interceptors,
        ),
        **options,
    )
