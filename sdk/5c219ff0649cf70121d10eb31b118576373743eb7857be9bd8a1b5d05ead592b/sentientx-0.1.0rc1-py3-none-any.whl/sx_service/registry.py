"""The one registry of platform doors and their development and hosted addresses.

Callers select an explicit :class:`EndpointProfile`; the registry never guesses that a missing
production address means localhost.  Application processes use :meth:`Door.process_url`, which
permits a development default only outside ``SX_ENVIRONMENT=production``.  Deployment renderers
use :func:`resolve_url` and inject the resulting canonical ``SX_*_URL`` values.

Everything downstream derives from these rows (one rendered source per truth):

* ``python -m sx_service dev-ports`` — the local-profile port contract;
* ``python -m sx_service console-ts`` — ``platform/console/src/platform.gen.ts``, consumed by
  the console's ``vite.config.ts`` (its per-door proxy loop), its shell, and its one
  door-bound fetch client;
* ``python -m sx_service table`` — the human port table for READMEs;
* ``python -m sx_service rate-limits`` — the class half of ``docs/RATE-LIMITS.md``
  (``tools/check_rate_bindings.py --write`` writes the file, appending what each
  adopting door binds per route — a fact only a built door holds);
* ``sx_authd``'s ``allowed_next_origins`` (built from ``CONSOLE`` at import time);
* the root contract test ``tests/test_platform_registry.py`` (audiences against sx_authd's
  executable registry, Tilt forwards, retired env-var names).

Deliberately absent: in-cluster data and service endpoints. Kubernetes DNS renders those
directly into workloads; this registry only models addresses selected by product clients.
Credentials are also absent: identity stays per-app by design.

Audience strings are the sx_authd ``audiences`` registry's values (the SQL registry is the
one executable source; the root contract test pins these to it byte-for-byte).

This is the one module in the kit that reads platform URL environment variables — see
``sx_service.testing``. Hosted product identity is a fact here; workload placement remains
a deployment fact.
"""

import os
from dataclasses import dataclass
from enum import StrEnum


class Pillar(StrEnum):
    """The four platform pillars (docs/PLATFORM-MODEL.md), spelled as the UI renders them."""

    EXPERIENCE = "Experience"
    WORLDS = "Worlds"
    AUTONOMY = "Autonomy"
    FLEET = "Fleet"


class WorkspaceGroup(StrEnum):
    """Human launcher groups: the loop, in the brand's words (``docs/BRAND.md``).

    A robot is shown, taught, tested, trusted, and improved; the project says what it
    should know. These describe how people find work, not which platform pillar owns the
    backing fact. Ownership remains in :class:`Pillar`; leaking it into navigation is how
    an embodiment specialist ended up presented as an "Experience" destination.
    """

    PROJECTS = "Projects"
    SHOW = "Show it"
    TEACH = "Teach it"
    TEST = "Test it"
    TRUST = "Trust it"
    IMPROVE = "Improve it"


class DoorId(StrEnum):
    """Stable identities used by clients, deployment, generated UI, and station profiles."""

    AUTH = "auth"
    AUTH_MCP = "auth-mcp"
    AUTH_PUBLIC = "auth-public"
    FACTORY = "factory"
    FLEET = "fleet"
    WADDLE = "waddle"
    LABELER = "labeler"
    INGEST = "ingest"
    CATALOG = "catalog"
    TASKPEDIA = "taskpedia"
    WORLDS = "worlds"
    POLICY_WS = "policy-ws"
    SUPERVISION_WS = "supervisors-serving"
    AUTONOMY = "autonomy"
    REGISTRY = "registry"
    TELEMETRY = "telemetry"


class EndpointProfile(StrEnum):
    """The two product-client contexts for one logical door."""

    HOSTED = "hosted"
    DEVELOPMENT = "development"


class EndpointResolutionError(ValueError):
    """A door cannot be resolved for the requested profile."""


class MissingEndpointError(RuntimeError):
    """A production process lacks a declared, rendered door address."""


ENDPOINT_SELECTION_ENV = "SX_PLATFORM_ENDPOINTS"
CONTROL_PLANE_DEV_PORT = 8401


def _environment(name: str) -> str | None:
    """The registry's one read boundary for ambient process configuration."""

    return os.environ.get(name)


def _production_endpoint_selection() -> frozenset[DoorId] | None:
    """Return the renderer-owned production endpoint selection.

    Kubernetes ``envFrom`` projects application Secrets after the deployment
    inventory has selected its endpoints.  A stale URL in one of those broad
    Secrets must not silently grow a workload's platform reach, so production
    processes accept configured door URLs only when the renderer also names the
    door in this independent selection.
    """

    if (_environment("SX_ENVIRONMENT") or "development") != "production":
        return None
    raw = _environment(ENDPOINT_SELECTION_ENV)
    if raw is None:
        raise MissingEndpointError(
            f"production requires rendered endpoint selection {ENDPOINT_SELECTION_ENV}"
        )
    names = [] if not raw else [part.strip() for part in raw.split(",")]
    if any(not name for name in names) or len(names) != len(set(names)):
        raise MissingEndpointError(f"{ENDPOINT_SELECTION_ENV} must contain unique door IDs")
    try:
        return frozenset(DoorId(name) for name in names)
    except ValueError as error:
        raise MissingEndpointError(
            f"{ENDPOINT_SELECTION_ENV} contains an unknown door ID"
        ) from error


@dataclass(frozen=True, slots=True)
class HostedPlatform:
    """One hosted product origin from which every public door is derived."""

    name: str
    domain: str


HOSTED_PLATFORM = HostedPlatform("hosted", "sentientx.io")


@dataclass(frozen=True, slots=True)
class Door:
    """One served platform door: how it binds in dev and how every consumer reaches it.

    ``dev_managed`` marks doors the Kind/Tilt profile starts. Development-only runtime
    sockets keep a row so their local port and
    environment spelling stay canonical, but have no ``public_subdomain``: runtime
    placement is not a stable platform door.
    """

    name: DoorId
    env_var: str
    # An isolated owner process still binds this port; normal dev clients use the application.
    dev_port: int
    # The sx_authd audiences guarding the door — usually one, but a door that hosts more
    # than one route family carries the audience of each (they are separate trust domains
    # and do not merge). Empty = a local/unguarded wire.
    audiences: tuple[str, ...]
    scheme: str = "http"
    dev_host: str = "127.0.0.1"
    path: str = ""
    dev_managed: bool = True
    public_subdomain: str | None = None

    @property
    def isolated_url(self) -> str:
        """An explicitly started owner fixture, outside the normal local application."""
        return f"{self.scheme}://{self.dev_host}:{self.dev_port}{self.path}"

    @property
    def dev_url(self) -> str:
        if not self.dev_managed:
            return self.isolated_url
        name = DoorId.AUTH if self.name is DoorId.AUTH_PUBLIC else self.name
        return f"{self.scheme}://{self.dev_host}:{CONTROL_PLANE_DEV_PORT}/d/{name}{self.path}"

    def process_url(self) -> str:
        """Read a rendered process address, allowing loopback only in development.

        ``SX_ENVIRONMENT=production`` is stamped by the deployment renderer on every workload.
        A production process with no injected URL is therefore a typed startup failure, not a
        client that quietly connects to its own container.
        """

        selection = _production_endpoint_selection()
        if selection is not None and self.name not in selection:
            raise MissingEndpointError(
                f"production door {self.name} is not declared by {ENDPOINT_SELECTION_ENV}"
            )
        configured = (_environment(self.env_var) or "").strip().rstrip("/")
        if configured:
            return configured
        if (_environment("SX_ENVIRONMENT") or "development") == "production":
            raise MissingEndpointError(
                f"production requires rendered endpoint {self.env_var} for door {self.name}"
            )
        return self.dev_url

    def configured_url(self) -> str | None:
        """Return a declared process override without inventing a profile default.

        Offline-first adapters use this to make hosted synchronization opt-in while
        keeping the environment read and canonical variable spelling in this registry.
        Production ignores values for doors outside the renderer-owned selection.
        """

        selection = _production_endpoint_selection()
        if selection is not None and self.name not in selection:
            return None
        configured = (_environment(self.env_var) or "").strip().rstrip("/")
        return configured or None


def resolve_url(
    door: Door,
    profile: EndpointProfile,
) -> str:
    """Resolve one door without consulting ambient process configuration."""

    if profile is EndpointProfile.DEVELOPMENT:
        return door.dev_url
    if profile is EndpointProfile.HOSTED:
        if door.public_subdomain is None:
            raise EndpointResolutionError(f"door {door.name} has no hosted endpoint")
        scheme = "wss" if door.scheme == "ws" else "https"
        return f"{scheme}://{door.public_subdomain}.{HOSTED_PLATFORM.domain}{door.path}"
    raise EndpointResolutionError(f"unknown endpoint profile {profile!r}")


AUTH = Door(DoorId.AUTH, "SX_AUTH_URL", 8300, audiences=("auth",), public_subdomain="auth")
# The same sx_authd process seen by a BROWSER: cookies scope to the host name, so the
# public face defaults to `localhost` while backend introspection uses `127.0.0.1`.
AUTH_PUBLIC = Door(
    DoorId.AUTH_PUBLIC,
    "SX_AUTH_PUBLIC_URL",
    8300,
    audiences=("auth",),
    dev_host="localhost",
    public_subdomain="auth",
)
# The same identity operations an agent reaches, on the factory-storefront pattern: its own
# process, its own port, the same credential and the same meter class as the HTTP twin.
AUTH_MCP = Door(
    DoorId.AUTH_MCP,
    "SX_AUTH_MCP_URL",
    8310,
    audiences=("auth",),
    path="/mcp",
    public_subdomain="auth",
)
FACTORY = Door(
    DoorId.FACTORY, "SX_FACTORY_URL", 8000, audiences=("factory",), public_subdomain="factory"
)
FLEET = Door(DoorId.FLEET, "SX_FLEET_URL", 8100, audiences=("fleet",), public_subdomain="fleet")
WADDLE = Door(
    DoorId.WADDLE, "SX_WADDLE_URL", 8400, audiences=("waddle",), public_subdomain="waddle"
)
LABELER = Door(
    DoorId.LABELER,
    "SX_LABELER_URL",
    8422,
    audiences=("labeler",),
    public_subdomain="labeler",
)
INGEST = Door(
    DoorId.INGEST,
    "SX_PIPELINE_INGEST_URL",
    8420,
    audiences=("pipeline",),
    public_subdomain="pipeline",
)
CATALOG = Door(
    DoorId.CATALOG,
    "SX_CATALOG_URL",
    8423,
    audiences=("catalog",),
    public_subdomain="catalog",
)
TASKPEDIA = Door(
    DoorId.TASKPEDIA,
    "SX_TASKPEDIA_URL",
    8430,
    audiences=("catalog",),
    public_subdomain="taskpedia",
)
WORLDS = Door(
    DoorId.WORLDS,
    "SX_WORLDS_URL",
    8600,
    audiences=("worlds",),
    public_subdomain="worlds",
)
# The served-policy websocket (`train-policy-server`): a GPU process, never a
# local-profile child; LAN-local by construction (sx-serving), so no audience guards the wire.
POLICY_WS = Door(
    DoorId.POLICY_WS,
    "SX_POLICY_WS_URL",
    8601,
    audiences=(),
    scheme="ws",
    dev_managed=False,
    public_subdomain=None,
)
# The supervision serving wire (`WS /session` + `POST /assess`): robots hold the
# permanent session socket. Deployment-addressed like POLICY_WS — Modal, a GPU box,
# or the hand-started demo ladder on its dev port — never a local-profile child.
#
# Unlike POLICY_WS this is NOT LAN-local by construction: it is documented as a Modal
# deployment, i.e. reachable from the public internet, and it returns `override_action`
# values the robot applies to a physical arm. So it carries the `supervisors` audience
# and robots authenticate with their per-station machine key, exactly as they do to the
# control plane's hooks.
SUPERVISION_WS = Door(
    DoorId.SUPERVISION_WS,
    "SX_SUPERVISORS_SERVING_URL",
    8199,
    audiences=("supervisors",),
    scheme="ws",
    dev_managed=False,
)
# The one Autonomy door: the campaign control plane (the generated `ImprovementService`
# and the conversation routes at `/api/autonomy/conversations`) with the training-job
# service mounted beside it. Two audiences, deliberately unmerged — a key that starts a
# campaign spends budget across every pillar by proxy, which is not what a key that
# submits a training job may do.
AUTONOMY = Door(
    DoorId.AUTONOMY,
    "SX_AUTONOMY_URL",
    8800,
    audiences=("auto-improve", "train"),
    public_subdomain="autonomy",
)
REGISTRY = Door(
    DoorId.REGISTRY,
    "SX_REGISTRY_URL",
    5000,
    audiences=(),
    scheme="https",
    dev_managed=False,
    public_subdomain="registry",
)
TELEMETRY = Door(
    DoorId.TELEMETRY,
    "SX_TELEMETRY_URL",
    34318,
    audiences=("telemetry",),
    dev_managed=False,
    public_subdomain="telemetry",
)
DOORS: tuple[Door, ...] = (
    AUTH,
    AUTH_MCP,
    AUTH_PUBLIC,
    FACTORY,
    FLEET,
    WADDLE,
    LABELER,
    INGEST,
    CATALOG,
    TASKPEDIA,
    WORLDS,
    POLICY_WS,
    SUPERVISION_WS,
    AUTONOMY,
    REGISTRY,
    TELEMETRY,
)
DOORS_BY_ID = {door.name: door for door in DOORS}


#: The four platform pillars. They are the vocabulary of the agent surfaces — API, MCP, CLI,
#: ``docs/PLATFORM-MODEL.md`` — and are ownership, not navigation, so no human address spells
#: one. Enforced below, and in the console by ``platform/console/src/router.test.tsx``.
PILLAR_NAMES = frozenset({"experience", "worlds", "autonomy", "fleet"})

#: The address every project-scoped workspace hangs from, written in the router's own
#: parameter syntax. Both segments are slugs — the organization's and the project's — and
#: they are the *only* place the console says which project a page is about.
PROJECT_SCOPE_PREFIX = "/p/$org/$project"


@dataclass(frozen=True, slots=True)
class Workspace:
    """One human workspace inside the console: its route and access projection.

    ``id`` is the shell's stable vocabulary key (it carries the launcher icon);
    ``route_base`` is the durable URL prefix, while ``name`` is the job-oriented label people
    see. ``audiences`` names the Auth grants that make the workspace relevant. Projects accepts
    every project-bound audience because every admitted user resolves to one enabled Project;
    the Project does not widen what any pillar door permits. Labels can become clearer without
    breaking bookmarks. Exactly one workspace is the honest first destination for a new browser.
    Rendered into the console's ``platform.gen.ts``.

    ``project_scoped`` is *read* from the route rather than declared beside it: a workspace is
    project-scoped exactly when its address carries the project, so the router's placement and
    the audience check cannot disagree (standing rule 5 — one rendered source per truth). The
    console still receives the boolean; it is a projection of the path, not a second fact.

    Human-facing route segments name the verb, never the pillar (``docs/BRAND.md`` §11), which
    is why simulation lives at ``/simulate`` and supervision at ``/supervise``.
    """

    id: str
    group: WorkspaceGroup
    name: str
    route_base: str
    audiences: tuple[str, ...]
    requires_organization_membership: bool = False
    default: bool = False

    @property
    def project_scoped(self) -> bool:
        """Whether the selected Project narrows this workspace's audience check."""
        return self.route_base.startswith(PROJECT_SCOPE_PREFIX)

    def __post_init__(self) -> None:
        if self.requires_organization_membership == bool(self.audiences):
            raise ValueError(
                "a workspace requires either organization membership or at least one audience"
            )
        if PILLAR_NAMES & set(self.route_base.strip("/").split("/")):
            raise ValueError(
                f"{self.route_base!r} names a platform pillar; a human-facing route names "
                "the verb (docs/BRAND.md §11)"
            )


PROJECT_WORKSPACE_AUDIENCES = tuple(
    sorted(
        {audience for door in DOORS for audience in door.audiences}
        # These are grant-bearing Project capabilities, but not standalone public doors.
        | {"compute"}
    )
)


WORKSPACES: tuple[Workspace, ...] = (
    # The project *is* its address: the scope prefix with nothing after it, so the Project's
    # own tabs (Tasks, Robots, Loop, Settings) are its children rather than a workspace beside
    # it. `/projects` remains the unscoped front door where a Project is chosen or created.
    Workspace(
        "projects",
        WorkspaceGroup.PROJECTS,
        "Projects",
        PROJECT_SCOPE_PREFIX,
        PROJECT_WORKSPACE_AUDIENCES,
        default=True,
    ),
    Workspace(
        "experience-capture",
        WorkspaceGroup.SHOW,
        "Collect data",
        "/capture",
        ("factory",),
    ),
    Workspace(
        "experience-label",
        WorkspaceGroup.SHOW,
        "Label data",
        "/label",
        ("labeler",),
    ),
    Workspace(
        "experience-library",
        WorkspaceGroup.SHOW,
        "Explore data",
        f"{PROJECT_SCOPE_PREFIX}/library",
        ("catalog",),
    ),
    Workspace(
        "autonomy-training",
        WorkspaceGroup.TEACH,
        "Train",
        f"{PROJECT_SCOPE_PREFIX}/training",
        ("train", "waddle"),
    ),
    Workspace(
        "worlds",
        WorkspaceGroup.TEST,
        "Simulate",
        f"{PROJECT_SCOPE_PREFIX}/simulate",
        ("worlds",),
    ),
    Workspace(
        "fleet-deployment",
        WorkspaceGroup.TRUST,
        "Deploy",
        f"{PROJECT_SCOPE_PREFIX}/deploy",
        ("fleet",),
    ),
    Workspace(
        "fleet-supervision",
        WorkspaceGroup.TRUST,
        "Supervise",
        "/supervise",
        ("supervisors",),
    ),
    Workspace(
        "autonomy-improve",
        WorkspaceGroup.IMPROVE,
        "Improve",
        f"{PROJECT_SCOPE_PREFIX}/improve",
        ("auto-improve",),
    ),
)

DEFAULT_WORKSPACE = next(workspace for workspace in WORKSPACES if workspace.default)


@dataclass(frozen=True, slots=True)
class Console:
    """The one console origin: every workspace is a route on it, every door a path prefix.

    One origin means no CORS and one host-scoped ``sx_session`` cookie for the whole product.
    Each door it speaks to is reachable at :meth:`door_prefix` — the vite dev proxy and the
    hosted Caddy vhost render the same rows, and the prefix is stripped before the backend
    sees the request, so backends stay unchanged.
    """

    id: str
    dev_port: int
    public_subdomain: str
    doors: tuple[Door, ...]

    @property
    def dev_origin(self) -> str:
        return f"http://localhost:{self.dev_port}"

    @property
    def hosted_origin(self) -> str:
        return f"https://{self.public_subdomain}.{HOSTED_PLATFORM.domain}"

    def door_prefix(self, door: Door) -> str:
        return f"/d/{door.name}"


CONSOLE = Console(
    "console",
    8080,
    "app",
    doors=(
        FACTORY,
        LABELER,
        CATALOG,
        TASKPEDIA,
        WADDLE,
        WORLDS,
        AUTONOMY,
        FLEET,
        AUTH,
    ),
)

# Dev-stack ports owned by neither a door nor the console, still gated by
# `just dev`/`dev-stop`: 5180 — the design-lens tool (`just design-lens`).
# (8199, the demo serving ladder, left this set when SUPERVISION_WS became a registered
# door: hand-started doors keep their row and stay out of the port gate, like POLICY_WS.)
DEV_ONLY_PORTS: frozenset[int] = frozenset({5180})


def dev_ports() -> tuple[int, ...]:
    """Every port the local profile or a developer-only tool may hold."""
    ports = {CONTROL_PLANE_DEV_PORT, 8101}  # HTTP application and Fleet station RPC.
    ports |= {CONSOLE.dev_port}
    ports |= DEV_ONLY_PORTS
    return tuple(sorted(ports))


# --- rate classes ------------------------------------------------------------
# Canonical request-rate classes for externally reachable doors. Cheap reads,
# polling, and machine heartbeats are deliberately generous; lower classes protect
# operations whose acceptance reserves compute, human work, or physical robot time.
# Services import these values directly; the human policy is rendered with
# ``python -m sx_service rate-limits``.
#
# These are request ceilings, not commercial usage entitlements. Durable quotas
# (episodes, active jobs, compute time, physical pod time) stay with the service
# that owns the resource and are checked after idempotency replay detection.


class RateClass(StrEnum):
    LOGIN_FAILURE = "login-failure"
    PUBLIC_READ = "public-read"
    PUBLIC_MUTATION = "public-mutation"
    OPERATION_POLL = "operation-poll"
    MACHINE_HEARTBEAT = "machine-heartbeat"
    AUTH_INTROSPECTION = "auth-introspection"
    TELEMETRY_INGEST = "telemetry-ingest"
    COMPUTE_SUBMIT = "compute-submit"
    HUMAN_WORK_SUBMIT = "human-work-submit"
    MEDIA_TILE_READ = "media-tile-read"
    MODEL_QUERY = "model-query"


class InvalidRateLimitError(ValueError):
    """A rate class was constructed with a non-positive budget or window."""


@dataclass(frozen=True, slots=True)
class RequestLimit:
    name: RateClass
    requests: int
    window_s: int
    purpose: str

    def __post_init__(self) -> None:
        if self.requests < 1:
            raise InvalidRateLimitError("requests must be positive")
        if self.window_s < 1:
            raise InvalidRateLimitError("window_s must be positive")

    @property
    def requests_per_minute(self) -> int:
        return round(self.requests * 60 / self.window_s)

    def at(self, requests_per_minute: int) -> "RequestLimit":
        """The same rate class at a per-tenant budget, still a typed limit.

        The two *durable* counters — the factory's per-key submission window and waddle's
        per-org ingest window — are overridable per tenant, and both used to carry that
        override as a bare `int` all the way to the SQL. The number is not the limit: the
        rate class it belongs to, its window, and the sentence explaining it are what a
        429 has to be able to say. This keeps them attached.
        """
        return RequestLimit(self.name, requests_per_minute, 60, self.purpose)


LOGIN_FAILURE = RequestLimit(
    RateClass.LOGIN_FAILURE,
    5,
    300,
    "Failed password attempts per client IP and normalized identity.",
)
PUBLIC_READ = RequestLimit(
    RateClass.PUBLIC_READ,
    6_000,
    60,
    "Cheap authenticated API and MCP reads.",
)
PUBLIC_MUTATION = RequestLimit(
    RateClass.PUBLIC_MUTATION,
    600,
    60,
    "Small metadata mutations that do not reserve long-lived work.",
)
OPERATION_POLL = RequestLimit(
    RateClass.OPERATION_POLL,
    12_000,
    60,
    "Status polling for honestly asynchronous operations.",
)
MACHINE_HEARTBEAT = RequestLimit(
    RateClass.MACHINE_HEARTBEAT,
    12_000,
    60,
    "Authenticated station and pod heartbeats, claims, and reports.",
)
AUTH_INTROSPECTION = RequestLimit(
    RateClass.AUTH_INTROSPECTION,
    30_000,
    60,
    "Service-to-service credential introspection; consumers cache the result.",
)
TELEMETRY_INGEST = RequestLimit(
    RateClass.TELEMETRY_INGEST,
    600,
    60,
    "Batched metrics, logs, and operational telemetry ingest.",
)
COMPUTE_SUBMIT = RequestLimit(
    RateClass.COMPUTE_SUBMIT,
    60,
    60,
    "Training, Worlds generation/evaluation, export, and render admissions.",
)
HUMAN_WORK_SUBMIT = RequestLimit(
    RateClass.HUMAN_WORK_SUBMIT,
    6,
    60,
    "Factory capture, self-improvement, and physical research admissions.",
)
MEDIA_TILE_READ = RequestLimit(
    RateClass.MEDIA_TILE_READ,
    60_000,
    60,
    "Content-addressed media tiles (thumbnails) fetched in bulk by one canvas paint.",
)
MODEL_QUERY = RequestLimit(
    RateClass.MODEL_QUERY,
    600,
    60,
    "Reads that run a model inference per request (semantic query embedding).",
)

RATE_LIMITS: tuple[RequestLimit, ...] = (
    LOGIN_FAILURE,
    PUBLIC_READ,
    PUBLIC_MUTATION,
    OPERATION_POLL,
    MACHINE_HEARTBEAT,
    AUTH_INTROSPECTION,
    TELEMETRY_INGEST,
    COMPUTE_SUBMIT,
    HUMAN_WORK_SUBMIT,
    MEDIA_TILE_READ,
    MODEL_QUERY,
)

# The classes above that meter work being reserved rather than data being read.
# A method declaring NO_SIDE_EFFECTS may not name one: a read that buys an
# admission's capacity is mispriced in both directions — it spends a budget
# sized for reservations, and it hides the reservation from the budget that
# exists to bound it. This is the one place the distinction is written down;
# `sx_service.rpc` refuses the descriptor and `tools/check_rate_bindings.py`
# refuses the mounted route, both from here.
RESERVING_RATE_CLASSES: frozenset[RateClass] = frozenset(
    {RateClass.PUBLIC_MUTATION, RateClass.COMPUTE_SUBMIT, RateClass.HUMAN_WORK_SUBMIT}
)


def render_rate_limits() -> str:
    """Render the class policy from the executable values above.

    The first half of ``docs/RATE-LIMITS.md``. Per-door bindings are not knowable
    here: native HTTP lives in each door's dependency graph and Connect lives in its
    mounted descriptor table. ``tools/check_rate_bindings.py`` appends that section.
    """

    lines = [
        "# Platform rate limits",
        "",
        "This file is generated by `tools/check_rate_bindings.py --write`. Do not edit",
        "it by hand. The classes below are `sx_service.registry`; native HTTP bindings",
        "at the end come from real dependency graphs and Connect bindings come from",
        "mounted descriptor tables. One command writes both; `python -m sx_service",
        "rate-limits` renders only this half.",
        "",
        "Limits are counted per door \N{MULTIPLICATION SIGN} class "
        "\N{MULTIPLICATION SIGN} authenticated principal and shared across",
        "every replica of that door (password failures use client IP plus normalized",
        "identity). A window is counted in slices of a sixtieth of its length: no window of",
        "the declared length admits more than its count, and a refusal may outlast the",
        "window by one slice.",
        "A rejection is HTTP `429` with a",
        "whole-second `Retry-After`. Successful idempotent replays never create or reserve",
        "work twice; services with durable usage quotas check replay before quota.",
        "",
        "| Class | Requests | Window | Equivalent RPM | Purpose |",
        "|---|---:|---:|---:|---|",
    ]
    for limit in RATE_LIMITS:
        lines.append(
            f"| `{limit.name.value}` | {limit.requests:,} | {limit.window_s}s | "
            f"{limit.requests_per_minute:,} | {limit.purpose} |"
        )
    lines += [
        "",
        "## Resource-owner rules",
        "",
        "- Cheap reads use `public-read`; operation polling uses `operation-poll`.",
        "- Metadata writes use `public-mutation`. Long-lived compute admissions also use",
        "  `compute-submit`; human or physical admissions use `human-work-submit`.",
        "- Machine heartbeats never share a human submission bucket.",
        "- `Idempotency-Key` is mandatory for non-structurally-idempotent long-lived work.",
        "  The same key and body returns the original resource; the same key with different",
        "  bytes fails `409`.",
        "- Commercial tiers change durable numerical entitlements at the resource owner",
        "  (episodes, concurrent jobs, compute seconds, or pod time), not identity roles and",
        "  not these generous transport ceilings. An entitlement lookup failure must not",
        "  widen access.",
        "",
        "## Current resource-owner controls",
        "",
        "- Experience capture: per-credential submission settings and the rolling 30-day",
        "  episode quota come from the factory's `key_limits`; absent rows use configured",
        "  defaults. The request window is shared across door replicas, the episode ledger",
        "  is durable, and",
        "  persisted idempotency is checked first.",
        "- Waddle ingest: per-organization ingest RPM and points-per-batch come from",
        "  `org_limits`; absent rows use server defaults. Its request window is shared across",
        "  replicas;",
        "  the durable batch ledger checks replay before that window.",
        "- Train, Worlds, Improve, Catalog exports, and Fleet research already require an",
        "  execution budget. Durable per-project concurrent-work and rolling usage",
        "  entitlements are planned; until each owner stores and atomically reserves them,",
        "  no paid-tier claim is made for that operation.",
        "",
    ]
    return "\n".join(lines)
