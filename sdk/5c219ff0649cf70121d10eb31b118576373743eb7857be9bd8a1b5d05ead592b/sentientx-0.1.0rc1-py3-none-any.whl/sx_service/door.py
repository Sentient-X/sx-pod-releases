"""The request and response shapes every door already agreed on, declared once —
and the one place a route's rate class is chosen.

:mod:`sx_service.app` made the door's *mechanics* unskippable. This module does the
same for the two payloads that are not any one door's domain:

* :class:`ErrorOut` — the platform error envelope. Five doors carried a private copy
  of it; four were field-identical and the fifth (waddle) had silently drifted to two
  of the five fields, so a client that read ``retryable`` got a different answer from
  the same platform depending on which door refused it.
* :class:`CancelOperationIn` — the body of "stop this long-lived operation". Five
  doors carried it under two spellings (``CancelIn``, ``CancelOperationIn``) and two
  different length bounds.

Both are *wire* shapes, so they live here rather than in ``sx-contracts``: they exist
because HTTP needs a body and a failure envelope, not because the domain has a
concept of them. The domain vocabulary — what an operation *is*, what a failure
*means* — stays in ``sx_contracts.operations``, which every door already speaks.

Deliberately absent: a shared idempotency-conflict exception. Three doors raise one,
and each is correctly a member of its own typed failure hierarchy
(``TrainingJobError``, ``ResearchError``, ``WorldsStoreError``) because that is what
its door's error mapping matches on. One shared type would have to subclass three
unrelated bases to keep those handlers working, which is a worse abstraction than
three honest siblings. What they share — the 409, the code, the field name — is
enforced by ``tools/check_door_envelopes.py`` instead.

Also here: the **rate binding**. A route used to install a limiter in one place and,
if anyone bothered, name a class in another; the Slice 4 work verbs were duly metered
at ``compute-submit`` while the policy said a machine's claim/report path is
``machine-heartbeat``, and nothing could notice. So the class is no longer a thing a
route *says*: :func:`declare_rate` records it on the dependency that installs the
meter, :func:`declared_rate` reads it back, and ``create_app`` publishes
:data:`RATE_EXTENSION` from what the route actually holds. Nothing writes that
extension by hand, so a native HTTP door cannot refuse at one class and document
another. The repository renderer reads the dependency graph itself; mounted Connect
methods instead carry their exact descriptor-owned rate in ``sx_service.rpc`` and
never pass through OpenAPI.

Requires the ``door`` extra.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from sx_service.registry import RequestLimit

#: The remaining native OpenAPI projection of the rate class ``create_app`` derives
#: from the metered dependency a route holds. Connect methods never publish it.
RATE_EXTENSION = "x-sx-rate"

#: Where :func:`declare_rate` parks the limit. Private: a door binds and reads
#: through the two functions below, never through the attribute name.
_RATE_ATTRIBUTE = "__sx_rate_limit__"


class ConflictingRateBindingError(RuntimeError):
    """One route holds dependencies installing two different rate classes.

    Both meters refuse, so publishing either class would be a claim about the other
    that is false. Raised while the app is built, not while it serves.
    """


def declare_rate(dependency: object, limit: RequestLimit) -> None:
    """Record that depending on ``dependency`` installs ``limit``'s meter.

    Callers pass the dependency they built *around* a meter, so the limit written
    here is the limit that refuses — see ``sx_auth.guard.metered``, which is how
    every door binds and takes the limit off the meter itself.
    """
    setattr(dependency, _RATE_ATTRIBUTE, limit)


def declared_rate(dependency: object) -> RequestLimit | None:
    """The class ``dependency`` installs, or ``None`` when it installs no meter.

    Absence is ordinary and legitimate: most dependencies are connections, bodies
    and parsed parameters, which meter nothing. The ``isinstance`` is the fail-closed
    half — an attribute of any other type is read as no binding at all.
    """
    limit = getattr(dependency, _RATE_ATTRIBUTE, None)
    return limit if isinstance(limit, RequestLimit) else None


class Model(BaseModel):
    """The base every door payload uses: frozen, and no unknown fields.

    ``extra="forbid"`` is the fail-closed half — a request carrying a field the door
    does not know is a mistake to report, never one to drop silently. ``frozen=True``
    is the honesty half: a parsed request body is a record of what arrived, and a
    response is a record of what was decided. Neither is a scratch buffer.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")


class ErrorOut(Model):
    """The one shape a door refuses in.

    ``retryable`` is the field that makes this worth sharing: it is the difference
    between a client backing off and a client giving up, and it is not derivable from
    the status code (a 409 idempotency conflict is permanent; a 503 is not). A door
    that omits it forces every caller to special-case that door.
    """

    code: str
    message: str
    retryable: bool
    resource_ref: str | None = None
    trace_id: str


class CancelOperationIn(Model):
    """The body of a cancellation request: why, in a bounded amount of prose.

    The bound is what makes the reason storable — it lands in an operation's durable
    cancellation fact, not in a log line.
    """

    reason: str = Field(min_length=1, max_length=500)
