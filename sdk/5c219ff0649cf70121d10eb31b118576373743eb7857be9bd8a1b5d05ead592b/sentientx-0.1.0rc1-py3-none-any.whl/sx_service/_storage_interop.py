# pyright: basic
"""Typed seam around boto3's dynamically generated S3 client."""

from __future__ import annotations

from collections.abc import Iterable, Iterator, Mapping
from typing import Protocol, cast

import boto3
from botocore.config import Config as BotoConfig


class StreamingBody(Protocol):
    def read(self) -> bytes: ...

    def iter_chunks(self, *, chunk_size: int) -> Iterator[bytes]: ...


class Paginator(Protocol):
    def paginate(self, **kwargs: object) -> Iterable[Mapping[str, object]]: ...


class S3Client(Protocol):
    def head_object(self, **kwargs: object) -> Mapping[str, object]: ...

    def generate_presigned_url(self, operation: str, **kwargs: object) -> str: ...

    def get_object(self, **kwargs: object) -> Mapping[str, object]: ...

    def download_file(self, bucket: str, key: str, path: str) -> None: ...

    def get_paginator(self, operation: str) -> Paginator: ...

    def upload_file(self, path: str, bucket: str, key: str) -> None: ...

    def copy_object(self, **kwargs: object) -> Mapping[str, object]: ...

    def put_object(self, **kwargs: object) -> Mapping[str, object]: ...

    def head_bucket(self, **kwargs: object) -> Mapping[str, object]: ...

    def create_bucket(self, **kwargs: object) -> Mapping[str, object]: ...

    def create_multipart_upload(self, **kwargs: object) -> Mapping[str, object]: ...

    def complete_multipart_upload(self, **kwargs: object) -> Mapping[str, object]: ...

    def abort_multipart_upload(self, **kwargs: object) -> Mapping[str, object]: ...


def create_s3_client(*, endpoint: str, access_key: str, secret_key: str, region: str) -> S3Client:
    """Construct the only dynamic boto3 client used by the service package.

    `region` is `"auto"` for R2, which has one global region and rejects a named
    one. A store that is region-aware — MinIO, moto, S3 itself — is told which,
    because a client that says `"auto"` to such a store cannot create a bucket in
    it. See `ObjectStoreConfig.region`.
    """
    return cast(
        S3Client,
        boto3.client(
            "s3",
            endpoint_url=endpoint,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name=region,
            # SigV4 is pinned rather than inferred. boto3 picks a signature
            # version from the region when none is given, and it picks the
            # legacy one for a named region against a custom endpoint — so
            # naming a region would otherwise silently downgrade every presigned
            # URL this platform mints. The store's location and the way its
            # grants are signed are separate facts, and only one of them varies.
            config=BotoConfig(max_pool_connections=10, signature_version="s3v4"),
        ),
    )
