"""One way to be an HTTP door, so a door cannot be built wrong.

A backend used to assemble its own application: construct ``FastAPI``, remember to
call ``configure_logging``, remember to add ``ObservabilityMiddleware``, and invent
a spelling for its health endpoint. Three of those four are invisible when omitted —
a door with no middleware still answers.

A door serves its API and nothing else. The product's one console is a static bundle
on its own origin, reaching every door through a path prefix, so no backend mounts a
SPA and no backend owns a path it did not register.

:func:`create_app` takes the two things that are genuinely the door's own — its
registry row and its routes — and makes the rest unskippable:

* ``configure_logging(service=door.name, force=True)`` runs before anything else,
  so every record the process emits carries the door's name;
* ``ObservabilityMiddleware`` is always installed, so every request gets its
  request/trace/span ids and one completion event;
* ``GET /api/healthz`` is registered **first**, returning :class:`HealthOut`. It is
  the one spelling — a probe that finds it finds the same shape at every door;
* the caller's routes come next, as one ``APIRouter``;
* every native HTTP route's rate class is read off the metered dependency it holds.
  The same dependency fact feeds the rate renderer and the remaining native OpenAPI
  ``x-sx-rate`` projection (:mod:`sx_service.door`).

The auth guard is deliberately absent. ``sx-auth`` reads its rate windows from
:mod:`sx_service.registry`, so this kit may never import it; a door mounts its own
guard as route dependencies inside the router it passes here.

Requires the ``door`` extra.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Iterator, Mapping, Sequence
from contextlib import AbstractAsyncContextManager
from types import MappingProxyType
from typing import Any, cast
from uuid import uuid4

from fastapi import APIRouter, FastAPI, HTTPException, Request
from fastapi.dependencies.models import Dependant
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.routing import APIRoute
from pydantic import BaseModel
from starlette.exceptions import HTTPException as StarletteHTTPException

from sx_service.door import RATE_EXTENSION, ConflictingRateBindingError, ErrorOut, declared_rate
from sx_service.logging import ObservabilityMiddleware, configure_logging, context_fields
from sx_service.observability import init_observability
from sx_service.registry import Door, RequestLimit

#: The one health payload. `ok` is always true — a door that cannot answer at all
#: is the unhealthy signal, and a body that could say `false` invites a probe that
#: reads it instead of the status code.
HEALTH_PATH = "/api/healthz"
READY_PATH = "/api/readyz"


class HealthOut(BaseModel):
    ok: bool = True


class ReadyOut(HealthOut):
    """Ready, and which release is answering.

    ``source_revision`` identifies this image's build for operational diagnostics.
    Different revisions do not by themselves imply incompatible APIs or an outage.
    """

    release: str
    source_revision: str


#: The keys a dict detail must carry to be the envelope. Extra keys are lawful —
#: a door may ride domain facts beside the core (auth's `usage_id`) — but a dict
#: missing any core field is not the envelope and gets wrapped like a string.
_ENVELOPE_CORE = frozenset({"code", "message", "retryable", "trace_id"})


def _http_exception_detail(exc: StarletteHTTPException) -> object:
    """Expose FastAPI's runtime detail union beyond Starlette's narrower annotation."""

    return exc.detail


async def structured_http_error(_: Request, exc: Exception) -> JSONResponse:
    """Every refusal leaves a door as the top-level :class:`ErrorOut` envelope.

    Door code raises ``HTTPException(status, ErrorOut(...).model_dump())``; this
    handler lifts that dict out of FastAPI's ``{"detail": ...}`` nesting so the wire
    is the envelope itself. Anything else — plain-string details, the router's own
    404/405 (it raises Starlette's ``HTTPException``, which this handler is keyed
    on), shared-guard refusals, and dicts that only resemble the envelope — is
    wrapped into a real envelope with a synthesized ``http_{status}`` code, so a
    client reading ``retryable`` always finds a boolean. Response headers
    (``Retry-After``) survive either way. Request *validation* errors are
    deliberately untouched: pydantic's 422 ``{"detail": [...]}`` list is its own
    documented contract, and generated clients already parse it.

    The parameter is ``Exception`` because that is Starlette's registration
    contract; the framework only routes the keyed type here, so any other class
    re-raises untouched.
    """
    if not isinstance(exc, StarletteHTTPException):  # pragma: no cover - registration invariant
        raise exc
    raw_detail = _http_exception_detail(exc)
    if isinstance(raw_detail, dict) and raw_detail.keys() >= _ENVELOPE_CORE:
        return JSONResponse(status_code=exc.status_code, content=raw_detail, headers=exc.headers)
    detail = raw_detail if isinstance(raw_detail, str) else repr(cast("object", raw_detail))
    envelope = ErrorOut(
        code=f"http_{exc.status_code}",
        message=detail,
        retryable=exc.status_code == 429 or exc.status_code >= 500,
        trace_id=str(context_fields().get("trace_id") or uuid4().hex),
    )
    return JSONResponse(
        status_code=exc.status_code, content=envelope.model_dump(), headers=exc.headers
    )


def _installed_rate(dependant: Dependant) -> RequestLimit | None:
    """The one rate class this route's dependency graph installs, if any.

    The whole graph, not the route's own parameters: a door's metered dependency is
    reached either as a handler parameter (it resolves the caller, so the handler
    wants its value) or as a parameterless route dependency, and both are the same
    fact about the route.
    """
    found: set[RequestLimit] = set()
    pending = [dependant]
    while pending:
        current = pending.pop()
        limit = declared_rate(current.call)
        if limit is not None:
            found.add(limit)
        pending.extend(current.dependencies)
    if len(found) > 1:
        raise ConflictingRateBindingError(
            "one route installs "
            + ", ".join(sorted(limit.name.value for limit in found))
            + "; a route holds one rate class"
        )
    return found.pop() if found else None


def _api_routes(router: APIRouter) -> Iterator[APIRoute]:
    """Every ``APIRoute`` a router holds, including through a nested router.

    A router that includes another keeps it as one deferred entry rather than
    flattening its routes, so the nested router is followed by hand here.
    """
    for route in router.routes:
        if isinstance(route, APIRoute):
            yield route
            continue
        nested = getattr(route, "original_router", None)
        if isinstance(nested, APIRouter):
            yield from _api_routes(nested)


def _publish_rate_bindings(routes: APIRouter) -> None:
    """Stamp ``x-sx-rate`` on every route from the meter it actually installs.

    Before the router is included, not after: including it snapshots each route's
    ``openapi_extra`` into the resolved form the OpenAPI document is built from, so a
    class written afterwards would be enforced and never published — the exact silent
    divergence this binding exists to make impossible.
    """
    for route in _api_routes(routes):
        limit = _installed_rate(route.dependant)
        if limit is None:
            continue
        route.openapi_extra = {**(route.openapi_extra or {}), RATE_EXTENSION: limit.name.value}


def http_route_rates(app: FastAPI) -> Iterator[tuple[APIRoute, RequestLimit | None]]:
    """Yield every real native HTTP route with the rate its dependency graph installs.

    Connect services are Starlette mounts rather than :class:`APIRoute` instances;
    their canonical method table comes from :func:`sx_service.rpc.mounted_rpc_services`.
    This structural split prevents a mounted RPC from being reconstructed from, or
    double-counted beside, an OpenAPI projection.
    """

    for route in _api_routes(app.router):
        yield route, _installed_rate(route.dependant)


def create_app(
    door: Door,
    *,
    version: str,
    routes: APIRouter,
    lifespan: Callable[[FastAPI], AbstractAsyncContextManager[None]],
    allowed_origins: Sequence[str] = (),
    exception_handlers: Mapping[Any, Any] = MappingProxyType({}),
    readiness: Callable[[], Awaitable[None]] | None = None,
) -> FastAPI:
    """Build the door named by ``door``, observable and probeable by construction.

    ``allowed_origins`` installs CORS only when a door is reached cross-origin by a
    browser; an empty sequence adds no middleware at all. The console shares the
    doors' origin through its proxy, so it needs none.
    """
    observability = init_observability(door.name, version=version)
    configure_logging(
        service=observability.config.service,
        release=observability.config.release,
        environment=observability.config.environment,
        force=True,
    )
    app = FastAPI(
        title=door.name,
        version=version,
        lifespan=lifespan,
        # The envelope handler is a door mechanic, installed by default; a caller's
        # own handlers still win on any key they name. Keyed on Starlette's base so
        # the router's own 404/405 raises route here too, not only FastAPI's subclass.
        exception_handlers={
            StarletteHTTPException: structured_http_error,
            **dict(exception_handlers),
        },
    )
    if allowed_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=list(allowed_origins),
            allow_credentials=True,
            allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            allow_headers=[
                "Content-Type",
                "Authorization",
                "X-API-Key",
                "traceparent",
                "tracestate",
            ],
        )
    app.add_middleware(ObservabilityMiddleware)

    @app.get(HEALTH_PATH, response_model=HealthOut)
    async def healthz() -> HealthOut:  # pyright: ignore[reportUnusedFunction]
        return HealthOut()

    @app.get(READY_PATH, response_model=ReadyOut)
    async def readyz() -> ReadyOut:  # pyright: ignore[reportUnusedFunction]
        if readiness is not None:
            try:
                await readiness()
            except Exception as error:
                raise HTTPException(503, "service is not ready") from error
        return ReadyOut(
            release=observability.config.release,
            source_revision=observability.config.source_revision,
        )

    _publish_rate_bindings(routes)
    app.include_router(routes)
    return app
