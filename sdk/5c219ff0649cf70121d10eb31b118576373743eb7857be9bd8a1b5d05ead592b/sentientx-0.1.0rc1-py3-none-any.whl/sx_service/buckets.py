"""Where objects live: the buckets, their governed prefixes, and how one is addressed.

This module replaces ``infra/object-storage.json`` + ``tools/check_object_storage.py``:
the safety invariants the guard grepped for are now unconstructible. A ``Prefix``
whose retention forbids deletion cannot carry an expiry, and a malformed prefix
path cannot be built at all — ``__post_init__`` raises a typed :class:`PolicyError`
at import time, so ``just check`` (or any consumer import) fails closed on a bad
declaration.

Consumers (one rendered source per truth):

* ``infra/terraform/r2`` — bucket/lifecycle/lock/CORS desired state, via
  ``infra/terraform/r2/policy.py`` rendering :func:`policy_document`;
* ``tools/r2_inventory.py`` — the read-only audit sweep;
* ``infra/kubernetes/platform/registry/zot.yaml`` — the Zot/R2 isolation contract;
* ``packages/sx-service/tests/test_buckets.py`` — the load-bearing lifecycle pins;
* ``sx_service.storage`` — the client that acts, whose every delete calls
  :func:`assert_deletable` first.

Two kinds of "never deleted" live here, and keeping them apart is the point.
:data:`NON_DELETABLE` is what *this platform's code* refuses: it has no delete
path and can carry no expiry, which binds every caller that goes through
:class:`sx_service.storage.ObjectStore`. :data:`PERMANENT` is the subset the
*object store itself* must refuse, through an R2 bucket lock rendered from this
declaration — a guarantee that survives a credential with delete rights, a
direct boto3 call, and an operator at a console.

This module depends on the standard library and ``sx-contracts``, which is itself
dependency-free. It is what the platform's storage *is* — including
:class:`ObjectRef`, an object's address, :func:`assert_deletable`, the law that
follows from the declarations above, and :class:`ArchiveProof`, the condition
under which raw bytes could ever stop being frozen. The boto3 client that
performs calls lives one module over, behind the ``storage`` extra, so Terraform,
the audit sweep, and a light contract package can all read this without an AWS SDK.
"""

from dataclasses import dataclass
from enum import StrEnum

from sx_contracts.content import Sha256Digest


class Retention(StrEnum):
    """Why bytes under a prefix exist, and therefore whether they may ever expire."""

    RAW_FROZEN = "raw_frozen"
    SCRATCH = "scratch"
    SCRATCH_AUDIT = "scratch_audit"
    MANAGED = "managed"
    MANAGED_AUDIT = "managed_audit"
    ARCHIVE = "archive"
    BACKUP = "backup"
    MIGRATION_FROZEN = "migration_frozen"
    RELEASE_GRAPH = "release_graph"


#: Retention classes whose data may never be expired by lifecycle policy.
NON_DELETABLE = frozenset(
    {Retention.RAW_FROZEN, Retention.ARCHIVE, Retention.BACKUP, Retention.MIGRATION_FROZEN}
)

#: The subset the object store itself must refuse, not merely this platform's code.
#:
#: :data:`NON_DELETABLE` binds every caller that goes through
#: :class:`sx_service.storage.ObjectStore`. That is most of them and not all of
#: them: `experience/data-pipeline` talks to boto3 directly, an operator has a
#: console, and a credential scoped "Object Read & Write" in R2 may delete —
#: Cloudflare publishes no token permission that grants write without delete. So
#: the trainable-episode tier is additionally rendered as an indefinite R2 bucket
#: lock by ``infra/terraform/r2``, which the store enforces below every credential.
#:
#: Only :attr:`Retention.ARCHIVE` is here, and the three absences are decisions:
#: ``RAW_FROZEN`` is frozen *today* but is meant to become delivery-conditioned
#: (see :class:`ArchiveProof`), and an indefinite lock would make that flip
#: physically impossible; ``BACKUP`` prunes on a retention schedule in every
#: design that has one, and no backup pruner exists in this tree to reconcile with;
#: ``MIGRATION_FROZEN`` governs no prefix at all today.
PERMANENT = frozenset({Retention.ARCHIVE})


class PolicyError(ValueError):
    """The declared desired state violates a storage safety invariant."""


class DeleteForbiddenError(PolicyError):
    """A delete was attempted against bytes the registry says must persist."""


class ArchiveUnprovenError(PolicyError):
    """Nothing proves this raw recording's trainable episode is durably archived."""


@dataclass(frozen=True, slots=True)
class ObjectRef:
    """One object's complete address: which bucket, which key."""

    bucket: str
    key: str


@dataclass(frozen=True, slots=True)
class Prefix:
    """One governed key prefix: who owns it and whether its bytes may expire."""

    path: str
    owner: str
    retention: Retention
    delete_after_days: int | None = None

    def __post_init__(self) -> None:
        if not self.path or self.path.startswith("/") or not self.path.endswith("/"):
            raise PolicyError(f"{self.path!r}: prefixes must be relative and end in '/'")
        if any(part in {"", ".", ".."} for part in self.path.rstrip("/").split("/")):
            raise PolicyError(f"{self.path!r}: prefix contains an unsafe path element")
        if not self.owner:
            raise PolicyError(f"{self.path!r}: owner is required")
        if self.delete_after_days is not None and self.delete_after_days <= 0:
            raise PolicyError(f"{self.path!r}: delete_after_days must be a positive integer")
        if self.retention in NON_DELETABLE and self.delete_after_days is not None:
            raise PolicyError(f"{self.path!r}: {self.retention} data may not expire")


@dataclass(frozen=True, slots=True)
class Bucket:
    """One R2 bucket: its owning system, browser exposure, and governed prefixes."""

    name: str
    owner: str
    cors: bool
    prefixes: tuple[Prefix, ...]

    def __post_init__(self) -> None:
        paths = [prefix.path for prefix in self.prefixes]
        if len(paths) != len(set(paths)):
            raise PolicyError(f"bucket {self.name!r} repeats a prefix path")

    def retention_of(self, key: str) -> Retention:
        """Why the bytes at ``key`` exist — by its longest declared prefix.

        Fails closed on the unknown: a key under no declared prefix has no
        retention, which is what makes an undeclared key undeletable rather
        than accidentally deletable.
        """
        governing = max(
            (prefix for prefix in self.prefixes if key.startswith(prefix.path)),
            key=lambda prefix: len(prefix.path),
            default=None,
        )
        if governing is None:
            raise PolicyError(f"{key!r} lies under no declared prefix of bucket {self.name!r}")
        return governing.retention


@dataclass(frozen=True, slots=True)
class Account:
    """Account-level R2 placement facts applied to every managed bucket."""

    jurisdiction: str
    location: str
    storage_class: str


ACCOUNT = Account(jurisdiction="default", location="apac", storage_class="Standard")

BUCKETS: tuple[Bucket, ...] = (
    Bucket(
        "sxd-data",
        owner="experience.sxd",
        cors=False,
        prefixes=(
            # Frozen, and frozen on a condition rather than a date. The intended
            # end state is a delivery window here and permanence only for the
            # trainable episode — but a window is a safe thing to grant only once
            # something can answer "the episode derived from these bytes is durably
            # archived". :class:`ArchiveProof` is that question; nothing can answer
            # it yet, and its docstring names the two triggers. Until then this
            # stays RAW_FROZEN, which is also why it is absent from PERMANENT: an
            # indefinite lock would make the eventual flip impossible.
            Prefix("raw/", "experience.sxd.ingest", Retention.RAW_FROZEN),
            Prefix("processed/", "experience.sxd.pipeline", Retention.SCRATCH, 14),
            Prefix("_tmp/", "experience.sxd.pipeline", Retention.SCRATCH_AUDIT),
            Prefix("classification/", "experience.sxd.pipeline", Retention.MANAGED_AUDIT),
            Prefix("delivered/", "experience.sxd.archive", Retention.ARCHIVE),
            Prefix("labeler/", "experience.labeler", Retention.SCRATCH_AUDIT),
            Prefix("exports/", "experience.sxd.exports", Retention.SCRATCH_AUDIT),
            # The redelivery subsystem was deleted on 2026-08-13, but its bytes were not:
            # nothing here may expire an ARCHIVE prefix, and a prefix that governs no
            # objects would leave those keys undeletable-by-accident rather than governed.
            # So the prefixes and their retentions stand and only the owner moves, to the
            # surviving owner of the same class of bytes in this bucket — the pipeline for
            # a campaign's working scratch, the archive for delivered episode bundles.
            Prefix("redeliver/", "experience.sxd.pipeline", Retention.SCRATCH_AUDIT),
            Prefix("redelivered/", "experience.sxd.archive", Retention.ARCHIVE),
            Prefix("delivery/", "experience.sxd.delivery", Retention.MANAGED_AUDIT),
        ),
    ),
    Bucket(
        "sx-catalog",
        owner="experience.catalog",
        cors=True,
        prefixes=(
            # The permanent tier, declared: a governed episode's bytes (`datasets/`) and
            # the membership values that name them (`snapshots/`). A catalogued episode
            # is what every later value is derived from — a lineage edge, a corpus, a
            # trained checkpoint — and a derivation is worth exactly what its source is
            # still worth, so these bytes have no delete path at all. This is a
            # declaration rather than a migration because nothing ever deleted under
            # them: every delete the catalog performs lands under `staging/` (a
            # displaced attempt's staged member, an oversized upload) or `exports/` (the
            # scratch sweep), superseding a layer is a Postgres pointer swap that leaves
            # the old object where it is, and deleting a dataset soft-deletes its entry.
            #
            # `tables/` is deliberately not here: its parquet parts are a derived,
            # MVCC-versioned projection keyed by table version, so a superseded version
            # is reclaimable garbage rather than an episode. It stays MANAGED.
            #
            # ARCHIVE is also PERMANENT, so these two prefixes are the ones the store
            # itself is asked to refuse — an indefinite R2 bucket lock, rendered from
            # this declaration by `infra/terraform/r2`, below every credential.
            Prefix("datasets/", "experience.catalog", Retention.ARCHIVE),
            Prefix("tables/", "experience.catalog", Retention.MANAGED),
            Prefix("assets/sha256/", "experience.catalog", Retention.MANAGED),
            Prefix("checkpoints/sha256/", "experience.catalog", Retention.MANAGED),
            Prefix("base-weights/sha256/", "experience.catalog", Retention.MANAGED),
            Prefix("compute-inputs/projects/", "experience.catalog", Retention.MANAGED),
            Prefix("compute-outputs/", "experience.catalog", Retention.MANAGED),
            Prefix("snapshots/", "experience.catalog", Retention.ARCHIVE),
            Prefix("policies/sha256/", "experience.catalog", Retention.MANAGED),
            # The sealed capture's own bytes and receipt: raw-frozen for the same
            # reason and on the same condition as `sxd-data`'s `raw/`, and released
            # by the same proof if it is ever released at all.
            Prefix("captures/", "experience.catalog", Retention.RAW_FROZEN),
            Prefix("staging/", "experience.catalog", Retention.SCRATCH_AUDIT),
            Prefix("exports/", "experience.catalog", Retention.SCRATCH_AUDIT),
            # The semantic index: derived Lance tables + thumbnails, rebuildable by
            # re-reading governed RRDs (a re-embed away). MANAGED like `tables/` —
            # Lance compaction deletes superseded fragments, so the prefix must be
            # deletable, and losing it loses only embedding spend.
            Prefix("index/", "experience.catalog", Retention.MANAGED),
        ),
    ),
    Bucket(
        "sx-waddle",
        owner="autonomy.waddle",
        cors=True,
        prefixes=(Prefix("orgs/", "autonomy.waddle", Retention.MANAGED),),
    ),
    Bucket(
        "sx-postgres-backups",
        owner="infra.postgres",
        cors=False,
        prefixes=(Prefix("backups/postgres/", "infra.postgres", Retention.BACKUP),),
    ),
    Bucket(
        "sx-clickhouse-backups",
        owner="infra.clickhouse",
        cors=False,
        prefixes=(Prefix("clickhouse/", "infra.clickhouse", Retention.BACKUP),),
    ),
    Bucket(
        "sx-fleet-registry",
        owner="fleet.registry",
        cors=False,
        prefixes=(Prefix("registry/", "fleet.registry", Retention.RELEASE_GRAPH),),
    ),
    Bucket(
        "sx-tempo",
        owner="infra.observability",
        cors=False,
        prefixes=(Prefix("tempo/", "infra.observability", Retention.MANAGED, 30),),
    ),
    Bucket(
        "sx-loki",
        owner="infra.observability",
        cors=False,
        prefixes=(
            Prefix("fake/", "infra.observability", Retention.MANAGED, 30),
            Prefix("index/", "infra.observability", Retention.MANAGED, 30),
            Prefix("ruler/", "infra.observability", Retention.MANAGED, 30),
        ),
    ),
    Bucket(
        "sx-langfuse",
        owner="infra.observability",
        cors=False,
        prefixes=(
            Prefix("events/", "infra.observability", Retention.MANAGED),
            Prefix("media/", "infra.observability", Retention.MANAGED),
        ),
    ),
)

#: Contact sheets: ``labeler/contact_sheets/<episode_id>/<source>/`` inside the
#: labeler's governed ``labeler/`` prefix above.
#:
#: Declared here because two systems that may not import each other share it.
#: The pipeline's ``contact_sheet`` step is the bulk producer and the Label door's
#: review UI is the reader — it lists this prefix before it will re-run ffmpeg —
#: so a drift between their two spellings is a review UI that silently re-extracts
#: every frame the pipeline already wrote. One string, both sides.
CONTACT_SHEET_PREFIX = "labeler/contact_sheets"


def bucket(name: str) -> Bucket:
    """The declared bucket, or a typed refusal — consumers never scan the tuple."""
    for declared in BUCKETS:
        if declared.name == name:
            return declared
    raise PolicyError(f"no declared bucket {name!r}")


def assert_deletable(ref: ObjectRef) -> None:
    """Refuse, with a type, any delete the declarations above do not permit.

    Fails closed twice over: a retention class in :data:`NON_DELETABLE` refuses,
    and so does a key under no declared prefix — or in no declared bucket.
    Nothing is deletable by default; a prefix is declared deletable to become so.
    This is sxd's never-delete-raw invariant, made a property of the platform
    rather than of whoever remembered to call a guard.
    """
    if bucket(ref.bucket).retention_of(ref.key) in NON_DELETABLE:
        raise DeleteForbiddenError(
            f"refusing to delete {ref.key!r} from {ref.bucket!r}: "
            "its declared retention forbids expiry"
        )


@dataclass(frozen=True, slots=True)
class ArchiveProof:
    """Why one raw recording's bytes could stop being frozen — a condition, never a date.

    The retention this platform is heading for keeps a capture's raw bytes and its
    processed working copies for a delivery window, and keeps only the *trainable
    episode* forever. The window is the easy half. The hard half is the predicate
    that must hold before a raw object is released at all, and it is not "thirty
    days have passed" — it is "the episode derived from these bytes is durably in
    the permanent tier". This value is that predicate; :meth:`assert_proven` is the
    only way past it.

    Three facts, each witnessed by something that is not this module:

    * ``source`` lies under a :attr:`Retention.RAW_FROZEN` prefix. Releasing bytes
      that were never frozen is a category error, and it refuses.
    * ``episode`` lies under a prefix in :data:`PERMANENT` — so the archived copy
      is somewhere the object store itself refuses to delete, not merely somewhere
      this platform's code declines to.
    * ``attested_sha256`` is what the *store* says the bytes at ``episode`` hash to
      (:attr:`sx_service.storage.ObjectHead.attested_sha256`), and it equals the
      digest the catalog recorded. Not "a worker uploaded it", not "a row exists":
      the store's own answer about the bytes it holds. ``None`` is an unattested
      object, which is unverified rather than verified, and refuses.

    That ``episode`` was derived from ``source`` is the caller's assertion — this
    module holds no lineage and cannot check it.

    **Nothing constructs one today, and that is the honest state of the flip.** Two
    witnesses do not exist yet in the catalog, so the predicate is unsatisfiable
    rather than merely unsatisfied, and ``raw/`` stays ``RAW_FROZEN``:

    1. *The attestation.* ``sx_catalog``'s promotion writes a ``datasets/`` layer
       with ``ObjectStore.copy``/``put_file`` and records a digest it computed on
       its own scratch copy. Nothing HEADs the landed object; no column on
       ``segment_layers`` holds a store attestation. ``ObjectHead.verify`` exists
       and is called for exactly one thing, a staged pipeline member under
       ``staging/``. **Trigger:** a readback that verifies the promoted layer
       against the store and persists the store's answer.
    2. *The derivation.* ``RegisterSegmentRequest.capture`` is optional, so a segment may
       be registered with no capture lineage edge at all, and a missing edge is
       indistinguishable from "not yet catalogued". There is also no query that
       answers "every episode of capture X is catalogued and ready".
       **Trigger:** capture evidence becomes required, and the catalog can answer
       that question for one capture.
    """

    source: ObjectRef
    episode: ObjectRef
    recorded_sha256: Sha256Digest
    attested_sha256: Sha256Digest | None

    def assert_proven(self) -> None:
        """Refuse, with a type, unless all three facts hold at once."""
        if bucket(self.source.bucket).retention_of(self.source.key) is not Retention.RAW_FROZEN:
            raise ArchiveUnprovenError(
                f"{self.source.key!r} is not raw-frozen: there is nothing here to release"
            )
        if bucket(self.episode.bucket).retention_of(self.episode.key) not in PERMANENT:
            raise ArchiveUnprovenError(
                f"refusing to release {self.source.key!r}: its episode {self.episode.key!r} "
                "does not lie in the permanent tier"
            )
        if self.attested_sha256 is None:
            raise ArchiveUnprovenError(
                f"refusing to release {self.source.key!r}: the object store attests no "
                f"whole-object sha256 for {self.episode.key!r}, so the archived copy is "
                "unverified, not verified"
            )
        if self.attested_sha256 != self.recorded_sha256:
            raise ArchiveUnprovenError(
                f"refusing to release {self.source.key!r}: the object store attests sha256 "
                f"{self.attested_sha256} for {self.episode.key!r}, but the catalog recorded "
                f"{self.recorded_sha256}"
            )


def policy_document() -> dict[str, object]:
    """The registry in the retired ``object-storage.json`` shape.

    Terraform's ``infra/terraform/r2`` root consumes this through its
    ``policy.py`` external-data bridge; the wire shape is pinned by its plan.

    Each prefix renders two derived booleans beside its retention, so the HCL
    filters on a fact rather than re-listing which retention classes mean what —
    ``deletable`` gates lifecycle expiry and ``permanent`` drives the bucket lock.
    Schema 2 added them.
    """
    return {
        "schema_version": 2,
        "account": {
            "jurisdiction": ACCOUNT.jurisdiction,
            "location": ACCOUNT.location,
            "storage_class": ACCOUNT.storage_class,
        },
        "buckets": {
            declared.name: {
                "owner": declared.owner,
                "cors": declared.cors,
                "prefixes": {
                    prefix.path: {
                        "owner": prefix.owner,
                        "retention": prefix.retention.value,
                        "delete_after_days": prefix.delete_after_days,
                        "deletable": prefix.retention not in NON_DELETABLE,
                        "permanent": prefix.retention in PERMANENT,
                    }
                    for prefix in declared.prefixes
                },
            }
            for declared in BUCKETS
        },
    }
