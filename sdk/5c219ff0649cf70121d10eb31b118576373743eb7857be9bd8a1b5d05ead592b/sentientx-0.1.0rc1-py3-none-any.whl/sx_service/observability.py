"""The process-wide OpenTelemetry runtime and the few boundaries it cannot infer.

Applications do not create providers, exporters, spans, or trace identifiers.  A door
reaches :func:`init_observability` through ``create_app``; a worker reaches it through
``run_worker``.  The only explicit operations left in this module are the external-effect
boundaries OpenTelemetry cannot discover by instrumenting a transport:

* :func:`model_call`, used only by modules that actually invoke a model provider; and
* :class:`TraceCarrier`, used by Ray, queues, and subprocess envelopes.

Export is always asynchronous and points at the host Collector on loopback by default.
Collector failure therefore cannot become application failure.  Source attributes are
filtered before they enter the exporter queue; the Collector applies the same policy again.
"""

from __future__ import annotations

import atexit
import hashlib
import json
import os
import platform
import socket
import threading
import time
from collections.abc import Generator, Mapping, Sequence
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from importlib import import_module
from types import MappingProxyType, TracebackType
from typing import Any, Final, Literal, TypeAlias, cast
from urllib.parse import urlsplit, urlunsplit

from opentelemetry import context, metrics, propagate, trace
from opentelemetry.context import Context
from opentelemetry.exporter.otlp.proto.http import Compression
from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.metrics import MeterProvider as ApiMeterProvider
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import Event, ReadableSpan, TracerProvider
from opentelemetry.sdk.trace.export import (
    BatchSpanProcessor,
    SpanExporter,
    SpanExportResult,
)
from opentelemetry.trace import Link, SpanKind, Status, StatusCode
from opentelemetry.trace import TracerProvider as ApiTracerProvider

from sx_service.logging import REDACTED, bind_context, get_logger, is_secret_key, redact_text

_log = get_logger(__name__)

_SCOPE: Final = "sx-service"
_CORRELATION_FIELDS: Final = frozenset(
    {
        "campaign_id",
        "episode_id",
        "operation_id",
        "project_id",
        "run_id",
        "session_id",
        "workflow_id",
    }
)
_PRIVATE_ATTRIBUTE_PARTS: Final = (
    "body",
    "content",
    "cookie",
    "db.statement",
    "object_key",
    "prompt",
    "response",
    "s3.key",
    "tool.arguments",
    "tool.result",
)
_MAX_ATTRIBUTE_TEXT: Final = 4096
_SpanAttribute: TypeAlias = (
    str | bool | int | float | Sequence[str] | Sequence[bool] | Sequence[int] | Sequence[float]
)


#: What a process built outside a release says its source revision is.
UNRELEASED = "unreleased"
#: What a bake with no `SOURCE_REVISION` argument stamps (`infra/oci/cloud/render_bake.py`
#: defaults it to forty zeros): a build nobody can trace, refused the same way.
UNTRACEABLE = "0" * 40


class ObservabilityConfigurationError(RuntimeError):
    """A process attempted to install two incompatible telemetry runtimes."""


class InvalidTraceCarrierError(ValueError):
    """A locally constructed carrier contains a field that is unsafe to transport."""


@dataclass(frozen=True, slots=True)
class ObservabilityConfig:
    """The one process identity, and the collector route if this deployment has one.

    ``endpoint`` is the single legitimate absence here, and it is a deployment fact:
    a workload that ships telemetry is given ``SX_OTEL_ENDPOINT`` by its generated
    Kubernetes release values, and a laptop, a test, and a CI job are not. There used to
    be a default of ``http://127.0.0.1:4318``, so every process that had never heard of a
    collector built real OTLP exporters and retried against a port nothing was listening
    on — 8 teardown errors in one suite, and log noise in every other. Absence is
    resolved once, in :func:`_providers`: no endpoint, no exporter.
    """

    service: str
    version: str
    environment: str
    release: str
    #: The git revision the running image was built from (``SX_SOURCE_REVISION``, baked
    #: into every first-party image by the cloud Dockerfile). A door answers it on
    #: ``/api/readyz`` so the console can name a door running another release than its
    #: own. ``UNRELEASED`` is the development sentinel; production refuses it.
    source_revision: str
    endpoint: str | None
    instance_id: str
    region: str
    workload: str
    node_pool: str
    capture_genai_content: bool

    def __post_init__(self) -> None:
        for name in ("service", "version", "environment", "release", "instance_id"):
            if not str(getattr(self, name)).strip():
                raise ObservabilityConfigurationError(f"{name} must not be empty")
        if self.endpoint is not None:
            endpoint = urlsplit(self.endpoint)
            if endpoint.scheme not in {"http", "https"} or not endpoint.netloc:
                raise ObservabilityConfigurationError("SX_OTEL_ENDPOINT must be an HTTP(S) origin")
            if endpoint.query or endpoint.fragment:
                raise ObservabilityConfigurationError(
                    "SX_OTEL_ENDPOINT cannot contain query or fragment"
                )
        if self.environment == "production" and self.capture_genai_content:
            raise ObservabilityConfigurationError(
                "SX_OTEL_CAPTURE_GENAI_CONTENT is forbidden in production"
            )
        if self.environment == "production" and self.source_revision in {
            UNRELEASED,
            UNTRACEABLE,
        }:
            raise ObservabilityConfigurationError(
                "SX_SOURCE_REVISION is required in production; every first-party image bakes it"
            )


@dataclass(slots=True)
class Observability:
    """Installed providers plus bounded process-shutdown ownership."""

    config: ObservabilityConfig
    tracer_provider: ApiTracerProvider
    meter_provider: ApiMeterProvider
    owns_providers: bool = True

    def tracer(self, scope: str = _SCOPE) -> trace.Tracer:
        return self.tracer_provider.get_tracer(scope, self.config.version)

    def meter(self, scope: str = _SCOPE) -> metrics.Meter:
        return self.meter_provider.get_meter(scope, self.config.version)

    def shutdown(self, timeout_s: float = 5.0) -> bool:
        """Flush on a helper thread so process exit has a real upper bound."""
        if not self.owns_providers:
            return True

        completed = threading.Event()

        def close() -> None:
            try:
                if isinstance(self.tracer_provider, TracerProvider):
                    self.tracer_provider.force_flush(timeout_millis=int(timeout_s * 500))
                    self.tracer_provider.shutdown()
                if isinstance(self.meter_provider, MeterProvider):
                    self.meter_provider.shutdown(timeout_millis=timeout_s * 500)
            finally:
                completed.set()

        thread = threading.Thread(target=close, name="sx-otel-shutdown", daemon=True)
        thread.start()
        completed.wait(timeout_s)
        return completed.is_set()


class _State:
    def __init__(self) -> None:
        self.lock = threading.RLock()
        self.runtime: Observability | None = None
        self.atexit_registered = False


_state = _State()
_application_process: ContextVar[Observability | None] = ContextVar(
    "sx_application_process", default=None
)


@contextmanager
def application_process(service: str, *, version: str) -> Generator[Observability]:
    """Build several HTTP modules under one explicit process telemetry identity.

    Only the composition root enters this scope. Independent worker bootstraps still
    reject conflicting identities; modules built here share the process providers.
    """
    runtime = init_observability(service, version=version)
    token = _application_process.set(runtime)
    try:
        yield runtime
    finally:
        _application_process.reset(token)


def init_observability(
    service: str,
    *,
    version: str = "unknown",
    environment: str | None = None,
    tracer_provider: ApiTracerProvider | None = None,
    meter_provider: ApiMeterProvider | None = None,
) -> Observability:
    """Install the process provider once; identical calls are free.

    Tests pass in-memory providers. Production callers never construct providers and get
    the bounded OTLP/HTTP exporters targeting the collector their release named in
    ``SX_OTEL_ENDPOINT``. A process whose release named none records without exporting;
    see :class:`ObservabilityConfig`.
    """
    composed = _application_process.get()
    if composed is not None:
        if tracer_provider is not None or meter_provider is not None:
            raise ObservabilityConfigurationError("a module cannot replace its process providers")
        return composed
    config = _config(service, version=version, environment=environment)
    with _state.lock:
        installed = _state.runtime
        if installed is not None:
            if installed.config == config:
                return installed
            if not installed.owns_providers and tracer_provider is None and meter_provider is None:
                # A test provider is process plumbing, not process identity.  It may back
                # several app factories imported by one test process while production still
                # rejects a conflicting second bootstrap below.
                return Observability(
                    config=config,
                    tracer_provider=installed.tracer_provider,
                    meter_provider=installed.meter_provider,
                    owns_providers=False,
                )
            raise ObservabilityConfigurationError(
                "conflicting OpenTelemetry initialization: "
                f"{installed.config.service}/{installed.config.version}/"
                f"{installed.config.environment} is already installed; requested "
                f"{config.service}/{config.version}/{config.environment}"
            )

        owns = tracer_provider is None and meter_provider is None
        if (tracer_provider is None) != (meter_provider is None):
            raise ObservabilityConfigurationError(
                "tests must inject tracer_provider and meter_provider together"
            )
        if owns:
            tracer_provider, meter_provider = _providers(config)
            _install_globals(tracer_provider, meter_provider)
        else:
            assert tracer_provider is not None and meter_provider is not None

        runtime = Observability(
            config=config,
            tracer_provider=tracer_provider,
            meter_provider=meter_provider,
            owns_providers=owns,
        )
        _state.runtime = runtime
        _instrument_clients(runtime)
        if not _state.atexit_registered:
            atexit.register(_shutdown_at_exit)
            _state.atexit_registered = True
        return runtime


@contextmanager
def test_observability(
    *,
    tracer_provider: ApiTracerProvider,
    meter_provider: ApiMeterProvider,
    service: str = "test-service",
    version: str = "test",
    environment: str = "test",
) -> Generator[Observability]:
    """Install in-memory providers for a test without resetting OTel global state."""
    config = _config(service, version=version, environment=environment)
    runtime = Observability(config, tracer_provider, meter_provider, owns_providers=False)
    with _state.lock:
        previous = _state.runtime
        _state.runtime = runtime
    try:
        yield runtime
    finally:
        with _state.lock:
            _state.runtime = previous


def current_observability() -> Observability:
    """Return the installed runtime, lazily bootstrapping process-only boundaries."""
    installed = _state.runtime
    if installed is not None:
        return installed
    return init_observability(os.environ.get("SX_SERVICE", "unknown"))


@dataclass(frozen=True, slots=True)
class TraceCarrier:
    """W3C propagation plus a bounded, non-authoritative correlation projection."""

    traceparent: str
    tracestate: str = ""
    correlation: tuple[tuple[str, str], ...] = ()

    def __post_init__(self) -> None:
        if len(self.traceparent) > 128 or len(self.tracestate) > 512:
            raise InvalidTraceCarrierError("trace context exceeds its bounded wire size")
        if len(self.correlation) > len(_CORRELATION_FIELDS):
            raise InvalidTraceCarrierError("too many correlation fields")
        seen: set[str] = set()
        for key, value in self.correlation:
            if key not in _CORRELATION_FIELDS or key in seen:
                raise InvalidTraceCarrierError(f"unsupported or repeated correlation field {key!r}")
            if not value or len(value) > 256 or any(ord(char) < 32 for char in value):
                raise InvalidTraceCarrierError(f"invalid correlation value for {key!r}")
            seen.add(key)


def inject_carrier(**correlation: str) -> TraceCarrier:
    """Project the active OTel context into the immutable transport value."""
    unknown = set(correlation) - _CORRELATION_FIELDS
    if unknown:
        raise InvalidTraceCarrierError(f"unsupported correlation fields: {sorted(unknown)}")
    carrier: dict[str, str] = {}
    propagate.inject(carrier)
    return TraceCarrier(
        traceparent=carrier.get("traceparent", ""),
        tracestate=carrier.get("tracestate", ""),
        correlation=tuple(sorted(correlation.items())),
    )


@contextmanager
def attach_carrier(carrier: TraceCarrier | None) -> Generator[None]:
    """Attach a remote parent for one task, restoring the prior context in ``finally``.

    Missing or malformed remote context is correlation failure, never work rejection.  The
    task becomes a new root and a diagnostic counter/log records why the edge broke.
    """
    runtime = current_observability()
    values: dict[str, str] = {}
    correlation: dict[str, str] = {}
    if carrier is not None:
        if carrier.traceparent:
            values["traceparent"] = carrier.traceparent
        if carrier.tracestate:
            values["tracestate"] = carrier.tracestate
        correlation = dict(carrier.correlation)
    extracted = propagate.extract(values) if values else Context()
    remote = trace.get_current_span(extracted).get_span_context()
    valid = bool(values) and remote.is_valid and remote.is_remote
    if not valid:
        extracted = Context()
        runtime.meter().create_counter(
            "observability.trace_carrier_invalid",
            description="Missing or malformed cross-process trace carriers",
        ).add(1, {"reason": "missing" if not values else "malformed"})
        _log.warning(
            "observability.trace_carrier_invalid",
            reason="missing" if not values else "malformed",
        )
    token = context.attach(extracted)
    try:
        with bind_context(**correlation):
            yield
    finally:
        context.detach(token)


class ModelCall:
    """Completion contract for one actual provider invocation."""

    def __init__(
        self,
        *,
        operation: str,
        provider: str,
        model: str,
        request: object,
        attributes: Mapping[str, object],
    ) -> None:
        self._runtime = current_observability()
        self._operation = operation
        self._provider = provider
        self._model = model
        self._request = request
        self._attributes = dict(attributes)
        self._manager: Any = None
        self._span: trace.Span | None = None
        self._completed = False
        self._started = 0.0

    def __enter__(self) -> ModelCall:
        request_bytes, request_fingerprint = _content_facts(self._request)
        attributes: dict[str, _SpanAttribute] = {
            "gen_ai.operation.name": self._operation,
            "gen_ai.provider.name": self._provider,
            "gen_ai.request.model": self._model,
            "gen_ai.request.byte_count": request_bytes,
            "gen_ai.request.content.sha256": request_fingerprint,
            "sx.telemetry.retain": "always",
            **_safe_attributes(self._attributes),
        }
        self._started = time.perf_counter()
        self._manager = self._runtime.tracer().start_as_current_span(
            f"gen_ai.{self._operation}", kind=SpanKind.CLIENT, attributes=attributes
        )
        self._span = self._manager.__enter__()
        self._runtime.meter().create_counter("gen_ai.client.operation.calls").add(
            1, {"gen_ai.operation.name": self._operation, "gen_ai.provider.name": self._provider}
        )
        return self

    def succeeded(
        self,
        response: object,
        *,
        model: str | None = None,
        input_tokens: int = 0,
        output_tokens: int = 0,
        cached_tokens: int = 0,
        total_tokens: int = 0,
        finish_reason: str = "",
        message_count: int = 0,
        tool_count: int = 0,
    ) -> None:
        """Complete the provider span from provider-specific parsed facts."""
        span = self._require_open_span()
        response_bytes, response_fingerprint = _content_facts(response)
        for key, value in (
            ("gen_ai.response.model", model or self._model),
            ("gen_ai.response.finish_reason", finish_reason),
            ("gen_ai.response.byte_count", response_bytes),
            ("gen_ai.response.content.sha256", response_fingerprint),
            ("gen_ai.usage.input_tokens", max(input_tokens, 0)),
            ("gen_ai.usage.output_tokens", max(output_tokens, 0)),
            ("gen_ai.usage.cached_input_tokens", max(cached_tokens, 0)),
            (
                "gen_ai.usage.total_tokens",
                max(total_tokens, input_tokens + output_tokens, 0),
            ),
            ("gen_ai.request.message_count", max(message_count, 0)),
            ("gen_ai.request.tool_count", max(tool_count, 0)),
        ):
            if value != "":
                span.set_attribute(key, value)
        if self._runtime.config.capture_genai_content:
            span.set_attribute("gen_ai.request.content", _capture_content(self._request))
            span.set_attribute("gen_ai.response.content", _capture_content(response))
            span.set_attribute("sx.telemetry.genai_content_capture", True)
        span.set_status(Status(StatusCode.OK))
        self._record_completion_metrics(
            status="ok",
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cached_tokens=cached_tokens,
        )
        self._completed = True

    def failed(self, error: object, *, response: object = "") -> None:
        """Complete a provider response that arrived but was unusable to the caller."""
        span = self._require_open_span()
        response_bytes, response_fingerprint = _content_facts(response)
        span.set_attribute("gen_ai.response.byte_count", response_bytes)
        span.set_attribute("gen_ai.response.content.sha256", response_fingerprint)
        span.set_status(Status(StatusCode.ERROR, redact_text(str(error))[:_MAX_ATTRIBUTE_TEXT]))
        self._record_completion_metrics(status="error")
        self._completed = True

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> Literal[False]:
        span = self._span
        try:
            if span is not None and exc is not None:
                span.record_exception(exc, escaped=True)
                span.set_status(Status(StatusCode.ERROR, type(exc).__name__))
                if not self._completed:
                    self._record_completion_metrics(status="error")
                self._completed = True
            elif span is not None and not self._completed:
                span.set_attribute("observability.model_call_incomplete", True)
                span.set_status(Status(StatusCode.ERROR, "model result was not recorded"))
                self._runtime.meter().create_counter(
                    "observability.model_call_incomplete",
                    description="Provider calls that returned without recording their result",
                ).add(1, {"gen_ai.operation.name": self._operation})
                _log.error(
                    "observability.model_call_incomplete",
                    operation=self._operation,
                    provider=self._provider,
                    model=self._model,
                )
                self._record_completion_metrics(status="incomplete")
        finally:
            if self._manager is not None:
                self._manager.__exit__(exc_type, exc, tb)
            self._manager = None
            self._span = None
        return False

    def _require_open_span(self) -> trace.Span:
        if self._span is None:
            raise RuntimeError("model-call record is not active")
        if self._completed:
            raise RuntimeError("model-call result was already recorded")
        return self._span

    def _record_completion_metrics(
        self,
        *,
        status: str,
        input_tokens: int = 0,
        output_tokens: int = 0,
        cached_tokens: int = 0,
    ) -> None:
        dimensions = {
            "gen_ai.operation.name": self._operation,
            "gen_ai.provider.name": self._provider,
            "gen_ai.request.model": self._model,
            "error.type": status,
        }
        self._runtime.meter().create_histogram(
            "gen_ai.client.operation.duration",
            unit="s",
            description="Model provider call duration",
        ).record(max(time.perf_counter() - self._started, 0.0), dimensions)
        token_counter = self._runtime.meter().create_counter(
            "gen_ai.client.token.usage",
            unit="{token}",
            description="Model provider token usage",
        )
        for token_type, count in (
            ("input", input_tokens),
            ("output", output_tokens),
            ("cache_read", cached_tokens),
        ):
            if count > 0:
                token_counter.add(count, {**dimensions, "gen_ai.token.type": token_type})


def model_call(
    *,
    operation: str,
    provider: str,
    model: str,
    request: object,
    attributes: Mapping[str, object] = MappingProxyType({}),
) -> ModelCall:
    """Open the real provider span.  Only registered provider modules may import this."""
    if not operation.strip() or not provider.strip() or not model.strip():
        raise ValueError("operation, provider, and model must not be empty")
    return ModelCall(
        operation=operation.strip(),
        provider=provider.strip(),
        model=model.strip(),
        request=request,
        attributes=attributes,
    )


class _RedactingSpanExporter(SpanExporter):
    def __init__(self, delegate: SpanExporter, *, capture_genai_content: bool) -> None:
        self._delegate = delegate
        self._capture_genai_content = capture_genai_content

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        return self._delegate.export(
            tuple(
                _redacted_span(span, capture_genai_content=self._capture_genai_content)
                for span in spans
            )
        )

    def shutdown(self) -> None:
        self._delegate.shutdown()

    def force_flush(self, timeout_millis: int = 30_000) -> bool:
        force_flush = getattr(self._delegate, "force_flush", None)
        return True if force_flush is None else bool(force_flush(timeout_millis))


def _redacted_span(span: ReadableSpan, *, capture_genai_content: bool) -> ReadableSpan:
    return ReadableSpan(
        name=span.name,
        context=span.context,
        parent=span.parent,
        resource=span.resource,
        attributes=_safe_attributes(
            span.attributes or {}, capture_genai_content=capture_genai_content
        ),
        events=tuple(
            Event(
                event.name,
                attributes=_safe_attributes(
                    event.attributes or {}, capture_genai_content=capture_genai_content
                ),
                timestamp=event.timestamp,
            )
            for event in span.events
        ),
        links=tuple(
            Link(
                link.context,
                attributes=_safe_attributes(
                    link.attributes or {}, capture_genai_content=capture_genai_content
                ),
            )
            for link in span.links
        ),
        kind=span.kind,
        status=span.status,
        start_time=span.start_time,
        end_time=span.end_time,
        instrumentation_scope=span.instrumentation_scope,
    )


def _safe_attributes(
    attributes: Mapping[str, Any],
    *,
    capture_genai_content: bool = False,
) -> dict[str, _SpanAttribute]:
    safe: dict[str, _SpanAttribute] = {}
    for key, value in attributes.items():
        normalized = key.lower().replace("-", "_")
        fingerprint = normalized.endswith(".content.sha256")
        approved_content = capture_genai_content and normalized in {
            "gen_ai.request.content",
            "gen_ai.response.content",
        }
        if is_secret_key(key) or (
            not fingerprint
            and not approved_content
            and any(part in normalized for part in _PRIVATE_ATTRIBUTE_PARTS)
        ):
            continue
        if normalized in {"url.full", "http.url", "server.address"} and isinstance(value, str):
            value = _without_query(value)
        if isinstance(value, str):
            value = redact_text(value)[:_MAX_ATTRIBUTE_TEXT]
        elif isinstance(value, Sequence) and not isinstance(value, bytes | bytearray):
            value = cast(Sequence[Any], value)[:64]
        safe[key] = cast(Any, value)
    return safe


def _without_query(value: str) -> str:
    try:
        parsed = urlsplit(value)
    except ValueError:
        return REDACTED
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, "", ""))


def _content_facts(value: object) -> tuple[int, str]:
    try:
        body = json.dumps(
            value,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
            default=str,
        ).encode("utf-8")
    except (TypeError, ValueError, OverflowError):
        body = repr(type(value)).encode("utf-8")
    return len(body), hashlib.sha256(body).hexdigest()


def _capture_content(value: object) -> str:
    captured = redact_text(json.dumps(value, ensure_ascii=False, default=str))
    return captured[:_MAX_ATTRIBUTE_TEXT]


def _config(service: str, *, version: str, environment: str | None) -> ObservabilityConfig:
    endpoint = os.environ.get("SX_OTEL_ENDPOINT", "").strip() or None
    release = os.environ.get("SX_RELEASE", "unknown").strip() or "unknown"
    source_revision = os.environ.get("SX_SOURCE_REVISION", "").strip() or UNRELEASED
    resolved_environment = (environment or os.environ.get("SX_ENVIRONMENT", "development")).strip()
    capture = os.environ.get("SX_OTEL_CAPTURE_GENAI_CONTENT", "").strip().lower() == "true"
    allowlist = {
        item.strip()
        for item in os.environ.get("SX_OTEL_GENAI_CONTENT_ALLOWLIST", "").split(",")
        if item.strip()
    }
    named_service = service.strip() or os.environ.get("SX_SERVICE", "unknown").strip() or "unknown"
    if capture and named_service not in allowlist:
        raise ObservabilityConfigurationError(
            "GenAI content capture requires the service in SX_OTEL_GENAI_CONTENT_ALLOWLIST"
        )
    return ObservabilityConfig(
        service=named_service,
        version=version.strip() or release,
        environment=resolved_environment,
        release=release,
        source_revision=source_revision,
        endpoint=endpoint.rstrip("/") if endpoint else None,
        instance_id=os.environ.get("SX_SERVICE_INSTANCE_ID", "").strip()
        or f"{socket.gethostname()}:{os.getpid()}",
        region=os.environ.get("SX_CLOUD_REGION", "unknown").strip() or "unknown",
        workload=os.environ.get("SX_WORKLOAD", named_service).strip() or named_service,
        node_pool=os.environ.get("SX_NODE_POOL", "unknown").strip() or "unknown",
        capture_genai_content=capture,
    )


def _providers(config: ObservabilityConfig) -> tuple[TracerProvider, MeterProvider]:
    """Build this process's providers, exporting only if a collector was configured.

    Both cases record: spans are opened, metrics are counted, and every instrumented
    path runs identically. The only difference is whether anything is shipped. A
    process with no ``SX_OTEL_ENDPOINT`` therefore exercises the same code a deployed
    one does, and never opens a socket to a collector nobody started.
    """

    resource = _resource(config)
    tracer_provider = TracerProvider(resource=resource)
    if config.endpoint is None:
        return tracer_provider, MeterProvider(resource=resource, metric_readers=())

    tracer_provider.add_span_processor(
        BatchSpanProcessor(
            _RedactingSpanExporter(
                OTLPSpanExporter(
                    endpoint=f"{config.endpoint}/v1/traces",
                    compression=Compression.Gzip,
                    timeout=3,
                ),
                capture_genai_content=config.capture_genai_content,
            ),
            max_queue_size=2048,
            max_export_batch_size=256,
            schedule_delay_millis=2000,
            export_timeout_millis=3000,
        )
    )
    metric_reader = PeriodicExportingMetricReader(
        OTLPMetricExporter(
            endpoint=f"{config.endpoint}/v1/metrics",
            compression=Compression.Gzip,
            timeout=3,
        ),
        export_interval_millis=15_000,
        export_timeout_millis=3_000,
    )
    return tracer_provider, MeterProvider(resource=resource, metric_readers=(metric_reader,))


def _resource(config: ObservabilityConfig) -> Resource:
    return Resource.create(
        {
            "service.name": config.service,
            "service.namespace": "sx",
            "service.version": config.version,
            "service.instance.id": config.instance_id,
            "deployment.environment": config.environment,
            "host.name": socket.gethostname(),
            "cloud.region": config.region,
            "process.runtime.name": platform.python_implementation(),
            "process.runtime.version": platform.python_version(),
            "workload.name": config.workload,
            "node.pool": config.node_pool,
            "release.generation": config.release,
            "release.source_revision": config.source_revision,
        }
    )


def _install_globals(tracer_provider: ApiTracerProvider, meter_provider: ApiMeterProvider) -> None:
    current_tracer = trace.get_tracer_provider()
    if current_tracer.__class__.__name__ != "ProxyTracerProvider":
        raise ObservabilityConfigurationError("a tracer provider was installed outside sx-service")
    current_meter = metrics.get_meter_provider()
    if current_meter.__class__.__name__ != "_ProxyMeterProvider":
        raise ObservabilityConfigurationError("a meter provider was installed outside sx-service")
    trace.set_tracer_provider(tracer_provider)
    metrics.set_meter_provider(meter_provider)


def _instrument_clients(runtime: Observability) -> None:
    """Instrument installed shared clients without importing their SDKs in applications."""
    specs = (
        ("opentelemetry.instrumentation.httpx", "HTTPXClientInstrumentor"),
        ("opentelemetry.instrumentation.requests", "RequestsInstrumentor"),
        ("opentelemetry.instrumentation.aiohttp_client", "AioHttpClientInstrumentor"),
        ("opentelemetry.instrumentation.psycopg", "PsycopgInstrumentor"),
        ("opentelemetry.instrumentation.redis", "RedisInstrumentor"),
        ("opentelemetry.instrumentation.botocore", "BotocoreInstrumentor"),
        ("opentelemetry.instrumentation.system_metrics", "SystemMetricsInstrumentor"),
    )
    for module_name, class_name in specs:
        try:
            instrumentor = getattr(import_module(module_name), class_name)()
            if not instrumentor.is_instrumented_by_opentelemetry:
                instrumentor.instrument(
                    tracer_provider=runtime.tracer_provider,
                    meter_provider=runtime.meter_provider,
                )
        except (ImportError, ModuleNotFoundError):
            continue
        except Exception as exc:
            _log.warning(
                "observability.client_instrumentation_failed",
                instrumentor=class_name,
                error=f"{type(exc).__name__}: {exc}",
            )


def _shutdown_at_exit() -> None:
    runtime = _state.runtime
    if runtime is not None and not runtime.shutdown():
        _log.warning("observability.shutdown_deadline_exceeded", timeout_s=5)
