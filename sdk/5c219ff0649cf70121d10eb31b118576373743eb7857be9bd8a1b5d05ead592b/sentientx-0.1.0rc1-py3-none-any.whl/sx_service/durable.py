"""One row, one fenced transition: the durable write every state machine shares.

A durable operation's state lives in one row, and the only write that may move it
is a *transition*::

    UPDATE <table> SET state = $to, … WHERE <key> AND state = ANY($expected) RETURNING …

Zero rows is never a count the caller inspects. It is one of two typed facts, told
apart by a second read: the row is gone (:class:`MissingRowError`), or it already
moved and this is the state it is actually in (:class:`StaleTransitionError`). A
caller maps the first to "not found" and the second to "already settled", and
nothing in between is left to a reviewer's memory.

**Why one statement.** The 2026-09 census of `formal/tla/coverage.toml` found that
eleven of the fifty-two known implementation gaps were a read followed by a write the
read did not fence, five of them exactly this shape on rows that already carried a
state column, and that eleven members had each hand-written the predicate. Beside one
of those gaps the sibling upsert already said ``WHERE status NOT IN ('failed',
'cancelled')``; the parent row next to it did not. The predicate is the whole law, so
it is spelled here once and the ratchet ``hand_rolled_state_transitions`` counts every
copy that remains.

**What a caller decides.** The primitive reports; the caller maps. A row already in
``to`` is *stale* here — whether that is a conflict or a replay of the caller's own
earlier attempt is the caller's law (a Temporal activity is at-least-once, so for it
the same settlement again is a replay), and the caller's ``except`` says which.

**Deliberately absent.** There is no fence column: four of the five gaps needed only
``state = $expected``, because a single-holder transition is identified by its state.
A lease that can change hands mid-flight needs a generation as well, and that is the
``LeasedTransition`` of `docs/plans/durable-row-2026-09.md` — it lands with its two
consumers, one of which (`sx_conversations`) already writes that exact predicate.
There is no admission here either: ``INSERT … ON CONFLICT DO NOTHING RETURNING`` is
the other primitive, and it lands the same way.

Requires the ``db`` extra.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from enum import StrEnum
from typing import Any, TypeVar, cast

import psycopg
from psycopg import sql
from psycopg.rows import tuple_row

S = TypeVar("S", bound=StrEnum)

NOW = sql.SQL("now()")
"""Database time, for a timestamp column the transition stamps (``updated_at = now()``)."""


class TransitionError(Exception):
    """A fenced transition did not move its row."""


class MissingRowError(TransitionError):
    """The row the transition names does not exist."""

    def __init__(self, row: Row) -> None:
        self.row = row
        super().__init__(f"{row.table} has no row {dict(row.key)!r}")


class UnknownStateError(TransitionError):
    """The row holds a state the caller's enum does not name.

    A newer writer stored a value this process was not built with, or the column has
    no CHECK constraint and something else wrote it. Either way the transition cannot
    say what it lost to, and that is a typed fact rather than a bare ``ValueError``.
    """

    def __init__(self, row: Row, *, raw: str, states: type[StrEnum]) -> None:
        self.row = row
        self.raw = raw
        self.states = states
        super().__init__(
            f"{row.table} row {dict(row.key)!r} is {raw!r}, which {states.__name__} does not name"
        )


class StaleTransitionError(TransitionError):
    """The row exists but is not in any state the transition expected.

    ``actual`` is what it is in — read after the write missed and parsed through the
    caller's own enum, so a caller can say "already committed" rather than
    "something else happened". It is typed as the base ``StrEnum`` because an
    ``except`` clause cannot name a type parameter; compare it with ``is`` against
    the member, or re-parse it with the enum, and both are total.
    """

    def __init__(self, row: Row, *, expected: frozenset[StrEnum], actual: StrEnum) -> None:
        self.row = row
        self.expected = expected
        self.actual = actual
        wanted = ", ".join(sorted(str(state) for state in expected))
        super().__init__(
            f"{row.table} row {dict(row.key)!r} is {str(actual)!r}, not one of {wanted}"
        )


@dataclass(frozen=True, slots=True)
class Row:
    """Which row: its table, the key columns that name it, and the column holding its state.

    ``table`` may be schema-qualified (``sxd_annotate.annotation_revisions``). Every name
    is quoted as an identifier; a value is always a bound parameter.
    """

    table: str
    key: Mapping[str, object]
    state_column: str = "state"

    def __post_init__(self) -> None:
        if not self.key:
            raise ValueError("a transition names its row by at least one key column")
        if self.state_column in self.key:
            raise ValueError("the state column is the fence, not part of the key")


def _transition_statement(
    row: Row,
    *,
    expected: Iterable[str],
    to: str,
    assign: Mapping[str, object] = {},
    returning: Sequence[str] = (),
) -> tuple[sql.Composed, list[object]]:
    """The one statement, composed: identifiers quoted, values parameterised.

    ``assign`` values are bound parameters, except a :class:`psycopg.sql.Composable`
    (``NOW``), which is inlined — the only way to stamp database time.
    """

    wanted = sorted(set(expected))
    if not wanted:
        raise ValueError("a transition expects at least one prior state")
    if row.state_column in assign:
        raise ValueError("the state column is moved by `to`, not assigned")
    sets: list[sql.Composable] = [sql.SQL("{} = %s").format(sql.Identifier(row.state_column))]
    params: list[object] = [to]
    for column, value in assign.items():
        if isinstance(value, sql.Composable):
            sets.append(sql.SQL("{} = {}").format(sql.Identifier(column), value))
        else:
            sets.append(sql.SQL("{} = %s").format(sql.Identifier(column)))
            params.append(value)
    where: list[sql.Composable] = [
        sql.SQL("{} = %s").format(sql.Identifier(column)) for column in row.key
    ]
    params.extend(row.key.values())
    where.append(sql.SQL("{} = ANY(%s)").format(sql.Identifier(row.state_column)))
    params.append(wanted)
    statement = sql.SQL("UPDATE {table} SET {sets} WHERE {where} RETURNING {returning}").format(
        table=sql.Identifier(*row.table.split(".")),
        sets=sql.SQL(", ").join(sets),
        where=sql.SQL(" AND ").join(where),
        returning=sql.SQL(", ").join(
            sql.Identifier(column) for column in (returning or (row.state_column,))
        ),
    )
    return statement, params


def _read_statement(row: Row) -> tuple[sql.Composed, list[object]]:
    statement = sql.SQL("SELECT {state} FROM {table} WHERE {where}").format(
        state=sql.Identifier(row.state_column),
        table=sql.Identifier(*row.table.split(".")),
        where=sql.SQL(" AND ").join(
            sql.SQL("{} = %s").format(sql.Identifier(column)) for column in row.key
        ),
    )
    return statement, list(row.key.values())


def _wanted(expected: S | Iterable[S]) -> frozenset[S]:
    # A StrEnum member is itself iterable — as characters. The isinstance is the
    # difference between {"open"} and {"o", "p", "e", "n"}.
    if isinstance(expected, StrEnum):
        return frozenset({cast(S, expected)})
    return frozenset(expected)


def _missed(
    row: Row, *, expected: frozenset[S], to: S, found: tuple[Any, ...] | None
) -> TransitionError:
    if found is None:
        return MissingRowError(row)
    raw = str(found[0])
    states = type(to)
    try:
        actual = states(raw)
    except ValueError:
        return UnknownStateError(row, raw=raw, states=states)
    return StaleTransitionError(row, expected=frozenset(expected), actual=actual)


def transition(
    conn: psycopg.Connection[Any],
    row: Row,
    *,
    expected: S | Iterable[S],
    to: S,
    assign: Mapping[str, object] = {},
    returning: Sequence[str] = (),
) -> tuple[Any, ...]:
    """Move ``row`` from one of ``expected`` to ``to``, or raise which fact stopped it.

    Returns the ``returning`` columns of the moved row (the state column when none are
    named). Runs in the caller's transaction: a transition is one statement, and
    whether it commits alone or with the writes around it is the caller's decision.
    """

    wanted = _wanted(expected)
    statement, params = _transition_statement(
        row,
        expected=[str(state) for state in wanted],
        to=str(to),
        assign=assign,
        returning=returning,
    )
    with conn.cursor(row_factory=tuple_row) as cursor:
        cursor.execute(statement, params)
        moved = cursor.fetchone()
        if moved is not None:
            return moved
        read, key = _read_statement(row)
        cursor.execute(read, key)
        raise _missed(row, expected=wanted, to=to, found=cursor.fetchone())


async def transition_async(
    conn: psycopg.AsyncConnection[Any],
    row: Row,
    *,
    expected: S | Iterable[S],
    to: S,
    assign: Mapping[str, object] = {},
    returning: Sequence[str] = (),
) -> tuple[Any, ...]:
    """:func:`transition` on an async connection — the same statement, the same facts."""

    wanted = _wanted(expected)
    statement, params = _transition_statement(
        row,
        expected=[str(state) for state in wanted],
        to=str(to),
        assign=assign,
        returning=returning,
    )
    async with conn.cursor(row_factory=tuple_row) as cursor:
        await cursor.execute(statement, params)
        moved = await cursor.fetchone()
        if moved is not None:
            return moved
        read, key = _read_statement(row)
        await cursor.execute(read, key)
        raise _missed(row, expected=wanted, to=to, found=await cursor.fetchone())
