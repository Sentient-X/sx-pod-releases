"""Structured operational logging: the context, the redaction, the JSON, the middleware.

One story, top to bottom. A correlation context (async-safe, shared by logs, APIs, and
workflow activities) is bound by the ASGI middleware at the bottom of this module and read
by the formatter at the top of it; everything a record carries passes through the same
fail-closed redaction on the way out. A backend that reaches for :func:`get_logger` gets all
four without wiring them together.

The ASGI middleware is dependency-free on purpose — it is plain ASGI, not Starlette
middleware — so a process with no web framework still shares the correlation context.
"""

from __future__ import annotations

import json
import logging
import re
import time
import traceback
from collections.abc import Awaitable, Callable, Generator, Mapping, Sequence
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import UTC, datetime
from pathlib import Path
from types import MappingProxyType
from typing import Any, Final, cast
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

# --- correlation context -----------------------------------------------------

_NO_FIELDS: Mapping[str, object] = MappingProxyType({})
_FIELDS: ContextVar[Mapping[str, object]] = ContextVar("sx_service_log_fields", default=_NO_FIELDS)


def context_fields() -> Mapping[str, object]:
    """Return bound domain fields plus the active distributed-trace identity.

    API handlers use this same function when persisting operation receipts. Keeping
    the active OTel identity here prevents them from minting a second trace id while
    the formatter happens to log the real inbound one.
    """
    return {**_FIELDS.get(), **_current_trace_fields()}


@contextmanager
def bind_context(**fields: object) -> Generator[None]:
    """Temporarily bind the non-null fields, restoring the previous context on exit."""
    merged = dict(_FIELDS.get())
    merged.update({key: value for key, value in fields.items() if value is not None})
    token = _FIELDS.set(merged)
    try:
        yield
    finally:
        _FIELDS.reset(token)


# --- redaction ---------------------------------------------------------------

REDACTED: Final = "[REDACTED]"

_SECRET_PARTS = (
    "authorization",
    "cookie",
    "password",
    "passwd",
    "secret",
    "session",
    "token",
    "api_key",
    "apikey",
    "credential",
    "private_key",
)
_SIGNED_QUERY_PARTS = (
    "x-amz-",
    "x-goog-",
    "signature",
    "sig",
    "token",
    "credential",
)

# A key named `api_key` is caught by the name; a key pasted into the middle of a model
# prompt is not, and a prompt is exactly where one ends up. These are the shapes the
# providers this platform calls actually mint.
_PROVIDER_KEY = re.compile(
    r"AIza[0-9A-Za-z_-]{35}"  # Google
    r"|sk-lf-[0-9A-Za-z_-]{8,}|pk-lf-[0-9A-Za-z_-]{8,}"  # Langfuse
    r"|sk-or-v1-[0-9a-f]{32,}"  # OpenRouter
    r"|sk-ant-[0-9A-Za-z_-]{20,}"  # Anthropic
    r"|sk-[0-9A-Za-z_-]{20,}"  # OpenAI, and anything else spelled its way
)
# Inline base64 — a VLM prompt carries megabytes of it per keyframe. The length survives
# because "the prompt was 900 KB of images" is the answer to a real question.
_DATA_URI = re.compile(r"data:([\w.+-]+/[\w.+-]+)?;base64,([A-Za-z0-9+/=]+)")
_LONG_BASE64 = re.compile(r"(?<![A-Za-z0-9+/])[A-Za-z0-9+/]{512,}={0,2}(?![A-Za-z0-9+/])")
_JWT = re.compile(r"(?<![A-Za-z0-9_-])eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+")
_EMAIL = re.compile(r"(?i)(?<![\w.+-])[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}(?![\w.-])")
_PHONE = re.compile(r"(?<![\w])(?:\+\d[\d .()\-]{7,}\d|\(?\d{3}\)?[ .-]\d{3}[ .-]\d{4})(?![\w])")
_PRIVATE_KEY = re.compile(
    r"-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----.*?-----END [A-Z0-9 ]*PRIVATE KEY-----",
    re.DOTALL,
)


def is_secret_key(key: str) -> bool:
    normalized = key.lower().replace("-", "_")
    return any(part in normalized for part in _SECRET_PARTS)


def redact(value: object, *, key: str | None = None) -> object:
    """Recursively redact secrets, embedded credentials, base64 payloads, and signed URLs.

    One redaction, two consumers: the log formatter above and
    :mod:`sx_service.observability`, which filters telemetry before export. They face the same
    hazard — a credential or a customer's bytes riding a payload nobody inspected — so a
    second implementation would only be the one that lags.
    """
    if key is not None and is_secret_key(key):
        return REDACTED
    if isinstance(value, Mapping):
        mapping = cast(Mapping[object, object], value)
        return {str(k): redact(v, key=str(k)) for k, v in mapping.items()}
    if isinstance(value, Sequence) and not isinstance(value, str | bytes | bytearray):
        return [redact(item) for item in cast(Sequence[object], value)]
    if isinstance(value, str):
        return redact_text(value)
    return value


def redact_text(value: str) -> str:
    """Redact one string before it can enter logs or telemetry."""
    text = _DATA_URI.sub(_redact_data_uri, value)
    text = _LONG_BASE64.sub("[REDACTED:base64]", text)
    text = _PRIVATE_KEY.sub(REDACTED, text)
    text = _PROVIDER_KEY.sub(REDACTED, text)
    text = _JWT.sub(REDACTED, text)
    text = _EMAIL.sub(REDACTED, text)
    text = _PHONE.sub(REDACTED, text)
    if "://" in text:
        text = _redact_url(text)
    return text


def _redact_data_uri(match: re.Match[str]) -> str:
    mime = match.group(1) or "application/octet-stream"
    return f"[REDACTED:data-uri:{mime}:{len(match.group(2))}-base64-chars]"


def _redact_url(value: str) -> str:
    try:
        parts = urlsplit(value)
    except ValueError:
        return value
    if not parts.query:
        return value
    query: list[tuple[str, str]] = []
    changed = False
    for name, item in parse_qsl(parts.query, keep_blank_values=True):
        if any(part in name.lower() for part in _SIGNED_QUERY_PARTS):
            query.append((name, REDACTED))
            changed = True
        else:
            query.append((name, item))
    if not changed:
        return value
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), parts.fragment))


# --- the canonical JSON record -----------------------------------------------

_service_name: str = "unknown"
_service_release: str = "unknown"
_service_environment: str = "development"

_STANDARD_RECORD_FIELDS: Final = frozenset(
    {
        "args",
        "asctime",
        "created",
        "exc_info",
        "exc_text",
        "filename",
        "funcName",
        "levelname",
        "levelno",
        "lineno",
        "module",
        "msecs",
        "message",
        "msg",
        "name",
        "pathname",
        "process",
        "processName",
        "relativeCreated",
        "stack_info",
        "taskName",
        "thread",
        "threadName",
    }
)

# Stdlib logging raises on any extra= key that names a LogRecord attribute, and
# the raise happens inside the caller's process — a workload died in production
# because a reconcile result was logged with created=. Domain vocabulary may
# not be constrained by LogRecord's, so reserved names travel under this prefix
# and the formatter restores them on the way out.
_RESERVED_FIELD_PREFIX: Final = "sx_reserved_"


class _JsonFormatter(logging.Formatter):
    """Emit one canonical newline-delimited JSON object per record."""

    def format(self, record: logging.LogRecord) -> str:
        event = getattr(record, "event", None)
        payload: dict[str, object] = {
            "timestamp": datetime.fromtimestamp(record.created, tz=UTC).isoformat(),
            "severity": record.levelname.lower(),
            "service": _service_name,
            "release": _service_release,
            "environment": _service_environment,
            "logger": record.name,
            "event": str(event or record.getMessage()),
            "message": record.getMessage(),
        }
        payload.update(context_fields())
        for key, value in record.__dict__.items():
            if key in _STANDARD_RECORD_FIELDS or key.startswith("_") or key == "event":
                continue
            if key.startswith(_RESERVED_FIELD_PREFIX):
                key = key.removeprefix(_RESERVED_FIELD_PREFIX)
            payload[key] = _serialize(value)
        if record.exc_info:
            payload["error"] = {
                "kind": record.exc_info[0].__name__ if record.exc_info[0] else "Exception",
                "message": str(record.exc_info[1]),
                "stack": self.formatException(record.exc_info),
            }
        return json.dumps(redact(payload), separators=(",", ":"), sort_keys=True)


def _serialize(value: object) -> object:
    if value is None or isinstance(value, bool | int | float | str):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        mapping = cast(Mapping[object, object], value)
        return {str(key): _serialize(item) for key, item in mapping.items()}
    if isinstance(value, list | tuple | set | frozenset):
        return [
            _serialize(item)
            for item in cast(
                list[object] | tuple[object, ...] | set[object] | frozenset[object], value
            )
        ]
    if isinstance(value, BaseException):
        return {
            "kind": type(value).__name__,
            "message": str(value),
            "stack": "".join(traceback.format_exception(value)),
        }
    return str(value)


class BoundLogger:
    """Small structured logger supporting stdlib and structlog-style calls."""

    __slots__ = ("_fields", "_logger")

    def __init__(self, logger: logging.Logger, fields: Mapping[str, object] | None = None) -> None:
        self._logger = logger
        self._fields = dict(fields or {})

    def bind(self, **fields: object) -> BoundLogger:
        merged = dict(self._fields)
        merged.update({key: value for key, value in fields.items() if value is not None})
        return BoundLogger(self._logger, merged)

    def debug(self, event: str, *args: object, **fields: object) -> None:
        self._log(logging.DEBUG, event, args, fields)

    def info(self, event: str, *args: object, **fields: object) -> None:
        self._log(logging.INFO, event, args, fields)

    def warning(self, event: str, *args: object, **fields: object) -> None:
        self._log(logging.WARNING, event, args, fields)

    warn = warning

    def error(self, event: str, *args: object, **fields: object) -> None:
        self._log(logging.ERROR, event, args, fields)

    def critical(self, event: str, *args: object, **fields: object) -> None:
        self._log(logging.CRITICAL, event, args, fields)

    def log(self, level: int, event: str, *args: object, **fields: object) -> None:
        self._log(level, event, args, fields)

    def exception(self, event: str, *args: object, **fields: object) -> None:
        fields["exc_info"] = True
        self._log(logging.ERROR, event, args, fields)

    def _log(
        self,
        level: int,
        event: str,
        args: tuple[object, ...],
        fields: dict[str, object],
    ) -> None:
        exc_info = fields.pop("exc_info", None) is True
        stack_info = bool(fields.pop("stack_info", False))
        merged = dict(self._fields)
        merged.update({key: value for key, value in fields.items() if value is not None})
        merged["event"] = event
        merged = {
            (_RESERVED_FIELD_PREFIX + key if key in _STANDARD_RECORD_FIELDS else key): value
            for key, value in merged.items()
        }
        self._logger.log(
            level,
            event,
            *args,
            extra=merged,
            exc_info=exc_info,
            stack_info=stack_info,
        )


def get_logger(name: str) -> BoundLogger:
    """Return a structured logger without mutating global logging configuration."""
    return BoundLogger(logging.getLogger(name))


#: Protovalidate's CEL engine logs a complete syntax tree per evaluation under these
#: bare logger names, which turns one deeply nested validation into thousands of INFO
#: lines and buries every event a door actually emits. Every process that validates a
#: Connect request carries the engine, so ``configure_logging`` silences it for all of
#: them; a door never has to remember to.
_CHATTY_LIBRARY_LOGGERS = ("Activation", "Environment", "Evaluator", "NameContainer", "evaluation")


def quiet_library_loggers(*names: str, level: int = logging.WARNING) -> None:
    """Raise the level of third-party loggers that are chatty at INFO.

    A door silences a library, not one of its own loggers, so this is the one place
    that reaches for a stdlib logger by name on someone else's behalf — keeping
    ``get_logger`` the only way a service obtains a logger of its own.
    """

    for name in names:
        logging.getLogger(name).setLevel(level)


def configure_logging(
    *,
    service: str,
    release: str = "unknown",
    environment: str = "development",
    level: int | str = logging.INFO,
    force: bool = False,
) -> None:
    """Configure the process root logger with the canonical JSON schema."""
    global _service_environment, _service_name, _service_release
    if not service.strip():
        raise ValueError("service must not be empty")
    _service_name = service.strip()
    _service_release = release.strip() or "unknown"
    _service_environment = environment.strip() or "development"
    root = logging.getLogger()
    if root.handlers and not force:
        return
    handler = logging.StreamHandler()
    handler.setFormatter(_JsonFormatter())
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(level)
    quiet_library_loggers(*_CHATTY_LIBRARY_LOGGERS)


# --- the ASGI end of the same context ----------------------------------------

Receive = Callable[[], Awaitable[dict[str, Any]]]
Send = Callable[[dict[str, Any]], Awaitable[None]]
ASGIApp = Callable[[dict[str, Any], Receive, Send], Awaitable[None]]

_log = get_logger(__name__)


class ObservabilityMiddleware:
    """Create real OTel server/message spans and emit one operational completion log."""

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(
        self,
        scope: dict[str, Any],
        receive: Receive,
        send: Send,
    ) -> None:
        if scope.get("type") == "websocket":
            await self._websocket(scope, receive, send)
            return
        if scope.get("type") != "http":
            await self.app(scope, receive, send)
            return
        from opentelemetry import propagate
        from opentelemetry.trace import SpanKind, Status, StatusCode

        from sx_service.observability import current_observability

        runtime = current_observability()
        headers = {bytes(k).lower(): bytes(v) for k, v in scope.get("headers", [])}
        request_id = headers.get(b"x-request-id", b"").decode("ascii", "ignore")
        status: int | None = None
        disconnected = False
        started = time.perf_counter()
        carrier = {
            key.decode("ascii", "ignore"): value.decode("ascii", "ignore")
            for key, value in headers.items()
            if key in {b"traceparent", b"tracestate"}
        }
        parent = propagate.extract(carrier)
        method = str(scope.get("method", "HTTP"))
        raw_path = str(scope.get("path", "/"))
        span_name = f"{method} {_normalized_route(scope)}"
        manager = runtime.tracer().start_as_current_span(
            span_name,
            context=parent,
            kind=SpanKind.SERVER,
            attributes={
                "http.request.method": method,
                "url.path": raw_path,
                "http.route": _normalized_route(scope),
                "sx.telemetry.class": _traffic_class(raw_path),
            },
        )

        async def send_with_headers(message: dict[str, Any]) -> None:
            nonlocal status
            if message.get("type") == "http.response.start":
                status = int(message.get("status", 500))
                response_headers = list(message.get("headers", []))
                if request_id:
                    response_headers.append((b"x-request-id", request_id.encode("ascii", "ignore")))
                outbound: dict[str, str] = {}
                propagate.inject(outbound)
                for key in ("traceparent", "tracestate"):
                    if value := outbound.get(key):
                        response_headers.append((key.encode("ascii"), value.encode("ascii")))
                message["headers"] = response_headers
            await send(message)

        async def receive_with_disconnect() -> dict[str, Any]:
            nonlocal disconnected
            message = await receive()
            if message.get("type") == "http.disconnect":
                disconnected = True
            return message

        # Bind the distributed identity explicitly so sync FastAPI handlers running
        # in a worker thread persist the same trace the ASGI span and logs carry.
        with manager as span, bind_context(request_id=request_id, **_current_trace_fields()):
            try:
                await self.app(scope, receive_with_disconnect, send_with_headers)
            except Exception as exc:  # log and re-raise the application error unchanged
                span.record_exception(exc, escaped=True)
                span.set_status(Status(StatusCode.ERROR, type(exc).__name__))
                _log.exception(
                    "http.request.failed",
                    method=method,
                    route=_normalized_route(scope),
                    duration_ms=round((time.perf_counter() - started) * 1000, 3),
                )
                raise
            if status is None:
                # A Connect wait returns without a response when its caller closes.
                # That is client cancellation, not a fabricated server failure. An
                # application that returns no response while still connected remains
                # a 500 so a broken ASGI path cannot disappear from telemetry.
                status = 499 if disconnected else 500
            duration_ms = (time.perf_counter() - started) * 1000
            route = _normalized_route(scope)
            span.update_name(f"{method} {route}")
            span.set_attribute("http.route", route)
            span.set_attribute("http.response.status_code", status)
            if status >= 500:
                span.set_status(Status(StatusCode.ERROR, f"HTTP {status}"))
            runtime.meter().create_histogram(
                "http.server.request.duration",
                unit="ms",
                description="Server request duration",
            ).record(duration_ms, {"http.request.method": method, "http.route": route})
            runtime.meter().create_counter("http.server.request.count").add(
                1,
                {
                    "http.request.method": method,
                    "http.route": route,
                    "http.response.status_code": status,
                },
            )
            _log.info(
                "http.request.completed",
                method=method,
                route=route,
                status_code=status,
                duration_ms=round(duration_ms, 3),
            )

    async def _websocket(
        self,
        scope: dict[str, Any],
        receive: Receive,
        send: Send,
    ) -> None:
        from opentelemetry import context, propagate
        from opentelemetry.trace import SpanKind

        from sx_service.observability import current_observability

        runtime = current_observability()
        headers = {
            bytes(key).decode("ascii", "ignore"): bytes(value).decode("ascii", "ignore")
            for key, value in scope.get("headers", [])
            if bytes(key).lower() in {b"traceparent", b"tracestate"}
        }
        parent = propagate.extract(headers)
        path = str(scope.get("path", "/"))
        handshake = runtime.tracer().start_as_current_span(
            f"WS {path}",
            context=parent,
            kind=SpanKind.SERVER,
            attributes={"url.path": path, "network.protocol.name": "websocket"},
        )
        handshake.__enter__()
        handshake_context = context.get_current()
        accepted = False
        message_manager: Any = None

        async def receive_message() -> dict[str, Any]:
            nonlocal message_manager
            if message_manager is not None:
                message_manager.__exit__(None, None, None)
                message_manager = None
            message = await receive()
            if message.get("type") == "websocket.receive" and (
                message.get("text") is not None or message.get("bytes") is not None
            ):
                message_manager = runtime.tracer().start_as_current_span(
                    "websocket.message",
                    context=handshake_context,
                    attributes={"network.protocol.name": "websocket"},
                )
                message_manager.__enter__()
            return message

        async def send_message(message: dict[str, Any]) -> None:
            nonlocal accepted
            if message.get("type") == "websocket.accept" and not accepted:
                accepted = True
                handshake.__exit__(None, None, None)
            await send(message)

        try:
            await self.app(scope, receive_message, send_message)
        finally:
            if message_manager is not None:
                message_manager.__exit__(None, None, None)
            if not accepted:
                handshake.__exit__(None, None, None)


def _current_trace_fields() -> dict[str, str]:
    """Derive correlation from the active OTel context; never mint or parse ids here."""
    try:
        from opentelemetry import trace
    except ImportError:
        return {}
    span_context = trace.get_current_span().get_span_context()
    if not span_context.is_valid:
        return {}
    return {
        "trace_id": format(span_context.trace_id, "032x"),
        "span_id": format(span_context.span_id, "016x"),
        "trace_flags": format(int(span_context.trace_flags), "02x"),
    }


def _normalized_route(scope: Mapping[str, object]) -> str:
    route = scope.get("route")
    path = getattr(route, "path", None)
    return str(path or scope.get("path") or "/")


def _traffic_class(path: str) -> str:
    lowered = path.lower()
    if any(part in lowered for part in ("/health", "/version", "/connectivity")):
        return "noise"
    return "application"
