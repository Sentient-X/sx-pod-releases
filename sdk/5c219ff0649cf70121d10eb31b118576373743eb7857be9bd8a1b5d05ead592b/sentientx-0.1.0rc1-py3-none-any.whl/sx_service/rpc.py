"""Descriptor-owned Connect RPC surfaces and their one lawful mount path.

The protobuf service descriptor is the source of truth. This module turns it
into one small, immutable method table used both by request admission and by
repository renderers, then refuses to mount a generated Connect application
unless its paths, message types, idempotency metadata, and handlers agree with
that table exactly.

Requires the ``rpc`` extra.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping, Sequence
from contextlib import suppress
from dataclasses import dataclass
from datetime import timedelta
from types import MappingProxyType
from typing import Any, Protocol, TypeVar, cast
from uuid import uuid4
from weakref import WeakKeyDictionary

from buf.validate import validate_pb2
from connectrpc.code import Code
from connectrpc.errors import ConnectError
from connectrpc.method import IdempotencyLevel, MethodInfo
from connectrpc.request import RequestContext
from connectrpc.server import Endpoint
from fastapi import FastAPI, HTTPException, Request
from google.protobuf import descriptor_pb2
from google.protobuf.descriptor import (
    Descriptor,
    EnumValueDescriptor,
    FieldDescriptor,
    MethodDescriptor,
    ServiceDescriptor,
)
from google.protobuf.message import Message
from protovalidate import ValidationError, Validator
from sentientx.sx.common.v1 import common_pb2
from starlette.routing import Mount
from starlette.types import ASGIApp, Scope

from sx_service.connect import ConnectUnaryOnly, guard
from sx_service.logging import context_fields
from sx_service.registry import (
    OPERATION_POLL,
    PUBLIC_MUTATION,
    PUBLIC_READ,
    RATE_LIMITS,
    RESERVING_RATE_CLASSES,
    RequestLimit,
)

_METHOD_POLICY = "sentientx.sx.api.v1.method_policy"
_METHOD_POLICY_MESSAGE = "sentientx.sx.api.v1.MethodPolicy"
_PUBLIC_PROJECTION = "sentientx.sx.api.v1.PublicProjection"
_OPERATION_KIND = "sentientx.sx.common.v1.OperationKind"
_OPERATION_REF = "sentientx.sx.common.v1.OperationRef"
_RATE_BY_NAME = MappingProxyType({limit.name.value: limit for limit in RATE_LIMITS})
_EXPECTED_POLICY_FIELDS = frozenset({"surface", "projection", "rate_class", "operation_kind"})
_IDEMPOTENCY = MappingProxyType(
    {
        descriptor_pb2.MethodOptions.IDEMPOTENCY_UNKNOWN: IdempotencyLevel.UNKNOWN,
        descriptor_pb2.MethodOptions.NO_SIDE_EFFECTS: IdempotencyLevel.NO_SIDE_EFFECTS,
        descriptor_pb2.MethodOptions.IDEMPOTENT: IdempotencyLevel.IDEMPOTENT,
    }
)
_MISSING = object()

_RequestT = TypeVar("_RequestT")
_ResponseT = TypeVar("_ResponseT")
_ServiceT = TypeVar("_ServiceT", contravariant=True)

_VALIDATOR = Validator()
_MAX_REPORTED_VIOLATIONS = 12
_HTTP_TO_CONNECT = MappingProxyType(
    {
        400: Code.INVALID_ARGUMENT,
        401: Code.UNAUTHENTICATED,
        403: Code.PERMISSION_DENIED,
        404: Code.NOT_FOUND,
        409: Code.FAILED_PRECONDITION,
        413: Code.INVALID_ARGUMENT,
        422: Code.INVALID_ARGUMENT,
        429: Code.RESOURCE_EXHAUSTED,
        503: Code.UNAVAILABLE,
    }
)


class RpcContractError(ValueError):
    """A descriptor, generated endpoint, request context, or mount disagrees."""


def trace_id() -> str:
    """Return the active request trace, or a fresh identity outside middleware."""

    return str(context_fields().get("trace_id") or uuid4().hex)


def refusal(
    status: Code,
    code: str,
    message: str,
    trace: str,
    *,
    retryable: bool,
    retry_after: timedelta | None = None,
) -> ConnectError:
    """Build the one typed refusal envelope shared by every Connect door."""

    detail = common_pb2.RefusalDetail(code=code, retryable=retryable, trace_id=trace)
    if retry_after is not None:
        detail.retry_after.FromTimedelta(retry_after)
    return ConnectError(status, message, (detail,))


def http_refusal(error: HTTPException, trace: str) -> ConnectError:
    """Carry an existing HTTP guard refusal across without a second vocabulary."""

    status = _HTTP_TO_CONNECT.get(error.status_code, Code.INTERNAL)
    detail = error.detail
    if isinstance(detail, Mapping):
        fields = cast("Mapping[str, object]", detail)
        code = str(fields.get("code", f"http_{error.status_code}"))
        message = str(fields.get("message", detail))
        retryable = bool(fields.get("retryable", error.status_code >= 500))
    else:
        code = f"http_{error.status_code}"
        message = str(detail)
        retryable = error.status_code in {429, 503}
    retry_after: timedelta | None = None
    if error.headers is not None and (raw := error.headers.get("Retry-After")) is not None:
        with suppress(ValueError):
            retry_after = timedelta(seconds=int(raw))
    return refusal(status, code, message, trace, retryable=retryable, retry_after=retry_after)


def _field_path(field: validate_pb2.FieldPath) -> str:
    return ".".join(
        f"{element.field_name}[{element.index}]"
        if element.HasField("index")
        else element.field_name
        for element in field.elements
    )


def _violations(error: ValidationError) -> str:
    """Render a bounded, actionable account of a schema refusal."""

    reported = [
        f"{_field_path(item.proto.field) or '<message>'}: {item.proto.message}"
        for item in error.violations[:_MAX_REPORTED_VIOLATIONS]
    ]
    remaining = len(error.violations) - len(reported)
    if remaining > 0:
        reported.append(f"and {remaining} more")
    return "; ".join(reported)


class ValidateUnary:
    """Validate both directions of async and sync unary calls.

    ``code_prefix`` is the stable public error namespace (for example,
    ``catalog_task`` or ``fleet``); ``noun`` is the human-readable owner named
    in internal response failures. The mechanism is shared while each door keeps
    its own vocabulary.
    """

    def __init__(self, code_prefix: str, noun: str, *, responses: bool = True) -> None:
        self._code_prefix = code_prefix
        self._noun = noun
        self._responses = responses

    def _request(self, request: object) -> str:
        trace = trace_id()
        if not isinstance(request, Message):
            raise refusal(
                Code.INTERNAL,
                f"invalid_{self._code_prefix}_request_type",
                f"{self._noun} received a non-Protobuf request",
                trace,
                retryable=False,
            )
        try:
            _VALIDATOR.validate(request)
        except ValidationError as error:
            raise refusal(
                Code.INVALID_ARGUMENT,
                f"invalid_{self._code_prefix}_request",
                _violations(error),
                trace,
                retryable=False,
            ) from error
        return trace

    def _response(self, response: object, trace: str) -> None:
        if not self._responses:
            return
        if not isinstance(response, Message):
            raise refusal(
                Code.INTERNAL,
                f"invalid_{self._code_prefix}_response_type",
                f"{self._noun} produced a non-Protobuf response",
                trace,
                retryable=False,
            )
        try:
            _VALIDATOR.validate(response)
        except ValidationError as error:
            raise refusal(
                Code.INTERNAL,
                f"invalid_{self._code_prefix}_response",
                f"{self._noun} produced a response that violates its schema: {_violations(error)}",
                trace,
                retryable=False,
            ) from error

    async def intercept_unary(
        self,
        call_next: Callable[
            [_RequestT, RequestContext[_RequestT, _ResponseT]], Awaitable[_ResponseT]
        ],
        request: _RequestT,
        ctx: RequestContext[_RequestT, _ResponseT],
    ) -> _ResponseT:
        trace = self._request(request)
        response = await call_next(request, ctx)
        self._response(response, trace)
        return response

    def intercept_unary_sync(
        self,
        call_next: Callable[[_RequestT, RequestContext[_RequestT, _ResponseT]], _ResponseT],
        request: _RequestT,
        ctx: RequestContext[_RequestT, _ResponseT],
    ) -> _ResponseT:
        """Apply the same law to generated WSGI applications and test doors."""

        trace = self._request(request)
        response = call_next(request, ctx)
        self._response(response, trace)
        return response


def asgi_request(ctx: RequestContext[Any, Any]) -> Request:
    """Project RPC request metadata into the request shape shared guards read."""

    headers = [
        (str(key).lower().encode("latin-1"), str(value).encode("latin-1"))
        for key, value in ctx.request_headers().items()
    ]
    scope = cast(
        "Scope",
        {
            "type": "http",
            "asgi": {"version": "3.0", "spec_version": "2.3"},
            "http_version": "1.1",
            "method": ctx.http_method(),
            "scheme": "http",
            "path": "/",
            "raw_path": b"/",
            "query_string": b"",
            "headers": headers,
            "client": None,
            "server": None,
        },
    )
    return Request(scope)


@dataclass(frozen=True, slots=True)
class RpcPolicy:
    """The validated public projection attached to one protobuf method.

    A method has one exactly when its descriptor policy declares a surface, so
    half a projection — a surface without its common/advanced spelling, or an
    operation kind on a method nothing publishes — cannot be represented here.
    An internal method that declares only the rate class its work costs has no
    projection at all, and its meter lives on :class:`RpcMethod` like any
    other method's.
    """

    surface: str
    projection: EnumValueDescriptor
    operation_kind: EnumValueDescriptor | None


@dataclass(frozen=True, slots=True)
class RpcMethod:
    """One descriptor method with its canonical path and admission policy.

    Every method has a rate; only a public one has a projection.
    """

    descriptor: MethodDescriptor
    path: str
    rate: RequestLimit
    policy: RpcPolicy | None

    @property
    def input(self) -> Descriptor:
        return self.descriptor.input_type

    @property
    def output(self) -> Descriptor:
        return self.descriptor.output_type

    @property
    def side_effect_free(self) -> bool:
        """Whether the protobuf method declares standard read semantics."""

        return (
            self.descriptor.GetOptions().idempotency_level
            == descriptor_pb2.MethodOptions.NO_SIDE_EFFECTS
        )


@dataclass(frozen=True, slots=True)
class RpcService:
    """The complete descriptor-native normal form for one Connect service."""

    descriptor: ServiceDescriptor
    path: str
    methods: tuple[RpcMethod, ...]

    def method(self, name: str) -> RpcMethod:
        for method in self.methods:
            if method.descriptor.name == name:
                return method
        raise RpcContractError(f"{self.descriptor.full_name} has no RPC method named {name!r}")

    def rate(self, ctx: RequestContext[_RequestT, _ResponseT]) -> RequestLimit:
        """Resolve one request's rate from this exact descriptor method."""

        actual = ctx.method()
        if actual.service_name != self.descriptor.full_name:
            raise RpcContractError(
                f"expected RPC service {self.descriptor.full_name!r}, got {actual.service_name!r}"
            )
        method = self.method(actual.name)
        _validate_message_type(actual.input, method.input, method.path, "input")
        _validate_message_type(actual.output, method.output, method.path, "output")
        return method.rate


@dataclass(frozen=True, slots=True)
class RpcMount:
    """A validated descriptor service bound to the guarded application serving it.

    The application is a :class:`~sx_service.connect.ConnectUnaryOnly`, not any
    ASGI callable, because this dataclass is public and twenty-five modules
    already import it: while the field admitted a bare ``ASGIApp``,
    ``mount_rpc(app, RpcMount(service, generated))`` mounted a door with no
    ceiling and no protocol allowlist, and nothing — not Pyright, not a test —
    said a word. The type refuses it now, and ``__post_init__`` refuses it again
    for callers the type checker does not reach.
    """

    service: RpcService
    application: ConnectUnaryOnly

    def __post_init__(self) -> None:
        # Read as `object` on purpose. The annotation above is what a type
        # checker sees, which is why it would call this check redundant; this
        # check is for the caller it does not see — an untyped module, a `cast`,
        # a door built before the field was narrowed.
        application = cast("object", self.application)
        if not isinstance(application, ConnectUnaryOnly):
            raise RpcContractError(
                f"{self.service.descriptor.full_name} would mount "
                f"{type(application).__name__} directly; an RPC service is served "
                "only through the Connect ingress guard, so build the mount with bind_rpc"
            )


class _GeneratedApplication(Protocol[_ServiceT]):
    @property
    def path(self) -> str: ...

    def _resolve_endpoints(self, service: _ServiceT) -> Mapping[str, Endpoint[Any, Any]]: ...


_MOUNTED: WeakKeyDictionary[FastAPI, tuple[RpcService, ...]] = WeakKeyDictionary()


def _listed_fields(message: Message) -> tuple[tuple[FieldDescriptor, object], ...]:
    return tuple(cast("Sequence[tuple[FieldDescriptor, object]]", message.ListFields()))


def _enum_value(
    field: FieldDescriptor, value: object, *, expected_enum: str, method: str
) -> EnumValueDescriptor:
    if not isinstance(value, int) or field.enum_type is None:
        raise RpcContractError(f"{method} policy field {field.name!r} is not an enum")
    if field.enum_type.full_name != expected_enum:
        raise RpcContractError(
            f"{method} policy field {field.name!r} uses {field.enum_type.full_name!r}, "
            f"expected {expected_enum!r}"
        )
    descriptor = field.enum_type.values_by_number.get(value)
    if descriptor is None or descriptor.number == 0:
        raise RpcContractError(f"{method} policy field {field.name!r} is unspecified")
    return descriptor


def _policy_message(method: MethodDescriptor) -> Message | None:
    extensions = [
        value
        for field, value in _listed_fields(method.GetOptions())
        if field.full_name == _METHOD_POLICY
    ]
    if not extensions:
        return None
    if len(extensions) != 1 or not isinstance(extensions[0], Message):
        raise RpcContractError(f"{method.full_name} has an invalid method policy extension")
    message = extensions[0]
    if message.DESCRIPTOR.full_name != _METHOD_POLICY_MESSAGE:
        raise RpcContractError(
            f"{method.full_name} policy uses {message.DESCRIPTOR.full_name!r}, "
            f"expected {_METHOD_POLICY_MESSAGE!r}"
        )
    return message


def _rpc_method(method: MethodDescriptor, path: str) -> RpcMethod:
    """Parse one method's meter and, when it declares one, its public projection.

    The descriptor is external input, so both lawful policy shapes are parsed
    exactly here. A public method declares its surface, projection and rate
    class together; an internal method may declare a rate class alone, when the
    class derived from its idempotency would misprice the work it really does.
    Half a public projection is a typed configuration error rather than a
    default, which is what keeps "declares a surface" and "is public" the same
    fact everywhere downstream.

    A declared class is still bounded by what the method admits it does: a
    method that declares NO_SIDE_EFFECTS may not name a reserving class, since
    a read does not buy an admission's capacity.
    """

    message = _policy_message(method)
    if message is None:
        return RpcMethod(method, path, _default_rate(method), None)
    values = {field.name: value for field, value in _listed_fields(message)}
    unknown = values.keys() - _EXPECTED_POLICY_FIELDS
    if unknown:
        raise RpcContractError(
            f"{method.full_name} policy has unsupported fields: {', '.join(sorted(unknown))}"
        )
    rate_name = values.get("rate_class")
    if not isinstance(rate_name, str) or not rate_name:
        raise RpcContractError(f"{method.full_name} policy has no rate class")
    try:
        rate = _RATE_BY_NAME[rate_name]
    except KeyError as error:
        raise RpcContractError(
            f"{method.full_name} policy names unknown rate class {rate_name!r}"
        ) from error
    if (
        rate.name in RESERVING_RATE_CLASSES
        and method.GetOptions().idempotency_level == descriptor_pb2.MethodOptions.NO_SIDE_EFFECTS
    ):
        raise RpcContractError(
            f"{method.full_name} declares reserving rate class {rate.name.value!r} "
            "on a side-effect-free method"
        )
    surface = values.get("surface")
    projection_value = values.get("projection")
    operation_value = values.get("operation_kind")
    if surface is None and projection_value is None:
        if operation_value is not None:
            raise RpcContractError(
                f"{method.full_name} declares an operation kind without a public surface"
            )
        return RpcMethod(method, path, rate, None)
    if not isinstance(surface, str) or not surface or projection_value is None:
        raise RpcContractError(
            f"{method.full_name} policy declares half a public projection; a surface and "
            "a projection are declared together or neither is declared"
        )
    fields = message.DESCRIPTOR.fields_by_name
    projection = _enum_value(
        cast("FieldDescriptor", fields["projection"]),
        projection_value,
        expected_enum=_PUBLIC_PROJECTION,
        method=method.full_name,
    )
    operation_kind = (
        None
        if operation_value is None
        else _enum_value(
            cast("FieldDescriptor", fields["operation_kind"]),
            operation_value,
            expected_enum=_OPERATION_KIND,
            method=method.full_name,
        )
    )
    if operation_kind is not None and (
        method.GetOptions().idempotency_level == descriptor_pb2.MethodOptions.NO_SIDE_EFFECTS
    ):
        raise RpcContractError(
            f"{method.full_name} declares an operation kind on a side-effect-free method"
        )
    return RpcMethod(method, path, rate, RpcPolicy(surface, projection, operation_kind))


def _default_rate(method: MethodDescriptor) -> RequestLimit:
    if method.GetOptions().idempotency_level != descriptor_pb2.MethodOptions.NO_SIDE_EFFECTS:
        return PUBLIC_MUTATION
    if any(
        field.message_type is not None and field.message_type.full_name == _OPERATION_REF
        for field in method.input_type.fields
    ):
        return OPERATION_POLL
    return PUBLIC_READ


def rpc_service(descriptor: ServiceDescriptor) -> RpcService:
    """Parse one protobuf service into its validated immutable normal form."""

    path = f"/{descriptor.full_name}"
    methods: list[RpcMethod] = []
    surfaces: set[str] = set()
    for descriptor_method in descriptor.methods:
        method = _rpc_method(descriptor_method, f"{path}/{descriptor_method.name}")
        if method.policy is not None:
            if method.policy.surface in surfaces:
                raise RpcContractError(
                    f"{descriptor.full_name} publishes duplicate surface {method.policy.surface!r}"
                )
            surfaces.add(method.policy.surface)
        methods.append(method)
    if not methods:
        raise RpcContractError(f"{descriptor.full_name} has no RPC methods")
    return RpcService(descriptor, path, tuple(methods))


def _message_descriptor(message_type: type[object], *, location: str) -> Descriptor:
    descriptor = cast("object", getattr(message_type, "DESCRIPTOR", None))
    if not isinstance(descriptor, Descriptor):
        raise RpcContractError(f"{location} is not a generated protobuf message type")
    return descriptor


def _validate_message_type(
    message_type: type[object], expected: Descriptor, path: str, direction: str
) -> None:
    actual = _message_descriptor(message_type, location=f"{path} {direction}")
    if actual is not expected:
        raise RpcContractError(
            f"{path} {direction} is {actual.full_name!r}, expected {expected.full_name!r}"
        )


def _validate_endpoint(method: RpcMethod, endpoint: Endpoint[Any, Any]) -> None:
    actual: MethodInfo[Any, Any] = endpoint.method
    if actual.service_name != method.descriptor.containing_service.full_name:
        raise RpcContractError(f"{method.path} endpoint serves service {actual.service_name!r}")
    if actual.name != method.descriptor.name:
        raise RpcContractError(f"{method.path} endpoint names method {actual.name!r}")
    _validate_message_type(actual.input, method.input, method.path, "input")
    _validate_message_type(actual.output, method.output, method.path, "output")
    expected_idempotency = _IDEMPOTENCY.get(method.descriptor.GetOptions().idempotency_level)
    if expected_idempotency is None or actual.idempotency_level is not expected_idempotency:
        expected_name = expected_idempotency.name if expected_idempotency is not None else "unknown"
        raise RpcContractError(
            f"{method.path} endpoint idempotency is {actual.idempotency_level.name!r}, "
            f"expected {expected_name!r}"
        )
    handler = cast("object", getattr(endpoint, "function", None))
    if not callable(handler):
        raise RpcContractError(f"{method.path} has no callable handler")


def _validate_ceiling(
    service: RpcService, connect_application: object, max_request_bytes: int
) -> None:
    """Refuse a door whose two statements of its ceiling disagree.

    The generated runtime keeps its own ``read_max_bytes``. It is not a guard —
    it compares after buffering and decompressing — but it is the number the
    door wrote down, and every call site writes the number twice. Reading the
    runtime's resolved value rather than trusting the call site is the only way
    the two can be held to one decision.
    """

    declared: object = getattr(connect_application, "_read_max_bytes", None)
    if declared is None:
        raise RpcContractError(
            f"{service.descriptor.full_name} generated application declares no "
            "read_max_bytes; build it with the same ceiling the mount is given"
        )
    if declared != max_request_bytes:
        raise RpcContractError(
            f"{service.descriptor.full_name} ceilings disagree: the generated application "
            f"declares read_max_bytes={declared!r} and the mount is given "
            f"max_request_bytes={max_request_bytes!r}"
        )


def bind_rpc(
    service: RpcService,
    *,
    implementation: _ServiceT,
    connect_application: _GeneratedApplication[_ServiceT],
    max_request_bytes: int,
) -> RpcMount:
    """Validate a generated Connect application and mount it behind the guard.

    ``max_request_bytes`` is required and has no default: the ingress guard is
    not an option a call site remembers to take, it is what binding *is*.
    Fifteen of the twenty-three production call sites — fourteen modules across
    five of the nine doors — had bound without it, each refusing the generated
    client's default gzip body and each leaving the pre-allocation ceiling
    unenforced, so the wrap is no longer something a call site can omit.

    It must also be the ceiling the generated application was built with. The
    two are one decision written twice — ``read_max_bytes`` there, here the real
    guard — and a door that lets them drift declares a limit it does not have.
    """

    if connect_application.path != service.path:
        raise RpcContractError(
            f"generated Connect mount is {connect_application.path!r}, expected {service.path!r}"
        )
    captured_service = getattr(connect_application, "_service", _MISSING)
    if captured_service is not implementation:
        raise RpcContractError(
            f"{service.descriptor.full_name} generated application captured a different service"
        )
    try:
        endpoints = connect_application._resolve_endpoints(  # pyright: ignore[reportPrivateUsage]
            implementation
        )
    except Exception as error:
        raise RpcContractError(
            f"{service.descriptor.full_name} could not bind every generated handler"
        ) from error
    expected_paths = {method.path for method in service.methods}
    actual_paths = set(endpoints)
    if actual_paths != expected_paths:
        missing = sorted(expected_paths - actual_paths)
        extra = sorted(actual_paths - expected_paths)
        raise RpcContractError(
            f"{service.descriptor.full_name} endpoint paths disagree; "
            f"missing={missing!r}, extra={extra!r}"
        )
    for method in service.methods:
        _validate_endpoint(method, endpoints[method.path])
    _validate_ceiling(service, connect_application, max_request_bytes)
    generated = cast("ASGIApp", connect_application)
    return RpcMount(service, guard(generated, max_request_bytes=max_request_bytes))


def mount_rpc(app: FastAPI, mount: RpcMount) -> None:
    """Mount one validated RPC service and record its descriptor normal form."""

    current = _MOUNTED.get(app, ())
    if any(service.path == mount.service.path for service in current) or any(
        isinstance(route, Mount) and route.path == mount.service.path for route in app.routes
    ):
        raise RpcContractError(f"RPC service path {mount.service.path!r} is already mounted")
    existing_surfaces = {
        method.policy.surface
        for service in current
        for method in service.methods
        if method.policy is not None
    }
    duplicate_surfaces = sorted(
        method.policy.surface
        for method in mount.service.methods
        if method.policy is not None and method.policy.surface in existing_surfaces
    )
    if duplicate_surfaces:
        raise RpcContractError(
            "RPC public surfaces are already mounted: " + ", ".join(duplicate_surfaces)
        )
    app.mount(mount.service.path, mount.application)
    _MOUNTED[app] = (*current, mount.service)


def mounted_rpc_services(app: FastAPI) -> tuple[RpcService, ...]:
    """Return the descriptor-normal services mounted through :func:`mount_rpc`."""

    return _MOUNTED.get(app, ())
