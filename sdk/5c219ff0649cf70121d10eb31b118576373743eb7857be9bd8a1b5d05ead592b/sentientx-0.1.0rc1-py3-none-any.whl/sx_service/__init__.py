"""The service shell every sx backend shares.

A backend file should contain its own domain and nothing else. Everything else about
*being a door* lives here, one concept per module, imported by its own name:

* :mod:`sx_service.app` — ``create_app``: the one way to be an HTTP door, so a door
  cannot be unobservable or unhealthy-endpointed. A door is API-only; the product's
  console is a static bundle on its own origin (``door`` extra);
* :mod:`sx_service.rpc` — descriptor-native Connect policy, generated endpoint
  validation, and the one RPC mount path (``rpc`` extra);
* :mod:`sx_service.registry` — what doors exist, how to reach them, what rate class
  guards them (and the console, its workspaces, dev ports, and the rendered projections
  of those rows);
* :mod:`sx_service.logging` — structured logging, the correlation context, redaction,
  and the ASGI middleware that binds a request into it;
* :mod:`sx_service.db` — the Postgres pool, the sync connection, and the
  advisory-locked numbered-SQL migration runner (``db`` extra);
* :mod:`sx_service.kubernetes` — the stdlib in-cluster Kubernetes API client for a
  service that owns a few cluster resources;
* :mod:`sx_service.buckets` — the object-storage ownership and retention registry;
* :mod:`sx_service.storage` — the object store itself: the typed R2/MinIO client
  whose every delete asks that registry first (``storage`` extra);
* :mod:`sx_service.testing` — the dependency-budget walk every shared package runs on
  itself (test-only; reach it through a ``dev`` group).

Nothing is re-exported from this module. A caller writes ``from sx_service.registry
import CATALOG``, so the import line says which part of the shell it depends on — and
which extra that part needs.
"""
