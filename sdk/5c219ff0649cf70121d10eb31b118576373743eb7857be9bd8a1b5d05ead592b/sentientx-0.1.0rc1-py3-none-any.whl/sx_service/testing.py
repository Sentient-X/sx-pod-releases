"""The dependency-budget check every shared package runs on itself.

Each `packages/*` entry declares what it is allowed to import and asserts that its
source stays inside it — that is how a rank-0 leaf stays installable in any
consumer's environment, and it is required of every package by
`tools/check_package_layering.py`. The generic form of that AST walk was repeated
across the package suites.

What stays in each package is the part that differs and matters: the budget itself,
and the paragraph explaining why that budget is what it is. What lives here is only
the walk.

This module is test-only. A package reaches it through `sx-service` in its `dev`
group, never in its runtime dependencies — the layering law reads those, and a leaf
must not gain an edge because of how it tests itself.
"""

from __future__ import annotations

import ast
from collections.abc import Collection, Iterator
from pathlib import Path

ENVIRONMENT_ATTRIBUTES = frozenset({"environ", "getenv"})
"""Reading configuration from the process environment, in either spelling.

Settings and secrets are wiring-site arguments stack-wide: a shared package that
reads the environment decides its own configuration and stops being reusable.
`sx_service.registry` is the deliberate exception — the registry *is* the one place
the canonical `SX_*_URL` variables are read — so the kit's own purity test exempts
it by name.
"""


class NoModulesFoundError(AssertionError):
    """A budget was asserted against a source tree that has no modules.

    Always a mistake in the test rather than a clean result: a check that silently
    passes because it looked in the wrong directory is worse than no check.
    """


def _modules(src: Path) -> list[Path]:
    """Every Python module under a package's source root, in a stable order."""
    paths = sorted(src.rglob("*.py"))
    if not paths:
        raise NoModulesFoundError(f"no modules found under {src}")
    return paths


def _top_level_imports(tree: ast.AST) -> Iterator[set[str]]:
    """Each import node paired with the root package names it pulls in.

    Relative imports are skipped: they are the package importing itself, which is
    never what a dependency budget is about.
    """
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            yield {alias.name.split(".")[0] for alias in node.names}
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            yield {node.module.split(".")[0]}


def _import_violations(src: Path, allowed: Collection[str]) -> list[str]:
    """Imports outside the budget, as `<module>: imports <name>` lines."""
    budget = frozenset(allowed)
    return [
        f"{path.relative_to(src)}: imports {name}"
        for path in _modules(src)
        for names in _top_level_imports(ast.parse(path.read_text()))
        for name in sorted(names - budget)
    ]


def _environment_reads(src: Path) -> list[str]:
    """Every `os.environ` / `os.getenv` access, as `<module>: os.<attr>` lines."""
    return [
        f"{path.relative_to(src)}: os.{node.attr}"
        for path in _modules(src)
        for node in ast.walk(ast.parse(path.read_text()))
        if isinstance(node, ast.Attribute) and node.attr in ENVIRONMENT_ATTRIBUTES
    ]


def assert_within_budget(src: Path, allowed: Collection[str], *, package: str) -> None:
    """Fail with every offending import listed, not just the first."""
    violations = _import_violations(src, allowed)
    assert not violations, f"imports beyond the {package} budget:\n" + "\n".join(violations)


def assert_no_environment_reads(src: Path, *, package: str) -> None:
    """Fail with every environment read listed."""
    violations = _environment_reads(src)
    assert not violations, f"environment reads in {package}:\n" + "\n".join(violations)
