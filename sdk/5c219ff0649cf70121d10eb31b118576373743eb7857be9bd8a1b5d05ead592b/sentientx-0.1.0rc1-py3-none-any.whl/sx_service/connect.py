"""The ingress guard every Connect door mounts in front of its generated app.

`sx_service.rpc` makes a door's *descriptor* unskippable. This module does the
same for the two things the generated runtime does not do for you, and which
three doors had each answered differently:

* **the protocol allowlist.** A generated Connect application is
  multi-protocol-capable: the runtime ships gRPC and gRPC-Web handlers beside
  the Connect ones. A service is assigned one ingress protocol from its real
  callers, so this refuses anything that is not Connect unary rather than
  quietly serving a second protocol variant of the same method.

* **the request-body ceiling, enforced before allocation.** ``read_max_bytes``
  on the generated application is a *post-hoc assertion*, not a guard: the
  runtime buffers the whole body, decompresses it in full, and only then
  compares the size. Both steps are unbounded, so an unauthenticated POST can
  exhaust memory either by streaming a large body or by sending a small gzip
  bomb. This wrapper streams with a running ceiling, refuses on
  ``content-length`` when the sender declares one, and bounds the inflater's
  *output* so a compressed pre-auth request cannot expand without bound.

The ceiling is a required argument with no default. A default is how one door
silently inherits a limit nobody chose for it — the three doors that grew their
own copies of this constant had already drifted to two different values, and
which one a door wants is a real decision about its largest lawful request.

A door that mounts this wrapper must construct its generated application with
``compressions=()``. The wrapper normalizes ``content-encoding`` away before the
runtime sees the body, so leaving the runtime's own decompressor enabled would
reintroduce exactly the unbounded path this exists to close. :func:`guard`
binds the two together so they cannot be set inconsistently, and
:func:`sx_service.rpc.bind_rpc` is its only caller: binding a generated
application to its descriptor and putting this in front of it are one act, so
a call site cannot do the first and forget the second. What makes that true is
not `bind_rpc` alone — `RpcMount` is public — but `RpcMount`'s field type: it
holds a :class:`ConnectUnaryOnly`, so there is no shape of mount that carries a
raw generated application past it.

Every refusal here is a Connect error body, not a bare HTTP status. A client
that finds no JSON falls back to the status, and that fallback reads 413 and 415
as ``unknown`` and 400 as ``internal`` — the codes that mean "the server had a
problem" — so a permanently oversized or corrupt request would be retried
forever. The status still says the HTTP truth; the body says which refusal it
is.

Requires the ``rpc`` extra.
"""

from __future__ import annotations

import asyncio
import json
import zlib
from typing import Literal, TypeAlias, cast

from starlette.types import ASGIApp, Receive, Scope, Send
from starlette.types import Message as ASGIMessage

#: The only content types a Connect unary ingress answers. gRPC and gRPC-Web are
#: refused here rather than served as a second variant of the same method.
ALLOWED_CONTENT_TYPES = frozenset({"application/json", "application/proto"})

_GZIP_WINDOW_BITS = 16 + zlib.MAX_WBITS
_ACCEPT_POST = b"application/json, application/proto"
_ACCEPT_ENCODING = b"gzip, identity"
_ERROR_MEDIA_TYPE = b"application/json"
_TOO_LARGE = "request body is larger than this endpoint accepts"
_SUPPORTED_ENCODINGS = "supported encodings are gzip, identity"

_Outcome: TypeAlias = Literal["disconnect", "oversized", "malformed"]


class ConnectUnaryOnly:
    """Admit Connect unary requests, bounded, and stop work when callers leave.

    Wraps a generated Connect ASGI application. ``max_request_bytes`` bounds
    both the bytes read from the socket and the bytes produced by decompressing
    them; neither is allowed to exceed it, and the refusal happens before the
    generated application is given the body.
    """

    def __init__(self, application: ASGIApp, *, max_request_bytes: int) -> None:
        if max_request_bytes < 1:
            raise ValueError("Connect request ceiling must be positive")
        self._application = application
        self._limit = max_request_bytes

    @staticmethod
    async def _reject(
        send: Send,
        status: int,
        headers: list[tuple[bytes, bytes]],
        *,
        code: str,
        message: str,
    ) -> None:
        """Refuse in the Connect error shape, not as a bare HTTP status.

        A bodiless status is not a Connect answer: ``ConnectWireError.from_response``
        falls back to ``from_http_status``, which reads 413 and 415 as ``unknown``
        and 400 as ``internal`` — the two codes every client treats as "the server
        had a problem, retry". A permanently oversized or corrupt request would
        then be retried forever. The body carries the code, and the client reads it
        in preference to the status, so the refusal keeps its meaning.
        """

        body = json.dumps({"code": code, "message": message}).encode()
        await send(
            {
                "type": "http.response.start",
                "status": status,
                "headers": [
                    *headers,
                    (b"content-type", _ERROR_MEDIA_TYPE),
                    (b"content-length", str(len(body)).encode()),
                ],
            }
        )
        await send({"type": "http.response.body", "body": body, "more_body": False})

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        limit = self._limit
        request_encoding = b"identity"
        if scope["type"] == "http" and scope.get("method") == "POST":
            headers = {bytes(key).lower(): bytes(value) for key, value in scope.get("headers", ())}
            content_type = headers.get(b"content-type", b"").decode("ascii", "ignore")
            media_type = content_type.partition(";")[0].strip().lower()
            if media_type not in ALLOWED_CONTENT_TYPES:
                await self._reject(
                    send,
                    415,
                    [(b"accept-post", _ACCEPT_POST)],
                    code="unimplemented",
                    message=f"{media_type or 'no content type'} is not served here; "
                    "this endpoint answers Connect unary only",
                )
                return
            request_encoding = headers.get(b"content-encoding", b"identity").lower()
            if request_encoding not in {b"identity", b"gzip"}:
                named = request_encoding.decode("ascii", "replace")
                await self._reject(
                    send,
                    415,
                    [(b"accept-encoding", _ACCEPT_ENCODING)],
                    code="unimplemented",
                    message=f"unknown compression: {named!r}: {_SUPPORTED_ENCODINGS}",
                )
                return
            raw_length = headers.get(b"content-length")
            if raw_length is not None:
                try:
                    too_large = int(raw_length) > limit
                except ValueError:
                    too_large = True
                if too_large:
                    await self._reject(send, 413, [], code="resource_exhausted", message=_TOO_LARGE)
                    return
            if request_encoding == b"gzip":
                # Generated clients send gzip by default. Normalize it with an
                # output ceiling before the generated server sees the body so a
                # compressed pre-auth request cannot expand without bound.
                scope = {
                    **scope,
                    "headers": [
                        (key, value)
                        for key, value in scope.get("headers", ())
                        if bytes(key).lower() not in {b"content-encoding", b"content-length"}
                    ],
                }
        if scope["type"] != "http":
            await self._application(scope, receive, send)
            return

        # One chunk of backpressure: the disconnect watcher may read ahead only
        # far enough to wake the generated application, never buffer an open-ended
        # unauthenticated request body beside its own decoder.
        messages: asyncio.Queue[ASGIMessage] = asyncio.Queue(maxsize=1)

        async def receive_messages() -> _Outcome:
            received = 0
            decoded = 0
            inflater = (
                zlib.decompressobj(_GZIP_WINDOW_BITS) if request_encoding == b"gzip" else None
            )
            while True:
                message = await receive()
                if message["type"] == "http.request":
                    body = message.get("body", b"")
                    received += len(body)
                    if received > limit:
                        return "oversized"
                    if inflater is not None:
                        try:
                            body = inflater.decompress(body, limit - decoded + 1)
                        except zlib.error:
                            return "malformed"
                        if inflater.unconsumed_tail:
                            return "oversized"
                        decoded += len(body)
                        if decoded > limit:
                            return "oversized"
                        if not message.get("more_body", False):
                            if not inflater.eof or inflater.unused_data:
                                return "malformed"
                            try:
                                tail = inflater.flush(limit - decoded + 1)
                            except zlib.error:
                                return "malformed"
                            decoded += len(tail)
                            if decoded > limit:
                                return "oversized"
                            body += tail
                        message = {**message, "body": body}
                await messages.put(message)
                if message["type"] == "http.disconnect":
                    return "disconnect"

        async def forwarded_receive() -> ASGIMessage:
            return await messages.get()

        async def run_application() -> None:
            await self._application(scope, forwarded_receive, send)

        receiver = asyncio.create_task(receive_messages())
        application = asyncio.create_task(run_application())
        try:
            done, _pending = await asyncio.wait(
                (application, receiver),
                return_when=asyncio.FIRST_COMPLETED,
            )
            if application in done:
                await application
                return
            outcome = await receiver
            application.cancel()
            await asyncio.gather(application, return_exceptions=True)
            if outcome == "oversized":
                await self._reject(send, 413, [], code="resource_exhausted", message=_TOO_LARGE)
            elif outcome == "malformed":
                await self._reject(
                    send,
                    400,
                    [],
                    code="invalid_argument",
                    message="request body is not the compression it declares",
                )
        finally:
            receiver.cancel()
            application.cancel()
            await asyncio.gather(receiver, application, return_exceptions=True)


class DoubleDecompressionError(ValueError):
    """A guarded mount left the generated runtime's own decompressor enabled.

    The two halves are one decision. This wrapper strips ``content-encoding``
    after inflating with an output ceiling, so a runtime that still negotiates
    gzip would inflate a second time — unbounded, which is the exact path the
    ceiling exists to close. Raised while the app is built, not while it serves.
    """


def _refuse_double_decompression(application: ASGIApp) -> None:
    """Refuse a generated application that would decompress after this guard.

    Reads the runtime's resolved codec table rather than the constructor
    argument, because ``compressions=None`` and ``compressions=()`` are both
    spellings a door might reach for and only one of them is safe. ``identity``
    is always present and is not a decompressor.

    An application with no codec table is not a Connect runtime — a plain ASGI
    callable in a test, say — and has nothing to double-decompress.
    """
    table: object = getattr(application, "_compressions", None)
    if not isinstance(table, dict):
        return
    # The runtime's table is a private attribute with no published type, so its
    # keys arrive untyped. Narrow to the strings we actually report rather than
    # letting `Unknown` leak into the refusal message.
    negotiable = sorted(
        key
        for key in cast("dict[object, object]", table)
        if isinstance(key, str) and key != "identity"
    )
    if negotiable:
        where = getattr(application, "path", type(application).__name__)
        raise DoubleDecompressionError(
            f"{where} is mounted behind the Connect ingress guard but its generated "
            f"application still negotiates {', '.join(negotiable)}; construct it with "
            "compressions=() so the bounded inflater is the only one"
        )


def guard(application: ASGIApp, *, max_request_bytes: int) -> ConnectUnaryOnly:
    """Put the bounded unary ingress in front of one generated application.

    This is where the ``compressions=()`` pairing is enforced: the wrap runs
    against the real generated application, so the one thing a door can still
    get wrong is refused here instead of documented and hoped for. The ceiling
    is the door's own — see :func:`sx_service.rpc.bind_rpc`, the only caller.
    """

    _refuse_double_decompression(application)
    return ConnectUnaryOnly(application, max_request_bytes=max_request_bytes)
