"""Postgres, declared once: the connection surfaces and the migration runner.

Two connection shapes, because services genuinely need two: an async pool the API
borrows from per request (opened and closed by the app lifespan), and a single
sync connection for the things that run outside the event loop — migrations,
workers, seeds, and break-glass tools.

The runner above them is house style made executable. Every sx backend keeps
hand-written SQL in numbered files, applied exactly once, in filename order, under
a Postgres advisory lock, with the applied set tracked in a per-service ledger
table. Ten services had retyped that same forty-line procedure; they differed in
precisely three facts — the ledger table, the lock name, and where the files live
— so those three are the value and everything else is derived.

Migrations are append-only once deployed. A file is never edited: the ledger keys
on the filename, so an edited file is silently skipped on every host that already
ran it.

Requires the ``db`` extra.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from urllib.parse import urlencode

import psycopg
from psycopg.conninfo import conninfo_to_dict, make_conninfo
from psycopg_pool import AsyncConnectionPool

DEFAULT_MIN_SIZE = 1
DEFAULT_MAX_SIZE = 8


def make_pool(
    dsn: str,
    *,
    min_size: int = DEFAULT_MIN_SIZE,
    max_size: int = DEFAULT_MAX_SIZE,
) -> AsyncConnectionPool:
    """The API's connection pool, created closed.

    ``open=False`` is deliberate: the pool must be opened inside the running
    event loop by the app lifespan, not at import time.
    """
    return AsyncConnectionPool(dsn, min_size=min_size, max_size=max_size, open=False)


def connect(dsn: str) -> psycopg.Connection[tuple[object, ...]]:
    """One sync connection (worker activities, migrations, tools)."""
    return psycopg.connect(dsn)


def libpq_dsn(dsn: str) -> str:
    """A DSN with any SQLAlchemy ``+driver`` suffix removed.

    Services configured through SQLAlchemy-style URLs (``postgresql+psycopg://``)
    and services configured through libpq URLs share one env var this way.
    """
    if dsn.startswith("postgresql+"):
        _scheme, rest = dsn.split("://", 1)
        return f"postgresql://{rest}"
    return dsn


def schema_dsn(dsn: str, schema: str, *, extensions_schema: str = "sx_extensions") -> str:
    """Select an explicit schema without dropping any libpq connection setting.

    The caller owns the allowed domain names. This boundary validates identifiers
    and refuses pre-existing session options, which could override search_path.
    """
    for name in (schema, extensions_schema):
        if re.fullmatch(r"[a-z_][a-z0-9_]*", name) is None:
            raise ValueError("invalid database schema identifier")
    parsed = conninfo_to_dict(libpq_dsn(dsn))
    if parsed.pop("options", None):
        raise ValueError("database authority cannot override per-domain session options")
    return make_conninfo(
        "", **parsed, options=f"-csearch_path={schema},{extensions_schema},pg_catalog"
    )


def sqlalchemy_dsn(dsn: str) -> str:
    """Express libpq parameters through SQLAlchemy's psycopg query parameters.

    Query encoding retains sockets, multi-host settings and percent-encoded
    credentials without interpreting them as URL authority punctuation.
    SQLAlchemy is deliberately not a dependency of the database kit.
    """
    return "postgresql+psycopg:///?" + urlencode(conninfo_to_dict(libpq_dsn(dsn)))


class MigrationsUnavailableError(RuntimeError):
    """The declared migration files could not be located.

    Fail-closed: a service whose schema cannot be found must not start and
    silently serve against whatever tables happen to exist.
    """


@dataclass(frozen=True, slots=True)
class SqlMigrations:
    """One service's migration set.

    ``directory`` is the checkout path. ``package`` is the installed-wheel
    fallback: services that ship their ``.sql`` files as package data name the
    importable package here, and the runner reads them from there when the
    source tree is absent.
    """

    ledger: str
    lock: str
    directory: Path
    package: str | None = None

    def files(self) -> tuple[Path, ...]:
        """The migration files in application order.

        Sorted by filename — the numbering *is* the order, which is why the
        files are named ``0001_…``, ``0002_…`` and never renumbered.
        """
        if self.directory.is_dir():
            found = [p for p in self.directory.iterdir() if p.suffix == ".sql"]
        elif self.package is not None:
            anchor = resources.files(self.package) / "migrations"
            found = [Path(str(p)) for p in anchor.iterdir() if str(p).endswith(".sql")]
        else:
            raise MigrationsUnavailableError(f"no migrations at {self.directory}")
        return tuple(sorted(found, key=lambda p: p.name))

    def apply(self, dsn: str) -> list[str]:
        """Apply every pending migration; return the filenames applied.

        The whole run is serialised by a session-level advisory lock, so
        concurrent replicas starting together cannot race. Each file runs in one
        runner-owned transaction together with its ledger insert — which is why
        a migration file must not contain its own BEGIN/COMMIT.

        The ledger is consulted per file rather than snapshotted once, because a
        migration is allowed to write to the ledger itself. That is how a service
        adopting this runner tells it that an earlier file, applied under a
        different key by whatever ran before, is already done — a snapshot taken
        before the run would not see that and would replay it.
        """
        applied: list[str] = []
        with psycopg.connect(dsn) as conn:
            conn.autocommit = True
            conn.execute("SELECT pg_advisory_lock(hashtext(%s))", (self.lock,))
            try:
                conn.execute(self._create_ledger)
                for path in self.files():
                    if conn.execute(self._select_one, (path.name,)).fetchone() is not None:
                        continue
                    # Migration files are trusted repository content, never
                    # caller input; bytes keep psycopg's LiteralString check out
                    # of the way without a cast.
                    statements = path.read_bytes()
                    with conn.transaction():
                        conn.execute(statements)
                        conn.execute(self._insert_ledger, (path.name,))
                    applied.append(path.name)
            finally:
                conn.execute("SELECT pg_advisory_unlock(hashtext(%s))", (self.lock,))
        return applied

    # The ledger name is an identifier, so it cannot be a bound parameter. It is
    # a constant declared in this repository, not caller input, and it is
    # validated here so a typo can never reach the database as SQL.
    @property
    def _ledger_identifier(self) -> str:
        if not self.ledger.replace("_", "").isalnum():
            raise MigrationsUnavailableError(f"unsafe ledger table name: {self.ledger!r}")
        return self.ledger

    @property
    def _create_ledger(self) -> bytes:
        return (
            f"CREATE TABLE IF NOT EXISTS {self._ledger_identifier} ("
            " filename text PRIMARY KEY,"
            " applied_at timestamptz NOT NULL DEFAULT now())"
        ).encode()

    @property
    def _select_one(self) -> bytes:
        return f"SELECT 1 FROM {self._ledger_identifier} WHERE filename = %s".encode()

    @property
    def _insert_ledger(self) -> bytes:
        return f"INSERT INTO {self._ledger_identifier} (filename) VALUES (%s)".encode()
