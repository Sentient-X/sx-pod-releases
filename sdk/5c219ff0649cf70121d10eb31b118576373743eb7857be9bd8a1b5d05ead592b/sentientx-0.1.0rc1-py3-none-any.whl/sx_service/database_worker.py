"""Start a worker against its domain schemas in one database authority.

The deployment supplies explicit environment-name/schema bindings. This launcher
owns no domain registry and does not add application/server dependencies.
"""

from __future__ import annotations

import argparse
import os
import re
from collections.abc import Mapping, Sequence

from sx_service.db import schema_dsn, sqlalchemy_dsn


def database_environment(
    authority: str,
    environment: Mapping[str, str],
    bindings: Sequence[str],
    sqlalchemy_bindings: Sequence[str] = (),
) -> dict[str, str]:
    result = dict(environment)
    seen: set[str] = set()
    for values, sqlalchemy in ((bindings, False), (sqlalchemy_bindings, True)):
        for binding in values:
            key, separator, schema = binding.partition("=")
            if not separator or re.fullmatch(r"[A-Z][A-Z0-9_]*", key) is None:
                raise ValueError("database binding must be ENVIRONMENT_KEY=schema")
            if key in seen or key == "SX_CONTROLPLANE_PG_DSN":
                raise ValueError(f"conflicting database binding: {key}")
            seen.add(key)
            projected = schema_dsn(authority, schema)
            result[key] = sqlalchemy_dsn(projected) if sqlalchemy else projected
            result.pop(key + "_FILE", None)
    if not seen:
        raise ValueError("a worker requires at least one database binding")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bind", action="append", default=[])
    parser.add_argument("--sqlalchemy-bind", action="append", default=[])
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not command:
        parser.error("a worker command is required after --")
    environment = database_environment(
        os.environ["SX_CONTROLPLANE_PG_DSN"], os.environ, args.bind, args.sqlalchemy_bind
    )
    os.execvpe(command[0], command, environment)


if __name__ == "__main__":
    main()
