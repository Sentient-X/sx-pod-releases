"""The object store, once: R2 in production, MinIO in development.

Two backends had retyped the same client — the same endpoint credentials, the
same ``max_pool_connections=10``, the same three "missing" error codes, the same
HEAD-before-write idempotency, the same paginator loop, the same dev-only
``ensure_bucket``. What they did *not* share was the part that matters: one of
them routed every delete through a retention guard and the other had no delete
path to guard. Sharing the client and leaving the guard behind would have been
the wrong half.

So this module owns both. :class:`ObjectStore` is the complete typed vocabulary
of S3 calls the platform makes — and none of them deletes. The standing order
(2026-08-17) is that every R2 deletion is human work: ``request_deletion``
first asks ``sx_service.buckets.assert_deletable`` — the declared registry
decides whether the bytes under a key are even allowed to stop existing — and
what an allowed request produces is a durable JSON record under
:data:`DELETION_QUEUE_PREFIX`, never a ``DeleteObject`` call. Raw-frozen,
archive, backup, and migration-frozen keys cannot even be queued, and neither
can a key under no declared prefix at all.

Two rules give the surface its shape:

* **Reads are addressed; writes are at home.** Every read takes an
  :class:`ObjectRef`, because a service legitimately reads buckets it does not
  own (the catalog registers objects out of ``sxd-data``). Every write and
  delete takes a bare key and lands in the one bucket this store is bound to. A
  service cannot write outside the bucket it owns — structurally, not by
  convention.
* **Nothing returns a response dict.** ``head`` yields an :class:`ObjectHead`,
  listing yields :class:`ObjectInfo`, hydration yields a :class:`FetchedObject`.
  The boto3 response shape stops at this file.

A third rule governs the one write nobody here performs. A presigned PUT hands
the bytes to a client this process never sees, so the only party that can say
what landed is the store. :meth:`ObjectStore.presign_put_pinned` mints the
expected SHA-256 *into the grant*, where it is covered by the signature; the
store then recomputes and refuses on disagreement, and a later HEAD attests the
digest it holds. :meth:`ObjectHead.verify` is the one place that answer is read,
and it refuses two ways — a wrong digest and *no* digest are both failures,
because an unattested object is unverified, never verified.

The control plane never proxies bytes on the request path: it HEADs, presigns,
and returns. The streaming calls (``fetch_to_scratch``, ``download_to``,
``copy``) exist for workers, and each is bounded — a multi-gigabyte layer is
never fully resident.

Requires the ``storage`` extra.
"""

from __future__ import annotations

import base64
import binascii
import json
from collections.abc import Iterable, Iterator, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from types import MappingProxyType
from typing import IO, cast
from uuid import uuid4

from botocore.exceptions import BotoCoreError, ClientError
from sx_contracts.content import Sha256Digest
from sx_contracts.identity import stream_blob
from sx_contracts.secret import Secret

from sx_service._storage_interop import S3Client, StreamingBody, create_s3_client
from sx_service.buckets import ObjectRef, assert_deletable

#: Where deletion requests land, in every bucket. No code in this repository
#: deletes from R2 (standing order, 2026-08-17): an allowed request becomes a
#: JSON record under this prefix and a human performs the deletion.
DELETION_QUEUE_PREFIX = "deletion-requests/"

#: What R2 calls its one region. A store that names this one is telling the
#: client it has no location to constrain a bucket to.
R2_REGION = "auto"

#: The two regions a `CreateBucket` must *not* name. R2 has one region and
#: rejects any constraint; S3 treats `us-east-1` as the absence of one and
#: rejects it by name. Every other region must be stated, or the store refuses
#: a create sent to its region-specific endpoint. Not a preference — three
#: incompatible refusals, reconciled in the one place that creates a bucket.
_UNNAMEABLE_REGIONS = frozenset({R2_REGION, "us-east-1"})

#: Streaming granularity for the hashing copies. One MiB keeps a multi-GB object
#: off the heap while staying far above per-call overhead.
CHUNK_BYTES = 1 << 20

#: S3's part-number range. A part outside it is a caller bug, not a store answer.
MAX_PARTS = 10_000

#: What "the object is not there" looks like across R2, MinIO, and S3 proper.
_MISSING = ("404", "NoSuchKey", "NotFound")

#: The header a pinned upload must carry. The store recomputes the digest of the
#: bytes it receives and refuses the write on disagreement — proven against the
#: dev MinIO, which answers ``XAmzContentChecksumMismatch`` with a 400 and
#: creates no object. It is never a claim the store takes on trust.
CHECKSUM_HEADER = "x-amz-checksum-sha256"

#: The digest a multipart object reports is a checksum *of its parts' checksums*,
#: not of its bytes, and the store labels it so. Only a whole-object attestation
#: answers the question :meth:`ObjectHead.verify` asks.
_COMPOSITE = "COMPOSITE"


class ObjectStoreError(RuntimeError):
    """The object store refused, or answered in a way no caller can use."""


class ObjectStoreUnavailableError(ObjectStoreError):
    """The store could not be reached, or refused for a reason that is not absence."""


class ObjectIdentityError(ObjectStoreError):
    """The store omitted every immutable identity token for an object."""


class ContentUnattestedError(ObjectStoreError):
    """The store holds no whole-object SHA-256 for these bytes, so nothing is proven.

    Raised where a caller asked to have content *confirmed*: an object written
    through an unpinned grant, or by a path that sent no checksum, is exactly as
    unverified afterwards as it was before. This type exists so that absence can
    never be mistaken for agreement.
    """


class ContentMismatchError(ObjectStoreError):
    """The store's SHA-256 for these bytes is not the digest that was expected."""


class MultipartUploadError(ObjectStoreError):
    """The object store refused a multipart operation."""


class MultipartUploadMissingError(MultipartUploadError):
    """The object store no longer has the requested multipart session."""


@dataclass(frozen=True, slots=True)
class ObjectHead:
    """What a HEAD knows: how big, and which token pins this version of the bytes.

    ``version_id`` and ``etag`` are empty when the store omits them — an
    unversioned R2 bucket has no version id, and a store may withhold an ETag.
    That absence is resolved in exactly one place, :attr:`identity`, which is the
    only thing either token is for.

    ``attested_sha256`` is a different kind of absence and gets a different
    spelling. An identity token is a *label*: any of them will do, so an empty
    one can fall through to the next. A content attestation is a *proof*, and
    there is nothing to fall through to — most objects in this platform have
    none, because most were written without one. ``None`` says so, and
    :meth:`verify` is where it is resolved, always by refusing.
    """

    size_bytes: int
    etag: str
    version_id: str
    attested_sha256: Sha256Digest | None = None

    @property
    def identity(self) -> str:
        """The token a caller may pin to detect that the bytes have drifted."""
        if self.version_id:
            return f"version:{self.version_id}"
        if self.etag:
            return f"etag:{self.etag}"
        raise ObjectIdentityError("object store omitted an immutable object identity")

    def verify(self, expected: Sha256Digest) -> None:
        """Refuse unless the *store* says the bytes under this key hash to ``expected``.

        The store is the only witness to a presigned upload, so this is the whole
        point of asking it for a checksum: the digest compared here was computed
        by the store over the bytes it actually holds, never asserted by whoever
        sent them. A door that pinned a grant with :meth:`ObjectStore.presign_put_pinned`
        calls this afterwards with the same digest it minted in.

        Both failures raise, and neither is silent: no attestation is
        :class:`ContentUnattestedError`, a disagreeing one is
        :class:`ContentMismatchError`.
        """
        if self.attested_sha256 is None:
            raise ContentUnattestedError(
                "object store holds no whole-object SHA-256 for these bytes: "
                "the content is unverified, not verified"
            )
        if self.attested_sha256 != expected:
            raise ContentMismatchError(
                f"object store attests sha256 {self.attested_sha256}, expected {expected}"
            )


@dataclass(frozen=True, slots=True)
class ObjectInfo:
    """One listed object: where it is, which version, and when it last changed."""

    ref: ObjectRef
    etag: str
    last_modified: datetime


@dataclass(frozen=True, slots=True)
class FetchedObject:
    """A source object hydrated to local scratch, with its content identity."""

    path: Path
    sha256: Sha256Digest
    size_bytes: int


@dataclass(frozen=True, slots=True)
class PinnedUpload:
    """A grant to write one *known* blob: the URL, and the headers it demands.

    A plain presigned PUT is a bare ``str`` because a URL is all there is to say
    — any bytes may go through it, any number of times. This one is a value
    instead, because the grant is not complete without its headers: the digest is
    inside the signature, so an upload that omits the header is refused by the
    store (a 400, no object created) rather than quietly landing unpinned. A
    door hands both to its client, together.
    """

    url: str
    headers: Mapping[str, str]


@dataclass(frozen=True, slots=True)
class CompletedPart:
    """One part receipt returned by a successful presigned multipart PUT."""

    part_number: int
    etag: str

    def __post_init__(self) -> None:
        if not 1 <= self.part_number <= MAX_PARTS:
            raise ValueError(f"multipart part_number must be between 1 and {MAX_PARTS}")
        if not self.etag:
            raise ValueError("multipart ETag must be non-empty")


@dataclass(frozen=True, slots=True)
class ObjectStoreConfig:
    """Where the store is, who this service is to it, and which bucket it owns.

    ``endpoint`` is where this process performs store operations. A presigned
    URL is consumed by somebody else, so ``presign_endpoint`` may name the same
    store at an address an HTTP client can reach. When it is absent,
    :attr:`ObjectStore.client_grants` uses ``endpoint`` and the original
    single-address behavior is preserved. Ordinary ``presign_*`` calls always
    use the internal endpoint for machine recipients on the service network.

    A service's settings object holds a hundred facts and the store takes only
    the storage facts it needs: the client can no more read a database DSN than
    a feature flag. The service parses these from its own environment — this kit
    never does.
    """

    endpoint: str
    access_key: str
    secret_key: Secret
    bucket: str
    presign_ttl_s: int
    presign_endpoint: str | None = None
    region: str = R2_REGION
    """Which region this store speaks, defaulting to the one R2 has.

    R2 is single-region and names it `"auto"`; it refuses a location constraint.
    Every other S3 implementation — MinIO, moto, S3 — refuses a *bucket create*
    that does not carry one when the client is not pointed at `us-east-1`. So the
    region is a fact about the store, parsed by the service that owns it, and the
    two behaviours differ in exactly one place: `ensure_bucket`.
    """


class ObjectGrants:
    """The bounded object-store authority minted for one recipient network."""

    def __init__(self, config: ObjectStoreConfig, client: S3Client) -> None:
        self._config = config
        self._client = client

    def presign_get(self, ref: ObjectRef) -> str:
        """A time-boxed download URL — the recipient fetches the bytes directly."""
        return self._client.generate_presigned_url(
            "get_object",
            Params={"Bucket": ref.bucket, "Key": ref.key},
            ExpiresIn=self._config.presign_ttl_s,
        )

    def presign_put(self, key: str) -> str:
        """A time-boxed open upload grant into the store's home bucket."""
        return self._client.generate_presigned_url(
            "put_object",
            Params={"Bucket": self._config.bucket, "Key": key},
            ExpiresIn=self._config.presign_ttl_s,
        )

    def presign_put_pinned(self, key: str, sha256: Sha256Digest) -> PinnedUpload:
        """A time-boxed upload grant whose signature pins the expected content."""
        encoded = base64.b64encode(bytes.fromhex(sha256)).decode()
        url = self._client.generate_presigned_url(
            "put_object",
            Params={"Bucket": self._config.bucket, "Key": key, "ChecksumSHA256": encoded},
            ExpiresIn=self._config.presign_ttl_s,
        )
        return PinnedUpload(url=url, headers=MappingProxyType({CHECKSUM_HEADER: encoded}))

    def presign_upload_part(self, key: str, upload_id: str, part_number: int) -> str:
        """A time-boxed URL for one part of an open multipart session."""
        if not 1 <= part_number <= MAX_PARTS:
            raise ValueError(f"multipart part_number must be between 1 and {MAX_PARTS}")
        try:
            return self._client.generate_presigned_url(
                "upload_part",
                Params={
                    "Bucket": self._config.bucket,
                    "Key": key,
                    "UploadId": upload_id,
                    "PartNumber": part_number,
                },
                ExpiresIn=self._config.presign_ttl_s,
            )
        except ClientError as error:
            raise MultipartUploadError("object store refused multipart part grant") from error


class ObjectStore:
    """Every object-store call the platform makes, bound to one home bucket."""

    def __init__(self, config: ObjectStoreConfig) -> None:
        self._config = config
        self._client: S3Client = create_s3_client(
            endpoint=config.endpoint,
            access_key=config.access_key,
            secret_key=config.secret_key.reveal(),
            region=config.region,
        )
        self._internal_grants = ObjectGrants(config, self._client)
        self._client_grants = self._internal_grants
        if config.presign_endpoint is not None and config.presign_endpoint != config.endpoint:
            self._client_grants = ObjectGrants(
                config,
                create_s3_client(
                    endpoint=config.presign_endpoint,
                    access_key=config.access_key,
                    secret_key=config.secret_key.reveal(),
                    region=config.region,
                ),
            )

    @property
    def bucket(self) -> str:
        """The one bucket this service owns and may write to."""
        return self._config.bucket

    @property
    def client_grants(self) -> ObjectGrants:
        """Grants signed for HTTP clients on the configured recipient network."""
        return self._client_grants

    def ref(self, key: str) -> ObjectRef:
        """Address a key in the home bucket."""
        return ObjectRef(self._config.bucket, key)

    # ── reads: any bucket this credential can reach ──────────────────────────

    def head(self, ref: ObjectRef) -> ObjectHead | None:
        """The object's facts, ``None`` when it is simply not there — or a refusal.

        Absent and unreachable are different answers, and a door that admits a
        source object has to tell them apart: the first is a 404 it may explain,
        the second a 503 it must retry. So this is the one read that translates
        the SDK's failure into :class:`ObjectStoreUnavailableError` rather than
        letting a botocore exception reach a caller.

        ``ChecksumMode`` is always enabled, because a HEAD without it returns no
        checksum at all — not even for an object that has one. There is no second
        head surface for callers who want the attestation; asking is free, and a
        store that ignores the mode simply answers as it always did.
        """
        try:
            response = self._client.head_object(
                Bucket=ref.bucket, Key=ref.key, ChecksumMode="ENABLED"
            )
        except ClientError as error:
            if _client_error_code(error) in _MISSING:
                return None
            raise ObjectStoreUnavailableError(f"object store refused HEAD {ref.key!r}") from error
        except BotoCoreError as error:
            raise ObjectStoreUnavailableError(f"object store refused HEAD {ref.key!r}") from error
        size = response.get("ContentLength")
        if isinstance(size, bool) or not isinstance(size, int):
            raise ObjectStoreError("object store returned an invalid content length")
        return ObjectHead(
            size_bytes=size,
            etag=str(response.get("ETag", "")).strip('"'),
            version_id=str(response.get("VersionId", "")),
            attested_sha256=_attested_sha256(response),
        )

    def presign_get(self, ref: ObjectRef) -> str:
        """A time-boxed download URL — the client fetches the bytes, not this process."""
        return self._internal_grants.presign_get(ref)

    def get_bytes(self, ref: ObjectRef) -> bytes:
        """Read one small object into memory (a report, a manifest, a snapshot part)."""
        response = self._client.get_object(Bucket=ref.bucket, Key=ref.key)
        return cast("StreamingBody", response["Body"]).read()

    def download_to(self, ref: ObjectRef, path: Path) -> None:
        """Stream one object to a local file (bounded memory, for large layers)."""
        self._client.download_file(ref.bucket, ref.key, str(path))

    def fetch_to_scratch(self, source: ObjectRef | Path, scratch_dir: Path) -> FetchedObject:
        """Hydrate a source object into local scratch, hashing as it lands.

        A local path is admitted so the same call serves a file:// registration;
        either way the bytes stream, and the landed file is named by the content
        identity only it can prove.
        """
        scratch_dir.mkdir(parents=True, exist_ok=True)
        if isinstance(source, Path):
            with source.open("rb") as stream:
                return _land(iter(lambda: stream.read(CHUNK_BYTES), b""), scratch_dir)
        response = self._client.get_object(Bucket=source.bucket, Key=source.key)
        body = cast("StreamingBody", response["Body"])
        return _land(body.iter_chunks(chunk_size=CHUNK_BYTES), scratch_dir)

    def list_objects(self, prefix: str) -> Iterator[ObjectInfo]:
        """Every object under a prefix of the home bucket, oldest page first."""
        paginator = self._client.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=self._config.bucket, Prefix=prefix):
            contents = page.get("Contents", [])
            if not isinstance(contents, list):
                raise ObjectStoreError("object store returned malformed listing contents")
            for value in cast("list[object]", contents):
                if not isinstance(value, dict):
                    raise ObjectStoreError("object store returned a malformed listed object")
                obj = cast("dict[str, object]", value)
                key = obj.get("Key")
                modified = obj.get("LastModified")
                if not isinstance(key, str) or not isinstance(modified, datetime):
                    raise ObjectStoreError("object store returned an incomplete listed object")
                yield ObjectInfo(
                    ref=self.ref(key),
                    etag=str(obj.get("ETag", "")).strip('"'),
                    last_modified=modified,
                )

    # ── writes: the home bucket, always ──────────────────────────────────────

    def presign_put(self, key: str) -> str:
        """A time-boxed upload URL — the client sends the bytes, not this process.

        An *open* grant: it says where the bytes may go, never which bytes. Any
        content is accepted, and the same URL may be spent again until it
        expires. Use :meth:`presign_put_pinned` wherever the door already knows
        the digest it is expecting — enforcement exists only when it is minted in.
        """
        return self._internal_grants.presign_put(key)

    def presign_put_pinned(self, key: str, sha256: Sha256Digest) -> PinnedUpload:
        """A time-boxed upload grant for *these bytes and no others*.

        The expected digest is minted into the grant, where the signature covers
        it: the client cannot substitute a digest of its own (the store answers
        ``SignatureDoesNotMatch``), cannot drop the header (``AccessDenied``),
        and cannot send bytes that hash to anything else — the store recomputes
        and refuses with ``XAmzContentChecksumMismatch``, creating no object. So
        a 200 through this grant means the store agrees, and a later
        :meth:`ObjectHead.verify` reads that agreement back.

        This is a separate call rather than an argument on :meth:`presign_put`
        because it is a different promise, and it returns a different thing: a
        URL alone would be an incomplete grant, and every upload through it
        would fail.
        """
        return self._internal_grants.presign_put_pinned(key, sha256)

    def put_file(self, path: Path, key: str) -> None:
        """Idempotent write: content identity is in the key, so an existing key is done."""
        if self.head(self.ref(key)) is not None:
            return
        self._client.upload_file(str(path), self._config.bucket, key)

    def put_file_replace(self, path: Path, key: str) -> None:
        """Overwriting write, for keys whose content legitimately changes.

        A compacted partition accrues rows as its month does. Content-addressed
        keys never use this — for those, an overwrite would be a contradiction.
        """
        self._client.upload_file(str(path), self._config.bucket, key)

    def copy(self, source: ObjectRef, dest_key: str) -> None:
        """Server-side copy into the home bucket — no bytes transit this process."""
        self._client.copy_object(
            Bucket=self._config.bucket,
            Key=dest_key,
            CopySource={"Bucket": source.bucket, "Key": source.key},
        )

    def request_deletion(self, key: str) -> None:
        """THE deletion choke point — and it never deletes.

        Standing order (2026-08-17): no code in this repository deletes from
        R2; every deletion is human work. The registry still decides first —
        a key whose retention class forbids deletion may not even be queued —
        and what an allowed request produces is a durable record under
        :data:`DELETION_QUEUE_PREFIX` in the home bucket, for a human to
        review and act on. The bytes under ``key`` remain untouched.
        """
        assert_deletable(self.ref(key))
        record = {
            "bucket": self._config.bucket,
            "key": key,
            "requested_at": datetime.now(UTC).isoformat(),
        }
        # Deterministic per object: a sweeper re-requesting the same key
        # refreshes one record instead of accreting duplicates.
        digest = stream_blob(iter([key.encode()])).sha256
        queue_key = f"{DELETION_QUEUE_PREFIX}{digest}.json"
        self._client.put_object(
            Bucket=self._config.bucket,
            Key=queue_key,
            Body=json.dumps(record).encode(),
            ContentType="application/json",
        )

    def ensure_bucket(self) -> None:
        """Dev/MinIO convenience; R2 buckets are provisioned out-of-band.

        The location constraint is sent exactly when the region can be named —
        see `_UNNAMEABLE_REGIONS`, which is where three stores' incompatible
        refusals are reconciled.
        """
        try:
            self._client.head_bucket(Bucket=self._config.bucket)
        except ClientError:
            if self._config.region in _UNNAMEABLE_REGIONS:
                self._client.create_bucket(Bucket=self._config.bucket)
            else:
                self._client.create_bucket(
                    Bucket=self._config.bucket,
                    CreateBucketConfiguration={"LocationConstraint": self._config.region},
                )

    # ── multipart: a staged write to the home bucket, presigned part by part ──

    def begin_multipart_upload(self, key: str) -> str:
        """Open a multipart session and return the store's identity for it."""
        try:
            response = self._client.create_multipart_upload(Bucket=self._config.bucket, Key=key)
        except ClientError as error:
            raise MultipartUploadError("object store refused multipart begin") from error
        upload_id = response.get("UploadId")
        if not isinstance(upload_id, str) or not upload_id:
            raise MultipartUploadError("object store returned no multipart upload identity")
        return upload_id

    def presign_upload_part(self, key: str, upload_id: str, part_number: int) -> str:
        """A time-boxed URL for one part of an open session."""
        return self._internal_grants.presign_upload_part(key, upload_id, part_number)

    def complete_multipart_upload(
        self, key: str, upload_id: str, parts: tuple[CompletedPart, ...]
    ) -> None:
        """Seal the session; the parts become the object."""
        try:
            self._client.complete_multipart_upload(
                Bucket=self._config.bucket,
                Key=key,
                UploadId=upload_id,
                MultipartUpload={
                    "Parts": [{"PartNumber": p.part_number, "ETag": p.etag} for p in parts]
                },
            )
        except ClientError as error:
            if _client_error_code(error) == "NoSuchUpload":
                raise MultipartUploadMissingError(
                    "object store multipart session no longer exists"
                ) from error
            raise MultipartUploadError("object store refused multipart completion") from error

    def abort_multipart_upload(self, key: str, upload_id: str) -> None:
        """Discard the session and its staged parts."""
        try:
            self._client.abort_multipart_upload(
                Bucket=self._config.bucket, Key=key, UploadId=upload_id
            )
        except ClientError as error:
            if _client_error_code(error) == "NoSuchUpload":
                raise MultipartUploadMissingError(
                    "object store multipart session no longer exists"
                ) from error
            raise MultipartUploadError("object store refused multipart abort") from error
        except BotoCoreError as error:
            raise MultipartUploadError("object store refused multipart abort") from error


def _attested_sha256(response: Mapping[str, object]) -> Sha256Digest | None:
    """The store's whole-object SHA-256, or ``None`` when it attests to nothing.

    Three answers collapse to ``None``, and they collapse deliberately: a store
    that returned no checksum, a store that returned a *composite* one, and a
    store that returned something unreadable. Only the first is ordinary — most
    objects here predate pinning — but all three mean the same thing to the
    caller, because :meth:`ObjectHead.verify` refuses on all three alike. There
    is no arrangement of a bad answer that yields a passing comparison.

    The composite case is the one worth naming. A multipart object reports a
    digest of its parts' digests, suffixed ``-N``; it is a real checksum of the
    wrong thing, and reading it as content identity would be a silent lie. The
    store labels it, and the 32-byte length check catches it even where the
    label is missing.
    """
    raw = response.get("ChecksumSHA256")
    if not isinstance(raw, str) or not raw:
        return None
    if str(response.get("ChecksumType", "")).upper() == _COMPOSITE:
        return None
    try:
        digest = base64.b64decode(raw, validate=True)
    except (binascii.Error, ValueError):
        return None
    if len(digest) != 32:
        return None
    return Sha256Digest(digest.hex())


def _client_error_code(error: ClientError) -> str | None:
    response = cast("Mapping[str, object]", error.response)
    detail = response.get("Error")
    if not isinstance(detail, dict):
        return None
    code = cast("dict[object, object]", detail).get("Code")
    return code if isinstance(code, str) else None


def _written(chunks: Iterable[bytes], out: IO[bytes]) -> Iterator[bytes]:
    """Yield each chunk once it is on disk, so landing and hashing share one pass."""
    for chunk in chunks:
        out.write(chunk)
        yield chunk


def _land(chunks: Iterable[bytes], scratch_dir: Path) -> FetchedObject:
    """Write a byte stream to scratch under a unique name, then rename to its digest."""
    staging = scratch_dir / f"fetch-{uuid4().hex}"
    with staging.open("wb") as out:
        blob = stream_blob(_written(chunks, out))
    landed = scratch_dir / blob.sha256[:16]
    staging.replace(landed)
    return FetchedObject(path=landed, sha256=blob.sha256, size_bytes=blob.size_bytes)
