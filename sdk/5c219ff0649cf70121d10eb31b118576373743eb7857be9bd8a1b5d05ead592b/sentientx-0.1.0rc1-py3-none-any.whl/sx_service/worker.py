"""One way to run a Temporal worker, so a worker cannot be run wrong.

Every long-lived worker in the stack had written the same bootstrap: configure
logging, connect a client, remember the data converter, size an activity thread
pool, build the ``Worker``, and run it beside whatever sidecar the service needs.
One of those is silently fatal when forgotten. Temporal's default converter
rebuilds a ``str`` subclass by *iterating* it, so a ``Sha256Digest`` field arrives
as a list of one-character strings with its constructor never run — the invariant
is not checked, nothing raises, and the damage is downstream. The converter is
not an option this module offers; it is what this module is for.

``run_worker`` is the whole process: it returns when the worker and its sidecars
stop, and a sidecar that raises takes the worker down with it rather than leaving
a half-running process that a health check would call alive.

Requires the ``worker`` extra.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Coroutine, Sequence
from concurrent.futures import ThreadPoolExecutor
from typing import Any, TypeAlias

from temporalio.client import Client
from temporalio.worker import Worker, WorkflowRunner

from sx_service.logging import configure_logging, get_logger
from sx_service.observability import init_observability
from sx_service.temporal import connect_temporal

#: A coroutine that runs beside the worker for the process's lifetime, given the
#: connected client — the catalog's workflow relay is the shape this exists for.
Sidecar: TypeAlias = Callable[[Client], Coroutine[Any, Any, None]]

_log = get_logger(__name__)


async def run_worker(
    service: str,
    *,
    task_queue: str,
    address: str,
    namespace: str,
    workflows: Sequence[type[Any]],
    activities: Sequence[Callable[..., Any]],
    activity_slots: int = 4,
    workflow_runner: WorkflowRunner | None = None,
    sidecars: Sequence[Sidecar] = (),
) -> None:
    """Run ``service``'s worker on ``task_queue`` until it stops.

    ``service`` is the name every record this process emits carries; a task queue
    is unique to one worker fleet, so the two together identify the process in
    logs without either being guessed.

    ``activity_slots`` is the one concurrency fact a worker states: how many
    activities may run at once. It sizes the sync-activity thread pool and the
    Temporal admission ceiling together, because two numbers that must agree are
    one number. The default suits a control-plane worker; a GPU trainer says 1
    (one process, one job), a submit-and-await fan-out says its fleet's slot
    count.

    ``workflow_runner`` is Temporal's sandbox policy, passed through untouched
    (``None`` = Temporal's default sandbox). The campaign worker exists for this:
    its payload dataclasses must keep one class identity across the sandbox
    boundary, so it passes a runner with its own module marked pass-through.
    """
    observability = init_observability(service)
    configure_logging(
        service=service,
        release=observability.config.release,
        environment=observability.config.environment,
        force=True,
    )
    client = await connect_temporal(
        address,
        namespace=namespace,
    )
    _log.info(
        "worker.started",
        task_queue=task_queue,
        temporal=address,
        namespace=namespace,
        workflows=len(workflows),
        activities=len(activities),
        activity_slots=activity_slots,
    )
    runner_kwargs: dict[str, Any] = (
        {} if workflow_runner is None else {"workflow_runner": workflow_runner}
    )
    with ThreadPoolExecutor(max_workers=activity_slots) as executor:
        worker = Worker(
            client,
            task_queue=task_queue,
            workflows=list(workflows),
            activities=list(activities),
            activity_executor=executor,
            max_concurrent_activities=activity_slots,
            **runner_kwargs,
        )
        async with asyncio.TaskGroup() as tasks:
            for sidecar in sidecars:
                tasks.create_task(sidecar(client))
            tasks.create_task(worker.run())
