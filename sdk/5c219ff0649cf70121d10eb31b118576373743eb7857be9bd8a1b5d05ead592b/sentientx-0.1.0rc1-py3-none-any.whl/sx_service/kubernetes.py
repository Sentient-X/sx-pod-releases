"""The in-cluster Kubernetes API, for a service that owns a few cluster resources.

Two owners need it: WorkspaceJob supervision (Jobs, NetworkPolicies, and the Lease
fences behind the provider proxy) and the Factory's pod-route reconciler (one
ExternalName Service per capture pod). Each needs four verbs on one resource in
one namespace, so the client is the projected ServiceAccount token, the cluster
CA, and JSON over ``urllib`` — no kubeconfig, no exec plugin, no client library,
which would be the largest dependency in either process.

A server answer is a :class:`KubernetesResponse` whatever its status: a 409 or a
404 is the resource's state, and the owner decides what it means. Only a request
that never completed — no token, a transport failure, a payload the budget or
the JSON parser refuses — raises :class:`KubernetesApiError`.
"""

from __future__ import annotations

import json
import ssl
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

_RESPONSE_BUDGET = 2 * 1024 * 1024


class KubernetesApiError(RuntimeError):
    """The request did not complete, so nothing is known about the resource's state."""


@dataclass(frozen=True, slots=True)
class KubernetesResponse:
    status: int
    document: object


class KubernetesApi(Protocol):
    def request(
        self, method: str, path: str, document: Mapping[str, object] | None = None
    ) -> KubernetesResponse: ...


@dataclass(frozen=True, slots=True)
class InClusterKubernetesApi:
    """The API as seen from a pod with a projected ServiceAccount token."""

    server: str = "https://kubernetes.default.svc"
    token_path: Path = Path("/var/run/secrets/kubernetes.io/serviceaccount/token")
    ca_path: Path = Path("/var/run/secrets/kubernetes.io/serviceaccount/ca.crt")
    timeout_seconds: float = 15.0

    def namespace(self) -> str:
        """The namespace this process runs in, projected beside its token."""
        try:
            namespace = self.token_path.with_name("namespace").read_text(encoding="utf-8").strip()
        except OSError as error:
            raise KubernetesApiError("Kubernetes namespace projection is unavailable") from error
        if not namespace:
            raise KubernetesApiError("Kubernetes namespace projection is empty")
        return namespace

    def request(
        self, method: str, path: str, document: Mapping[str, object] | None = None
    ) -> KubernetesResponse:
        if not path.startswith("/") or ".." in path.split("/"):
            raise KubernetesApiError("Kubernetes API path is not normalized")
        try:
            token = self.token_path.read_text(encoding="utf-8").strip()
        except OSError as error:
            raise KubernetesApiError("Kubernetes ServiceAccount token is unavailable") from error
        if not token:
            raise KubernetesApiError("Kubernetes ServiceAccount token is empty")
        body = (
            None
            if document is None
            else json.dumps(document, separators=(",", ":"), sort_keys=True).encode()
        )
        request = Request(
            self.server.rstrip("/") + path,
            data=body,
            method=method,
            headers={
                "Accept": "application/json",
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
        )
        context = ssl.create_default_context(cafile=str(self.ca_path))
        try:
            with urlopen(request, timeout=self.timeout_seconds, context=context) as response:
                payload = response.read(_RESPONSE_BUDGET + 1)
                status = response.status
        except HTTPError as error:
            payload = error.read(_RESPONSE_BUDGET + 1)
            status = error.code
        except (URLError, TimeoutError, OSError) as error:
            raise KubernetesApiError("Kubernetes API request failed closed") from error
        if len(payload) > _RESPONSE_BUDGET:
            raise KubernetesApiError("Kubernetes API response exceeded its budget")
        if not payload:
            return KubernetesResponse(status, {})
        try:
            return KubernetesResponse(status, json.loads(payload))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise KubernetesApiError("Kubernetes API response is malformed") from error
