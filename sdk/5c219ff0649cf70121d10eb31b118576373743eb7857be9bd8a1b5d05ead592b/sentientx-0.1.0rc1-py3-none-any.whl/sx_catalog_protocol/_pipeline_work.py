"""The partition-lease wire: what a worker offers, holds, produces, and loses.

Four values cross this boundary in both directions, and one crosses outward
only. The offer, the lease, the receipt and the failure are what a worker and
the catalog say to each other, so each has a transform in each direction. A
shortfall only ever travels outward — it is derived from the stored offer and
the admitted plan at read time, and nothing parses one back.

`sx_contracts.pipelines` owns every one of these as a real domain value whose
`__post_init__` proves its law, so a transform here refuses exactly what that
constructor refuses and adds nothing of its own.

**The stored rendering is not this one, deliberately.** `capacity_document` is
how a refused offer is digested and kept in `pipeline_capacity_refusals`; it is
a durable encoding and it stays. This is the wire, and neither is derived from
the other — deriving one would make a stored digest depend on which encoding
produced it.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Final
from uuid import UUID

from sentientx.sx.experience.catalog.v1 import pipeline_work_pb2
from sentientx.sx.operations.v1 import operations_pb2
from sx_contracts import OperationFailure, Sha256Digest
from sx_contracts.pipelines import (
    AcceleratorCapacity,
    Capacity,
    GraphError,
    LeasedObject,
    PartitionFailed,
    ProducedMember,
    Resource,
    Scarcity,
    Shortfall,
    WorkLease,
)
from sx_contracts.schemas import SchemaId

from sx_catalog_protocol._core import ProtocolTransformError

STALE_PARTITION_LEASE: Final[str] = "stale_partition_lease"
"""The `RefusalDetail.code` a fenced-out holder is answered with, and only it.

One spelling, read by the owner that writes it and by the executor that acts on
it. It is a code rather than a status because the four fenced verbs refuse for
more than one reason — a member can be absent, too large, unproven, or not the
contract the plan admitted — and a holder that read every conflict as "somebody
took my work" would drop a real rejection on the floor.
"""

_SCARCITIES: Mapping[Scarcity, pipeline_work_pb2.Scarcity] = {
    Scarcity.CPUS: pipeline_work_pb2.SCARCITY_CPUS,
    Scarcity.MEMORY_MIB: pipeline_work_pb2.SCARCITY_MEMORY_MIB,
    Scarcity.SCRATCH_MIB: pipeline_work_pb2.SCARCITY_SCRATCH_MIB,
    Scarcity.ACCELERATOR: pipeline_work_pb2.SCARCITY_ACCELERATOR,
    Scarcity.ACCELERATOR_MEMORY_MIB: pipeline_work_pb2.SCARCITY_ACCELERATOR_MEMORY_MIB,
    Scarcity.CUSTOM: pipeline_work_pb2.SCARCITY_CUSTOM,
}


# --- what a worker can supply -----------------------------------------------


def worker_capacity_to_proto(value: Capacity) -> pipeline_work_pb2.WorkerCapacity:
    """One offer, field for field with the resources a step declares."""

    return pipeline_work_pb2.WorkerCapacity(
        cpus=value.cpus,
        memory_mib=value.memory_mib,
        scratch_mib=value.scratch_mib,
        accelerators=[
            pipeline_work_pb2.OfferedAccelerator(
                kind=item.kind,
                ray_resource=item.ray_resource,
                count=item.count,
                memory_mib=item.memory_mib,
                runtime_abi=item.runtime_abi,
            )
            for item in value.accelerators
        ],
        custom=[
            pipeline_work_pb2.OfferedResource(name=item.name, amount=item.amount)
            for item in value.custom
        ],
    )


def worker_capacity_from_proto(value: pipeline_work_pb2.WorkerCapacity) -> Capacity:
    """Parse one offer, refusing everything the domain value refuses.

    Its own constructor is the check — a duplicate accelerator class, a
    non-identifier resource name, a non-positive amount — so nothing is
    re-stated here and nothing can be admitted that the scheduler would then
    have to interpret.
    """

    try:
        return Capacity(
            cpus=value.cpus,
            memory_mib=value.memory_mib,
            scratch_mib=value.scratch_mib,
            accelerators=tuple(
                AcceleratorCapacity(
                    kind=item.kind,
                    ray_resource=item.ray_resource,
                    count=item.count,
                    memory_mib=item.memory_mib,
                    runtime_abi=item.runtime_abi,
                )
                for item in value.accelerators
            ),
            custom=tuple(Resource(item.name, item.amount) for item in value.custom),
        )
    except GraphError as error:
        raise ProtocolTransformError(f"malformed worker capacity: {error}") from error


# --- what a shortfall is ----------------------------------------------------


def shortfall_to_proto(value: Shortfall) -> pipeline_work_pb2.Shortfall:
    """One deficit, in the axis's own words. Outward only: nothing parses one back."""

    return pipeline_work_pb2.Shortfall(
        scarcity=_SCARCITIES[value.scarcity],
        name=value.name,
        needed=value.needed,
        offered=value.offered,
    )


# --- the lease --------------------------------------------------------------


def partition_lease_to_proto(value: WorkLease) -> pipeline_work_pb2.PartitionLease:
    """Scheduling ownership and execution capability as one message.

    The run and the project it names are deliberately absent: the request this
    answers already carries the run, and the credential already resolved the
    project, so putting either here would be one fact with two spellings.
    """

    lease = pipeline_work_pb2.PartitionLease(
        plan_digest=str(value.plan_digest),
        ordinal=value.ordinal,
        generation=value.generation,
        attempt=value.attempt,
        inputs=[
            pipeline_work_pb2.LeasedObject(
                input_name=item.input_name,
                schema_id=str(item.schema),
                sha256=str(item.sha256),
                size_bytes=item.size_bytes,
                url=item.url,
            )
            for item in value.inputs
        ],
        output_url=value.output_url,
        output_max_bytes=value.output_max_bytes,
        report_url=value.report_url,
    )
    lease.expires_at.FromDatetime(_utc(value.expires_at))
    return lease


def partition_lease_from_proto(
    value: pipeline_work_pb2.PartitionLease, *, run_id: UUID, project_id: UUID
) -> WorkLease:
    """Rebuild the lease this worker now holds, under the identity it asked with.

    `run_id` and `project_id` come from the call rather than from the message on
    purpose. They are what the caller named and what its credential resolved to,
    so a lease that could restate them would be a value able to disagree with the
    request that produced it.
    """

    try:
        return WorkLease(
            run_id=run_id,
            project_id=project_id,
            plan_digest=Sha256Digest(value.plan_digest),
            ordinal=value.ordinal,
            generation=value.generation,
            attempt=value.attempt,
            inputs=tuple(
                LeasedObject(
                    input_name=item.input_name,
                    schema=SchemaId(item.schema_id),
                    sha256=Sha256Digest(item.sha256),
                    size_bytes=item.size_bytes,
                    url=item.url,
                )
                for item in value.inputs
            ),
            output_url=value.output_url,
            output_max_bytes=value.output_max_bytes,
            report_url=value.report_url,
            expires_at=value.expires_at.ToDatetime(tzinfo=UTC),
        )
    except (GraphError, ValueError) as error:
        raise ProtocolTransformError(f"malformed partition lease: {error}") from error


# --- what a partition produced ----------------------------------------------


def produced_member_to_proto(value: ProducedMember) -> pipeline_work_pb2.ProducedMember:
    """Identity, the procedure that ran, and the verdict it emitted. Nothing else."""

    return pipeline_work_pb2.ProducedMember(
        ordinal=value.ordinal,
        generation=value.generation,
        sha256=str(value.sha256),
        size_bytes=value.size_bytes,
        validator_digest=str(value.validator_digest),
        report_sha256=str(value.report_sha256),
    )


def produced_member_from_proto(value: pipeline_work_pb2.ProducedMember) -> ProducedMember:
    """Parse one receipt. Every claim in it is re-derived by the owner afterwards."""

    try:
        return ProducedMember(
            ordinal=value.ordinal,
            generation=value.generation,
            sha256=Sha256Digest(value.sha256),
            size_bytes=value.size_bytes,
            validator_digest=Sha256Digest(value.validator_digest),
            report_sha256=Sha256Digest(value.report_sha256),
        )
    except (GraphError, ValueError) as error:
        raise ProtocolTransformError(f"malformed produced member: {error}") from error


# --- how a partition ended without one --------------------------------------


def partition_failure_to_proto(value: PartitionFailed) -> pipeline_work_pb2.PartitionFailure:
    """The platform's own operation failure, under the fence that says whose it is."""

    return pipeline_work_pb2.PartitionFailure(
        ordinal=value.ordinal,
        generation=value.generation,
        failure=operations_pb2.OperationFailure(
            code=value.failure.code,
            message=value.failure.message,
            retryable=value.failure.retryable,
        ),
    )


def partition_failure_from_proto(value: pipeline_work_pb2.PartitionFailure) -> PartitionFailed:
    """Parse one ending, refusing an identity the partition vocabulary does not admit."""

    try:
        return PartitionFailed(
            ordinal=value.ordinal,
            generation=value.generation,
            failure=OperationFailure(
                value.failure.code, value.failure.message, value.failure.retryable
            ),
        )
    except (GraphError, ValueError) as error:
        raise ProtocolTransformError(f"malformed partition failure: {error}") from error


def _utc(value: datetime) -> datetime:
    return value if value.tzinfo is not None else value.replace(tzinfo=UTC)
