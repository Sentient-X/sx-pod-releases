"""Embodiment, composable-part, and assembly-definition protocol transforms."""

from __future__ import annotations

from collections.abc import Mapping
from typing import cast

from sentientx.sx.experience.catalog.v1 import catalog_pb2
from sx_embodiments import Embodiment, EmbodimentError
from sx_embodiments.assemble import ComposablePart, part_from_dict
from sx_embodiments.compose import BodyAttachment, LeaderAttachment, RootMount
from sx_embodiments.layout import Bounds, JointLayout
from sx_embodiments.parts import (
    ArmSpec,
    CameraSpec,
    ForceTorqueSpec,
    GripperSpec,
    JointGroupSpec,
    MobileBaseSpec,
    Part,
    PhysicalSpec,
)

from sx_catalog_protocol._assets import (
    asset_document,
    asset_from_dict,
    asset_from_proto,
    asset_to_proto,
)
from sx_catalog_protocol._core import (
    ProtocolTransformError,
    enum_from_proto,
    enum_to_proto,
    exact,
    mapping,
    number,
    sequence,
    text,
)


def _physical_to_proto(value: PhysicalSpec | None) -> catalog_pb2.PhysicalSpec | None:
    if value is None:
        return None
    result = catalog_pb2.PhysicalSpec()
    if value.payload_kg is not None:
        result.payload_kg = value.payload_kg
    if value.reach_m is not None:
        result.reach_m = value.reach_m
    if value.mass_kg is not None:
        result.mass_kg = value.mass_kg
    return result


def _layout_to_proto(value: JointLayout) -> catalog_pb2.JointLayout:
    axes = value.axes
    result = catalog_pb2.JointLayout()
    for axis in axes:
        row = result.axes.add(
            name=axis.name,
            unit=enum_to_proto(
                catalog_pb2.CoordinateUnit,
                "COORDINATE_UNIT_",
                {
                    "rad": "radian",
                    "m": "meter",
                    "rad/s": "radians_per_second",
                    "m/s": "meters_per_second",
                    "N*m": "newton_meter",
                    "unitless": "unitless",
                }[axis.unit.value],
            ),
        )
        if isinstance(axis.bounds, Bounds):
            row.bounds.bounded.lower = axis.bounds.lower
            row.bounds.bounded.upper = axis.bounds.upper
        else:
            row.bounds.unbounded.SetInParent()
        if axis.actuator is not None:
            binding = axis.actuator
            row.actuator.CopyFrom(
                catalog_pb2.ActuatorBinding(
                    model=enum_to_proto(
                        catalog_pb2.ActuatorModel,
                        "ACTUATOR_MODEL_",
                        binding.model.value,
                    ),
                    bus=enum_to_proto(
                        catalog_pb2.ActuatorBus,
                        "ACTUATOR_BUS_",
                        binding.bus.value,
                    ),
                    bus_id=binding.bus_id,
                    direction=(
                        "ACTUATOR_DIRECTION_FORWARD"
                        if binding.sign == 1
                        else "ACTUATOR_DIRECTION_REVERSED"
                    ),
                    zero_offset=binding.zero_offset,
                    reduction=binding.reduction,
                )
            )
    return result


def _part_to_proto(value: Part) -> catalog_pb2.Part:
    result = catalog_pb2.Part(part_id=str(value.part_id))
    if isinstance(value, ArmSpec):
        result.arm.layout.CopyFrom(_layout_to_proto(value.layout))
        result.arm.home.values.extend(value.home)
        if value.ready is not None:
            result.arm.ready.values.extend(value.ready)
        physical = _physical_to_proto(value.physical)
        if physical is not None:
            result.arm.physical.CopyFrom(physical)
        return result
    if isinstance(value, JointGroupSpec):
        result.joint_group.layout.CopyFrom(_layout_to_proto(value.layout))
        result.joint_group.home.values.extend(value.home)
        return result
    if isinstance(value, GripperSpec):
        result.gripper.CopyFrom(
            catalog_pb2.GripperSpec(
                grasp=enum_to_proto(catalog_pb2.GraspKind, "GRASP_KIND_", value.grasp.value)
            )
        )
        result.gripper.layout.CopyFrom(_layout_to_proto(value.layout))
        if value.travel_m is not None:
            result.gripper.travel.closed_m, result.gripper.travel.open_m = value.travel_m
        if value.grasp_centre_m is not None:
            (
                result.gripper.grasp_centre_m.x,
                result.gripper.grasp_centre_m.y,
                result.gripper.grasp_centre_m.z,
            ) = value.grasp_centre_m
        result.gripper.mimic_joints.extend(
            catalog_pb2.MimicJoint(
                name=mimic.joint_name,
                of=mimic.of,
                multiplier=mimic.multiplier,
            )
            for mimic in value.mimic_joints
        )
        if value.gap_curve is not None:
            result.gripper.gap_curve.knots.extend(
                catalog_pb2.CurveKnot(x=knot.x, y=knot.y) for knot in value.gap_curve.knots
            )
        physical = _physical_to_proto(value.physical)
        if physical is not None:
            result.gripper.physical.CopyFrom(physical)
        return result
    if isinstance(value, CameraSpec):
        result.camera.CopyFrom(
            catalog_pb2.CameraSpec(
                sensor_model=enum_to_proto(
                    catalog_pb2.SensorModel, "SENSOR_MODEL_", value.model.value
                ),
                modality=enum_to_proto(
                    catalog_pb2.CameraModality, "CAMERA_MODALITY_", value.modality.value
                ),
                fps=value.fps,
            )
        )
        optics = value.optics
        result.camera.optics.CopyFrom(
            catalog_pb2.CameraOptics(
                width=optics.width,
                height=optics.height,
                image_from_camera=optics.image_from_camera,
                distortion_model=enum_to_proto(
                    catalog_pb2.DistortionModel,
                    "DISTORTION_MODEL_",
                    optics.distortion_model,
                ),
                distortion_coefficients=optics.distortion_coefficients,
                authority=enum_to_proto(
                    catalog_pb2.CameraOpticsAuthority,
                    "CAMERA_OPTICS_AUTHORITY_",
                    optics.authority.value,
                ),
                source=catalog_pb2.FactSource(
                    repository=optics.source.repository,
                    revision=optics.source.revision,
                    path=optics.source.path,
                ),
            )
        )
        return result
    if isinstance(value, MobileBaseSpec):
        result.mobile_base.layout.CopyFrom(_layout_to_proto(value.layout))
        return result
    if isinstance(value, ForceTorqueSpec):
        if value.rate_hz is not None:
            result.force_torque.rate_hz = value.rate_hz
        else:
            result.force_torque.SetInParent()
        return result
    result.device.description = value.description
    return result


def part_to_proto(value: ComposablePart) -> catalog_pb2.ComposablePart:
    """Project one canonical composable body part into its generated union."""

    part = _part_to_proto(value)
    result = catalog_pb2.ComposablePart(part_id=part.part_id)
    kind = part.WhichOneof("kind")
    if kind == "arm":
        result.arm.CopyFrom(part.arm)
    elif kind == "joint_group":
        result.joint_group.CopyFrom(part.joint_group)
    elif kind == "gripper":
        result.gripper.CopyFrom(part.gripper)
    elif kind == "mobile_base":
        result.mobile_base.CopyFrom(part.mobile_base)
    else:
        raise AssertionError("sx-embodiments ComposablePart union is not exhaustive")
    return result


def embodiment_to_proto(value: Embodiment) -> catalog_pb2.Embodiment:
    """Project one complete embodiment into the generated Catalog message."""

    result = catalog_pb2.Embodiment(
        schema_version=value.schema_version,
        id=str(value.id),
        name=str(value.name),
        label=value.label,
        kind=enum_to_proto(catalog_pb2.EmbodimentKind, "EMBODIMENT_KIND_", value.kind.value),
        lineage=catalog_pb2.Lineage(
            family=value.lineage.family,
            variant=value.lineage.variant,
            revision=value.lineage.revision,
        ),
        assets=[asset_to_proto(asset) for asset in value.assets],
    )
    for component in value.components:
        row = result.components.add(instance=component.instance)
        part = _part_to_proto(component.part)
        if isinstance(component.attachment, BodyAttachment):
            row.body.CopyFrom(part)
        elif isinstance(component.attachment, LeaderAttachment):
            row.leader.CopyFrom(part)
        else:
            row.sensor.CopyFrom(part)
        if isinstance(component.mount, RootMount):
            row.mount.root.frame = component.mount.frame
        else:
            row.mount.mounted_on.parent = component.mount.parent
            row.mount.mounted_on.frame = component.mount.frame
    if value.rates is not None:
        result.rates.policy_hz = value.rates.policy_hz
        if value.rates.low_level_hz is not None:
            result.rates.low_level_hz = value.rates.low_level_hz
    if value.base_mount is not None:
        mount = value.base_mount
        result.base_mount.CopyFrom(
            catalog_pb2.BaseMount(
                kind=enum_to_proto(catalog_pb2.MountKind, "MOUNT_KIND_", mount.kind.value),
                frame=mount.frame,
                half_extent_x_m=mount.half_extents[0],
                half_extent_y_m=mount.half_extents[1],
                centre_x_m=mount.centre[0],
                centre_y_m=mount.centre[1],
                clearance_m=mount.clearance_m,
            )
        )
    result.operator_mounts.extend(
        catalog_pb2.OperatorMount(
            site=enum_to_proto(catalog_pb2.OperatorSite, "OPERATOR_SITE_", mount.site.value),
            root_frame=mount.root_frame,
            attachment_frame=mount.attachment_frame,
        )
        for mount in value.operator_mounts
    )
    return result


def _physical_document(value: catalog_pb2.PhysicalSpec) -> dict[str, object]:
    return {
        "payload_kg": value.payload_kg if value.HasField("payload_kg") else None,
        "reach_m": value.reach_m if value.HasField("reach_m") else None,
        "mass_kg": value.mass_kg if value.HasField("mass_kg") else None,
    }


def _layout_document(value: catalog_pb2.JointLayout) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    units = {
        "radian": "rad",
        "meter": "m",
        "radians_per_second": "rad/s",
        "meters_per_second": "m/s",
        "newton_meter": "N*m",
        "unitless": "unitless",
    }
    for axis in value.axes:
        bounds_kind = axis.bounds.WhichOneof("bounds")
        if bounds_kind == "bounded":
            bounds: dict[str, object] = {
                "kind": "bounded",
                "lower": axis.bounds.bounded.lower,
                "upper": axis.bounds.bounded.upper,
            }
        elif bounds_kind == "unbounded":
            bounds = {"kind": "unbounded"}
        else:
            raise ProtocolTransformError("generated joint axis has no coordinate bounds")
        actuator: dict[str, object] | None = None
        if axis.HasField("actuator"):
            direction = axis.actuator.direction
            if direction == catalog_pb2.ACTUATOR_DIRECTION_FORWARD:
                sign = 1
            elif direction == catalog_pb2.ACTUATOR_DIRECTION_REVERSED:
                sign = -1
            else:
                raise ProtocolTransformError("generated actuator has unspecified direction")
            actuator = {
                "model": enum_from_proto(
                    catalog_pb2.ActuatorModel, "ACTUATOR_MODEL_", axis.actuator.model
                ),
                "bus": enum_from_proto(catalog_pb2.ActuatorBus, "ACTUATOR_BUS_", axis.actuator.bus),
                "bus_id": axis.actuator.bus_id,
                "sign": sign,
                "zero_offset": axis.actuator.zero_offset,
                "reduction": axis.actuator.reduction,
            }
        unit = enum_from_proto(catalog_pb2.CoordinateUnit, "COORDINATE_UNIT_", axis.unit)
        rows.append(
            {
                "name": axis.name,
                "unit": units[unit],
                "bounds": bounds,
                "actuator": actuator,
            }
        )
    return rows


def _part_document(
    value: catalog_pb2.Part | catalog_pb2.ComposablePart,
) -> dict[str, object]:
    kind = value.WhichOneof("kind")
    common: dict[str, object] = {"part_id": value.part_id, "kind": kind}
    if kind == "arm":
        arm = value.arm
        return common | {
            "layout": _layout_document(arm.layout),
            "home": list(arm.home.values),
            "ready": list(arm.ready.values) if arm.HasField("ready") else None,
            "physical": _physical_document(arm.physical) if arm.HasField("physical") else None,
        }
    if kind == "joint_group":
        group = value.joint_group
        return common | {
            "layout": _layout_document(group.layout),
            "home": list(group.home.values),
        }
    if kind == "gripper":
        gripper = value.gripper
        return common | {
            "grasp": enum_from_proto(catalog_pb2.GraspKind, "GRASP_KIND_", gripper.grasp),
            "layout": _layout_document(gripper.layout),
            "travel_m": (
                [gripper.travel.closed_m, gripper.travel.open_m]
                if gripper.HasField("travel")
                else None
            ),
            "grasp_centre_m": (
                [
                    gripper.grasp_centre_m.x,
                    gripper.grasp_centre_m.y,
                    gripper.grasp_centre_m.z,
                ]
                if gripper.HasField("grasp_centre_m")
                else None
            ),
            "mimic_joints": [
                {"name": item.name, "of": item.of, "multiplier": item.multiplier}
                for item in gripper.mimic_joints
            ],
            "gap_curve": (
                [{"x": knot.x, "y": knot.y} for knot in gripper.gap_curve.knots]
                if gripper.HasField("gap_curve")
                else None
            ),
            "physical": (
                _physical_document(gripper.physical) if gripper.HasField("physical") else None
            ),
        }
    if kind == "camera":
        camera = cast("catalog_pb2.Part", value).camera
        optics = camera.optics
        return common | {
            "sensor_model": enum_from_proto(
                catalog_pb2.SensorModel, "SENSOR_MODEL_", camera.sensor_model
            ),
            "modality": enum_from_proto(
                catalog_pb2.CameraModality,
                "CAMERA_MODALITY_",
                camera.modality,
            ),
            "fps": camera.fps,
            "optics": {
                "width": optics.width,
                "height": optics.height,
                "image_from_camera": list(optics.image_from_camera),
                "distortion_model": enum_from_proto(
                    catalog_pb2.DistortionModel,
                    "DISTORTION_MODEL_",
                    optics.distortion_model,
                ),
                "distortion_coefficients": list(optics.distortion_coefficients),
                "authority": enum_from_proto(
                    catalog_pb2.CameraOpticsAuthority,
                    "CAMERA_OPTICS_AUTHORITY_",
                    optics.authority,
                ),
                "source": {
                    "repository": optics.source.repository,
                    "revision": optics.source.revision,
                    "path": optics.source.path,
                },
            },
        }
    if kind == "mobile_base":
        return common | {"layout": _layout_document(value.mobile_base.layout)}
    if kind == "force_torque":
        sensor = cast("catalog_pb2.Part", value).force_torque
        return common | {"rate_hz": sensor.rate_hz if sensor.HasField("rate_hz") else None}
    if kind == "device":
        return common | {"description": cast("catalog_pb2.Part", value).device.description}
    raise ProtocolTransformError("generated part has no specified kind")


def part_from_proto(value: catalog_pb2.ComposablePart) -> ComposablePart:
    """Reconstruct one canonical composable part from its generated union."""

    try:
        return part_from_dict(_part_document(value))
    except ValueError as error:
        raise ProtocolTransformError("generated message carries a malformed part") from error


def _mount_document(value: catalog_pb2.ComponentMount) -> dict[str, object]:
    kind = value.WhichOneof("mount")
    if kind == "root":
        return {"kind": "root", "frame": value.root.frame}
    if kind == "mounted_on":
        return {
            "kind": "mounted_on",
            "parent": value.mounted_on.parent,
            "frame": value.mounted_on.frame,
        }
    raise ProtocolTransformError("generated component has no specified mount")


def embodiment_from_proto(value: catalog_pb2.Embodiment) -> Embodiment:
    """Reconstruct and identity-check one canonical embodiment from generated fields."""

    components: list[dict[str, object]] = []
    for component in value.components:
        attachment = component.WhichOneof("attachment")
        if attachment not in {"body", "leader", "sensor"}:
            raise ProtocolTransformError("generated component has no specified attachment")
        part = getattr(component, attachment)
        components.append(
            {
                "instance": component.instance,
                "attachment": {"kind": attachment, "part": _part_document(part)},
                "mount": _mount_document(component.mount),
            }
        )
    rates: dict[str, object] | None = None
    if value.HasField("rates"):
        rates = {
            "policy_hz": value.rates.policy_hz,
            "low_level_hz": (
                value.rates.low_level_hz if value.rates.HasField("low_level_hz") else None
            ),
        }
    base_mount: dict[str, object] | None = None
    if value.HasField("base_mount"):
        mount = value.base_mount
        base_mount = {
            "kind": enum_from_proto(catalog_pb2.MountKind, "MOUNT_KIND_", mount.kind),
            "frame": mount.frame,
            "half_extents": [mount.half_extent_x_m, mount.half_extent_y_m],
            "centre": [mount.centre_x_m, mount.centre_y_m],
            "clearance_m": mount.clearance_m,
        }
    document: dict[str, object] = {
        "schema_version": value.schema_version,
        "id": value.id,
        "name": value.name,
        "label": value.label,
        "kind": enum_from_proto(catalog_pb2.EmbodimentKind, "EMBODIMENT_KIND_", value.kind),
        "lineage": {
            "family": value.lineage.family,
            "variant": value.lineage.variant,
            "revision": value.lineage.revision,
        },
        "components": components,
        "rates": rates,
        "base_mount": base_mount,
        "operator_mounts": [
            {
                "site": enum_from_proto(catalog_pb2.OperatorSite, "OPERATOR_SITE_", mount.site),
                "root_frame": mount.root_frame,
                "attachment_frame": mount.attachment_frame,
            }
            for mount in value.operator_mounts
        ],
        "assets": [asset_document(asset_from_proto(asset)) for asset in value.assets],
    }
    try:
        return Embodiment.from_dict(document)
    except EmbodimentError as error:
        raise ProtocolTransformError(
            f"generated message carries a malformed embodiment: {error}"
        ) from error


def _rates_document(value: catalog_pb2.ControlRates) -> dict[str, object]:
    return {
        "policy_hz": value.policy_hz,
        "low_level_hz": value.low_level_hz if value.HasField("low_level_hz") else None,
    }


def _base_mount_document(value: catalog_pb2.BaseMount) -> dict[str, object]:
    return {
        "kind": enum_from_proto(catalog_pb2.MountKind, "MOUNT_KIND_", value.kind),
        "frame": value.frame,
        "half_extents": [value.half_extent_x_m, value.half_extent_y_m],
        "centre": [value.centre_x_m, value.centre_y_m],
        "clearance_m": value.clearance_m,
    }


def assembly_definition_from_proto(
    value: catalog_pb2.AssemblyDefinition,
) -> dict[str, object]:
    """Decode the untrusted authoring definition consumed by ``sx_embodiments.assemble``."""

    return {
        "name": value.name,
        "label": value.label,
        "kind": enum_from_proto(catalog_pb2.EmbodimentKind, "EMBODIMENT_KIND_", value.kind),
        "lineage": {
            "family": value.lineage.family,
            "variant": value.lineage.variant,
            "revision": value.lineage.revision,
        },
        "attachments": [
            {
                "instance": item.instance,
                "part_id": item.part_id,
                "mount": _mount_document(item.mount),
            }
            for item in value.attachments
        ],
        "assets": [asset_document(asset_from_proto(item)) for item in value.assets],
        "rates": _rates_document(value.rates) if value.HasField("rates") else None,
        "base_mount": (
            _base_mount_document(value.base_mount) if value.HasField("base_mount") else None
        ),
    }


def _mount_from_dict(value: object, *, label: str) -> catalog_pb2.ComponentMount:
    document = mapping(value, label=label)
    kind = text(document, "kind", label=label)
    result = catalog_pb2.ComponentMount()
    if kind == "root":
        root = exact(document, {"kind", "frame"}, label=label)
        result.root.frame = text(root, "frame", label=label)
        return result
    if kind == "mounted_on":
        mounted = exact(document, {"kind", "parent", "frame"}, label=label)
        result.mounted_on.parent = text(mounted, "parent", label=label)
        result.mounted_on.frame = text(mounted, "frame", label=label)
        return result
    raise ProtocolTransformError(f"{label}.kind is unknown: {kind!r}")


def assembly_definition_to_proto(
    value: Mapping[str, object],
) -> catalog_pb2.AssemblyDefinition:
    """Parse the established strict authoring document into its generated message."""

    document = exact(
        value,
        {"name", "label", "kind", "lineage", "attachments", "assets", "rates", "base_mount"},
        label="assembly definition",
    )
    lineage = exact(
        document["lineage"],
        {"family", "variant", "revision"},
        label="assembly definition.lineage",
    )
    variant = lineage["variant"]
    revision = lineage["revision"]
    if not isinstance(variant, str) or not isinstance(revision, str):
        raise ProtocolTransformError("assembly definition lineage values must be text")
    result = catalog_pb2.AssemblyDefinition(
        name=text(document, "name", label="assembly definition"),
        label=text(document, "label", label="assembly definition"),
        kind=enum_to_proto(
            catalog_pb2.EmbodimentKind,
            "EMBODIMENT_KIND_",
            text(document, "kind", label="assembly definition"),
        ),
        lineage=catalog_pb2.Lineage(
            family=text(lineage, "family", label="assembly definition.lineage"),
            variant=variant,
            revision=revision,
        ),
    )
    for index, raw in enumerate(
        sequence(document["attachments"], label="assembly definition.attachments")
    ):
        label = f"assembly definition.attachments[{index}]"
        attachment = exact(raw, {"instance", "part_id", "mount"}, label=label)
        result.attachments.add(
            instance=text(attachment, "instance", label=label),
            part_id=text(attachment, "part_id", label=label),
            mount=_mount_from_dict(attachment["mount"], label=f"{label}.mount"),
        )
    result.assets.extend(
        asset_to_proto(asset_from_dict(raw, label=f"assembly definition.assets[{index}]"))
        for index, raw in enumerate(
            sequence(document["assets"], label="assembly definition.assets")
        )
    )
    if document["rates"] is not None:
        rates = exact(
            document["rates"],
            {"policy_hz", "low_level_hz"},
            label="assembly definition.rates",
        )
        result.rates.policy_hz = number(rates, "policy_hz", label="assembly definition.rates")
        if rates["low_level_hz"] is not None:
            result.rates.low_level_hz = number(
                rates,
                "low_level_hz",
                label="assembly definition.rates",
            )
    if document["base_mount"] is not None:
        mount = exact(
            document["base_mount"],
            {"kind", "frame", "half_extents", "centre", "clearance_m"},
            label="assembly definition.base_mount",
        )
        half_extents = sequence(
            mount["half_extents"], label="assembly definition.base_mount.half_extents"
        )
        centre = sequence(mount["centre"], label="assembly definition.base_mount.centre")
        if len(half_extents) != 2 or len(centre) != 2:
            raise ProtocolTransformError("assembly base mount pairs must contain two values")
        numeric = [*half_extents, *centre]
        if any(isinstance(item, bool) or not isinstance(item, int | float) for item in numeric):
            raise ProtocolTransformError("assembly base mount coordinates must be numbers")
        result.base_mount.CopyFrom(
            catalog_pb2.BaseMount(
                kind=enum_to_proto(
                    catalog_pb2.MountKind,
                    "MOUNT_KIND_",
                    text(mount, "kind", label="assembly definition.base_mount"),
                ),
                frame=text(mount, "frame", label="assembly definition.base_mount"),
                half_extent_x_m=float(cast("int | float", half_extents[0])),
                half_extent_y_m=float(cast("int | float", half_extents[1])),
                centre_x_m=float(cast("int | float", centre[0])),
                centre_y_m=float(cast("int | float", centre[1])),
                clearance_m=number(
                    mount,
                    "clearance_m",
                    label="assembly definition.base_mount",
                ),
            )
        )
    return result
