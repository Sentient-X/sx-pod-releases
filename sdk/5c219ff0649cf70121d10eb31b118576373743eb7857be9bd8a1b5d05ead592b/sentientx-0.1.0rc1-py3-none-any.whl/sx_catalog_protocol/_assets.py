"""Governed asset transforms for the Catalog protocol boundary."""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import PurePosixPath

from sentientx.sx.common.v1 import assets_pb2
from sx_contracts import (
    AssetFormat,
    AssetProvenance,
    AssetRef,
    AssetRole,
    ContentBlob,
    ProvenancedAsset,
    Sha256Digest,
)

from sx_catalog_protocol._core import (
    ProtocolTransformError,
    enum_from_proto,
    enum_to_proto,
    exact,
    integer,
    text,
)


def asset_to_proto(value: ProvenancedAsset) -> assets_pb2.ProvenancedAsset:
    """Project one canonical governed asset without changing its byte identity."""

    asset = value.asset
    result = assets_pb2.ProvenancedAsset(
        asset=assets_pb2.AssetRef(
            location=asset.location,
            content=assets_pb2.ContentBlob(
                sha256=str(asset.content.sha256),
                size_bytes=asset.content.size_bytes,
            ),
            format=enum_to_proto(assets_pb2.AssetFormat, "ASSET_FORMAT_", asset.format.value),
            role=enum_to_proto(assets_pb2.AssetRole, "ASSET_ROLE_", asset.role.value),
        ),
        provenance=assets_pb2.AssetProvenance(
            repository=value.provenance.repository,
            revision=value.provenance.revision,
            path=value.provenance.path,
            license_id=value.provenance.license_id,
        ),
    )
    if asset.media_type is not None:
        result.asset.media_type = asset.media_type
    if asset.logical_path is not None:
        result.asset.logical_path = str(asset.logical_path)
    if value.provenance.generator is not None:
        result.provenance.generator = value.provenance.generator
    return result


def asset_from_proto(value: assets_pb2.ProvenancedAsset) -> ProvenancedAsset:
    """Reconstruct one governed asset and re-run its content/path invariants."""

    asset = value.asset
    provenance = value.provenance
    try:
        return ProvenancedAsset(
            AssetRef(
                location=asset.location,
                content=ContentBlob(
                    Sha256Digest(asset.content.sha256),
                    asset.content.size_bytes,
                ),
                format=AssetFormat(
                    enum_from_proto(assets_pb2.AssetFormat, "ASSET_FORMAT_", asset.format)
                ),
                role=AssetRole(enum_from_proto(assets_pb2.AssetRole, "ASSET_ROLE_", asset.role)),
                media_type=asset.media_type if asset.HasField("media_type") else None,
                logical_path=(
                    PurePosixPath(asset.logical_path) if asset.HasField("logical_path") else None
                ),
            ),
            AssetProvenance(
                repository=provenance.repository,
                revision=provenance.revision,
                path=provenance.path,
                license_id=provenance.license_id,
                generator=provenance.generator if provenance.HasField("generator") else None,
            ),
        )
    except ValueError as error:
        raise ProtocolTransformError("generated message carries a malformed asset") from error


def asset_from_dict(value: object, *, label: str = "asset") -> ProvenancedAsset:
    """Parse one untrusted canonical asset document at an authoring boundary."""

    document = exact(value, {"asset", "provenance"}, label=label)
    asset = exact(
        document["asset"],
        {"location", "content", "format", "role", "media_type", "logical_path"},
        label=f"{label}.asset",
    )
    content = exact(
        asset["content"],
        {"sha256", "size_bytes"},
        label=f"{label}.asset.content",
    )
    provenance = exact(
        document["provenance"],
        {"repository", "revision", "path", "license_id", "generator"},
        label=f"{label}.provenance",
    )

    def optionaltext(owner: Mapping[str, object], field: str, *, where: str) -> str | None:
        raw = owner[field]
        if raw is None:
            return None
        if not isinstance(raw, str) or not raw:
            raise ProtocolTransformError(f"{where}.{field} must be non-empty text or null")
        return raw

    try:
        logical_path = optionaltext(asset, "logical_path", where=f"{label}.asset")
        return ProvenancedAsset(
            AssetRef(
                location=text(asset, "location", label=f"{label}.asset"),
                content=ContentBlob(
                    Sha256Digest(text(content, "sha256", label=f"{label}.asset.content")),
                    integer(content, "size_bytes", label=f"{label}.asset.content"),
                ),
                format=AssetFormat(text(asset, "format", label=f"{label}.asset")),
                role=AssetRole(text(asset, "role", label=f"{label}.asset")),
                media_type=optionaltext(asset, "media_type", where=f"{label}.asset"),
                logical_path=PurePosixPath(logical_path) if logical_path is not None else None,
            ),
            AssetProvenance(
                repository=text(provenance, "repository", label=f"{label}.provenance"),
                revision=text(provenance, "revision", label=f"{label}.provenance"),
                path=text(provenance, "path", label=f"{label}.provenance"),
                license_id=text(provenance, "license_id", label=f"{label}.provenance"),
                generator=optionaltext(provenance, "generator", where=f"{label}.provenance"),
            ),
        )
    except ProtocolTransformError:
        raise
    except ValueError as error:
        raise ProtocolTransformError(f"{label} is malformed") from error


def asset_document(value: ProvenancedAsset) -> dict[str, object]:
    asset = value.asset
    provenance = value.provenance
    return {
        "asset": {
            "location": asset.location,
            "content": {
                "sha256": str(asset.content.sha256),
                "size_bytes": asset.content.size_bytes,
            },
            "format": asset.format.value,
            "role": asset.role.value,
            "media_type": asset.media_type,
            "logical_path": str(asset.logical_path) if asset.logical_path is not None else None,
        },
        "provenance": {
            "repository": provenance.repository,
            "revision": provenance.revision,
            "path": provenance.path,
            "license_id": provenance.license_id,
            "generator": provenance.generator,
        },
    }
