"""The pipeline plan, its quote, and what an executor says about a run.

Three values cross this boundary, and each keeps the normal form its domain
already owns. A plan carries the graph's own canonical wire rather than a second
Protobuf model of what a graph is — `sx_contracts.pipelines` re-proves every
step's content identity on parse, and a structural copy would make the plan
digest depend on which encoding produced it. An estimate and a report are small
closed values, so they cross as real messages.

Every direction is total on valid inputs and refuses anything that is not exactly
the domain's own normal form.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC, datetime
from typing import TypedDict
from uuid import UUID

from sentientx.sx.common.v1 import common_pb2
from sentientx.sx.experience.catalog.v1 import pipelines_pb2
from sentientx.sx.operations.v1 import operations_pb2
from sx_contracts import (
    AcceptedOperation,
    CancellationRequest,
    CancelledOperation,
    FailedOperation,
    IdempotencyKey,
    OperationFailure,
    OperationId,
    OperationKind,
    OperationReceipt,
    PlatformPillar,
    ResourceRef,
    RunningOperation,
    SchemaCompatibility,
    Sha256Digest,
    SucceededOperation,
    TraceId,
    UpdateCursor,
)
from sx_contracts.pipelines import (
    AdmittedPlan,
    GraphError,
    PipelinePlan,
    PlanStage,
    ResolvedInput,
    RunCancelled,
    RunFailed,
    RunPhase,
    RunProgress,
    RunPublished,
    RunReport,
    pipeline_from_json,
    pipeline_json,
)
from sx_contracts.schemas import SchemaId
from sx_contracts.usage import MeteredQuantity, MeterId, PlanEstimate, UsageContractError

from sx_catalog_protocol._core import ProtocolTransformError

_OUTLETS: Mapping[SchemaCompatibility, pipelines_pb2.SchemaCompatibility] = {
    SchemaCompatibility.IDENTICAL: pipelines_pb2.SCHEMA_COMPATIBILITY_IDENTICAL,
    SchemaCompatibility.READ_COMPATIBLE: pipelines_pb2.SCHEMA_COMPATIBILITY_READ_COMPATIBLE,
    SchemaCompatibility.MIGRATION_REQUIRED: pipelines_pb2.SCHEMA_COMPATIBILITY_MIGRATION_REQUIRED,
    SchemaCompatibility.INCOMPATIBLE: pipelines_pb2.SCHEMA_COMPATIBILITY_INCOMPATIBLE,
}

_PHASES: Mapping[RunPhase, pipelines_pb2.RunPhase] = {
    RunPhase.PLANNING: pipelines_pb2.RUN_PHASE_PLANNING,
    RunPhase.WAITING_FOR_CAPACITY: pipelines_pb2.RUN_PHASE_WAITING_FOR_CAPACITY,
    RunPhase.EXECUTING: pipelines_pb2.RUN_PHASE_EXECUTING,
    RunPhase.VALIDATING: pipelines_pb2.RUN_PHASE_VALIDATING,
    RunPhase.PUBLISHING: pipelines_pb2.RUN_PHASE_PUBLISHING,
    RunPhase.CANCELLING: pipelines_pb2.RUN_PHASE_CANCELLING,
}


# --- the plan ---------------------------------------------------------------


def pipeline_plan_to_proto(value: PipelinePlan) -> pipelines_pb2.PipelinePlan:
    """Carry the graph's own canonical wire, its bindings, and its destination."""

    return pipelines_pb2.PipelinePlan(
        canonical_pipeline=pipeline_json(value.pipeline).encode("utf-8"),
        inputs=[
            pipelines_pb2.PipelineInputBinding(input_name=name, snapshot=snapshot)
            for name, snapshot in sorted(value.inputs.items())
        ],
        destination=value.destination,
    )


def pipeline_plan_from_proto(value: pipelines_pb2.PipelinePlan) -> PipelinePlan:
    """Parse one plan and re-prove the graph it claims.

    Four refusals, in the order a forged message reaches them: bytes that are not
    UTF-8, bytes the graph codec will not admit, bytes that are admissible but
    not canonical, and a binding that names one graph input twice. The third is
    what makes the plan digest a fact about the plan rather than about whoever
    encoded it.
    """

    try:
        encoded = value.canonical_pipeline.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ProtocolTransformError("a pipeline graph is not UTF-8") from error
    try:
        pipeline = pipeline_from_json(encoded)
    except GraphError as error:
        raise ProtocolTransformError(f"malformed pipeline graph: {error}") from error
    if pipeline_json(pipeline) != encoded:
        raise ProtocolTransformError("pipeline graph bytes are not canonical")
    inputs = {binding.input_name: binding.snapshot for binding in value.inputs}
    if len(inputs) != len(value.inputs):
        raise ProtocolTransformError("a plan binds one graph input more than once")
    if not inputs:
        raise ProtocolTransformError("a plan binds at least one graph input")
    return PipelinePlan(pipeline, inputs, value.destination)


# --- the quote --------------------------------------------------------------


def plan_estimate_to_proto(value: PlanEstimate) -> pipelines_pb2.PlanEstimate:
    """Quantities under a meter version, and the assumptions they rest on."""

    return pipelines_pb2.PlanEstimate(
        members=value.members,
        assumed_partition_seconds=value.assumed_partition_seconds,
        meter_version=value.meter_version,
        per_partition=[_quantity_to_proto(item) for item in value.per_partition],
        total=[_quantity_to_proto(item) for item in value.total],
        assumptions=list(value.assumptions),
    )


def plan_estimate_from_proto(value: pipelines_pb2.PlanEstimate) -> PlanEstimate:
    """Parse one quote, rejecting a meter or a quantity the domain refuses."""

    try:
        return PlanEstimate(
            members=value.members,
            assumed_partition_seconds=value.assumed_partition_seconds,
            meter_version=value.meter_version,
            per_partition=tuple(_quantity_from_proto(item) for item in value.per_partition),
            total=tuple(_quantity_from_proto(item) for item in value.total),
            assumptions=tuple(value.assumptions),
        )
    except UsageContractError as error:
        raise ProtocolTransformError(f"malformed plan estimate: {error}") from error


def _quantity_to_proto(value: MeteredQuantity) -> pipelines_pb2.MeteredQuantity:
    return pipelines_pb2.MeteredQuantity(meter=str(value.meter), quantity=value.quantity)


def _quantity_from_proto(value: pipelines_pb2.MeteredQuantity) -> MeteredQuantity:
    return MeteredQuantity(MeterId(value.meter), value.quantity)


# --- what the executor says back --------------------------------------------


def run_report_to_proto(value: RunReport) -> pipelines_pb2.RunReport:
    """One report, tagged by the state it moves the run to."""

    if isinstance(value, RunProgress):
        return pipelines_pb2.RunReport(
            progress=pipelines_pb2.RunProgressReport(phase=run_phase_to_proto(value.phase))
        )
    if isinstance(value, RunPublished):
        return pipelines_pb2.RunReport(
            published=pipelines_pb2.RunPublishedReport(snapshot_id=str(value.snapshot_id))
        )
    if isinstance(value, RunFailed):
        return pipelines_pb2.RunReport(
            failed=pipelines_pb2.RunFailedReport(
                failure=operations_pb2.OperationFailure(
                    code=value.failure.code,
                    message=value.failure.message,
                    retryable=value.failure.retryable,
                )
            )
        )
    return pipelines_pb2.RunReport(cancelled=pipelines_pb2.RunCancelledReport(reason=value.reason))


def run_report_from_proto(value: pipelines_pb2.RunReport) -> RunReport:
    """Parse one report into the closed vocabulary the run lifecycle speaks.

    An unset arm is refused rather than defaulted: a newer executor choosing an
    arm this owner does not know must not be read as one it does.
    """

    arm = value.WhichOneof("report")
    if arm == "progress":
        return RunProgress(phase=run_phase_from_proto(value.progress.phase))
    if arm == "published":
        try:
            return RunPublished(snapshot_id=UUID(value.published.snapshot_id))
        except ValueError as error:
            raise ProtocolTransformError("a published run names a snapshot uuid") from error
    if arm == "failed":
        failure = value.failed.failure
        return RunFailed(failure=OperationFailure(failure.code, failure.message, failure.retryable))
    if arm == "cancelled":
        return RunCancelled(reason=value.cancelled.reason)
    raise ProtocolTransformError("a run report names no ending this owner knows")


def run_phase_to_proto(value: RunPhase) -> pipelines_pb2.RunPhase:
    """Total: every closed domain phase has exactly one declared wire value.

    Written out rather than derived from the name, because the table is the proof.
    A phase added on one side and not the other is a KeyError here and a failing
    equality in `tests/test_pipelines.py`, instead of a lookup that happens to work.
    """

    return _PHASES[value]


def run_phase_from_proto(value: int) -> RunPhase:
    """proto3 enums are open, so an unknown number and the zero are both refused."""

    for phase, declared in _PHASES.items():
        if declared == value:
            return phase
    raise ProtocolTransformError(f"a run phase is never {value}")


# --- what validation proved -------------------------------------------------


def admitted_plan_to_proto(value: AdmittedPlan) -> pipelines_pb2.AdmittedPlan:
    """Everything validating a plan established, and nothing that required running it."""

    return pipelines_pb2.AdmittedPlan(
        plan_digest=str(value.digest),
        inputs=[
            pipelines_pb2.ResolvedInput(
                input_name=item.input_name,
                snapshot=item.snapshot,
                schema_id=str(item.schema),
                members=item.members,
            )
            for item in value.inputs
        ],
        stages=[
            pipelines_pb2.PlanStage(node=stage.node, produces=str(stage.produces))
            for stage in value.stages
        ],
        produces=str(value.produces),
        destination=value.destination,
        outlet=_OUTLETS[value.outlet],
    )


def admitted_plan_from_proto(value: pipelines_pb2.AdmittedPlan) -> AdmittedPlan:
    """Parse one admission, refusing an outlet compatibility the domain does not name."""

    return AdmittedPlan(
        digest=Sha256Digest(value.plan_digest),
        inputs=tuple(
            ResolvedInput(
                input_name=item.input_name,
                snapshot=item.snapshot,
                schema=SchemaId(item.schema_id),
                members=item.members,
            )
            for item in value.inputs
        ),
        stages=tuple(
            PlanStage(node=stage.node, produces=SchemaId(stage.produces)) for stage in value.stages
        ),
        produces=SchemaId(value.produces),
        destination=value.destination,
        outlet=schema_compatibility_from_proto(value.outlet),
    )


def schema_compatibility_to_proto(
    value: SchemaCompatibility,
) -> pipelines_pb2.SchemaCompatibility:
    """Total: every closed domain compatibility has exactly one declared wire value."""

    return _OUTLETS[value]


def schema_compatibility_from_proto(value: int) -> SchemaCompatibility:
    """proto3 enums are open, so an unknown number and the zero are both refused."""

    for compatibility, declared in _OUTLETS.items():
        if declared == value:
            return compatibility
    raise ProtocolTransformError(f"a schema compatibility is never {value}")


# --- the run's platform receipt ---------------------------------------------


def run_receipt_from_proto(value: pipelines_pb2.PipelineRun) -> OperationReceipt:
    """The operation half of one run, spoken as the receipt every pillar shares.

    The receipt is the whole answer to *where has this run got to*; the phase and
    the published snapshot are declared fields beside it, so nothing is lifted
    into the receipt's open `progress` mapping here. That mapping was how the
    retired JSON wire smuggled two typed facts past a schema that had no room for
    them, and it has room for them now.
    """

    metadata = value.metadata
    ref = metadata.ref
    if (
        ref.pillar != common_pb2.PLATFORM_PILLAR_EXPERIENCE
        or ref.kind != common_pb2.OPERATION_KIND_PIPELINE_RUN
    ):
        raise ProtocolTransformError("that operation does not name a Catalog pipeline run")
    if metadata.resource.owner != "catalog" or not metadata.resource.kind:
        raise ProtocolTransformError("a pipeline run names a Catalog resource")
    if not metadata.HasField("idempotency_key"):
        raise ProtocolTransformError("a pipeline run carries the key that admitted it")
    common = _ReceiptCommon(
        operation_id=OperationId(ref.operation_id),
        pillar=PlatformPillar.EXPERIENCE,
        kind=OperationKind.PIPELINE_RUN,
        resource_ref=ResourceRef(f"{metadata.resource.kind}:{metadata.resource.id}"),
        trace_id=TraceId(metadata.trace_id),
        cursor=UpdateCursor(metadata.cursor),
        idempotency_key=IdempotencyKey(metadata.idempotency_key),
        progress={},
        created_at=metadata.created_at.ToDatetime(tzinfo=UTC),
        updated_at=metadata.updated_at.ToDatetime(tzinfo=UTC),
    )
    lifecycle = value.lifecycle
    arm = lifecycle.WhichOneof("state")
    if arm == "accepted":
        return AcceptedOperation(**common, cancellation=_cancellation(lifecycle.accepted))
    if arm == "running":
        return RunningOperation(**common, cancellation=_cancellation(lifecycle.running))
    if arm == "succeeded":
        return SucceededOperation(
            **common, completed_at=lifecycle.succeeded.completed_at.ToDatetime(tzinfo=UTC)
        )
    if arm == "failed":
        failure = lifecycle.failed.failure
        return FailedOperation(
            **common,
            failure=OperationFailure(failure.code, failure.message, failure.retryable),
            failed_at=lifecycle.failed.failed_at.ToDatetime(tzinfo=UTC),
        )
    if arm == "cancelled":
        return CancelledOperation(
            **common,
            reason=lifecycle.cancelled.reason,
            cancelled_at=lifecycle.cancelled.cancelled_at.ToDatetime(tzinfo=UTC),
        )
    raise ProtocolTransformError("a run lifecycle names no state this owner knows")


class _ReceiptCommon(TypedDict):
    operation_id: OperationId
    pillar: PlatformPillar
    kind: OperationKind
    resource_ref: ResourceRef
    trace_id: TraceId
    cursor: UpdateCursor
    idempotency_key: IdempotencyKey
    progress: Mapping[str, object]
    created_at: datetime
    updated_at: datetime


def _cancellation(
    value: operations_pb2.AcceptedOperation | operations_pb2.RunningOperation,
) -> CancellationRequest | None:
    if not value.HasField("cancellation"):
        return None
    return CancellationRequest(
        reason=value.cancellation.reason,
        requested_at=value.cancellation.requested_at.ToDatetime(tzinfo=UTC),
    )
