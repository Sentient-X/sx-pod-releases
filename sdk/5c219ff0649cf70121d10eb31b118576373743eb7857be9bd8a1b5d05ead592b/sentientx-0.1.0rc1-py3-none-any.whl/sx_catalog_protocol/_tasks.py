"""Task-contract, capability, goal, and reference protocol transforms."""

from __future__ import annotations

from typing import cast

import sx_contracts.tasks as task_domain
from sentientx.sx.common.v1 import capabilities_pb2, common_pb2, tasks_pb2
from sx_contracts import (
    Capability,
    Sha256Digest,
    TaskContract,
    TaskContractError,
    TaskContractRef,
    TaskId,
    TaskSchemaVersion,
    from_canonical_json,
)
from sx_contracts.identity import CanonicalDocument
from sx_contracts.identity import canonical_json as canonical_document

from sx_catalog_protocol._core import ProtocolTransformError, enum_from_proto, enum_to_proto


def _measure_to_proto(value: task_domain.Measure) -> tasks_pb2.TaskMeasure:
    result = tasks_pb2.TaskMeasure()
    if isinstance(value, task_domain.PlanarDistanceTo):
        result.planar_distance_to.reference = value.reference
    elif isinstance(value, task_domain.VerticalDistanceTo):
        result.vertical_distance_to.reference = value.reference
    elif isinstance(value, task_domain.OrientationErrorTo):
        result.orientation_error_to.reference = value.reference
    elif isinstance(value, task_domain.UprightOrientationError):
        result.upright_orientation_error.SetInParent()
    elif isinstance(value, task_domain.FractionTransferredTo):
        result.fraction_transferred_to.reference = value.reference
    elif isinstance(value, task_domain.CountWithin):
        result.count_within.reference = value.reference
    elif isinstance(value, task_domain.JointFractionAtLeast):
        result.joint_fraction_at_least.articulation = value.articulation
        result.joint_fraction_at_least.fraction = value.fraction
    elif isinstance(value, task_domain.BinaryStateIs):
        result.binary_state_is.articulation = value.articulation
        result.binary_state_is.on = value.on
    elif isinstance(value, task_domain.JointAngleOutside):
        result.joint_angle_outside.articulation = value.articulation
        result.joint_angle_outside.lower_rad = value.lower_rad
        result.joint_angle_outside.upper_rad = value.upper_rad
    else:
        result.contact_with.surface = value.surface
    return result


def _comparison_to_proto(value: task_domain.Comparison) -> tasks_pb2.TaskComparison:
    result = tasks_pb2.TaskComparison()
    if isinstance(value, task_domain.AtMost):
        result.at_most.value = value.value
    elif isinstance(value, task_domain.AtLeast):
        result.at_least.value = value.value
    elif isinstance(value, task_domain.Exactly):
        result.exactly.value = value.value
    else:
        result.within.value = value.value
        result.within.tolerance = value.tolerance
    return result


def task_goal_to_proto(value: task_domain.TaskGoal) -> tasks_pb2.TaskGoal:
    return tasks_pb2.TaskGoal(
        relation=enum_to_proto(
            tasks_pb2.TaskGoalRelation,
            "TASK_GOAL_RELATION_",
            value.relation.value,
        ),
        counterparty=enum_to_proto(
            tasks_pb2.TaskCounterparty, "TASK_COUNTERPARTY_", value.counterparty.value
        ),
        predicates=[
            tasks_pb2.GoalPredicate(
                entity=predicate.entity,
                measure=_measure_to_proto(predicate.measure),
                comparison=_comparison_to_proto(predicate.comparison),
            )
            for predicate in value.predicates
        ],
    )


def capability_from_proto(value: int) -> Capability:
    """Parse one generated capability enum into the closed domain vocabulary."""

    try:
        name = capabilities_pb2.Capability.Name(value)
    except ValueError as error:
        raise ProtocolTransformError(f"unknown generated capability value {value}") from error
    if not name.startswith("CAPABILITY_") or name.endswith("UNSPECIFIED"):
        raise ProtocolTransformError("generated capability is unspecified")
    try:
        return Capability[name.removeprefix("CAPABILITY_")]
    except KeyError as error:
        raise ProtocolTransformError(
            f"generated capability is not in the domain: {name}"
        ) from error


def capability_to_proto(value: Capability) -> capabilities_pb2.Capability:
    """Project one domain capability into the generated closed enum."""

    return cast(
        "capabilities_pb2.Capability",
        capabilities_pb2.Capability.Value(f"CAPABILITY_{value.name}"),
    )


def task_contract_ref_to_proto(value: TaskContractRef) -> common_pb2.TaskContractRef:
    """Project one exact immutable task-contract identity."""

    return common_pb2.TaskContractRef(
        task_id=str(value.task_id),
        schema_version=str(value.schema_version),
        sha256=str(value.sha256),
    )


def task_contract_ref_from_proto(value: common_pb2.TaskContractRef) -> TaskContractRef:
    """Parse one exact generated task identity into the canonical domain value."""

    if not value.task_id:
        raise ProtocolTransformError("generated task contract ref has no task id")
    try:
        return TaskContractRef(
            task_id=TaskId(value.task_id),
            schema_version=TaskSchemaVersion(value.schema_version),
            sha256=Sha256Digest(value.sha256),
        )
    except (TaskContractError, ValueError) as error:
        raise ProtocolTransformError(f"malformed generated task contract ref: {error}") from error


def _evaluation_to_proto(
    value: task_domain.EvaluationCriteria,
) -> tasks_pb2.TaskEvaluationCriteria:
    result = tasks_pb2.TaskEvaluationCriteria()
    if isinstance(value, task_domain.NativeEvaluationCriteria):
        result.native.threshold = value.threshold
        result.native.trials = value.trials
    else:
        result.suite.threshold = value.threshold
        result.suite.trials = value.trials
        result.suite.suite.suite_id = value.suite.suite_id
        result.suite.suite.sha256 = str(value.suite.sha256)
    return result


def _taskpedia_code_to_proto(value: task_domain.TaskpediaCodeRef) -> tasks_pb2.TaskpediaCodeRef:
    common = {
        "code": value.code,
        "relation": enum_to_proto(
            tasks_pb2.EvidenceRelation,
            "EVIDENCE_RELATION_",
            value.relation.value,
        ),
    }
    if value.origin is None:
        return tasks_pb2.TaskpediaCodeRef(**common)
    return tasks_pb2.TaskpediaCodeRef(
        **common,
        origin=enum_to_proto(tasks_pb2.EvidenceOrigin, "EVIDENCE_ORIGIN_", value.origin.value),
    )


def task_contract_to_proto(value: TaskContract) -> tasks_pb2.TaskContract:
    """Project the complete schema-1.1 contract used by Catalog admissibility RPCs."""

    task = value.task
    template = tasks_pb2.TaskTemplate(
        id=str(task.id),
        name=task.name,
        horizon=enum_to_proto(tasks_pb2.TaskHorizon, "TASK_HORIZON_", task.horizon.value),
        reasoning=enum_to_proto(tasks_pb2.ReasoningKind, "REASONING_KIND_", task.reasoning.value),
        rigs=[str(rig) for rig in task.rigs],
        operator=enum_to_proto(tasks_pb2.OperatorTier, "OPERATOR_TIER_", task.operator.value),
        embodiment=capabilities_pb2.TaskCapabilityRequirements(
            roles=[
                capabilities_pb2.TaskRoleRequirement(
                    role_id=str(role.role_id),
                    capabilities=[
                        capability_to_proto(capability) for capability in role.capabilities.ordered
                    ],
                )
                for role in task.embodiment.roles
            ]
        ),
        steps=[
            tasks_pb2.TaskStep(skill=str(step.skill), reversible=step.reversible)
            for step in task.steps
        ],
        taskpedia_codes=[_taskpedia_code_to_proto(code) for code in task.taskpedia_codes],
        objects=[
            tasks_pb2.TaskObject(
                role=enum_to_proto(tasks_pb2.TaskObjectRole, "TASK_OBJECT_ROLE_", item.role.value),
                head=str(item.head),
                count=tasks_pb2.CountInterval(
                    minimum=item.count.minimum,
                    maximum=item.count.maximum,
                ),
                mix=enum_to_proto(tasks_pb2.TaskObjectMix, "TASK_OBJECT_MIX_", item.mix.value),
                options=item.options,
            )
            for item in task.objects
        ],
        environment=tasks_pb2.TaskEnvironment(
            stations=[str(station) for station in task.environment.stations],
            lighting=task.environment.lighting,
            surfaces=task.environment.surfaces,
        ),
        distractors=tasks_pb2.DistractorPlan(
            easy=task.distractors.easy,
            medium=task.distractors.medium,
            hard=task.distractors.hard,
        ),
        initial_poses=tasks_pb2.InitialPosePlan(
            object_bins=task.initial_poses.object_bins,
            robot_bins=task.initial_poses.robot_bins,
        ),
        diversification=tasks_pb2.DiversificationPlan(
            scheme=enum_to_proto(
                tasks_pb2.DiversificationScheme,
                "DIVERSIFICATION_SCHEME_",
                task.diversification.scheme.value,
            ),
            budget=task.diversification.budget,
            adapt=enum_to_proto(
                tasks_pb2.AdaptationKind, "ADAPTATION_KIND_", task.diversification.adapt.value
            ),
        ),
        success=task.success,
        goal=task_goal_to_proto(task.goal),
        complexity=[
            enum_to_proto(tasks_pb2.ComplexityAxis, "COMPLEXITY_AXIS_", axis.value)
            for axis in task.complexity
        ],
        failure_conditions=[
            tasks_pb2.FailureCondition(
                kind=enum_to_proto(
                    tasks_pb2.FailureConditionKind,
                    "FAILURE_CONDITION_KIND_",
                    failure.kind.value,
                ),
                detail=failure.detail,
            )
            for failure in task.failure_conditions
        ],
    )
    for source, target in zip(task.steps, template.steps, strict=True):
        for name in ("object", "target", "when", "until", "note"):
            item = getattr(source, name)
            if item is not None:
                setattr(target, name, item)
    object_scheme = task.diversification.object_scheme
    if object_scheme is not None:
        template.diversification.object_scheme.CopyFrom(
            tasks_pb2.ObjectDiversification(
                role=enum_to_proto(
                    tasks_pb2.TaskObjectRole,
                    "TASK_OBJECT_ROLE_",
                    object_scheme.role.value,
                ),
                instances=object_scheme.instances,
                justification=object_scheme.justification,
            )
        )
    if task.variation is not None:
        variation = task.variation
        template.variation.CopyFrom(
            tasks_pb2.VariationPlan(
                fill_states=[
                    enum_to_proto(tasks_pb2.FillState, "FILL_STATE_", item.value)
                    for item in variation.fill_states
                ],
                media=variation.media,
                pace=[
                    enum_to_proto(tasks_pb2.DemonstrationPace, "DEMONSTRATION_PACE_", item.value)
                    for item in variation.pace
                ],
                perturbations=[
                    enum_to_proto(tasks_pb2.PerturbationKind, "PERTURBATION_KIND_", item.value)
                    for item in variation.perturbations
                ],
                conditions=[
                    enum_to_proto(tasks_pb2.ObjectCondition, "OBJECT_CONDITION_", item.value)
                    for item in variation.conditions
                ],
                cameras=variation.cameras,
            )
        )
        if variation.recovery_share is not None:
            template.variation.recovery_share = variation.recovery_share
    if task.capture is not None:
        if task.capture.episodes_per_scenario_max is not None:
            template.capture.episodes_per_scenario_max = task.capture.episodes_per_scenario_max
        if task.capture.episode_minutes_est is not None:
            template.capture.episode_minutes_est = task.capture.episode_minutes_est
    if task.evaluation is not None:
        template.evaluation.CopyFrom(_evaluation_to_proto(task.evaluation))
    for source, target in zip(task.failure_conditions, template.failure_conditions, strict=True):
        if source.limit is not None:
            target.limit = source.limit
    if task.safety is not None:
        template.safety = task.safety
    return tasks_pb2.TaskContract(
        schema_version=str(value.schema_version),
        family=str(value.family),
        task=template,
    )


def _task_measure_document(value: tasks_pb2.TaskMeasure) -> dict[str, object]:
    kind = value.WhichOneof("measure")
    if kind is None:
        raise ProtocolTransformError("generated task measure is missing")
    measure = getattr(value, kind)
    document: dict[str, object] = {"kind": kind}
    for field in measure.DESCRIPTOR.fields:
        document[field.name] = getattr(measure, field.name)
    return document


def _task_comparison_document(value: tasks_pb2.TaskComparison) -> dict[str, object]:
    kind = value.WhichOneof("comparison")
    if kind is None:
        raise ProtocolTransformError("generated task comparison is missing")
    comparison = getattr(value, kind)
    return {"kind": kind} | {
        field.name: getattr(comparison, field.name) for field in comparison.DESCRIPTOR.fields
    }


def task_contract_from_proto(value: tasks_pb2.TaskContract) -> TaskContract:
    """Reconstruct the complete task contract through its canonical fail-closed reader."""

    task = value.task
    evaluation: dict[str, object] | None = None
    if task.HasField("evaluation"):
        kind = task.evaluation.WhichOneof("criteria")
        if kind not in {"native", "suite"}:
            raise ProtocolTransformError("generated task evaluation criteria are missing")
        criteria = getattr(task.evaluation, kind)
        evaluation = {
            "kind": "registered_suite" if kind == "suite" else "native",
            "threshold": criteria.threshold,
            "trials": criteria.trials,
        }
        if kind == "suite":
            evaluation["suite"] = {
                "suite_id": criteria.suite.suite_id,
                "sha256": criteria.suite.sha256,
            }
    document: dict[str, object] = {
        "schema_version": value.schema_version,
        "family": value.family,
        "task": {
            "id": task.id,
            "name": task.name,
            "horizon": enum_from_proto(tasks_pb2.TaskHorizon, "TASK_HORIZON_", task.horizon),
            "reasoning": enum_from_proto(
                tasks_pb2.ReasoningKind,
                "REASONING_KIND_",
                task.reasoning,
            ),
            "rigs": list(task.rigs),
            "operator": enum_from_proto(
                tasks_pb2.OperatorTier,
                "OPERATOR_TIER_",
                task.operator,
            ),
            "embodiment": {
                "roles": [
                    {
                        "role_id": role.role_id,
                        "capabilities": [
                            capability_from_proto(capability).value
                            for capability in role.capabilities
                        ],
                    }
                    for role in task.embodiment.roles
                ]
            },
            "steps": [
                {
                    "skill": item.skill,
                    "object": item.object if item.HasField("object") else None,
                    "target": item.target if item.HasField("target") else None,
                    "when": item.when if item.HasField("when") else None,
                    "until": item.until if item.HasField("until") else None,
                    "note": item.note if item.HasField("note") else None,
                    "reversible": item.reversible,
                }
                for item in task.steps
            ],
            "taskpedia_codes": [
                {
                    "code": item.code,
                    "relation": enum_from_proto(
                        tasks_pb2.EvidenceRelation,
                        "EVIDENCE_RELATION_",
                        item.relation,
                    ),
                    "origin": (
                        enum_from_proto(
                            tasks_pb2.EvidenceOrigin,
                            "EVIDENCE_ORIGIN_",
                            item.origin,
                        )
                        if item.HasField("origin")
                        else None
                    ),
                }
                for item in task.taskpedia_codes
            ],
            "objects": [
                {
                    "role": enum_from_proto(
                        tasks_pb2.TaskObjectRole,
                        "TASK_OBJECT_ROLE_",
                        item.role,
                    ),
                    "head": item.head,
                    "count": {
                        "minimum": item.count.minimum,
                        "maximum": item.count.maximum,
                    },
                    "mix": enum_from_proto(
                        tasks_pb2.TaskObjectMix,
                        "TASK_OBJECT_MIX_",
                        item.mix,
                    ),
                    "options": list(item.options),
                }
                for item in task.objects
            ],
            "environment": {
                "stations": list(task.environment.stations),
                "lighting": list(task.environment.lighting),
                "surfaces": list(task.environment.surfaces),
            },
            "distractors": {
                "easy": task.distractors.easy,
                "medium": task.distractors.medium,
                "hard": task.distractors.hard,
            },
            "initial_poses": {
                "object_bins": list(task.initial_poses.object_bins),
                "robot_bins": list(task.initial_poses.robot_bins),
            },
            "diversification": {
                "scheme": enum_from_proto(
                    tasks_pb2.DiversificationScheme,
                    "DIVERSIFICATION_SCHEME_",
                    task.diversification.scheme,
                ),
                "budget": task.diversification.budget,
                "adapt": enum_from_proto(
                    tasks_pb2.AdaptationKind,
                    "ADAPTATION_KIND_",
                    task.diversification.adapt,
                ),
                "object_scheme": (
                    {
                        "role": enum_from_proto(
                            tasks_pb2.TaskObjectRole,
                            "TASK_OBJECT_ROLE_",
                            task.diversification.object_scheme.role,
                        ),
                        "instances": list(task.diversification.object_scheme.instances),
                        "justification": task.diversification.object_scheme.justification,
                    }
                    if task.diversification.HasField("object_scheme")
                    else None
                ),
            },
            "success": task.success,
            "goal": {
                "relation": enum_from_proto(
                    tasks_pb2.TaskGoalRelation,
                    "TASK_GOAL_RELATION_",
                    task.goal.relation,
                ),
                "counterparty": enum_from_proto(
                    tasks_pb2.TaskCounterparty,
                    "TASK_COUNTERPARTY_",
                    task.goal.counterparty,
                ),
                "predicates": [
                    {
                        "entity": item.entity,
                        "measure": _task_measure_document(item.measure),
                        "comparison": _task_comparison_document(item.comparison),
                    }
                    for item in task.goal.predicates
                ],
            },
            "complexity": [
                enum_from_proto(tasks_pb2.ComplexityAxis, "COMPLEXITY_AXIS_", item)
                for item in task.complexity
            ],
            "variation": (
                {
                    "fill_states": [
                        enum_from_proto(tasks_pb2.FillState, "FILL_STATE_", item)
                        for item in task.variation.fill_states
                    ],
                    "media": list(task.variation.media),
                    "pace": [
                        enum_from_proto(
                            tasks_pb2.DemonstrationPace,
                            "DEMONSTRATION_PACE_",
                            item,
                        )
                        for item in task.variation.pace
                    ],
                    "perturbations": [
                        enum_from_proto(
                            tasks_pb2.PerturbationKind,
                            "PERTURBATION_KIND_",
                            item,
                        )
                        for item in task.variation.perturbations
                    ],
                    "conditions": [
                        enum_from_proto(
                            tasks_pb2.ObjectCondition,
                            "OBJECT_CONDITION_",
                            item,
                        )
                        for item in task.variation.conditions
                    ],
                    "recovery_share": (
                        task.variation.recovery_share
                        if task.variation.HasField("recovery_share")
                        else None
                    ),
                    "cameras": list(task.variation.cameras),
                }
                if task.HasField("variation")
                else None
            ),
            "capture": (
                {
                    "episodes_per_scenario_max": (
                        task.capture.episodes_per_scenario_max
                        if task.capture.HasField("episodes_per_scenario_max")
                        else None
                    ),
                    "episode_minutes_est": (
                        task.capture.episode_minutes_est
                        if task.capture.HasField("episode_minutes_est")
                        else None
                    ),
                }
                if task.HasField("capture")
                else None
            ),
            "evaluation": evaluation,
            "failure_conditions": [
                {
                    "kind": enum_from_proto(
                        tasks_pb2.FailureConditionKind,
                        "FAILURE_CONDITION_KIND_",
                        item.kind,
                    ),
                    "detail": item.detail,
                    "limit": item.limit if item.HasField("limit") else None,
                }
                for item in task.failure_conditions
            ],
            "safety": task.safety if task.HasField("safety") else None,
        },
    }
    try:
        return from_canonical_json(canonical_document(cast("CanonicalDocument", document)))
    except ValueError as error:
        raise ProtocolTransformError(
            "generated message carries a malformed task contract"
        ) from error
