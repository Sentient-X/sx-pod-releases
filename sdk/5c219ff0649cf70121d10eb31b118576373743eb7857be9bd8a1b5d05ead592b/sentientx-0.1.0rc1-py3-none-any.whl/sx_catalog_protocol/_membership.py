"""What a membership and a corpus are on the wire.

Two values cross this boundary and each keeps the normal form its own domain
already owns. A corpus travels as the exact canonical document `sx_corpora`
hashes, plus the digest every reader re-derives from it — the identity is taken
over that document, so a structural Protobuf copy would make a corpus's sha256
depend on which encoding produced it. A selection member is a small closed pair
and crosses as a real message.

Both directions are total on valid inputs and refuse anything that is not exactly
the domain's own normal form.
"""

from __future__ import annotations

import json
from typing import cast

from sentientx.sx.experience.catalog.v1 import membership_pb2
from sx_contracts import Sha256Digest
from sx_contracts.identity import CanonicalDocument, canonical_json
from sx_corpora import (
    CorpusContractError,
    CorpusName,
    CorpusSnapshot,
    DatasetName,
    SelectionMember,
    manifest_from_dict,
    manifest_to_dict,
)

from sx_catalog_protocol._core import ProtocolTransformError


def _canonical_bytes(snapshot: CorpusSnapshot) -> bytes:
    document = cast("CanonicalDocument", manifest_to_dict(snapshot.manifest))
    return canonical_json(document).encode("utf-8")


def corpus_snapshot_to_proto(value: CorpusSnapshot) -> membership_pb2.CorpusSnapshot:
    """Carry the corpus domain's one canonical manifest and the identity over it."""

    return membership_pb2.CorpusSnapshot(
        name=str(value.name),
        sha256=str(value.sha256),
        canonical_manifest=_canonical_bytes(value),
    )


def corpus_snapshot_from_proto(value: membership_pb2.CorpusSnapshot) -> CorpusSnapshot:
    """Parse one exact manifest and prove the digest it claims.

    Four refusals, in the order a forged message reaches them: bytes that are not
    UTF-8 JSON, bytes the corpus codec will not admit, bytes that are admissible
    but not canonical, and a declared digest that is not the one those bytes hash
    to. `CorpusSnapshot`'s own constructor makes the last refusal, which is the
    point of reconstructing the domain value rather than trusting the message.
    """

    try:
        document = json.loads(value.canonical_manifest)
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ProtocolTransformError("corpus manifest is not canonical UTF-8 JSON") from error
    try:
        manifest = manifest_from_dict(document)
    except ValueError as error:
        raise ProtocolTransformError(f"malformed corpus manifest: {error}") from error
    try:
        snapshot = CorpusSnapshot(
            name=CorpusName(value.name),
            sha256=Sha256Digest(value.sha256),
            manifest=manifest,
        )
    except ValueError as error:
        raise ProtocolTransformError(
            f"corpus digest does not identify its manifest: {error}"
        ) from error
    if value.canonical_manifest != _canonical_bytes(snapshot):
        raise ProtocolTransformError("corpus manifest bytes are not canonical")
    return snapshot


def selection_member_to_proto(value: SelectionMember) -> membership_pb2.SelectionMember:
    return membership_pb2.SelectionMember(dataset=str(value.dataset), segment_id=value.segment_id)


def selection_member_from_proto(value: membership_pb2.SelectionMember) -> SelectionMember:
    """One named member, or a typed refusal — never a half-named one."""

    try:
        return SelectionMember(dataset=DatasetName(value.dataset), segment_id=value.segment_id)
    except CorpusContractError as error:
        raise ProtocolTransformError(f"malformed selection member: {error}") from error
