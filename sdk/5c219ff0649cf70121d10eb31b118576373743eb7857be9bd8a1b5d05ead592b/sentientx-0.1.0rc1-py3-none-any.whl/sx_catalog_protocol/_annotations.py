"""The reviewed-annotation transform: `sx.annotation/v1` as a closed message graph.

Unlike the evaluation evidence next door, an annotation's graph is five
declarations deep with no open-ended document inside it, so the generated
boundary carries the domain's own fields rather than opaque canonical bytes: a
reader of the schema sees the whole fact. The price of that choice is that the
reader must be the one place invariants are re-established, which is why
`annotation_from_proto` reconstructs through the domain constructors instead of
assembling records field by field.

`t_end_ns` is the one lawful absence on this wire (a legacy annotation predates
explicit event ends), so it travels with explicit presence in both directions and
never collapses into a zero.
"""

from __future__ import annotations

from typing import cast

from sentientx.sx.experience.catalog.v1 import annotations_pb2
from sx_contracts import (
    AnnotatedSubtask,
    AnnotationStage,
    EpisodeAnnotation,
    SubtaskAction,
    SubtaskStatus,
)

from sx_catalog_protocol._core import ProtocolTransformError, enum_from_proto, enum_to_proto

_STAGE_PREFIX = "ANNOTATION_STAGE_"
_STATUS_PREFIX = "SUBTASK_STATUS_"


def annotation_stage_to_proto(value: AnnotationStage) -> annotations_pb2.AnnotationStage:
    """Project one domain review stage into the generated closed enum.

    Named separately from the whole annotation because Catalog's stored row keeps
    the stage beside the digest, and reprojecting the entire graph to read one
    field would be the long way round.
    """

    return cast(
        "annotations_pb2.AnnotationStage",
        annotations_pb2.AnnotationStage.Value(f"{_STAGE_PREFIX}{value.name}"),
    )


def annotation_stage_from_proto(value: annotations_pb2.AnnotationStage) -> AnnotationStage:
    """Read one generated review stage back as the domain's own, fail closed.

    The inverse of `annotation_stage_to_proto`, for the same reason it exists
    separately: Catalog's stored row keeps the stage beside the digest, so a
    caller reading its receipt should not have to reproject the whole graph.
    """

    return AnnotationStage(enum_from_proto(annotations_pb2.AnnotationStage, _STAGE_PREFIX, value))


def _subtask_to_proto(value: AnnotatedSubtask) -> annotations_pb2.AnnotatedSubtask:
    subtask = annotations_pb2.AnnotatedSubtask(
        ordinal=value.ordinal,
        t_start_ns=value.t_start_ns,
        status=enum_to_proto(annotations_pb2.SubtaskStatus, _STATUS_PREFIX, value.status.value),
        description=value.description,
        actions=[
            annotations_pb2.SubtaskAction(
                part=action.part,
                skill=action.skill,
                target_items=list(action.target_items),
                target_location=action.target_location,
                description=action.description,
            )
            for action in value.actions
        ],
    )
    if value.t_end_ns is not None:
        subtask.t_end_ns = value.t_end_ns
    return subtask


def annotation_to_proto(value: EpisodeAnnotation) -> annotations_pb2.EpisodeAnnotation:
    """Project one reviewed annotation onto its generated field graph."""

    return annotations_pb2.EpisodeAnnotation(
        episode_id=value.episode_id,
        stage=enum_to_proto(annotations_pb2.AnnotationStage, _STAGE_PREFIX, value.stage.value),
        task=value.task,
        task_description=value.task_description,
        scene=value.scene,
        scene_description=value.scene_description,
        success=value.success,
        subtasks=[_subtask_to_proto(subtask) for subtask in value.subtasks],
    )


def _subtask_from_proto(value: annotations_pb2.AnnotatedSubtask) -> AnnotatedSubtask:
    return AnnotatedSubtask(
        ordinal=value.ordinal,
        t_start_ns=value.t_start_ns,
        t_end_ns=value.t_end_ns if value.HasField("t_end_ns") else None,
        status=SubtaskStatus(
            enum_from_proto(annotations_pb2.SubtaskStatus, _STATUS_PREFIX, value.status)
        ),
        description=value.description,
        actions=tuple(
            SubtaskAction(
                part=action.part,
                skill=action.skill,
                target_items=tuple(action.target_items),
                target_location=action.target_location,
                description=action.description,
            )
            for action in value.actions
        ),
    )


def annotation_from_proto(value: annotations_pb2.EpisodeAnnotation) -> EpisodeAnnotation:
    """Rebuild one reviewed annotation through the domain's own constructors.

    Every law the domain owns — a named body part, ordinals strictly increasing,
    an end that does not precede its start — is re-established here rather than
    trusted from the sender, because a generated message can carry a shape the
    schema admits and the domain does not.
    """

    try:
        return EpisodeAnnotation(
            episode_id=value.episode_id,
            stage=AnnotationStage(
                enum_from_proto(annotations_pb2.AnnotationStage, _STAGE_PREFIX, value.stage)
            ),
            task=value.task,
            task_description=value.task_description,
            scene=value.scene,
            scene_description=value.scene_description,
            success=value.success,
            subtasks=tuple(_subtask_from_proto(subtask) for subtask in value.subtasks),
        )
    except ProtocolTransformError:
        raise
    except ValueError as error:
        raise ProtocolTransformError(f"malformed generated annotation: {error}") from error
