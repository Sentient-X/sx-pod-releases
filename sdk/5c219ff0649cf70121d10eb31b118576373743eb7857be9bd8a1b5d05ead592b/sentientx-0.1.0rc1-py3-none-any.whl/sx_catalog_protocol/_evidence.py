"""The canonical Worlds-evidence document transport.

A ``WorldRun``'s graph reaches 101 declarations, 42 of them Catalog's own
embodiment schema, so the generated boundary carries the evaluation domain's one
canonical document plus the identity derived from it — never a second WorldRun
object model. Both directions are total on valid inputs and refuse anything that
is not exactly the domain's own normal form.
"""

from __future__ import annotations

import json
from typing import cast

from sentientx.sx.experience.catalog.v1 import evidence_pb2
from sx_contracts.identity import CanonicalDocument, canonical_json
from sx_worlds import WorldRun, world_run_from_dict, world_run_to_dict

from sx_catalog_protocol._core import ProtocolTransformError


def _canonical_bytes(run: WorldRun) -> bytes:
    return canonical_json(cast("CanonicalDocument", world_run_to_dict(run))).encode("utf-8")


def world_run_to_proto(value: WorldRun) -> evidence_pb2.WorldRunDocument:
    """Carry the evaluation domain's one canonical run document and derived id."""

    return evidence_pb2.WorldRunDocument(
        run_id=str(value.id),
        canonical_json=_canonical_bytes(value),
    )


def world_run_from_proto(value: evidence_pb2.WorldRunDocument) -> WorldRun:
    """Parse one exact run document and prove the identity it claims.

    Three refusals, in the order a forged message reaches them: bytes that are not
    UTF-8 JSON, bytes the evaluation codec will not admit as a complete run, and
    bytes that are admissible but not canonical or that name another run id. The
    last is what makes ``run_id`` proof — the reader re-derives it and never
    believes the sender.
    """

    try:
        document = json.loads(value.canonical_json)
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ProtocolTransformError("world run is not canonical UTF-8 JSON") from error
    try:
        run = world_run_from_dict(document)
    except ValueError as error:
        raise ProtocolTransformError(f"malformed world run: {error}") from error
    if value.canonical_json != _canonical_bytes(run):
        raise ProtocolTransformError("world run bytes are not canonical")
    if value.run_id != str(run.id):
        raise ProtocolTransformError("world run id disagrees with its canonical bytes")
    return run
