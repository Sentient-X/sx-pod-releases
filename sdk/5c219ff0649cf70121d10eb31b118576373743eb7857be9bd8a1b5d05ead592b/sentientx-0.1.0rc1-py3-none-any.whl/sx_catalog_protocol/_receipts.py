"""Catalog operation receipts, decoded once for synchronous and async clients."""

from datetime import UTC

from sentientx.sx.common.v1 import common_pb2
from sentientx.sx.experience.catalog.v1 import operations_pb2
from sentientx.sx.operations.v1 import operations_pb2 as lifecycle_pb2
from sx_contracts import (
    AcceptedOperation,
    CancellationRequest,
    CancelledOperation,
    FailedOperation,
    IdempotencyKey,
    OperationFailure,
    OperationId,
    OperationKind,
    OperationReceipt,
    PlatformPillar,
    ResourceRef,
    RunningOperation,
    SucceededOperation,
    TraceId,
    UpdateCursor,
)

from sx_catalog_protocol._core import ProtocolTransformError

CATALOG_KINDS_TO_PROTO = {
    OperationKind.REGISTRATION: common_pb2.OPERATION_KIND_REGISTRATION,
    OperationKind.BATCH_REGISTRATION: common_pb2.OPERATION_KIND_BATCH_REGISTRATION,
    OperationKind.ASSET_REGISTRATION: common_pb2.OPERATION_KIND_ASSET_REGISTRATION,
    OperationKind.CAPTURE_REGISTRATION: common_pb2.OPERATION_KIND_CAPTURE_REGISTRATION,
    OperationKind.POLICY_REGISTRATION: common_pb2.OPERATION_KIND_POLICY_REGISTRATION,
    OperationKind.TRAINING_CHECKPOINT_REGISTRATION: (
        common_pb2.OPERATION_KIND_TRAINING_CHECKPOINT_REGISTRATION
    ),
    OperationKind.EXPORT_CREDENTIAL_VALIDATION: (
        common_pb2.OPERATION_KIND_EXPORT_CREDENTIAL_VALIDATION
    ),
    OperationKind.INGEST_CONVERSION: common_pb2.OPERATION_KIND_INGEST_CONVERSION,
    OperationKind.EXPORT: common_pb2.OPERATION_KIND_EXPORT,
    OperationKind.RETENTION: common_pb2.OPERATION_KIND_RETENTION,
    OperationKind.COMPACTION: common_pb2.OPERATION_KIND_COMPACTION,
    OperationKind.REINDEX: common_pb2.OPERATION_KIND_REINDEX,
}
_KINDS_FROM_PROTO = {number: kind for kind, number in CATALOG_KINDS_TO_PROTO.items()}

#: Which Experience operations this owner answers for. Read by the client when it
#: picks the owner an operation reference reattaches through.
CATALOG_OPERATION_KINDS = frozenset(CATALOG_KINDS_TO_PROTO)


def _cancellation(
    value: lifecycle_pb2.AcceptedOperation | lifecycle_pb2.RunningOperation,
) -> CancellationRequest | None:
    if not value.HasField("cancellation"):
        return None
    return CancellationRequest(
        reason=value.cancellation.reason,
        requested_at=value.cancellation.requested_at.ToDatetime(tzinfo=UTC),
    )


def operation_receipt_from_proto(value: operations_pb2.CatalogOperation) -> OperationReceipt:
    """One generated Catalog operation as the canonical five-state receipt."""

    metadata = value.metadata
    ref = metadata.ref
    if ref.pillar != common_pb2.PLATFORM_PILLAR_EXPERIENCE:
        raise ProtocolTransformError("Catalog returned a non-Experience operation")
    try:
        kind = _KINDS_FROM_PROTO[ref.kind]
    except KeyError as error:
        raise ProtocolTransformError("Catalog returned an unsupported operation kind") from error
    operation_id = OperationId(ref.operation_id)
    resource = ResourceRef(
        f"{metadata.resource.owner}/{metadata.resource.kind}/{metadata.resource.id}"
    )
    trace_id = TraceId(metadata.trace_id)
    cursor = UpdateCursor(metadata.cursor)
    key = IdempotencyKey(metadata.idempotency_key) if metadata.HasField("idempotency_key") else None
    created_at = metadata.created_at.ToDatetime(tzinfo=UTC)
    updated_at = metadata.updated_at.ToDatetime(tzinfo=UTC)
    lifecycle = value.lifecycle
    arm = lifecycle.WhichOneof("state")
    if arm == "accepted":
        return AcceptedOperation(
            operation_id,
            PlatformPillar.EXPERIENCE,
            kind,
            resource,
            trace_id,
            cursor=cursor,
            idempotency_key=key,
            cancellation=_cancellation(lifecycle.accepted),
            created_at=created_at,
            updated_at=updated_at,
        )
    if arm == "running":
        return RunningOperation(
            operation_id,
            PlatformPillar.EXPERIENCE,
            kind,
            resource,
            trace_id,
            cursor=cursor,
            idempotency_key=key,
            cancellation=_cancellation(lifecycle.running),
            created_at=created_at,
            updated_at=updated_at,
        )
    if arm == "succeeded":
        return SucceededOperation(
            operation_id,
            PlatformPillar.EXPERIENCE,
            kind,
            resource,
            trace_id,
            cursor=cursor,
            idempotency_key=key,
            created_at=created_at,
            updated_at=updated_at,
            completed_at=lifecycle.succeeded.completed_at.ToDatetime(tzinfo=UTC),
        )
    if arm == "failed":
        failed = lifecycle.failed
        return FailedOperation(
            operation_id,
            PlatformPillar.EXPERIENCE,
            kind,
            resource,
            trace_id,
            OperationFailure(
                failed.failure.code,
                failed.failure.message,
                failed.failure.retryable,
            ),
            cursor=cursor,
            idempotency_key=key,
            created_at=created_at,
            updated_at=updated_at,
            failed_at=failed.failed_at.ToDatetime(tzinfo=UTC),
        )
    if arm == "cancelled":
        cancelled = lifecycle.cancelled
        return CancelledOperation(
            operation_id,
            PlatformPillar.EXPERIENCE,
            kind,
            resource,
            trace_id,
            cancelled.reason,
            cursor=cursor,
            idempotency_key=key,
            created_at=created_at,
            updated_at=updated_at,
            cancelled_at=cancelled.cancelled_at.ToDatetime(tzinfo=UTC),
        )
    raise ProtocolTransformError(f"Catalog returned unknown lifecycle arm {arm!r}")
