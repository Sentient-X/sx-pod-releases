"""The delivery wire: one lease outward, one report inward.

Two values cross this boundary, in one direction each, and both ends need both
directions of the transform — the catalog builds a lease and parses a report, the
executor parses a lease and builds a report — so all four live here rather than
being written twice.

`sx_contracts.delivery` owns the lease and the report as real domain values whose
`__post_init__` proves their law: a lease over no member authorizes no delivery,
each member is named once, two members never flatten onto one delivered key, the
report object is not one of them, and nothing already written belongs to a
non-member. A transform here refuses exactly what those constructors refuse and
adds nothing of its own — which is what makes the protovalidate rules on
`DeliveryLease` a transport restatement of a domain law rather than a second law.
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import UUID

from sentientx.sx.experience.catalog.v1 import deliveries_pb2
from sentientx.sx.operations.v1 import operations_pb2
from sx_contracts import OperationFailure, Sha256Digest
from sx_contracts.delivery import (
    DeliveredArtifact,
    DeliveryCancelled,
    DeliveryComplete,
    DeliveryContractError,
    DeliveryFailed,
    DeliveryLease,
    DeliveryProgress,
    DeliveryReport,
    LeasedMember,
)
from sx_contracts.schemas import SchemaContractError, SchemaId

from sx_catalog_protocol._core import ProtocolTransformError


def _utc(value: datetime) -> datetime:
    return value if value.tzinfo is not None else value.replace(tzinfo=UTC)


def delivered_artifact_to_proto(value: DeliveredArtifact) -> deliveries_pb2.DeliveredArtifact:
    """One object a worker wrote, as the message that says it."""

    return deliveries_pb2.DeliveredArtifact(
        member_id=value.member_id,
        key=value.key,
        sha256=str(value.sha256),
        size_bytes=value.size_bytes,
        source_sha256=str(value.source_sha256),
    )


def delivered_artifact_from_proto(value: deliveries_pb2.DeliveredArtifact) -> DeliveredArtifact:
    """One reported object, reconstructed as the value the catalog checks."""

    try:
        return DeliveredArtifact(
            member_id=value.member_id,
            key=value.key,
            sha256=Sha256Digest(value.sha256),
            size_bytes=value.size_bytes,
            source_sha256=Sha256Digest(value.source_sha256),
        )
    except ValueError as error:
        raise ProtocolTransformError(f"delivered artifact is not canonical: {error}") from error


def delivery_lease_to_proto(value: DeliveryLease) -> deliveries_pb2.DeliveryLease:
    """One delivery, whole: what it is, what it may read, and where it lands."""

    message = deliveries_pb2.DeliveryLease(
        delivery_id=str(value.delivery_id),
        project_id=str(value.project_id),
        executor_id=value.executor_id,
        generation=value.generation,
        delivery_digest=str(value.delivery_digest),
        lineage_digest=str(value.lineage_digest),
        profile=value.profile,
        accepts=str(value.accepts),
        produces=str(value.produces),
        report_key=value.report_key,
        report_url=value.report_url,
    )
    message.members.extend(
        deliveries_pb2.LeasedMember(
            member_id=member.member_id,
            sha256=str(member.sha256),
            size_bytes=member.size_bytes,
            source_url=member.source_url,
            key=member.key,
            upload_url=member.upload_url,
        )
        for member in value.members
    )
    message.delivered.extend(delivered_artifact_to_proto(item) for item in value.delivered)
    message.expires_at.FromDatetime(_utc(value.expires_at))
    return message


def delivery_lease_from_proto(value: deliveries_pb2.DeliveryLease) -> DeliveryLease:
    """The lease an executor was handed, re-proved by the contract's own constructor.

    Nothing is re-checked here that `DeliveryLease.__post_init__` checks: the
    duplicate member, the colliding key, the report object that is also a member and
    the already-written stray are its rules, and restating them would be a second
    place for them to disagree.
    """

    try:
        return DeliveryLease(
            delivery_id=UUID(value.delivery_id),
            project_id=UUID(value.project_id),
            executor_id=value.executor_id,
            generation=value.generation,
            delivery_digest=Sha256Digest(value.delivery_digest),
            lineage_digest=Sha256Digest(value.lineage_digest),
            profile=value.profile,
            accepts=SchemaId(value.accepts),
            produces=SchemaId(value.produces),
            members=tuple(
                LeasedMember(
                    member_id=member.member_id,
                    sha256=Sha256Digest(member.sha256),
                    size_bytes=member.size_bytes,
                    source_url=member.source_url,
                    key=member.key,
                    upload_url=member.upload_url,
                )
                for member in value.members
            ),
            delivered=tuple(delivered_artifact_from_proto(item) for item in value.delivered),
            report_key=value.report_key,
            report_url=value.report_url,
            expires_at=value.expires_at.ToDatetime(tzinfo=UTC),
        )
    except (DeliveryContractError, SchemaContractError, ValueError) as error:
        raise ProtocolTransformError(f"delivery lease is not canonical: {error}") from error


def delivery_report_to_proto(value: DeliveryReport) -> deliveries_pb2.DeliveryReport:
    """What a worker says, tagged by the state it moves the delivery to.

    Total over the union, and the `match` is exhaustive by construction rather than
    by an `else`: a fifth variant added to `DeliveryReport` is a type error here,
    which is where it should be, instead of a report silently encoded as a
    cancellation.
    """

    report = deliveries_pb2.DeliveryReport()
    artifacts = [delivered_artifact_to_proto(item) for item in value.artifacts]
    match value:
        case DeliveryProgress():
            report.progress.artifacts.extend(artifacts)
        case DeliveryComplete():
            report.complete.artifacts.extend(artifacts)
        case DeliveryFailed():
            report.failed.failure.CopyFrom(
                operations_pb2.OperationFailure(
                    code=value.failure.code,
                    message=value.failure.message,
                    retryable=value.failure.retryable,
                )
            )
            report.failed.artifacts.extend(artifacts)
        case DeliveryCancelled():
            report.cancelled.reason = value.reason
            report.cancelled.artifacts.extend(artifacts)
    return report


def delivery_report_from_proto(value: deliveries_pb2.DeliveryReport) -> DeliveryReport:
    """The report as the door acts on it, refusing an arm nothing described.

    The oneof is `required` on the wire, so an absent arm is refused before this
    runs — and refused again here, because this transform is also called in process
    by tests and by any future caller that did not cross a validating transport.
    """

    arm = value.WhichOneof("report")
    if arm == "progress":
        return DeliveryProgress(
            tuple(delivered_artifact_from_proto(item) for item in value.progress.artifacts)
        )
    if arm == "complete":
        return DeliveryComplete(
            tuple(delivered_artifact_from_proto(item) for item in value.complete.artifacts)
        )
    if arm == "failed":
        try:
            failure = OperationFailure(
                code=value.failed.failure.code,
                message=value.failed.failure.message,
                retryable=value.failed.failure.retryable,
            )
        except ValueError as error:
            raise ProtocolTransformError(f"delivery failure is not canonical: {error}") from error
        return DeliveryFailed(
            failure=failure,
            artifacts=tuple(delivered_artifact_from_proto(item) for item in value.failed.artifacts),
        )
    if arm == "cancelled":
        try:
            return DeliveryCancelled(
                reason=value.cancelled.reason,
                artifacts=tuple(
                    delivered_artifact_from_proto(item) for item in value.cancelled.artifacts
                ),
            )
        except ValueError as error:
            raise ProtocolTransformError(
                f"delivery cancellation is not canonical: {error}"
            ) from error
    raise ProtocolTransformError("a delivery report names one of the four states it reached")
