"""Shared strict parsing primitives for Catalog protocol transforms."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Protocol, cast


class ProtocolTransformError(ValueError):
    """A generated message cannot reconstruct the canonical domain value it claims."""


class _EnumType(Protocol):
    def Value(self, name: str) -> int: ...

    def Name(self, number: int) -> str: ...


def mapping(value: object, *, label: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise ProtocolTransformError(f"{label} must be an object")
    raw = cast("Mapping[object, object]", value)
    if not all(isinstance(key, str) for key in raw):
        raise ProtocolTransformError(f"{label} keys must be strings")
    return cast("Mapping[str, object]", raw)


def exact(value: object, fields: set[str], *, label: str) -> Mapping[str, object]:
    document = mapping(value, label=label)
    if set(document) != fields:
        missing = sorted(fields - set(document))
        extra = sorted(set(document) - fields)
        raise ProtocolTransformError(f"{label} fields differ: missing={missing}, extra={extra}")
    return document


def text(document: Mapping[str, object], field: str, *, label: str) -> str:
    value = document[field]
    if not isinstance(value, str) or not value:
        raise ProtocolTransformError(f"{label}.{field} must be non-empty text")
    return value


def number(document: Mapping[str, object], field: str, *, label: str) -> float:
    value = document[field]
    if isinstance(value, bool) or not isinstance(value, int | float):
        raise ProtocolTransformError(f"{label}.{field} must be a number")
    return float(value)


def integer(document: Mapping[str, object], field: str, *, label: str) -> int:
    value = document[field]
    if isinstance(value, bool) or not isinstance(value, int):
        raise ProtocolTransformError(f"{label}.{field} must be an integer")
    return value


def sequence(value: object, *, label: str) -> Sequence[object]:
    if not isinstance(value, Sequence) or isinstance(value, str | bytes | bytearray):
        raise ProtocolTransformError(f"{label} must be a list")
    return cast("Sequence[object]", value)


def enum_to_proto(enum: _EnumType, prefix: str, value: str) -> str:
    name = f"{prefix}{value.upper().replace('.', '_').replace('/', '_')}"
    enum.Value(name)
    return name


def enum_from_proto(enum: _EnumType, prefix: str, value: int) -> str:
    try:
        name = enum.Name(value)
    except ValueError as error:
        raise ProtocolTransformError(f"unknown generated enum value {value}") from error
    if not name.startswith(prefix) or name.endswith("UNSPECIFIED"):
        raise ProtocolTransformError(f"generated enum is not a specified {prefix.rstrip('_')}")
    return name.removeprefix(prefix).lower()
