"""The provider-effect lease and receipt at the Catalog/worker boundary."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import UUID

from sentientx.sx.experience.catalog.v1 import provider_effects_pb2
from sentientx.sx.operations.v1 import operations_pb2
from sx_contracts import IdempotencyKey, OperationFailure, Sha256Digest
from sx_contracts.effects import (
    AmbiguityRecovery,
    CredentialSlot,
    EffectAmbiguous,
    EffectContractError,
    EffectFailed,
    EffectOperation,
    EffectSettlement,
    EffectSucceeded,
    ProviderAdmission,
    ProviderLease,
    ProviderLeaseRequest,
    ProviderName,
    ProviderReceipt,
    RateWindow,
    UsageFact,
    UsageUnit,
    ledger_state,
)
from sx_contracts.pipelines import Effects

from sx_catalog_protocol._core import ProtocolTransformError

_EFFECT_TO_PROTO = {
    Effects.READ_ONLY: provider_effects_pb2.PROVIDER_EFFECT_CLASS_READ_ONLY,
    Effects.PROVIDER_IDEMPOTENT_MUTATION: (
        provider_effects_pb2.PROVIDER_EFFECT_CLASS_PROVIDER_IDEMPOTENT_MUTATION
    ),
    Effects.RECONCILED_MUTATION: provider_effects_pb2.PROVIDER_EFFECT_CLASS_RECONCILED_MUTATION,
}
_EFFECT_FROM_PROTO = {encoded: value for value, encoded in _EFFECT_TO_PROTO.items()}
_USAGE_TO_PROTO = {
    UsageUnit.REQUESTS: provider_effects_pb2.PROVIDER_USAGE_UNIT_REQUESTS,
    UsageUnit.INPUT_TOKENS: provider_effects_pb2.PROVIDER_USAGE_UNIT_INPUT_TOKENS,
    UsageUnit.OUTPUT_TOKENS: provider_effects_pb2.PROVIDER_USAGE_UNIT_OUTPUT_TOKENS,
    UsageUnit.CACHED_INPUT_TOKENS: provider_effects_pb2.PROVIDER_USAGE_UNIT_CACHED_INPUT_TOKENS,
}
_USAGE_FROM_PROTO = {encoded: value for value, encoded in _USAGE_TO_PROTO.items()}
_RECOVERY_TO_PROTO = {
    AmbiguityRecovery.REPLAY_UNDER_KEY: (
        provider_effects_pb2.PROVIDER_EFFECT_RECOVERY_REPLAY_UNDER_KEY
    ),
    AmbiguityRecovery.PROVIDER_QUERY: provider_effects_pb2.PROVIDER_EFFECT_RECOVERY_PROVIDER_QUERY,
    AmbiguityRecovery.UNRECONCILABLE: (
        provider_effects_pb2.PROVIDER_EFFECT_RECOVERY_UNRECONCILABLE
    ),
}
_RECOVERY_FROM_PROTO = {encoded: value for value, encoded in _RECOVERY_TO_PROTO.items()}


def _utc(value: datetime) -> datetime:
    return value if value.tzinfo is not None else value.replace(tzinfo=UTC)


def _usage_to_proto(value: UsageFact) -> provider_effects_pb2.ProviderUsageFact:
    return provider_effects_pb2.ProviderUsageFact(
        unit=_USAGE_TO_PROTO[value.unit], quantity=value.quantity
    )


def _usage_from_proto(value: provider_effects_pb2.ProviderUsageFact) -> UsageFact:
    try:
        return UsageFact(unit=_USAGE_FROM_PROTO[value.unit], quantity=value.quantity)
    except (KeyError, ValueError) as error:
        raise ProtocolTransformError(f"provider usage is not canonical: {error}") from error


def provider_effect_lease_request_to_proto(
    value: ProviderLeaseRequest,
) -> provider_effects_pb2.ProviderEffectLeaseRequest:
    try:
        effects = _EFFECT_TO_PROTO[value.effects]
    except KeyError as error:
        raise ProtocolTransformError("a provider effect must make an external call") from error
    return provider_effects_pb2.ProviderEffectLeaseRequest(
        credential_slot=str(value.credential_slot),
        operation=str(value.operation),
        call_budget_s=value.call_budget_s,
        idempotency_key=str(value.idempotency_key),
        effects=effects,
    )


def provider_effect_lease_request_from_proto(
    value: provider_effects_pb2.ProviderEffectLeaseRequest,
) -> ProviderLeaseRequest:
    try:
        return ProviderLeaseRequest(
            credential_slot=CredentialSlot(value.credential_slot),
            operation=EffectOperation(value.operation),
            call_budget_s=value.call_budget_s,
            idempotency_key=IdempotencyKey(value.idempotency_key),
            effects=_EFFECT_FROM_PROTO[value.effects],
        )
    except (EffectContractError, KeyError, ValueError) as error:
        raise ProtocolTransformError(f"provider lease request is not canonical: {error}") from error


def provider_effect_lease_to_proto(
    value: ProviderLease,
) -> provider_effects_pb2.ProviderEffectLease:
    message = provider_effects_pb2.ProviderEffectLease(
        effect_id=str(value.effect_id),
        provider=str(value.provider),
        credential_slot=str(value.credential_slot),
        operation=str(value.operation),
        idempotency_key=str(value.idempotency_key),
        attempt=value.attempt,
        window=provider_effects_pb2.ProviderRateWindow(
            window_s=value.window.window_s,
            granted=value.window.granted,
            limit=value.window.limit,
        ),
        outstanding=value.outstanding,
        max_outstanding=value.max_outstanding,
    )
    message.expires_at.FromDatetime(_utc(value.expires_at))
    return message


def provider_effect_lease_from_proto(
    value: provider_effects_pb2.ProviderEffectLease,
) -> ProviderLease:
    try:
        if not value.HasField("window") or not value.HasField("expires_at"):
            raise EffectContractError("a provider lease names its window and expiry")
        return ProviderLease(
            effect_id=UUID(value.effect_id),
            provider=ProviderName(value.provider),
            credential_slot=CredentialSlot(value.credential_slot),
            operation=EffectOperation(value.operation),
            idempotency_key=IdempotencyKey(value.idempotency_key),
            attempt=value.attempt,
            window=RateWindow(
                window_s=value.window.window_s,
                granted=value.window.granted,
                limit=value.window.limit,
            ),
            outstanding=value.outstanding,
            max_outstanding=value.max_outstanding,
            expires_at=value.expires_at.ToDatetime(tzinfo=UTC),
        )
    except (EffectContractError, ValueError) as error:
        raise ProtocolTransformError(f"provider lease is not canonical: {error}") from error


def provider_effect_settlement_to_proto(
    value: EffectSettlement,
) -> provider_effects_pb2.ProviderEffectSettlement:
    message = provider_effects_pb2.ProviderEffectSettlement()
    match value:
        case EffectSucceeded():
            message.succeeded.usage.extend(_usage_to_proto(fact) for fact in value.usage)
            message.succeeded.provider_response_id = value.provider_response_id
            message.succeeded.response_sha256 = str(value.response_sha256)
        case EffectFailed():
            message.failed.usage.extend(_usage_to_proto(fact) for fact in value.usage)
            message.failed.failure.CopyFrom(
                operations_pb2.OperationFailure(
                    code=value.failure.code,
                    message=value.failure.message,
                    retryable=value.failure.retryable,
                )
            )
        case EffectAmbiguous():
            message.ambiguous.usage.extend(_usage_to_proto(fact) for fact in value.usage)
            message.ambiguous.failure.CopyFrom(
                operations_pb2.OperationFailure(
                    code=value.failure.code,
                    message=value.failure.message,
                    retryable=value.failure.retryable,
                )
            )
            message.ambiguous.recovery = _RECOVERY_TO_PROTO[value.recovery]
            message.ambiguous.provider_handle = value.provider_handle
    return message


def _failure(value: operations_pb2.OperationFailure) -> OperationFailure:
    return OperationFailure(value.code, value.message, value.retryable)


def provider_effect_settlement_from_proto(
    value: provider_effects_pb2.ProviderEffectSettlement,
) -> EffectSettlement:
    try:
        arm = value.WhichOneof("outcome")
        if arm == "succeeded":
            return EffectSucceeded(
                usage=tuple(_usage_from_proto(fact) for fact in value.succeeded.usage),
                provider_response_id=value.succeeded.provider_response_id,
                response_sha256=Sha256Digest(value.succeeded.response_sha256),
            )
        if arm == "failed":
            if not value.failed.HasField("failure"):
                raise EffectContractError("a failed effect names its failure")
            return EffectFailed(
                usage=tuple(_usage_from_proto(fact) for fact in value.failed.usage),
                failure=_failure(value.failed.failure),
            )
        if arm == "ambiguous":
            if not value.ambiguous.HasField("failure"):
                raise EffectContractError("an ambiguous effect names its failure")
            return EffectAmbiguous(
                usage=tuple(_usage_from_proto(fact) for fact in value.ambiguous.usage),
                failure=_failure(value.ambiguous.failure),
                recovery=_RECOVERY_FROM_PROTO[value.ambiguous.recovery],
                provider_handle=value.ambiguous.provider_handle,
            )
        raise EffectContractError("a provider settlement names exactly one outcome")
    except (EffectContractError, KeyError, ValueError) as error:
        raise ProtocolTransformError(f"provider settlement is not canonical: {error}") from error


def provider_effect_receipt_to_proto(
    value: ProviderReceipt,
) -> provider_effects_pb2.ProviderEffectReceipt:
    message = provider_effects_pb2.ProviderEffectReceipt(
        effect_id=str(value.effect_id),
        provider=str(value.provider),
        credential_slot=str(value.credential_slot),
        operation=str(value.operation),
        idempotency_key=str(value.idempotency_key),
        attempt=value.attempt,
        settlement=provider_effect_settlement_to_proto(value.settlement),
    )
    message.granted_at.FromDatetime(_utc(value.granted_at))
    message.settled_at.FromDatetime(_utc(value.settled_at))
    return message


def provider_effect_receipt_from_proto(
    value: provider_effects_pb2.ProviderEffectReceipt,
) -> ProviderReceipt:
    try:
        if not value.HasField("settlement"):
            raise EffectContractError("a provider receipt names its settlement")
        if not value.HasField("granted_at") or not value.HasField("settled_at"):
            raise EffectContractError("a provider receipt names both timestamps")
        settlement = provider_effect_settlement_from_proto(value.settlement)
        return ProviderReceipt(
            effect_id=UUID(value.effect_id),
            provider=ProviderName(value.provider),
            credential_slot=CredentialSlot(value.credential_slot),
            operation=EffectOperation(value.operation),
            idempotency_key=IdempotencyKey(value.idempotency_key),
            attempt=value.attempt,
            settlement=settlement,
            granted_at=value.granted_at.ToDatetime(tzinfo=UTC),
            settled_at=value.settled_at.ToDatetime(tzinfo=UTC),
            state=ledger_state(settlement),
        )
    except (EffectContractError, ValueError) as error:
        raise ProtocolTransformError(f"provider receipt is not canonical: {error}") from error


def provider_effect_admission_to_proto(
    value: ProviderAdmission,
) -> provider_effects_pb2.ProviderEffectAdmission:
    if isinstance(value, ProviderLease):
        return provider_effects_pb2.ProviderEffectAdmission(
            lease=provider_effect_lease_to_proto(value)
        )
    return provider_effects_pb2.ProviderEffectAdmission(
        receipt=provider_effect_receipt_to_proto(value)
    )


def provider_effect_admission_from_proto(
    value: provider_effects_pb2.ProviderEffectAdmission,
) -> ProviderAdmission:
    arm = value.WhichOneof("admission")
    if arm == "lease":
        return provider_effect_lease_from_proto(value.lease)
    if arm == "receipt":
        return provider_effect_receipt_from_proto(value.receipt)
    raise ProtocolTransformError("a provider admission is either a lease or a receipt")
