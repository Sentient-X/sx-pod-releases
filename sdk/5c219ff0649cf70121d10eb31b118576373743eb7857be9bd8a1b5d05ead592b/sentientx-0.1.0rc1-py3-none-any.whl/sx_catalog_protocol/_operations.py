"""Transforms for Catalog's durable-operation boundary.

Three families live here, each a total function on valid input and a typed
refusal on anything else:

* the deployable policy, whose graph is closed and tiny enough that the wire
  carries the value itself rather than its canonical bytes;
* the sealed capture receipt, whose canonical ``sx.capture-receipt/v2`` codec
  already owns its identity, so the wire carries exactly those bytes;
* the terminal ledger documents a succeeded Catalog operation records, parsed
  into one closed result arm each.

The result parsers take the ledger's own ``outputs`` mapping because that is
what the owner stores. They refuse a document that is missing, mistyped, or
carrying fields this arm does not name, so a corrupted row fails closed instead
of being echoed onto a public wire.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from datetime import datetime
from typing import cast

from sentientx.sx.common.v1 import common_pb2
from sentientx.sx.experience.catalog.v1 import operations_pb2
from sx_contracts.capture import (
    CaptureArtifactFile,
    CaptureArtifactFormat,
    CaptureArtifactManifest,
    CaptureContractError,
    CaptureSessionReceipt,
    EpisodeId,
    capture_receipt_from_dict,
    capture_receipt_to_dict,
)
from sx_contracts.content import ArtifactId, ContentRef, ContentRefError, Sha256Digest
from sx_contracts.decisions import DecisionError, ReplanInterval
from sx_contracts.identity import CanonicalDocument, canonical_json
from sx_contracts.images import BoundImage, ImageContractError, ImageDigest, ImageName
from sx_contracts.policies import (
    DEPLOYABLE_POLICY_SCHEMA_VERSION,
    DeployablePolicy,
    DeployablePolicyContractError,
    InnerAgent,
    PlacementDemand,
    VlaPolicy,
)
from sx_contracts.tasks import TaskContractRef

from sx_catalog_protocol._core import (
    ProtocolTransformError,
    exact,
    integer,
    number,
    sequence,
    text,
)
from sx_catalog_protocol._tasks import task_contract_ref_to_proto

_PLACEMENT_TO_PROTO = {
    PlacementDemand.EDGE: operations_pb2.PLACEMENT_DEMAND_EDGE,
    PlacementDemand.EDGE_PREFERRED: operations_pb2.PLACEMENT_DEMAND_EDGE_PREFERRED,
}
_PLACEMENT_FROM_PROTO = {wire: demand for demand, wire in _PLACEMENT_TO_PROTO.items()}


# --- content identity --------------------------------------------------------


def content_ref_to_proto(value: ContentRef) -> common_pb2.ContentRef:
    """Project one governed artifact identity onto the shared wire ref."""

    return common_pb2.ContentRef(artifact_id=str(value.artifact_id), sha256=str(value.sha256))


def content_ref_from_proto(value: common_pb2.ContentRef) -> ContentRef:
    """Parse one shared wire ref back into the canonical content identity."""

    try:
        return ContentRef(ArtifactId(value.artifact_id), Sha256Digest(value.sha256))
    except ContentRefError as error:
        raise ProtocolTransformError(f"malformed content ref: {error}") from error


# --- the deployable policy ---------------------------------------------------


def deployable_policy_to_proto(value: DeployablePolicy) -> operations_pb2.DeployablePolicy:
    """Project the complete sx.deployable-policy/v5 value field for field."""

    message = operations_pb2.DeployablePolicy(
        schema_version=DEPLOYABLE_POLICY_SCHEMA_VERSION,
        artifact=content_ref_to_proto(value.artifact),
        vla=operations_pb2.VlaPolicy(
            artifact=content_ref_to_proto(value.vla.artifact),
            checkpoint=content_ref_to_proto(value.vla.checkpoint),
        ),
    )
    agent = value.inner_agent
    if agent is not None:
        message.inner_agent.CopyFrom(
            operations_pb2.InnerAgent(
                bundle=content_ref_to_proto(agent.bundle),
                runtime=operations_pb2.PolicyRuntimeImage(
                    name=str(agent.runtime.name),
                    digest=str(agent.runtime.digest),
                ),
                demand=_PLACEMENT_TO_PROTO[agent.demand],
                replan_interval=operations_pb2.PolicyReplanInterval(
                    chunks=agent.replan_interval.chunks,
                    wall_ms=agent.replan_interval.wall_ms,
                ),
                decision_timeout_ms=agent.decision_timeout_ms,
            )
        )
    return message


def deployable_policy_from_proto(value: operations_pb2.DeployablePolicy) -> DeployablePolicy:
    """Reconstruct one deployable policy and re-run every domain invariant."""

    if value.schema_version != DEPLOYABLE_POLICY_SCHEMA_VERSION:
        raise ProtocolTransformError(
            f"unsupported deployable-policy schema: {value.schema_version!r}"
        )
    vla = VlaPolicy(
        content_ref_from_proto(value.vla.artifact),
        content_ref_from_proto(value.vla.checkpoint),
    )
    if not value.HasField("inner_agent"):
        return DeployablePolicy(content_ref_from_proto(value.artifact), vla, None)
    agent = value.inner_agent
    demand = _PLACEMENT_FROM_PROTO.get(agent.demand)
    if demand is None:
        raise ProtocolTransformError(f"unknown inner-agent placement demand {agent.demand}")
    try:
        runtime = BoundImage(ImageName(agent.runtime.name), ImageDigest(agent.runtime.digest))
        replan = ReplanInterval(agent.replan_interval.chunks, agent.replan_interval.wall_ms)
        inner = InnerAgent(
            bundle=content_ref_from_proto(agent.bundle),
            runtime=runtime,
            demand=demand,
            replan_interval=replan,
            decision_timeout_ms=agent.decision_timeout_ms,
        )
    except (ImageContractError, DecisionError, DeployablePolicyContractError) as error:
        raise ProtocolTransformError(f"malformed inner agent: {error}") from error
    return DeployablePolicy(content_ref_from_proto(value.artifact), vla, inner)


def deployable_policy_resource_to_proto(
    *,
    entry_id: str,
    name: str,
    policy: DeployablePolicy,
    size_bytes: int,
    task: TaskContractRef,
    embodiment_name: str,
    embodiment_id: str,
    action_interface_name: str,
    action_interface_id: str,
    dataset: str,
    created_at: datetime,
) -> operations_pb2.DeployablePolicyResource:
    """Project one registered policy together with the revisions it was admitted against."""

    resource = operations_pb2.DeployablePolicyResource(
        id=entry_id,
        name=name,
        policy=deployable_policy_to_proto(policy),
        size_bytes=size_bytes,
        task=task_contract_ref_to_proto(task),
        embodiment_name=embodiment_name,
        embodiment_id=embodiment_id,
        action_interface_name=action_interface_name,
        action_interface_id=action_interface_id,
        dataset=dataset,
    )
    resource.created_at.FromDatetime(created_at)
    return resource


def training_checkpoint_to_proto(
    *,
    entry_id: str,
    name: str,
    checkpoint: ContentRef,
    size_bytes: int,
    corpus: str,
    corpus_sha256: str,
    created_at: datetime,
) -> operations_pb2.TrainingCheckpoint:
    """Project one foundation checkpoint bound to the exact corpus behind it."""

    message = operations_pb2.TrainingCheckpoint(
        id=entry_id,
        name=name,
        checkpoint=content_ref_to_proto(checkpoint),
        size_bytes=size_bytes,
        corpus=corpus,
        corpus_sha256=corpus_sha256,
    )
    message.created_at.FromDatetime(created_at)
    return message


# --- the sealed capture receipt ----------------------------------------------


_CAPTURE_FORMAT_FROM_PROTO = {
    operations_pb2.CAPTURE_ARTIFACT_FORMAT_MCAP: CaptureArtifactFormat.MCAP,
    operations_pb2.CAPTURE_ARTIFACT_FORMAT_LEROBOT_V3_TAR: CaptureArtifactFormat.LEROBOT_V3_TAR,
    operations_pb2.CAPTURE_ARTIFACT_FORMAT_SIMULATION_JSON: CaptureArtifactFormat.SIMULATION_JSON,
}


def capture_manifest_from_proto(
    value: operations_pb2.CaptureArtifactManifest,
) -> CaptureArtifactManifest:
    """Reconstruct one raw-artifact manifest and re-run its own byte laws."""

    artifact_format = _CAPTURE_FORMAT_FROM_PROTO.get(value.format)
    if artifact_format is None:
        raise ProtocolTransformError("capture artifact format is unspecified")
    try:
        return CaptureArtifactManifest(
            schema_version=value.schema_version,
            format=artifact_format,
            sha256=Sha256Digest(value.sha256),
            size_bytes=value.size_bytes,
            episode_ids=tuple(EpisodeId(episode) for episode in value.episode_ids),
            files=tuple(
                CaptureArtifactFile(item.path, Sha256Digest(item.sha256), item.size_bytes)
                for item in value.files
            ),
        )
    except CaptureContractError as error:
        raise ProtocolTransformError(f"malformed capture artifact manifest: {error}") from error


def capture_receipt_to_canonical_json(receipt: CaptureSessionReceipt) -> bytes:
    """The exact canonical bytes whose digest is the receipt's identity."""

    return canonical_json(cast("CanonicalDocument", capture_receipt_to_dict(receipt))).encode(
        "utf-8"
    )


def capture_receipt_from_canonical_json(payload: bytes) -> CaptureSessionReceipt:
    """Parse one sealed receipt and prove the bytes are its own normal form.

    Three refusals in the order a forged message reaches them: bytes that are
    not UTF-8 JSON, bytes the capture codec will not admit as a complete sealed
    receipt, and bytes that are admissible but not canonical. The last is what
    keeps the digest a fact about the receipt rather than about the sender.
    """

    try:
        document = json.loads(payload)
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ProtocolTransformError("capture receipt is not canonical UTF-8 JSON") from error
    try:
        receipt = capture_receipt_from_dict(document)
    except (CaptureContractError, ValueError) as error:
        raise ProtocolTransformError(f"malformed capture receipt: {error}") from error
    if payload != capture_receipt_to_canonical_json(receipt):
        raise ProtocolTransformError("capture receipt bytes are not canonical")
    return receipt


# --- terminal ledger documents -----------------------------------------------


def segment_result_to_proto(
    dataset_id: str, outputs: Mapping[str, object]
) -> operations_pb2.CatalogSegmentRef:
    """One registered segment: its dataset, its id, and its live base digest.

    ``base_sha256`` is the overlay-aware spelling the ledger writes for a layer
    registration and falls back to ``sha256`` for a base registration, which is
    the same reading the REST result route performed.
    """

    segment_id = text(outputs, "segment_id", label="segment registration")
    digest = outputs.get("base_sha256", outputs.get("sha256"))
    if not isinstance(digest, str) or not digest:
        raise ProtocolTransformError("segment registration has no base digest")
    return operations_pb2.CatalogSegmentRef(
        dataset_id=dataset_id,
        segment_id=segment_id,
        base_sha256=digest,
    )


def batch_result_to_proto(
    outputs: Mapping[str, object],
) -> operations_pb2.BatchRegistrationResult:
    """One immutable batch and the exact segments it became."""

    batch_id = text(outputs, "batch_id", label="batch registration")
    members = sequence(outputs.get("segment_ids"), label="batch registration segment_ids")
    segment_ids: list[str] = []
    for member in members:
        if not isinstance(member, str) or not member:
            raise ProtocolTransformError("batch registration member is not a segment id")
        segment_ids.append(member)
    return operations_pb2.BatchRegistrationResult(batch_id=batch_id, segment_ids=segment_ids)


def asset_result_to_proto(
    outputs: Mapping[str, object],
) -> operations_pb2.AssetRegistrationResult:
    """One promoted, content-addressed embodiment asset."""

    document = exact(outputs, {"sha256", "object_key"}, label="asset registration")
    return operations_pb2.AssetRegistrationResult(
        sha256=text(document, "sha256", label="asset registration"),
        object_key=text(document, "object_key", label="asset registration"),
    )


def capture_result_to_proto(
    outputs: Mapping[str, object],
) -> operations_pb2.CaptureRegistrationResult:
    """One sealed capture session admitted whole."""

    document = exact(
        outputs,
        {"session_id", "receipt_sha256", "receipt_key"},
        label="capture registration",
    )
    return operations_pb2.CaptureRegistrationResult(
        session_id=text(document, "session_id", label="capture registration"),
        receipt_sha256=text(document, "receipt_sha256", label="capture registration"),
        receipt_key=text(document, "receipt_key", label="capture registration"),
    )


def export_result_to_proto(outputs: Mapping[str, object]) -> operations_pb2.ExportResult:
    """One completed delivery into a customer bucket."""

    document = exact(
        outputs,
        {"segments", "bucket", "kind", "credential_id", "standard_conversion_sha256"},
        label="export",
    )
    return operations_pb2.ExportResult(
        segments=integer(document, "segments", label="export"),
        bucket=text(document, "bucket", label="export"),
        target_kind=text(document, "kind", label="export"),
        credential_id=text(document, "credential_id", label="export"),
        standard_conversion_sha256=text(document, "standard_conversion_sha256", label="export"),
    )


def retention_result_to_proto(outputs: Mapping[str, object]) -> operations_pb2.RetentionResult:
    """One scratch sweep; `deleted` counts objects queued for human deletion."""

    document = exact(outputs, {"deleted", "ttl_days"}, label="retention")
    return operations_pb2.RetentionResult(
        deleted=integer(document, "deleted", label="retention"),
        ttl_days=integer(document, "ttl_days", label="retention"),
    )


def export_credential_result_to_proto(
    outputs: Mapping[str, object],
) -> operations_pb2.ExportCredentialValidationResult:
    """One customer export credential proved usable against its provider."""

    document = exact(outputs, {"credential_id", "state"}, label="export credential validation")
    return operations_pb2.ExportCredentialValidationResult(
        credential_id=text(document, "credential_id", label="export credential validation"),
        state=text(document, "state", label="export credential validation"),
    )


def ingest_conversion_result_to_proto(
    outputs: Mapping[str, object],
) -> operations_pb2.IngestConversionResult:
    """One Ray conversion receipt, carried as the external engine's own bytes."""

    document = exact(outputs, {"ray_submission_id", "result"}, label="ingest conversion")
    receipt = document["result"]
    if not isinstance(receipt, Mapping | list):
        raise ProtocolTransformError("ingest conversion receipt is not a JSON document")
    return operations_pb2.IngestConversionResult(
        ray_submission_id=text(document, "ray_submission_id", label="ingest conversion"),
        receipt_json=canonical_json(cast("CanonicalDocument", receipt)).encode("utf-8"),
    )


def semantic_index_result_to_proto(
    outputs: Mapping[str, object],
) -> operations_pb2.SemanticIndexResult:
    """One segment's semantic index build and the tables it staged."""

    label = "semantic index"
    document = exact(
        outputs,
        {
            "frame_count",
            "texts_rows",
            "gpu_seconds",
            "embedder_version",
            "detector_version",
            "staged",
        },
        label=label,
    )
    staged: list[operations_pb2.SemanticStagedTable] = []
    for entry in sequence(document["staged"], label=f"{label} staged"):
        table = exact(entry, {"table", "rows", "size_bytes"}, label=f"{label} staged table")
        staged.append(
            operations_pb2.SemanticStagedTable(
                table=text(table, "table", label=f"{label} staged table"),
                rows=integer(table, "rows", label=f"{label} staged table"),
                size_bytes=integer(table, "size_bytes", label=f"{label} staged table"),
            )
        )
    return operations_pb2.SemanticIndexResult(
        frame_count=integer(document, "frame_count", label=label),
        texts_rows=integer(document, "texts_rows", label=label),
        gpu_seconds=number(document, "gpu_seconds", label=label),
        embedder_version=integer(document, "embedder_version", label=label),
        detector_version=integer(document, "detector_version", label=label),
        staged=staged,
    )


def semantic_sweep_result_to_proto(
    outputs: Mapping[str, object],
) -> operations_pb2.SemanticSweepResult:
    """One pass of a project's semantic-index backlog."""

    document = exact(outputs, {"enqueued", "remaining"}, label="semantic sweep")
    return operations_pb2.SemanticSweepResult(
        enqueued=integer(document, "enqueued", label="semantic sweep"),
        remaining=integer(document, "remaining", label="semantic sweep"),
    )


def semantic_task_map_result_to_proto(
    outputs: Mapping[str, object],
) -> operations_pb2.SemanticTaskMapResult:
    """One rebuild of a project's task map and semantic atlas."""

    label = "semantic task map"
    document = exact(
        outputs,
        {"episodes", "clusters", "atlas_points", "atlas_frames_total"},
        label=label,
    )
    return operations_pb2.SemanticTaskMapResult(
        episodes=integer(document, "episodes", label=label),
        clusters=integer(document, "clusters", label=label),
        atlas_points=integer(document, "atlas_points", label=label),
        atlas_frames_total=integer(document, "atlas_frames_total", label=label),
    )
