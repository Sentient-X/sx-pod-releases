"""Canonical application and capability-approval document transports."""

from __future__ import annotations

import json
from typing import cast

from sentientx.sx.experience.catalog.v1 import applications_pb2
from sx_autonomy import (
    ApplicationQualification,
    CapabilityApproval,
    application_qualification_from_dict,
    application_qualification_to_dict,
    capability_approval_from_dict,
    capability_approval_to_dict,
)
from sx_contracts import (
    RobotApplication,
    robot_application_from_dict,
    robot_application_to_dict,
)
from sx_contracts.identity import CanonicalDocument, canonical_json

from sx_catalog_protocol._core import ProtocolTransformError


def _parse_document(value: bytes, *, label: str) -> object:
    try:
        return json.loads(value)
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ProtocolTransformError(f"{label} is not canonical UTF-8 JSON") from error


def _canonical_bytes(value: dict[str, object]) -> bytes:
    return canonical_json(cast("CanonicalDocument", value)).encode("utf-8")


def robot_application_to_proto(
    value: RobotApplication,
) -> applications_pb2.RobotApplicationDocument:
    """Carry the application domain's one canonical document and derived ref."""

    return applications_pb2.RobotApplicationDocument(
        application_ref=str(value.ref),
        canonical_application=_canonical_bytes(robot_application_to_dict(value)),
    )


def robot_application_from_proto(
    value: applications_pb2.RobotApplicationDocument,
) -> RobotApplication:
    """Parse one exact application document and prove its claimed identity."""

    try:
        application = robot_application_from_dict(
            _parse_document(value.canonical_application, label="robot application")
        )
    except ValueError as error:
        raise ProtocolTransformError(f"malformed robot application: {error}") from error
    expected = _canonical_bytes(robot_application_to_dict(application))
    if value.canonical_application != expected:
        raise ProtocolTransformError("robot application bytes are not canonical")
    if value.application_ref != str(application.ref):
        raise ProtocolTransformError("robot application ref disagrees with its canonical bytes")
    return application


def application_qualification_to_proto(
    value: ApplicationQualification,
) -> applications_pb2.ApplicationQualificationDocument:
    """Carry the qualification domain's one canonical document and derived ref."""

    return applications_pb2.ApplicationQualificationDocument(
        qualification_ref=str(value.ref),
        canonical_qualification=_canonical_bytes(application_qualification_to_dict(value)),
    )


def application_qualification_from_proto(
    value: applications_pb2.ApplicationQualificationDocument,
) -> ApplicationQualification:
    """Parse one qualification and prove its ref against its embedded application."""

    try:
        qualification = application_qualification_from_dict(
            _parse_document(value.canonical_qualification, label="application qualification")
        )
    except ValueError as error:
        raise ProtocolTransformError(f"malformed application qualification: {error}") from error
    expected = _canonical_bytes(application_qualification_to_dict(qualification))
    if value.canonical_qualification != expected:
        raise ProtocolTransformError("application qualification bytes are not canonical")
    if value.qualification_ref != str(qualification.ref):
        raise ProtocolTransformError(
            "application qualification ref disagrees with its canonical bytes"
        )
    return qualification


def capability_approval_to_proto(
    value: CapabilityApproval,
) -> applications_pb2.CapabilityApprovalDocument:
    """Carry the approval domain's complete canonical evidence and derived ref."""

    return applications_pb2.CapabilityApprovalDocument(
        approval_ref=str(value.ref),
        canonical_approval=_canonical_bytes(capability_approval_to_dict(value)),
    )


def capability_approval_from_proto(
    value: applications_pb2.CapabilityApprovalDocument,
) -> CapabilityApproval:
    """Parse an approval and prove its reference against every embedded fact."""

    try:
        approval = capability_approval_from_dict(
            _parse_document(value.canonical_approval, label="capability approval")
        )
    except ValueError as error:
        raise ProtocolTransformError(f"malformed capability approval: {error}") from error
    expected = _canonical_bytes(capability_approval_to_dict(approval))
    if value.canonical_approval != expected:
        raise ProtocolTransformError("capability approval bytes are not canonical")
    if value.approval_ref != str(approval.ref):
        raise ProtocolTransformError("capability approval ref disagrees with its canonical bytes")
    return approval
