"""The introspection wire contract between the sx_authd service and its consumers.

The service serializes every ``/api/introspect`` response through
:func:`introspection_to_json`; :class:`AuthClient` parses with
:func:`parse_introspection`. This module IS the contract — both sides type
against it, and the golden-JSON test pins the shape. Roles travel as strings
(each audience owns its own vocabulary); consumers narrow to their own StrEnum
and drop unknown roles — fail closed, never widen.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime
from enum import StrEnum
from typing import NewType
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, ValidationError
from sx_contracts import Sha256Digest


class OrgKind(StrEnum):
    """The typed org generalization: apps map onto their own vocabularies
    (supervisors: internal→sentient, customer→deployment_company, vendor→teleop_vendor)."""

    INTERNAL = "internal"
    CUSTOMER = "customer"
    VENDOR = "vendor"


class OrganizationRole(StrEnum):
    OWNER = "owner"
    ADMIN = "admin"
    BILLING_ADMIN = "billing_admin"
    MEMBER = "member"


# A turn keeps the historical four-hour default. Finite owner workflows may request
# longer authority, but never beyond the Console's maximum 30-day campaign budget plus
# a small admission/start grace. Auth still revalidates both live credentials on every
# use, so this is an upper bound on the opaque reference rather than a bearer-token TTL.
DEFAULT_DELEGATION_TTL_S = 4 * 60 * 60
MAX_DELEGATION_TTL_S = 30 * 24 * 60 * 60 + 5 * 60


class PrincipalKind(StrEnum):
    USER = "user"
    SERVICE = "service"


class CredentialKind(StrEnum):
    API_KEY = "api_key"
    SESSION = "session"


class BillingAdmissionState(StrEnum):
    UNCONFIGURED = "unconfigured"
    UNCAPPED = "uncapped"
    ALLOWED = "allowed"
    BLOCKED = "blocked"


class ProjectBillingAdmission(BaseModel):
    """Lago's live commercial answer for starting new billable work."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    project_id: UUID
    state: BillingAdmissionState
    allowed: bool
    current_amount_cents: int | None = None
    hard_limit_cents: int | None = None
    period_end: datetime | None = None


class IntrospectionShapeError(RuntimeError):
    """An introspection body violated the wire contract (never treated as inactive)."""


ProjectId = NewType("ProjectId", UUID)
DEV_PROJECT_ID = ProjectId(UUID(int=0))


class OrgRef(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    slug: str
    kind: OrgKind


class ProjectRef(BaseModel):
    """One centrally governed project.

    ``org`` is the resource-owning organization and may differ from a
    principal's home organization for an explicit cross-organization binding.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: ProjectId
    slug: str
    org: OrgRef


class OrganizationMembership(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    organization: OrgRef
    role: OrganizationRole


class GrantRecord(BaseModel):
    """One live project role binding, already filtered to the audience.

    This is project authority, distinct from the principal's explicit organization
    memberships. ``role`` stays a string at the wire; the audience's app narrows it to
    its own enum.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    project: ProjectRef
    scope: str
    role: str


class Principal(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    kind: PrincipalKind
    subject: str  # email for users, name for service principals
    display_name: str
    org: OrgRef
    memberships: tuple[OrganizationMembership, ...] = ()
    grants: tuple[GrantRecord, ...]


def grants_for_project(principal: Principal, project_id: ProjectId) -> tuple[GrantRecord, ...]:
    """Return only the live audience grants for one explicitly selected project."""

    return tuple(grant for grant in principal.grants if grant.project.id == project_id)


class CredentialInfo(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    kind: CredentialKind
    expires_at: datetime | None = None  # a caching hint; None = no fixed expiry


class IntrospectionResult(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    principal: Principal
    credential: CredentialInfo
    cache_ttl_s: int  # server-advertised: the centrally tunable revocation bound


class CredentialRef(BaseModel):
    """What a consumer sends: the sha256 hex digest — the raw credential never
    leaves the app that received it."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    kind: CredentialKind
    sha256: Sha256Digest


class IntrospectRequest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    credential: CredentialRef
    audience: str


class DelegationRef(BaseModel):
    """A revocable, project-scoped authority reference safe for durable histories."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    expires_at: datetime


class CreateDelegationRequest(BaseModel):
    """Bind one live caller credential to one service, audience, project, and turn."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    source: CredentialRef
    source_principal_id: UUID
    project_id: ProjectId
    audience: str = Field(min_length=1)
    idempotency_key: str = Field(min_length=1, max_length=200)
    expires_in_s: int = Field(
        default=DEFAULT_DELEGATION_TTL_S,
        ge=60,
        le=MAX_DELEGATION_TTL_S,
    )


class IntrospectDelegationRequest(BaseModel):
    """Resolve a durable delegation for the service credential presenting it."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    delegation_id: UUID
    holder: CredentialRef
    audience: str = Field(min_length=1)


def introspection_to_json(result: IntrospectionResult | None) -> dict[str, object]:
    """RFC 7662-flavored: unknown/revoked/expired is ``{"active": false}`` with
    status 200, so consumers can cache negatives."""
    if result is None:
        return {"active": False}
    return {"active": True, **result.model_dump(mode="json")}


def parse_introspection(body: Mapping[str, object]) -> IntrospectionResult | None:
    """``None`` for inactive credentials; typed error on a malformed body."""
    if body.get("active") is not True:
        return None
    payload = {k: v for k, v in body.items() if k != "active"}
    try:
        return IntrospectionResult.model_validate(payload)
    except ValidationError as exc:
        raise IntrospectionShapeError(str(exc)) from exc
