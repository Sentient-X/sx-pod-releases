"""Session tokens and cookies: opaque, server-side, revocable.

One mechanism for every app: a 256-bit random token in an HttpOnly ``samesite=lax`` cookie,
looked up server-side against the app's own session table. No signed cookies — server-side
sessions are revocable (logout, deactivation) and need no signing-secret rotation.
"""

import secrets

from fastapi import Response

DEFAULT_SESSION_TTL_S = 7 * 24 * 3600


def new_session_token() -> str:
    """A fresh opaque session token (256 bits, urlsafe)."""
    return secrets.token_urlsafe(32)


def set_session_cookie(
    response: Response,
    *,
    cookie_name: str,
    token: str,
    secure: bool,
    max_age_s: int,
    domain: str | None = None,
) -> None:
    """Attach the session cookie: HttpOnly, ``samesite=lax``, never script-readable.

    ``domain`` makes the cookie a parent-domain cookie (the platform-SSO shape,
    e.g. ``.sentientx.io``); ``None`` keeps it host-scoped (dev localhost).
    """
    response.set_cookie(
        cookie_name,
        token,
        httponly=True,
        samesite="lax",
        secure=secure,
        max_age=max_age_s,
        domain=domain,
    )


def clear_session_cookie(
    response: Response, *, cookie_name: str, domain: str | None = None
) -> None:
    """Remove the session cookie (``domain`` must match how it was set)."""
    response.delete_cookie(cookie_name, domain=domain)
