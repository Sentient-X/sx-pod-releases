"""Login throttling: the shared sliding window, counting failures instead of requests.

Generalized from the sxd labeler's brute-force guard. Production injects the same distributed
backend as request admission; development and tests may explicitly use the in-memory meter.

What makes this different from every other metered surface is *what* is counted, not how.
`RequestMeter` next door already owned the window: the same slice counts, the same
forgetting rule against `limit.window_s`, the same `ceil` retry-after. This held a second
copy of all of it purely because a login is refused on the strength of *previous* failures
rather than of itself — so the meter grew `refuse_if_full`/`note`/`forget`, and the copy is
gone.
"""

import time
from collections.abc import Callable, Collection

from fastapi import HTTPException, Request
from sx_service.registry import LOGIN_FAILURE, RequestLimit

from sx_auth.guard import MeterUnavailableError, RateLimitedError, RequestMeter, refusal_envelope


def client_ip(request: Request, *, trusted_proxies: Collection[str] = ()) -> str:
    """The caller's IP, believing ``X-Forwarded-For`` only from a declared proxy.

    ``X-Forwarded-For`` is caller-supplied. Reading it unconditionally lets anyone
    choose their own throttle key by rotating the header, which turns the login
    failure budget into no budget at all — so the header counts only when the peer
    that delivered it is one we put there.

    Proxies *append*, so the trustworthy entry is the rightmost hop that is not
    itself a trusted proxy: everything to its left was written by someone upstream
    and could be anything. With no proxies declared the peer address is the answer
    and the header is ignored entirely.
    """
    peer = request.client.host if request.client else "unknown"
    if not trusted_proxies or peer not in trusted_proxies:
        return peer
    forwarded = request.headers.get("x-forwarded-for")
    if not forwarded:
        return peer
    for hop in reversed([part.strip() for part in forwarded.split(",") if part.strip()]):
        if hop not in trusted_proxies:
            return hop
    return peer


class LoginThrottle:
    """Sliding-window failure counter; :meth:`check` raises 429 once the window is full."""

    def __init__(
        self,
        limit: RequestLimit = LOGIN_FAILURE,
        clock: Callable[[], float] = time.monotonic,
        *,
        meter: RequestMeter | None = None,
    ) -> None:
        self._meter = meter or RequestMeter(limit, clock=clock)

    def _subject(self, ip: str, ident: str) -> str:
        return f"{ip}\0{ident.strip().lower()}"

    async def check(self, ip: str, ident: str) -> None:
        """Raise 429 when (ip, ident) has exhausted its failure budget for the window."""
        try:
            await self._meter.refuse_if_full(self._subject(ip, ident))
        except RateLimitedError as error:
            raise HTTPException(
                429,
                refusal_envelope(
                    "rate_limit_exceeded",
                    "too many login attempts; try again later",
                    retryable=True,
                ),
                headers={"Retry-After": str(error.retry_after_s)},
            ) from error
        except MeterUnavailableError as error:
            raise HTTPException(
                503,
                refusal_envelope(
                    "rate_limit_unavailable", "login admission service unavailable", retryable=True
                ),
            ) from error

    async def note_failure(self, ip: str, ident: str) -> None:
        """Record one failed attempt."""
        try:
            await self._meter.note(self._subject(ip, ident))
        except MeterUnavailableError as error:
            raise HTTPException(503, _admission_unavailable()) from error

    async def note_success(self, ip: str, ident: str) -> None:
        """Clear the failure budget after a successful login."""
        try:
            await self._meter.forget(self._subject(ip, ident))
        except MeterUnavailableError as error:
            raise HTTPException(503, _admission_unavailable()) from error


def _admission_unavailable() -> dict[str, object]:
    return refusal_envelope(
        "rate_limit_unavailable", "login admission service unavailable", retryable=True
    )
