"""Machine identity: the node-subject codec and the credential→node binding law.

A machine is a **service principal whose name is its node subject** — ``pod:piperx-01``,
``station:dev-01``, ``uploader:factory-nas-01``. No new principal kind, no nodes table:
``service_principals.name UNIQUE``
is the one-principal-per-node law, and the binding law at every door is subject equality —
a credential speaks for node X iff its principal's subject is ``{kind}:{X}``. User subjects
are emails (they contain ``@``, never a ``kind:`` prefix), so the namespaces cannot collide;
belt-and-braces, resolution also requires the SERVICE principal kind.

The machine's acting project is derived, not sent: a machine credential carries exactly one
machine-role grant binding (written at enrollment), and that grant's project is the acting
project. Zero grants or more than one project fails closed — an ambiguous machine is an
enrollment mistake, not a disambiguation problem.

Role strings are the node-kind values themselves (``pod``, ``station``,
``uploader``): one vocabulary, byte-equal to the sx_authd ``audience_roles`` rows.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from uuid import UUID

from sx_auth.principal import IntrospectionResult, PrincipalKind, ProjectRef


class NodeKind(StrEnum):
    """The machine kinds. Values double as the machine ROLE strings in sx_authd's registry
    (``('factory','pod')``, ``('fleet','pod')``, ``('supervisors','station')``)."""

    POD = "pod"
    CONTROLLER = "controller"
    STATION = "station"
    UPLOADER = "uploader"


class NodeAccessError(Exception):
    """Base for fail-closed machine-credential refusals; doors map these to typed 403s."""


class NodeSubjectError(NodeAccessError):
    """A subject that is not a well-formed node subject."""

    def __init__(self, subject: str, reason: str) -> None:
        self.subject = subject
        self.reason = reason
        super().__init__(f"not a node subject ({reason}): {subject!r}")


class NotANodeCredentialError(NodeAccessError):
    """The credential's principal is not a machine of the required kind."""

    def __init__(self, subject: str, required_kind: NodeKind, reason: str) -> None:
        self.subject = subject
        self.required_kind = required_kind
        self.reason = reason
        super().__init__(f"credential is not a {required_kind.value} credential ({reason})")


class NodeRoleMissingError(NodeAccessError):
    """The machine principal holds no grant with its machine role in this audience."""

    def __init__(self, subject: str, kind: NodeKind) -> None:
        self.subject = subject
        self.kind = kind
        super().__init__(f"{subject!r} holds no {kind.value!r}-role grant in this audience")


class AmbiguousNodeProjectError(NodeAccessError):
    """Machine grants name more than one project — an enrollment mistake, refused."""

    def __init__(self, subject: str, project_slugs: tuple[str, ...]) -> None:
        self.subject = subject
        self.project_slugs = project_slugs
        super().__init__(
            f"{subject!r} is bound to {len(project_slugs)} projects "
            f"({', '.join(project_slugs)}); a machine acts in exactly one"
        )


class NodeIdentityMismatchError(NodeAccessError):
    """The credential does not speak for the node it claims."""

    def __init__(self, node: NodeId, claimed_name: str) -> None:
        self.node = node
        self.claimed_name = claimed_name
        super().__init__(
            f"credential speaks for {node.kind.value} {node.name!r}, "
            f"not the claimed {claimed_name!r}"
        )


@dataclass(frozen=True, slots=True)
class NodeId:
    """One machine's identity: its kind and its door-visible name (pod_id / station id)."""

    kind: NodeKind
    name: str

    def __post_init__(self) -> None:
        if not self.name:
            raise NodeSubjectError(f"{self.kind.value}:", "empty name")

    @property
    def subject(self) -> str:
        """The service-principal name this node enrolls under."""
        return f"{self.kind.value}:{self.name}"


def parse_node_subject(subject: str) -> NodeId:
    """Split-once inverse of :attr:`NodeId.subject`; fail-closed on any other shape."""
    kind_raw, sep, name = subject.partition(":")
    if not sep:
        raise NodeSubjectError(subject, "no kind prefix")
    if not name:
        raise NodeSubjectError(subject, "empty name")
    try:
        kind = NodeKind(kind_raw)
    except ValueError:
        raise NodeSubjectError(subject, f"unknown kind {kind_raw!r}") from None
    return NodeId(kind, name)


@dataclass(frozen=True, slots=True)
class NodePrincipal:
    """A verified machine caller: who it is, which node it speaks for, where it acts."""

    principal_id: UUID
    node: NodeId
    project: ProjectRef
    credential_id: UUID


def resolve_node(result: IntrospectionResult, kind: NodeKind) -> NodePrincipal:
    """Resolve an introspected credential into the machine it speaks for.

    Raises a :class:`NodeAccessError` subclass on every refusal — the caller's door maps
    them to its typed 403.
    """
    principal = result.principal
    if principal.kind is not PrincipalKind.SERVICE:
        raise NotANodeCredentialError(principal.subject, kind, "not a service principal")
    try:
        node = parse_node_subject(principal.subject)
    except NodeSubjectError as error:
        raise NotANodeCredentialError(principal.subject, kind, error.reason) from error
    if node.kind is not kind:
        raise NotANodeCredentialError(principal.subject, kind, f"is a {node.kind.value} credential")
    machine_grants = [grant for grant in principal.grants if grant.role == kind.value]
    if not machine_grants:
        raise NodeRoleMissingError(principal.subject, kind)
    projects = {grant.project.id: grant.project for grant in machine_grants}
    if len(projects) != 1:
        slugs = tuple(sorted(project.slug for project in projects.values()))
        raise AmbiguousNodeProjectError(principal.subject, slugs)
    (project,) = projects.values()
    return NodePrincipal(
        principal_id=principal.id,
        node=node,
        project=project,
        credential_id=result.credential.id,
    )


def require_node(principal: NodePrincipal, claimed_name: str) -> None:
    """The binding law: the credential must speak for exactly the claimed node."""
    if principal.node.name != claimed_name:
        raise NodeIdentityMismatchError(principal.node, claimed_name)
