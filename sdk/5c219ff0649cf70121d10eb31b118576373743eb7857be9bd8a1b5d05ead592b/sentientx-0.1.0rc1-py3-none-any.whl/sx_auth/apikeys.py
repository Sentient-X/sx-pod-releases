"""Machine auth: API keys (hashed, scoped).

Keys are stored as sha256 hex digests — the exact format the existing tables already hold,
so adoption migrates no data. Key *storage and scope lookup* stay app-side (they need the
app's database session); this module carries the mechanisms: hashing and minting. (The
shared-secret webhook check, ``check_header_token``, was deleted when its last callers —
the supervisors station hooks — moved to per-station machine credentials.)
"""

import hashlib
import secrets


def hash_api_key(raw: str) -> str:
    """The stored form of an API key: sha256 hex digest of the raw key."""
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def mint_api_key(prefix: str) -> str:
    """A fresh raw API key, prefixed so leaked keys are recognizable in logs/scans."""
    return f"{prefix}_{secrets.token_urlsafe(24)}"
