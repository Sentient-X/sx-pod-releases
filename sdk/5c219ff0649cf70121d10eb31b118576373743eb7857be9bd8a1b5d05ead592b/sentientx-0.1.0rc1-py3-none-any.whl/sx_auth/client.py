"""The consumer side of sx_authd introspection: a typed client with an
in-process TTL cache, so credential verification adds zero steady-state latency.

The raw credential is hashed locally; only the sha256 crosses the wire. The
positive-cache TTL is server-advertised (``cache_ttl_s``) — the platform's
revocation bound is tuned centrally, not per consumer. Once an entry expires,
transport errors, non-200 responses, and malformed responses raise
:class:`AuthUnavailableError` (map it to 503 — never fabricate or reuse an expired
principal, never turn an outage into 401).

Env-free like the rest of this package: every knob is a constructor argument.
"""

from __future__ import annotations

import asyncio
import hashlib
import time
from collections.abc import Callable
from contextlib import suppress
from dataclasses import dataclass
from datetime import UTC, datetime
from uuid import UUID

import httpx
from pydantic import ValidationError
from sx_contracts import Sha256Digest

from sx_auth.credentials import PresentedCredential
from sx_auth.principal import (
    DEFAULT_DELEGATION_TTL_S,
    CreateDelegationRequest,
    CredentialKind,
    CredentialRef,
    DelegationRef,
    IntrospectDelegationRequest,
    IntrospectionResult,
    IntrospectionShapeError,
    IntrospectRequest,
    ProjectBillingAdmission,
    ProjectId,
    parse_introspection,
)


class AuthUnavailableError(RuntimeError):
    """The auth service cannot verify the credential from a fresh cache entry
    or a live response. Consumers answer 503 — an outage is never a 401."""


@dataclass(slots=True)
class _Entry:
    result: IntrospectionResult | None  # None = cached negative (inactive)
    fetched_at: float
    ttl_s: float


class AuthClient:
    """One instance per app process; the cache is the instance."""

    def __init__(
        self,
        *,
        base_url: str,
        service_key: str,
        audience: str,
        http: httpx.AsyncClient | None = None,
        negative_ttl_s: float = 5.0,
        ttl_cap_s: float | None = None,
        max_cache_entries: int = 4096,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._service_key = service_key
        self._audience = audience
        self.http = http or httpx.AsyncClient(timeout=5.0)
        self._negative_ttl_s = negative_ttl_s
        # Safety surfaces (supervisors) cap the server-advertised TTL so their
        # revocation bound stays seconds-scale regardless of central tuning.
        self._ttl_cap_s = ttl_cap_s
        self._max_cache_entries = max_cache_entries
        self._clock = clock
        self._cache: dict[str, _Entry] = {}
        self._inflight: dict[str, asyncio.Task[IntrospectionResult | None]] = {}

    @property
    def audience(self) -> str:
        """The audience this client introspects for (stamped into every request)."""
        return self._audience

    async def introspect_api_key(self, raw: str) -> IntrospectionResult | None:
        return await self._introspect(CredentialKind.API_KEY, raw)

    async def introspect_session(self, token: str) -> IntrospectionResult | None:
        return await self._introspect(CredentialKind.SESSION, token)

    async def introspect(self, credential: PresentedCredential) -> IntrospectionResult | None:
        """Verify whichever credential the request carried, so callers that took
        it from :func:`sx_auth.credentials.present_credential` need not branch on
        its kind. Dispatches through the two public methods rather than the cache
        path, so a subclass that overrides them (test stubs do) still governs."""
        if credential.kind is CredentialKind.SESSION:
            return await self.introspect_session(credential.raw)
        return await self.introspect_api_key(credential.raw)

    async def create_delegation(
        self,
        credential: PresentedCredential,
        *,
        principal_id: UUID,
        project_id: UUID,
        idempotency_key: str,
        expires_in_s: int = DEFAULT_DELEGATION_TTL_S,
    ) -> DelegationRef:
        """Create or replay one project-scoped delegation owned by this service."""

        source = self._credential_ref(credential)
        body = CreateDelegationRequest(
            source=source,
            source_principal_id=principal_id,
            project_id=ProjectId(project_id),
            audience=self._audience,
            idempotency_key=idempotency_key,
            expires_in_s=expires_in_s,
        )
        try:
            response = await self.http.post(
                f"{self._base_url}/api/delegations",
                json=body.model_dump(mode="json"),
                headers={"X-API-Key": self._service_key},
            )
            if response.status_code != 200:
                raise AuthUnavailableError(
                    f"delegation admission failed: HTTP {response.status_code}"
                )
            return DelegationRef.model_validate(response.json())
        except (httpx.TransportError, ValidationError, AuthUnavailableError) as exc:
            raise AuthUnavailableError(f"delegation admission unavailable: {exc}") from exc

    async def introspect_delegation(
        self,
        holder: PresentedCredential,
        delegation_id: UUID,
    ) -> IntrospectionResult | None:
        """Resolve one delegation while this door remains the authenticated introspector."""

        body = IntrospectDelegationRequest(
            delegation_id=delegation_id,
            holder=self._credential_ref(holder),
            audience=self._audience,
        )
        try:
            response = await self.http.post(
                f"{self._base_url}/api/delegations/introspect",
                json=body.model_dump(mode="json"),
                headers={"X-API-Key": self._service_key},
            )
            if response.status_code != 200:
                raise AuthUnavailableError(
                    f"delegation introspection failed: HTTP {response.status_code}"
                )
            return parse_introspection(response.json())
        except (httpx.TransportError, IntrospectionShapeError, AuthUnavailableError) as exc:
            raise AuthUnavailableError(f"delegation introspection unavailable: {exc}") from exc

    async def revoke_delegation(self, delegation_id: UUID) -> None:
        """Idempotently revoke one delegation owned by this service principal."""

        try:
            response = await self.http.post(
                f"{self._base_url}/api/delegations/{delegation_id}/revoke",
                headers={"X-API-Key": self._service_key},
            )
            if response.status_code != 204:
                raise AuthUnavailableError(
                    f"delegation revocation failed: HTTP {response.status_code}"
                )
        except (httpx.TransportError, AuthUnavailableError) as exc:
            raise AuthUnavailableError(f"delegation revocation unavailable: {exc}") from exc

    @staticmethod
    def _credential_ref(credential: PresentedCredential) -> CredentialRef:
        digest = hashlib.sha256(credential.raw.encode()).hexdigest()
        return CredentialRef(kind=credential.kind, sha256=Sha256Digest(digest))

    async def introspect_fresh(self, credential: PresentedCredential) -> IntrospectionResult | None:
        """Re-read Auth for an action that must observe a just-committed policy fact.

        Paid resource creation is rare and must not sit behind the ordinary positive
        authorization cache after an administrator accepts organization terms.
        """

        digest = hashlib.sha256(credential.raw.encode()).hexdigest()
        cache_key = f"{credential.kind.value}:{digest}"
        stale = self._inflight.get(cache_key)
        if stale is not None:
            # A paid action still gets its own live verification attempt; a
            # preceding transport failure or cancelled waiter is not reused.
            with suppress(Exception, asyncio.CancelledError):
                await asyncio.shield(stale)
            if self._inflight.get(cache_key) is stale:
                self._inflight.pop(cache_key, None)
        self._cache.pop(cache_key, None)
        return await self.introspect(credential)

    async def project_billing_admission(self, project_id: UUID) -> ProjectBillingAdmission:
        """Ask Auth for Lago's live hard-limit decision; never cache it locally."""

        try:
            response = await self.http.get(
                f"{self._base_url}/api/internal/projects/{project_id}/billing/admission",
                headers={"X-API-Key": self._service_key},
            )
            if response.status_code != 200:
                raise AuthUnavailableError(f"billing admission failed: HTTP {response.status_code}")
            return ProjectBillingAdmission.model_validate(response.json())
        except (httpx.TransportError, ValidationError, AuthUnavailableError) as exc:
            raise AuthUnavailableError(f"billing admission unavailable: {exc}") from exc

    async def _introspect(self, kind: CredentialKind, raw: str) -> IntrospectionResult | None:
        digest = hashlib.sha256(raw.encode()).hexdigest()
        cache_key = f"{kind.value}:{digest}"
        now = self._clock()
        entry = self._cache.get(cache_key)
        if entry is not None and now - entry.fetched_at <= entry.ttl_s:
            return entry.result

        task = self._inflight.get(cache_key)
        if task is None:
            task = asyncio.create_task(self._fetch(kind, digest, cache_key, now))
            self._inflight[cache_key] = task
            task.add_done_callback(
                lambda completed, key=cache_key: self._retire_inflight(key, completed)
            )
        return await asyncio.shield(task)

    async def _fetch(
        self,
        kind: CredentialKind,
        digest: str,
        cache_key: str,
        fetched_at: float,
    ) -> IntrospectionResult | None:

        body = IntrospectRequest(
            credential=CredentialRef(kind=kind, sha256=Sha256Digest(digest)),
            audience=self._audience,
        )
        try:
            response = await self.http.post(
                f"{self._base_url}/api/introspect",
                json=body.model_dump(mode="json"),
                headers={"X-API-Key": self._service_key},
            )
            if response.status_code != 200:
                # 401/403 here mean OUR service key is bad (deployment error);
                # 5xx means the service is down. Both: cannot verify.
                raise AuthUnavailableError(f"introspection failed: HTTP {response.status_code}")
            result = parse_introspection(response.json())
        except (httpx.TransportError, IntrospectionShapeError, AuthUnavailableError) as exc:
            raise AuthUnavailableError(f"auth service unavailable: {exc}") from exc

        ttl = self._negative_ttl_s if result is None else self._positive_ttl(result)
        self._store(cache_key, _Entry(result=result, fetched_at=fetched_at, ttl_s=ttl))
        return result

    def _retire_inflight(
        self,
        cache_key: str,
        completed: asyncio.Task[IntrospectionResult | None],
    ) -> None:
        if self._inflight.get(cache_key) is completed:
            self._inflight.pop(cache_key, None)
        if not completed.cancelled():
            # Retrieve failures even if every waiter was cancelled; live waiters still
            # receive the same exception from their own await.
            completed.exception()

    def _positive_ttl(self, result: IntrospectionResult) -> float:
        ttl = float(result.cache_ttl_s)
        if self._ttl_cap_s is not None:
            ttl = min(ttl, self._ttl_cap_s)
        expires_at = result.credential.expires_at
        if expires_at is not None:
            remaining = (expires_at - datetime.now(UTC)).total_seconds()
            ttl = max(0.0, min(ttl, remaining))
        return ttl

    def _store(self, key: str, entry: _Entry) -> None:
        cache = self._cache
        if len(cache) >= self._max_cache_entries:
            now = self._clock()
            for stale in [k for k, e in cache.items() if now - e.fetched_at > e.ttl_s]:
                del cache[stale]
            while len(cache) >= self._max_cache_entries:  # still full: drop oldest
                del cache[min(cache, key=lambda k: cache[k].fetched_at)]
        cache[key] = entry
