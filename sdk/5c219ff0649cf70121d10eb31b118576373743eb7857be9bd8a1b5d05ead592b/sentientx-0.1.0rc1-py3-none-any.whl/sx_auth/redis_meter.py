"""Redis state owner for the request windows shared by every replica of one door.

One hash per door, rate class, and principal: a request count per slice of the
window (:data:`sx_auth.guard.WINDOW_SLICES` slices, so a minute class is counted to
the second) plus the last admitted member, kept so a retry after a lost reply is
answered with the committed admission. Only the last: the log remembered every member
in the window, so an admission another replica interleaves between the commit and the
retry now makes the retry count again — one slot spent, never one widened, and for
``login-failure`` one failure charged twice on a failover, against a budget of five.
Memory per key is bounded by the slice count, never by the ceiling — the log this
replaced stored one sorted-set member per admitted request, so widening a class widened
the shared Redis's footprint in proportion, and a full ``noeviction`` store fails every
door closed at once. The counter pays in CPU instead: reading the live slices costs
about six times the server work of the log's cardinality read, so the one Redis
thread's EVAL rate, not its memory, is the ceiling to watch.

The key prefix is ``v2``: the ``v1`` keys were sorted sets, and a hash write against
one would be a type error, not a count. The two key families are disjoint, so for as
long as a rollout runs pods of both versions a principal has both budgets — up to twice
the declared count, split by which pod serves it — and the ``v1`` keys expire on their
own one window after the last old pod leaves.
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from typing import Any, Literal, cast
from uuid import uuid4

from redis.asyncio import Redis
from redis.asyncio.sentinel import Sentinel
from redis.exceptions import ConnectionError as RedisConnectionError
from redis.exceptions import RedisError
from redis.exceptions import TimeoutError as RedisTimeoutError
from sx_service.registry import RequestLimit

from sx_auth.guard import MeterUnavailableError, RateLimitedError, RequestMeterFactory, slice_ms

# Mirrors InMemoryMeterBackend in sx_auth.guard: the same slices, the same forgetting
# rule, the same retry, so the development backend refuses exactly where this does.
_WINDOW_LUA = """
local key = KEYS[1]
local operation = ARGV[1]
local request_limit = tonumber(ARGV[2])
local window_ms = tonumber(ARGV[3])
local slice_ms = tonumber(ARGV[4])
local member = ARGV[5]
local server_time = redis.call('TIME')
local now_ms = (tonumber(server_time[1]) * 1000) + math.floor(tonumber(server_time[2]) / 1000)
local horizon = now_ms - window_ms

if operation == 'forget' then
  redis.call('DEL', key)
  return {1, 0}
end

-- Field 'm' is the last admitted member; every other field is a slice index holding
-- the count admitted in that slice. A slice is forgotten once all of it is older than
-- the window, so a window of the declared length never admits more than the limit.
local fields = redis.call('HGETALL', key)
local count = 0
local live = {}
local counts = {}
local last_member = nil
local dead = {}
for i = 1, #fields, 2 do
  local field = fields[i]
  if field == 'm' then
    last_member = fields[i + 1]
  else
    local slice = tonumber(field)
    if (slice + 1) * slice_ms > horizon then
      counts[slice] = tonumber(fields[i + 1])
      count = count + counts[slice]
      live[#live + 1] = slice
    else
      dead[#dead + 1] = field
    end
  end
end
if #dead > 0 then
  redis.call('HDEL', key, unpack(dead))
end

-- A Redis failover can lose the reply after this script committed. The caller
-- retries with the same member, so answer the committed admission instead of
-- counting it twice or refusing its own replay at the window boundary. Only the
-- last admission is remembered: an admission interleaved from another replica makes
-- the retry count again, which spends one slot of the budget and never widens it.
if (operation == 'check' or operation == 'note') and last_member == member then
  return {1, 0}
end

-- Mirrors sx_auth.guard.retry_ms: a window can hold more than its limit ('note'
-- never refuses), so walk the oldest slices until what remains is under the limit.
if (operation == 'check' or operation == 'refuse') and count >= request_limit then
  table.sort(live)
  local remaining = count
  for _, slice in ipairs(live) do
    remaining = remaining - counts[slice]
    if remaining < request_limit then
      return {0, (slice + 1) * slice_ms - horizon}
    end
  end
  -- Unreachable while the limit admits at least one request; refuse rather than
  -- fall through into admitting a full window, as the Python mirror does.
  return {0, (live[#live] + 1) * slice_ms - horizon}
end

if operation == 'check' or operation == 'note' then
  redis.call('HINCRBY', key, string.format('%.0f', math.floor(now_ms / slice_ms)), 1)
  redis.call('HSET', key, 'm', member)
  redis.call('PEXPIRE', key, window_ms + slice_ms + 1000)
end
return {1, 0}
"""

Operation = Literal["check", "refuse", "note", "forget"]
MeterBackendKind = Literal["memory", "redis"]
_RETRY_DELAYS_S = (0.05, 0.2)


@dataclass(frozen=True, slots=True, kw_only=True)
class RedisMeterSettings:
    sentinels: tuple[tuple[str, int], ...]
    master_name: str
    username: str
    password: str
    key_hmac_secret: bytes
    socket_timeout_s: float = 1.0

    def __post_init__(self) -> None:
        if not self.sentinels:
            raise ValueError("at least one Redis Sentinel is required")
        if not self.master_name or not self.password or not self.key_hmac_secret:
            raise ValueError("Redis master, password, and key HMAC secret are required")


class RedisMeterBackend:
    kind = "redis"

    def __init__(self, client: Redis, *, key_hmac_secret: bytes) -> None:
        self._client = client
        self._key_hmac_secret = key_hmac_secret
        self._ready = True

    @property
    def ready(self) -> bool:
        return self._ready

    async def ensure_ready(self) -> None:
        try:
            ping = cast(
                "Callable[[], Awaitable[bool]]",
                self._client.ping,  # pyright: ignore[reportUnknownMemberType]
            )
            await ping()
        except RedisError as error:
            self._ready = False
            raise MeterUnavailableError(str(error)) from error
        self._ready = True

    @classmethod
    def connect(cls, settings: RedisMeterSettings) -> RedisMeterBackend:
        sentinel = Sentinel(
            list(settings.sentinels),
            socket_timeout=settings.socket_timeout_s,
            sentinel_kwargs={"username": settings.username, "password": settings.password},
        )
        master_for = cast(
            "Callable[..., Redis]",
            sentinel.master_for,  # pyright: ignore[reportUnknownMemberType]
        )
        client = master_for(
            settings.master_name,
            username=settings.username,
            password=settings.password,
            socket_timeout=settings.socket_timeout_s,
            decode_responses=False,
        )
        return cls(client, key_hmac_secret=settings.key_hmac_secret)

    def _key(self, scope: str, limit: RequestLimit, subject: str) -> str:
        digest = hmac.new(self._key_hmac_secret, subject.encode(), hashlib.sha256).hexdigest()
        # The window is part of the key: a slice index means nothing outside the width
        # that produced it, so two limits of one class with different windows never
        # read each other's counts.
        return f"sx:rate:v2:{scope}:{limit.name.value}:{limit.window_s}:{digest}"

    async def _apply(
        self,
        operation: Operation,
        scope: str,
        limit: RequestLimit,
        subject: str,
    ) -> None:
        member = uuid4().hex
        for attempt in range(len(_RETRY_DELAYS_S) + 1):
            try:
                raw = await cast(
                    "Awaitable[Any]",
                    self._client.eval(
                        _WINDOW_LUA,
                        1,
                        self._key(scope, limit, subject),
                        operation,
                        str(limit.requests),
                        str(limit.window_s * 1000),
                        str(slice_ms(limit)),
                        member,
                    ),
                )
            except (RedisConnectionError, RedisTimeoutError) as error:
                # Only a lost transport is worth retrying: the reply may have been lost
                # after the script committed, and the same member makes the retry safe.
                self._ready = False
                if attempt == len(_RETRY_DELAYS_S):
                    raise MeterUnavailableError(str(error)) from error
                await asyncio.sleep(_RETRY_DELAYS_S[attempt])
                continue
            except RedisError as error:
                # A served refusal — a full noeviction store, a script error — is the
                # answer; retrying it would triple the load on a Redis already at its limit.
                self._ready = False
                raise MeterUnavailableError(str(error)) from error
            self._ready = True
            result = cast("list[Any]", raw)
            if int(result[0]) == 0:
                retry_after_s = max(1, (int(result[1]) + 999) // 1000)
                raise RateLimitedError(limit, retry_after_s)
            return

    async def check(self, scope: str, limit: RequestLimit, subject: str) -> None:
        await self._apply("check", scope, limit, subject)

    async def refuse_if_full(self, scope: str, limit: RequestLimit, subject: str) -> None:
        await self._apply("refuse", scope, limit, subject)

    async def note(self, scope: str, limit: RequestLimit, subject: str) -> None:
        await self._apply("note", scope, limit, subject)

    async def forget(self, scope: str, limit: RequestLimit, subject: str) -> None:
        await self._apply("forget", scope, limit, subject)

    async def aclose(self) -> None:
        await self._client.aclose()


def redis_meter_factory(settings: RedisMeterSettings, *, scope: str) -> RequestMeterFactory:
    return RequestMeterFactory(scope=scope, backend=RedisMeterBackend.connect(settings))


def configured_meter_factory(
    *,
    scope: str,
    backend: MeterBackendKind,
    sentinels: str = "",
    master_name: str = "mymaster",
    username: str = "default",
    password: str = "",
    key_hmac_secret: str = "",
) -> RequestMeterFactory:
    """Build the explicitly selected state owner from values read at an app's config edge."""
    if backend == "memory":
        from sx_auth.guard import InMemoryMeterBackend

        return RequestMeterFactory(scope=scope, backend=InMemoryMeterBackend())
    nodes: list[tuple[str, int]] = []
    for raw in sentinels.split(","):
        host, separator, port = raw.strip().rpartition(":")
        if not separator or not host:
            raise ValueError("Redis Sentinel nodes must be comma-separated host:port values")
        nodes.append((host, int(port)))
    return redis_meter_factory(
        RedisMeterSettings(
            sentinels=tuple(nodes),
            master_name=master_name,
            username=username,
            password=password,
            key_hmac_secret=key_hmac_secret.encode(),
        ),
        scope=scope,
    )


def environment_meter_factory(
    *,
    scope: str,
    environment: Mapping[str, str],
    auth_required: bool,
) -> RequestMeterFactory:
    """Resolve the universal rate-meter contract at a process composition edge.

    Production doors that authenticate callers may not silently fall back to a
    process-local budget. Development and tests select the in-memory owner when no
    backend is declared; an explicitly configured Redis backend is validated in all
    environments.
    """
    deployment = environment.get("SX_ENVIRONMENT", "development").strip().lower()
    selected = environment.get("SX_RATE_LIMIT_BACKEND", "").strip().lower()
    if deployment == "production" and auth_required and selected != "redis":
        raise ValueError("authenticated production doors require SX_RATE_LIMIT_BACKEND=redis")
    backend: MeterBackendKind
    if selected in {"", "memory"}:
        backend = "memory"
    elif selected == "redis":
        backend = "redis"
    else:
        raise ValueError("SX_RATE_LIMIT_BACKEND must be 'memory' or 'redis'")
    return configured_meter_factory(
        scope=scope,
        backend=backend,
        sentinels=environment.get("SX_RATE_LIMIT_REDIS_SENTINELS", ""),
        master_name=environment.get("SX_RATE_LIMIT_REDIS_MASTER", "mymaster"),
        username=environment.get("SX_RATE_LIMIT_REDIS_USERNAME", "default"),
        password=environment.get("SX_RATE_LIMIT_REDIS_PASSWORD", ""),
        key_hmac_secret=environment.get("SX_RATE_LIMIT_HMAC_SECRET", ""),
    )
