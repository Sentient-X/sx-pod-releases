"""Short-lived, single-use machine join-code contracts."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, model_validator

from sx_auth.node import NodeKind


class _Model(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class JoinCodeCreate(_Model):
    project_id: UUID
    kind: NodeKind
    node_id: str = Field(pattern=r"^[a-zA-Z0-9._-]+$")
    audiences: tuple[str, ...] = Field(min_length=1)
    ttl_s: int = Field(default=600, ge=60, le=3_600)

    @model_validator(mode="after")
    def enrollable_kind(self) -> JoinCodeCreate:
        if self.kind not in {NodeKind.POD, NodeKind.STATION, NodeKind.CONTROLLER}:
            raise ValueError("join codes enroll only pod, station, or controller nodes")
        if len(set(self.audiences)) != len(self.audiences) or any(
            not audience.strip() for audience in self.audiences
        ):
            raise ValueError("join-code audiences must be unique non-empty names")
        return self


class JoinCodeOut(_Model):
    code: str = Field(pattern=r"^sxj_[A-Za-z0-9_-]{20,}$")
    organization_id: UUID
    project_id: UUID
    kind: NodeKind
    node_id: str
    audiences: tuple[str, ...]
    expires_at: datetime


class JoinCodeRedeem(_Model):
    code: str = Field(pattern=r"^sxj_[A-Za-z0-9_-]{20,}$")


class JoinedNode(_Model):
    """The once-shown least-privilege credential produced by redemption."""

    principal_id: UUID
    subject: str
    organization_id: UUID
    project_id: UUID
    audiences: tuple[str, ...]
    key: str
    key_id: UUID
    key_hint: str
