"""The audience auth door shared by the mounted service backends.

One credential + metering story for every audience-scoped HTTP door (train's
serve API, the Worlds gate): identity is the central control plane's —
credentials introspect through :class:`sx_auth.client.AuthClient` — roles
are filtered to the caller's explicit ``X-SX-Project-Id`` before they narrow
to :class:`ApiRole` through the door's explicit audience-role map, with unknown
roles dropped (fail closed), and
metering is a per-principal request window, counted in slices (see
:data:`WINDOW_SLICES`), so no door is cheaper than the storefront beside it. Dev is
auth-optional: an unauthenticated request resolves to :data:`DEV_PRINCIPAL` without
touching the auth service, so tests and `just dev` never depend on sx_authd being up.

:class:`ApiRole` is the door-facing capability ladder. Its default map is byte-equal
to the reader/operator/admin rows sx_authd seeds for those audiences. A composing door
that deliberately authorizes through another audience supplies that audience's explicit
map rather than teaching the shared resolver aliases or silently widening unknown roles.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from enum import StrEnum
from math import ceil
from typing import Protocol
from uuid import UUID, uuid4

from fastapi import HTTPException, Request
from fastapi.requests import HTTPConnection
from sx_service.door import ErrorOut, declare_rate
from sx_service.logging import context_fields
from sx_service.registry import RequestLimit

from sx_auth.client import AuthClient, AuthUnavailableError
from sx_auth.credentials import DelegatedCredential, PresentedCredential, present_credential
from sx_auth.node import NodeKind, NodePrincipal, require_node, resolve_node
from sx_auth.principal import (
    DEV_PROJECT_ID,
    CredentialKind,
    OrgKind,
    OrgRef,
    ProjectId,
    ProjectRef,
    grants_for_project,
)


class ApiRole(StrEnum):
    """Byte-equal to the audience's reader/operator/admin rows in sx_authd's registry."""

    READER = "reader"
    OPERATOR = "operator"
    ADMIN = "admin"


_ROLE_RANK = {ApiRole.READER: 0, ApiRole.OPERATOR: 1, ApiRole.ADMIN: 2}
_DEFAULT_ROLE_MAP = {role.value: role for role in ApiRole}


@dataclass(frozen=True, slots=True)
class ApiPrincipal:
    principal_id: UUID | None
    subject: str
    project: ProjectRef
    role: ApiRole


DEV_PROJECT = ProjectRef(
    id=DEV_PROJECT_ID,
    slug="dev-local",
    org=OrgRef(id=UUID(int=0), slug="dev-local", kind=OrgKind.INTERNAL),
)
DEV_PRINCIPAL = ApiPrincipal(
    principal_id=None,
    subject="dev-local",
    project=DEV_PROJECT,
    role=ApiRole.ADMIN,
)
"""The auth-optional resolution: in-process composition, tests, and `just dev`."""


class RateLimitedError(Exception):
    """One principal exhausted one named request window."""

    def __init__(self, limit: RequestLimit, retry_after_s: int) -> None:
        self.limit = limit
        self.retry_after_s = retry_after_s
        super().__init__(
            f"{limit.name.value} rate limit exceeded ({limit.requests} requests/{limit.window_s}s)"
        )


class MeterUnavailableError(RuntimeError):
    """The configured production meter cannot make an admission decision."""


WINDOW_SLICES = 60
"""Every backend counts a window in at most this many slices.

The meter is a sliding-window *counter*, not a log of admissions: one count per slice,
each slice at least a sixtieth of the window (rounded up to a millisecond, so a
window is never counted short), and a slice is forgotten once all of it is older than
the window. No window of the declared length ever admits more than the limit, and a
refusal may outlast the window by at most one slice — a minute class is counted to the
second, ``login-failure`` to five seconds. The log this replaced stored one member per
admitted request, so the shared admission Redis's memory scaled with the *ceiling* rather
than with the number of active principals, and the point of a ceiling is that it can be
raised.
"""


def slice_ms(limit: RequestLimit) -> int:
    """The width of one slice of ``limit``'s window, in milliseconds."""
    return -(-(limit.window_s * 1000) // WINDOW_SLICES)


def retry_ms(window: Mapping[int, int], limit: RequestLimit, horizon_ms: int) -> int:
    """How long until enough of the oldest live slices are forgotten to admit one request.

    A window can hold more than its limit — ``note`` never refuses, so concurrent login
    failures overshoot — and then forgetting only the oldest slice is not enough. Walk
    the slices oldest-first until what remains is under the limit; the wait ends when
    the last slice walked is entirely older than the window. The Lua in
    :mod:`sx_auth.redis_meter` mirrors this arithmetic.
    """
    remaining = sum(window.values())
    width = slice_ms(limit)
    for index in sorted(window):
        remaining -= window[index]
        if remaining < limit.requests:
            return (index + 1) * width - horizon_ms
    # Unreachable while a limit admits at least one request (the registry refuses
    # `requests < 1`): the whole window must be forgotten. Refuse, as the Lua does.
    return (max(window) + 1) * width - horizon_ms


class RequestMeterBackend(Protocol):
    kind: str

    @property
    def ready(self) -> bool: ...

    async def ensure_ready(self) -> None: ...

    async def check(self, scope: str, limit: RequestLimit, subject: str) -> None: ...

    async def refuse_if_full(self, scope: str, limit: RequestLimit, subject: str) -> None: ...

    async def note(self, scope: str, limit: RequestLimit, subject: str) -> None: ...

    async def forget(self, scope: str, limit: RequestLimit, subject: str) -> None: ...

    async def aclose(self) -> None: ...


class InMemoryMeterBackend:
    """Explicit development/test backend; one async lock keeps the slice counts consistent.

    The same slices, forgetting rule, and retry as the Lua in :mod:`sx_auth.redis_meter`,
    so a door refuses in development exactly where it refuses in production.
    """

    kind = "memory"

    def __init__(self, *, clock: Callable[[], float] = time.monotonic) -> None:
        self._clock = clock
        self._windows: dict[tuple[str, str, int, str], dict[int, int]] = {}
        self._lock = asyncio.Lock()

    @property
    def ready(self) -> bool:
        return True

    async def ensure_ready(self) -> None:
        return None

    async def aclose(self) -> None:
        return None

    def _key(self, scope: str, limit: RequestLimit, subject: str) -> tuple[str, str, int, str]:
        # The window is part of the key, as in the Redis backend: a slice index is only
        # meaningful at the width that produced it.
        return scope, limit.name.value, limit.window_s, subject

    def _alive(self, scope: str, limit: RequestLimit, subject: str, now_ms: int) -> dict[int, int]:
        """The subject's live slice counts, every slice older than the window forgotten.

        A subject with nothing live holds no entry, so a subject that is only ever
        refused — a login throttle key is attacker-chosen — costs nothing.
        """
        key = self._key(scope, limit, subject)
        width = slice_ms(limit)
        horizon = now_ms - limit.window_s * 1000
        window = {
            index: count
            for index, count in self._windows.get(key, {}).items()
            if (index + 1) * width > horizon
        }
        if window:
            self._windows[key] = window
        else:
            self._windows.pop(key, None)
        return window

    def _refuse_if_full(self, scope: str, limit: RequestLimit, subject: str, now_ms: int) -> None:
        window = self._alive(scope, limit, subject, now_ms)
        if sum(window.values()) >= limit.requests:
            wait_ms = retry_ms(window, limit, now_ms - limit.window_s * 1000)
            raise RateLimitedError(limit, max(1, ceil(wait_ms / 1000)))

    def _count(self, scope: str, limit: RequestLimit, subject: str, now_ms: int) -> None:
        window = self._alive(scope, limit, subject, now_ms)
        current = now_ms // slice_ms(limit)
        window[current] = window.get(current, 0) + 1
        self._windows[self._key(scope, limit, subject)] = window

    def _now_ms(self) -> int:
        return int(self._clock() * 1000)

    async def check(self, scope: str, limit: RequestLimit, subject: str) -> None:
        async with self._lock:
            now_ms = self._now_ms()
            self._refuse_if_full(scope, limit, subject, now_ms)
            self._count(scope, limit, subject, now_ms)

    async def refuse_if_full(self, scope: str, limit: RequestLimit, subject: str) -> None:
        async with self._lock:
            self._refuse_if_full(scope, limit, subject, self._now_ms())

    async def note(self, scope: str, limit: RequestLimit, subject: str) -> None:
        async with self._lock:
            self._count(scope, limit, subject, self._now_ms())

    async def forget(self, scope: str, limit: RequestLimit, subject: str) -> None:
        async with self._lock:
            self._windows.pop(self._key(scope, limit, subject), None)


class RequestMeter:
    """One named window bound to a door scope and an injected state owner."""

    def __init__(
        self,
        limit: RequestLimit,
        *,
        scope: str | None = None,
        backend: RequestMeterBackend | None = None,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.limit = limit
        self.scope = scope or f"local-{uuid4().hex}"
        self._backend = backend or InMemoryMeterBackend(clock=clock)

    async def _observed(self, operation: str, action: Callable[[], Awaitable[None]]) -> None:
        from sx_service.observability import current_observability

        started = time.perf_counter()
        outcome = "ok"
        try:
            await action()
        except RateLimitedError:
            outcome = "rejected"
            raise
        except MeterUnavailableError:
            outcome = "unavailable"
            raise
        except Exception:
            outcome = "error"
            raise
        finally:
            attributes = {
                "door": self.scope,
                "rate_class": self.limit.name.value,
                "backend": self._backend.kind,
                "operation": operation,
                "outcome": outcome,
            }
            meter = current_observability().meter()
            meter.create_counter(
                "sx.rate_limit.decisions",
                description="Rate-limit admission decisions without subject identity",
            ).add(1, attributes)
            meter.create_histogram(
                "sx.rate_limit.decision.duration",
                unit="ms",
                description="Rate-limit backend decision latency",
            ).record((time.perf_counter() - started) * 1000, attributes)

    async def check(self, subject: str) -> None:
        """Refuse if the subject's window is full, and count this call against it."""
        await self._observed("check", lambda: self._backend.check(self.scope, self.limit, subject))

    async def refuse_if_full(self, subject: str) -> None:
        """The refusal half alone, for a meter counting something other than this call.

        `LoginThrottle` counts failed *attempts*, so the request it must refuse and the
        request it must count are different requests. Everything metering the call it is
        admitting uses `check`, which does both.
        """
        await self._observed(
            "refuse", lambda: self._backend.refuse_if_full(self.scope, self.limit, subject)
        )

    async def note(self, subject: str) -> None:
        """Count one event against the subject's window without refusing anything."""
        await self._observed("note", lambda: self._backend.note(self.scope, self.limit, subject))

    async def forget(self, subject: str) -> None:
        """Discard the subject's window — the budget is spent on failures, not successes."""
        await self._observed(
            "forget", lambda: self._backend.forget(self.scope, self.limit, subject)
        )


@dataclass(frozen=True, slots=True)
class RequestMeterFactory:
    scope: str
    backend: RequestMeterBackend

    def meter(self, limit: RequestLimit) -> RequestMeter:
        return RequestMeter(limit, scope=self.scope, backend=self.backend)

    @property
    def ready(self) -> bool:
        return self.backend.ready

    async def ensure_ready(self) -> None:
        await self.backend.ensure_ready()

    async def aclose(self) -> None:
        await self.backend.aclose()


def refusal_envelope(code: str, message: str, *, retryable: bool) -> dict[str, object]:
    """The shared guard's refusals wear the same envelope as every door's own.

    The platform's rate refusal used to be its least-enveloped answer — a bare
    string a client could not branch on. The trace id comes from the request's
    logging context, minted fresh only when no request is active.
    """
    return ErrorOut(
        code=code,
        message=message,
        retryable=retryable,
        trace_id=str(context_fields().get("trace_id") or uuid4().hex),
    ).model_dump()


async def enforce_request_limit(meter: RequestMeter, subject: str) -> None:
    """Apply a meter at an HTTP boundary with the platform's one 429 contract."""

    try:
        await meter.check(subject)
    except RateLimitedError as error:
        raise HTTPException(
            429,
            refusal_envelope("rate_limit_exceeded", str(error), retryable=True),
            headers={"Retry-After": str(error.retry_after_s)},
        ) from error
    except MeterUnavailableError as error:
        raise HTTPException(
            503,
            refusal_envelope(
                "rate_limit_unavailable", "rate-limit service unavailable", retryable=True
            ),
        ) from error


def metered[DependencyT](meter: RequestMeter, dependency: DependencyT) -> DependencyT:
    """Bind a door dependency to the meter it installs, and hand it back.

    A route's rate class is then a *property of the route* — read off the meter the
    route holds when the app is built (`sx_service.door`), published as `x-sx-rate`,
    and checked by `tools/check_rate_bindings.py`. The limit is never restated: it
    comes off `meter`, which is the object that refuses. Every door builds its
    dependency around a meter and passes both here in one expression, so there is no
    spelling of this in which the documented class and the enforced one can differ.
    """
    declare_rate(dependency, meter.limit)
    return dependency


def _selected_project(request: Request) -> ProjectId:
    raw = request.headers.get("x-sx-project-id")
    if raw is None:
        raise HTTPException(400, "missing X-SX-Project-Id")
    try:
        return ProjectId(UUID(raw))
    except ValueError as error:
        raise HTTPException(422, "invalid X-SX-Project-Id") from error


def request_credential(
    request: HTTPConnection,
) -> PresentedCredential | DelegatedCredential | None:
    """Parse the complete caller identity carried by one HTTP request."""

    credential = present_credential(request)
    raw_delegation_id = request.headers.get("x-sx-delegation-id")
    if raw_delegation_id is None:
        return credential
    if credential is None or credential.kind is not CredentialKind.API_KEY:
        raise HTTPException(401, "a delegation holder must use a service API key")
    try:
        delegation_id = UUID(raw_delegation_id)
    except ValueError as error:
        raise HTTPException(422, "invalid X-SX-Delegation-Id") from error
    return DelegatedCredential(credential, delegation_id)


async def resolve_principal(
    request: Request,
    client: AuthClient,
    meter: RequestMeter,
    *,
    auth_required: bool,
    role_map: Mapping[str, ApiRole] = _DEFAULT_ROLE_MAP,
) -> ApiPrincipal:
    credential = request_credential(request)
    if credential is None:
        if auth_required:
            raise HTTPException(401, "missing credential")
        return DEV_PRINCIPAL
    try:
        # Dispatched here rather than through AuthClient.introspect: the door is
        # written against the two named methods, which is the whole interface a
        # service has to stand up to inject a fake. Widening that so this one
        # call site can be shorter would break every minimal conformer.
        if isinstance(credential, DelegatedCredential):
            result = await client.introspect_delegation(credential.holder, credential.delegation_id)
        else:
            result = (
                await client.introspect_session(credential.raw)
                if credential.kind is CredentialKind.SESSION
                else await client.introspect_api_key(credential.raw)
            )
    except AuthUnavailableError as error:
        raise HTTPException(503, "auth service unavailable") from error
    if result is None:
        raise HTTPException(401, "unknown or revoked credential")
    project_id = _selected_project(request)
    grants = grants_for_project(result.principal, project_id)
    best: ApiRole | None = None
    for grant in grants:
        role = role_map.get(grant.role)
        if role is None:
            continue  # unknown role: dropped, never widened
        if best is None or _ROLE_RANK[role] >= _ROLE_RANK[best]:
            best = role
    if best is None:
        raise HTTPException(
            403,
            f"no {client.audience} grant for selected project on this credential",
        )
    await enforce_request_limit(meter, result.principal.subject)
    return ApiPrincipal(
        principal_id=result.principal.id,
        subject=result.principal.subject,
        project=grants[0].project,
        role=best,
    )


def require_role(principal: ApiPrincipal, required: ApiRole) -> None:
    if _ROLE_RANK[principal.role] < _ROLE_RANK[required]:
        raise HTTPException(403, f"role {required.value!r} required")


@dataclass(frozen=True, slots=True)
class NodeCaller:
    """A resolved machine caller on a node wire.

    ``principal`` is ``None`` only on the auth-optional dev path with no credential
    presented (the machine analogue of :data:`DEV_PRINCIPAL`) — then ``require`` passes
    any claim. A presented credential is always fully verified, so dev stacks running
    seeded machine keys exercise the real binding law end to end.
    """

    principal: NodePrincipal | None

    def require(self, claimed_name: str) -> None:
        """The binding law; raises :class:`sx_auth.node.NodeIdentityMismatchError`."""
        if self.principal is not None:
            require_node(self.principal, claimed_name)


async def resolve_node_principal(
    request: HTTPConnection,
    client: AuthClient,
    meter: RequestMeter,
    *,
    kind: NodeKind,
    auth_required: bool,
) -> NodeCaller:
    """The machine sibling of :func:`resolve_principal` — same client and meter, no
    ``X-SX-Project-Id`` (a machine's project derives from its single machine grant).

    Typed against ``HTTPConnection`` so a websocket authenticates through this one
    path too: the supervision wire's robots are machine callers like any other, and
    a socket that can command an arm must not get a second, laxer resolution.

    Credential-level failures raise ``HTTPException`` (401 unknown/missing, 503 outage,
    429 metered) exactly like the human path. Machine-resolution failures propagate as
    :class:`sx_auth.node.NodeAccessError` subclasses so each door maps them to its own
    typed 403 envelope — a door that does not catch them still refuses, never widens.
    """
    credential = present_credential(request)
    if credential is None or credential.kind is CredentialKind.SESSION:
        # A session cookie is a BROWSER credential; machines authenticate with
        # API keys only. A cookie that happens to ride a machine-wire request
        # (shared client, same origin) is not a machine credential — it neither
        # authenticates nor incriminates the caller here.
        if auth_required:
            raise HTTPException(401, "missing machine credential")
        return NodeCaller(principal=None)
    try:
        result = await client.introspect_api_key(credential.raw)
    except AuthUnavailableError as error:
        raise HTTPException(503, "auth service unavailable") from error
    if result is None:
        raise HTTPException(401, "unknown or revoked credential")
    node = resolve_node(result, kind)
    await enforce_request_limit(meter, result.principal.subject)
    return NodeCaller(principal=node)
