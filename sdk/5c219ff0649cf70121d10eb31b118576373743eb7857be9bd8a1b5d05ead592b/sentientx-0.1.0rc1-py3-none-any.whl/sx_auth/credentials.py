"""How a backend finds the credential on an inbound request.

Three kinds of caller reach a platform backend and each can carry exactly one
thing: an SDK or service sends ``Authorization: Bearer``, a script sends
``X-API-Key``, and a browser sends neither — it has only the platform session
cookie ``sx_session``, which the UI never sees and cannot attach by hand.

A backend that reads only the headers is therefore reachable by every caller
EXCEPT a browser, which is why an un-gated console is the usual symptom. One
extractor keeps that from being re-decided per service.
"""

from __future__ import annotations

from dataclasses import dataclass
from uuid import UUID

from fastapi.requests import HTTPConnection

from sx_auth.principal import CredentialKind

SESSION_COOKIE = "sx_session"


@dataclass(frozen=True, slots=True)
class PresentedCredential:
    """The one credential a request carries, and which door verifies it."""

    raw: str
    kind: CredentialKind


@dataclass(frozen=True, slots=True)
class DelegatedCredential:
    """A service credential acting through one Auth-owned delegation reference.

    Only ``delegation_id`` is durable. The holder's raw key comes from the activity
    environment and never enters a workflow payload or history.
    """

    holder: PresentedCredential
    delegation_id: UUID


def present_credential(request: HTTPConnection) -> PresentedCredential | None:
    """The credential on this connection, or ``None`` if it carries none.

    Headers win over the cookie: a browser tab that also holds a session may
    call with an explicit key, and the explicit act is the intended identity.
    An empty header value counts as absent — never introspect the empty string.

    Typed against ``HTTPConnection``, the Starlette base of both ``Request`` and
    ``WebSocket``, because a websocket carries a credential exactly as a request
    does — in its handshake headers. The supervision wire, where a robot holds a
    permanent socket, needs the same extractor rather than a second one.
    """
    auth = request.headers.get("authorization")
    if auth and auth.lower().startswith("bearer ") and auth[7:].strip():
        return PresentedCredential(auth[7:].strip(), CredentialKind.API_KEY)
    key = request.headers.get("x-api-key")
    if key and key.strip():
        return PresentedCredential(key.strip(), CredentialKind.API_KEY)
    session = request.cookies.get(SESSION_COOKIE)
    if session and session.strip():
        return PresentedCredential(session.strip(), CredentialKind.SESSION)
    return None
